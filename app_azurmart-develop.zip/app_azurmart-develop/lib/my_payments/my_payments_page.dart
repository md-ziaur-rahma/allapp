import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/payment_details/payment_details_page.dart';
import 'package:azuramartmy/provider_models/user_payment_lsit_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MyPayments extends StatelessWidget {
  const MyPayments({Key? key}) : super(key: key);
  Future<UserPaymentModel?> fetchUserPaymentList() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Client client = Client();
    var url = Uri.parse(Urls.baseUrl + Urls.userPaymentList);
    print('user balance list ($url)');
    var response = await client.post(url, body: {
      'session': '$session',
      'user_id': '$userId',
      'token': '$token',
    });
    print(response.body);
    if (response.statusCode == 200) {
      final Map<String, dynamic> body = await json.decode(response.body);
      UserPaymentModel userPaymentModel = UserPaymentModel.fromJson(body);
      if (response.body.isNotEmpty) {
        return userPaymentModel;
      }
    } else {
      throw Exception('Failed to load post');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'My Payments',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: AppsColors.buttonColor,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.light : SystemUiOverlayStyle(
            statusBarColor: AppsColors.buttonColor,
            statusBarIconBrightness: Brightness.light),
      ),
      body: SafeArea(
        child: FutureBuilder(
          future: fetchUserPaymentList(),
          builder:
              (BuildContext context, AsyncSnapshot<UserPaymentModel?> snapshot) {
            if (snapshot.hasData) {
              if (snapshot.data!.data!.isNotEmpty) {
                return CustomScrollView(
                  scrollDirection: Axis.vertical,
                  slivers: [
                    SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (BuildContext context, index) {
                          return PaymentListItem(
                            snapshot: snapshot,
                            index: index,
                          );
                        },
                        childCount: snapshot.data!.data!.length,
                      ),
                    )
                  ],
                );
              } else {
                return const Center(
                  child: Text(
                    'Payment Not Found!',
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 18,
                        fontWeight: FontWeight.bold),
                  ),
                );
              }
            } else if (snapshot.hasError) {
              return Center(
                child: Text(snapshot.error.toString()),
              );
            }
            return LoadingWidget(
              color: AppsColors.buttonColor,
            );
          },
        ),
      ),
    );
  }
}

class PaymentListItem extends StatelessWidget {
  PaymentListItem({Key? key, required this.snapshot, this.index}) : super(key: key);
  final AsyncSnapshot<UserPaymentModel?> snapshot;
  final int? index;

  final f = DateFormat('MMM-dd-yyyy  hh:mm aa');

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      margin: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(6.0),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: const Color(0xFFF4F4F4),
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'PAY ID #',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  '${snapshot.data!.data![index!].code}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Source',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  '${snapshot.data!.data![index!].type}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Date',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  f.format(DateTime.parse(snapshot.data!.data![index!].paymentDate!)),
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Apply To',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ...List.generate(
                      snapshot.data!.data![index!].order!.length,
                      (orderIndex) => Text(
                        '${snapshot.data!.data![index!].order![orderIndex].orderNo} - ${snapshot.data!.data![index!].order![orderIndex].amount!.toStringAsFixed(2)}',
                        style: const TextStyle(
                            color: Colors.black87,
                            fontWeight: FontWeight.normal,
                            fontSize: 16),
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Amount',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  'RM${snapshot.data!.data![index!].mrAmount!.toStringAsFixed(2)}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Expanded(
                  flex: 1,
                  child: Text(
                    'Status',
                    style: TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                        fontSize: 16),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Text(
                    snapshot.data!.data![index!].isMatched == 1
                        ? ' Verified '
                        : ' Not Verified ',
                    textAlign: TextAlign.end,
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.normal,
                        backgroundColor:
                            snapshot.data!.data![index!].isMatched == 1
                                ? Colors.green
                                : Colors.amber,
                        fontSize: 16),
                  ),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                TextButton(
                  onPressed: () async {
                    Navigator.of(context)
                        .push(CustomRoutePageBuilder.createPageRouteLeft(
                            context,
                            PaymentDetailsPage(
                              txnId: snapshot.data!.data![index!].pkNo,
                            )));
                  },
                  child: Text(
                    'Payment Details',
                    style: TextStyle(color: AppsColors.blueGreenX),
                  ),
                ),
                const Text('')
              ],
            ),
          ),
        ],
      ),
    );
  }
}
