
class AddressListModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  Data? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  Data? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;


  set status(int? value) {
    _status = value;
  }

  AddressListModel({
      int? status, 
      bool? success, 
      int? code, 
      String? message, 
      String? description, 
      Data? data, 
      dynamic errors, 
      Api? api}){
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
}

  AddressListModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    _data = json["data"] != null ? Data.fromJson(json["data"]) : null;
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.toJson();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }

  set success(bool? value) {
    _success = value;
  }

  set code(int? value) {
    _code = value;
  }

  set message(String? value) {
    _message = value;
  }

  set description(String? value) {
    _description = value;
  }

  set data(Data? value) {
    _data = value;
  }

  set errors(dynamic value) {
    _errors = value;
  }

  set api(Api? value) {
    _api = value;
  }
}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;


  set version(String? value) {
    _version = value;
  }

  Api({
      String? version}){
    _version = version;
}

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }

}

class Data {
  List<Shipping_address>? _shippingAddress;
  Billing_address? _billingAddress;

  List<Shipping_address>? get shippingAddress => _shippingAddress;
  Billing_address? get billingAddress => _billingAddress;


  set shippingAddress(List<Shipping_address>? value) {
    _shippingAddress = value;
  }

  Data({
      List<Shipping_address>? shippingAddress, 
      Billing_address? billingAddress}){
    _shippingAddress = shippingAddress;
    _billingAddress = billingAddress;
}

  Data.fromJson(dynamic json) {
    if (json["shipping_address"] != null) {
      _shippingAddress = [];
      json["shipping_address"].forEach((v) {
        _shippingAddress!.add(Shipping_address.fromJson(v));
      });
    }
    _billingAddress = json["billing_address"] != "" ? Billing_address.fromJson(json["billing_address"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_shippingAddress != null) {
      map["shipping_address"] = _shippingAddress!.map((v) => v.toJson()).toList();
    }
    if (_billingAddress != null) {
      map["billing_address"] = _billingAddress!.toJson();
    }
    return map;
  }

  set billingAddress(Billing_address? value) {
    _billingAddress = value;
  }
}

class Billing_address {
  int? _pkno;
  int? _code;
  String? _name;
  String? _lastname;
  String? _telno;
  String? _addressline1;
  String? _addressline2;
  String? _addressline3;
  String? _addressline4;
  String? _state;
  String? _city;
  String? _postcode;
  int? _fcityno;
  int? _fstateno;
  int? _fcountryno;
  String? _country;
  String? _location;
  int? _faddresstypeno;
  int? _addresstype;
  int? _isactive;
  int? _fcustomerno;
  int? _fresellerno;
  int? _isdefault;

  int? get pkno => _pkno;
  int? get code => _code;
  String? get name => _name;
  String? get lastname => _lastname;
  String? get telno => _telno;
  String? get addressline1 => _addressline1;
  String? get addressline2 => _addressline2;
  String? get addressline3 => _addressline3;
  String? get addressline4 => _addressline4;
  String? get state => _state;
  String? get city => _city;
  String? get postcode => _postcode;
  int? get fcityno => _fcityno;
  int? get fstateno => _fstateno;
  int? get fcountryno => _fcountryno;
  String? get country => _country;
  String? get location => _location;
  int? get faddresstypeno => _faddresstypeno;
  int? get addresstype => _addresstype;
  int? get isactive => _isactive;
  int? get fcustomerno => _fcustomerno;
  int? get fresellerno => _fresellerno;
  int? get isdefault => _isdefault;


  set pkno(int? value) {
    _pkno = value;
  }


  set fcityno(int? value) {
    _fcityno = value;
  }

  Billing_address({
      int? pkno, 
      int? code, 
      String? name, 
      String? lastname, 
      String? telno, 
      String? addressline1, 
      String? addressline2, 
      String? addressline3, 
      String? addressline4, 
      String? state, 
      String? city, 
      String? postcode,
    int? fcityno,
    int? fstateno,
      int? fcountryno, 
      String? country, 
      String? location, 
      int? faddresstypeno, 
      int? addresstype, 
      int? isactive, 
      int? fcustomerno, 
      int? fresellerno, 
      int? isdefault}){
    _pkno = pkno;
    _code = code;
    _name = name;
    _lastname = lastname;
    _telno = telno;
    _addressline1 = addressline1;
    _addressline2 = addressline2;
    _addressline3 = addressline3;
    _addressline4 = addressline4;
    _state = state;
    _city = city;
    _postcode = postcode;
    _fcityno = fcityno;
    _fstateno = fstateno;
    _fcountryno = fcountryno;
    _country = country;
    _location = location;
    _faddresstypeno = faddresstypeno;
    _addresstype = addresstype;
    _isactive = isactive;
    _fcustomerno = fcustomerno;
    _fresellerno = fresellerno;
    _isdefault = isdefault;
}

  Billing_address.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _code = json["CODE"];
    _name = json["NAME"];
    _lastname = json["LAST_NAME"];
    _telno = json["TEL_NO"];
    _addressline1 = json["ADDRESS_LINE_1"];
    _addressline2 = json["ADDRESS_LINE_2"];
    _addressline3 = json["ADDRESS_LINE_3"];
    _addressline4 = json["ADDRESS_LINE_4"];
    _state = json["STATE"];
    _city = json["CITY"];
    _postcode = json["POST_CODE"];
    _fcityno = json["F_CITY_NO"];
    _fstateno = json["F_STATE_NO"];
    _fcountryno = json["F_COUNTRY_NO"];
    _country = json["COUNTRY"];
    _location = json["LOCATION"];
    _faddresstypeno = json["F_ADDRESS_TYPE_NO"];
    _addresstype = json["ADDRESS_TYPE"];
    _isactive = json["IS_ACTIVE"];
    _fcustomerno = json["F_CUSTOMER_NO"];
    _fresellerno = json["F_RESELLER_NO"];
    _isdefault = json["IS_DEFAULT"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["CODE"] = _code;
    map["NAME"] = _name;
    map["LAST_NAME"] = _lastname;
    map["TEL_NO"] = _telno;
    map["ADDRESS_LINE_1"] = _addressline1;
    map["ADDRESS_LINE_2"] = _addressline2;
    map["ADDRESS_LINE_3"] = _addressline3;
    map["ADDRESS_LINE_4"] = _addressline4;
    map["STATE"] = _state;
    map["CITY"] = _city;
    map["POST_CODE"] = _postcode;
    map["F_CITY_NO"] = _fcityno;
    map["F_STATE_NO"] = _fstateno;
    map["F_COUNTRY_NO"] = _fcountryno;
    map["COUNTRY"] = _country;
    map["LOCATION"] = _location;
    map["F_ADDRESS_TYPE_NO"] = _faddresstypeno;
    map["ADDRESS_TYPE"] = _addresstype;
    map["IS_ACTIVE"] = _isactive;
    map["F_CUSTOMER_NO"] = _fcustomerno;
    map["F_RESELLER_NO"] = _fresellerno;
    map["IS_DEFAULT"] = _isdefault;
    return map;
  }

  set code(int? value) {
    _code = value;
  }

  set name(String? value) {
    _name = value;
  }

  set lastname(String? value) {
    _lastname = value;
  }

  set telno(String? value) {
    _telno = value;
  }

  set addressline1(String? value) {
    _addressline1 = value;
  }

  set addressline2(String? value) {
    _addressline2 = value;
  }

  set addressline3(String? value) {
    _addressline3 = value;
  }

  set addressline4(String? value) {
    _addressline4 = value;
  }

  set state(String? value) {
    _state = value;
  }

  set city(String? value) {
    _city = value;
  }

  set postcode(String? value) {
    _postcode = value;
  }

  set fcountryno(int? value) {
    _fcountryno = value;
  }

  set country(String? value) {
    _country = value;
  }

  set location(String? value) {
    _location = value;
  }

  set faddresstypeno(int? value) {
    _faddresstypeno = value;
  }

  set addresstype(int? value) {
    _addresstype = value;
  }

  set isactive(int? value) {
    _isactive = value;
  }

  set fcustomerno(int? value) {
    _fcustomerno = value;
  }

  set fresellerno(int? value) {
    _fresellerno = value;
  }

  set isdefault(int? value) {
    _isdefault = value;
  }

  set fstateno(int? value) {
    _fstateno = value;
  }
}

class Shipping_address {
  int? _pkno;
  int? _code;
  String? _name;
  String? _lastname;
  String? _telno;
  String? _addressline1;
  String? _addressline2;
  String? _addressline3;
  String? _addressline4;
  String? _state;
  String? _city;
  String? _postcode;
  int? _fcityno;
  int? _fstateno;
  int? _fcountryno;
  String? _country;
  String? _location;
  int? _faddresstypeno;
  int? _addresstype;
  int? _isactive;
  int? _fcustomerno;
  int? _fresellerno;
  int? _isdefault;

  int? get pkno => _pkno;
  int? get code => _code;
  String? get name => _name;
  String? get lastname => _lastname;
  String? get telno => _telno;
  String? get addressline1 => _addressline1;
  String? get addressline2 => _addressline2;
  String? get addressline3 => _addressline3;
  String? get addressline4 => _addressline4;
  String? get state => _state;
  String? get city => _city;
  String? get postcode => _postcode;
  int? get fcityno => _fcityno;
  int? get fstateno => _fstateno;
  int? get fcountryno => _fcountryno;
  String? get country => _country;
  String? get location => _location;
  int? get faddresstypeno => _faddresstypeno;
  int? get addresstype => _addresstype;
  int? get isactive => _isactive;
  int? get fcustomerno => _fcustomerno;
  int? get fresellerno => _fresellerno;
  int? get isdefault => _isdefault;


  set pkno(int? value) {
    _pkno = value;
  }


  set fcityno(int? value) {
    _fcityno = value;
  }

  Shipping_address({
      int? pkno, 
      int? code, 
      String? name, 
      String? lastname, 
      String? telno, 
      String? addressline1, 
      String? addressline2, 
      String? addressline3, 
      String? addressline4, 
      String? state, 
      String? city, 
      String? postcode,
    int? fcityno,
    int? fstateno,
    int? fcountryno,
      String? country, 
      String? location, 
      int? faddresstypeno, 
      int? addresstype, 
      int? isactive, 
      int? fcustomerno, 
      int? fresellerno, 
      int? isdefault}){
    _pkno = pkno;
    _code = code;
    _name = name;
    _lastname = lastname;
    _telno = telno;
    _addressline1 = addressline1;
    _addressline2 = addressline2;
    _addressline3 = addressline3;
    _addressline4 = addressline4;
    _state = state;
    _city = city;
    _postcode = postcode;
    _fcityno = fcityno;
    _fstateno = fstateno;
    _fcountryno = fcountryno;
    _country = country;
    _location = location;
    _faddresstypeno = faddresstypeno;
    _addresstype = addresstype;
    _isactive = isactive;
    _fcustomerno = fcustomerno;
    _fresellerno = fresellerno;
    _isdefault = isdefault;
}

  Shipping_address.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _code = json["CODE"];
    _name = json["NAME"];
    _lastname = json["LAST_NAME"];
    _telno = json["TEL_NO"];
    _addressline1 = json["ADDRESS_LINE_1"];
    _addressline2 = json["ADDRESS_LINE_2"];
    _addressline3 = json["ADDRESS_LINE_3"];
    _addressline4 = json["ADDRESS_LINE_4"];
    _state = json["STATE"];
    _city = json["CITY"];
    _postcode = json["POST_CODE"];
    _fcityno = json["F_CITY_NO"];
    _fstateno = json["F_STATE_NO"];
    _fcountryno = json["F_COUNTRY_NO"];
    _country = json["COUNTRY"];
    _location = json["LOCATION"];
    _faddresstypeno = json["F_ADDRESS_TYPE_NO"];
    _addresstype = json["ADDRESS_TYPE"];
    _isactive = json["IS_ACTIVE"];
    _fcustomerno = json["F_CUSTOMER_NO"];
    _fresellerno = json["F_RESELLER_NO"];
    _isdefault = json["IS_DEFAULT"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["CODE"] = _code;
    map["NAME"] = _name;
    map["LAST_NAME"] = _lastname;
    map["TEL_NO"] = _telno;
    map["ADDRESS_LINE_1"] = _addressline1;
    map["ADDRESS_LINE_2"] = _addressline2;
    map["ADDRESS_LINE_3"] = _addressline3;
    map["ADDRESS_LINE_4"] = _addressline4;
    map["STATE"] = _state;
    map["CITY"] = _city;
    map["POST_CODE"] = _postcode;
    map["F_CITY_NO"] = _fcityno;
    map["F_STATE_NO"] = _fstateno;
    map["F_COUNTRY_NO"] = _fcountryno;
    map["COUNTRY"] = _country;
    map["LOCATION"] = _location;
    map["F_ADDRESS_TYPE_NO"] = _faddresstypeno;
    map["ADDRESS_TYPE"] = _addresstype;
    map["IS_ACTIVE"] = _isactive;
    map["F_CUSTOMER_NO"] = _fcustomerno;
    map["F_RESELLER_NO"] = _fresellerno;
    map["IS_DEFAULT"] = _isdefault;
    return map;
  }

  set code(int? value) {
    _code = value;
  }

  set name(String? value) {
    _name = value;
  }

  set lastname(String? value) {
    _lastname = value;
  }

  set telno(String? value) {
    _telno = value;
  }

  set addressline1(String? value) {
    _addressline1 = value;
  }

  set addressline2(String? value) {
    _addressline2 = value;
  }

  set addressline3(String? value) {
    _addressline3 = value;
  }

  set addressline4(String? value) {
    _addressline4 = value;
  }

  set state(String? value) {
    _state = value;
  }

  set city(String? value) {
    _city = value;
  }

  set postcode(String? value) {
    _postcode = value;
  }

  set fcountryno(int? value) {
    _fcountryno = value;
  }

  set country(String? value) {
    _country = value;
  }

  set location(String? value) {
    _location = value;
  }

  set faddresstypeno(int? value) {
    _faddresstypeno = value;
  }

  set addresstype(int? value) {
    _addresstype = value;
  }

  set isactive(int? value) {
    _isactive = value;
  }

  set fcustomerno(int? value) {
    _fcustomerno = value;
  }

  set fresellerno(int? value) {
    _fresellerno = value;
  }

  set isdefault(int? value) {
    _isdefault = value;
  }

  set fstateno(int? value) {
    _fstateno = value;
  }
}