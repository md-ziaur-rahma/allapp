// To parse this JSON data, do
//
//     final orderDetailsModel = orderDetailsModelFromJson(jsonString);

import 'dart:convert';

OrderDetailsModel orderDetailsModelFromJson(String str) => OrderDetailsModel.fromJson(json.decode(str));

String orderDetailsModelToJson(OrderDetailsModel data) => json.encode(data.toJson());

class OrderDetailsModel {
  OrderDetailsModel({
    this.status,
    this.success,
    this.code,
    this.message,
    this.description,
    this.data,
    this.errors,
    this.api,
  });

  int? status;
  bool? success;
  int? code;
  String? message;
  String? description;
  Data? data;
  dynamic errors;
  Api? api;

  factory OrderDetailsModel.fromJson(Map<String, dynamic> json) => OrderDetailsModel(
    status: json["status"],
    success: json["success"],
    code: json["code"],
    message: json["message"],
    description: json["description"],
    data: Data.fromJson(json["data"]),
    errors: json["errors"],
    api: Api.fromJson(json["api"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "code": code,
    "message": message,
    "description": description,
    "data": data!.toJson(),
    "errors": errors,
    "api": api!.toJson(),
  };
}

class Api {
  Api({
    this.version,
  });

  String? version;

  factory Api.fromJson(Map<String, dynamic> json) => Api(
    version: json["version"],
  );

  Map<String, dynamic> toJson() => {
    "version": version,
  };
}

class Data {
  Data({
    this.booking,
    this.order,
    this.bundle,
    this.nonBundle,
    this.returnedItems,
    this.deletedItems,
    this.payments,
    this.refunded,
    this.dispatched,
    this.bookChild,
    this.billingAddress,
    this.subtotal,
    this.totalPostage,
    this.penalty,
    this.cancelFee,
    this.discount,
    this.total,
    this.due,
    this.paymentAmount,
    this.prdArrivalTime,
  });

  Booking? booking;
  Order? order;
  List<List<Bundle>>? bundle;
  List<List<NonBundle>>? nonBundle;
  List<ReturnedItem>? returnedItems;
  List<DeletedItem>? deletedItems;
  List<Payment>? payments;
  List<Refunded>? refunded;
  List<Dispatched>? dispatched;
  List<BookChild>? bookChild;
  BillingAddress? billingAddress;
  double? subtotal;
  double? totalPostage;
  double? penalty;
  double? cancelFee;
  double? discount;
  double? total;
  double? due;
  double? paymentAmount;
  int? prdArrivalTime;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    booking: Booking.fromJson(json["booking"]),
    order: Order.fromJson(json["order"]),
    bundle: List<List<Bundle>>.from(json["bundle"].map((x) => List<Bundle>.from(x.map((x) => Bundle.fromJson(x))))),
    nonBundle: List<List<NonBundle>>.from(json["non_bundle"].map((x) => List<NonBundle>.from(x.map((x) => NonBundle.fromJson(x))))),
    returnedItems: List<ReturnedItem>.from(json["returned_items"].map((x) => ReturnedItem.fromJson(x))),
    deletedItems: List<DeletedItem>.from(json["deleted_items"].map((x) => DeletedItem.fromJson(x))),
    payments: List<Payment>.from(json["payments"].map((x) => Payment.fromJson(x))),
    refunded: List<Refunded>.from(json["refunded"].map((x) => Refunded.fromJson(x))),
    dispatched: List<Dispatched>.from(json["dispatched"].map((x) => Dispatched.fromJson(x))),
    bookChild: List<BookChild>.from(json["book_childs"].map((x) => BookChild.fromJson(x))),
    billingAddress: BillingAddress.fromJson(json["billing_address"]),
    subtotal: json["subtotal"] is int
        ? (json['subtotal'] as int).toDouble()
        : json['subtotal'],
    totalPostage: json["total_postage"] is int
        ? (json['total_postage'] as int).toDouble()
        : json['total_postage'],
    penalty: json["penalty"] is int
        ? (json['penalty'] as int).toDouble()
        : json['penalty'],
    cancelFee: json["cancel_fee"] is int
        ? (json['cancel_fee'] as int).toDouble()
        : json['cancel_fee'],
    discount: json["discount"] is int
        ? (json['discount'] as int).toDouble()
        : json['discount'],
    total: json["total"] is int
        ? (json['total'] as int).toDouble()
        : json['total'],
    due: json["due"] is int
        ? (json['due'] as int).toDouble()
        : json['due'],
    paymentAmount: json["payment_amount"] is int
        ? (json['payment_amount'] as int).toDouble()
        : json['payment_amount'],
    prdArrivalTime: json["prd_arrival_time"],
  );

  Map<String, dynamic> toJson() => {
    "booking": booking!.toJson(),
    "order": order!.toJson(),
    "bundle": List<dynamic>.from(bundle!.map((x) => List<dynamic>.from(x.map((x) => x.toJson())))),
    "non_bundle": List<dynamic>.from(nonBundle!.map((x) => List<dynamic>.from(x.map((x) => x.toJson())))),
    "returned_items": List<dynamic>.from(returnedItems!.map((x) => x.toJson())),
    "deleted_items": List<dynamic>.from(deletedItems!.map((x) => x.toJson())),
    "payments": List<dynamic>.from(payments!.map((x) => x.toJson())),
    "refunded": List<dynamic>.from(refunded!.map((x) => x.toJson())),
    "dispatched": List<dynamic>.from(dispatched!.map((x) => x.toJson())),
    "book_childs": List<dynamic>.from(bookChild!.map((x) => x.toJson())),
    "billing_address": billingAddress!.toJson(),
    "subtotal": subtotal,
    "total_postage": totalPostage,
    "penalty": penalty,
    "cancel_fee": cancelFee,
    "discount": discount,
    "total": total,
    "due": due,
    "payment_amount": paymentAmount,
    "prd_arrival_time": prdArrivalTime,
  };
}

class Booking {
  Booking({
    this.pkNo,
    this.bookingNo,
    this.rebookingTime,
    this.bookingTime,
    this.expieryDateTime,
    this.confirmTime,
    this.reconfirmTime,
    this.fBookingSalesAgentNo,
    this.bookingSalesAgentName,
    this.bookingStatus,
    this.bookingNotes,
    this.fCustomerNo,
    this.customerName,
    this.isReseller,
    this.fResellerNo,
    this.resellerName,
    this.comments,
    this.isActive,
    this.cancelFee,
    this.penaltyFee,
    this.penaltyNote,
    this.isExpired,
    this.addColVarchar2,
    this.fSsCreatedBy,
    this.ssCreatedOn,
    this.fSsModifiedBy,
    this.ssModifiedOn,
    this.fSsCompanyNo,
    this.freightCost,
    this.postageCost,
    this.totalPrice,
    this.totalPriceBeforeReturn,
    this.discount,
    this.totalCommission,
    this.totalItemQty,
    this.isBundleMatched,
    this.customerPostage,
    this.isReadBookingNotes,
    this.readByBookingNotes,
    this.cancelRequestBy,
    this.cancelRequestAt,
    this.cancelNote,
    this.canceledAt,
    this.isReturn,
  });

  int? pkNo;
  int? bookingNo;
  String? rebookingTime;
  String? bookingTime;
  String? expieryDateTime;
  String? confirmTime;
  String? reconfirmTime;
  int? fBookingSalesAgentNo;
  String? bookingSalesAgentName;
  int? bookingStatus;
  String? bookingNotes;
  int? fCustomerNo;
  String? customerName;
  int? isReseller;
  dynamic fResellerNo;
  dynamic resellerName;
  dynamic comments;
  int? isActive;
  double? cancelFee;
  double? penaltyFee;
  dynamic penaltyNote;
  int? isExpired;
  dynamic addColVarchar2;
  int? fSsCreatedBy;
  String? ssCreatedOn;
  int? fSsModifiedBy;
  String? ssModifiedOn;
  dynamic fSsCompanyNo;
  double? freightCost;
  double? postageCost;
  double? totalPrice;
  double? totalPriceBeforeReturn;
  double? discount;
  double? totalCommission;
  int? totalItemQty;
  int? isBundleMatched;
  double? customerPostage;
  int? isReadBookingNotes;
  dynamic readByBookingNotes;
  dynamic cancelRequestBy;
  dynamic cancelRequestAt;
  dynamic cancelNote;
  dynamic canceledAt;
  int? isReturn;

  factory Booking.fromJson(Map<String, dynamic> json) => Booking(
    pkNo: json["PK_NO"],
    bookingNo: json["BOOKING_NO"],
    rebookingTime: json["REBOOKING_TIME"],
    bookingTime: json["BOOKING_TIME"],
    expieryDateTime: json["EXPIERY_DATE_TIME"],
    confirmTime: json["CONFIRM_TIME"],
    reconfirmTime: json["RECONFIRM_TIME"],
    fBookingSalesAgentNo: json["F_BOOKING_SALES_AGENT_NO"],
    bookingSalesAgentName: json["BOOKING_SALES_AGENT_NAME"],
    bookingStatus: json["BOOKING_STATUS"],
    bookingNotes: json["BOOKING_NOTES"],
    fCustomerNo: json["F_CUSTOMER_NO"],
    customerName: json["CUSTOMER_NAME"],
    isReseller: json["IS_RESELLER"],
    fResellerNo: json["F_RESELLER_NO"],
    resellerName: json["RESELLER_NAME"],
    comments: json["COMMENTS"],
    isActive: json["IS_ACTIVE"],
    cancelFee: json["CANCEL_FEE"] is int
      ? (json['CANCEL_FEE'] as int).toDouble()
      : json['CANCEL_FEE'],
    penaltyFee: json["PENALTY_FEE"] is int
      ? (json['PENALTY_FEE'] as int).toDouble()
      : json['PENALTY_FEE'],
    penaltyNote: json["PENALTY_NOTE"],
    isExpired: json["IS_EXPAIRED"],
    addColVarchar2: json["ADD_COL_VARCHAR_2"],
    fSsCreatedBy: json["F_SS_CREATED_BY"],
    ssCreatedOn: json["SS_CREATED_ON"],
    fSsModifiedBy: json["F_SS_MODIFIED_BY"],
    ssModifiedOn: json["SS_MODIFIED_ON"],
    fSsCompanyNo: json["F_SS_COMPANY_NO"],
    freightCost: json["FREIGHT_COST"] is int
      ? (json['FREIGHT_COST'] as int).toDouble()
      : json['FREIGHT_COST'],
    postageCost: json["POSTAGE_COST"] is int
      ? (json['POSTAGE_COST'] as int).toDouble()
      : json['POSTAGE_COST'],
    totalPrice: json["TOTAL_PRICE"] is int
      ? (json['TOTAL_PRICE'] as int).toDouble()
      : json['TOTAL_PRICE'],
    totalPriceBeforeReturn: json["TOTAL_PRICE_BEFORE_RETURN"] is int
      ? (json['TOTAL_PRICE_BEFORE_RETURN'] as int).toDouble()
      : json['TOTAL_PRICE_BEFORE_RETURN'],
    discount: json["DISCOUNT"] is int
      ? (json['DISCOUNT'] as int).toDouble()
      : json['DISCOUNT'],
    totalCommission: json["TOTAL_COMISSION"] is int
      ? (json['TOTAL_COMISSION'] as int).toDouble()
      : json['TOTAL_COMISSION'],
    totalItemQty: json["TOTAL_ITEM_QTY"],
    isBundleMatched: json["IS_BUNDLE_MATCHED"],
    customerPostage: json["CUSTOMER_POSTAGE"] is int
      ? (json['CUSTOMER_POSTAGE'] as int).toDouble()
      : json['CUSTOMER_POSTAGE'],
    isReadBookingNotes: json["IS_READ_BOOKING_NOTES"],
    readByBookingNotes: json["READ_BY_BOOKING_NOTES"],
    cancelRequestBy: json["CANCEL_REQUEST_BY"],
    cancelRequestAt: json["CANCEL_REQUEST_AT"],
    cancelNote: json["CANCEL_NOTE"],
    canceledAt: json["CANCELED_AT"],
    isReturn: json["IS_RETURN"],
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "BOOKING_NO": bookingNo,
    "REBOOKING_TIME": rebookingTime,
    "BOOKING_TIME": bookingTime,
    "EXPIERY_DATE_TIME": expieryDateTime,
    "CONFIRM_TIME": confirmTime,
    "RECONFIRM_TIME": reconfirmTime,
    "F_BOOKING_SALES_AGENT_NO": fBookingSalesAgentNo,
    "BOOKING_SALES_AGENT_NAME": bookingSalesAgentName,
    "BOOKING_STATUS": bookingStatus,
    "BOOKING_NOTES": bookingNotes,
    "F_CUSTOMER_NO": fCustomerNo,
    "CUSTOMER_NAME": customerName,
    "IS_RESELLER": isReseller,
    "F_RESELLER_NO": fResellerNo,
    "RESELLER_NAME": resellerName,
    "COMMENTS": comments,
    "IS_ACTIVE": isActive,
    "CANCEL_FEE": cancelFee,
    "PENALTY_FEE": penaltyFee,
    "PENALTY_NOTE": penaltyNote,
    "IS_EXPAIRED": isExpired,
    "ADD_COL_VARCHAR_2": addColVarchar2,
    "F_SS_CREATED_BY": fSsCreatedBy,
    "SS_CREATED_ON": ssCreatedOn,
    "F_SS_MODIFIED_BY": fSsModifiedBy,
    "SS_MODIFIED_ON": ssModifiedOn,
    "F_SS_COMPANY_NO": fSsCompanyNo,
    "FREIGHT_COST": freightCost,
    "POSTAGE_COST": postageCost,
    "TOTAL_PRICE": totalPrice,
    "TOTAL_PRICE_BEFORE_RETURN": totalPriceBeforeReturn,
    "DISCOUNT": discount,
    "TOTAL_COMISSION": totalCommission,
    "TOTAL_ITEM_QTY": totalItemQty,
    "IS_BUNDLE_MATCHED": isBundleMatched,
    "CUSTOMER_POSTAGE": customerPostage,
    "IS_READ_BOOKING_NOTES": isReadBookingNotes,
    "READ_BY_BOOKING_NOTES": readByBookingNotes,
    "CANCEL_REQUEST_BY": cancelRequestBy,
    "CANCEL_REQUEST_AT": cancelRequestAt,
    "CANCEL_NOTE": cancelNote,
    "CANCELED_AT": canceledAt,
    "IS_RETURN": isReturn,
  };
}

class Bundle {
  Bundle({
    this.fBookingNo,
    this.fInvStockNo,
    this.fBundleNo,
    this.fVariantNo,
    this.totalRegularBundlePrice,
    this.totalRegularPrice,
    this.totalInstallmentPrice,
    this.totalInstallmentBundlePrice,
    this.matchedQty,
    this.bundleQty,
    this.bundleNamePublic,
    this.bundleName,
    this.pSs,
    this.pSm,
    this.pAir,
    this.pSea,
    this.rSs,
    this.rSm,
    this.rAir,
    this.rSea,
    this.imagePath,
    this.bundleInvs,
    this.bundleBreakdown,
    this.defaultAmount,
    this.savedAmount,
    this.unitPrice,
    this.currentIsRegular,
    this.currentIsSm,
    this.returnedItems,
    this.deletedItems,
  });

  int? fBookingNo;
  int? fInvStockNo;
  int? fBundleNo;
  int? fVariantNo;
  double? totalRegularBundlePrice;
  double? totalRegularPrice;
  double? totalInstallmentPrice;
  double? totalInstallmentBundlePrice;
  int? matchedQty;
  int? bundleQty;
  String? bundleNamePublic;
  String? bundleName;
  double? pSs;
  double? pSm;
  double? pAir;
  double? pSea;
  double? rSs;
  double? rSm;
  double? rAir;
  double? rSea;
  dynamic imagePath;
  String? bundleInvs;
  List<BundleBreakdown>? bundleBreakdown;
  double? defaultAmount;
  double? savedAmount;
  double? unitPrice;
  int? currentIsRegular;
  int? currentIsSm;
  List<dynamic>? returnedItems;
  List<dynamic>? deletedItems;

  factory Bundle.fromJson(Map<String, dynamic> json) => Bundle(
    fBookingNo: json["F_BOOKING_NO"],
    fInvStockNo: json["F_INV_STOCK_NO"],
    fBundleNo: json["F_BUNDLE_NO"],
    fVariantNo: json["F_VARIANT_NO"],
    totalRegularBundlePrice: json["TOTAL_REGULAR_BUNDLE_PRICE"] is int
      ? (json['TOTAL_REGULAR_BUNDLE_PRICE'] as int).toDouble()
      : json['TOTAL_REGULAR_BUNDLE_PRICE'],
    totalRegularPrice: json["TOTAL_REGULAR_PRICE"] is int
      ? (json['TOTAL_REGULAR_PRICE'] as int).toDouble()
      : json['TOTAL_REGULAR_PRICE'],
    totalInstallmentPrice: json["TOTAL_INSTALLMENT_PRICE"] is int
      ? (json['TOTAL_INSTALLMENT_PRICE'] as int).toDouble()
      : json['TOTAL_INSTALLMENT_PRICE'],
    totalInstallmentBundlePrice: json["TOTAL_INSTALLMENT_BUNDLE_PRICE"] is int
      ? (json['TOTAL_INSTALLMENT_BUNDLE_PRICE'] as int).toDouble()
      : json['TOTAL_INSTALLMENT_BUNDLE_PRICE'],
    matchedQty: json["MATCHED_QTY"],
    bundleQty: json["BUNDLE_QTY"],
    bundleNamePublic: json["BUNDLE_NAME_PUBLIC"],
    bundleName: json["BUNDLE_NAME"],
    pSs: json["P_SS"] is int
      ? (json['P_SS'] as int).toDouble()
      : json['P_SS'],
    pSm: json["P_SM"] is int
      ? (json['P_SM'] as int).toDouble()
      : json['P_SM'],
    pAir: json["P_AIR"] is int
      ? (json['P_AIR'] as int).toDouble()
      : json['P_AIR'],
    pSea: json["P_SEA"] is int
      ? (json['P_SEA'] as int).toDouble()
      : json['P_SEA'],
    rSs: json["R_SS"] is int
      ? (json['R_SS'] as int).toDouble()
      : json['R_SS'],
    rSm: json["R_SM"] is int
      ? (json['R_SM'] as int).toDouble()
      : json['R_SM'],
    rAir: json["R_AIR"] is int
      ? (json['R_AIR'] as int).toDouble()
      : json['R_AIR'],
    rSea: json["R_SEA"] is int
      ? (json['R_SEA'] as int).toDouble()
      : json['R_SEA'],
    imagePath: json["IMAGE_PATH"],
    bundleInvs: json["BUNDLE_INVS"],
    bundleBreakdown: List<BundleBreakdown>.from(json["bundle_breakdown"].map((x) => BundleBreakdown.fromJson(x))),
    defaultAmount: json["DEFAULT_AMOUNT"] is int
      ? (json['DEFAULT_AMOUNT'] as int).toDouble()
      : json['DEFAULT_AMOUNT'],
    savedAmount: json["SAVED_AMOUNT"] is int
      ? (json['SAVED_AMOUNT'] as int).toDouble()
      : json['SAVED_AMOUNT'],
    unitPrice: json["UNIT_PRICE"] is int
      ? (json['UNIT_PRICE'] as int).toDouble()
      : json['UNIT_PRICE'],
    currentIsRegular: json["CURRENT_IS_REGULAR"],
    currentIsSm: json["CURRENT_IS_SM"],
    returnedItems: List<dynamic>.from(json["returned_items"].map((x) => x)),
    deletedItems: List<dynamic>.from(json["deleted_items"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "F_BOOKING_NO": fBookingNo,
    "F_INV_STOCK_NO": fInvStockNo,
    "F_BUNDLE_NO": fBundleNo,
    "F_VARIANT_NO": fVariantNo,
    "TOTAL_REGULAR_BUNDLE_PRICE": totalRegularBundlePrice,
    "TOTAL_REGULAR_PRICE": totalRegularPrice,
    "TOTAL_INSTALLMENT_PRICE": totalInstallmentPrice,
    "TOTAL_INSTALLMENT_BUNDLE_PRICE": totalInstallmentBundlePrice,
    "MATCHED_QTY": matchedQty,
    "BUNDLE_QTY": bundleQty,
    "BUNDLE_NAME_PUBLIC": bundleNamePublic,
    "BUNDLE_NAME": bundleName,
    "P_SS": pSs,
    "P_SM": pSm,
    "P_AIR": pAir,
    "P_SEA": pSea,
    "R_SS": rSs,
    "R_SM": rSm,
    "R_AIR": rAir,
    "R_SEA": rSea,
    "IMAGE_PATH": imagePath,
    "BUNDLE_INVS": bundleInvs,
    "bundle_breakdown": List<dynamic>.from(bundleBreakdown!.map((x) => x.toJson())),
    "DEFAULT_AMOUNT": defaultAmount,
    "SAVED_AMOUNT": savedAmount,
    "UNIT_PRICE": unitPrice,
    "CURRENT_IS_REGULAR": currentIsRegular,
    "CURRENT_IS_SM": currentIsSm,
    "returned_items": List<dynamic>.from(returnedItems!.map((x) => x)),
    "deleted_items": List<dynamic>.from(deletedItems!.map((x) => x)),
  };
}

class BundleBreakdown {
  BundleBreakdown({
    this.variantCount,
    this.singleInvPks,
    this.currentAirFreight,
    this.currentSeaFreight,
    this.currentSsCost,
    this.currentSmCost,
    this.currentRegularPrice,
    this.prdVariantImagePath,
    this.prdVarinatName,
    this.fPrdVariantNo,
    this.fShippmentNo,
    this.shipmentType,
    this.fInvWarehouseNo,
    this.currentIsRegular,
    this.currentIsSm,
    this.igCode,
    this.shipmentStatus,
    this.schArrivalDate,
    this.invWarehouseName,
    this.regularPrice,
    this.installmentPrice,
    this.refundPks,
    this.shippedQty,
    this.refundQty,
    this.deleteQty,
    this.totalQty,
    this.unitDefaultPrice,
  });

  int? variantCount;
  String? singleInvPks;
  double? currentAirFreight;
  double? currentSeaFreight;
  double? currentSsCost;
  double? currentSmCost;
  double? currentRegularPrice;
  String? prdVariantImagePath;
  String? prdVarinatName;
  int? fPrdVariantNo;
  dynamic fShippmentNo;
  dynamic shipmentType;
  int? fInvWarehouseNo;
  int? currentIsRegular;
  int? currentIsSm;
  String? igCode;
  dynamic shipmentStatus;
  String? schArrivalDate;
  String? invWarehouseName;
  double? regularPrice;
  double? installmentPrice;
  dynamic refundPks;
  int? shippedQty;
  int? refundQty;
  int? deleteQty;
  int? totalQty;
  double? unitDefaultPrice;

  factory BundleBreakdown.fromJson(Map<String, dynamic> json) => BundleBreakdown(
    variantCount: json["VARIANT_COUNT"],
    singleInvPks: json["SINGLE_INV_PKS"],
    currentAirFreight: json["CURRENT_AIR_FREIGHT"] is int
      ? (json['CURRENT_AIR_FREIGHT'] as int).toDouble()
      : json['CURRENT_AIR_FREIGHT'],
    currentSeaFreight: json["CURRENT_SEA_FREIGHT"] is int
      ? (json['CURRENT_SEA_FREIGHT'] as int).toDouble()
      : json['CURRENT_SEA_FREIGHT'],
    currentSsCost: json["CURRENT_SS_COST"] is int
      ? (json['CURRENT_SS_COST'] as int).toDouble()
      : json["CURRENT_SS_COST"] is String ? double.parse(json['CURRENT_SS_COST'] as String) : json['CURRENT_SS_COST'],
    currentSmCost: json["CURRENT_SM_COST"] is int
      ? (json['CURRENT_SM_COST'] as int).toDouble()
      : json["CURRENT_SM_COST"] is String ? double.parse(json['CURRENT_SM_COST'] as String) : json['CURRENT_SM_COST'],
    currentRegularPrice: json["CURRENT_REGULAR_PRICE"] is int
      ? (json['CURRENT_REGULAR_PRICE'] as int).toDouble()
      : json['CURRENT_REGULAR_PRICE'],
    prdVariantImagePath: json["PRD_VARIANT_IMAGE_PATH"],
    prdVarinatName: json["PRD_VARINAT_NAME"],
    fPrdVariantNo: json["F_PRD_VARIANT_NO"],
    fShippmentNo: json["F_SHIPPMENT_NO"],
    shipmentType: json["SHIPMENT_TYPE"],
    fInvWarehouseNo: json["F_INV_WAREHOUSE_NO"],
    currentIsRegular: json["CURRENT_IS_REGULAR"],
    currentIsSm: json["CURRENT_IS_SM"],
    igCode: json["IG_CODE"],
    shipmentStatus: json["SHIPMENT_STATUS"],
    schArrivalDate: json["SCH_ARRIVAL_DATE"],
    invWarehouseName: json["INV_WAREHOUSE_NAME"],
    regularPrice: json["REGULAR_PRICE"] is int
      ? (json['REGULAR_PRICE'] as int).toDouble()
      : json['REGULAR_PRICE'],
    installmentPrice: json["INSTALLMENT_PRICE"] is int
      ? (json['INSTALLMENT_PRICE'] as int).toDouble()
      : json['INSTALLMENT_PRICE'],
    refundPks: json["REFUND_PKS"],
    shippedQty: json["SHIPPED_QTY"],
    refundQty: json["REFUND_QTY"],
    deleteQty: json["DELETE_QTY"],
    totalQty: json["TOTAL_QTY"],
    unitDefaultPrice: json["UNIT_DEFAULT_PRICE"] is int
      ? (json['UNIT_DEFAULT_PRICE'] as int).toDouble()
      : json['UNIT_DEFAULT_PRICE'],
  );

  Map<String, dynamic> toJson() => {
    "VARIANT_COUNT": variantCount,
    "SINGLE_INV_PKS": singleInvPks,
    "CURRENT_AIR_FREIGHT": currentAirFreight,
    "CURRENT_SEA_FREIGHT": currentSeaFreight,
    "CURRENT_SS_COST": currentSsCost,
    "CURRENT_SM_COST": currentSmCost,
    "CURRENT_REGULAR_PRICE": currentRegularPrice,
    "PRD_VARIANT_IMAGE_PATH": prdVariantImagePath,
    "PRD_VARINAT_NAME": prdVarinatName,
    "F_PRD_VARIANT_NO": fPrdVariantNo,
    "F_SHIPPMENT_NO": fShippmentNo,
    "SHIPMENT_TYPE": shipmentType,
    "F_INV_WAREHOUSE_NO": fInvWarehouseNo,
    "CURRENT_IS_REGULAR": currentIsRegular,
    "CURRENT_IS_SM": currentIsSm,
    "IG_CODE": igCode,
    "SHIPMENT_STATUS": shipmentStatus,
    "SCH_ARRIVAL_DATE": schArrivalDate,
    "INV_WAREHOUSE_NAME": invWarehouseName,
    "REGULAR_PRICE": regularPrice,
    "INSTALLMENT_PRICE": installmentPrice,
    "REFUND_PKS": refundPks,
    "SHIPPED_QTY": shippedQty,
    "REFUND_QTY": refundQty,
    "DELETE_QTY": deleteQty,
    "TOTAL_QTY": totalQty,
    "UNIT_DEFAULT_PRICE": unitDefaultPrice,
  };
}

class Dispatched {
  Dispatched({
    this.fVariantNo,
    this.prdVariantImagePath,
    this.igCode,
    this.prdVarinatName,
    this.pkNo,
    this.fBookingNo,
    this.fInvStockNo,
    this.comments,
    this.isActive,
    this.addColNumber1,
    this.addColNumber2,
    this.addColVarchar1,
    this.addColVarchar2,
    this.fSsCreatedBy,
    this.ssCreatedOn,
    this.ssModifiedOn,
    this.fDeliveryAddress,
    this.fSsCompanyNo,
    this.isSystemHold,
    this.isAdminHold,
    this.dispatchStatus,
    this.airFreight,
    this.seaFreight,
    this.isFreight,
    this.ssCost,
    this.smCost,
    this.isSm,
    this.regularPrice,
    this.installmentPrice,
    this.isRegular,
    this.currentAirFreight,
    this.currentSeaFreight,
    this.currentIsFreight,
    this.currentSsCost,
    this.currentSmCost,
    this.currentIsSm,
    this.currentRegularPrice,
    this.currentInstallmentPrice,
    this.currentIsRegular,
    this.currentFDeliveryAddress,
    this.orderStatus,
    this.isSelfPickup,
    this.isAdminApproval,
    this.isReady,
    this.arrivalNotificationFlag,
    this.dispatchNotificationFlag,
    this.isCodShelveTransfer,
    this.comission,
    this.rtsCollectionUserId,
    this.isCollectedForRts,
    this.fBundleNo,
    this.bundleSequenc,
    this.codRtcAck,
    this.linePrice,
    this.courierTrackingNo,
    this.qty,
    this.courierName,
  });

  int? fVariantNo;
  String? prdVariantImagePath;
  String? igCode;
  String? prdVarinatName;
  int? pkNo;
  int? fBookingNo;
  int? fInvStockNo;
  dynamic comments;
  int? isActive;
  dynamic addColNumber1;
  dynamic addColNumber2;
  dynamic addColVarchar1;
  dynamic addColVarchar2;
  String? fSsCreatedBy;
  String? ssCreatedOn;
  String? ssModifiedOn;
  int? fDeliveryAddress;
  dynamic fSsCompanyNo;
  int? isSystemHold;
  int? isAdminHold;
  int? dispatchStatus;
  double? airFreight;
  double? seaFreight;
  int? isFreight;
  double? ssCost;
  double? smCost;
  int? isSm;
  double? regularPrice;
  double? installmentPrice;
  int? isRegular;
  double? currentAirFreight;
  double? currentSeaFreight;
  int? currentIsFreight;
  double? currentSsCost;
  double? currentSmCost;
  int? currentIsSm;
  double? currentRegularPrice;
  double? currentInstallmentPrice;
  int? currentIsRegular;
  int? currentFDeliveryAddress;
  int? orderStatus;
  int? isSelfPickup;
  int? isAdminApproval;
  int? isReady;
  int? arrivalNotificationFlag;
  int? dispatchNotificationFlag;
  int? isCodShelveTransfer;
  double? comission;
  int? rtsCollectionUserId;
  int? isCollectedForRts;
  int? fBundleNo;
  int? bundleSequenc;
  int? codRtcAck;
  double? linePrice;
  String? courierTrackingNo;
  int? qty;
  String? courierName;

  factory Dispatched.fromJson(Map<String, dynamic> json) => Dispatched(
    fVariantNo: json["f_variant_no"],
    prdVariantImagePath: json["PRD_VARIANT_IMAGE_PATH"],
    igCode: json["IG_CODE"],
    prdVarinatName: json["PRD_VARINAT_NAME"],
    pkNo: json["PK_NO"],
    fBookingNo: json["F_BOOKING_NO"],
    fInvStockNo: json["F_INV_STOCK_NO"],
    comments: json["COMMENTS"],
    isActive: json["IS_ACTIVE"],
    addColNumber1: json["ADD_COL_NUMBER_1"],
    addColNumber2: json["ADD_COL_NUMBER_2"],
    addColVarchar1: json["ADD_COL_VARCHAR_1"],
    addColVarchar2: json["ADD_COL_VARCHAR_2"],
    fSsCreatedBy: json["F_SS_CREATED_BY"],
    ssCreatedOn: json["SS_CREATED_ON"],
    ssModifiedOn: json["SS_MODIFIED_ON"],
    fDeliveryAddress: json["F_DELIVERY_ADDRESS"],
    fSsCompanyNo: json["F_SS_COMPANY_NO"],
    isSystemHold: json["IS_SYSTEM_HOLD"],
    isAdminHold: json["IS_ADMIN_HOLD"],
    dispatchStatus: json["DISPATCH_STATUS"],
    airFreight: json["AIR_FREIGHT"] is int
      ? (json['AIR_FREIGHT'] as int).toDouble()
      : json['AIR_FREIGHT'],
    seaFreight: json["SEA_FREIGHT"] is int
      ? (json['SEA_FREIGHT'] as int).toDouble()
      : json['SEA_FREIGHT'],
    isFreight: json["IS_FREIGHT"],
    ssCost: json["SS_COST"] is int
      ? (json['SS_COST'] as int).toDouble()
      : json['SS_COST'],
    smCost: json["SM_COST"] is int
      ? (json['SM_COST'] as int).toDouble()
      : json['SM_COST'],
    isSm: json["IS_SM"],
    regularPrice: json["REGULAR_PRICE"] is int
      ? (json['REGULAR_PRICE'] as int).toDouble()
      : json['REGULAR_PRICE'],
    installmentPrice: json["INSTALLMENT_PRICE"] is int
      ? (json['INSTALLMENT_PRICE'] as int).toDouble()
      : json['INSTALLMENT_PRICE'],
    isRegular: json["IS_REGULAR"],
    currentAirFreight: json["CURRENT_AIR_FREIGHT"] is int
      ? (json['CURRENT_AIR_FREIGHT'] as int).toDouble()
      : json['CURRENT_AIR_FREIGHT'],
    currentSeaFreight: json["CURRENT_SEA_FREIGHT"] is int
      ? (json['CURRENT_SEA_FREIGHT'] as int).toDouble()
      : json['CURRENT_SEA_FREIGHT'],
    currentIsFreight: json["CURRENT_IS_FREIGHT"],
    currentSsCost: json["CURRENT_SS_COST"] is int
        ? (json['CURRENT_SS_COST'] as int).toDouble()
        : json["CURRENT_SS_COST"] is String ? double.parse(json['CURRENT_SS_COST'] as String) : json['CURRENT_SS_COST'],
    currentSmCost: json["CURRENT_SM_COST"] is int
        ? (json['CURRENT_SM_COST'] as int).toDouble()
        : json["CURRENT_SM_COST"] is String ? double.parse(json['CURRENT_SM_COST'] as String) : json['CURRENT_SM_COST'],
    currentIsSm: json["CURRENT_IS_SM"],
    currentRegularPrice: json["CURRENT_SM_COST"] is int
      ? (json['CURRENT_SM_COST'] as int).toDouble()
      : json['CURRENT_SM_COST'],
    currentInstallmentPrice: json["CURRENT_INSTALLMENT_PRICE"] is int
      ? (json['CURRENT_INSTALLMENT_PRICE'] as int).toDouble()
      : json['CURRENT_INSTALLMENT_PRICE'],
    currentIsRegular: json["CURRENT_IS_REGULAR"],
    currentFDeliveryAddress: json["CURRENT_F_DELIVERY_ADDRESS"],
    orderStatus: json["ORDER_STATUS"],
    isSelfPickup: json["IS_SELF_PICKUP"],
    isAdminApproval: json["IS_ADMIN_APPROVAL"],
    isReady: json["IS_READY"],
    arrivalNotificationFlag: json["ARRIVAL_NOTIFICATION_FLAG"],
    dispatchNotificationFlag: json["DISPATCH_NOTIFICATION_FLAG"],
    isCodShelveTransfer: json["IS_COD_SHELVE_TRANSFER"],
    comission: json["COMISSION"] is int
      ? (json['COMISSION'] as int).toDouble()
      : json['COMISSION'],
    rtsCollectionUserId: json["RTS_COLLECTION_USER_ID"],
    isCollectedForRts: json["IS_COLLECTED_FOR_RTS"],
    fBundleNo: json["F_BUNDLE_NO"],
    bundleSequenc: json["BUNDLE_SEQUENC"],
    codRtcAck: json["COD_RTC_ACK"],
    linePrice: json["LINE_PRICE"] is int
      ? (json['LINE_PRICE'] as int).toDouble()
      : json['LINE_PRICE'],
    courierTrackingNo: json["COURIER_TRACKING_NO"],
    qty: json["qty"],
    courierName: json["COURIER_NAME"],
  );

  Map<String, dynamic> toJson() => {
    "f_variant_no": fVariantNo,
    "PRD_VARIANT_IMAGE_PATH": prdVariantImagePath,
    "IG_CODE": igCode,
    "PRD_VARINAT_NAME": prdVarinatName,
    "PK_NO": pkNo,
    "F_BOOKING_NO": fBookingNo,
    "F_INV_STOCK_NO": fInvStockNo,
    "COMMENTS": comments,
    "IS_ACTIVE": isActive,
    "ADD_COL_NUMBER_1": addColNumber1,
    "ADD_COL_NUMBER_2": addColNumber2,
    "ADD_COL_VARCHAR_1": addColVarchar1,
    "ADD_COL_VARCHAR_2": addColVarchar2,
    "F_SS_CREATED_BY": fSsCreatedBy,
    "SS_CREATED_ON": ssCreatedOn,
    "SS_MODIFIED_ON": ssModifiedOn,
    "F_DELIVERY_ADDRESS": fDeliveryAddress,
    "F_SS_COMPANY_NO": fSsCompanyNo,
    "IS_SYSTEM_HOLD": isSystemHold,
    "IS_ADMIN_HOLD": isAdminHold,
    "DISPATCH_STATUS": dispatchStatus,
    "AIR_FREIGHT": airFreight,
    "SEA_FREIGHT": seaFreight,
    "IS_FREIGHT": isFreight,
    "SS_COST": ssCost,
    "SM_COST": smCost,
    "IS_SM": isSm,
    "REGULAR_PRICE": regularPrice,
    "INSTALLMENT_PRICE": installmentPrice,
    "IS_REGULAR": isRegular,
    "CURRENT_AIR_FREIGHT": currentAirFreight,
    "CURRENT_SEA_FREIGHT": currentSeaFreight,
    "CURRENT_IS_FREIGHT": currentIsFreight,
    "CURRENT_SS_COST": currentSsCost,
    "CURRENT_SM_COST": currentSmCost,
    "CURRENT_IS_SM": currentIsSm,
    "CURRENT_REGULAR_PRICE": currentRegularPrice,
    "CURRENT_INSTALLMENT_PRICE": currentInstallmentPrice,
    "CURRENT_IS_REGULAR": currentIsRegular,
    "CURRENT_F_DELIVERY_ADDRESS": currentFDeliveryAddress,
    "ORDER_STATUS": orderStatus,
    "IS_SELF_PICKUP": isSelfPickup,
    "IS_ADMIN_APPROVAL": isAdminApproval,
    "IS_READY": isReady,
    "ARRIVAL_NOTIFICATION_FLAG": arrivalNotificationFlag,
    "DISPATCH_NOTIFICATION_FLAG": dispatchNotificationFlag,
    "IS_COD_SHELVE_TRANSFER": isCodShelveTransfer,
    "COMISSION": comission,
    "RTS_COLLECTION_USER_ID": rtsCollectionUserId,
    "IS_COLLECTED_FOR_RTS": isCollectedForRts,
    "F_BUNDLE_NO": fBundleNo,
    "BUNDLE_SEQUENC": bundleSequenc,
    "COD_RTC_ACK": codRtcAck,
    "LINE_PRICE": linePrice,
    "COURIER_TRACKING_NO": courierTrackingNo,
    "qty": qty,
    "COURIER_NAME": courierName,
  };
}

class NonBundle {
  NonBundle({
    this.fBookingNo,
    this.fInvStockNo,
    this.currentRegularPrice,
    this.currentInstallmentPrice,
    this.airFreight,
    this.seaFreight,
    this.isFreight,
    this.ssCost,
    this.smCost,
    this.isSm,
    this.isRegular,
    this.prdVarinatName,
    this.variantCount,
    this.singleInvPks,
    this.prdVariantImagePath,
    this.fVariantNo,
    this.fInvWarehouseNo,
    this.shipmentType,
    this.invWarehouseName,
    this.shipmentStatus,
    this.schArrivalDate,
    this.currentIsRegular,
    this.currentIsSm,
    this.currentSsCost,
    this.currentSmCost,
    this.igCode,
    this.regularPrice,
    this.installmentPrice,
    this.refundPks,
    this.shippedQty,
    this.refundQty,
    this.deleteQty,
    this.totalQty,
    this.unitPrice,
    this.unitDefaultPrice,
    this.lineTotal,
  });

  int? fBookingNo;
  int? fInvStockNo;
  double? currentRegularPrice;
  double? currentInstallmentPrice;
  double? airFreight;
  double? seaFreight;
  int? isFreight;
  double? ssCost;
  double? smCost;
  int? isSm;
  int? isRegular;
  String? prdVarinatName;
  int? variantCount;
  String? singleInvPks;
  String? prdVariantImagePath;
  int? fVariantNo;
  int? fInvWarehouseNo;
  dynamic shipmentType;
  String? invWarehouseName;
  dynamic shipmentStatus;
  String? schArrivalDate;
  int? currentIsRegular;
  int? currentIsSm;
  double? currentSsCost;
  double? currentSmCost;
  String? igCode;
  double? regularPrice;
  double? installmentPrice;
  dynamic refundPks;
  int? shippedQty;
  int? refundQty;
  int? deleteQty;
  int? totalQty;
  double? unitPrice;
  double? unitDefaultPrice;
  int? lineTotal;

  factory NonBundle.fromJson(Map<String, dynamic> json) => NonBundle(
    fBookingNo: json["F_BOOKING_NO"],
    fInvStockNo: json["F_INV_STOCK_NO"],
    currentRegularPrice: json["CURRENT_REGULAR_PRICE"] is int
      ? (json['CURRENT_REGULAR_PRICE'] as int).toDouble()
      : json['CURRENT_REGULAR_PRICE'],
    currentInstallmentPrice: json["CURRENT_INSTALLMENT_PRICE"] is int
      ? (json['CURRENT_INSTALLMENT_PRICE'] as int).toDouble()
      : json['CURRENT_INSTALLMENT_PRICE'],
    airFreight: json["AIR_FREIGHT"] is int
      ? (json['AIR_FREIGHT'] as int).toDouble()
      : json['AIR_FREIGHT'],
    seaFreight: json["SEA_FREIGHT"] is int
      ? (json['SEA_FREIGHT'] as int).toDouble()
      : json['SEA_FREIGHT'],
    isFreight: json["IS_FREIGHT"],
    ssCost: json["SS_COST"] is int
      ? (json['SS_COST'] as int).toDouble()
      : json['SS_COST'],
    smCost: json["SM_COST"] is int
      ? (json['SM_COST'] as int).toDouble()
      : json['SM_COST'],
    isSm: json["IS_SM"],
    isRegular: json["IS_REGULAR"],
    prdVarinatName: json["PRD_VARINAT_NAME"],
    variantCount: json["VARIANT_COUNT"],
    singleInvPks: json["SINGLE_INV_PKS"],
    prdVariantImagePath: json["PRD_VARIANT_IMAGE_PATH"],
    fVariantNo: json["f_variant_no"],
    fInvWarehouseNo: json["F_INV_WAREHOUSE_NO"],
    shipmentType: json["SHIPMENT_TYPE"],
    invWarehouseName: json["INV_WAREHOUSE_NAME"],
    shipmentStatus: json["SHIPMENT_STATUS"],
    schArrivalDate: json["SCH_ARRIVAL_DATE"],
    currentIsRegular: json["CURRENT_IS_REGULAR"],
    currentIsSm: json["CURRENT_IS_SM"],
    currentSsCost: json["CURRENT_SS_COST"] is int
        ? (json['CURRENT_SS_COST'] as int).toDouble()
        : json["CURRENT_SS_COST"] is String ? double.parse(json['CURRENT_SS_COST'] as String) : json['CURRENT_SS_COST'],
    currentSmCost: json["CURRENT_SM_COST"] is int
        ? (json['CURRENT_SM_COST'] as int).toDouble()
        : json["CURRENT_SM_COST"] is String ? double.parse(json['CURRENT_SM_COST'] as String) : json['CURRENT_SM_COST'],
    igCode: json["IG_CODE"],
    regularPrice: json["REGULAR_PRICE"] is int
      ? (json['REGULAR_PRICE'] as int).toDouble()
      : json['REGULAR_PRICE'],
    installmentPrice: json["INSTALLMENT_PRICE"] is int
      ? (json['INSTALLMENT_PRICE'] as int).toDouble()
      : json['INSTALLMENT_PRICE'],
    refundPks: json["REFUND_PKS"],
    shippedQty: json["SHIPPED_QTY"],
    refundQty: json["REFUND_QTY"],
    deleteQty: json["DELETE_QTY"],
    totalQty: json["TOTAL_QTY"],
    unitPrice: json["UNIT_PRICE"] is int
      ? (json['UNIT_PRICE'] as int).toDouble()
      : json['UNIT_PRICE'],
    unitDefaultPrice: json["UNIT_DEFAULT_PRICE"] is int
      ? (json['UNIT_DEFAULT_PRICE'] as int).toDouble()
      : json['UNIT_DEFAULT_PRICE'],
    lineTotal: json["LINE_TOTAL"],
  );

  Map<String, dynamic> toJson() => {
    "F_BOOKING_NO": fBookingNo,
    "F_INV_STOCK_NO": fInvStockNo,
    "CURRENT_REGULAR_PRICE": currentRegularPrice,
    "CURRENT_INSTALLMENT_PRICE": currentInstallmentPrice,
    "AIR_FREIGHT": airFreight,
    "SEA_FREIGHT": seaFreight,
    "IS_FREIGHT": isFreight,
    "SS_COST": ssCost,
    "SM_COST": smCost,
    "IS_SM": isSm,
    "IS_REGULAR": isRegular,
    "PRD_VARINAT_NAME": prdVarinatName,
    "VARIANT_COUNT": variantCount,
    "SINGLE_INV_PKS": singleInvPks,
    "PRD_VARIANT_IMAGE_PATH": prdVariantImagePath,
    "f_variant_no": fVariantNo,
    "F_INV_WAREHOUSE_NO": fInvWarehouseNo,
    "SHIPMENT_TYPE": shipmentType,
    "INV_WAREHOUSE_NAME": invWarehouseName,
    "SHIPMENT_STATUS": shipmentStatus,
    "SCH_ARRIVAL_DATE": schArrivalDate,
    "CURRENT_IS_REGULAR": currentIsRegular,
    "CURRENT_IS_SM": currentIsSm,
    "CURRENT_SS_COST": currentSsCost,
    "CURRENT_SM_COST": currentSmCost,
    "IG_CODE": igCode,
    "REGULAR_PRICE": regularPrice,
    "INSTALLMENT_PRICE": installmentPrice,
    "REFUND_PKS": refundPks,
    "SHIPPED_QTY": shippedQty,
    "REFUND_QTY": refundQty,
    "DELETE_QTY": deleteQty,
    "TOTAL_QTY": totalQty,
    "UNIT_PRICE": unitPrice,
    "UNIT_DEFAULT_PRICE": unitDefaultPrice,
    "LINE_TOTAL": lineTotal,
  };
}

class Order {
  Order({
    this.pkNo,
    this.code,
    this.fBookingNo,
    this.fCustomerNo,
    this.customerName,
    this.isReseller,
    this.fResellerNo,
    this.resellerName,
    this.dispatchStatus,
    this.fFromAddress,
    this.fToAddress,
    this.fBillingAddress,
    this.fOrderTypeNo,
    this.orderTypeName,
    this.orderActualTopup,
    this.orderBufferTopup,
    this.orderBalanceUsed,
    this.orderBalanceReturn,
    this.isAdminHold,
    this.isSystemHold,
    this.isCancel,
    this.isDefault,
    this.isSelfPickup,
    this.isAdminApproval,
    this.fromName,
    this.fromMobile,
    this.fromAddressLine1,
    this.fromAddressLine2,
    this.fromAddressLine3,
    this.fromAddressLine4,
    this.fromCity,
    this.fromPostcode,
    this.fromState,
    this.fromCountry,
    this.fromFCountryNo,
    this.deliveryName,
    this.deliveryLastName,
    this.deliveryMobile,
    this.deliveryAddressLine1,
    this.deliveryAddressLine2,
    this.deliveryAddressLine3,
    this.deliveryAddressLine4,
    this.deliveryCity,
    this.deliveryPostcode,
    this.deliveryState,
    this.deliveryCountry,
    this.deliveryFCountryNo,
    this.deliveryEmail,
    this.isReady,
    this.comTest,
    this.pickupId,
    this.updatedBy,
    this.prevDeliveryName,
    this.prevDeliveryMobile,
    this.prevDeliveryAddressLine1,
    this.prevDeliveryAddressLine2,
    this.prevDeliveryAddressLine3,
    this.prevDeliveryAddressLine4,
    this.prevDeliveryCity,
    this.prevDeliveryPostcode,
    this.prevDeliveryState,
    this.prevDeliveryCountry,
    this.prevDeliveryFCountryNo,
    this.defaultAt,
    this.defaultType,
    this.graceTime,
    this.orderGroupId,
    this.adminPaid,
  });

  int? pkNo;
  dynamic code;
  int? fBookingNo;
  int? fCustomerNo;
  String? customerName;
  int? isReseller;
  dynamic fResellerNo;
  dynamic resellerName;
  int? dispatchStatus;
  int? fFromAddress;
  int? fToAddress;
  dynamic fBillingAddress;
  dynamic fOrderTypeNo;
  String? orderTypeName;
  int? orderActualTopup;
  int? orderBufferTopup;
  int? orderBalanceUsed;
  int? orderBalanceReturn;
  int? isAdminHold;
  int? isSystemHold;
  int? isCancel;
  int? isDefault;
  int? isSelfPickup;
  int? isAdminApproval;
  String? fromName;
  String? fromMobile;
  String? fromAddressLine1;
  String? fromAddressLine2;
  String? fromAddressLine3;
  String? fromAddressLine4;
  String? fromCity;
  String? fromPostcode;
  String? fromState;
  String? fromCountry;
  int? fromFCountryNo;
  String? deliveryName;
  String? deliveryLastName;
  String? deliveryMobile;
  String? deliveryAddressLine1;
  String? deliveryAddressLine2;
  dynamic deliveryAddressLine3;
  dynamic deliveryAddressLine4;
  String? deliveryCity;
  String? deliveryPostcode;
  String? deliveryState;
  String? deliveryCountry;
  int? deliveryFCountryNo;
  String? deliveryEmail;
  int? isReady;
  dynamic comTest;
  int? pickupId;
  int? updatedBy;
  String? prevDeliveryName;
  String? prevDeliveryMobile;
  String? prevDeliveryAddressLine1;
  String? prevDeliveryAddressLine2;
  dynamic prevDeliveryAddressLine3;
  dynamic prevDeliveryAddressLine4;
  String? prevDeliveryCity;
  String? prevDeliveryPostcode;
  String? prevDeliveryState;
  String? prevDeliveryCountry;
  int? prevDeliveryFCountryNo;
  dynamic defaultAt;
  int? defaultType;
  String? graceTime;
  int? orderGroupId;
  int? adminPaid;

  factory Order.fromJson(Map<String, dynamic> json) => Order(
    pkNo: json["PK_NO"],
    code: json["CODE"],
    fBookingNo: json["F_BOOKING_NO"],
    fCustomerNo: json["F_CUSTOMER_NO"],
    customerName: json["CUSTOMER_NAME"],
    isReseller: json["IS_RESELLER"],
    fResellerNo: json["F_RESELLER_NO"],
    resellerName: json["RESELLER_NAME"],
    dispatchStatus: json["DISPATCH_STATUS"],
    fFromAddress: json["F_FROM_ADDRESS"],
    fToAddress: json["F_TO_ADDRESS"],
    fBillingAddress: json["F_BILLING_ADDRESS"],
    fOrderTypeNo: json["F_ORDER_TYPE_NO"],
    orderTypeName: json["ORDER_TYPE_NAME"],
    orderActualTopup: json["ORDER_ACTUAL_TOPUP"],
    orderBufferTopup: json["ORDER_BUFFER_TOPUP"],
    orderBalanceUsed: json["ORDER_BALANCE_USED"],
    orderBalanceReturn: json["ORDER_BALANCE_RETURN"],
    isAdminHold: json["IS_ADMIN_HOLD"],
    isSystemHold: json["IS_SYSTEM_HOLD"],
    isCancel: json["IS_CANCEL"],
    isDefault: json["IS_DEFAULT"],
    isSelfPickup: json["IS_SELF_PICKUP"],
    isAdminApproval: json["IS_ADMIN_APPROVAL"],
    fromName: json["FROM_NAME"],
    fromMobile: json["FROM_MOBILE"],
    fromAddressLine1: json["FROM_ADDRESS_LINE_1"],
    fromAddressLine2: json["FROM_ADDRESS_LINE_2"],
    fromAddressLine3: json["FROM_ADDRESS_LINE_3"],
    fromAddressLine4: json["FROM_ADDRESS_LINE_4"],
    fromCity: json["FROM_CITY"],
    fromPostcode: json["FROM_POSTCODE"],
    fromState: json["FROM_STATE"],
    fromCountry: json["FROM_COUNTRY"],
    fromFCountryNo: json["FROM_F_COUNTRY_NO"],
    deliveryName: json["DELIVERY_NAME"],
    deliveryLastName: json["DELIVERY_LAST_NAME"],
    deliveryMobile: json["DELIVERY_MOBILE"],
    deliveryAddressLine1: json["DELIVERY_ADDRESS_LINE_1"],
    deliveryAddressLine2: json["DELIVERY_ADDRESS_LINE_2"],
    deliveryAddressLine3: json["DELIVERY_ADDRESS_LINE_3"],
    deliveryAddressLine4: json["DELIVERY_ADDRESS_LINE_4"],
    deliveryCity: json["DELIVERY_CITY"],
    deliveryPostcode: json["DELIVERY_POSTCODE"],
    deliveryState: json["DELIVERY_STATE"],
    deliveryCountry: json["DELIVERY_COUNTRY"],
    deliveryFCountryNo: json["DELIVERY_F_COUNTRY_NO"],
    deliveryEmail: json["DELIVERY_EMAIL"],
    isReady: json["IS_READY"],
    comTest: json["COM_TEST"],
    pickupId: json["PICKUP_ID"],
    updatedBy: json["UPDATED_BY"],
    prevDeliveryName: json["PREV_DELIVERY_NAME"],
    prevDeliveryMobile: json["PREV_DELIVERY_MOBILE"],
    prevDeliveryAddressLine1: json["PREV_DELIVERY_ADDRESS_LINE_1"],
    prevDeliveryAddressLine2: json["PREV_DELIVERY_ADDRESS_LINE_2"],
    prevDeliveryAddressLine3: json["PREV_DELIVERY_ADDRESS_LINE_3"],
    prevDeliveryAddressLine4: json["PREV_DELIVERY_ADDRESS_LINE_4"],
    prevDeliveryCity: json["PREV_DELIVERY_CITY"],
    prevDeliveryPostcode: json["PREV_DELIVERY_POSTCODE"],
    prevDeliveryState: json["PREV_DELIVERY_STATE"],
    prevDeliveryCountry: json["PREV_DELIVERY_COUNTRY"],
    prevDeliveryFCountryNo: json["PREV_DELIVERY_F_COUNTRY_NO"],
    defaultAt: json["DEFAULT_AT"],
    defaultType: json["DEFAULT_TYPE"],
    graceTime: json["GRACE_TIME"],
    orderGroupId: json["ORDER_GROUP_ID"],
    adminPaid: json["ADMIN_PAID"],
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "CODE": code,
    "F_BOOKING_NO": fBookingNo,
    "F_CUSTOMER_NO": fCustomerNo,
    "CUSTOMER_NAME": customerName,
    "IS_RESELLER": isReseller,
    "F_RESELLER_NO": fResellerNo,
    "RESELLER_NAME": resellerName,
    "DISPATCH_STATUS": dispatchStatus,
    "F_FROM_ADDRESS": fFromAddress,
    "F_TO_ADDRESS": fToAddress,
    "F_BILLING_ADDRESS": fBillingAddress,
    "F_ORDER_TYPE_NO": fOrderTypeNo,
    "ORDER_TYPE_NAME": orderTypeName,
    "ORDER_ACTUAL_TOPUP": orderActualTopup,
    "ORDER_BUFFER_TOPUP": orderBufferTopup,
    "ORDER_BALANCE_USED": orderBalanceUsed,
    "ORDER_BALANCE_RETURN": orderBalanceReturn,
    "IS_ADMIN_HOLD": isAdminHold,
    "IS_SYSTEM_HOLD": isSystemHold,
    "IS_CANCEL": isCancel,
    "IS_DEFAULT": isDefault,
    "IS_SELF_PICKUP": isSelfPickup,
    "IS_ADMIN_APPROVAL": isAdminApproval,
    "FROM_NAME": fromName,
    "FROM_MOBILE": fromMobile,
    "FROM_ADDRESS_LINE_1": fromAddressLine1,
    "FROM_ADDRESS_LINE_2": fromAddressLine2,
    "FROM_ADDRESS_LINE_3": fromAddressLine3,
    "FROM_ADDRESS_LINE_4": fromAddressLine4,
    "FROM_CITY": fromCity,
    "FROM_POSTCODE": fromPostcode,
    "FROM_STATE": fromState,
    "FROM_COUNTRY": fromCountry,
    "FROM_F_COUNTRY_NO": fromFCountryNo,
    "DELIVERY_NAME": deliveryName,
    "DELIVERY_LAST_NAME": deliveryLastName,
    "DELIVERY_MOBILE": deliveryMobile,
    "DELIVERY_ADDRESS_LINE_1": deliveryAddressLine1,
    "DELIVERY_ADDRESS_LINE_2": deliveryAddressLine2,
    "DELIVERY_ADDRESS_LINE_3": deliveryAddressLine3,
    "DELIVERY_ADDRESS_LINE_4": deliveryAddressLine4,
    "DELIVERY_CITY": deliveryCity,
    "DELIVERY_POSTCODE": deliveryPostcode,
    "DELIVERY_STATE": deliveryState,
    "DELIVERY_COUNTRY": deliveryCountry,
    "DELIVERY_F_COUNTRY_NO": deliveryFCountryNo,
    "DELIVERY_EMAIL": deliveryEmail,
    "IS_READY": isReady,
    "COM_TEST": comTest,
    "PICKUP_ID": pickupId,
    "UPDATED_BY": updatedBy,
    "PREV_DELIVERY_NAME": prevDeliveryName,
    "PREV_DELIVERY_MOBILE": prevDeliveryMobile,
    "PREV_DELIVERY_ADDRESS_LINE_1": prevDeliveryAddressLine1,
    "PREV_DELIVERY_ADDRESS_LINE_2": prevDeliveryAddressLine2,
    "PREV_DELIVERY_ADDRESS_LINE_3": prevDeliveryAddressLine3,
    "PREV_DELIVERY_ADDRESS_LINE_4": prevDeliveryAddressLine4,
    "PREV_DELIVERY_CITY": prevDeliveryCity,
    "PREV_DELIVERY_POSTCODE": prevDeliveryPostcode,
    "PREV_DELIVERY_STATE": prevDeliveryState,
    "PREV_DELIVERY_COUNTRY": prevDeliveryCountry,
    "PREV_DELIVERY_F_COUNTRY_NO": prevDeliveryFCountryNo,
    "DEFAULT_AT": defaultAt,
    "DEFAULT_TYPE": defaultType,
    "GRACE_TIME": graceTime,
    "ORDER_GROUP_ID": orderGroupId,
    "ADMIN_PAID": adminPaid,
  };
}

class Payment {
  Payment({
    this.fAccCustomerPaymentNo,
    this.paymentAmount,
    this.pkNo,
    this.code,
    this.txnDate,
  });

  int? fAccCustomerPaymentNo;
  double? paymentAmount;
  int? pkNo;
  int? code;
  String? txnDate;

  factory Payment.fromJson(Map<String, dynamic> json) => Payment(
    fAccCustomerPaymentNo: json["F_ACC_CUSTOMER_PAYMENT_NO"],
    paymentAmount: json["PAYMENT_AMOUNT"] is int
      ? (json['PAYMENT_AMOUNT'] as int).toDouble()
      : json['PAYMENT_AMOUNT'],
    pkNo: json["PK_NO"],
    code: json["CODE"],
    txnDate: json["TXN_DATE"],
  );

  Map<String, dynamic> toJson() => {
    "F_ACC_CUSTOMER_PAYMENT_NO": fAccCustomerPaymentNo,
    "PAYMENT_AMOUNT": paymentAmount,
    "PK_NO": pkNo,
    "CODE": code,
    "TXN_DATE": txnDate,
  };
}

class BillingAddress {
  BillingAddress({this.pkNo,
      this.code,
      this.name,
      this.lastName,
      this.telNo,
      this.addressLine1,
      this.addressLine2,
      this.addressLine3,
      this.addressLine4,
      this.state,
      this.city,
      this.postCode,
      this.fCountryNo,
      this.country,
      this.location,
      this.fAddressTypeNo,
      this.isActive,
      this.fCustomerNo,
      this.fResellerNo,
      this.isDefault});
  int? pkNo;
  int? code;
  String? name;
  String? lastName;
  String? telNo;
  String? addressLine1;
  String? addressLine2;
  String? addressLine3;
  String? addressLine4;
  String? state;
  String? city;
  String? postCode;
  int? fCountryNo;
  String? country;
  String? location;
  int? fAddressTypeNo;
  int? isActive;
  int? fCustomerNo;
  int? fResellerNo;
  int? isDefault;

  factory BillingAddress.fromJson(Map<String, dynamic> json) => BillingAddress(
    pkNo: json["PK_NO"],
    code: json["CODE"],
    name: json["NAME"],
    lastName: json["LAST_NAME"],
    telNo: json["TEL_NO"],
    addressLine1: json["ADDRESS_LINE_1"],
    addressLine2: json["ADDRESS_LINE_2"],
    addressLine3: json["ADDRESS_LINE_3"],
    addressLine4: json["ADDRESS_LINE_4"],
    state: json["STATE"],
    city: json["CITY"],
    postCode: json["POST_CODE"],
    fCountryNo: json["F_COUNTRY_NO"],
    country: json["COUNTRY"],
    location: json["LOCATION"],
    fAddressTypeNo: json["F_ADDRESS_TYPE_NO"],
    isActive: json["IS_ACTIVE"],
    fCustomerNo: json["F_CUSTOMER_NO"],
    fResellerNo: json["F_RESELLER_NO"],
    isDefault: json["IS_DEFAULT"],
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "CODE": code,
    "NAME": name,
    "LAST_NAME": lastName,
    "TEL_NO": telNo,
    "ADDRESS_LINE_1": addressLine1,
    "ADDRESS_LINE_2": addressLine2,
    "ADDRESS_LINE_3": addressLine3,
    "ADDRESS_LINE_4": addressLine4,
    "STATE": state,
    "CITY": city,
    "POST_CODE": postCode,
    "F_COUNTRY_NO": fCountryNo,
    "COUNTRY": country,
    "LOCATION": location,
    "F_ADDRESS_TYPE_NO": fAddressTypeNo,
    "IS_ACTIVE": isActive,
    "F_CUSTOMER_NO": fCustomerNo,
    "F_RESELLER_NO": fResellerNo,
    "IS_DEFAULT": isDefault
  };

}

class ReturnedItem {
  ReturnedItem({
    this.fVariantNo,
    this.prdVariantImagePath,
    this.igCode,
    this.prdVariantName,
    this.id,
    this.pkNo,
    this.fBookingNo,
    this.fInvStockNo,
    this.comments,
    this.isActive,
    this.fSsCreatedBy,
    this.ssCreatedOn,
    this.ssModifiedOn,
    this.fDeliveryAddress,
    this.fSsCompanyNo,
    this.isSystemHold,
    this.isAdminHold,
    this.dispatchStatus,
    this.airFreight,
    this.seaFreight,
    this.isFreight,
    this.ssCost,
    this.smCost,
    this.isSm,
    this.regularPrice,
    this.installmentPrice,
    this.isRegular,
    this.currentAirFreight,
    this.currentSeaFreight,
    this.currentIsFreight,
    this.currentSsCost,
    this.currentSmCost,
    this.currentIsSm,
    this.currentRegularPrice,
    this.currentInstallmentPrice,
    this.currentIsRegular,
    this.currentFDeliveryAddress,
    this.orderStatus,
    this.isSelfPickup,
    this.isAdminApproval,
    this.isReady,
    this.arrivalNotificationFlag,
    this.dispatchNotificationFlag,
    this.isCodShelveTransfer,
    this.commission,
    this.rtsCollectionUserId,
    this.isCollectedForRts,
    this.fBundleNo,
    this.bundleSequence,
    this.codRtcAck,
    this.linePrice,
    this.changeType,
    this.returnType,
    this.returnDate,
    this.customerPostage,
    this.refundAmount,
    this.fPaymentNo,
    this.returnQty,
    this.unitPrice,
    this.lineTotal,
  });

  int? fVariantNo;
  String? prdVariantImagePath;
  String? igCode;
  String? prdVariantName;
  int? id;
  int? pkNo;
  int? fBookingNo;
  int? fInvStockNo;
  String? comments;
  int? isActive;
  int? fSsCreatedBy;
  String? ssCreatedOn;
  String? ssModifiedOn;
  int? fDeliveryAddress;
  int? fSsCompanyNo;
  int? isSystemHold;
  int? isAdminHold;
  int? dispatchStatus;
  double? airFreight;
  double? seaFreight;
  int? isFreight;
  double? ssCost;
  double? smCost;
  int? isSm;
  double? regularPrice;
  double? installmentPrice;
  int? isRegular;
  double? currentAirFreight;
  double? currentSeaFreight;
  int? currentIsFreight;
  double? currentSsCost;
  double? currentSmCost;
  int? currentIsSm;
  double? currentRegularPrice;
  double? currentInstallmentPrice;
  int? currentIsRegular;
  int? currentFDeliveryAddress;
  int? orderStatus;
  int? isSelfPickup;
  int? isAdminApproval;
  int? isReady;
  int? arrivalNotificationFlag;
  int? dispatchNotificationFlag;
  int? isCodShelveTransfer;
  double? commission;
  int? rtsCollectionUserId;
  int? isCollectedForRts;
  int? fBundleNo;
  int? bundleSequence;
  int? codRtcAck;
  double? linePrice;
  String? changeType;
  int? returnType;
  String? returnDate;
  double? customerPostage;
  double? refundAmount;
  int? fPaymentNo;
  int? returnQty;
  double? unitPrice;
  double? lineTotal;

  factory ReturnedItem.fromJson(Map<String, dynamic> json) => ReturnedItem(
    fVariantNo: json["f_variant_no"],
    prdVariantImagePath: json["PRD_VARIANT_IMAGE_PATH"],
    igCode: json["IG_CODE"],
    prdVariantName: json["PRD_VARINAT_NAME"],
    id: json["ID"],
    pkNo: json["PK_NO"],
    fBookingNo: json["F_BOOKING_NO"],
    fInvStockNo: json["F_INV_STOCK_NO"],
    comments: json["COMMENTS"],
    isActive: json["IS_ACTIVE"],
    fSsCreatedBy: json["F_SS_CREATED_BY"],
    ssCreatedOn: json["SS_CREATED_ON"],
    ssModifiedOn: json["SS_MODIFIED_ON"],
    fDeliveryAddress: json["F_DELIVERY_ADDRESS"],
    fSsCompanyNo: json["F_SS_COMPANY_NO"],
    isSystemHold: json["IS_SYSTEM_HOLD"],
    isAdminHold: json["IS_ADMIN_HOLD"],
    dispatchStatus: json["DISPATCH_STATUS"],
    airFreight: json["AIR_FREIGHT"] is int
      ? (json['AIR_FREIGHT'] as int).toDouble()
      : json['AIR_FREIGHT'],
    seaFreight: json["SEA_FREIGHT"] is int
      ? (json['SEA_FREIGHT'] as int).toDouble()
      : json['SEA_FREIGHT'],
    isFreight: json["IS_FREIGHT"],
    ssCost: json["SS_COST"] is int
      ? (json['SS_COST'] as int).toDouble()
      : json['SS_COST'],
    smCost: json["SM_COST"] is int
      ? (json['SM_COST'] as int).toDouble()
      : json['SM_COST'],
    isSm: json["IS_SM"],
    regularPrice: json["REGULAR_PRICE"] is int
      ? (json['REGULAR_PRICE'] as int).toDouble()
      : json['REGULAR_PRICE'],
    installmentPrice: json["INSTALLMENT_PRICE"] is int
      ? (json['INSTALLMENT_PRICE'] as int).toDouble()
      : json['INSTALLMENT_PRICE'],
    isRegular: json["IS_REGULAR"],
    currentAirFreight: json["CURRENT_AIR_FREIGHT"] is int
      ? (json['CURRENT_AIR_FREIGHT'] as int).toDouble()
      : json['CURRENT_AIR_FREIGHT'],
    currentSeaFreight: json["CURRENT_SEA_FREIGHT"] is int
      ? (json['CURRENT_SEA_FREIGHT'] as int).toDouble()
      : json['CURRENT_SEA_FREIGHT'],
    currentIsFreight: json["CURRENT_IS_FREIGHT"],
    currentSsCost: json["CURRENT_SS_COST"] is int
        ? (json['CURRENT_SS_COST'] as int).toDouble()
        : json["CURRENT_SS_COST"] is String ? double.parse(json['CURRENT_SS_COST'] as String) : json['CURRENT_SS_COST'],
    currentSmCost: json["CURRENT_SM_COST"] is int
        ? (json['CURRENT_SM_COST'] as int).toDouble()
        : json["CURRENT_SM_COST"] is String ? double.parse(json['CURRENT_SM_COST'] as String) : json['CURRENT_SM_COST'],
    currentIsSm: json["CURRENT_IS_SM"],
    currentRegularPrice: json["CURRENT_REGULAR_PRICE"] is int
      ? (json['CURRENT_REGULAR_PRICE'] as int).toDouble()
      : json['CURRENT_REGULAR_PRICE'],
    currentInstallmentPrice: json["CURRENT_INSTALLMENT_PRICE"] is int
      ? (json['CURRENT_INSTALLMENT_PRICE'] as int).toDouble()
      : json['CURRENT_INSTALLMENT_PRICE'],
    currentIsRegular: json["CURRENT_IS_REGULAR"],
    currentFDeliveryAddress: json["CURRENT_F_DELIVERY_ADDRESS"],
    orderStatus: json["ORDER_STATUS"],
    isSelfPickup: json["IS_SELF_PICKUP"],
    isAdminApproval: json["IS_ADMIN_APPROVAL"],
    isReady: json["IS_READY"],
    arrivalNotificationFlag: json["ARRIVAL_NOTIFICATION_FLAG"],
    dispatchNotificationFlag: json["DISPATCH_NOTIFICATION_FLAG"],
    isCodShelveTransfer: json["IS_COD_SHELVE_TRANSFER"],
    commission: json["COMISSION"] is int
      ? (json['COMISSION'] as int).toDouble()
      : json['COMISSION'],
    rtsCollectionUserId: json["RTS_COLLECTION_USER_ID"],
    isCollectedForRts: json["IS_COLLECTED_FOR_RTS"],
    fBundleNo: json["F_BUNDLE_NO"],
    bundleSequence: json["BUNDLE_SEQUENC"],
    codRtcAck: json["COD_RTC_ACK"],
    linePrice: json["LINE_PRICE"] is int
      ? (json['LINE_PRICE'] as int).toDouble()
      : json['LINE_PRICE'],
    changeType: json["CHANGE_TYPE"],
    returnType: json["RETURN_TYPE"],
    returnDate: json["RETURN_DATE"],
    customerPostage: json["CUSTOMER_POSTAGE"] is int
      ? (json['CUSTOMER_POSTAGE'] as int).toDouble()
      : json['CUSTOMER_POSTAGE'],
    refundAmount: json["REFUND_AMOUNT"] is int
      ? (json['REFUND_AMOUNT'] as int).toDouble()
      : json['REFUND_AMOUNT'],
    fPaymentNo: json["F_PAYMENT_NO"],
    returnQty: json["RETURN_QTY"],
    unitPrice: json["UNIT_PRICE"] is int
      ? (json['UNIT_PRICE'] as int).toDouble()
      : json['UNIT_PRICE'],
    lineTotal: json["LINE_TOTAL"] is int
      ? (json['LINE_TOTAL'] as int).toDouble()
      : json['LINE_TOTAL'],
  );

  Map<String, dynamic> toJson() => {
    "f_variant_no": fVariantNo,
    "PRD_VARIANT_IMAGE_PATH": prdVariantImagePath,
    "IG_CODE": igCode,
    "PRD_VARINAT_NAME": prdVariantName,
    "ID": id,
    "PK_NO": pkNo,
    "F_BOOKING_NO": fBookingNo,
    "F_INV_STOCK_NO": fInvStockNo,
    "COMMENTS": comments,
    "IS_ACTIVE": isActive,
    "F_SS_CREATED_BY": fSsCreatedBy,
    "SS_CREATED_ON": ssCreatedOn,
    "SS_MODIFIED_ON": ssModifiedOn,
    "F_DELIVERY_ADDRESS": fDeliveryAddress,
    "F_SS_COMPANY_NO": fSsCompanyNo,
    "IS_SYSTEM_HOLD": isSystemHold,
    "IS_ADMIN_HOLD": isAdminHold,
    "DISPATCH_STATUS": dispatchStatus,
    "AIR_FREIGHT": airFreight,
    "SEA_FREIGHT": seaFreight,
    "IS_FREIGHT": isFreight,
    "SS_COST": ssCost,
    "SM_COST": smCost,
    "IS_SM": isSm,
    "REGULAR_PRICE": regularPrice,
    "INSTALLMENT_PRICE": installmentPrice,
    "IS_REGULAR": isRegular,
    "CURRENT_AIR_FREIGHT": currentAirFreight,
    "CURRENT_SEA_FREIGHT": currentSeaFreight,
    "CURRENT_IS_FREIGHT": currentIsFreight,
    "CURRENT_SS_COST": currentSsCost,
    "CURRENT_SM_COST": currentSmCost,
    "CURRENT_IS_SM": currentIsSm,
    "CURRENT_REGULAR_PRICE": currentRegularPrice,
    "CURRENT_INSTALLMENT_PRICE": currentInstallmentPrice,
    "CURRENT_IS_REGULAR": currentIsRegular,
    "CURRENT_F_DELIVERY_ADDRESS": currentFDeliveryAddress,
    "ORDER_STATUS": orderStatus,
    "IS_SELF_PICKUP": isSelfPickup,
    "IS_ADMIN_APPROVAL": isAdminApproval,
    "IS_READY": isReady,
    "ARRIVAL_NOTIFICATION_FLAG": arrivalNotificationFlag,
    "DISPATCH_NOTIFICATION_FLAG": dispatchNotificationFlag,
    "IS_COD_SHELVE_TRANSFER": isCodShelveTransfer,
    "COMISSION": commission,
    "RTS_COLLECTION_USER_ID": rtsCollectionUserId,
    "IS_COLLECTED_FOR_RTS": isCollectedForRts,
    "F_BUNDLE_NO": fBundleNo,
    "BUNDLE_SEQUENC": bundleSequence,
    "COD_RTC_ACK": codRtcAck,
    "LINE_PRICE": linePrice,
    "CHANGE_TYPE": changeType,
    "RETURN_TYPE": returnType,
    "RETURN_DATE": returnDate,
    "CUSTOMER_POSTAGE": customerPostage,
    "REFUND_AMOUNT": refundAmount,
    "F_PAYMENT_NO": fPaymentNo,
    "RETURN_QTY": returnQty,
    "UNIT_PRICE": unitPrice,
    "LINE_TOTAL": lineTotal,
  };
}

class Refunded {
  Refunded({
    this.fVariantNo,
    this.prdVariantImagePath,
    this.igCode,
    this.prdVariantName,
    this.id,
    this.pkNo,
    this.fBookingNo,
    this.fInvStockNo,
    this.comments,
    this.isActive,
    this.fSsCreatedBy,
    this.ssCreatedOn,
    this.ssModifiedOn,
    this.fDeliveryAddress,
    this.fSsCompanyNo,
    this.isSystemHold,
    this.isAdminHold,
    this.dispatchStatus,
    this.airFreight,
    this.seaFreight,
    this.isFreight,
    this.ssCost,
    this.smCost,
    this.isSm,
    this.regularPrice,
    this.installmentPrice,
    this.isRegular,
    this.currentAirFreight,
    this.currentSeaFreight,
    this.currentIsFreight,
    this.currentSsCost,
    this.currentSmCost,
    this.currentIsSm,
    this.currentRegularPrice,
    this.currentInstallmentPrice,
    this.currentIsRegular,
    this.currentFDeliveryAddress,
    this.orderStatus,
    this.isSelfPickup,
    this.isAdminApproval,
    this.isReady,
    this.arrivalNotificationFlag,
    this.dispatchNotificationFlag,
    this.isCodShelveTransfer,
    this.commission,
    this.rtsCollectionUserId,
    this.isCollectedForRts,
    this.fBundleNo,
    this.bundleSequence,
    this.codRtcAck,
    this.linePrice,
    this.changeType,
    this.returnType,
    this.returnDate,
    this.customerPostage,
    this.refundAmount,
    this.fPaymentNo,
    this.returnNote,
  });

  int? fVariantNo;
  String? prdVariantImagePath;
  String? igCode;
  String? prdVariantName;
  int? id;
  int? pkNo;
  int? fBookingNo;
  int? fInvStockNo;
  String? comments;
  int? isActive;
  int? fSsCreatedBy;
  String? ssCreatedOn;
  String? ssModifiedOn;
  int? fDeliveryAddress;
  int? fSsCompanyNo;
  int? isSystemHold;
  int? isAdminHold;
  int? dispatchStatus;
  double? airFreight;
  double? seaFreight;
  int? isFreight;
  double? ssCost;
  double? smCost;
  int? isSm;
  double? regularPrice;
  double? installmentPrice;
  int? isRegular;
  double? currentAirFreight;
  double? currentSeaFreight;
  int? currentIsFreight;
  double? currentSsCost;
  double? currentSmCost;
  int? currentIsSm;
  double? currentRegularPrice;
  double? currentInstallmentPrice;
  int? currentIsRegular;
  int? currentFDeliveryAddress;
  int? orderStatus;
  int? isSelfPickup;
  int? isAdminApproval;
  int? isReady;
  int? arrivalNotificationFlag;
  int? dispatchNotificationFlag;
  int? isCodShelveTransfer;
  double? commission;
  int? rtsCollectionUserId;
  int? isCollectedForRts;
  int? fBundleNo;
  int? bundleSequence;
  int? codRtcAck;
  double? linePrice;
  String? changeType;
  int? returnType;
  String? returnDate;
  double? customerPostage;
  double? refundAmount;
  int? fPaymentNo;
  String? returnNote;

  factory Refunded.fromJson(Map<String, dynamic> json) => Refunded(
    fVariantNo: json["f_variant_no"],
    prdVariantImagePath: json["PRD_VARIANT_IMAGE_PATH"],
    igCode: json["IG_CODE"],
    prdVariantName: json["PRD_VARINAT_NAME"],
    id: json["ID"],
    pkNo: json["PK_NO"],
    fBookingNo: json["F_BOOKING_NO"],
    fInvStockNo: json["F_INV_STOCK_NO"],
    comments: json["COMMENTS"],
    isActive: json["IS_ACTIVE"],
    fSsCreatedBy: json["F_SS_CREATED_BY"],
    ssCreatedOn: json["SS_CREATED_ON"],
    ssModifiedOn: json["SS_MODIFIED_ON"],
    fDeliveryAddress: json["F_DELIVERY_ADDRESS"],
    fSsCompanyNo: json["F_SS_COMPANY_NO"],
    isSystemHold: json["IS_SYSTEM_HOLD"],
    isAdminHold: json["IS_ADMIN_HOLD"],
    dispatchStatus: json["DISPATCH_STATUS"],
    airFreight: json["AIR_FREIGHT"] is int
      ? (json['AIR_FREIGHT'] as int).toDouble()
      : json['AIR_FREIGHT'],
    seaFreight: json["SEA_FREIGHT"] is int
      ? (json['SEA_FREIGHT'] as int).toDouble()
      : json['SEA_FREIGHT'],
    isFreight: json["IS_FREIGHT"],
    ssCost: json["SS_COST"] is int
      ? (json['SS_COST'] as int).toDouble()
      : json['SS_COST'],
    smCost: json["SM_COST"] is int
      ? (json['SM_COST'] as int).toDouble()
      : json['SM_COST'],
    isSm: json["IS_SM"],
    regularPrice: json["REGULAR_PRICE"] is int
      ? (json['REGULAR_PRICE'] as int).toDouble()
      : json['REGULAR_PRICE'],
    installmentPrice: json["INSTALLMENT_PRICE"] is int
      ? (json['INSTALLMENT_PRICE'] as int).toDouble()
      : json['INSTALLMENT_PRICE'],
    isRegular: json["IS_REGULAR"],
    currentAirFreight: json["CURRENT_AIR_FREIGHT"] is int
      ? (json['CURRENT_AIR_FREIGHT'] as int).toDouble()
      : json['CURRENT_AIR_FREIGHT'],
    currentSeaFreight: json["CURRENT_SEA_FREIGHT"] is int
      ? (json['CURRENT_SEA_FREIGHT'] as int).toDouble()
      : json['CURRENT_SEA_FREIGHT'],
    currentIsFreight: json["CURRENT_IS_FREIGHT"],
    currentSsCost: json["CURRENT_SS_COST"] is int
        ? (json['CURRENT_SS_COST'] as int).toDouble()
        : json["CURRENT_SS_COST"] is String ? double.parse(json['CURRENT_SS_COST'] as String) : json['CURRENT_SS_COST'],
    currentSmCost: json["CURRENT_SM_COST"] is int
        ? (json['CURRENT_SM_COST'] as int).toDouble()
        : json["CURRENT_SM_COST"] is String ? double.parse(json['CURRENT_SM_COST'] as String) : json['CURRENT_SM_COST'],
    currentIsSm: json["CURRENT_IS_SM"],
    currentRegularPrice: json["CURRENT_REGULAR_PRICE"] is int
      ? (json['CURRENT_REGULAR_PRICE'] as int).toDouble()
      : json['CURRENT_REGULAR_PRICE'],
    currentInstallmentPrice: json["CURRENT_INSTALLMENT_PRICE"] is int
      ? (json['CURRENT_INSTALLMENT_PRICE'] as int).toDouble()
      : json['CURRENT_INSTALLMENT_PRICE'],
    currentIsRegular: json["CURRENT_IS_REGULAR"],
    currentFDeliveryAddress: json["CURRENT_F_DELIVERY_ADDRESS"],
    orderStatus: json["ORDER_STATUS"],
    isSelfPickup: json["IS_SELF_PICKUP"],
    isAdminApproval: json["IS_ADMIN_APPROVAL"],
    isReady: json["IS_READY"],
    arrivalNotificationFlag: json["ARRIVAL_NOTIFICATION_FLAG"],
    dispatchNotificationFlag: json["DISPATCH_NOTIFICATION_FLAG"],
    isCodShelveTransfer: json["IS_COD_SHELVE_TRANSFER"],
    commission: json["COMISSION"] is int
      ? (json['COMISSION'] as int).toDouble()
      : json['COMISSION'],
    rtsCollectionUserId: json["RTS_COLLECTION_USER_ID"],
    isCollectedForRts: json["IS_COLLECTED_FOR_RTS"],
    fBundleNo: json["F_BUNDLE_NO"],
    bundleSequence: json["BUNDLE_SEQUENC"],
    codRtcAck: json["COD_RTC_ACK"],
    linePrice: json["LINE_PRICE"] is int
      ? (json['LINE_PRICE'] as int).toDouble()
      : json['LINE_PRICE'],
    changeType: json["CHANGE_TYPE"],
    returnType: json["RETURN_TYPE"],
    returnDate: json["RETURN_DATE"],
    customerPostage: json["CUSTOMER_POSTAGE"] is int
      ? (json['CUSTOMER_POSTAGE'] as int).toDouble()
      : json['CUSTOMER_POSTAGE'],
    refundAmount: json["REFUND_AMOUNT"] is int
      ? (json['REFUND_AMOUNT'] as int).toDouble()
      : json['REFUND_AMOUNT'],
    fPaymentNo: json["F_PAYMENT_NO"],
    returnNote: json["RETURN_NOTE"],
  );

  Map<String, dynamic> toJson() => {
    "f_variant_no": fVariantNo,
    "PRD_VARIANT_IMAGE_PATH": prdVariantImagePath,
    "IG_CODE": igCode,
    "PRD_VARINAT_NAME": prdVariantName,
    "ID": id,
    "PK_NO": pkNo,
    "F_BOOKING_NO": fBookingNo,
    "F_INV_STOCK_NO": fInvStockNo,
    "COMMENTS": comments,
    "IS_ACTIVE": isActive,
    "F_SS_CREATED_BY": fSsCreatedBy,
    "SS_CREATED_ON": ssCreatedOn,
    "SS_MODIFIED_ON": ssModifiedOn,
    "F_DELIVERY_ADDRESS": fDeliveryAddress,
    "F_SS_COMPANY_NO": fSsCompanyNo,
    "IS_SYSTEM_HOLD": isSystemHold,
    "IS_ADMIN_HOLD": isAdminHold,
    "DISPATCH_STATUS": dispatchStatus,
    "AIR_FREIGHT": airFreight,
    "SEA_FREIGHT": seaFreight,
    "IS_FREIGHT": isFreight,
    "SS_COST": ssCost,
    "SM_COST": smCost,
    "IS_SM": isSm,
    "REGULAR_PRICE": regularPrice,
    "INSTALLMENT_PRICE": installmentPrice,
    "IS_REGULAR": isRegular,
    "CURRENT_AIR_FREIGHT": currentAirFreight,
    "CURRENT_SEA_FREIGHT": currentSeaFreight,
    "CURRENT_IS_FREIGHT": currentIsFreight,
    "CURRENT_SS_COST": currentSsCost,
    "CURRENT_SM_COST": currentSmCost,
    "CURRENT_IS_SM": currentIsSm,
    "CURRENT_REGULAR_PRICE": currentRegularPrice,
    "CURRENT_INSTALLMENT_PRICE": currentInstallmentPrice,
    "CURRENT_IS_REGULAR": currentIsRegular,
    "CURRENT_F_DELIVERY_ADDRESS": currentFDeliveryAddress,
    "ORDER_STATUS": orderStatus,
    "IS_SELF_PICKUP": isSelfPickup,
    "IS_ADMIN_APPROVAL": isAdminApproval,
    "IS_READY": isReady,
    "ARRIVAL_NOTIFICATION_FLAG": arrivalNotificationFlag,
    "DISPATCH_NOTIFICATION_FLAG": dispatchNotificationFlag,
    "IS_COD_SHELVE_TRANSFER": isCodShelveTransfer,
    "COMISSION": commission,
    "RTS_COLLECTION_USER_ID": rtsCollectionUserId,
    "IS_COLLECTED_FOR_RTS": isCollectedForRts,
    "F_BUNDLE_NO": fBundleNo,
    "BUNDLE_SEQUENC": bundleSequence,
    "COD_RTC_ACK": codRtcAck,
    "LINE_PRICE": linePrice,
    "CHANGE_TYPE": changeType,
    "RETURN_TYPE": returnType,
    "RETURN_DATE": returnDate,
    "CUSTOMER_POSTAGE": customerPostage,
    "REFUND_AMOUNT": refundAmount,
    "F_PAYMENT_NO": fPaymentNo,
    "RETURN_NOTE": returnNote,
  };
}

class DeletedItem {
  DeletedItem({
    this.fVariantNo,
    this.prdVariantImagePath,
    this.igCode,
    this.prdVariantName,
    this.id,
    this.pkNo,
    this.fBookingNo,
    this.fInvStockNo,
    this.comments,
    this.isActive,
    this.ssCreatedOn,
    this.ssModifiedOn,
    this.fDeliveryAddress,
    this.isSystemHold,
    this.isAdminHold,
    this.dispatchStatus,
    this.airFreight,
    this.seaFreight,
    this.isFreight,
    this.ssCost,
    this.smCost,
    this.isSm,
    this.regularPrice,
    this.installmentPrice,
    this.isRegular,
    this.currentAirFreight,
    this.currentSeaFreight,
    this.currentIsFreight,
    this.currentSsCost,
    this.currentSmCost,
    this.currentIsSm,
    this.currentRegularPrice,
    this.currentInstallmentPrice,
    this.currentIsRegular,
    this.currentFDeliveryAddress,
    this.orderStatus,
    this.isSelfPickup,
    this.isAdminApproval,
    this.isReady,
    this.arrivalNotificationFlag,
    this.dispatchNotificationFlag,
    this.isCodShelveTransfer,
    this.commission,
    this.rtsCollectionUserId,
    this.isCollectedForRts,
    this.codRtcAck,
    this.linePrice,
    this.changeType,
    this.returnDate,
    this.customerPostage,
    this.refundAmount,
    this.fPaymentNo,
    this.deleteQty,
    this.unitPrice,
    this.lineTotal,
  });

  int? fVariantNo;
  String? prdVariantImagePath;
  String? igCode;
  String? prdVariantName;
  int? id;
  int? pkNo;
  int? fBookingNo;
  int? fInvStockNo;
  String? comments;
  int? isActive;
  String? ssCreatedOn;
  String? ssModifiedOn;
  int? fDeliveryAddress;
  int? isSystemHold;
  int? isAdminHold;
  int? dispatchStatus;
  double? airFreight;
  double? seaFreight;
  int? isFreight;
  double? ssCost;
  double? smCost;
  int? isSm;
  double? regularPrice;
  double? installmentPrice;
  int? isRegular;
  double? currentAirFreight;
  double? currentSeaFreight;
  int? currentIsFreight;
  double? currentSsCost;
  double? currentSmCost;
  int? currentIsSm;
  double? currentRegularPrice;
  double? currentInstallmentPrice;
  int? currentIsRegular;
  int? currentFDeliveryAddress;
  int? orderStatus;
  int? isSelfPickup;
  int? isAdminApproval;
  int? isReady;
  int? arrivalNotificationFlag;
  int? dispatchNotificationFlag;
  int? isCodShelveTransfer;
  double? commission;
  int? rtsCollectionUserId;
  int? isCollectedForRts;
  int? codRtcAck;
  double? linePrice;
  String? changeType;
  String? returnDate;
  double? customerPostage;
  double? refundAmount;
  int? fPaymentNo;
  int? deleteQty;
  double? unitPrice;
  double? lineTotal;

  factory DeletedItem.fromJson(Map<String, dynamic> json) => DeletedItem(
    fVariantNo: json["f_variant_no"],
    prdVariantImagePath: json["PRD_VARIANT_IMAGE_PATH"],
    igCode: json["IG_CODE"],
    prdVariantName: json["PRD_VARINAT_NAME"],
    id: json["ID"],
    pkNo: json["PK_NO"],
    fBookingNo: json["F_BOOKING_NO"],
    fInvStockNo: json["F_INV_STOCK_NO"],
    comments: json["COMMENTS"],
    isActive: json["IS_ACTIVE"],
    ssCreatedOn: json["SS_CREATED_ON"],
    ssModifiedOn: json["SS_MODIFIED_ON"],
    fDeliveryAddress: json["F_DELIVERY_ADDRESS"],
    isSystemHold: json["IS_SYSTEM_HOLD"],
    isAdminHold: json["IS_ADMIN_HOLD"],
    dispatchStatus: json["DISPATCH_STATUS"],
    airFreight: json["AIR_FREIGHT"] is int
      ? (json['AIR_FREIGHT'] as int).toDouble()
      : json['AIR_FREIGHT'],
    seaFreight: json["SEA_FREIGHT"] is int
      ? (json['SEA_FREIGHT'] as int).toDouble()
      : json['SEA_FREIGHT'],
    isFreight: json["IS_FREIGHT"],
    ssCost: json["SS_COST"] is int
      ? (json['SS_COST'] as int).toDouble()
      : json['SS_COST'],
    smCost: json["SM_COST"] is int
      ? (json['SM_COST'] as int).toDouble()
      : json['SM_COST'],
    isSm: json["IS_SM"],
    regularPrice: json["REGULAR_PRICE"] is int
      ? (json['REGULAR_PRICE'] as int).toDouble()
      : json['REGULAR_PRICE'],
    installmentPrice: json["INSTALLMENT_PRICE"] is int
      ? (json['INSTALLMENT_PRICE'] as int).toDouble()
      : json['INSTALLMENT_PRICE'],
    isRegular: json["IS_REGULAR"],
    currentAirFreight: json["CURRENT_AIR_FREIGHT"] is int
      ? (json['CURRENT_AIR_FREIGHT'] as int).toDouble()
      : json['CURRENT_AIR_FREIGHT'],
    currentSeaFreight: json["CURRENT_SEA_FREIGHT"] is int
      ? (json['CURRENT_SEA_FREIGHT'] as int).toDouble()
      : json['CURRENT_SEA_FREIGHT'],
    currentIsFreight: json["CURRENT_IS_FREIGHT"],
    currentSsCost: json["CURRENT_SS_COST"] is int
        ? (json['CURRENT_SS_COST'] as int).toDouble()
        : json["CURRENT_SS_COST"] is String ? double.parse(json['CURRENT_SS_COST'] as String) : json['CURRENT_SS_COST'],
    currentSmCost: json["CURRENT_SM_COST"] is int
        ? (json['CURRENT_SM_COST'] as int).toDouble()
        : json["CURRENT_SM_COST"] is String ? double.parse(json['CURRENT_SM_COST'] as String) : json['CURRENT_SM_COST'],
    currentIsSm: json["CURRENT_IS_SM"],
    currentRegularPrice: json["CURRENT_REGULAR_PRICE"] is int
      ? (json['CURRENT_REGULAR_PRICE'] as int).toDouble()
      : json['CURRENT_REGULAR_PRICE'],
    currentInstallmentPrice: json["CURRENT_INSTALLMENT_PRICE"] is int
      ? (json['CURRENT_INSTALLMENT_PRICE'] as int).toDouble()
      : json['CURRENT_INSTALLMENT_PRICE'],
    currentIsRegular: json["CURRENT_IS_REGULAR"],
    currentFDeliveryAddress: json["CURRENT_F_DELIVERY_ADDRESS"],
    orderStatus: json["ORDER_STATUS"],
    isSelfPickup: json["IS_SELF_PICKUP"],
    isAdminApproval: json["IS_ADMIN_APPROVAL"],
    isReady: json["IS_READY"],
    arrivalNotificationFlag: json["ARRIVAL_NOTIFICATION_FLAG"],
    dispatchNotificationFlag: json["DISPATCH_NOTIFICATION_FLAG"],
    isCodShelveTransfer: json["IS_COD_SHELVE_TRANSFER"],
    commission: json["COMISSION"] is int
      ? (json['COMISSION'] as int).toDouble()
      : json['COMISSION'],
    rtsCollectionUserId: json["RTS_COLLECTION_USER_ID"],
    isCollectedForRts: json["IS_COLLECTED_FOR_RTS"],
    codRtcAck: json["COD_RTC_ACK"],
    linePrice: json["LINE_PRICE"] is int
      ? (json['LINE_PRICE'] as int).toDouble()
      : json['LINE_PRICE'],
    changeType: json["CHANGE_TYPE"],
    returnDate: json["RETURN_DATE"],
    customerPostage: json["CUSTOMER_POSTAGE"] is int
      ? (json['CUSTOMER_POSTAGE'] as int).toDouble()
      : json['CUSTOMER_POSTAGE'],
    refundAmount: json["REFUND_AMOUNT"] is int
      ? (json['REFUND_AMOUNT'] as int).toDouble()
      : json['REFUND_AMOUNT'],
    fPaymentNo: json["F_PAYMENT_NO"],
    deleteQty: json["DELETE_QTY"],
    unitPrice: json["UNIT_PRICE"] is int
      ? (json['UNIT_PRICE'] as int).toDouble()
      : json['UNIT_PRICE'],
    lineTotal: json["LINE_TOTAL"] is int
      ? (json['LINE_TOTAL'] as int).toDouble()
      : json['LINE_TOTAL'],
  );

  Map<String, dynamic> toJson() => {
    "f_variant_no": fVariantNo,
    "PRD_VARIANT_IMAGE_PATH": prdVariantImagePath,
    "IG_CODE": igCode,
    "PRD_VARINAT_NAME": prdVariantName,
    "ID": id,
    "PK_NO": pkNo,
    "F_BOOKING_NO": fBookingNo,
    "F_INV_STOCK_NO": fInvStockNo,
    "COMMENTS": comments,
    "IS_ACTIVE": isActive,
    "SS_CREATED_ON": ssCreatedOn,
    "SS_MODIFIED_ON": ssModifiedOn,
    "F_DELIVERY_ADDRESS": fDeliveryAddress,
    "IS_SYSTEM_HOLD": isSystemHold,
    "IS_ADMIN_HOLD": isAdminHold,
    "DISPATCH_STATUS": dispatchStatus,
    "AIR_FREIGHT": airFreight,
    "SEA_FREIGHT": seaFreight,
    "IS_FREIGHT": isFreight,
    "SS_COST": ssCost,
    "SM_COST": smCost,
    "IS_SM": isSm,
    "REGULAR_PRICE": regularPrice,
    "INSTALLMENT_PRICE": installmentPrice,
    "IS_REGULAR": isRegular,
    "CURRENT_AIR_FREIGHT": currentAirFreight,
    "CURRENT_SEA_FREIGHT": currentSeaFreight,
    "CURRENT_IS_FREIGHT": currentIsFreight,
    "CURRENT_SS_COST": currentSsCost,
    "CURRENT_SM_COST": currentSmCost,
    "CURRENT_IS_SM": currentIsSm,
    "CURRENT_REGULAR_PRICE": currentRegularPrice,
    "CURRENT_INSTALLMENT_PRICE": currentInstallmentPrice,
    "CURRENT_IS_REGULAR": currentIsRegular,
    "CURRENT_F_DELIVERY_ADDRESS": currentFDeliveryAddress,
    "ORDER_STATUS": orderStatus,
    "IS_SELF_PICKUP": isSelfPickup,
    "IS_ADMIN_APPROVAL": isAdminApproval,
    "IS_READY": isReady,
    "ARRIVAL_NOTIFICATION_FLAG": arrivalNotificationFlag,
    "DISPATCH_NOTIFICATION_FLAG": dispatchNotificationFlag,
    "IS_COD_SHELVE_TRANSFER": isCodShelveTransfer,
    "COMISSION": commission,
    "RTS_COLLECTION_USER_ID": rtsCollectionUserId,
    "IS_COLLECTED_FOR_RTS": isCollectedForRts,
    "COD_RTC_ACK": codRtcAck,
    "LINE_PRICE": linePrice,
    "CHANGE_TYPE": changeType,
    "RETURN_DATE": returnDate,
    "CUSTOMER_POSTAGE": customerPostage,
    "REFUND_AMOUNT": refundAmount,
    "F_PAYMENT_NO": fPaymentNo,
    "DELETE_QTY": deleteQty,
    "UNIT_PRICE": unitPrice,
    "LINE_TOTAL": lineTotal,
  };
}

class BookChild {
  BookChild({
    this.fVariantNo,
    this.prdVariantImagePath,
    this.igCode,
    this.prdVariantName,
    this.pkNo,
    this.fBookingNo,
    this.fInvStockNo,
    this.comments,
    this.isActive,
    this.ssCreatedOn,
    this.ssModifiedOn,
    this.fDeliveryAddress,
    this.isSystemHold,
    this.isAdminHold,
    this.dispatchStatus,
    this.airFreight,
    this.seaFreight,
    this.isFreight,
    this.ssCost,
    this.smCost,
    this.isSm,
    this.regularPrice,
    this.installmentPrice,
    this.isRegular,
    this.currentAirFreight,
    this.currentSeaFreight,
    this.currentIsFreight,
    this.currentSsCost,
    this.currentSmCost,
    this.currentIsSm,
    this.currentRegularPrice,
    this.currentInstallmentPrice,
    this.currentIsRegular,
    this.currentFDeliveryAddress,
    this.orderStatus,
    this.isSelfPickup,
    this.isAdminApproval,
    this.isReady,
    this.arrivalNotificationFlag,
    this.dispatchNotificationFlag,
    this.isCodShelveTransfer,
    this.commission,
    this.rtsCollectionUserId,
    this.isCollectedForRts,
    this.codRtcAck,
    this.linePrice,
    this.qty,
    this.shippedQty,
    this.refundQty,
    this.deleteQty,
    this.unitPrice,
    this.lineTotal,
    this.totalQty,
  });

  int? fVariantNo;
  String? prdVariantImagePath;
  String? igCode;
  String? prdVariantName;
  int? pkNo;
  int? fBookingNo;
  int? fInvStockNo;
  String? comments;
  int? isActive;
  String? ssCreatedOn;
  String? ssModifiedOn;
  int? fDeliveryAddress;
  int? isSystemHold;
  int? isAdminHold;
  int? dispatchStatus;
  double? airFreight;
  double? seaFreight;
  int? isFreight;
  double? ssCost;
  double? smCost;
  int? isSm;
  double? regularPrice;
  double? installmentPrice;
  int? isRegular;
  double? currentAirFreight;
  double? currentSeaFreight;
  int? currentIsFreight;
  double? currentSsCost;
  double? currentSmCost;
  int? currentIsSm;
  double? currentRegularPrice;
  double? currentInstallmentPrice;
  int? currentIsRegular;
  int? currentFDeliveryAddress;
  int? orderStatus;
  int? isSelfPickup;
  int? isAdminApproval;
  int? isReady;
  int? arrivalNotificationFlag;
  int? dispatchNotificationFlag;
  int? isCodShelveTransfer;
  double? commission;
  int? rtsCollectionUserId;
  int? isCollectedForRts;
  int? codRtcAck;
  double? linePrice;
  int? qty;
  int? shippedQty;
  int? refundQty;
  int? deleteQty;
  double? unitPrice;
  double? lineTotal;
  int? totalQty;

  factory BookChild.fromJson(Map<String, dynamic> json) => BookChild(
    fVariantNo: json["f_variant_no"],
    prdVariantImagePath: json["PRD_VARIANT_IMAGE_PATH"],
    igCode: json["IG_CODE"],
    prdVariantName: json["PRD_VARINAT_NAME"],
    pkNo: json["PK_NO"],
    fBookingNo: json["F_BOOKING_NO"],
    fInvStockNo: json["F_INV_STOCK_NO"],
    comments: json["COMMENTS"],
    isActive: json["IS_ACTIVE"],
    ssCreatedOn: json["SS_CREATED_ON"],
    ssModifiedOn: json["SS_MODIFIED_ON"],
    fDeliveryAddress: json["F_DELIVERY_ADDRESS"],
    isSystemHold: json["IS_SYSTEM_HOLD"],
    isAdminHold: json["IS_ADMIN_HOLD"],
    dispatchStatus: json["DISPATCH_STATUS"],
    airFreight: json["AIR_FREIGHT"] is int
      ? (json['AIR_FREIGHT'] as int).toDouble()
      : json['AIR_FREIGHT'],
    seaFreight: json["SEA_FREIGHT"] is int
      ? (json['SEA_FREIGHT'] as int).toDouble()
      : json['SEA_FREIGHT'],
    isFreight: json["IS_FREIGHT"],
    ssCost: json["SS_COST"] is int
      ? (json['SS_COST'] as int).toDouble()
      : json['SS_COST'],
    smCost: json["SM_COST"] is int
      ? (json['SM_COST'] as int).toDouble()
      : json['SM_COST'],
    isSm: json["IS_SM"],
    regularPrice: json["REGULAR_PRICE"] is int
      ? (json['REGULAR_PRICE'] as int).toDouble()
      : json['REGULAR_PRICE'],
    installmentPrice: json["INSTALLMENT_PRICE"] is int
      ? (json['INSTALLMENT_PRICE'] as int).toDouble()
      : json['INSTALLMENT_PRICE'],
    isRegular: json["IS_REGULAR"],
    currentAirFreight: json["CURRENT_AIR_FREIGHT"] is int
      ? (json['CURRENT_AIR_FREIGHT'] as int).toDouble()
      : json['CURRENT_AIR_FREIGHT'],
    currentSeaFreight: json["CURRENT_SEA_FREIGHT"] is int
      ? (json['CURRENT_SEA_FREIGHT'] as int).toDouble()
      : json['CURRENT_SEA_FREIGHT'],
    currentIsFreight: json["CURRENT_IS_FREIGHT"],
    currentSsCost: json["CURRENT_SS_COST"] is int
      ? (json['CURRENT_SS_COST'] as int).toDouble()
      : json["CURRENT_SS_COST"] is String ? double.parse(json['CURRENT_SS_COST'] as String) : json['CURRENT_SS_COST'],
    currentSmCost: json["CURRENT_SM_COST"] is int
      ? (json['CURRENT_SM_COST'] as int).toDouble()
      : json["CURRENT_SM_COST"] is String ? double.parse(json['CURRENT_SM_COST'] as String) : json['CURRENT_SM_COST'],
    currentIsSm: json["CURRENT_IS_SM"],
    currentRegularPrice: json["AIR_FREIGHT"] is int
      ? (json['AIR_FREIGHT'] as int).toDouble()
      : json['AIR_FREIGHT'],
    currentInstallmentPrice: json["CURRENT_INSTALLMENT_PRICE"] is int
      ? (json['CURRENT_INSTALLMENT_PRICE'] as int).toDouble()
      : json['CURRENT_INSTALLMENT_PRICE'],
    currentIsRegular: json["CURRENT_IS_REGULAR"],
    currentFDeliveryAddress: json["CURRENT_F_DELIVERY_ADDRESS"],
    orderStatus: json["ORDER_STATUS"],
    isSelfPickup: json["IS_SELF_PICKUP"],
    isAdminApproval: json["IS_ADMIN_APPROVAL"],
    isReady: json["IS_READY"],
    arrivalNotificationFlag: json["ARRIVAL_NOTIFICATION_FLAG"],
    dispatchNotificationFlag: json["DISPATCH_NOTIFICATION_FLAG"],
    isCodShelveTransfer: json["IS_COD_SHELVE_TRANSFER"],
    commission: json["COMISSION"] is int
      ? (json['COMISSION'] as int).toDouble()
      : json['COMISSION'],
    rtsCollectionUserId: json["RTS_COLLECTION_USER_ID"],
    isCollectedForRts: json["IS_COLLECTED_FOR_RTS"],
    codRtcAck: json["COD_RTC_ACK"],
    linePrice: json["LINE_PRICE"] is int
      ? (json['LINE_PRICE'] as int).toDouble()
      : json['LINE_PRICE'],
    qty: json["QTY"],
    shippedQty: json["SHIPPED_QTY"],
    refundQty: json["REFUND_QTY"],
    deleteQty: json["DELETE_QTY"],
    unitPrice: json["UNIT_PRICE"] is int
      ? (json['UNIT_PRICE'] as int).toDouble()
      : json['UNIT_PRICE'],
    lineTotal: json["LINE_TOTAL"] is int
      ? (json['LINE_TOTAL'] as int).toDouble()
      : json['LINE_TOTAL'],
    totalQty: json["TOTAL_QTY"],
  );

  Map<String, dynamic> toJson() => {
    "f_variant_no": fVariantNo,
    "PRD_VARIANT_IMAGE_PATH": prdVariantImagePath,
    "IG_CODE": igCode,
    "PRD_VARINAT_NAME": prdVariantName,
    "PK_NO": pkNo,
    "F_BOOKING_NO": fBookingNo,
    "F_INV_STOCK_NO": fInvStockNo,
    "COMMENTS": comments,
    "IS_ACTIVE": isActive,
    "SS_CREATED_ON": ssCreatedOn,
    "SS_MODIFIED_ON": ssModifiedOn,
    "F_DELIVERY_ADDRESS": fDeliveryAddress,
    "IS_SYSTEM_HOLD": isSystemHold,
    "IS_ADMIN_HOLD": isAdminHold,
    "DISPATCH_STATUS": dispatchStatus,
    "AIR_FREIGHT": airFreight,
    "SEA_FREIGHT": seaFreight,
    "IS_FREIGHT": isFreight,
    "SS_COST": ssCost,
    "SM_COST": smCost,
    "IS_SM": isSm,
    "REGULAR_PRICE": regularPrice,
    "INSTALLMENT_PRICE": installmentPrice,
    "IS_REGULAR": isRegular,
    "CURRENT_AIR_FREIGHT": currentAirFreight,
    "CURRENT_SEA_FREIGHT": currentSeaFreight,
    "CURRENT_IS_FREIGHT": currentIsFreight,
    "CURRENT_SS_COST": currentSsCost,
    "CURRENT_SM_COST": currentSmCost,
    "CURRENT_IS_SM": currentIsSm,
    "CURRENT_REGULAR_PRICE": currentRegularPrice,
    "CURRENT_INSTALLMENT_PRICE": currentInstallmentPrice,
    "CURRENT_IS_REGULAR": currentIsRegular,
    "CURRENT_F_DELIVERY_ADDRESS": currentFDeliveryAddress,
    "ORDER_STATUS": orderStatus,
    "IS_SELF_PICKUP": isSelfPickup,
    "IS_ADMIN_APPROVAL": isAdminApproval,
    "IS_READY": isReady,
    "ARRIVAL_NOTIFICATION_FLAG": arrivalNotificationFlag,
    "DISPATCH_NOTIFICATION_FLAG": dispatchNotificationFlag,
    "IS_COD_SHELVE_TRANSFER": isCodShelveTransfer,
    "COMISSION": commission,
    "RTS_COLLECTION_USER_ID": rtsCollectionUserId,
    "IS_COLLECTED_FOR_RTS": isCollectedForRts,
    "COD_RTC_ACK": codRtcAck,
    "LINE_PRICE": linePrice,
    "QTY": qty,
    "SHIPPED_QTY": shippedQty,
    "REFUND_QTY": refundQty,
    "DELETE_QTY": deleteQty,
    "UNIT_PRICE": unitPrice,
    "LINE_TOTAL": lineTotal,
    "TOTAL_QTY": totalQty,
  };
}