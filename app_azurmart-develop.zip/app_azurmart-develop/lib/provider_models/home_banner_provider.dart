// import 'dart:convert';
//
// import 'package:azura_mart_design/network_models/home_banner.dart';
// import 'package:azura_mart_design/utils/url.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:http/http.dart' as http;
//
// class HomeBannerProvider extends ChangeNotifier{
//   bool isLoading = true;
//   HomeBanner banner = new HomeBanner();
//   // List<Data> homeBannerList = new List();
//
//   setData(HomeBanner banner){
//     this.banner = banner;
//     this.isLoading = false;
//     notifyListeners();
//   }
//
//   HomeBanner getData(){
//     return banner;
//   }
//
//   Future<HomeBanner> hitBannerApi() async{
//     try{
//       // SharedPreferences localStorage = await SharedPreferences.getInstance();
//       // String token = localStorage.getString(SharedPreferenceUtils.TOKEN);
//       final url = Uri.parse(Urls.baseUrl+Urls.home_banner);
//       var response = await http.post(url,headers: {
//         'Content-type' : 'application/json',
//         'Charset': 'utf-8',
//         'Accept' : 'application/json',
//       }
//       );
//       final Map<String, dynamic> body =await json.decode(response.body);
//       HomeBanner banners = HomeBanner.fromJson(body);
//       print(banners.message);
//       return banners;
//     }on Exception catch(e){
//       print(e);
//     }
//
//     return new HomeBanner();
//   }
//
// }