// To parse this JSON data, do
//
//     final cartModel = cartModelFromJson(jsonString);

// import 'dart:convert';
//
// CartModel cartModelFromJson(String str) => CartModel.fromJson(json.decode(str));
//
// String cartModelToJson(CartModel data) => json.encode(data.toJson());

class CartModel {
  CartModel({
    this.status,
    this.success,
    this.code,
    this.message,
    this.description,
    this.data,
    this.errors,
    this.api,
  });

  int? status;
  bool? success;
  int? code;
  String? message;
  String? description;
  Data? data;
  dynamic errors;
  Api? api;

  factory CartModel.fromJson(Map<String, dynamic> json) => CartModel(
    status: json["status"],
    success: json["success"],
    code: json["code"],
    message: json["message"],
    description: json["description"],
    data: Data.fromJson(json["data"]),
    errors: json["errors"],
    api: Api.fromJson(json["api"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "code": code,
    "message": message,
    "description": description,
    "data": data!.toJson(),
    "errors": errors,
    "api": api!.toJson(),
  };
}

class Api {
  Api({
    this.version,
  });

  String? version;

  factory Api.fromJson(Map<String, dynamic> json) => Api(
    version: json["version"],
  );

  Map<String, dynamic> toJson() => {
    "version": version,
  };
}

class Data {
  Data({
    this.bundle,
    this.nonBundle,
    this.cart,
    this.cartCount,
    required this.cartQtyCount,
    required this.totalPrice,
    this.totalInsPrice,
    this.totalSSCost,
    this.totalSMCost
  });

  List<List<Bundle>>? bundle;
  List<List<NonBundle>>? nonBundle;
  List<Cart>? cart;
  int? cartCount;
  int cartQtyCount;
  double totalPrice;
  double? totalInsPrice;
  double? totalSSCost;
  double? totalSMCost;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    bundle: List<List<Bundle>>.from(json["bundle"].map((x) => List<Bundle>.from(x.map((x) => Bundle.fromJson(x))))),
    nonBundle: List<List<NonBundle>>.from(json["non_bundle"].map((x) => List<NonBundle>.from(x.map((x) => NonBundle.fromJson(x))))),
    cart: List<Cart>.from(json["cart"].map((x) => Cart.fromJson(x))),
    cartCount: json["CART_COUNT"],
    cartQtyCount: json["CART_QTY_COUNT"],
    totalPrice: json["TOTAL_PRICE"] is int
      ? (json['TOTAL_PRICE'] as int).toDouble()
      : json['TOTAL_PRICE'],
    totalInsPrice: json["TOTAL_INS_PRICE"] is int
        ? (json['TOTAL_INS_PRICE'] as int).toDouble()
        : json['TOTAL_INS_PRICE'],
    totalSSCost: json["SS_COST"] is int
        ? (json['SS_COST'] as int).toDouble()
        : json['SS_COST'],
    totalSMCost: json["SM_COST"] is int
        ? (json['SM_COST'] as int).toDouble()
        : json['SM_COST'],
  );

  Map<String, dynamic> toJson() => {
    "bundle": List<dynamic>.from(bundle!.map((x) => List<dynamic>.from(x.map((x) => x.toJson())))),
    "non_bundle": List<dynamic>.from(nonBundle!.map((x) => List<dynamic>.from(x.map((x) => x.toJson())))),
    "cart": List<dynamic>.from(cart!.map((x) => x.toJson())),
    "CART_COUNT": cartCount,
    "CART_QTY_COUNT": cartQtyCount,
    "TOTAL_PRICE": totalPrice,
    "TOTAL_INS_PRICE": totalInsPrice,
    "SS_COST": totalSSCost,
    "SM_COST": totalSMCost,
  };
}

class Bundle {
  Bundle({
    this.fBookingNo,
    this.fInvStockNo,
    this.fBundleNo,
    this.fVariantNo,
    this.totalRegularBundlePrice,
    this.totalRegularPrice,
    this.totalInstallmentPrice,
    this.totalInstallmentBundlePrice,
    this.matchedQty,
    this.bundleQty,
    this.bundleNamePublic,
    this.bundleName,
    this.imagePath,
    this.bundleInvs,
    this.bundleBreakdown,
  });

  int? fBookingNo;
  int? fInvStockNo;
  int? fBundleNo;
  int? fVariantNo;
  double? totalRegularBundlePrice;
  double? totalRegularPrice;
  double? totalInstallmentPrice;
  double? totalInstallmentBundlePrice;
  int? matchedQty;
  int? bundleQty;
  String? bundleNamePublic;
  String? bundleName;
  String? imagePath;
  String? bundleInvs;
  List<BundleBreakdown>? bundleBreakdown;

  factory Bundle.fromJson(Map<String, dynamic> json) => Bundle(
    fBookingNo: json["F_BOOKING_NO"],
    fInvStockNo: json["F_INV_STOCK_NO"],
    fBundleNo: json["F_BUNDLE_NO"],
    fVariantNo: json["F_VARIANT_NO"],
    totalRegularBundlePrice: json["TOTAL_REGULAR_BUNDLE_PRICE"] is int
      ? (json['TOTAL_REGULAR_BUNDLE_PRICE'] as int).toDouble()
      : json['TOTAL_REGULAR_BUNDLE_PRICE'],
    totalRegularPrice: json["TOTAL_REGULAR_PRICE"] is int
      ? (json['TOTAL_REGULAR_PRICE'] as int).toDouble()
      : json['TOTAL_REGULAR_PRICE'],
    totalInstallmentPrice: json["TOTAL_INSTALLMENT_PRICE"] is int
      ? (json['TOTAL_INSTALLMENT_PRICE'] as int).toDouble()
      : json['TOTAL_INSTALLMENT_PRICE'],
    totalInstallmentBundlePrice: json["TOTAL_INSTALLMENT_BUNDLE_PRICE"] is int
      ? (json['TOTAL_INSTALLMENT_BUNDLE_PRICE'] as int).toDouble()
      : json['TOTAL_INSTALLMENT_BUNDLE_PRICE'],
    matchedQty: json["MATCHED_QTY"],
    bundleQty: json["BUNDLE_QTY"],
    bundleNamePublic: json["BUNDLE_NAME_PUBLIC"],
    bundleName: json["BUNDLE_NAME"],
    imagePath: json["IMAGE_PATH"],
    bundleInvs: json["BUNDLE_INVS"],
    bundleBreakdown: List<BundleBreakdown>.from(json["bundle_breakdown"].map((x) => BundleBreakdown.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "F_BOOKING_NO": fBookingNo,
    "F_INV_STOCK_NO": fInvStockNo,
    "F_BUNDLE_NO": fBundleNo,
    "F_VARIANT_NO": fVariantNo,
    "TOTAL_REGULAR_BUNDLE_PRICE": totalRegularBundlePrice,
    "TOTAL_REGULAR_PRICE": totalRegularPrice,
    "TOTAL_INSTALLMENT_PRICE": totalInstallmentPrice,
    "TOTAL_INSTALLMENT_BUNDLE_PRICE": totalInstallmentBundlePrice,
    "MATCHED_QTY": matchedQty,
    "BUNDLE_QTY": bundleQty,
    "BUNDLE_NAME_PUBLIC": bundleNamePublic,
    "BUNDLE_NAME": bundleName,
    "IMAGE_PATH": imagePath,
    "BUNDLE_INVS": bundleInvs,
    "bundle_breakdown": List<dynamic>.from(bundleBreakdown!.map((x) => x.toJson())),
  };
}

class BundleBreakdown {
  BundleBreakdown({
    required this.variantCount,
    this.currentAirFreight,
    this.currentSeaFreight,
    this.currentSsCost,
    this.currentSmCost,
    this.currentRegularPrice,
    this.prdVarinatName,
    this.fPrdVariantNo,
    this.fShippmentNo,
    this.shipmentStatus,
    this.schArrivalDate,
    this.shipmentType,
    this.fInvWarehouseNo,
    this.cartPk,
    this.maxOrder,
    this.isStockOut,
    this.prdVariantImagePath,
    this.url,
    this.stockInfo,
  });

  int variantCount;
  double? currentAirFreight;
  double? currentSeaFreight;
  double? currentSsCost;
  double? currentSmCost;
  double? currentRegularPrice;
  String? prdVarinatName;
  int? fPrdVariantNo;
  int? fShippmentNo;
  int? shipmentStatus;
  String? schArrivalDate;
  String? shipmentType;
  int? fInvWarehouseNo;
  int? cartPk;
  int? maxOrder;
  int? isStockOut;
  String? prdVariantImagePath;
  String? url;
  List<StockInfo>? stockInfo;

  factory BundleBreakdown.fromJson(Map<String, dynamic> json) => BundleBreakdown(
    variantCount: json["VARIANT_COUNT"],
    currentAirFreight: json["CURRENT_AIR_FREIGHT"] is int
      ? (json['CURRENT_AIR_FREIGHT'] as int).toDouble()
      : json['CURRENT_AIR_FREIGHT'],
    currentSeaFreight: json["CURRENT_SEA_FREIGHT"] is int
      ? (json['CURRENT_SEA_FREIGHT'] as int).toDouble()
      : json['CURRENT_SEA_FREIGHT'],
    currentSsCost: json["CURRENT_SS_COST"] is int
      ? (json['CURRENT_SS_COST'] as int).toDouble()
      : json['CURRENT_SS_COST'],
    currentSmCost: json["CURRENT_SM_COST"] is int
      ? (json['CURRENT_SM_COST'] as int).toDouble()
      : json['CURRENT_SM_COST'],
    currentRegularPrice: json["CURRENT_REGULAR_PRICE"] is int
      ? (json['CURRENT_REGULAR_PRICE'] as int).toDouble()
      : json['CURRENT_REGULAR_PRICE'],
    prdVarinatName: json["PRD_VARINAT_NAME"],
    fPrdVariantNo: json["F_PRD_VARIANT_NO"],
    fShippmentNo: json["F_SHIPPMENT_NO"],
    shipmentStatus: json["SHIPMENT_STATUS"],
    schArrivalDate: json["SCH_ARRIVAL_DATE"],
    shipmentType: json["SHIPMENT_TYPE"],
    fInvWarehouseNo: json["F_INV_WAREHOUSE_NO"],
    cartPk: json["CART_PK"],
    maxOrder: json["MAX_ORDER"],
    isStockOut: json["IS_STOCK_OUT"],
    prdVariantImagePath: json["PRD_VARIANT_IMAGE_PATH"],
    url: json["URL"],
    stockInfo: List<StockInfo>.from(json["stock_info"].map((x) => StockInfo.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "VARIANT_COUNT": variantCount,
    "CURRENT_AIR_FREIGHT": currentAirFreight,
    "CURRENT_SEA_FREIGHT": currentSeaFreight,
    "CURRENT_SS_COST": currentSsCost,
    "CURRENT_SM_COST": currentSmCost,
    "CURRENT_REGULAR_PRICE": currentRegularPrice,
    "PRD_VARINAT_NAME": prdVarinatName,
    "F_PRD_VARIANT_NO": fPrdVariantNo,
    "F_SHIPPMENT_NO": fShippmentNo,
    "SHIPMENT_STATUS": shipmentStatus,
    "SCH_ARRIVAL_DATE": schArrivalDate,
    "SHIPMENT_TYPE": shipmentType,
    "F_INV_WAREHOUSE_NO": fInvWarehouseNo,
    "CART_PK": cartPk,
    "MAX_ORDER": maxOrder,
    "IS_STOCK_OUT": isStockOut,
    "PRD_VARIANT_IMAGE_PATH": prdVariantImagePath,
    "URL": url,
    "stock_info": List<dynamic>.from(stockInfo!.map((x) => x.toJson())),
  };
}

class StockInfo {
  StockInfo({
    this.prdVarinatName,
    this.igCode,
    this.invWarehouseName,
    this.fInvWarehouseNo,
    this.skuid,
    this.shipmentType,
    this.fShippmentNo,
    this.fPrdVariantNo,
    this.schArrivalDate,
    this.shipmentStatus,
    this.total,
    this.selected,
    this.groupValue,
  });

  String? prdVarinatName;
  String? igCode;
  String? invWarehouseName;
  int? fInvWarehouseNo;
  String? skuid;
  String? shipmentType;
  int? fShippmentNo;
  int? fPrdVariantNo;
  String? schArrivalDate;
  int? shipmentStatus;
  int? total;
  int? selected;
  String? groupValue;

  factory StockInfo.fromJson(Map<String, dynamic> json) => StockInfo(
    prdVarinatName: json["PRD_VARINAT_NAME"],
    igCode: json["IG_CODE"],
    invWarehouseName: json["INV_WAREHOUSE_NAME"],
    fInvWarehouseNo: json["F_INV_WAREHOUSE_NO"],
    skuid: json["SKUID"],
    shipmentType: json["SHIPMENT_TYPE"] == null ? null : json["SHIPMENT_TYPE"],
    fShippmentNo: json["F_SHIPPMENT_NO"] == null ? null : json["F_SHIPPMENT_NO"],
    fPrdVariantNo: json["F_PRD_VARIANT_NO"],
    schArrivalDate: json["SCH_ARRIVAL_DATE"] == null ? "" : json["SCH_ARRIVAL_DATE"],
    shipmentStatus: json["SHIPMENT_STATUS"] == null ? null : json["SHIPMENT_STATUS"],
    total: json["TOTAL"],
    selected: json["selected"],
    groupValue: json["group_value"],
  );

  Map<String, dynamic> toJson() => {
    "PRD_VARINAT_NAME": prdVarinatName,
    "IG_CODE": igCode,
    "INV_WAREHOUSE_NAME": invWarehouseName,
    "F_INV_WAREHOUSE_NO": fInvWarehouseNo,
    "SKUID": skuid,
    "SHIPMENT_TYPE": shipmentType == null ? null : shipmentType,
    "F_SHIPPMENT_NO": fShippmentNo == null ? null : fShippmentNo,
    "F_PRD_VARIANT_NO": fPrdVariantNo,
    "SCH_ARRIVAL_DATE": schArrivalDate == null ? "" : schArrivalDate,
    "SHIPMENT_STATUS": shipmentStatus == null ? null : shipmentStatus,
    "TOTAL": total,
    "selected": selected,
    "group_value": groupValue,
  };
}

class NonBundle {
  NonBundle({
    this.fBookingNo,
    this.fInvStockNo,
    this.currentRegularPrice,
    this.currentInstallmentPrice,
    this.airFreight,
    this.seaFreight,
    this.isFreight,
    this.ssCost,
    this.smCost,
    this.isSm,
    this.isRegular,
    this.prdVarinatName,
    required this.itemQty,
    this.fPrdVariantNo,
    this.fInvWarehouseNo,
    this.shipmentType,
    this.invWarehouseName,
    this.shipmentStatus,
    this.schArrivalDate,
    this.checkOfferVariant,
    this.cartPk,
    this.maxOrder,
    this.isStockOut,
    this.prdVariantImagePath,
    this.url,
    this.stockInfo,
  });

  int? fBookingNo;
  int? fInvStockNo;
  double? currentRegularPrice;
  double? currentInstallmentPrice;
  double? airFreight;
  double? seaFreight;
  int? isFreight;
  double? ssCost;
  double? smCost;
  dynamic isSm;
  int? isRegular;
  String? prdVarinatName;
  int itemQty;
  int? fPrdVariantNo;
  int? fInvWarehouseNo;
  String? shipmentType;
  String? invWarehouseName;
  int? shipmentStatus;
  String? schArrivalDate;
  CheckOfferVariant? checkOfferVariant;
  int? cartPk;
  int? maxOrder;
  int? isStockOut;
  String? prdVariantImagePath;
  String? url;
  List<StockInfo>? stockInfo;

  factory NonBundle.fromJson(Map<String, dynamic> json) => NonBundle(
    fBookingNo: json["F_BOOKING_NO"],
    fInvStockNo: json["F_INV_STOCK_NO"],
    currentRegularPrice: json["CURRENT_REGULAR_PRICE"] is int
      ? (json['CURRENT_REGULAR_PRICE'] as int).toDouble()
      : json['CURRENT_REGULAR_PRICE'],
    currentInstallmentPrice: json["CURRENT_INSTALLMENT_PRICE"] is int
      ? (json['CURRENT_INSTALLMENT_PRICE'] as int).toDouble()
      : json['CURRENT_INSTALLMENT_PRICE'],
    airFreight: json["AIR_FREIGHT"] is int
      ? (json['AIR_FREIGHT'] as int).toDouble()
      : json['AIR_FREIGHT'],
    seaFreight: json["SEA_FREIGHT"] is int
      ? (json['SEA_FREIGHT'] as int).toDouble()
      : json['SEA_FREIGHT'],
    isFreight: json["IS_FREIGHT"],
    ssCost: json["SS_COST"] is int
      ? (json['SS_COST'] as int).toDouble()
      : json['SS_COST'],
    smCost: json["SM_COST"] is int
      ? (json['SM_COST'] as int).toDouble()
      : json['SM_COST'],
    isSm: json["IS_SM"],
    isRegular: json["IS_REGULAR"],
    prdVarinatName: json["PRD_VARINAT_NAME"],
    itemQty: json["ITEM_QTY"],
    fPrdVariantNo: json["F_PRD_VARIANT_NO"],
    fInvWarehouseNo: json["F_INV_WAREHOUSE_NO"],
    shipmentType: json["SHIPMENT_TYPE"] == null ? null : json["SHIPMENT_TYPE"],
    invWarehouseName: json["INV_WAREHOUSE_NAME"],
    shipmentStatus: json["SHIPMENT_STATUS"] == null ? null : json["SHIPMENT_STATUS"],
    schArrivalDate: json["SCH_ARRIVAL_DATE"] == null ? "" : json["SCH_ARRIVAL_DATE"],
    checkOfferVariant: json["check_offer_variant"] == null ? null : CheckOfferVariant.fromJson(json["check_offer_variant"]),
    cartPk: json["CART_PK"],
    maxOrder: json["MAX_ORDER"],
    isStockOut: json["IS_STOCK_OUT"],
    prdVariantImagePath: json["PRD_VARIANT_IMAGE_PATH"],
    url: json["URL"],
    stockInfo: List<StockInfo>.from(json["stock_info"].map((x) => StockInfo.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "F_BOOKING_NO": fBookingNo,
    "F_INV_STOCK_NO": fInvStockNo,
    "CURRENT_REGULAR_PRICE": currentRegularPrice,
    "CURRENT_INSTALLMENT_PRICE": currentInstallmentPrice,
    "AIR_FREIGHT": airFreight,
    "SEA_FREIGHT": seaFreight,
    "IS_FREIGHT": isFreight,
    "SS_COST": ssCost,
    "SM_COST": smCost,
    "IS_SM": isSm,
    "IS_REGULAR": isRegular,
    "PRD_VARINAT_NAME": prdVarinatName,
    "ITEM_QTY": itemQty,
    "F_PRD_VARIANT_NO": fPrdVariantNo,
    "F_INV_WAREHOUSE_NO": fInvWarehouseNo,
    "SHIPMENT_TYPE": shipmentType == null ? null : shipmentType,
    "INV_WAREHOUSE_NAME": invWarehouseName,
    "SHIPMENT_STATUS": shipmentStatus == null ? null : shipmentStatus,
    "SCH_ARRIVAL_DATE": schArrivalDate == null ? null : schArrivalDate,
    "check_offer_variant": checkOfferVariant == null ? null : checkOfferVariant!.toJson(),
    "CART_PK": cartPk,
    "MAX_ORDER": maxOrder,
    "IS_STOCK_OUT": isStockOut,
    "PRD_VARIANT_IMAGE_PATH": prdVariantImagePath,
    "URL": url,
    "stock_info": List<dynamic>.from(stockInfo!.map((x) => x.toJson())),
  };
}

class CheckOfferVariant {
  CheckOfferVariant({
    this.pkNo,
    this.code,
    this.fSlsBundlePrimarySetNo,
    this.fPrdVariantNo,
    this.prdVariantName,
    this.skuid,
    this.bundleNamePublic,
    this.bundleGroupName,
    this.urlSlug,
  });

  int? pkNo;
  dynamic code;
  int? fSlsBundlePrimarySetNo;
  int? fPrdVariantNo;
  String? prdVariantName;
  String? skuid;
  String? bundleNamePublic;
  String? bundleGroupName;
  String? urlSlug;

  factory CheckOfferVariant.fromJson(Map<String, dynamic> json) => CheckOfferVariant(
    pkNo: json["PK_NO"],
    code: json["CODE"],
    fSlsBundlePrimarySetNo: json["F_SLS_BUNDLE_PRIMARY_SET_NO"],
    fPrdVariantNo: json["F_PRD_VARIANT_NO"],
    prdVariantName: json["PRD_VARIANT_NAME"],
    skuid: json["SKUID"],
    bundleNamePublic: json["BUNDLE_NAME_PUBLIC"],
    bundleGroupName: json["BUNDLE_GROUP_NAME"],
    urlSlug: json["URL_SLUG"],
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "CODE": code,
    "F_SLS_BUNDLE_PRIMARY_SET_NO": fSlsBundlePrimarySetNo,
    "F_PRD_VARIANT_NO": fPrdVariantNo,
    "PRD_VARIANT_NAME": prdVariantName,
    "SKUID": skuid,
    "BUNDLE_NAME_PUBLIC": bundleNamePublic,
    "BUNDLE_GROUP_NAME": bundleGroupName,
    "URL_SLUG": urlSlug,
  };
}

class Cart {
  Cart({
    this.pkNo,
    this.fPrdMasterNo,
    this.fPrdVariantNo,
    this.fCustomerNo,
    this.fWarehouseNo,
    this.fShippmentNo,
    this.sessionId,
    required this.totalItemQty,
    this.regularPrice,
    this.installmentPrice,
    this.isBooking,
    this.isActive,
    this.ssModifiedOn,
    this.ssCreatedOn,
    this.fSsCreatedBy,
    this.fSsModifiedBy,
    this.paymentPlan,
    this.isReseller,
    this.fBookingTempNo,
    this.stockInfo,
    this.products,
    this.bundleNamePublic,
  });

  int? pkNo;
  int? fPrdMasterNo;
  int? fPrdVariantNo;
  int? fCustomerNo;
  int? fWarehouseNo;
  int? fShippmentNo;
  String? sessionId;
  int totalItemQty;
  int? regularPrice;
  int? installmentPrice;
  int? isBooking;
  int? isActive;
  DateTime? ssModifiedOn;
  DateTime? ssCreatedOn;
  dynamic fSsCreatedBy;
  dynamic fSsModifiedBy;
  dynamic paymentPlan;
  int? isReseller;
  int? fBookingTempNo;
  List<StockInfo>? stockInfo;
  Products? products;
  String? bundleNamePublic;

  factory Cart.fromJson(Map<String, dynamic> json) => Cart(
    pkNo: json["PK_NO"],
    fPrdMasterNo: json["F_PRD_MASTER_NO"],
    fPrdVariantNo: json["F_PRD_VARIANT_NO"],
    fCustomerNo: json["F_CUSTOMER_NO"],
    fWarehouseNo: json["F_WAREHOUSE_NO"],
    fShippmentNo: json["F_SHIPPMENT_NO"],
    sessionId: json["SESSION_ID"],
    totalItemQty: json["TOTAL_ITEM_QTY"],
    regularPrice: json["REGULAR_PRICE"],
    installmentPrice: json["INSTALLMENT_PRICE"],
    isBooking: json["IS_BOOKING"],
    isActive: json["IS_ACTIVE"],
    ssModifiedOn: DateTime.parse(json["SS_MODIFIED_ON"]),
    ssCreatedOn: DateTime.parse(json["SS_CREATED_ON"]),
    fSsCreatedBy: json["F_SS_CREATED_BY"],
    fSsModifiedBy: json["F_SS_MODIFIED_BY"],
    paymentPlan: json["PAYMENT_PLAN"],
    isReseller: json["IS_RESELLER"],
    fBookingTempNo: json["F_BOOKING_TEMP_NO"],
    stockInfo: List<StockInfo>.from(json["stock_info"].map((x) => StockInfo.fromJson(x))),
    products: Products.fromJson(json["products"]),
    bundleNamePublic: json["BUNDLE_NAME_PUBLIC"],
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "F_PRD_MASTER_NO": fPrdMasterNo,
    "F_PRD_VARIANT_NO": fPrdVariantNo,
    "F_CUSTOMER_NO": fCustomerNo,
    "F_WAREHOUSE_NO": fWarehouseNo,
    "F_SHIPPMENT_NO": fShippmentNo,
    "SESSION_ID": sessionId,
    "TOTAL_ITEM_QTY": totalItemQty,
    "REGULAR_PRICE": regularPrice,
    "INSTALLMENT_PRICE": installmentPrice,
    "IS_BOOKING": isBooking,
    "IS_ACTIVE": isActive,
    "SS_MODIFIED_ON": ssModifiedOn!.toIso8601String(),
    "SS_CREATED_ON": ssCreatedOn!.toIso8601String(),
    "F_SS_CREATED_BY": fSsCreatedBy,
    "F_SS_MODIFIED_BY": fSsModifiedBy,
    "PAYMENT_PLAN": paymentPlan,
    "IS_RESELLER": isReseller,
    "F_BOOKING_TEMP_NO": fBookingTempNo,
    "stock_info": List<dynamic>.from(stockInfo!.map((x) => x.toJson())),
    "products": products!.toJson(),
    "BUNDLE_NAME_PUBLIC": bundleNamePublic,
  };
}

class Products {
  Products({
    this.pkNo,
    this.fPrdMasterSetupNo,
    this.code,
    this.compositeCode,
    this.variantName,
    this.variantCustomsName,
    this.fSizeNo,
    this.sizeName,
    this.fColorNo,
    this.color,
    this.mktCode,
    this.mrkIdCompositeCode,
    this.hsCode,
    this.barcode,
    this.isBarcodeByMfg,
    this.narration,
    this.fPrimaryImgVariantId,
    this.primaryImgRelativePath,
    this.thumbPath,
    this.regularPrice,
    this.installmentPrice,
    this.seaFreightCharge,
    this.airFreightCharge,
    this.preferredShippingMethod,
    this.localPostage,
    this.interDistrictPostage,
    this.fVatClass,
    this.vatAmountPercent,
    this.isResellerProgramEnabled,
    this.keywordSearch,
    this.comments,
    this.isActive,
    this.addColNumber1,
    this.isApproved,
    this.approvedBy,
    this.approvedOn,
    this.fSsCreatedBy,
    this.ssCreatedOn,
    this.fSsModifiedBy,
    this.ssModifiedOn,
    this.fSsCompanyNo,
    this.webArticle,
    this.urlSlug,
    this.shortNarration,
    this.promotionalMessage,
    this.isFeature,
    this.newArrival,
    this.needApproval,
    this.maxOrder,
    this.metaTitle,
    this.metaKeywards,
    this.metaDescription,
    this.url,
  });

  int? pkNo;
  int? fPrdMasterSetupNo;
  int? code;
  String? compositeCode;
  String? variantName;
  String? variantCustomsName;
  int? fSizeNo;
  String? sizeName;
  int? fColorNo;
  String? color;
  int? mktCode;
  String? mrkIdCompositeCode;
  String? hsCode;
  String? barcode;
  int? isBarcodeByMfg;
  String? narration;
  dynamic fPrimaryImgVariantId;
  String? primaryImgRelativePath;
  String? thumbPath;
  int? regularPrice;
  int? installmentPrice;
  int? seaFreightCharge;
  int? airFreightCharge;
  String? preferredShippingMethod;
  int? localPostage;
  int? interDistrictPostage;
  int? fVatClass;
  int? vatAmountPercent;
  dynamic isResellerProgramEnabled;
  String? keywordSearch;
  String? comments;
  int? isActive;
  int? addColNumber1;
  dynamic isApproved;
  dynamic approvedBy;
  String? approvedOn;
  int? fSsCreatedBy;
  String? ssCreatedOn;
  int? fSsModifiedBy;
  String? ssModifiedOn;
  dynamic fSsCompanyNo;
  dynamic webArticle;
  String? urlSlug;
  dynamic shortNarration;
  dynamic promotionalMessage;
  int? isFeature;
  int? newArrival;
  dynamic needApproval;
  int? maxOrder;
  dynamic metaTitle;
  dynamic metaKeywards;
  dynamic metaDescription;
  String? url;

  factory Products.fromJson(Map<String, dynamic> json) => Products(
    pkNo: json["PK_NO"],
    fPrdMasterSetupNo: json["F_PRD_MASTER_SETUP_NO"],
    code: json["CODE"],
    compositeCode: json["COMPOSITE_CODE"],
    variantName: json["VARIANT_NAME"],
    variantCustomsName: json["VARIANT_CUSTOMS_NAME"],
    fSizeNo: json["F_SIZE_NO"],
    sizeName: json["SIZE_NAME"],
    fColorNo: json["F_COLOR_NO"],
    color: json["COLOR"],
    mktCode: json["MKT_CODE"],
    mrkIdCompositeCode: json["MRK_ID_COMPOSITE_CODE"],
    hsCode: json["HS_CODE"],
    barcode: json["BARCODE"],
    isBarcodeByMfg: json["IS_BARCODE_BY_MFG"],
    narration: json["NARRATION"],
    fPrimaryImgVariantId: json["F_PRIMARY_IMG_VARIANT_ID"],
    primaryImgRelativePath: json["PRIMARY_IMG_RELATIVE_PATH"],
    thumbPath: json["THUMB_PATH"],
    regularPrice: json["REGULAR_PRICE"],
    installmentPrice: json["INSTALLMENT_PRICE"],
    seaFreightCharge: json["SEA_FREIGHT_CHARGE"],
    airFreightCharge: json["AIR_FREIGHT_CHARGE"],
    preferredShippingMethod: json["PREFERRED_SHIPPING_METHOD"],
    localPostage: json["LOCAL_POSTAGE"],
    interDistrictPostage: json["INTER_DISTRICT_POSTAGE"],
    fVatClass: json["F_VAT_CLASS"],
    vatAmountPercent: json["VAT_AMOUNT_PERCENT"],
    isResellerProgramEnabled: json["IS_RESELLER_PROGRAM_ENABLED"],
    keywordSearch: json["KEYWORD_SEARCH"],
    comments: json["COMMENTS"],
    isActive: json["IS_ACTIVE"],
    addColNumber1: json["ADD_COL_NUMBER_1"],
    isApproved: json["IS_APPROVED"],
    approvedBy: json["APPROVED_BY"],
    approvedOn: json["APPROVED_ON"],
    fSsCreatedBy: json["F_SS_CREATED_BY"],
    ssCreatedOn: json["SS_CREATED_ON"],
    fSsModifiedBy: json["F_SS_MODIFIED_BY"],
    ssModifiedOn: json["SS_MODIFIED_ON"],
    fSsCompanyNo: json["F_SS_COMPANY_NO"],
    webArticle: json["WEB_ARTICLE"],
    urlSlug: json["URL_SLUG"],
    shortNarration: json["SHORT_NARRATION"],
    promotionalMessage: json["PROMOTIONAL_MESSAGE"],
    isFeature: json["IS_FEATURE"],
    newArrival: json["NEW_ARRIVAL"],
    needApproval: json["NEED_APPROVAL"],
    maxOrder: json["MAX_ORDER"],
    metaTitle: json["META_TITLE"],
    metaKeywards: json["META_KEYWARDS"],
    metaDescription: json["META_DESCRIPTION"],
    url: json["URL"],
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "F_PRD_MASTER_SETUP_NO": fPrdMasterSetupNo,
    "CODE": code,
    "COMPOSITE_CODE": compositeCode,
    "VARIANT_NAME": variantName,
    "VARIANT_CUSTOMS_NAME": variantCustomsName,
    "F_SIZE_NO": fSizeNo,
    "SIZE_NAME": sizeName,
    "F_COLOR_NO": fColorNo,
    "COLOR": color,
    "MKT_CODE": mktCode,
    "MRK_ID_COMPOSITE_CODE": mrkIdCompositeCode,
    "HS_CODE": hsCode,
    "BARCODE": barcode,
    "IS_BARCODE_BY_MFG": isBarcodeByMfg,
    "NARRATION": narration,
    "F_PRIMARY_IMG_VARIANT_ID": fPrimaryImgVariantId,
    "PRIMARY_IMG_RELATIVE_PATH": primaryImgRelativePath,
    "THUMB_PATH": thumbPath,
    "REGULAR_PRICE": regularPrice,
    "INSTALLMENT_PRICE": installmentPrice,
    "SEA_FREIGHT_CHARGE": seaFreightCharge,
    "AIR_FREIGHT_CHARGE": airFreightCharge,
    "PREFERRED_SHIPPING_METHOD": preferredShippingMethod,
    "LOCAL_POSTAGE": localPostage,
    "INTER_DISTRICT_POSTAGE": interDistrictPostage,
    "F_VAT_CLASS": fVatClass,
    "VAT_AMOUNT_PERCENT": vatAmountPercent,
    "IS_RESELLER_PROGRAM_ENABLED": isResellerProgramEnabled,
    "KEYWORD_SEARCH": keywordSearch,
    "COMMENTS": comments,
    "IS_ACTIVE": isActive,
    "ADD_COL_NUMBER_1": addColNumber1,
    "IS_APPROVED": isApproved,
    "APPROVED_BY": approvedBy,
    "APPROVED_ON": approvedOn,
    "F_SS_CREATED_BY": fSsCreatedBy,
    "SS_CREATED_ON": ssCreatedOn,
    "F_SS_MODIFIED_BY": fSsModifiedBy,
    "SS_MODIFIED_ON": ssModifiedOn,
    "F_SS_COMPANY_NO": fSsCompanyNo,
    "WEB_ARTICLE": webArticle,
    "URL_SLUG": urlSlug,
    "SHORT_NARRATION": shortNarration,
    "PROMOTIONAL_MESSAGE": promotionalMessage,
    "IS_FEATURE": isFeature,
    "NEW_ARRIVAL": newArrival,
    "NEED_APPROVAL": needApproval,
    "MAX_ORDER": maxOrder,
    "META_TITLE": metaTitle,
    "META_KEYWARDS": metaKeywards,
    "META_DESCRIPTION": metaDescription,
    "URL": url,
  };
}
