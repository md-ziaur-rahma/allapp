// To parse this JSON data, do
//
//     final instagramFeedModel = instagramFeedModelFromJson(jsonString);

import 'dart:convert';

InstagramFeedModel instagramFeedModelFromJson(String str) => InstagramFeedModel.fromJson(json.decode(str));

String instagramFeedModelToJson(InstagramFeedModel data) => json.encode(data.toJson());

class InstagramFeedModel {
  InstagramFeedModel({
    this.status,
    this.success,
    this.code,
    this.message,
    this.description,
    this.data,
    this.errors,
    this.api,
  });

  int? status;
  bool? success;
  int? code;
  String? message;
  String? description;
  Data? data;
  dynamic errors;
  Api? api;

  factory InstagramFeedModel.fromJson(Map<String, dynamic> json) => InstagramFeedModel(
    status: json["status"],
    success: json["success"],
    code: json["code"],
    message: json["message"],
    description: json["description"],
    data: Data.fromJson(json["data"]),
    errors: json["errors"],
    api: Api.fromJson(json["api"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "code": code,
    "message": message,
    "description": description,
    "data": data!.toJson(),
    "errors": errors,
    "api": api!.toJson(),
  };
}

class Api {
  Api({
    this.version,
  });

  String? version;

  factory Api.fromJson(Map<String, dynamic> json) => Api(
    version: json["version"],
  );

  Map<String, dynamic> toJson() => {
    "version": version,
  };
}

class Data {
  Data({
    this.azuramart,
    this.azuramartHome,
    this.azuramartReview,
  });

  Azuramart? azuramart;
  Azuramart? azuramartHome;
  Azuramart? azuramartReview;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    azuramart: Azuramart.fromJson(json["azuramart"]),
    azuramartHome: Azuramart.fromJson(json["azuramart_home"]),
    azuramartReview: Azuramart.fromJson(json["azuramart_review"]),
  );

  Map<String, dynamic> toJson() => {
    "azuramart": azuramart!.toJson(),
    "azuramart_home": azuramartHome!.toJson(),
    "azuramart_review": azuramartReview!.toJson(),
  };
}

class Azuramart {
  Azuramart({
    this.data,
    this.paging,
  });

  List<Datum>? data;
  Paging? paging;

  factory Azuramart.fromJson(Map<String, dynamic> json) => Azuramart(
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
    paging: Paging.fromJson(json["paging"]),
  );

  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
    "paging": paging!.toJson(),
  };
}

class Datum {
  Datum({
    this.id,
    this.mediaType,
    this.mediaUrl,
    this.timestamp,
    this.permalink,
    this.caption,
  });

  String? id;
  MediaType? mediaType;
  String? mediaUrl;
  String? timestamp;
  String? permalink;
  String? caption;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    mediaType: mediaTypeValues.map[json["media_type"]],
    mediaUrl: json["media_url"],
    timestamp: json["timestamp"],
    permalink: json["permalink"],
    caption: json["caption"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "media_type": mediaTypeValues.reverse![mediaType!],
    "media_url": mediaUrl,
    "timestamp": timestamp,
    "permalink": permalink,
    "caption": caption,
  };
}

enum MediaType { IMAGE, CAROUSEL_ALBUM }

final mediaTypeValues = EnumValues({
  "CAROUSEL_ALBUM": MediaType.CAROUSEL_ALBUM,
  "IMAGE": MediaType.IMAGE
});

class Paging {
  Paging({
    this.cursors,
    this.next,
  });

  Cursors? cursors;
  String? next;

  factory Paging.fromJson(Map<String, dynamic> json) => Paging(
    cursors: Cursors.fromJson(json["cursors"]),
    next: json["next"],
  );

  Map<String, dynamic> toJson() => {
    "cursors": cursors!.toJson(),
    "next": next,
  };
}

class Cursors {
  Cursors({
    this.before,
    this.after,
  });

  String? before;
  String? after;

  factory Cursors.fromJson(Map<String, dynamic> json) => Cursors(
    before: json["before"],
    after: json["after"],
  );

  Map<String, dynamic> toJson() => {
    "before": before,
    "after": after,
  };
}

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String>? reverseMap;

  EnumValues(this.map);

  Map<T, String>? get reverse {
    if (reverseMap == null) {
      reverseMap = map.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap;
  }
}
