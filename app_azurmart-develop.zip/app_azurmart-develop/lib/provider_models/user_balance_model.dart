import 'dart:convert';

UserBalanceModel userBalanceModelFromJson(String str) => UserBalanceModel.fromJson(json.decode(str));

String userBalanceModelToJson(UserBalanceModel data) => json.encode(data.toJson());

class UserBalanceModel {
  UserBalanceModel({
    this.status,
    this.success,
    this.code,
    this.message,
    this.description,
    this.data,
    this.errors,
    this.api,
  });

  int? status;
  bool? success;
  int? code;
  String? message;
  String? description;
  Data? data;
  dynamic errors;
  Api? api;

  factory UserBalanceModel.fromJson(Map<String, dynamic> json) => UserBalanceModel(
    status: json["status"],
    success: json["success"],
    code: json["code"],
    message: json["message"],
    description: json["description"],
    data: Data.fromJson(json["data"]),
    errors: json["errors"],
    api: Api.fromJson(json["api"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "code": code,
    "message": message,
    "description": description,
    "data": data!.toJson(),
    "errors": errors,
    "api": api!.toJson(),
  };
}

class Api {
  Api({
    this.version,
  });

  String? version;

  factory Api.fromJson(Map<String, dynamic> json) => Api(
    version: json["version"],
  );

  Map<String, dynamic> toJson() => {
    "version": version,
  };
}

class Data {
  Data({
    this.credit,
    this.due,
    this.history,
  });

  double? credit;
  double? due;
  List<History>? history;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    credit: json["credit"] is int
      ? (json['credit'] as int).toDouble()
      : json['credit'],
    due: json["due"] is int
      ? (json['due'] as int).toDouble()
      : json['due'],
    history: List<History>.from(json["history"].map((x) => History.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "credit": credit,
    "due": due,
    "history": List<dynamic>.from(history!.map((x) => x.toJson())),
  };
}

class History {
  History({
    this.orderPkNo,
    this.fCustomerNo,
    this.bookingPkNo,
    this.bookingNo,
    this.orderDate,
    this.orderPrice,
    this.orderDiscount,
    this.orderDue,
    this.penaltyFee,
    this.isCancel,
    this.dateAt,
    this.payPkNo,
    this.paymentNo,
    this.payAmount,
    this.txPkNo,
    this.paymentVerify,
    this.fBookingNoForPaymentType3,
    this.returnPrice,
    this.entryByNo,
    this.entryByName,
    this.entryAt,
    this.orderId,
    this.type,
    this.orderValue,
    this.balance,
  });

  int? orderPkNo;
  int? fCustomerNo;
  int? bookingPkNo;
  int? bookingNo;
  String? orderDate;
  double? orderPrice;
  double? orderDiscount;
  double? orderDue;
  double? penaltyFee;
  int? isCancel;
  String? dateAt;
  int? payPkNo;
  int? paymentNo;
  double? payAmount;
  int? txPkNo;
  int? paymentVerify;
  int? fBookingNoForPaymentType3;
  double? returnPrice;
  int? entryByNo;
  String? entryByName;
  String? entryAt;
  int? orderId;
  String? type;
  double? orderValue;
  double? balance;

  factory History.fromJson(Map<String, dynamic> json) => History(
    orderPkNo: json["ORDER_PK_NO"],
    fCustomerNo: json["F_CUSTOMER_NO"],
    bookingPkNo: json["BOOKING_PK_NO"],
    bookingNo: json["BOOKING_NO"],
    orderDate: json["ORDER_DATE"],
    orderPrice: json["ORDER_PRICE"] is int
      ? (json['ORDER_PRICE'] as int).toDouble()
      : json['ORDER_PRICE'],
    orderDiscount: json["ORDER_DISCOUNT"] is int
      ? (json['ORDER_DISCOUNT'] as int).toDouble()
      : json['ORDER_DISCOUNT'],
    orderDue: json["ORDER_DUE"] is int
      ? (json['ORDER_DUE'] as int).toDouble()
      : json['ORDER_DUE'],
    penaltyFee: json["PENALTY_FEE"] is int
      ? (json['PENALTY_FEE'] as int).toDouble()
      : json['PENALTY_FEE'],
    isCancel: json["IS_CANCEL"],
    dateAt: json["DATE_AT"],
    payPkNo: json["PAY_PK_NO"],
    paymentNo: json["PAYMENT_NO"],
    payAmount: json["PAY_AMOUNT"] is int
      ? (json['PAY_AMOUNT'] as int).toDouble()
      : json['PAY_AMOUNT'],
    txPkNo: json["TX_PK_NO"],
    paymentVerify: json["PAYMENT_VERIFY"],
    fBookingNoForPaymentType3: json["F_BOOKING_NO_FOR_PAYMENT_TYPE3"],
    returnPrice: json["RETURN_PRICE"] is int
      ? (json['RETURN_PRICE'] as int).toDouble()
      : json['RETURN_PRICE'],
    entryByNo: json["ENTRY_BY_NO"],
    entryByName: json["ENTRY_BY_NAME"],
    entryAt: json["ENTRY_AT"],
    orderId: json["ORDER_ID"],
    type: json["TYPE"],
    orderValue: json["ORDER_VALUE"] is int
      ? (json['ORDER_VALUE'] as int).toDouble()
      : json['ORDER_VALUE'],
    balance: json["BALANCE"] is int
      ? (json['BALANCE'] as int).toDouble()
      : json['BALANCE'],
  );

  Map<String, dynamic> toJson() => {
    "ORDER_PK_NO": orderPkNo,
    "F_CUSTOMER_NO": fCustomerNo,
    "BOOKING_PK_NO": bookingPkNo,
    "BOOKING_NO": bookingNo,
    "ORDER_DATE": orderDate,
    "ORDER_PRICE": orderPrice,
    "ORDER_DISCOUNT": orderDiscount,
    "ORDER_DUE": orderDue,
    "PENALTY_FEE": penaltyFee,
    "IS_CANCEL": isCancel,
    "DATE_AT": dateAt,
    "PAY_PK_NO": payPkNo,
    "PAYMENT_NO": paymentNo,
    "PAY_AMOUNT": payAmount,
    "TX_PK_NO": txPkNo,
    "PAYMENT_VERIFY": paymentVerify,
    "F_BOOKING_NO_FOR_PAYMENT_TYPE3": fBookingNoForPaymentType3,
    "RETURN_PRICE": returnPrice,
    "ENTRY_BY_NO": entryByNo,
    "ENTRY_BY_NAME": entryByName,
    "ENTRY_AT": entryAt,
    "ORDER_ID": orderId,
    "TYPE": type,
    "ORDER_VALUE": orderValue,
    "BALANCE": balance,
  };
}
