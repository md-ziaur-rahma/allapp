import 'dart:convert';

GetOrderPaymentModel getOrderPaymentModelFromJson(String str) => GetOrderPaymentModel.fromJson(json.decode(str));

String getOrderPaymentModelToJson(GetOrderPaymentModel data) => json.encode(data.toJson());

class GetOrderPaymentModel {
  GetOrderPaymentModel({
    this.status,
    this.success,
    this.code,
    this.message,
    this.description,
    this.data,
    this.errors,
    this.api,
  });

  int? status;
  bool? success;
  int? code;
  String? message;
  String? description;
  Data? data;
  dynamic errors;
  Api? api;

  factory GetOrderPaymentModel.fromJson(Map<String, dynamic> json) => GetOrderPaymentModel(
    status: json["status"],
    success: json["success"],
    code: json["code"],
    message: json["message"],
    description: json["description"],
    data: Data.fromJson(json["data"]),
    errors: json["errors"],
    api: Api.fromJson(json["api"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "code": code,
    "message": message,
    "description": description,
    "data": data!.toJson(),
    "errors": errors,
    "api": api!.toJson(),
  };
}

class Api {
  Api({
    this.version,
  });

  String? version;

  factory Api.fromJson(Map<String, dynamic> json) => Api(
    version: json["version"],
  );

  Map<String, dynamic> toJson() => {
    "version": version,
  };
}

class Data {
  Data({
    this.due,
    this.bilPay,
    this.url,
    this.msg,
    this.paymentType,
    this.orderValue,
    this.totalPaid,
    this.instPayments,
  });

  double? due;
  int? bilPay;
  String? url;
  String? msg;
  String? paymentType;
  double? orderValue;
  double? totalPaid;
  List<InstPayment>? instPayments;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    due: json["due"] is int
      ? (json['due'] as int).toDouble()
      : json['due'],
    bilPay: json["bil_pay"],
    url: json["url"],
    msg: json["msg"],
    paymentType: json["payment_type"],
    orderValue: json["order_value"] is int
      ? (json['order_value'] as int).toDouble()
      : json['order_value'],
    totalPaid: json["total_paid"] is int
  ? (json['total_paid'] as int).toDouble()
      : json['total_paid'],
    instPayments: json["inst_payments"] != null ? List<InstPayment>.from(json["inst_payments"].map((x) => InstPayment.fromJson(x))) : json["inst_payments"],
  );

  Map<String, dynamic> toJson() => {
    "due": due,
    "bil_pay": bilPay,
    "url": url,
    "msg": msg,
    "payment_type": paymentType,
    "order_value": orderValue,
    "total_paid": totalPaid,
    "inst_payments": List<dynamic>.from(instPayments!.map((x) => x.toJson())),
  };
}

class InstPayment {
  InstPayment({
    this.pkNo,
    this.calculatedInstallmentAmount,
    this.paidInstallmentAmount,
    this.orderGroupId,
    this.fAccCustomerPaymentNo,
    this.fAccResellerPaymentNo,
    this.ssCreatedOn,
    this.ssModifiedOn,
    this.fCustomerNo,
    this.fResellerNo,
    this.isPaid,
    this.installmentCount,
  });

  int? pkNo;
  double? calculatedInstallmentAmount;
  double? paidInstallmentAmount;
  int? orderGroupId;
  int? fAccCustomerPaymentNo;
  int? fAccResellerPaymentNo;
  String? ssCreatedOn;
  String? ssModifiedOn;
  int? fCustomerNo;
  int? fResellerNo;
  int? isPaid;
  int? installmentCount;

  factory InstPayment.fromJson(Map<String, dynamic> json) => InstPayment(
    pkNo: json["PK_NO"],
    calculatedInstallmentAmount: json["CALCULATED_INSTALLMENT_AMOUNT"] is int
      ? (json['CALCULATED_INSTALLMENT_AMOUNT'] as int).toDouble()
      : json['CALCULATED_INSTALLMENT_AMOUNT'],
    paidInstallmentAmount: json["PAID_INSTALLMENT_AMOUNT"] is int
  ? (json['PAID_INSTALLMENT_AMOUNT'] as int).toDouble()
      : json['PAID_INSTALLMENT_AMOUNT'],
    orderGroupId: json["ORDER_GROUP_ID"],
    fAccCustomerPaymentNo: json["F_ACC_CUSTOMER_PAYMENT_NO"],
    fAccResellerPaymentNo: json["F_ACC_RESELLER_PAYMENT_NO"],
    ssCreatedOn: json["SS_CREATED_ON"],
    ssModifiedOn: json["SS_MODIFIED_ON"],
    fCustomerNo: json["F_CUSTOMER_NO"],
    fResellerNo: json["F_RESELLER_NO"],
    isPaid: json["IS_PAID"],
    installmentCount: json["INSTALLMENT_COUNT"],
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "CALCULATED_INSTALLMENT_AMOUNT": calculatedInstallmentAmount,
    "PAID_INSTALLMENT_AMOUNT": paidInstallmentAmount,
    "ORDER_GROUP_ID": orderGroupId,
    "F_ACC_CUSTOMER_PAYMENT_NO": fAccCustomerPaymentNo,
    "F_ACC_RESELLER_PAYMENT_NO": fAccResellerPaymentNo,
    "SS_CREATED_ON": ssCreatedOn,
    "SS_MODIFIED_ON": ssModifiedOn,
    "F_CUSTOMER_NO": fCustomerNo,
    "F_RESELLER_NO": fResellerNo,
    "IS_PAID": isPaid,
    "INSTALLMENT_COUNT": installmentCount,
  };
}
