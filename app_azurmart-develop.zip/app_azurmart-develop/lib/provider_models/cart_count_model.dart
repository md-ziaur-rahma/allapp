class CartCountModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  Data? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  Data? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  CartCountModel({
      int? status, 
      bool? success, 
      int? code, 
      String? message, 
      String? description, 
      Data? data, 
      dynamic errors, 
      Api? api}){
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
}

  CartCountModel.fromJson(dynamic json) {
    _status = json['status'];
    _success = json['success'];
    _code = json['code'];
    _message = json['message'];
    _description = json['description'];
    _data = json['data'] != null ? Data.fromJson(json['data']) : null;
    _errors = json['errors'];
    _api = json['api'] != null ? Api.fromJson(json['api']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['status'] = _status;
    map['success'] = _success;
    map['code'] = _code;
    map['message'] = _message;
    map['description'] = _description;
    if (_data != null) {
      map['data'] = _data!.toJson();
    }
    map['errors'] = _errors;
    if (_api != null) {
      map['api'] = _api!.toJson();
    }
    return map;
  }

}

class Api {
  String? _version;

  String? get version => _version;

  Api({
      String? version}){
    _version = version;
}

  Api.fromJson(dynamic json) {
    _version = json['version'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['version'] = _version;
    return map;
  }

}

class Data {
  int? _cartcount;
  int? _cartqtycount;
  double? _totalprice;

  int? get cartcount => _cartcount;
  int? get cartqtycount => _cartqtycount;
  double? get totalprice => _totalprice;

  Data({
      int? cartcount, 
      int? cartqtycount, 
      double? totalprice}){
    _cartcount = cartcount;
    _cartqtycount = cartqtycount;
    _totalprice = totalprice;
}

  Data.fromJson(dynamic json) {
    _cartcount = json['CART_COUNT'];
    _cartqtycount = json['CART_QTY_COUNT'];
    _totalprice = json["TOTAL_PRICE"] is int
        ? (json['TOTAL_PRICE'] as int).toDouble()
        : json['TOTAL_PRICE'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['CART_COUNT'] = _cartcount;
    map['CART_QTY_COUNT'] = _cartqtycount;
    map['TOTAL_PRICE'] = _totalprice;
    return map;
  }

}