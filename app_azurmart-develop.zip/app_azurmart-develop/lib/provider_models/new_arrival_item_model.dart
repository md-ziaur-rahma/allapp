/// status : 1
/// success : true
/// code : 200
/// message : "Data is available !"
/// description : ""
/// data : [{"PK_NO":3272,"F_PRD_MASTER_SETUP_NO":1120,"VARIANT_NAME":"KATE SPADE PAULINE K2251 - BLACK - US 7","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/1120/prod_23062021_60d27707ebd4e.jpeg","URL_SLUG":"kate-spade-pauline-k2251-black-us-7","TOTAL_FREE_STOCK":10,"PROMOTIONAL_MESSAGE":"fdsf","REGULAR_PRICE":339,"URL":"product/kate-spade-pauline-k2251-black-us-7","RATING":0,"isWish":0,"OFFER":[{"URL":"3-x-le-creuset-mini-cocotte-10cm","NAME":"3 x Le Creuset Mini Cocotte 10cm"},{"URL":"4-x-bordallo-pinheiro-cabbage-bowl-green-17cm","NAME":"4 x BORDALLO PINHEIRO CABBAGE BOWL - GREEN - 17cm"},{"URL":"6-x-bordallo-pinheiro-cabbage-bowl-green-17cm","NAME":"6 x BORDALLO PINHEIRO CABBAGE BOWL - GREEN - 17cm"}]},{"PK_NO":3271,"F_PRD_MASTER_SETUP_NO":1123,"VARIANT_NAME":"CATH KIDSTON CARRYALL - CHRISMAS GUARD - 786836","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/1123/prod_23062021_60d2652583db1.jpg","URL_SLUG":"cath-kidston-carryall-chrismas-guard-786836","TOTAL_FREE_STOCK":3,"PROMOTIONAL_MESSAGE":"fdsfs","REGULAR_PRICE":159,"URL":"product/cath-kidston-carryall-chrismas-guard-786836","RATING":0,"isWish":0,"OFFER":[]},{"PK_NO":3268,"F_PRD_MASTER_SETUP_NO":235,"VARIANT_NAME":"LONGCHAMP LI PLIAGE CLUB L1621619P40 - FUCHSIA - SMALL SHORT HANDLE","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/235/prod_23062021_60d23539cb3e4.jpg","URL_SLUG":"longchamp-li-pliage-club-l1621619p40-fuchsia-small-short-handle","TOTAL_FREE_STOCK":0,"PROMOTIONAL_MESSAGE":"fdsfs","REGULAR_PRICE":449,"URL":"product/longchamp-li-pliage-club-l1621619p40-fuchsia-small-short-handle","RATING":0,"isWish":0,"OFFER":[]},{"PK_NO":3263,"F_PRD_MASTER_SETUP_NO":1122,"VARIANT_NAME":"LONGCHAMP LI PLIAGE CLUB BACKPACK 10053619556 - NAVY - LARGE","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/1122/prod_23062021_60d2169b905ea.jpg","URL_SLUG":"longchamp-li-pliage-club-backpack-10053619556-navy-large","TOTAL_FREE_STOCK":0,"PROMOTIONAL_MESSAGE":"fdsf","REGULAR_PRICE":499,"URL":"product/longchamp-li-pliage-club-backpack-10053619556-navy-large","RATING":0,"isWish":0,"OFFER":[{"URL":"6-x-le-creuset-27cm-dinner-plate","NAME":"6 x Le Creuset 27cm Dinner Plate"},{"URL":"4-x-le-creuset-27cm-dinner-plate","NAME":"4 x Le Creuset 27cm Dinner Plate"}]}]
/// errors : null
/// api : {"version":"1.0"}

class NewArrivalItemModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  List<Data>? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  List<Data>? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  set status(int? value) {
    _status = value;
  }

  NewArrivalItemModel(
      {int? status,
      bool? success,
      int? code,
      String? message,
      String? description,
      List<Data>? data,
      dynamic errors,
      Api? api}) {
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
  }

  NewArrivalItemModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    if (json["data"] != null) {
      _data = [];
      json["data"].forEach((v) {
        _data!.add(Data.fromJson(v));
      });
    }
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.map((v) => v.toJson()).toList();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }

  set success(bool? value) {
    _success = value;
  }

  set code(int? value) {
    _code = value;
  }

  set message(String? value) {
    _message = value;
  }

  set description(String? value) {
    _description = value;
  }

  set data(List<Data>? value) {
    _data = value;
  }

  set errors(dynamic value) {
    _errors = value;
  }

  set api(Api? value) {
    _api = value;
  }
}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;

  Api({String? version}) {
    _version = version;
  }

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }
}

/// PK_NO : 3272
/// F_PRD_MASTER_SETUP_NO : 1120
/// VARIANT_NAME : "KATE SPADE PAULINE K2251 - BLACK - US 7"
/// PRIMARY_IMG_RELATIVE_PATH : "/media/images/products/1120/prod_23062021_60d27707ebd4e.jpeg"
/// URL_SLUG : "kate-spade-pauline-k2251-black-us-7"
/// TOTAL_FREE_STOCK : 10
/// PROMOTIONAL_MESSAGE : "fdsf"
/// REGULAR_PRICE : 339
/// URL : "product/kate-spade-pauline-k2251-black-us-7"
/// RATING : 0
/// isWish : 0
/// OFFER : [{"URL":"3-x-le-creuset-mini-cocotte-10cm","NAME":"3 x Le Creuset Mini Cocotte 10cm"},{"URL":"4-x-bordallo-pinheiro-cabbage-bowl-green-17cm","NAME":"4 x BORDALLO PINHEIRO CABBAGE BOWL - GREEN - 17cm"},{"URL":"6-x-bordallo-pinheiro-cabbage-bowl-green-17cm","NAME":"6 x BORDALLO PINHEIRO CABBAGE BOWL - GREEN - 17cm"}]

class Data {
  int? _pkno;
  int? _fprdmastersetupno;
  String? _variantname;
  String? _primaryimgrelativepath;
  String? _thumbPath;
  String? _urlslug;
  int? _totalfreestock;
  String? _promotionalmessage;
  double? _regularprice;
  String? _url;
  int? _rating;
  int? _isWish;
  int? _offer;

  int? get pkno => _pkno;
  int? get fprdmastersetupno => _fprdmastersetupno;
  String? get variantname => _variantname;
  String? get primaryimgrelativepath => _primaryimgrelativepath;
  String? get urlslug => _urlslug;
  int? get totalfreestock => _totalfreestock;
  String? get promotionalmessage => _promotionalmessage;
  double? get regularprice => _regularprice;
  String? get url => _url;
  int? get rating => _rating;
  int? get isWish => _isWish;
  int? get offer => _offer;
  String? get thumbPath => _thumbPath;

  set thumbPath(String? value) {
    _thumbPath = value;
  }

  set pkno(int? value) {
    _pkno = value;
  }

  Data(
      {int? pkno,
      int? fprdmastersetupno,
      String? variantname,
      String? primaryimgrelativepath,
      String? thumbPath,
      String? urlslug,
      int? totalfreestock,
      String? promotionalmessage,
      double? regularprice,
      String? url,
      int? rating,
      int? isWish,
      int? offer}) {
    _pkno = pkno;
    _fprdmastersetupno = fprdmastersetupno;
    _variantname = variantname;
    _primaryimgrelativepath = primaryimgrelativepath;
    _thumbPath = thumbPath;
    _urlslug = urlslug;
    _totalfreestock = totalfreestock;
    _promotionalmessage = promotionalmessage;
    _regularprice = regularprice;
    _url = url;
    _rating = rating;
    _isWish = isWish;
    _offer = offer;
  }

  Data.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _fprdmastersetupno = json["F_PRD_MASTER_SETUP_NO"];
    _variantname = json["VARIANT_NAME"];
    _primaryimgrelativepath = json["PRIMARY_IMG_RELATIVE_PATH"];
    _thumbPath = json["THUMB_PATH"];
    _urlslug = json["URL_SLUG"];
    _totalfreestock = json["TOTAL_FREE_STOCK"];
    _promotionalmessage = json["PROMOTIONAL_MESSAGE"];
    _regularprice = json["REGULAR_PRICE"] is int
        ? (json['REGULAR_PRICE'] as int).toDouble()
        : json['REGULAR_PRICE'];
    _url = json["URL"];
    _rating = json["RATING"];
    _isWish = json["isWish"];
    _offer = json["OFFER"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["F_PRD_MASTER_SETUP_NO"] = _fprdmastersetupno;
    map["VARIANT_NAME"] = _variantname;
    map["PRIMARY_IMG_RELATIVE_PATH"] = _primaryimgrelativepath;
    map["THUMB_PATH"] = _thumbPath;
    map["URL_SLUG"] = _urlslug;
    map["TOTAL_FREE_STOCK"] = _totalfreestock;
    map["PROMOTIONAL_MESSAGE"] = _promotionalmessage;
    map["REGULAR_PRICE"] = _regularprice;
    map["URL"] = _url;
    map["RATING"] = _rating;
    map["isWish"] = _isWish;
    map["OFFER"] = _offer;
    return map;
  }

  set fprdmastersetupno(int? value) {
    _fprdmastersetupno = value;
  }

  set variantname(String? value) {
    _variantname = value;
  }

  set primaryimgrelativepath(String? value) {
    _primaryimgrelativepath = value;
  }

  set urlslug(String? value) {
    _urlslug = value;
  }

  set totalfreestock(int? value) {
    _totalfreestock = value;
  }

  set promotionalmessage(String? value) {
    _promotionalmessage = value;
  }

  set regularprice(double? value) {
    _regularprice = value;
  }

  set url(String? value) {
    _url = value;
  }

  set rating(int? value) {
    _rating = value;
  }

  set isWish(int? value) {
    _isWish = value;
  }

  set offer(int? value) {
    _offer = value;
  }
}

/// URL : "3-x-le-creuset-mini-cocotte-10cm"
/// NAME : "3 x Le Creuset Mini Cocotte 10cm"

class OFFER {
  String? _url;
  String? _name;

  String? get url => _url;
  String? get name => _name;

  OFFER({String? url, String? name}) {
    _url = url;
    _name = name;
  }

  OFFER.fromJson(dynamic json) {
    _url = json["URL"];
    _name = json["NAME"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["URL"] = _url;
    map["NAME"] = _name;
    return map;
  }
}
