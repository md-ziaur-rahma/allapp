/// status : 1
/// success : true
/// code : 200
/// message : "Data is available !"
/// description : ""
/// data : [{"category_name":"BABY","category_id":7,"category_icon":null,"URL_SLUG":"baby","BANNER_PATH":null,"IS_FEATURE":0,"subcategories":[{"PK_NO":54,"F_PRD_CATEGORY_NO":7,"CODE":105,"COMPOSITE_CODE":"107105","NAME":"BABY ESSENTIALS","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":49,"SS_CREATED_ON":"2021-03-27 09:55:23","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-03-27 09:55:23","F_SS_COMPANY_NO":null,"URL_SLUG":"baby-essentials","ORDER_ID":3,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":null,"TOTAL_VARIANT":1},{"PK_NO":37,"F_PRD_CATEGORY_NO":7,"CODE":101,"COMPOSITE_CODE":"107101","NAME":"BAG","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-30 02:18:44","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-30 02:18:44","F_SS_COMPANY_NO":null,"URL_SLUG":"bag","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":2},{"PK_NO":38,"F_PRD_CATEGORY_NO":7,"CODE":102,"COMPOSITE_CODE":"107102","NAME":"BIN","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-12-04 03:26:55","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-12-04 03:26:55","F_SS_COMPANY_NO":null,"URL_SLUG":"bin","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":1},{"PK_NO":51,"F_PRD_CATEGORY_NO":7,"CODE":103,"COMPOSITE_CODE":"107103","NAME":"BLENDER","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":49,"SS_CREATED_ON":"2021-03-07 08:43:46","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-03-07 08:43:46","F_SS_COMPANY_NO":null,"URL_SLUG":"blender","ORDER_ID":1,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":null,"TOTAL_VARIANT":3},{"PK_NO":53,"F_PRD_CATEGORY_NO":7,"CODE":104,"COMPOSITE_CODE":"107104","NAME":"FEEDING SET","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":49,"SS_CREATED_ON":"2021-03-27 08:40:27","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-03-27 08:40:27","F_SS_COMPANY_NO":null,"URL_SLUG":"feeding-set","ORDER_ID":2,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":null,"TOTAL_VARIANT":1}]},{"category_name":"Clothing","category_id":5,"category_icon":null,"URL_SLUG":"clothing","BANNER_PATH":null,"IS_FEATURE":1,"subcategories":[{"PK_NO":27,"F_PRD_CATEGORY_NO":5,"CODE":107,"COMPOSITE_CODE":"105107","NAME":"Hat / Cap","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:07:51","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:07:51","F_SS_COMPANY_NO":null,"URL_SLUG":"hat-cap","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":24,"F_PRD_CATEGORY_NO":5,"CODE":104,"COMPOSITE_CODE":"105104","NAME":"Polo Shirts","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:06:40","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:06:40","F_SS_COMPANY_NO":null,"URL_SLUG":"polo-shirts","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":26,"F_PRD_CATEGORY_NO":5,"CODE":106,"COMPOSITE_CODE":"105106","NAME":"Scarf","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:07:17","F_SS_MODIFIED_BY":1,"SS_MODIFIED_ON":"2020-11-08 16:09:37","F_SS_COMPANY_NO":null,"URL_SLUG":"scarf","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":22,"F_PRD_CATEGORY_NO":5,"CODE":102,"COMPOSITE_CODE":"105102","NAME":"Shirt / Blouse","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:06:13","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:06:13","F_SS_COMPANY_NO":null,"URL_SLUG":"shirt-blouse","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":28,"F_PRD_CATEGORY_NO":5,"CODE":108,"COMPOSITE_CODE":"105108","NAME":"Shorts","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:08:18","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:08:18","F_SS_COMPANY_NO":null,"URL_SLUG":"shorts","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":25,"F_PRD_CATEGORY_NO":5,"CODE":105,"COMPOSITE_CODE":"105105","NAME":"Sweater","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:07:01","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:07:01","F_SS_COMPANY_NO":null,"URL_SLUG":"sweater","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":1},{"PK_NO":23,"F_PRD_CATEGORY_NO":5,"CODE":103,"COMPOSITE_CODE":"105103","NAME":"T-Shirt","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:06:27","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:06:27","F_SS_COMPANY_NO":null,"URL_SLUG":"t-shirt","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":7},{"PK_NO":21,"F_PRD_CATEGORY_NO":5,"CODE":101,"COMPOSITE_CODE":"105101","NAME":"Trousers","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:05:46","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:05:46","F_SS_COMPANY_NO":null,"URL_SLUG":"trousers","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0}]},{"category_name":"Electrical & Electronics","category_id":4,"category_icon":null,"URL_SLUG":"electrical-electronics","BANNER_PATH":null,"IS_FEATURE":0,"subcategories":[{"PK_NO":19,"F_PRD_CATEGORY_NO":4,"CODE":105,"COMPOSITE_CODE":"104105","NAME":"Accessories","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:04:03","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:04:03","F_SS_COMPANY_NO":null,"URL_SLUG":"accessories","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":18,"F_PRD_CATEGORY_NO":4,"CODE":104,"COMPOSITE_CODE":"104104","NAME":"Computers","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:03:31","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:03:31","F_SS_COMPANY_NO":null,"URL_SLUG":"computers","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":16,"F_PRD_CATEGORY_NO":4,"CODE":102,"COMPOSITE_CODE":"104102","NAME":"Laptop","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:03:08","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:03:08","F_SS_COMPANY_NO":null,"URL_SLUG":"laptop","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":15,"F_PRD_CATEGORY_NO":4,"CODE":101,"COMPOSITE_CODE":"104101","NAME":"Mobile Phone","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:02:39","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:02:39","F_SS_COMPANY_NO":null,"URL_SLUG":"mobile-phone","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":20,"F_PRD_CATEGORY_NO":4,"CODE":106,"COMPOSITE_CODE":"104106","NAME":"Projector","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:04:15","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:04:15","F_SS_COMPANY_NO":null,"URL_SLUG":"projector","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":17,"F_PRD_CATEGORY_NO":4,"CODE":103,"COMPOSITE_CODE":"104103","NAME":"Tab","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 16:03:18","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 16:03:18","F_SS_COMPANY_NO":null,"URL_SLUG":"tab","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0}]},{"category_name":"Fashion & Accessories","category_id":2,"category_icon":null,"URL_SLUG":"fashion-accessories","BANNER_PATH":null,"IS_FEATURE":1,"subcategories":[{"PK_NO":14,"F_PRD_CATEGORY_NO":2,"CODE":107,"COMPOSITE_CODE":"102107","NAME":"Accessories","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 11:35:39","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 11:35:39","F_SS_COMPANY_NO":null,"URL_SLUG":"accessories","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":101},{"PK_NO":42,"F_PRD_CATEGORY_NO":2,"CODE":115,"COMPOSITE_CODE":"102115","NAME":"BACKPACK","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2021-01-01 03:38:03","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-01-01 03:38:03","F_SS_COMPANY_NO":null,"URL_SLUG":"backpack","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":68},{"PK_NO":41,"F_PRD_CATEGORY_NO":2,"CODE":114,"COMPOSITE_CODE":"102114","NAME":"Bangle","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-12-30 19:42:47","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-12-30 19:42:47","F_SS_COMPANY_NO":null,"URL_SLUG":"bangle","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":47,"F_PRD_CATEGORY_NO":2,"CODE":120,"COMPOSITE_CODE":"102120","NAME":"BELT BAG","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2021-01-04 01:17:03","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-01-04 01:17:03","F_SS_COMPANY_NO":null,"URL_SLUG":"belt-bag","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":5},{"PK_NO":13,"F_PRD_CATEGORY_NO":2,"CODE":106,"COMPOSITE_CODE":"102106","NAME":"Belts","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 11:34:52","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 11:34:52","F_SS_COMPANY_NO":null,"URL_SLUG":"belts","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":44,"F_PRD_CATEGORY_NO":2,"CODE":117,"COMPOSITE_CODE":"102117","NAME":"BOOKBAG","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2021-01-02 01:03:31","F_SS_MODIFIED_BY":1,"SS_MODIFIED_ON":"2021-01-02 01:03:49","F_SS_COMPANY_NO":null,"URL_SLUG":"bookbag","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":1},{"PK_NO":50,"F_PRD_CATEGORY_NO":2,"CODE":123,"COMPOSITE_CODE":"102123","NAME":"BUM BAG","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2021-01-15 01:11:10","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-01-15 01:11:10","F_SS_COMPANY_NO":null,"URL_SLUG":"bum-bag","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":8},{"PK_NO":49,"F_PRD_CATEGORY_NO":2,"CODE":122,"COMPOSITE_CODE":"102122","NAME":"CAP","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2021-01-09 04:21:14","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-01-09 04:21:14","F_SS_COMPANY_NO":null,"URL_SLUG":"cap","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":2},{"PK_NO":34,"F_PRD_CATEGORY_NO":2,"CODE":109,"COMPOSITE_CODE":"102109","NAME":"CLUTCH","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-26 03:24:31","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-26 03:24:31","F_SS_COMPANY_NO":null,"URL_SLUG":"clutch","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":16},{"PK_NO":9,"F_PRD_CATEGORY_NO":2,"CODE":102,"COMPOSITE_CODE":"102102","NAME":"Handbags","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 11:15:40","F_SS_MODIFIED_BY":1,"SS_MODIFIED_ON":"2020-11-08 11:17:37","F_SS_COMPANY_NO":null,"URL_SLUG":"handbags","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":303},{"PK_NO":39,"F_PRD_CATEGORY_NO":2,"CODE":112,"COMPOSITE_CODE":"102112","NAME":"HOLIDAY BAG","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-12-14 03:59:46","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-12-14 03:59:46","F_SS_COMPANY_NO":null,"URL_SLUG":"holiday-bag","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":22},{"PK_NO":45,"F_PRD_CATEGORY_NO":2,"CODE":118,"COMPOSITE_CODE":"102118","NAME":"IPHONE CASE","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2021-01-04 00:13:30","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-01-04 00:13:30","F_SS_COMPANY_NO":null,"URL_SLUG":"iphone-case","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":7},{"PK_NO":12,"F_PRD_CATEGORY_NO":2,"CODE":105,"COMPOSITE_CODE":"102105","NAME":"Jewellery","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 11:34:00","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 11:34:00","F_SS_COMPANY_NO":null,"URL_SLUG":"jewellery","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":48,"F_PRD_CATEGORY_NO":2,"CODE":121,"COMPOSITE_CODE":"102121","NAME":"LAPTOP CASE","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2021-01-04 04:56:04","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-01-04 04:56:04","F_SS_COMPANY_NO":null,"URL_SLUG":"laptop-case","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":1},{"PK_NO":36,"F_PRD_CATEGORY_NO":2,"CODE":111,"COMPOSITE_CODE":"102111","NAME":"PIN","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-26 04:12:24","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-26 04:12:24","F_SS_COMPANY_NO":null,"URL_SLUG":"pin","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":1},{"PK_NO":43,"F_PRD_CATEGORY_NO":2,"CODE":116,"COMPOSITE_CODE":"102116","NAME":"POUCH","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2021-01-01 23:44:44","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-01-01 23:44:44","F_SS_COMPANY_NO":null,"URL_SLUG":"pouch","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":15},{"PK_NO":40,"F_PRD_CATEGORY_NO":2,"CODE":113,"COMPOSITE_CODE":"102113","NAME":"SCARF","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-12-17 02:57:21","F_SS_MODIFIED_BY":1,"SS_MODIFIED_ON":"2021-01-18 19:59:13","F_SS_COMPANY_NO":null,"URL_SLUG":"scarf","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":8},{"PK_NO":10,"F_PRD_CATEGORY_NO":2,"CODE":103,"COMPOSITE_CODE":"102103","NAME":"Shoes","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 11:16:54","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 11:16:54","F_SS_COMPANY_NO":null,"URL_SLUG":"shoes","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":128},{"PK_NO":31,"F_PRD_CATEGORY_NO":2,"CODE":108,"COMPOSITE_CODE":"102108","NAME":"Shopper Bag","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-17 03:01:14","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-17 03:01:14","F_SS_COMPANY_NO":null,"URL_SLUG":"shopper-bag","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":2},{"PK_NO":35,"F_PRD_CATEGORY_NO":2,"CODE":110,"COMPOSITE_CODE":"102110","NAME":"TSHIRT","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-26 03:45:05","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-26 03:45:05","F_SS_COMPANY_NO":null,"URL_SLUG":"tshirt","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":28},{"PK_NO":11,"F_PRD_CATEGORY_NO":2,"CODE":104,"COMPOSITE_CODE":"102104","NAME":"Wallets / Purse","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 11:17:29","F_SS_MODIFIED_BY":1,"SS_MODIFIED_ON":"2020-11-08 11:33:18","F_SS_COMPANY_NO":null,"URL_SLUG":"wallets-purse","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":67},{"PK_NO":8,"F_PRD_CATEGORY_NO":2,"CODE":101,"COMPOSITE_CODE":"102101","NAME":"Watches","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 11:14:15","F_SS_MODIFIED_BY":1,"SS_MODIFIED_ON":"2020-11-08 11:17:54","F_SS_COMPANY_NO":null,"URL_SLUG":"watches","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":189},{"PK_NO":46,"F_PRD_CATEGORY_NO":2,"CODE":119,"COMPOSITE_CODE":"102119","NAME":"WRISLET","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2021-01-04 00:50:08","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-01-04 00:50:08","F_SS_COMPANY_NO":null,"URL_SLUG":"wrislet","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":13}]},{"category_name":"Health & Beauty","category_id":3,"category_icon":null,"URL_SLUG":"health-beauty","BANNER_PATH":null,"IS_FEATURE":0,"subcategories":[{"PK_NO":29,"F_PRD_CATEGORY_NO":3,"CODE":101,"COMPOSITE_CODE":"103101","NAME":"Electrical Appliances","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-10 10:20:14","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-10 10:20:14","F_SS_COMPANY_NO":null,"URL_SLUG":"electrical-appliances","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":1}]},{"category_name":"Home & Kitchen","category_id":1,"category_icon":null,"URL_SLUG":"home-kitchen","BANNER_PATH":null,"IS_FEATURE":1,"subcategories":[{"PK_NO":1,"F_PRD_CATEGORY_NO":1,"CODE":101,"COMPOSITE_CODE":"101101","NAME":"Cookware","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-07 21:50:55","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-07 21:50:55","F_SS_COMPANY_NO":null,"URL_SLUG":"cookware","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":301},{"PK_NO":7,"F_PRD_CATEGORY_NO":1,"CODE":107,"COMPOSITE_CODE":"101107","NAME":"DIY & Tools","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 11:03:52","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 11:03:52","F_SS_COMPANY_NO":null,"URL_SLUG":"diy-tools","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":0},{"PK_NO":5,"F_PRD_CATEGORY_NO":1,"CODE":105,"COMPOSITE_CODE":"101105","NAME":"Kitchen Appliances","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 10:46:10","F_SS_MODIFIED_BY":1,"SS_MODIFIED_ON":"2020-11-08 10:46:28","F_SS_COMPANY_NO":null,"URL_SLUG":"kitchen-appliances","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":30},{"PK_NO":30,"F_PRD_CATEGORY_NO":1,"CODE":108,"COMPOSITE_CODE":"101108","NAME":"Kitchen Appliances (Non-electric)","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-10 14:53:55","F_SS_MODIFIED_BY":1,"SS_MODIFIED_ON":"2020-11-10 14:54:40","F_SS_COMPANY_NO":null,"URL_SLUG":"kitchen-appliances-non-electric","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":7},{"PK_NO":3,"F_PRD_CATEGORY_NO":1,"CODE":103,"COMPOSITE_CODE":"101103","NAME":"Kitchen Utensil & Gadgets","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-07 21:52:02","F_SS_MODIFIED_BY":1,"SS_MODIFIED_ON":"2020-11-08 10:48:03","F_SS_COMPANY_NO":null,"URL_SLUG":"kitchen-utensil-gadgets","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":169},{"PK_NO":4,"F_PRD_CATEGORY_NO":1,"CODE":104,"COMPOSITE_CODE":"101104","NAME":"Laundry & Ironing","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-07 22:07:18","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-07 22:07:18","F_SS_COMPANY_NO":null,"URL_SLUG":"laundry-ironing","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":3},{"PK_NO":2,"F_PRD_CATEGORY_NO":1,"CODE":102,"COMPOSITE_CODE":"101102","NAME":"Stoneware","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-07 21:51:25","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-07 21:51:25","F_SS_COMPANY_NO":null,"URL_SLUG":"stoneware","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":373},{"PK_NO":6,"F_PRD_CATEGORY_NO":1,"CODE":106,"COMPOSITE_CODE":"101106","NAME":"Vacuums & Floorcare","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-08 11:03:11","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-08 11:03:11","F_SS_COMPANY_NO":null,"URL_SLUG":"vacuums-floorcare","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":8}]},{"category_name":"Toy","category_id":6,"category_icon":null,"URL_SLUG":"toy","BANNER_PATH":null,"IS_FEATURE":0,"subcategories":[{"PK_NO":32,"F_PRD_CATEGORY_NO":6,"CODE":101,"COMPOSITE_CODE":"106101","NAME":"Battery Operated","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-18 18:46:40","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-18 18:46:40","F_SS_COMPANY_NO":null,"URL_SLUG":"battery-operated","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":1},{"PK_NO":33,"F_PRD_CATEGORY_NO":6,"CODE":102,"COMPOSITE_CODE":"106102","NAME":"Non Battery Operated","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-20 23:34:23","F_SS_MODIFIED_BY":1,"SS_MODIFIED_ON":"2020-11-20 23:39:13","F_SS_COMPANY_NO":null,"URL_SLUG":"non-battery-operated","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":1}]}]
/// errors : null
/// api : {"version":"1.0"}

class Category2 {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  List<Data>? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  List<Data>? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  Category2(
      {int? status,
      bool? success,
      int? code,
      String? message,
      String? description,
      List<Data>? data,
      dynamic errors,
      Api? api}) {
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
  }

  Category2.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    if (json["data"] != null) {
      _data = [];
      json["data"].forEach((v) {
        _data!.add(Data.fromJson(v));
      });
    }
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.map((v) => v.toJson()).toList();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }
}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;

  Api({String? version}) {
    _version = version;
  }

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }
}

/// category_name : "BABY"
/// category_id : 7
/// category_icon : null
/// URL_SLUG : "baby"
/// BANNER_PATH : null
/// IS_FEATURE : 0
/// subcategories : [{"PK_NO":54,"F_PRD_CATEGORY_NO":7,"CODE":105,"COMPOSITE_CODE":"107105","NAME":"BABY ESSENTIALS","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":49,"SS_CREATED_ON":"2021-03-27 09:55:23","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-03-27 09:55:23","F_SS_COMPANY_NO":null,"URL_SLUG":"baby-essentials","ORDER_ID":3,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":null,"TOTAL_VARIANT":1},{"PK_NO":37,"F_PRD_CATEGORY_NO":7,"CODE":101,"COMPOSITE_CODE":"107101","NAME":"BAG","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-30 02:18:44","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-11-30 02:18:44","F_SS_COMPANY_NO":null,"URL_SLUG":"bag","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":2},{"PK_NO":38,"F_PRD_CATEGORY_NO":7,"CODE":102,"COMPOSITE_CODE":"107102","NAME":"BIN","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-12-04 03:26:55","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2020-12-04 03:26:55","F_SS_COMPANY_NO":null,"URL_SLUG":"bin","ORDER_ID":null,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":0,"TOTAL_VARIANT":1},{"PK_NO":51,"F_PRD_CATEGORY_NO":7,"CODE":103,"COMPOSITE_CODE":"107103","NAME":"BLENDER","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":49,"SS_CREATED_ON":"2021-03-07 08:43:46","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-03-07 08:43:46","F_SS_COMPANY_NO":null,"URL_SLUG":"blender","ORDER_ID":1,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":null,"TOTAL_VARIANT":3},{"PK_NO":53,"F_PRD_CATEGORY_NO":7,"CODE":104,"COMPOSITE_CODE":"107104","NAME":"FEEDING SET","HS_PREFIX":null,"COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":null,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":null,"F_SS_CREATED_BY":49,"SS_CREATED_ON":"2021-03-27 08:40:27","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-03-27 08:40:27","F_SS_COMPANY_NO":null,"URL_SLUG":"feeding-set","ORDER_ID":2,"BANNER_PATH":null,"THUMBNAIL_PATH":null,"ICON":null,"META_TITLE":null,"META_KEYWARDS":null,"META_DESCRIPTION":null,"IS_FEATURE":null,"TOTAL_VARIANT":1}]

class Data {
  String? _categoryName;
  int? _categoryId;
  dynamic _categoryIcon;
  String? _urlslug;
  dynamic _bannerpath;
  int? _isfeature;
  String? _thumbnail_path;
  List<Subcategories>? _subcategories;

  String? get categoryName => _categoryName;
  int? get categoryId => _categoryId;
  dynamic get categoryIcon => _categoryIcon;
  String? get urlslug => _urlslug;
  dynamic get bannerpath => _bannerpath;
  int? get isfeature => _isfeature;
  String? get thumbnail_path => _thumbnail_path;
  List<Subcategories>? get subcategories => _subcategories;

  Data(
      {String? categoryName,
      int? categoryId,
      dynamic categoryIcon,
      String? urlslug,
      dynamic bannerpath,
      int? isfeature,
      String? thumbnail_path,
      List<Subcategories>? subcategories}) {
    _categoryName = categoryName;
    _categoryId = categoryId;
    _categoryIcon = categoryIcon;
    _urlslug = urlslug;
    _bannerpath = bannerpath;
    _isfeature = isfeature;
    _thumbnail_path = thumbnail_path;
    _subcategories = subcategories;
  }

  Data.fromJson(dynamic json) {
    _categoryName = json["category_name"];
    _categoryId = json["category_id"];
    _categoryIcon = json["category_icon"];
    _urlslug = json["URL_SLUG"];
    _bannerpath = json["BANNER_PATH"];
    _isfeature = json["IS_FEATURE"];
    _thumbnail_path = json["THUMBNAIL_PATH"];
    if (json["subcategories"] != null) {
      _subcategories = [];
      json["subcategories"].forEach((v) {
        _subcategories!.add(Subcategories.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["category_name"] = _categoryName;
    map["category_id"] = _categoryId;
    map["category_icon"] = _categoryIcon;
    map["URL_SLUG"] = _urlslug;
    map["BANNER_PATH"] = _bannerpath;
    map["IS_FEATURE"] = _isfeature;
    map["THUMBNAIL_PATH"] = _thumbnail_path;
    if (_subcategories != null) {
      map["subcategories"] = _subcategories!.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// PK_NO : 54
/// F_PRD_CATEGORY_NO : 7
/// CODE : 105
/// COMPOSITE_CODE : "107105"
/// NAME : "BABY ESSENTIALS"
/// HS_PREFIX : null
/// COMMENTS : null
/// IS_ACTIVE : 1
/// ADD_COL_NUMBER_1 : null
/// ADD_COL_NUMBER_2 : null
/// ADD_COL_VARCHAR_1 : null
/// ADD_COL_VARCHAR_2 : null
/// F_SS_CREATED_BY : 49
/// SS_CREATED_ON : "2021-03-27 09:55:23"
/// F_SS_MODIFIED_BY : null
/// SS_MODIFIED_ON : "2021-03-27 09:55:23"
/// F_SS_COMPANY_NO : null
/// URL_SLUG : "baby-essentials"
/// ORDER_ID : 3
/// BANNER_PATH : null
/// THUMBNAIL_PATH : null
/// ICON : null
/// META_TITLE : null
/// META_KEYWARDS : null
/// META_DESCRIPTION : null
/// IS_FEATURE : null
/// TOTAL_VARIANT : 1

class Subcategories {
  int? _pkno;
  int? _fprdcategoryno;
  int? _code;
  String? _compositecode;
  String? _name;
  dynamic _hsprefix;
  dynamic _comments;
  int? _isactive;
  dynamic _addcolnumber1;
  dynamic _addcolnumber2;
  dynamic _addcolvarchar1;
  dynamic _addcolvarchar2;
  int? _fsscreatedby;
  String? _sscreatedon;
  dynamic _fssmodifiedby;
  String? _ssmodifiedon;
  dynamic _fsscompanyno;
  String? _urlslug;
  int? _orderid;
  dynamic _bannerpath;
  dynamic _thumbnailpath;
  dynamic _icon;
  dynamic _metatitle;
  dynamic _metakeywards;
  dynamic _metadescription;
  dynamic _isfeature;
  int? _totalvariant;

  int? get pkno => _pkno;
  int? get fprdcategoryno => _fprdcategoryno;
  int? get code => _code;
  String? get compositecode => _compositecode;
  String? get name => _name;
  dynamic get hsprefix => _hsprefix;
  dynamic get comments => _comments;
  int? get isactive => _isactive;
  dynamic get addcolnumber1 => _addcolnumber1;
  dynamic get addcolnumber2 => _addcolnumber2;
  dynamic get addcolvarchar1 => _addcolvarchar1;
  dynamic get addcolvarchar2 => _addcolvarchar2;
  int? get fsscreatedby => _fsscreatedby;
  String? get sscreatedon => _sscreatedon;
  dynamic get fssmodifiedby => _fssmodifiedby;
  String? get ssmodifiedon => _ssmodifiedon;
  dynamic get fsscompanyno => _fsscompanyno;
  String? get urlslug => _urlslug;
  int? get orderid => _orderid;
  dynamic get bannerpath => _bannerpath;
  dynamic get thumbnailpath => _thumbnailpath;
  dynamic get icon => _icon;
  dynamic get metatitle => _metatitle;
  dynamic get metakeywards => _metakeywards;
  dynamic get metadescription => _metadescription;
  dynamic get isfeature => _isfeature;
  int? get totalvariant => _totalvariant;

  Subcategories(
      {int? pkno,
      int? fprdcategoryno,
      int? code,
      String? compositecode,
      String? name,
      dynamic hsprefix,
      dynamic comments,
      int? isactive,
      dynamic addcolnumber1,
      dynamic addcolnumber2,
      dynamic addcolvarchar1,
      dynamic addcolvarchar2,
      int? fsscreatedby,
      String? sscreatedon,
      dynamic fssmodifiedby,
      String? ssmodifiedon,
      dynamic fsscompanyno,
      String? urlslug,
      int? orderid,
      dynamic bannerpath,
      dynamic thumbnailpath,
      dynamic icon,
      dynamic metatitle,
      dynamic metakeywards,
      dynamic metadescription,
      dynamic isfeature,
      int? totalvariant}) {
    _pkno = pkno;
    _fprdcategoryno = fprdcategoryno;
    _code = code;
    _compositecode = compositecode;
    _name = name;
    _hsprefix = hsprefix;
    _comments = comments;
    _isactive = isactive;
    _addcolnumber1 = addcolnumber1;
    _addcolnumber2 = addcolnumber2;
    _addcolvarchar1 = addcolvarchar1;
    _addcolvarchar2 = addcolvarchar2;
    _fsscreatedby = fsscreatedby;
    _sscreatedon = sscreatedon;
    _fssmodifiedby = fssmodifiedby;
    _ssmodifiedon = ssmodifiedon;
    _fsscompanyno = fsscompanyno;
    _urlslug = urlslug;
    _orderid = orderid;
    _bannerpath = bannerpath;
    _thumbnailpath = thumbnailpath;
    _icon = icon;
    _metatitle = metatitle;
    _metakeywards = metakeywards;
    _metadescription = metadescription;
    _isfeature = isfeature;
    _totalvariant = totalvariant;
  }

  Subcategories.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _fprdcategoryno = json["F_PRD_CATEGORY_NO"];
    _code = json["CODE"];
    _compositecode = json["COMPOSITE_CODE"];
    _name = json["NAME"];
    _hsprefix = json["HS_PREFIX"];
    _comments = json["COMMENTS"];
    _isactive = json["IS_ACTIVE"];
    _addcolnumber1 = json["ADD_COL_NUMBER_1"];
    _addcolnumber2 = json["ADD_COL_NUMBER_2"];
    _addcolvarchar1 = json["ADD_COL_VARCHAR_1"];
    _addcolvarchar2 = json["ADD_COL_VARCHAR_2"];
    _fsscreatedby = json["F_SS_CREATED_BY"];
    _sscreatedon = json["SS_CREATED_ON"];
    _fssmodifiedby = json["F_SS_MODIFIED_BY"];
    _ssmodifiedon = json["SS_MODIFIED_ON"];
    _fsscompanyno = json["F_SS_COMPANY_NO"];
    _urlslug = json["URL_SLUG"];
    _orderid = json["ORDER_ID"];
    _bannerpath = json["BANNER_PATH"];
    _thumbnailpath = json["THUMBNAIL_PATH"];
    _icon = json["ICON"];
    _metatitle = json["META_TITLE"];
    _metakeywards = json["META_KEYWARDS"];
    _metadescription = json["META_DESCRIPTION"];
    _isfeature = json["IS_FEATURE"];
    _totalvariant = json["TOTAL_VARIANT"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["F_PRD_CATEGORY_NO"] = _fprdcategoryno;
    map["CODE"] = _code;
    map["COMPOSITE_CODE"] = _compositecode;
    map["NAME"] = _name;
    map["HS_PREFIX"] = _hsprefix;
    map["COMMENTS"] = _comments;
    map["IS_ACTIVE"] = _isactive;
    map["ADD_COL_NUMBER_1"] = _addcolnumber1;
    map["ADD_COL_NUMBER_2"] = _addcolnumber2;
    map["ADD_COL_VARCHAR_1"] = _addcolvarchar1;
    map["ADD_COL_VARCHAR_2"] = _addcolvarchar2;
    map["F_SS_CREATED_BY"] = _fsscreatedby;
    map["SS_CREATED_ON"] = _sscreatedon;
    map["F_SS_MODIFIED_BY"] = _fssmodifiedby;
    map["SS_MODIFIED_ON"] = _ssmodifiedon;
    map["F_SS_COMPANY_NO"] = _fsscompanyno;
    map["URL_SLUG"] = _urlslug;
    map["ORDER_ID"] = _orderid;
    map["BANNER_PATH"] = _bannerpath;
    map["THUMBNAIL_PATH"] = _thumbnailpath;
    map["ICON"] = _icon;
    map["META_TITLE"] = _metatitle;
    map["META_KEYWARDS"] = _metakeywards;
    map["META_DESCRIPTION"] = _metadescription;
    map["IS_FEATURE"] = _isfeature;
    map["TOTAL_VARIANT"] = _totalvariant;
    return map;
  }
}
