/// status : 1
/// success : true
/// code : 200
/// message : "Data is available !"
/// description : ""
/// data : [{"PK_NO":3272,"F_PRD_MASTER_SETUP_NO":1120,"VARIANT_NAME":"KATE SPADE PAULINE K2251 - BLACK - US 7","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/1120/prod_23062021_60d27707ebd4e.jpeg","URL_SLUG":"kate-spade-pauline-k2251-black-us-7","TOTAL_FREE_STOCK":10,"REGULAR_PRICE":339,"URL":"product/kate-spade-pauline-k2251-black-us-7","RATING":0,"isWish":0,"OFFER":1},{"PK_NO":3271,"F_PRD_MASTER_SETUP_NO":1123,"VARIANT_NAME":"CATH KIDSTON CARRYALL - CHRISMAS GUARD - 786836","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/1123/prod_23062021_60d2652583db1.jpg","URL_SLUG":"cath-kidston-carryall-chrismas-guard-786836","TOTAL_FREE_STOCK":3,"REGULAR_PRICE":159,"URL":"product/cath-kidston-carryall-chrismas-guard-786836","RATING":0,"isWish":0,"OFFER":0},{"PK_NO":3269,"F_PRD_MASTER_SETUP_NO":1123,"VARIANT_NAME":"CATH KIDSTON CARRYALL - SQUIGGLE CAT - 813440","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/1123/prod_23062021_60d26360b19ec.jpg","URL_SLUG":"cath-kidston-carryall-squiggle-cat-813440","TOTAL_FREE_STOCK":5,"REGULAR_PRICE":159,"URL":"product/cath-kidston-carryall-squiggle-cat-813440","RATING":0,"isWish":0,"OFFER":0},null]
/// errors : null
/// api : {"version":"1.0"}

class FeatureModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  List<Data>? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  List<Data>? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;


  set status(int? value) {
    _status = value;
  }

  FeatureModel({
      int? status, 
      bool? success, 
      int? code, 
      String? message, 
      String? description, 
      List<Data>? data, 
      dynamic errors, 
      Api? api}){
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
}

  FeatureModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    if (json["data"] != null) {
      _data = [];
      json["data"].forEach((v) {
        _data!.add(Data.fromJson(v));
      });
    }
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.map((v) => v.toJson()).toList();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }

  set success(bool? value) {
    _success = value;
  }

  set code(int? value) {
    _code = value;
  }

  set message(String? value) {
    _message = value;
  }

  set description(String? value) {
    _description = value;
  }

  set data(List<Data>? value) {
    _data = value;
  }

  set errors(dynamic value) {
    _errors = value;
  }

  set api(Api? value) {
    _api = value;
  }
}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;

  Api({
      String? version}){
    _version = version;
}

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }

}

/// PK_NO : 3272
/// F_PRD_MASTER_SETUP_NO : 1120
/// VARIANT_NAME : "KATE SPADE PAULINE K2251 - BLACK - US 7"
/// PRIMARY_IMG_RELATIVE_PATH : "/media/images/products/1120/prod_23062021_60d27707ebd4e.jpeg"
/// URL_SLUG : "kate-spade-pauline-k2251-black-us-7"
/// TOTAL_FREE_STOCK : 10
/// REGULAR_PRICE : 339
/// URL : "product/kate-spade-pauline-k2251-black-us-7"
/// RATING : 0
/// isWish : 0
/// OFFER : 1

class Data {
  int? _pkno;
  int? _fprdmastersetupno;
  String? _variantname;
  String? _primaryimgrelativepath;
  String? _thumbPath;
  String? _urlslug;
  int? _totalfreestock;
  double? _regularprice;
  String? _url;
  int? _rating;
  int? _isWish;
  int? _offer;

  int? get pkno => _pkno;

  String? get thumbPath => _thumbPath;

  set thumbPath(String? value) {
    _thumbPath = value;
  }

  int? get fprdmastersetupno => _fprdmastersetupno;
  String? get variantname => _variantname;
  String? get primaryimgrelativepath => _primaryimgrelativepath;
  String? get urlslug => _urlslug;
  int? get totalfreestock => _totalfreestock;
  double? get regularprice => _regularprice;
  String? get url => _url;
  int? get rating => _rating;
  int? get isWish => _isWish;
  int? get offer => _offer;


  set pkno(int? value) {
    _pkno = value;
  }

  Data({
      int? pkno, 
      int? fprdmastersetupno, 
      String? variantname, 
      String? primaryimgrelativepath,
    String? thumbPath,
      String? urlslug, 
      int? totalfreestock, 
      double? regularprice,
      String? url, 
      int? rating, 
      int? isWish, 
      int? offer}){
    _pkno = pkno;
    _fprdmastersetupno = fprdmastersetupno;
    _variantname = variantname;
    _primaryimgrelativepath = primaryimgrelativepath;
    _thumbPath = thumbPath;
    _urlslug = urlslug;
    _totalfreestock = totalfreestock;
    _regularprice = regularprice;
    _url = url;
    _rating = rating;
    _isWish = isWish;
    _offer = offer;
}

  Data.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _fprdmastersetupno = json["F_PRD_MASTER_SETUP_NO"];
    _variantname = json["VARIANT_NAME"];
    _primaryimgrelativepath = json["PRIMARY_IMG_RELATIVE_PATH"];
    _thumbPath = json["THUMB_PATH"];
    _urlslug = json["URL_SLUG"];
    _totalfreestock = json["TOTAL_FREE_STOCK"];
    _regularprice = json["REGULAR_PRICE"] is int
        ? (json['REGULAR_PRICE'] as int).toDouble()
        : json['REGULAR_PRICE'];
    _url = json["URL"];
    _rating = json["RATING"];
    _isWish = json["isWish"];
    _offer = json["OFFER"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["F_PRD_MASTER_SETUP_NO"] = _fprdmastersetupno;
    map["VARIANT_NAME"] = _variantname;
    map["PRIMARY_IMG_RELATIVE_PATH"] = _primaryimgrelativepath;
    map["THUMB_PATH"] = _thumbPath;
    map["URL_SLUG"] = _urlslug;
    map["TOTAL_FREE_STOCK"] = _totalfreestock;
    map["REGULAR_PRICE"] = _regularprice;
    map["URL"] = _url;
    map["RATING"] = _rating;
    map["isWish"] = _isWish;
    map["OFFER"] = _offer;
    return map;
  }

  set fprdmastersetupno(int? value) {
    _fprdmastersetupno = value;
  }

  set variantname(String? value) {
    _variantname = value;
  }

  set primaryimgrelativepath(String? value) {
    _primaryimgrelativepath = value;
  }

  set urlslug(String? value) {
    _urlslug = value;
  }

  set totalfreestock(int? value) {
    _totalfreestock = value;
  }

  set regularprice(double? value) {
    _regularprice = value;
  }

  set url(String? value) {
    _url = value;
  }

  set rating(int? value) {
    _rating = value;
  }

  set isWish(int? value) {
    _isWish = value;
  }

  set offer(int? value) {
    _offer = value;
  }
}