/// status : 1
/// success : true
/// code : 200
/// message : "Data is available !"
/// description : ""
/// data : {"offer":{"PK_NO":64,"F_A_LIST_NO":48,"F_B_LIST_NO":8,"BUNDLE_NAME_PUBLIC":"Le Creuset Round Classic 28cm + Silver Knob"},"product_a":[{"PK_NO":185,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/32/prod_21112020_5fb904c009268.jpg","REGULAR_PRICE":1199,"URL_SLUG":"lc-classic-round-casserole-ocean-28cm","VARIANT_NAME":"LC Classic Round Casserole - OCEAN - 28cm","STOCK":4,"URL":"product/lc-classic-round-casserole-ocean-28cm","PRODUCT_NAME":"LC CLASSIC ROUND CASSEROLE - OCEAN - 28CM"},{"PK_NO":1376,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/product/prod_07032021_6044303d2502b.jpg","REGULAR_PRICE":1489,"URL_SLUG":"lc-classic-round-casserole-cerise-28cm","VARIANT_NAME":"LC Classic Round Casserole - Cerise - 28cm","STOCK":0,"URL":"product/lc-classic-round-casserole-cerise-28cm","PRODUCT_NAME":"LC CLASSIC ROUND CASSEROLE - CERISE - 28CM"},{"PK_NO":2936,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/32/prod_25052021_60ac02616fc7f.jpg","REGULAR_PRICE":1299,"URL_SLUG":"lc-classic-round-casserole-carribean-28cm","VARIANT_NAME":"LC Classic Round Casserole - CARRIBEAN - 28cm","STOCK":2,"URL":"product/lc-classic-round-casserole-carribean-28cm","PRODUCT_NAME":"LC CLASSIC ROUND CASSEROLE - CARRIBEAN - 28CM"}],"product_b":[{"PK_NO":187,"PRIMARY_IMG_RELATIVE_PATH":null,"REGULAR_PRICE":139,"URL_SLUG":"lc-round-knob-silver-large","VARIANT_NAME":"LC ROUND KNOB - Silver - Large","STOCK":44,"URL":"product/lc-round-knob-silver-large","PRODUCT_NAME":"LC ROUND KNOB - SILVER - LARGE"},{"PK_NO":1738,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/85/prod_24032021_605a7013b5908.jpg","REGULAR_PRICE":139,"URL_SLUG":"lc-round-knob-silver-small","VARIANT_NAME":"LC ROUND KNOB - Silver - SMALL","STOCK":3,"URL":"product/lc-round-knob-silver-small","PRODUCT_NAME":"LC ROUND KNOB - SILVER - SMALL"}]}
/// errors : null
/// api : {"version":"1.0"}

class OfferDetailsModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  Data? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  Data? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  OfferDetailsModel(
      {int? status,
      bool? success,
      int? code,
      String? message,
      String? description,
      Data? data,
      dynamic errors,
      Api? api}) {
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
  }

  OfferDetailsModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    _data = json["data"] != null ? Data.fromJson(json["data"]) : null;
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.toJson();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }
}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;

  Api({String? version}) {
    _version = version;
  }

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }
}

/// offer : {"PK_NO":64,"F_A_LIST_NO":48,"F_B_LIST_NO":8,"BUNDLE_NAME_PUBLIC":"Le Creuset Round Classic 28cm + Silver Knob"}
/// product_a : [{"PK_NO":185,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/32/prod_21112020_5fb904c009268.jpg","REGULAR_PRICE":1199,"URL_SLUG":"lc-classic-round-casserole-ocean-28cm","VARIANT_NAME":"LC Classic Round Casserole - OCEAN - 28cm","STOCK":4,"URL":"product/lc-classic-round-casserole-ocean-28cm","PRODUCT_NAME":"LC CLASSIC ROUND CASSEROLE - OCEAN - 28CM"},{"PK_NO":1376,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/product/prod_07032021_6044303d2502b.jpg","REGULAR_PRICE":1489,"URL_SLUG":"lc-classic-round-casserole-cerise-28cm","VARIANT_NAME":"LC Classic Round Casserole - Cerise - 28cm","STOCK":0,"URL":"product/lc-classic-round-casserole-cerise-28cm","PRODUCT_NAME":"LC CLASSIC ROUND CASSEROLE - CERISE - 28CM"},{"PK_NO":2936,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/32/prod_25052021_60ac02616fc7f.jpg","REGULAR_PRICE":1299,"URL_SLUG":"lc-classic-round-casserole-carribean-28cm","VARIANT_NAME":"LC Classic Round Casserole - CARRIBEAN - 28cm","STOCK":2,"URL":"product/lc-classic-round-casserole-carribean-28cm","PRODUCT_NAME":"LC CLASSIC ROUND CASSEROLE - CARRIBEAN - 28CM"}]
/// product_b : [{"PK_NO":187,"PRIMARY_IMG_RELATIVE_PATH":null,"REGULAR_PRICE":139,"URL_SLUG":"lc-round-knob-silver-large","VARIANT_NAME":"LC ROUND KNOB - Silver - Large","STOCK":44,"URL":"product/lc-round-knob-silver-large","PRODUCT_NAME":"LC ROUND KNOB - SILVER - LARGE"},{"PK_NO":1738,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/85/prod_24032021_605a7013b5908.jpg","REGULAR_PRICE":139,"URL_SLUG":"lc-round-knob-silver-small","VARIANT_NAME":"LC ROUND KNOB - Silver - SMALL","STOCK":3,"URL":"product/lc-round-knob-silver-small","PRODUCT_NAME":"LC ROUND KNOB - SILVER - SMALL"}]

class Data {
  List<Offer>? _offer;
  List<Product_a>? _productA;
  List<Product_b>? _productB;

  List<Offer>? get offer => _offer;
  List<Product_a>? get productA => _productA;
  List<Product_b>? get productB => _productB;

  Data(
      {List<Offer>? offer, List<Product_a>? productA, List<Product_b>? productB}) {
    _offer = offer;
    _productA = productA;
    _productB = productB;
  }

  Data.fromJson(dynamic json) {
    if (json["offers"] != null) {
      _offer = [];
      json["offers"].forEach((v) {
        _offer!.add(Offer.fromJson(v));
      });
    }
    if (json["product_a"] != null) {
      _productA = [];
      json["product_a"].forEach((v) {
        _productA!.add(Product_a.fromJson(v));
      });
    }
    if (json["product_b"] != null) {
      _productB = [];
      json["product_b"].forEach((v) {
        _productB!.add(Product_b.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_offer != null) {
      map["offers"] = _offer!.map((v) => v.toJson()).toList();
    }
    if (_productA != null) {
      map["product_a"] = _productA!.map((v) => v.toJson()).toList();
    }
    if (_productB != null) {
      map["product_b"] = _productB!.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// PK_NO : 187
/// PRIMARY_IMG_RELATIVE_PATH : null
/// REGULAR_PRICE : 139
/// URL_SLUG : "lc-round-knob-silver-large"
/// VARIANT_NAME : "LC ROUND KNOB - Silver - Large"
/// STOCK : 44
/// URL : "product/lc-round-knob-silver-large"
/// PRODUCT_NAME : "LC ROUND KNOB - SILVER - LARGE"

class Product_b {
  int? _pkno;
  dynamic _primaryimgrelativepath;
  double? _regularprice;
  String? _urlslug;
  String? _variantname;
  int? _stock;
  String? _url;
  String? _productname;

  int? get pkno => _pkno;
  dynamic get primaryimgrelativepath => _primaryimgrelativepath;
  double? get regularprice => _regularprice;
  String? get urlslug => _urlslug;
  String? get variantname => _variantname;
  int? get stock => _stock;
  String? get url => _url;
  String? get productname => _productname;

  Product_b(
      {int? pkno,
      dynamic primaryimgrelativepath,
      double? regularprice,
      String? urlslug,
      String? variantname,
      int? stock,
      String? url,
      String? productname}) {
    _pkno = pkno;
    _primaryimgrelativepath = primaryimgrelativepath;
    _regularprice = regularprice;
    _urlslug = urlslug;
    _variantname = variantname;
    _stock = stock;
    _url = url;
    _productname = productname;
  }

  Product_b.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _primaryimgrelativepath = json["PRIMARY_IMG_RELATIVE_PATH"];
    _regularprice = json["REGULAR_PRICE"] is int
        ? (json['REGULAR_PRICE'] as int).toDouble()
        : json['REGULAR_PRICE'];
    _urlslug = json["URL_SLUG"];
    _variantname = json["VARIANT_NAME"];
    _stock = json["STOCK"];
    _url = json["URL"];
    _productname = json["PRODUCT_NAME"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["PRIMARY_IMG_RELATIVE_PATH"] = _primaryimgrelativepath;
    map["REGULAR_PRICE"] = _regularprice;
    map["URL_SLUG"] = _urlslug;
    map["VARIANT_NAME"] = _variantname;
    map["STOCK"] = _stock;
    map["URL"] = _url;
    map["PRODUCT_NAME"] = _productname;
    return map;
  }
}

/// PK_NO : 185
/// PRIMARY_IMG_RELATIVE_PATH : "/media/images/products/32/prod_21112020_5fb904c009268.jpg"
/// REGULAR_PRICE : 1199
/// URL_SLUG : "lc-classic-round-casserole-ocean-28cm"
/// VARIANT_NAME : "LC Classic Round Casserole - OCEAN - 28cm"
/// STOCK : 4
/// URL : "product/lc-classic-round-casserole-ocean-28cm"
/// PRODUCT_NAME : "LC CLASSIC ROUND CASSEROLE - OCEAN - 28CM"

class Product_a {
  int? _pkno;
  String? _primaryimgrelativepath;
  String? _thumbPath;
  double? _regularprice;
  String? _urlslug;
  String? _variantname;
  int? _stock;
  String? _url;
  String? _productname;

  int? get pkno => _pkno;
  String? get primaryimgrelativepath => _primaryimgrelativepath;
  double? get regularprice => _regularprice;
  String? get urlslug => _urlslug;
  String? get variantname => _variantname;
  int? get stock => _stock;
  String? get url => _url;
  String? get productname => _productname;
  String? get thumbPath => _thumbPath;

  set thumbPath(String? value) {
    _thumbPath = value;
  }

  Product_a(
      {int? pkno,
      String? primaryimgrelativepath,
      String? thumbPath,
      double? regularprice,
      String? urlslug,
      String? variantname,
      int? stock,
      String? url,
      String? productname}) {
    _pkno = pkno;
    _primaryimgrelativepath = primaryimgrelativepath;
    _thumbPath = thumbPath;
    _regularprice = regularprice;
    _urlslug = urlslug;
    _variantname = variantname;
    _stock = stock;
    _url = url;
    _productname = productname;
  }

  Product_a.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _primaryimgrelativepath = json["PRIMARY_IMG_RELATIVE_PATH"];
    _thumbPath = json["THUMB_PATH"];
    _regularprice = json["REGULAR_PRICE"] is int
        ? (json['REGULAR_PRICE'] as int).toDouble()
        : json['REGULAR_PRICE'];
    _urlslug = json["URL_SLUG"];
    _variantname = json["VARIANT_NAME"];
    _stock = json["STOCK"];
    _url = json["URL"];
    _productname = json["PRODUCT_NAME"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["PRIMARY_IMG_RELATIVE_PATH"] = _primaryimgrelativepath;
    map["THUMB_PATH"] = _thumbPath;
    map["REGULAR_PRICE"] = _regularprice;
    map["URL_SLUG"] = _urlslug;
    map["VARIANT_NAME"] = _variantname;
    map["STOCK"] = _stock;
    map["URL"] = _url;
    map["PRODUCT_NAME"] = _productname;
    return map;
  }
}

/// PK_NO : 64
/// F_A_LIST_NO : 48
/// F_B_LIST_NO : 8
/// BUNDLE_NAME_PUBLIC : "Le Creuset Round Classic 28cm + Silver Knob"

class Offer {
  int? _pkno;
  int? _falistno;
  int? _fblistno;
  String? _bundlenamepublic;

  int? get pkno => _pkno;
  int? get falistno => _falistno;
  int? get fblistno => _fblistno;
  String? get bundlenamepublic => _bundlenamepublic;

  Offer({int? pkno, int? falistno, int? fblistno, String? bundlenamepublic}) {
    _pkno = pkno;
    _falistno = falistno;
    _fblistno = fblistno;
    _bundlenamepublic = bundlenamepublic;
  }

  Offer.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _falistno = json["F_A_LIST_NO"];
    _fblistno = json["F_B_LIST_NO"];
    _bundlenamepublic = json["BUNDLE_NAME_PUBLIC"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["F_A_LIST_NO"] = _falistno;
    map["F_B_LIST_NO"] = _fblistno;
    map["BUNDLE_NAME_PUBLIC"] = _bundlenamepublic;
    return map;
  }
}
