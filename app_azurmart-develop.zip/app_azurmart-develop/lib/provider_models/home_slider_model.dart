/// status : 1
/// success : true
/// code : 200
/// message : "Data is available !"
/// description : ""
/// data : [{"PK_NO":18,"TITLE":"SLIDER 1","SUBTITLE":"slider 1","BANNER":"media/images/banner/prod_10042021_607162555b3da.jpg","IMAGE_NAME":"prod_10042021_607162555b3da.jpg","URL_LINK":"#!","ORDER_BY":1,"IS_FEATURE":1,"IS_ACTIVE":1,"CREATED_BY":1,"CREATED_ON":"2021-04-10 12:52:23","MODIFIED_BY":1,"MODIFIED_ON":"2021-04-10 02:31:17"},{"PK_NO":19,"TITLE":"SLIDER 2","SUBTITLE":"slider 2","BANNER":"media/images/banner/prod_10042021_6071624e64e8c.jpg","IMAGE_NAME":"prod_10042021_6071624e64e8c.jpg","URL_LINK":"#!","ORDER_BY":2,"IS_FEATURE":1,"IS_ACTIVE":1,"CREATED_BY":1,"CREATED_ON":"2021-04-10 12:53:22","MODIFIED_BY":1,"MODIFIED_ON":"2021-04-10 02:31:10"}]
/// errors : null
/// api : {"version":"1.0"}

class HomeSliderModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  List<Data>? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  List<Data>? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  HomeSliderModel({
      int? status, 
      bool? success, 
      int? code, 
      String? message, 
      String? description, 
      List<Data>? data, 
      dynamic errors, 
      Api? api}){
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
}

  HomeSliderModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    if (json["data"] != null) {
      _data = [];
      json["data"].forEach((v) {
        _data!.add(Data.fromJson(v));
      });
    }
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.map((v) => v.toJson()).toList();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }

}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;

  Api({
      String? version}){
    _version = version;
}

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }

}

/// PK_NO : 18
/// TITLE : "SLIDER 1"
/// SUBTITLE : "slider 1"
/// BANNER : "media/images/banner/prod_10042021_607162555b3da.jpg"
/// IMAGE_NAME : "prod_10042021_607162555b3da.jpg"
/// URL_LINK : "#!"
/// ORDER_BY : 1
/// IS_FEATURE : 1
/// IS_ACTIVE : 1
/// CREATED_BY : 1
/// CREATED_ON : "2021-04-10 12:52:23"
/// MODIFIED_BY : 1
/// MODIFIED_ON : "2021-04-10 02:31:17"

class Data {
  int? _pkno;
  String? _title;
  String? _subtitle;
  String? _banner;
  String? _imagename;
  String? _urllink;
  int? _orderby;
  int? _isfeature;
  int? _isactive;
  int? _createdby;
  String? _createdon;
  int? _modifiedby;
  String? _modifiedon;

  int? get pkno => _pkno;
  String? get title => _title;
  String? get subtitle => _subtitle;
  String? get banner => _banner;
  String? get imagename => _imagename;
  String? get urllink => _urllink;
  int? get orderby => _orderby;
  int? get isfeature => _isfeature;
  int? get isactive => _isactive;
  int? get createdby => _createdby;
  String? get createdon => _createdon;
  int? get modifiedby => _modifiedby;
  String? get modifiedon => _modifiedon;

  Data({
      int? pkno, 
      String? title, 
      String? subtitle, 
      String? banner, 
      String? imagename, 
      String? urllink, 
      int? orderby, 
      int? isfeature, 
      int? isactive, 
      int? createdby, 
      String? createdon, 
      int? modifiedby, 
      String? modifiedon}){
    _pkno = pkno;
    _title = title;
    _subtitle = subtitle;
    _banner = banner;
    _imagename = imagename;
    _urllink = urllink;
    _orderby = orderby;
    _isfeature = isfeature;
    _isactive = isactive;
    _createdby = createdby;
    _createdon = createdon;
    _modifiedby = modifiedby;
    _modifiedon = modifiedon;
}

  Data.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _title = json["TITLE"];
    _subtitle = json["SUBTITLE"];
    _banner = json["BANNER"];
    _imagename = json["IMAGE_NAME"];
    _urllink = json["URL_LINK"];
    _orderby = json["ORDER_BY"];
    _isfeature = json["IS_FEATURE"];
    _isactive = json["IS_ACTIVE"];
    _createdby = json["CREATED_BY"];
    _createdon = json["CREATED_ON"];
    _modifiedby = json["MODIFIED_BY"];
    _modifiedon = json["MODIFIED_ON"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["TITLE"] = _title;
    map["SUBTITLE"] = _subtitle;
    map["BANNER"] = _banner;
    map["IMAGE_NAME"] = _imagename;
    map["URL_LINK"] = _urllink;
    map["ORDER_BY"] = _orderby;
    map["IS_FEATURE"] = _isfeature;
    map["IS_ACTIVE"] = _isactive;
    map["CREATED_BY"] = _createdby;
    map["CREATED_ON"] = _createdon;
    map["MODIFIED_BY"] = _modifiedby;
    map["MODIFIED_ON"] = _modifiedon;
    return map;
  }

}