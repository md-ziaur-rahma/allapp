/// status : 1
/// success : true
/// code : 200
/// message : "Data is available !"
/// description : ""
/// data : [{"PK_NO":7,"NAME":"AQILAH","PHONE_NUMBER":"0123456789","DESIGNATION":"Customer Service","DEFAULT_MSG":"Hi, I have some questions about sales, can you please help me?","PHOTO":"/media/images/profile/avatar-60e062129b748-60e9711fc1767.webp"},{"PK_NO":1,"NAME":"HUDA","PHONE_NUMBER":"+8801711103662","DESIGNATION":"SALES AGENT","DEFAULT_MSG":"Hi, I have some questions about sales, can you please help me?","PHOTO":"/media/image/logo/avatar-60e06346f1790.webp"},{"PK_NO":2,"NAME":"MIRA","PHONE_NUMBER":"+60 11-2905 337","DESIGNATION":"SALES AGENT","DEFAULT_MSG":"Hi, I have some questions about sales, can you please help me?","PHOTO":"/media/images/profile/avatar-60e06346f1790-60e9712c839d9.webp"},{"PK_NO":3,"NAME":"SYARIFA","PHONE_NUMBER":"+60 10-405 4788","DESIGNATION":"CEO","DEFAULT_MSG":"Hi, I have some questions about sales, can you please help me?","PHOTO":"/media/images/profile/sharif-60e971717b7f3.webp"},{"PK_NO":4,"NAME":"AZURA","PHONE_NUMBER":"+44 7983 283981","DESIGNATION":"CEO","DEFAULT_MSG":"Hi, I have some questions about sales, can you please help me?","PHOTO":"/media/images/profile/sharif-60e9717b3715a.webp"}]
/// errors : null
/// api : {"version":"1.0"}

class WhatsappModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  List<Data>? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  List<Data>? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;


  set status(int? value) {
    _status = value;
  }

  WhatsappModel({
      int? status, 
      bool? success, 
      int? code, 
      String? message, 
      String? description, 
      List<Data>? data, 
      dynamic errors, 
      Api? api}){
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
}

  WhatsappModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    if (json["data"] != null) {
      _data = [];
      json["data"].forEach((v) {
        _data!.add(Data.fromJson(v));
      });
    }
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.map((v) => v.toJson()).toList();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }

  set success(bool? value) {
    _success = value;
  }

  set code(int? value) {
    _code = value;
  }

  set message(String? value) {
    _message = value;
  }

  set description(String? value) {
    _description = value;
  }

  set data(List<Data>? value) {
    _data = value;
  }

  set errors(dynamic value) {
    _errors = value;
  }

  set api(Api? value) {
    _api = value;
  }
}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;


  set version(String? value) {
    _version = value;
  }

  Api({
      String? version}){
    _version = version;
}

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }

}

/// PK_NO : 7
/// NAME : "AQILAH"
/// PHONE_NUMBER : "0123456789"
/// DESIGNATION : "Customer Service"
/// DEFAULT_MSG : "Hi, I have some questions about sales, can you please help me?"
/// PHOTO : "/media/images/profile/avatar-60e062129b748-60e9711fc1767.webp"

class Data {
  int? _pkno;
  String? _name;
  String? _phonenumber;
  String? _designation;
  String? _defaultmsg;
  String? _photo;

  int? get pkno => _pkno;
  String? get name => _name;
  String? get phonenumber => _phonenumber;
  String? get designation => _designation;
  String? get defaultmsg => _defaultmsg;
  String? get photo => _photo;


  set pkno(int? value) {
    _pkno = value;
  }

  Data({
      int? pkno, 
      String? name, 
      String? phonenumber, 
      String? designation, 
      String? defaultmsg, 
      String? photo}){
    _pkno = pkno;
    _name = name;
    _phonenumber = phonenumber;
    _designation = designation;
    _defaultmsg = defaultmsg;
    _photo = photo;
}

  Data.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _name = json["NAME"];
    _phonenumber = json["PHONE_NUMBER"];
    _designation = json["DESIGNATION"];
    _defaultmsg = json["DEFAULT_MSG"] ?? "";
    _photo = json["PHOTO"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["NAME"] = _name;
    map["PHONE_NUMBER"] = _phonenumber;
    map["DESIGNATION"] = _designation;
    map["DEFAULT_MSG"] = _defaultmsg ?? "";
    map["PHOTO"] = _photo;
    return map;
  }

  set name(String? value) {
    _name = value;
  }

  set phonenumber(String? value) {
    _phonenumber = value;
  }

  set designation(String? value) {
    _designation = value;
  }

  set defaultmsg(String? value) {
    _defaultmsg = value;
  }

  set photo(String? value) {
    _photo = value;
  }
}