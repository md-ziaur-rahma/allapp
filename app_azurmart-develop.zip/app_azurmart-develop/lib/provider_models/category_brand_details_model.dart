
class CategoryBrandDetailsModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  Data? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  Data? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  CategoryBrandDetailsModel({
      int? status, 
      bool? success, 
      int? code, 
      String? message, 
      String? description, 
      Data? data, 
      dynamic errors, 
      Api? api}){
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
}

  CategoryBrandDetailsModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    _data = json["data"] != null ? Data.fromJson(json["data"]) : null;
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.toJson();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }

}

class Api {
  String? _version;

  String? get version => _version;

  Api({
    String? version}) {
    _version = version;
  }

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }

}
class Data {
  List<Sub_cat>? _subCat;
  List<Brands>? _brands;

  List<Sub_cat>? get subCat => _subCat;
  List<Brands>? get brands => _brands;

  Data({
      List<Sub_cat>? subCat, 
      List<Brands>? brands}){
    _subCat = subCat;
    _brands = brands;
}

  Data.fromJson(dynamic json) {
    if (json["sub_cat"] != null) {
      _subCat = [];
      json["sub_cat"].forEach((v) {
        _subCat!.add(Sub_cat.fromJson(v));
      });
    }
    if (json["brands"] != null) {
      _brands = [];
      json["brands"].forEach((v) {
        _brands!.add(Brands.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_subCat != null) {
      map["sub_cat"] = _subCat!.map((v) => v.toJson()).toList();
    }
    if (_brands != null) {
      map["brands"] = _brands!.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

class Brands {
  int? _pkno;
  String? _name;
  String? _brandlogo;

  int? get pkno => _pkno;
  String? get name => _name;
  String? get brandlogo => _brandlogo;

  Brands({
      int? pkno, 
      String? name, 
      String? brandlogo}){
    _pkno = pkno;
    _name = name;
    _brandlogo = brandlogo;
}

  Brands.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _name = json["NAME"];
    _brandlogo = json["BRAND_LOGO"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["NAME"] = _name;
    map["BRAND_LOGO"] = _brandlogo;
    return map;
  }

}

class Sub_cat {
  int? _pkno;
  int? _fprdcategoryno;
  String? _name;
  String? _urlslug;
  dynamic _thumbnailpath;
  dynamic _bannerpath;
  dynamic _icon;
  int? _totalvariant;

  int? get pkno => _pkno;
  int? get fprdcategoryno => _fprdcategoryno;
  String? get name => _name;
  String? get urlslug => _urlslug;
  dynamic get thumbnailpath => _thumbnailpath;
  dynamic get bannerpath => _bannerpath;
  dynamic get icon => _icon;
  int? get totalvariant => _totalvariant;

  Sub_cat({
      int? pkno, 
      int? fprdcategoryno, 
      String? name, 
      String? urlslug, 
      dynamic thumbnailpath, 
      dynamic bannerpath, 
      dynamic icon, 
      int? totalvariant}){
    _pkno = pkno;
    _fprdcategoryno = fprdcategoryno;
    _name = name;
    _urlslug = urlslug;
    _thumbnailpath = thumbnailpath;
    _bannerpath = bannerpath;
    _icon = icon;
    _totalvariant = totalvariant;
}

  Sub_cat.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _fprdcategoryno = json["F_PRD_CATEGORY_NO"];
    _name = json["NAME"];
    _urlslug = json["URL_SLUG"];
    _thumbnailpath = json["THUMBNAIL_PATH"];
    _bannerpath = json["BANNER_PATH"];
    _icon = json["ICON"];
    _totalvariant = json["TOTAL_VARIANT"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["F_PRD_CATEGORY_NO"] = _fprdcategoryno;
    map["NAME"] = _name;
    map["URL_SLUG"] = _urlslug;
    map["THUMBNAIL_PATH"] = _thumbnailpath;
    map["BANNER_PATH"] = _bannerpath;
    map["ICON"] = _icon;
    map["TOTAL_VARIANT"] = _totalvariant;
    return map;
  }

}