// To parse this JSON data, do
//
//     final couponProductModel = couponProductModelFromJson(jsonString);

import 'dart:convert';

CouponProductModel couponProductModelFromJson(String str) => CouponProductModel.fromJson(json.decode(str));

String couponProductModelToJson(CouponProductModel data) => json.encode(data.toJson());

class CouponProductModel {
  CouponProductModel({
    this.status,
    this.success,
    this.code,
    this.message,
    this.description,
    this.data,
    this.errors,
    this.api,
  });

  int? status;
  bool? success;
  int? code;
  String? message;
  String? description;
  List<Data>? data;
  String? errors;
  Api? api;

  factory CouponProductModel.fromJson(Map<String, dynamic> json) => CouponProductModel(
    status: json["status"],
    success: json["success"],
    code: json["code"],
    message: json["message"],
    description: json["description"],
    data: List<Data>.from(json["data"].map((x) => Data.fromJson(x))),
    errors: json["errors"],
    api: Api.fromJson(json["api"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "code": code,
    "message": message,
    "description": description,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
    "errors": errors,
    "api": api!.toJson(),
  };
}

class Api {
  Api({
    this.version,
  });

  String? version;

  factory Api.fromJson(Map<String, dynamic> json) => Api(
    version: json["version"],
  );

  Map<String, dynamic> toJson() => {
    "version": version,
  };
}

class Data {
  Data({
    this.pkNo,
    this.variantName,
    this.urlSlug,
    this.fPrdMasterSetupNo,
    this.totalFreeStock,
    this.primaryImgRelativePath,
    this.thumbPath,
    this.regularPrice,
    this.installmentPrice,
    this.discount,
    this.couponType,
  });

  int? pkNo;
  String? variantName;
  String? urlSlug;
  int? fPrdMasterSetupNo;
  int? totalFreeStock;
  String? primaryImgRelativePath;
  String? thumbPath;
  double? regularPrice;
  double? installmentPrice;
  double? discount;
  int? couponType;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    pkNo: json["PK_NO"],
    variantName: json["VARIANT_NAME"],
    urlSlug: json["URL_SLUG"],
    fPrdMasterSetupNo: json["F_PRD_MASTER_SETUP_NO"],
    totalFreeStock: json["TOTAL_FREE_STOCK"],
    primaryImgRelativePath: json["PRIMARY_IMG_RELATIVE_PATH"],
    thumbPath: json["THUMB_PATH"],
    regularPrice: json["REGULAR_PRICE"] is int
      ? (json['REGULAR_PRICE'] as int).toDouble()
      : json['REGULAR_PRICE'],
    installmentPrice: json["INSTALLMENT_PRICE"] is int
      ? (json['INSTALLMENT_PRICE'] as int).toDouble()
      : json['INSTALLMENT_PRICE'],
    discount: json["DISCOUNT"] is int
      ? (json['DISCOUNT'] as int).toDouble()
      : json['DISCOUNT'],
    couponType: json["COUPON_TYPE"],
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "VARIANT_NAME": variantName,
    "URL_SLUG": urlSlug,
    "F_PRD_MASTER_SETUP_NO": fPrdMasterSetupNo,
    "TOTAL_FREE_STOCK": totalFreeStock,
    "PRIMARY_IMG_RELATIVE_PATH": primaryImgRelativePath,
    "THUMB_PATH": thumbPath,
    "REGULAR_PRICE": regularPrice,
    "INSTALLMENT_PRICE": installmentPrice,
    "DISCOUNT": discount,
    "COUPON_TYPE": couponType,
  };
}
