class TempStateModel {
  String? _state;
  int? _state_pk;

  TempStateModel(this._state, this._state_pk);

  int? get state_pk => _state_pk;

  String? get state => _state;

  set state_pk(int? value) {
    _state_pk = value;
  }

  set state(String? value) {
    _state = value;
  }
}