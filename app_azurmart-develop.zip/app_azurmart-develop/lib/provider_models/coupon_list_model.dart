// To parse this JSON data, do
//
//     final couponListModel = couponListModelFromJson(jsonString);

import 'dart:convert';

CouponListModel couponListModelFromJson(String str) => CouponListModel.fromJson(json.decode(str));

String couponListModelToJson(CouponListModel data) => json.encode(data.toJson());

class CouponListModel {
  CouponListModel({
    this.status,
    this.success,
    this.code,
    this.message,
    this.description,
    this.data,
    this.errors,
    this.api,
  });

  int? status;
  bool? success;
  int? code;
  String? message;
  String? description;
  List<CouponList>? data;
  dynamic errors;
  Api? api;

  factory CouponListModel.fromJson(Map<String, dynamic> json) => CouponListModel(
    status: json["status"],
    success: json["success"],
    code: json["code"],
    message: json["message"],
    description: json["description"],
    data: List<CouponList>.from(json["data"].map((x) => CouponList.fromJson(x))),
    errors: json["errors"],
    api: Api.fromJson(json["api"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "code": code,
    "message": message,
    "description": description,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
    "errors": errors,
    "api": api!.toJson(),
  };
}

class Api {
  Api({
    required this.version,
  });

  String version;

  factory Api.fromJson(Map<String, dynamic> json) => Api(
    version: json["version"],
  );

  Map<String, dynamic> toJson() => {
    "version": version,
  };
}

class CouponList {
  CouponList({
    this.pkNo,
    this.couponType,
    this.discount,
    this.couponCode,
    this.products,
  });

  int? pkNo;
  int? couponType;
  double? discount;
  String? couponCode;
  List<Products>? products;

  factory CouponList.fromJson(Map<String, dynamic> json) => CouponList(
    pkNo: json["PK_NO"],
    couponType: json["COUPON_TYPE"],
    discount: json["DISCOUNT"] is int
      ? (json['DISCOUNT'] as int).toDouble()
      : json['DISCOUNT'],
    couponCode: json["COUPON_CODE"],
    products: List<Products>.from(json["data"].map((x) => Products.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "COUPON_TYPE": couponType,
    "DISCOUNT": discount,
    "COUPON_CODE": couponCode,
    "data": List<dynamic>.from(products!.map((x) => x.toJson())),
  };
}

class Products {
  Products({
    this.pkNo,
    this.variantName,
    this.totalFreeStock,
    this.primaryImgRelativePath,
    this.thumbPath,
    this.regularPrice,
    this.discount,
    this.urlSlug,
    this.couponType,
    this.couponCode,
  });

  int? pkNo;
  String? variantName;
  int? totalFreeStock;
  String? primaryImgRelativePath;
  String? thumbPath;
  double? regularPrice;
  double? discount;
  String? urlSlug;
  int? couponType;
  String? couponCode;

  factory Products.fromJson(Map<String, dynamic> json) => Products(
    pkNo: json["PK_NO"],
    variantName: json["VARIANT_NAME"],
    totalFreeStock: json["TOTAL_FREE_STOCK"],
    primaryImgRelativePath: json["PRIMARY_IMG_RELATIVE_PATH"],
    thumbPath: json["THUMB_PATH"],
    regularPrice: json["REGULAR_PRICE"] is int
      ? (json['REGULAR_PRICE'] as int).toDouble()
      : json['REGULAR_PRICE'],
    discount: json["DISCOUNT"] is int
      ? (json['DISCOUNT'] as int).toDouble()
      : json['DISCOUNT'],
    urlSlug: json["URL_SLUG"],
    couponType: json["COUPON_TYPE"],
    couponCode: json["COUPON_CODE"],
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "VARIANT_NAME": variantName,
    "TOTAL_FREE_STOCK": totalFreeStock,
    "PRIMARY_IMG_RELATIVE_PATH": primaryImgRelativePath,
    "THUMB_PATH": thumbPath,
    "REGULAR_PRICE": regularPrice,
    "DISCOUNT": discount,
    "URL_SLUG": urlSlug,
    "COUPON_TYPE": couponType,
    "COUPON_CODE": couponCode,
  };
}
