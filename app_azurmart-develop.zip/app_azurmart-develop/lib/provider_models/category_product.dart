/// status : 1
/// success : true
/// code : 200
/// message : "Data is available !"
/// description : ""
/// data : [{"PK_NO":3261,"F_PRD_MASTER_SETUP_NO":695,"VARIANT_NAME":"LE CREUSET CAPPUCINO MUG GRADE B 200 ML - Deep Teal - 200ml","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/695/prod_22062021_60d208d21d133.jpg","URL_SLUG":"le-creuset-cappucino-mug-grade-b-200-ml-deep-teal-200ml","TOTAL_FREE_STOCK":22,"REGULAR_PRICE":89,"URL":"product/le-creuset-cappucino-mug-grade-b-200-ml-deep-teal-200ml","isWish":0,"OFFER":0},{"PK_NO":3260,"F_PRD_MASTER_SETUP_NO":695,"VARIANT_NAME":"LE CREUSET CAPPUCINO MUG GRADE B 200 ML - SEA SALT - 200ml","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/695/prod_22062021_60d2089c565c4.jpg","URL_SLUG":"le-creuset-cappucino-mug-grade-b-200-ml-sea-salt-200ml","TOTAL_FREE_STOCK":12,"REGULAR_PRICE":89,"URL":"product/le-creuset-cappucino-mug-grade-b-200-ml-sea-salt-200ml","isWish":0,"OFFER":0},{"PK_NO":3259,"F_PRD_MASTER_SETUP_NO":695,"VARIANT_NAME":"LE CREUSET CAPPUCINO MUG GRADE B 200 ML - Cerise - 200ml","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/695/prod_22062021_60d208547405d.jpg","URL_SLUG":"le-creuset-cappucino-mug-grade-b-200-ml-cerise-200ml","TOTAL_FREE_STOCK":22,"REGULAR_PRICE":89,"URL":"product/le-creuset-cappucino-mug-grade-b-200-ml-cerise-200ml","isWish":0,"OFFER":0},{"PK_NO":3258,"F_PRD_MASTER_SETUP_NO":695,"VARIANT_NAME":"LE CREUSET CAPPUCINO MUG GRADE B 200 ML - Coastal Blue - 200ml","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/695/prod_22062021_60d2081b95ce5.jpg","URL_SLUG":"le-creuset-cappucino-mug-grade-b-200-ml-coastal-blue-200ml","TOTAL_FREE_STOCK":12,"REGULAR_PRICE":89,"URL":"product/le-creuset-cappucino-mug-grade-b-200-ml-coastal-blue-200ml","isWish":0,"OFFER":0},{"PK_NO":3257,"F_PRD_MASTER_SETUP_NO":695,"VARIANT_NAME":"LE CREUSET CAPPUCINO MUG GRADE B 200 ML - CREME - 200ml","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/695/prod_22062021_60d207f056aea.jpg","URL_SLUG":"le-creuset-cappucino-mug-grade-b-200-ml-creme-200ml","TOTAL_FREE_STOCK":12,"REGULAR_PRICE":89,"URL":"product/le-creuset-cappucino-mug-grade-b-200-ml-creme-200ml","isWish":0,"OFFER":0},{"PK_NO":3256,"F_PRD_MASTER_SETUP_NO":695,"VARIANT_NAME":"LE CREUSET CAPPUCINO MUG GRADE B 200 ML - Meringue - 200ml","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/695/prod_22062021_60d207bd7fbd0.jpg","URL_SLUG":"le-creuset-cappucino-mug-grade-b-200-ml-meringue-200ml","TOTAL_FREE_STOCK":22,"REGULAR_PRICE":89,"URL":"product/le-creuset-cappucino-mug-grade-b-200-ml-meringue-200ml","isWish":0,"OFFER":0},{"PK_NO":3255,"F_PRD_MASTER_SETUP_NO":695,"VARIANT_NAME":"LE CREUSET CAPPUCINO MUG GRADE B 200 ML - Fig - 200ml","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/695/prod_22062021_60d20779657e1.jpg","URL_SLUG":"le-creuset-cappucino-mug-grade-b-200-ml-fig-200ml","TOTAL_FREE_STOCK":22,"REGULAR_PRICE":89,"URL":"product/le-creuset-cappucino-mug-grade-b-200-ml-fig-200ml","isWish":0,"OFFER":0},{"PK_NO":3254,"F_PRD_MASTER_SETUP_NO":695,"VARIANT_NAME":"LE CREUSET CAPPUCINO MUG GRADE B 200 ML - Soleil - 200ml","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/695/prod_22062021_60d2073b9122f.jpg","URL_SLUG":"le-creuset-cappucino-mug-grade-b-200-ml-soleil-200ml","TOTAL_FREE_STOCK":22,"REGULAR_PRICE":89,"URL":"product/le-creuset-cappucino-mug-grade-b-200-ml-soleil-200ml","isWish":0,"OFFER":0},{"PK_NO":3253,"F_PRD_MASTER_SETUP_NO":695,"VARIANT_NAME":"LE CREUSET CAPPUCINO MUG GRADE B 200 ML - MATT BLACK - 200ml","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/695/prod_22062021_60d2070d11570.jpg","URL_SLUG":"le-creuset-cappucino-mug-grade-b-200-ml-matt-black-200ml","TOTAL_FREE_STOCK":12,"REGULAR_PRICE":89,"URL":"product/le-creuset-cappucino-mug-grade-b-200-ml-matt-black-200ml","isWish":0,"OFFER":0},{"PK_NO":3252,"F_PRD_MASTER_SETUP_NO":695,"VARIANT_NAME":"LE CREUSET CAPPUCINO MUG GRADE B 200 ML - CHIFFON PINK - 200ml","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/695/prod_22062021_60d206a91b71d.jpg","URL_SLUG":"le-creuset-cappucino-mug-grade-b-200-ml-chiffon-pink-200ml","TOTAL_FREE_STOCK":22,"REGULAR_PRICE":89,"URL":"product/le-creuset-cappucino-mug-grade-b-200-ml-chiffon-pink-200ml","isWish":0,"OFFER":0}]
/// errors : null
/// api : {"version":"1.0"}

class CategoryProduct {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  List<Data>? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  List<Data>? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  set status(int? value) {
    _status = value;
  }

  CategoryProduct(
      {int? status,
      bool? success,
      int? code,
      String? message,
      String? description,
      List<Data>? data,
      dynamic errors,
      Api? api}) {
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
  }

  CategoryProduct.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    if (json["data"] != null) {
      _data = [];
      json["data"].forEach((v) {
        _data!.add(Data.fromJson(v));
      });
    }
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.map((v) => v.toJson()).toList();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }

  set success(bool? value) {
    _success = value;
  }

  set code(int? value) {
    _code = value;
  }

  set message(String? value) {
    _message = value;
  }

  set description(String? value) {
    _description = value;
  }

  set data(List<Data>? value) {
    _data = value;
  }

  set errors(dynamic value) {
    _errors = value;
  }

  set api(Api? value) {
    _api = value;
  }
}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;

  Api({String? version}) {
    _version = version;
  }

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }
}

/// PK_NO : 3261
/// F_PRD_MASTER_SETUP_NO : 695
/// VARIANT_NAME : "LE CREUSET CAPPUCINO MUG GRADE B 200 ML - Deep Teal - 200ml"
/// PRIMARY_IMG_RELATIVE_PATH : "/media/images/products/695/prod_22062021_60d208d21d133.jpg"
/// URL_SLUG : "le-creuset-cappucino-mug-grade-b-200-ml-deep-teal-200ml"
/// TOTAL_FREE_STOCK : 22
/// REGULAR_PRICE : 89
/// URL : "product/le-creuset-cappucino-mug-grade-b-200-ml-deep-teal-200ml"
/// isWish : 0
/// OFFER : 0

class Data {
  int? _pkno;
  int? _fprdmastersetupno;
  String? _variantname;
  String? _primaryimgrelativepath;
  String? _thumbPath;
  String? _urlslug;
  int? _totalfreestock;
  double? _regularprice;
  String? _url;
  int? _isWish;
  int? _offer;

  int? get pkno => _pkno;
  int? get fprdmastersetupno => _fprdmastersetupno;
  String? get variantname => _variantname;
  String? get primaryimgrelativepath => _primaryimgrelativepath;
  String? get urlslug => _urlslug;
  int? get totalfreestock => _totalfreestock;
  double? get regularprice => _regularprice;
  String? get url => _url;
  int? get isWish => _isWish;
  int? get offer => _offer;
  String? get thumbPath => _thumbPath;

  set thumbPath(String? value) {
    _thumbPath = value;
  }

  set pkno(int? value) {
    _pkno = value;
  }

  Data(
      {int? pkno,
      int? fprdmastersetupno,
      String? variantname,
      String? primaryimgrelativepath,
        String? thumbPath,
      String? urlslug,
      int? totalfreestock,
      double? regularprice,
      String? url,
      int? isWish,
      int? offer}) {
    _pkno = pkno;
    _fprdmastersetupno = fprdmastersetupno;
    _variantname = variantname;
    _primaryimgrelativepath = primaryimgrelativepath;
    _thumbPath = thumbPath;
    _urlslug = urlslug;
    _totalfreestock = totalfreestock;
    _regularprice = regularprice;
    _url = url;
    _isWish = isWish;
    _offer = offer;
  }

  Data.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _fprdmastersetupno = json["F_PRD_MASTER_SETUP_NO"];
    _variantname = json["VARIANT_NAME"];
    _primaryimgrelativepath = json["PRIMARY_IMG_RELATIVE_PATH"];
    _thumbPath = json["THUMB_PATH"];
    _urlslug = json["URL_SLUG"];
    _totalfreestock = json["TOTAL_FREE_STOCK"];
    _regularprice = json["REGULAR_PRICE"] is int
        ? (json['REGULAR_PRICE'] as int).toDouble()
        : json['REGULAR_PRICE'];
    _url = json["URL"];
    _isWish = json["isWish"];
    _offer = json["OFFER"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["F_PRD_MASTER_SETUP_NO"] = _fprdmastersetupno;
    map["VARIANT_NAME"] = _variantname;
    map["PRIMARY_IMG_RELATIVE_PATH"] = _primaryimgrelativepath;
    map["THUMB_PATH"] = _thumbPath;
    map["URL_SLUG"] = _urlslug;
    map["TOTAL_FREE_STOCK"] = _totalfreestock;
    map["REGULAR_PRICE"] = _regularprice;
    map["URL"] = _url;
    map["isWish"] = _isWish;
    map["OFFER"] = _offer;
    return map;
  }

  set fprdmastersetupno(int? value) {
    _fprdmastersetupno = value;
  }

  set variantname(String? value) {
    _variantname = value;
  }

  set primaryimgrelativepath(String? value) {
    _primaryimgrelativepath = value;
  }

  set urlslug(String? value) {
    _urlslug = value;
  }

  set totalfreestock(int? value) {
    _totalfreestock = value;
  }

  set regularprice(double? value) {
    _regularprice = value;
  }

  set url(String? value) {
    _url = value;
  }

  set isWish(int? value) {
    _isWish = value;
  }

  set offer(int? value) {
    _offer = value;
  }
}
