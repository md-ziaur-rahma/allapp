class BestSellModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  List<Data>? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  List<Data>? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;


  set status(int? value) {
    _status = value;
  }

  BestSellModel(
      {int? status,
      bool? success,
      int? code,
      String? message,
      String? description,
      List<Data>? data,
      dynamic errors,
      Api? api}) {
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
  }

  BestSellModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    if (json["data"] != null) {
      _data = [];
      json["data"].forEach((v) {
        _data!.add(Data.fromJson(v));
      });
    }
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.map((v) => v.toJson()).toList();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }

  set success(bool? value) {
    _success = value;
  }

  set code(int? value) {
    _code = value;
  }

  set message(String? value) {
    _message = value;
  }

  set description(String? value) {
    _description = value;
  }

  set data(List<Data>? value) {
    _data = value;
  }

  set errors(dynamic value) {
    _errors = value;
  }

  set api(Api? value) {
    _api = value;
  }
}

class Api {
  String? _version;

  String? get version => _version;


  set version(String? value) {
    _version = value;
  }

  Api({String? version}) {
    _version = version;
  }

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }
}

class Data {
  int? _pkno;
  String? _variantname;
  String? _urlslug;
  int? _fprdmastersetupno;
  int? _totalfreestock;
  int? _sellqty;
  String? _primaryimgrelativepath;
  String? _thumbPath;
  double? _regularprice;
  double? _installmentprice;
  String? _url;
  int? _rating;
  int? _isWish;
  int? _offer;

  int? get pkno => _pkno;
  String? get variantname => _variantname;
  String? get urlslug => _urlslug;
  int? get fprdmastersetupno => _fprdmastersetupno;
  int? get totalfreestock => _totalfreestock;
  int? get sellqty => _sellqty;
  String? get primaryimgrelativepath => _primaryimgrelativepath;
  double? get regularprice => _regularprice;
  double? get installmentprice => _installmentprice;
  String? get url => _url;
  int? get rating => _rating;
  int? get isWish => _isWish;
  int? get offer => _offer;
  String? get thumbPath => _thumbPath;

  set thumbPath(String? value) {
    _thumbPath = value;
  }

  set pkno(int? value) {
    _pkno = value;
  }


  set offer(int? value) {
    _offer = value;
  }

  Data(
      {int? pkno,
      String? variantname,
      String? urlslug,
      int? fprdmastersetupno,
      int? totalfreestock,
      int? sellqty,
      String? primaryimgrelativepath,
        String? thumbPath,
      double? regularprice,
      double? installmentprice,
      String? url,
      int? rating,
      int? isWish,
      int? offer}) {
    _pkno = pkno;
    _variantname = variantname;
    _urlslug = urlslug;
    _fprdmastersetupno = fprdmastersetupno;
    _totalfreestock = totalfreestock;
    _sellqty = sellqty;
    _primaryimgrelativepath = primaryimgrelativepath;
    _thumbPath = thumbPath;
    _regularprice = regularprice;
    _installmentprice = installmentprice;
    _url = url;
    _rating = rating;
    _isWish = isWish;
    _offer = offer;
  }

  Data.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _variantname = json["VARIANT_NAME"];
    _urlslug = json["URL_SLUG"];
    _fprdmastersetupno = json["F_PRD_MASTER_SETUP_NO"];
    _totalfreestock = json["TOTAL_FREE_STOCK"];
    _sellqty = json["SELL_QTY"];
    _primaryimgrelativepath = json["PRIMARY_IMG_RELATIVE_PATH"];
    _thumbPath = thumbPath;
    _thumbPath = json["THUMB_PATH"];
    _regularprice = json["REGULAR_PRICE"] is int
        ? (json['REGULAR_PRICE'] as int).toDouble()
        : json['REGULAR_PRICE'];
    _installmentprice = json["INSTALLMENT_PRICE"] is int
        ? (json['INSTALLMENT_PRICE'] as int).toDouble()
        : json['INSTALLMENT_PRICE'];
    _url = json["URL"];
    _rating = json["rating"];
    _isWish = json["isWish"];
    _offer = json["OFFER"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["VARIANT_NAME"] = _variantname;
    map["URL_SLUG"] = _urlslug;
    map["F_PRD_MASTER_SETUP_NO"] = _fprdmastersetupno;
    map["TOTAL_FREE_STOCK"] = _totalfreestock;
    map["SELL_QTY"] = _sellqty;
    map["PRIMARY_IMG_RELATIVE_PATH"] = _primaryimgrelativepath;
    map["THUMB_PATH"] = _thumbPath;
    map["REGULAR_PRICE"] = _regularprice;
    map["INSTALLMENT_PRICE"] = _installmentprice;
    map["URL"] = _url;
    map["rating"] = _rating;
    map["isWish"] = _isWish;
    map["OFFER"] = _offer;
    return map;
  }

  set variantname(String? value) {
    _variantname = value;
  }

  set urlslug(String? value) {
    _urlslug = value;
  }

  set fprdmastersetupno(int? value) {
    _fprdmastersetupno = value;
  }

  set totalfreestock(int? value) {
    _totalfreestock = value;
  }

  set sellqty(int? value) {
    _sellqty = value;
  }

  set primaryimgrelativepath(String? value) {
    _primaryimgrelativepath = value;
  }

  set regularprice(double? value) {
    _regularprice = value;
  }

  set installmentprice(double? value) {
    _installmentprice = value;
  }

  set url(String? value) {
    _url = value;
  }

  set rating(int? value) {
    _rating = value;
  }

  set isWish(int? value) {
    _isWish = value;
  }
}
