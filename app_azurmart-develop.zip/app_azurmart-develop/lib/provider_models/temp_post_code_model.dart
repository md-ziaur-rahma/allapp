class TempPostCodeModel {
  String? _pocode;
  int? _fcityno;
  String? _cityname;
  String? _statename;
  int? _fstateno;


  TempPostCodeModel(this._pocode, this._fcityno, this._cityname,
      this._statename, this._fstateno);

  String? get pocode => _pocode;

  int? get fcityno => _fcityno;

  int? get fstateno => _fstateno;

  String? get statename => _statename;

  String? get cityname => _cityname;

  set fstateno(int? value) {
    _fstateno = value;
  }

  set statename(String? value) {
    _statename = value;
  }

  set cityname(String? value) {
    _cityname = value;
  }

  set fcityno(int? value) {
    _fcityno = value;
  }

  set pocode(String? value) {
    _pocode = value;
  }
}