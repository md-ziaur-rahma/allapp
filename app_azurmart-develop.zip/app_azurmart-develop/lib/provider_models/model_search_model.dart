/// status : 1
/// success : true
/// code : 200
/// message : "Data is available !"
/// description : ""
/// data : [{"PK_NO":66,"MODEL_NAME":"GRILL","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/47/prod_15112020_5fb18ac4c0814.jpg"},{"PK_NO":366,"MODEL_NAME":"GRILL","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/541/prod_03032021_603fc0150c4d1.jpg"},{"PK_NO":533,"MODEL_NAME":"GRILL & GRIDDLE","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/736/prod_08042021_606de2eb5a278.jpg"},{"PK_NO":659,"MODEL_NAME":"GRILL GRADE B","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/850/prod_15042021_60782abf3c5d8.jpg"},{"PK_NO":368,"MODEL_NAME":"MULTI FUNCTION POT / GRILL","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/542/prod_04032021_603fd18e80754.jpg"},{"PK_NO":279,"MODEL_NAME":"SKILLET GRILL","PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/418/prod_07022021_601ff65bc76c8.jpg"}]
/// errors : null
/// api : {"version":"1.0"}

class ModelSearchModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  List<Data>? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  List<Data>? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;


  set status(int? value) {
    _status = value;
  }

  ModelSearchModel({
      int? status, 
      bool? success, 
      int? code, 
      String? message, 
      String? description, 
      List<Data>? data, 
      dynamic errors, 
      Api? api}){
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
}

  ModelSearchModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    if (json["data"] != null) {
      _data = [];
      json["data"].forEach((v) {
        _data!.add(Data.fromJson(v));
      });
    }
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.map((v) => v.toJson()).toList();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }

  set success(bool? value) {
    _success = value;
  }

  set code(int? value) {
    _code = value;
  }

  set message(String? value) {
    _message = value;
  }

  set description(String? value) {
    _description = value;
  }

  set data(List<Data>? value) {
    _data = value;
  }

  set errors(dynamic value) {
    _errors = value;
  }

  set api(Api? value) {
    _api = value;
  }
}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;

  Api({
      String? version}){
    _version = version;
}

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }

}

/// PK_NO : 66
/// MODEL_NAME : "GRILL"
/// PRIMARY_IMG_RELATIVE_PATH : "/media/images/products/47/prod_15112020_5fb18ac4c0814.jpg"

class Data {
  int? _pkno;
  String? _modelname;
  String? _primaryimgrelativepath;

  int? get pkno => _pkno;
  String? get modelname => _modelname;
  String? get primaryimgrelativepath => _primaryimgrelativepath;


  set pkno(int? value) {
    _pkno = value;
  }

  Data({
      int? pkno, 
      String? modelname, 
      String? primaryimgrelativepath}){
    _pkno = pkno;
    _modelname = modelname;
    _primaryimgrelativepath = primaryimgrelativepath;
}

  Data.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _modelname = json["MODEL_NAME"];
    _primaryimgrelativepath = json["PRIMARY_IMG_RELATIVE_PATH"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["MODEL_NAME"] = _modelname;
    map["PRIMARY_IMG_RELATIVE_PATH"] = _primaryimgrelativepath;
    return map;
  }

  set modelname(String? value) {
    _modelname = value;
  }

  set primaryimgrelativepath(String? value) {
    _primaryimgrelativepath = value;
  }
}