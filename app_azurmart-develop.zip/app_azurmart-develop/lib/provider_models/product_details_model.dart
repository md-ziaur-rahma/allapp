/// status : 1
/// success : true
/// code : 200
/// message : "Data is available !"
/// description : ""
/// data : {"product_size":[{"SIZE_NAME":"ONE SIZE","VARIANT_NAME":"COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923","URL_SLUG":"cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923","REGULAR_PRICE":179,"URL":"baby/bag/cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923","isActive":1}],"product_color":[{"COLOR_NAME":"MINI MERMAIDS","VARIANT_NAME":"COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923","VARIANT_ICON":"/media/images/products/132/prod_30112020_5fc403b43b573.jpg","REGULAR_PRICE":179,"URL_SLUG":"cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923","URL":"baby/bag/cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923","isActive":1},{"COLOR_NAME":"MISS DINOMITE","VARIANT_NAME":"COSATTO SUPA CHANGING BAG - MISS DINOMITE - ONE SIZE - CT3923","VARIANT_ICON":"/media/images/products/132/prod_30112020_5fc404c3ef3e1.jpg","REGULAR_PRICE":179,"URL_SLUG":"cosatto-supa-changing-bag-miss-dinomite-one-size-ct3923","URL":"baby/bag/cosatto-supa-changing-bag-miss-dinomite-one-size-ct3923","isActive":0}],"availablity":29,"stock_info":[{"PRD_VARINAT_NAME":"COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923","IG_CODE":"AM1102101","INV_WAREHOUSE_NAME":"MY WAREHOUSE 02","SKUID":"107101101101","PREFERRED_SHIPPING_METHOD":"SEA","SHIPMENT_TYPE":"SEA","F_SHIPPMENT_NO":2,"CUSTOMER_PREFFERED_SHIPPING_METHOD":null,"SCH_ARRIVAL_DATE":"2021-03-04","SHIPMENT_STATUS":80,"FINAL_PREFFERED_SHIPPING_METHOD":"SEA","BARCODE":"5021645050934","F_PRD_VARIANT_NO":280,"TOTAL":29,"F_PRD_MASTER_NO":132}],"realated_product":[{"PK_NO":660,"DEFAULT_NAME":"TOMMEE TIPPEE HEALTHCARE KIT","F_PRD_SUB_CATEGORY_ID":54,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/660/prod_27032021_605e91230e0ce.jpg","CAT_SLUG":"baby","SUB_SLUG":"baby-essentials","average_rating":0,"URL":"baby/baby-essentials/tommee-tippee-healthcare-kit-black-9-baby-essentials","PRICE":89,"review":0},{"PK_NO":657,"DEFAULT_NAME":"TOMMEE TIPPIE BABY FOOD BLENDER","F_PRD_SUB_CATEGORY_ID":51,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/657/prod_27032021_605e87edb69cd.jpg","CAT_SLUG":"baby","SUB_SLUG":"blender","average_rating":0,"URL":"baby/blender/tommee-tippie-baby-food-blender-white-mini","PRICE":149,"review":0},{"PK_NO":654,"DEFAULT_NAME":"TOMMEE TIPPIE FEEDING SET","F_PRD_SUB_CATEGORY_ID":53,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/654/prod_27032021_605e820436799.jpg","CAT_SLUG":"baby","SUB_SLUG":"feeding-set","average_rating":0,"URL":"baby/feeding-set/tommee-tippie-closure-to-nature-complete-feeding-set-white-423232","PRICE":599,"review":0},{"PK_NO":567,"DEFAULT_NAME":"BEABA BABYCOOK","F_PRD_SUB_CATEGORY_ID":51,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/567/prod_08032021_604562927f227.jpg","CAT_SLUG":"baby","SUB_SLUG":"blender","average_rating":0,"URL":"baby/blender/beaba-babycook-jade-green-solo-4-in-1","PRICE":495,"review":0},{"PK_NO":136,"DEFAULT_NAME":"NAPPY DISPOSAL","F_PRD_SUB_CATEGORY_ID":38,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/136/prod_04122020_5fc959f8b3efd.jpg","CAT_SLUG":"baby","SUB_SLUG":"bin","average_rating":0,"URL":"baby/bin/angelcare-nappy-disposal-white-one-size","PRICE":149,"review":0}],"rating_percentage":100,"product":{"PK_NO":280,"F_PRD_MASTER_SETUP_NO":132,"CODE":101,"COMPOSITE_CODE":"107101101101","VARIANT_NAME":"COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923","VARIANT_CUSTOMS_NAME":"NP577821 Cosatto Supa Changing Bag- Mermaids","F_SIZE_NO":87,"SIZE_NAME":"ONE SIZE","F_COLOR_NO":121,"COLOR":"MINI MERMAIDS","MKT_CODE":101,"MRK_ID_COMPOSITE_CODE":"AM1102101","HS_CODE":"42022900","BARCODE":"5021645050934","IS_BARCODE_BY_MFG":1,"NARRATION":"<p>SUPA CHANGING BAG</p><p><span style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\">Style up your Supa with the luxurious coordinating changing bag.</span><br style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\"><br style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\"><span style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\">Like all our gear, this bag is designed to make your life easier...</span><br style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\"><br style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\"><span style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\">Featuring a padded wipe clean changing mat, adjustable strap and multiple compartments, everything can be kept safely in its own place.</span></p><p class=\"sub-heading\" style=\"margin: 20px 0px 10px; font-family: Comfortaa, cursive; font-size: 1.3em; line-height: 1.1; color: rgb(51, 51, 51); letter-spacing: normal;\">Dimensions</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; font-family: Comfortaa, cursive; color: rgb(51, 51, 51); letter-spacing: normal;\">L: 44cm W: 36cm H:42cm</p>","F_PRIMARY_IMG_VARIANT_ID":446,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/132/prod_30112020_5fc403b43b573.jpg","REGULAR_PRICE":179,"INSTALLMENT_PRICE":199,"SEA_FREIGHT_CHARGE":0,"AIR_FREIGHT_CHARGE":100,"PREFERRED_SHIPPING_METHOD":"SEA","LOCAL_POSTAGE":0,"INTER_DISTRICT_POSTAGE":10,"F_VAT_CLASS":3,"VAT_AMOUNT_PERCENT":20,"IS_RESELLER_PROGRAM_ENABLED":null,"KEYWORD_SEARCH":"COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923 NP577821 Cosatto Supa Changing Bag- Mermaids ONE SIZE MINI MERMAIDS COSATTO CHANGING BAG BABY BAG CTCB101101 SEA  SUPA CHANGING BAG   Style up your Supa with the luxurious coordinating changing bag.    Like all our gear, this bag is designed to make your life easier...    Featuring a padded wipe clean changing mat, adjustable strap and multiple compartments, everything can be kept safely in its own place.   Dimensions  L: 44cm W: 36cm H:42cm ","COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":1,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":" ","F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-30 02:25:24","F_SS_MODIFIED_BY":1,"SS_MODIFIED_ON":"2020-12-02 17:37:14","F_SS_COMPANY_NO":null,"WEB_ARTICLE":null,"URL_SLUG":"cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923","isWish":1,"reviews":[{"PK_NO":30,"F_PRD_MASTER_NO":132,"F_PRD_VARIANT_NO":280,"F_CUSTOMER_NO":1282,"CUSTOMER_NAME":"sifat ecommerce","RATING":5,"REVIEW_TEXT":"WOW","LANGUAGE_ID":1,"IS_FEATURE":0,"IS_ACTIVE":0,"F_SS_CREATED_BY":null,"SS_CREATED_ON":"2021-04-13 12:07:57","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-04-13 12:07:57"}]},"review":[{"PK_NO":30,"F_PRD_MASTER_NO":132,"F_PRD_VARIANT_NO":280,"F_CUSTOMER_NO":1282,"CUSTOMER_NAME":"sifat ecommerce","RATING":5,"REVIEW_TEXT":"WOW","LANGUAGE_ID":1,"IS_FEATURE":0,"IS_ACTIVE":0,"F_SS_CREATED_BY":null,"SS_CREATED_ON":"2021-04-13 12:07:57","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-04-13 12:07:57"}],"img":[{"RELATIVE_PATH":"/media/images/products/132/prod_30112020_5fc403b43b573.jpg"}]}
/// errors : null
/// api : {"version":"1.0"}

class ProductDetailsModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  Data? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  Data? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  ProductDetailsModel(
      {int? status,
      bool? success,
      int? code,
      String? message,
      String? description,
      Data? data,
      dynamic errors,
      Api? api}) {
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
  }

  ProductDetailsModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    _data = json["data"] != null ? Data.fromJson(json["data"]) : null;
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.toJson();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }
}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;

  Api({String? version}) {
    _version = version;
  }

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }
}

/// product_size : [{"SIZE_NAME":"ONE SIZE","VARIANT_NAME":"COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923","URL_SLUG":"cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923","REGULAR_PRICE":179,"URL":"baby/bag/cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923","isActive":1}]
/// product_color : [{"COLOR_NAME":"MINI MERMAIDS","VARIANT_NAME":"COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923","VARIANT_ICON":"/media/images/products/132/prod_30112020_5fc403b43b573.jpg","REGULAR_PRICE":179,"URL_SLUG":"cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923","URL":"baby/bag/cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923","isActive":1},{"COLOR_NAME":"MISS DINOMITE","VARIANT_NAME":"COSATTO SUPA CHANGING BAG - MISS DINOMITE - ONE SIZE - CT3923","VARIANT_ICON":"/media/images/products/132/prod_30112020_5fc404c3ef3e1.jpg","REGULAR_PRICE":179,"URL_SLUG":"cosatto-supa-changing-bag-miss-dinomite-one-size-ct3923","URL":"baby/bag/cosatto-supa-changing-bag-miss-dinomite-one-size-ct3923","isActive":0}]
/// availablity : 29
/// stock_info : [{"PRD_VARINAT_NAME":"COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923","IG_CODE":"AM1102101","INV_WAREHOUSE_NAME":"MY WAREHOUSE 02","SKUID":"107101101101","PREFERRED_SHIPPING_METHOD":"SEA","SHIPMENT_TYPE":"SEA","F_SHIPPMENT_NO":2,"CUSTOMER_PREFFERED_SHIPPING_METHOD":null,"SCH_ARRIVAL_DATE":"2021-03-04","SHIPMENT_STATUS":80,"FINAL_PREFFERED_SHIPPING_METHOD":"SEA","BARCODE":"5021645050934","F_PRD_VARIANT_NO":280,"TOTAL":29,"F_PRD_MASTER_NO":132}]
/// realated_product : [{"PK_NO":660,"DEFAULT_NAME":"TOMMEE TIPPEE HEALTHCARE KIT","F_PRD_SUB_CATEGORY_ID":54,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/660/prod_27032021_605e91230e0ce.jpg","CAT_SLUG":"baby","SUB_SLUG":"baby-essentials","average_rating":0,"URL":"baby/baby-essentials/tommee-tippee-healthcare-kit-black-9-baby-essentials","PRICE":89,"review":0},{"PK_NO":657,"DEFAULT_NAME":"TOMMEE TIPPIE BABY FOOD BLENDER","F_PRD_SUB_CATEGORY_ID":51,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/657/prod_27032021_605e87edb69cd.jpg","CAT_SLUG":"baby","SUB_SLUG":"blender","average_rating":0,"URL":"baby/blender/tommee-tippie-baby-food-blender-white-mini","PRICE":149,"review":0},{"PK_NO":654,"DEFAULT_NAME":"TOMMEE TIPPIE FEEDING SET","F_PRD_SUB_CATEGORY_ID":53,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/654/prod_27032021_605e820436799.jpg","CAT_SLUG":"baby","SUB_SLUG":"feeding-set","average_rating":0,"URL":"baby/feeding-set/tommee-tippie-closure-to-nature-complete-feeding-set-white-423232","PRICE":599,"review":0},{"PK_NO":567,"DEFAULT_NAME":"BEABA BABYCOOK","F_PRD_SUB_CATEGORY_ID":51,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/567/prod_08032021_604562927f227.jpg","CAT_SLUG":"baby","SUB_SLUG":"blender","average_rating":0,"URL":"baby/blender/beaba-babycook-jade-green-solo-4-in-1","PRICE":495,"review":0},{"PK_NO":136,"DEFAULT_NAME":"NAPPY DISPOSAL","F_PRD_SUB_CATEGORY_ID":38,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/136/prod_04122020_5fc959f8b3efd.jpg","CAT_SLUG":"baby","SUB_SLUG":"bin","average_rating":0,"URL":"baby/bin/angelcare-nappy-disposal-white-one-size","PRICE":149,"review":0}]
/// rating_percentage : 100
/// product : {"PK_NO":280,"F_PRD_MASTER_SETUP_NO":132,"CODE":101,"COMPOSITE_CODE":"107101101101","VARIANT_NAME":"COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923","VARIANT_CUSTOMS_NAME":"NP577821 Cosatto Supa Changing Bag- Mermaids","F_SIZE_NO":87,"SIZE_NAME":"ONE SIZE","F_COLOR_NO":121,"COLOR":"MINI MERMAIDS","MKT_CODE":101,"MRK_ID_COMPOSITE_CODE":"AM1102101","HS_CODE":"42022900","BARCODE":"5021645050934","IS_BARCODE_BY_MFG":1,"NARRATION":"<p>SUPA CHANGING BAG</p><p><span style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\">Style up your Supa with the luxurious coordinating changing bag.</span><br style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\"><br style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\"><span style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\">Like all our gear, this bag is designed to make your life easier...</span><br style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\"><br style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\"><span style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\">Featuring a padded wipe clean changing mat, adjustable strap and multiple compartments, everything can be kept safely in its own place.</span></p><p class=\"sub-heading\" style=\"margin: 20px 0px 10px; font-family: Comfortaa, cursive; font-size: 1.3em; line-height: 1.1; color: rgb(51, 51, 51); letter-spacing: normal;\">Dimensions</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; font-family: Comfortaa, cursive; color: rgb(51, 51, 51); letter-spacing: normal;\">L: 44cm W: 36cm H:42cm</p>","F_PRIMARY_IMG_VARIANT_ID":446,"PRIMARY_IMG_RELATIVE_PATH":"/media/images/products/132/prod_30112020_5fc403b43b573.jpg","REGULAR_PRICE":179,"INSTALLMENT_PRICE":199,"SEA_FREIGHT_CHARGE":0,"AIR_FREIGHT_CHARGE":100,"PREFERRED_SHIPPING_METHOD":"SEA","LOCAL_POSTAGE":0,"INTER_DISTRICT_POSTAGE":10,"F_VAT_CLASS":3,"VAT_AMOUNT_PERCENT":20,"IS_RESELLER_PROGRAM_ENABLED":null,"KEYWORD_SEARCH":"COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923 NP577821 Cosatto Supa Changing Bag- Mermaids ONE SIZE MINI MERMAIDS COSATTO CHANGING BAG BABY BAG CTCB101101 SEA  SUPA CHANGING BAG   Style up your Supa with the luxurious coordinating changing bag.    Like all our gear, this bag is designed to make your life easier...    Featuring a padded wipe clean changing mat, adjustable strap and multiple compartments, everything can be kept safely in its own place.   Dimensions  L: 44cm W: 36cm H:42cm ","COMMENTS":null,"IS_ACTIVE":1,"ADD_COL_NUMBER_1":1,"ADD_COL_NUMBER_2":null,"ADD_COL_VARCHAR_1":null,"ADD_COL_VARCHAR_2":" ","F_SS_CREATED_BY":1,"SS_CREATED_ON":"2020-11-30 02:25:24","F_SS_MODIFIED_BY":1,"SS_MODIFIED_ON":"2020-12-02 17:37:14","F_SS_COMPANY_NO":null,"WEB_ARTICLE":null,"URL_SLUG":"cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923","isWish":1,"reviews":[{"PK_NO":30,"F_PRD_MASTER_NO":132,"F_PRD_VARIANT_NO":280,"F_CUSTOMER_NO":1282,"CUSTOMER_NAME":"sifat ecommerce","RATING":5,"REVIEW_TEXT":"WOW","LANGUAGE_ID":1,"IS_FEATURE":0,"IS_ACTIVE":0,"F_SS_CREATED_BY":null,"SS_CREATED_ON":"2021-04-13 12:07:57","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-04-13 12:07:57"}]}
/// review : [{"PK_NO":30,"F_PRD_MASTER_NO":132,"F_PRD_VARIANT_NO":280,"F_CUSTOMER_NO":1282,"CUSTOMER_NAME":"sifat ecommerce","RATING":5,"REVIEW_TEXT":"WOW","LANGUAGE_ID":1,"IS_FEATURE":0,"IS_ACTIVE":0,"F_SS_CREATED_BY":null,"SS_CREATED_ON":"2021-04-13 12:07:57","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-04-13 12:07:57"}]
/// img : [{"RELATIVE_PATH":"/media/images/products/132/prod_30112020_5fc403b43b573.jpg"}]

class Data {
  List<Offer>? _offer;
  List<Product_size>? _productSize;
  List<Product_color>? _productColor;
  int? _availablity;
  List<Stock_info>? _stockInfo;
  List<Realated_product>? _realatedProduct;
  int? _ratingPercentage;
  Product? _product;
  Brand? _brand;
  List<Img>? _img;

  List<Offer>? get offer => _offer;
  List<Product_size>? get productSize => _productSize;
  List<Product_color>? get productColor => _productColor;
  int? get availablity => _availablity;
  List<Stock_info>? get stockInfo => _stockInfo;
  List<Realated_product>? get realatedProduct => _realatedProduct;
  int? get ratingPercentage => _ratingPercentage;
  Product? get product => _product;
  Brand? get brand => _brand;
  List<Img>? get img => _img;

  set offer(List<Offer>? value) {
    _offer = value;
  }

  set productSize(List<Product_size>? value) {
    _productSize = value;
  }

  set brand(Brand? value) {
    _brand = value;
  }

  Data(
      {List<Offer>? offer,
      List<Product_size>? productSize,
      List<Product_color>? productColor,
      int? availablity,
      List<Stock_info>? stockInfo,
      List<Realated_product>? realatedProduct,
      int? ratingPercentage,
      Product? product,
      Brand? brand,
      List<Review>? review,
      List<Img>? img}) {
    _offer = offer;
    _productSize = productSize;
    _productColor = productColor;
    _availablity = availablity;
    _stockInfo = stockInfo;
    _realatedProduct = realatedProduct;
    _ratingPercentage = ratingPercentage;
    _product = product;
    _brand = brand;
    _img = img;
  }

  Data.fromJson(dynamic json) {
    if (json["offer"] != null) {
      _offer = [];
      json["offer"].forEach((v) {
        _offer!.add(Offer.fromJson(v));
      });
    }
    if (json["product_size"] != null) {
      _productSize = [];
      json["product_size"].forEach((v) {
        _productSize!.add(Product_size.fromJson(v));
      });
    }
    if (json["product_color"] != null) {
      _productColor = [];
      json["product_color"].forEach((v) {
        _productColor!.add(Product_color.fromJson(v));
      });
    }
    _availablity = json["availablity"];
    if (json["stock_info"] != null) {
      _stockInfo = [];
      json["stock_info"].forEach((v) {
        _stockInfo!.add(Stock_info.fromJson(v));
      });
    }
    if (json["realated_product"] != null) {
      _realatedProduct = [];
      json["realated_product"].forEach((v) {
        _realatedProduct!.add(Realated_product.fromJson(v));
      });
    }
    _ratingPercentage = json["rating_percentage"];
    _brand = json["brand"] != null ? Brand.fromJson(json["brand"]) : null;
    _product =
        json["product"] != null ? Product.fromJson(json["product"]) : null;
    if (json["img"] != null) {
      _img = [];
      json["img"].forEach((v) {
        _img!.add(Img.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_offer != null) {
      map["offer"] = _offer!.map((v) => v.toJson()).toList();
    }
    if (_productSize != null) {
      map["product_size"] = _productSize!.map((v) => v.toJson()).toList();
    }
    if (_productColor != null) {
      map["product_color"] = _productColor!.map((v) => v.toJson()).toList();
    }
    map["availablity"] = _availablity;
    if (_stockInfo != null) {
      map["stock_info"] = _stockInfo!.map((v) => v.toJson()).toList();
    }
    if (_realatedProduct != null) {
      map["realated_product"] =
          _realatedProduct!.map((v) => v.toJson()).toList();
    }
    map["rating_percentage"] = _ratingPercentage;
    if (_product != null) {
      map["product"] = _product!.toJson();
    }
    if (_brand != null) {
      map["brand"] = _brand!.toJson();
    }
    if (_img != null) {
      map["img"] = _img!.map((v) => v.toJson()).toList();
    }
    return map;
  }

  set productColor(List<Product_color>? value) {
    _productColor = value;
  }

  set availablity(int? value) {
    _availablity = value;
  }

  set stockInfo(List<Stock_info>? value) {
    _stockInfo = value;
  }

  set realatedProduct(List<Realated_product>? value) {
    _realatedProduct = value;
  }

  set ratingPercentage(int? value) {
    _ratingPercentage = value;
  }

  set product(Product? value) {
    _product = value;
  }

  set img(List<Img>? value) {
    _img = value;
  }
}

/// RELATIVE_PATH : "/media/images/products/132/prod_30112020_5fc403b43b573.jpg"

class Img {
  String? _relativepath;

  String? get relativepath => _relativepath;

  Img({String? relativepath}) {
    _relativepath = relativepath;
  }

  Img.fromJson(dynamic json) {
    _relativepath = json["RELATIVE_PATH"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["RELATIVE_PATH"] = _relativepath;
    return map;
  }
}

/// PK_NO : 30
/// F_PRD_MASTER_NO : 132
/// F_PRD_VARIANT_NO : 280
/// F_CUSTOMER_NO : 1282
/// CUSTOMER_NAME : "sifat ecommerce"
/// RATING : 5
/// REVIEW_TEXT : "WOW"
/// LANGUAGE_ID : 1
/// IS_FEATURE : 0
/// IS_ACTIVE : 0
/// F_SS_CREATED_BY : null
/// SS_CREATED_ON : "2021-04-13 12:07:57"
/// F_SS_MODIFIED_BY : null
/// SS_MODIFIED_ON : "2021-04-13 12:07:57"

class Review {
  int? _pkno;
  int? _fprdmasterno;
  int? _fprdvariantno;
  int? _fcustomerno;
  String? _customername;
  int? _rating;
  String? _reviewtext;
  int? _languageid;
  int? _isfeature;
  int? _isactive;
  dynamic _fsscreatedby;
  String? _sscreatedon;
  dynamic _fssmodifiedby;
  String? _ssmodifiedon;

  int? get pkno => _pkno;
  int? get fprdmasterno => _fprdmasterno;
  int? get fprdvariantno => _fprdvariantno;
  int? get fcustomerno => _fcustomerno;
  String? get customername => _customername;
  int? get rating => _rating;
  String? get reviewtext => _reviewtext;
  int? get languageid => _languageid;
  int? get isfeature => _isfeature;
  int? get isactive => _isactive;
  dynamic get fsscreatedby => _fsscreatedby;
  String? get sscreatedon => _sscreatedon;
  dynamic get fssmodifiedby => _fssmodifiedby;
  String? get ssmodifiedon => _ssmodifiedon;

  Review(
      {int? pkno,
      int? fprdmasterno,
      int? fprdvariantno,
      int? fcustomerno,
      String? customername,
      int? rating,
      String? reviewtext,
      int? languageid,
      int? isfeature,
      int? isactive,
      dynamic fsscreatedby,
      String? sscreatedon,
      dynamic fssmodifiedby,
      String? ssmodifiedon}) {
    _pkno = pkno;
    _fprdmasterno = fprdmasterno;
    _fprdvariantno = fprdvariantno;
    _fcustomerno = fcustomerno;
    _customername = customername;
    _rating = rating;
    _reviewtext = reviewtext;
    _languageid = languageid;
    _isfeature = isfeature;
    _isactive = isactive;
    _fsscreatedby = fsscreatedby;
    _sscreatedon = sscreatedon;
    _fssmodifiedby = fssmodifiedby;
    _ssmodifiedon = ssmodifiedon;
  }

  Review.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _fprdmasterno = json["F_PRD_MASTER_NO"];
    _fprdvariantno = json["F_PRD_VARIANT_NO"];
    _fcustomerno = json["F_CUSTOMER_NO"];
    _customername = json["CUSTOMER_NAME"];
    _rating = json["RATING"];
    _reviewtext = json["REVIEW_TEXT"];
    _languageid = json["LANGUAGE_ID"];
    _isfeature = json["IS_FEATURE"];
    _isactive = json["IS_ACTIVE"];
    _fsscreatedby = json["F_SS_CREATED_BY"];
    _sscreatedon = json["SS_CREATED_ON"];
    _fssmodifiedby = json["F_SS_MODIFIED_BY"];
    _ssmodifiedon = json["SS_MODIFIED_ON"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["F_PRD_MASTER_NO"] = _fprdmasterno;
    map["F_PRD_VARIANT_NO"] = _fprdvariantno;
    map["F_CUSTOMER_NO"] = _fcustomerno;
    map["CUSTOMER_NAME"] = _customername;
    map["RATING"] = _rating;
    map["REVIEW_TEXT"] = _reviewtext;
    map["LANGUAGE_ID"] = _languageid;
    map["IS_FEATURE"] = _isfeature;
    map["IS_ACTIVE"] = _isactive;
    map["F_SS_CREATED_BY"] = _fsscreatedby;
    map["SS_CREATED_ON"] = _sscreatedon;
    map["F_SS_MODIFIED_BY"] = _fssmodifiedby;
    map["SS_MODIFIED_ON"] = _ssmodifiedon;
    return map;
  }
}

/// PK_NO : 280
/// F_PRD_MASTER_SETUP_NO : 132
/// CODE : 101
/// COMPOSITE_CODE : "107101101101"
/// VARIANT_NAME : "COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923"
/// VARIANT_CUSTOMS_NAME : "NP577821 Cosatto Supa Changing Bag- Mermaids"
/// F_SIZE_NO : 87
/// SIZE_NAME : "ONE SIZE"
/// F_COLOR_NO : 121
/// COLOR : "MINI MERMAIDS"
/// MKT_CODE : 101
/// MRK_ID_COMPOSITE_CODE : "AM1102101"
/// HS_CODE : "42022900"
/// BARCODE : "5021645050934"
/// IS_BARCODE_BY_MFG : 1
/// NARRATION : "<p>SUPA CHANGING BAG</p><p><span style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\">Style up your Supa with the luxurious coordinating changing bag.</span><br style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\"><br style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\"><span style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\">Like all our gear, this bag is designed to make your life easier...</span><br style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\"><br style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\"><span style=\"color: rgb(51, 51, 51); font-family: Comfortaa, cursive; letter-spacing: normal;\">Featuring a padded wipe clean changing mat, adjustable strap and multiple compartments, everything can be kept safely in its own place.</span></p><p class=\"sub-heading\" style=\"margin: 20px 0px 10px; font-family: Comfortaa, cursive; font-size: 1.3em; line-height: 1.1; color: rgb(51, 51, 51); letter-spacing: normal;\">Dimensions</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; font-family: Comfortaa, cursive; color: rgb(51, 51, 51); letter-spacing: normal;\">L: 44cm W: 36cm H:42cm</p>"
/// F_PRIMARY_IMG_VARIANT_ID : 446
/// PRIMARY_IMG_RELATIVE_PATH : "/media/images/products/132/prod_30112020_5fc403b43b573.jpg"
/// REGULAR_PRICE : 179
/// INSTALLMENT_PRICE : 199
/// SEA_FREIGHT_CHARGE : 0
/// AIR_FREIGHT_CHARGE : 100
/// PREFERRED_SHIPPING_METHOD : "SEA"
/// LOCAL_POSTAGE : 0
/// INTER_DISTRICT_POSTAGE : 10
/// F_VAT_CLASS : 3
/// VAT_AMOUNT_PERCENT : 20
/// IS_RESELLER_PROGRAM_ENABLED : null
/// KEYWORD_SEARCH : "COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923 NP577821 Cosatto Supa Changing Bag- Mermaids ONE SIZE MINI MERMAIDS COSATTO CHANGING BAG BABY BAG CTCB101101 SEA  SUPA CHANGING BAG   Style up your Supa with the luxurious coordinating changing bag.    Like all our gear, this bag is designed to make your life easier...    Featuring a padded wipe clean changing mat, adjustable strap and multiple compartments, everything can be kept safely in its own place.   Dimensions  L: 44cm W: 36cm H:42cm "
/// COMMENTS : null
/// IS_ACTIVE : 1
/// ADD_COL_NUMBER_1 : 1
/// ADD_COL_NUMBER_2 : null
/// ADD_COL_VARCHAR_1 : null
/// ADD_COL_VARCHAR_2 : " "
/// F_SS_CREATED_BY : 1
/// SS_CREATED_ON : "2020-11-30 02:25:24"
/// F_SS_MODIFIED_BY : 1
/// SS_MODIFIED_ON : "2020-12-02 17:37:14"
/// F_SS_COMPANY_NO : null
/// WEB_ARTICLE : null
/// URL_SLUG : "cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923"
/// isWish : 1
/// reviews : [{"PK_NO":30,"F_PRD_MASTER_NO":132,"F_PRD_VARIANT_NO":280,"F_CUSTOMER_NO":1282,"CUSTOMER_NAME":"sifat ecommerce","RATING":5,"REVIEW_TEXT":"WOW","LANGUAGE_ID":1,"IS_FEATURE":0,"IS_ACTIVE":0,"F_SS_CREATED_BY":null,"SS_CREATED_ON":"2021-04-13 12:07:57","F_SS_MODIFIED_BY":null,"SS_MODIFIED_ON":"2021-04-13 12:07:57"}]

class Brand {
  int? _pkno;
  String? _name;
  String? _brand_logo;

  int? get pkno => _pkno;

  String? get name => _name;

  String? get brand_logo => _brand_logo;

  set brand_logo(String? value) {
    _brand_logo = value;
  }

  set name(String? value) {
    _name = value;
  }

  set pkno(int? value) {
    _pkno = value;
  }

  Brand({int? pkno, String? name, String? brand_logo}) {
    _pkno = pkno;
    _name = name;
    _brand_logo = brand_logo;
  }
  Brand.fromJson(dynamic json) {
    _pkno = json['PK_NO'];
    _name = json['NAME'];
    _brand_logo = json['BRAND_LOGO'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["NAME"] = _name;
    map["BRAND_LOGO"] = _brand_logo;
    return map;
  }
}

class Product {
  int? _pkno;
  int? _fprdmastersetupno;
  int? _code;
  String? _brand;
  String? _model;
  String? _compositecode;
  String? _variantname;
  String? _variantcustomsname;
  int? _fsizeno;
  String? _sizename;
  int? _fcolorno;
  String? _color;
  int? _mktcode;
  String? _mrkidcompositecode;
  String? _hscode;
  String? _barcode;
  int? _isbarcodebymfg;
  String? _narration;
  int? _fprimaryimgvariantid;
  String? _primaryimgrelativepath;
  double? _regularprice;
  double? _installmentprice;
  double? _seafreightcharge;
  double? _airfreightcharge;
  String? _preferredshippingmethod;
  double? _localpostage;
  double? _interdistrictpostage;
  int? _fvatclass;
  int? _vatamountpercent;
  dynamic _isresellerprogramenabled;
  String? _keywordsearch;
  dynamic _comments;
  int? _isactive;
  int? _addcolnumber1;
  dynamic _addcolnumber2;
  dynamic _addcolvarchar1;
  String? _addcolvarchar2;
  int? _fsscreatedby;
  String? _sscreatedon;
  int? _fssmodifiedby;
  String? _ssmodifiedon;
  dynamic _fsscompanyno;
  dynamic _webarticle;
  String? _urlslug;
  String? _promotionalmsg;
  int? _totalFreeStock;
  int? _isWish;

  int? get pkno => _pkno;
  int? get fprdmastersetupno => _fprdmastersetupno;
  int? get code => _code;
  String? get brand => _brand;
  String? get model => _model;
  String? get compositecode => _compositecode;
  String? get variantname => _variantname;
  String? get variantcustomsname => _variantcustomsname;
  int? get fsizeno => _fsizeno;
  String? get sizename => _sizename;
  int? get fcolorno => _fcolorno;
  String? get color => _color;
  int? get mktcode => _mktcode;
  String? get mrkidcompositecode => _mrkidcompositecode;
  String? get hscode => _hscode;
  String? get barcode => _barcode;
  int? get isbarcodebymfg => _isbarcodebymfg;
  String? get narration => _narration;
  int? get fprimaryimgvariantid => _fprimaryimgvariantid;
  String? get primaryimgrelativepath => _primaryimgrelativepath;
  double? get regularprice => _regularprice;
  double? get installmentprice => _installmentprice;
  double? get seafreightcharge => _seafreightcharge;
  double? get airfreightcharge => _airfreightcharge;
  String? get preferredshippingmethod => _preferredshippingmethod;
  double? get localpostage => _localpostage;
  double? get interdistrictpostage => _interdistrictpostage;
  int? get fvatclass => _fvatclass;
  int? get vatamountpercent => _vatamountpercent;
  dynamic get isresellerprogramenabled => _isresellerprogramenabled;
  String? get keywordsearch => _keywordsearch;
  dynamic get comments => _comments;
  int? get isactive => _isactive;
  int? get addcolnumber1 => _addcolnumber1;
  dynamic get addcolnumber2 => _addcolnumber2;
  dynamic get addcolvarchar1 => _addcolvarchar1;
  String? get addcolvarchar2 => _addcolvarchar2;
  int? get fsscreatedby => _fsscreatedby;
  String? get sscreatedon => _sscreatedon;
  int? get fssmodifiedby => _fssmodifiedby;
  String? get ssmodifiedon => _ssmodifiedon;
  dynamic get fsscompanyno => _fsscompanyno;
  dynamic get webarticle => _webarticle;
  String? get urlslug => _urlslug;
  String? get promotionalmsg => _promotionalmsg;
  int? get totalFreeStock => _totalFreeStock;
  int? get isWish => _isWish;

  set promotionalmsg(String? value) {
    _promotionalmsg = value;
  }

  set pkno(int? value) {
    _pkno = value;
  }

  set totalFreeStock(int? value) {
    _totalFreeStock = value;
  }

  Product(
      {int? pkno,
      int? fprdmastersetupno,
      int? code,
      String? brand,
      String? model,
      String? compositecode,
      String? variantname,
      String? variantcustomsname,
      int? fsizeno,
      String? sizename,
      int? fcolorno,
      String? color,
      int? mktcode,
      String? mrkidcompositecode,
      String? hscode,
      String? barcode,
      int? isbarcodebymfg,
      String? narration,
      int? fprimaryimgvariantid,
      String? primaryimgrelativepath,
      double? regularprice,
      double? installmentprice,
      double? seafreightcharge,
      double? airfreightcharge,
      String? preferredshippingmethod,
      double? localpostage,
      double? interdistrictpostage,
      int? fvatclass,
      int? vatamountpercent,
      dynamic isresellerprogramenabled,
      String? keywordsearch,
      dynamic comments,
      int? isactive,
      int? addcolnumber1,
      dynamic addcolnumber2,
      dynamic addcolvarchar1,
      String? addcolvarchar2,
      int? fsscreatedby,
      String? sscreatedon,
      int? fssmodifiedby,
      String? ssmodifiedon,
      dynamic fsscompanyno,
      dynamic webarticle,
      String? urlslug,
      String? promotionalmsg,
      int? isWish,
      int? totalFreeStock}) {
    _pkno = pkno;
    _fprdmastersetupno = fprdmastersetupno;
    _code = code;
    _brand = brand;
    _model = model;
    _compositecode = compositecode;
    _variantname = variantname;
    _variantcustomsname = variantcustomsname;
    _fsizeno = fsizeno;
    _sizename = sizename;
    _fcolorno = fcolorno;
    _color = color;
    _mktcode = mktcode;
    _mrkidcompositecode = mrkidcompositecode;
    _hscode = hscode;
    _barcode = barcode;
    _isbarcodebymfg = isbarcodebymfg;
    _narration = narration;
    _fprimaryimgvariantid = fprimaryimgvariantid;
    _primaryimgrelativepath = primaryimgrelativepath;
    _regularprice = regularprice;
    _installmentprice = installmentprice;
    _seafreightcharge = seafreightcharge;
    _airfreightcharge = airfreightcharge;
    _preferredshippingmethod = preferredshippingmethod;
    _localpostage = localpostage;
    _interdistrictpostage = interdistrictpostage;
    _fvatclass = fvatclass;
    _vatamountpercent = vatamountpercent;
    _isresellerprogramenabled = isresellerprogramenabled;
    _keywordsearch = keywordsearch;
    _comments = comments;
    _isactive = isactive;
    _addcolnumber1 = addcolnumber1;
    _addcolnumber2 = addcolnumber2;
    _addcolvarchar1 = addcolvarchar1;
    _addcolvarchar2 = addcolvarchar2;
    _fsscreatedby = fsscreatedby;
    _sscreatedon = sscreatedon;
    _fssmodifiedby = fssmodifiedby;
    _ssmodifiedon = ssmodifiedon;
    _fsscompanyno = fsscompanyno;
    _webarticle = webarticle;
    _urlslug = urlslug;
    _promotionalmsg = promotionalmsg;
    _isWish = isWish;
    _totalFreeStock = totalFreeStock;
  }

  Product.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _fprdmastersetupno = json["F_PRD_MASTER_SETUP_NO"];
    _code = json["CODE"];
    _brand = json["BRAND"];
    _model = json["MODEL"];
    _compositecode = json["COMPOSITE_CODE"];
    _variantname = json["VARIANT_NAME"];
    _variantcustomsname = json["VARIANT_CUSTOMS_NAME"];
    _fsizeno = json["F_SIZE_NO"];
    _sizename = json["SIZE_NAME"];
    _fcolorno = json["F_COLOR_NO"];
    _color = json["COLOR"];
    _mktcode = json["MKT_CODE"];
    _mrkidcompositecode = json["MRK_ID_COMPOSITE_CODE"];
    _hscode = json["HS_CODE"];
    _barcode = json["BARCODE"];
    _isbarcodebymfg = json["IS_BARCODE_BY_MFG"];
    _narration = json["NARRATION"];
    _fprimaryimgvariantid = json["F_PRIMARY_IMG_VARIANT_ID"];
    _primaryimgrelativepath = json["PRIMARY_IMG_RELATIVE_PATH"];
    _regularprice = json["REGULAR_PRICE"] is int
        ? (json['REGULAR_PRICE'] as int).toDouble()
        : json['REGULAR_PRICE'];
    _installmentprice = json["INSTALLMENT_PRICE"] is int
        ? (json['INSTALLMENT_PRICE'] as int).toDouble()
        : json['INSTALLMENT_PRICE'];
    _seafreightcharge = json["SEA_FREIGHT_CHARGE"] is int
        ? (json['SEA_FREIGHT_CHARGE'] as int).toDouble()
        : json['SEA_FREIGHT_CHARGE'];
    _airfreightcharge = json["AIR_FREIGHT_CHARGE"] is int
        ? (json['AIR_FREIGHT_CHARGE'] as int).toDouble()
        : json['AIR_FREIGHT_CHARGE'];
    _preferredshippingmethod = json["PREFERRED_SHIPPING_METHOD"];
    _localpostage = json["LOCAL_POSTAGE"] is int
        ? (json['LOCAL_POSTAGE'] as int).toDouble()
        : json['LOCAL_POSTAGE'];
    _interdistrictpostage = json["INTER_DISTRICT_POSTAGE"] is int
        ? (json['INTER_DISTRICT_POSTAGE'] as int).toDouble()
        : json['INTER_DISTRICT_POSTAGE'];
    _fvatclass = json["F_VAT_CLASS"];
    _vatamountpercent = json["VAT_AMOUNT_PERCENT"];
    _isresellerprogramenabled = json["IS_RESELLER_PROGRAM_ENABLED"];
    _keywordsearch = json["KEYWORD_SEARCH"];
    _comments = json["COMMENTS"];
    _isactive = json["IS_ACTIVE"];
    _addcolnumber1 = json["ADD_COL_NUMBER_1"];
    _addcolnumber2 = json["ADD_COL_NUMBER_2"];
    _addcolvarchar1 = json["ADD_COL_VARCHAR_1"];
    _addcolvarchar2 = json["ADD_COL_VARCHAR_2"];
    _fsscreatedby = json["F_SS_CREATED_BY"];
    _sscreatedon = json["SS_CREATED_ON"];
    _fssmodifiedby = json["F_SS_MODIFIED_BY"];
    _ssmodifiedon = json["SS_MODIFIED_ON"];
    _fsscompanyno = json["F_SS_COMPANY_NO"];
    _webarticle = json["WEB_ARTICLE"];
    _urlslug = json["URL_SLUG"];
    _promotionalmsg = json["PROMOTIONAL_MESSAGE"];
    _isWish = json["isWish"];
    _totalFreeStock = json["TOTAL_FREE_STOCK"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["F_PRD_MASTER_SETUP_NO"] = _fprdmastersetupno;
    map["CODE"] = _code;
    map["BRAND"] = _brand;
    map["MODEL"] = _model;
    map["COMPOSITE_CODE"] = _compositecode;
    map["VARIANT_NAME"] = _variantname;
    map["VARIANT_CUSTOMS_NAME"] = _variantcustomsname;
    map["F_SIZE_NO"] = _fsizeno;
    map["SIZE_NAME"] = _sizename;
    map["F_COLOR_NO"] = _fcolorno;
    map["COLOR"] = _color;
    map["MKT_CODE"] = _mktcode;
    map["MRK_ID_COMPOSITE_CODE"] = _mrkidcompositecode;
    map["HS_CODE"] = _hscode;
    map["BARCODE"] = _barcode;
    map["IS_BARCODE_BY_MFG"] = _isbarcodebymfg;
    map["NARRATION"] = _narration;
    map["F_PRIMARY_IMG_VARIANT_ID"] = _fprimaryimgvariantid;
    map["PRIMARY_IMG_RELATIVE_PATH"] = _primaryimgrelativepath;
    map["REGULAR_PRICE"] = _regularprice;
    map["INSTALLMENT_PRICE"] = _installmentprice;
    map["SEA_FREIGHT_CHARGE"] = _seafreightcharge;
    map["AIR_FREIGHT_CHARGE"] = _airfreightcharge;
    map["PREFERRED_SHIPPING_METHOD"] = _preferredshippingmethod;
    map["LOCAL_POSTAGE"] = _localpostage;
    map["INTER_DISTRICT_POSTAGE"] = _interdistrictpostage;
    map["F_VAT_CLASS"] = _fvatclass;
    map["VAT_AMOUNT_PERCENT"] = _vatamountpercent;
    map["IS_RESELLER_PROGRAM_ENABLED"] = _isresellerprogramenabled;
    map["KEYWORD_SEARCH"] = _keywordsearch;
    map["COMMENTS"] = _comments;
    map["IS_ACTIVE"] = _isactive;
    map["ADD_COL_NUMBER_1"] = _addcolnumber1;
    map["ADD_COL_NUMBER_2"] = _addcolnumber2;
    map["ADD_COL_VARCHAR_1"] = _addcolvarchar1;
    map["ADD_COL_VARCHAR_2"] = _addcolvarchar2;
    map["F_SS_CREATED_BY"] = _fsscreatedby;
    map["SS_CREATED_ON"] = _sscreatedon;
    map["F_SS_MODIFIED_BY"] = _fssmodifiedby;
    map["SS_MODIFIED_ON"] = _ssmodifiedon;
    map["F_SS_COMPANY_NO"] = _fsscompanyno;
    map["WEB_ARTICLE"] = _webarticle;
    map["URL_SLUG"] = _urlslug;
    map["PROMOTIONAL_MESSAGE"];
    map["isWish"] = _isWish;
    map["TOTAL_FREE_STOCK"] = _totalFreeStock;
    return map;
  }

  set fprdmastersetupno(int? value) {
    _fprdmastersetupno = value;
  }

  set code(int? value) {
    _code = value;
  }

  set brand(String? value) {
    _brand = value;
  }

  set model(String? value) {
    _model = value;
  }

  set compositecode(String? value) {
    _compositecode = value;
  }

  set variantname(String? value) {
    _variantname = value;
  }

  set variantcustomsname(String? value) {
    _variantcustomsname = value;
  }

  set fsizeno(int? value) {
    _fsizeno = value;
  }

  set sizename(String? value) {
    _sizename = value;
  }

  set fcolorno(int? value) {
    _fcolorno = value;
  }

  set color(String? value) {
    _color = value;
  }

  set mktcode(int? value) {
    _mktcode = value;
  }

  set mrkidcompositecode(String? value) {
    _mrkidcompositecode = value;
  }

  set hscode(String? value) {
    _hscode = value;
  }

  set barcode(String? value) {
    _barcode = value;
  }

  set isbarcodebymfg(int? value) {
    _isbarcodebymfg = value;
  }

  set narration(String? value) {
    _narration = value;
  }

  set fprimaryimgvariantid(int? value) {
    _fprimaryimgvariantid = value;
  }

  set primaryimgrelativepath(String? value) {
    _primaryimgrelativepath = value;
  }

  set regularprice(double? value) {
    _regularprice = value;
  }

  set installmentprice(double? value) {
    _installmentprice = value;
  }

  set seafreightcharge(double? value) {
    _seafreightcharge = value;
  }

  set airfreightcharge(double? value) {
    _airfreightcharge = value;
  }

  set preferredshippingmethod(String? value) {
    _preferredshippingmethod = value;
  }

  set localpostage(double? value) {
    _localpostage = value;
  }

  set interdistrictpostage(double? value) {
    _interdistrictpostage = value;
  }

  set fvatclass(int? value) {
    _fvatclass = value;
  }

  set vatamountpercent(int? value) {
    _vatamountpercent = value;
  }

  set isresellerprogramenabled(dynamic value) {
    _isresellerprogramenabled = value;
  }

  set keywordsearch(String? value) {
    _keywordsearch = value;
  }

  set comments(dynamic value) {
    _comments = value;
  }

  set isactive(int? value) {
    _isactive = value;
  }

  set addcolnumber1(int? value) {
    _addcolnumber1 = value;
  }

  set addcolnumber2(dynamic value) {
    _addcolnumber2 = value;
  }

  set addcolvarchar1(dynamic value) {
    _addcolvarchar1 = value;
  }

  set addcolvarchar2(String? value) {
    _addcolvarchar2 = value;
  }

  set fsscreatedby(int? value) {
    _fsscreatedby = value;
  }

  set sscreatedon(String? value) {
    _sscreatedon = value;
  }

  set fssmodifiedby(int? value) {
    _fssmodifiedby = value;
  }

  set ssmodifiedon(String? value) {
    _ssmodifiedon = value;
  }

  set fsscompanyno(dynamic value) {
    _fsscompanyno = value;
  }

  set webarticle(dynamic value) {
    _webarticle = value;
  }

  set urlslug(String? value) {
    _urlslug = value;
  }

  set isWish(int? value) {
    _isWish = value;
  }
}

/// PK_NO : 30
/// F_PRD_MASTER_NO : 132
/// F_PRD_VARIANT_NO : 280
/// F_CUSTOMER_NO : 1282
/// CUSTOMER_NAME : "sifat ecommerce"
/// RATING : 5
/// REVIEW_TEXT : "WOW"
/// LANGUAGE_ID : 1
/// IS_FEATURE : 0
/// IS_ACTIVE : 0
/// F_SS_CREATED_BY : null
/// SS_CREATED_ON : "2021-04-13 12:07:57"
/// F_SS_MODIFIED_BY : null
/// SS_MODIFIED_ON : "2021-04-13 12:07:57"

/// PK_NO : 660
/// DEFAULT_NAME : "TOMMEE TIPPEE HEALTHCARE KIT"
/// F_PRD_SUB_CATEGORY_ID : 54
/// PRIMARY_IMG_RELATIVE_PATH : "/media/images/products/660/prod_27032021_605e91230e0ce.jpg"
/// CAT_SLUG : "baby"
/// SUB_SLUG : "baby-essentials"
/// average_rating : 0
/// URL : "baby/baby-essentials/tommee-tippee-healthcare-kit-black-9-baby-essentials"
/// PRICE : 89
/// review : 0

class Realated_product {
  int? _pkno;
  String? _variantname;
  int? _fprdsubcategoryid;
  String? _primaryimgrelativepath;
  String? _catslug;
  String? _subslug;
  int? _averageRating;
  String? _url;
  double? _price;
  int? _fprdvariantno;
  int? _isWish;
  int? _review;

  int? get pkno => _pkno;
  String? get variantname => _variantname;
  int? get fprdsubcategoryid => _fprdsubcategoryid;
  String? get primaryimgrelativepath => _primaryimgrelativepath;
  String? get catslug => _catslug;
  String? get subslug => _subslug;
  int? get averageRating => _averageRating;
  String? get url => _url;
  double? get price => _price;
  int? get review => _review;
  int? get fprdvariantno => _fprdvariantno;
  int? get isWish => _isWish;

  Realated_product(
      {int? pkno,
      String? variantname,
      int? fprdsubcategoryid,
      String? primaryimgrelativepath,
      String? catslug,
      String? subslug,
      int? averageRating,
      String? url,
      double? price,
      int? fprdvariantno,
      int? isWish,
      int? review}) {
    _pkno = pkno;
    _variantname = variantname;
    _fprdsubcategoryid = fprdsubcategoryid;
    _primaryimgrelativepath = primaryimgrelativepath;
    _catslug = catslug;
    _subslug = subslug;
    _averageRating = averageRating;
    _url = url;
    _price = price;
    _fprdvariantno = fprdvariantno;
    _isWish = isWish;
    _review = review;
  }

  Realated_product.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _variantname = json["VARIANT_NAME"];
    _fprdsubcategoryid = json["F_PRD_SUB_CATEGORY_ID"];
    _primaryimgrelativepath = json["PRIMARY_IMG_RELATIVE_PATH"];
    _catslug = json["CAT_SLUG"];
    _subslug = json["SUB_SLUG"];
    _averageRating = json["average_rating"];
    _url = json["URL"];
    _price = json["REGULAR_PRICE"] is int
        ? (json['REGULAR_PRICE'] as int).toDouble()
        : json['REGULAR_PRICE'];
    _fprdvariantno = json["F_PRD_VARIANT_NO"];
    _isWish = json["isWish"];
    _review = json["review"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["DEFAULT_NAME"] = _variantname;
    map["F_PRD_SUB_CATEGORY_ID"] = _fprdsubcategoryid;
    map["PRIMARY_IMG_RELATIVE_PATH"] = _primaryimgrelativepath;
    map["CAT_SLUG"] = _catslug;
    map["SUB_SLUG"] = _subslug;
    map["average_rating"] = _averageRating;
    map["URL"] = _url;
    map["PRICE"] = _price;
    map["review"] = _review;
    map["isWish"] = _isWish;
    map["F_PRD_VARIANT_NO"] = _fprdvariantno;
    return map;
  }
}

/// PRD_VARINAT_NAME : "COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923"
/// IG_CODE : "AM1102101"
/// INV_WAREHOUSE_NAME : "MY WAREHOUSE 02"
/// SKUID : "107101101101"
/// PREFERRED_SHIPPING_METHOD : "SEA"
/// SHIPMENT_TYPE : "SEA"
/// F_SHIPPMENT_NO : 2
/// CUSTOMER_PREFFERED_SHIPPING_METHOD : null
/// SCH_ARRIVAL_DATE : "2021-03-04"
/// SHIPMENT_STATUS : 80
/// FINAL_PREFFERED_SHIPPING_METHOD : "SEA"
/// BARCODE : "5021645050934"
/// F_PRD_VARIANT_NO : 280
/// TOTAL : 29
/// F_PRD_MASTER_NO : 132

class Stock_info {
  String? _prdvarinatname;
  String? _igcode;
  String? _invwarehousename;
  int? _finvwarehouseno;
  String? _skuid;
  String? _preferredshippingmethod;
  String? _shipmenttype;
  int? _fshippmentno;
  dynamic _customerprefferedshippingmethod;
  String? _scharrivaldate;
  int? _shipmentstatus;
  String? _finalprefferedshippingmethod;
  String? _barcode;
  int? _fprdvariantno;
  int? _total;
  int? _fprdmasterno;

  String? get prdvarinatname => _prdvarinatname;
  String? get igcode => _igcode;
  String? get invwarehousename => _invwarehousename;
  int? get finvwarehouseno => _finvwarehouseno;
  String? get skuid => _skuid;
  String? get preferredshippingmethod => _preferredshippingmethod;
  String? get shipmenttype => _shipmenttype;
  int? get fshippmentno => _fshippmentno;
  dynamic get customerprefferedshippingmethod =>
      _customerprefferedshippingmethod;
  String? get scharrivaldate => _scharrivaldate;
  int? get shipmentstatus => _shipmentstatus;
  String? get finalprefferedshippingmethod => _finalprefferedshippingmethod;
  String? get barcode => _barcode;
  int? get fprdvariantno => _fprdvariantno;
  int? get total => _total;
  int? get fprdmasterno => _fprdmasterno;

  set prdvarinatname(String? value) {
    _prdvarinatname = value;
  }

  set finvwarehouseno(int? value) {
    _finvwarehouseno = value;
  }

  Stock_info(
      {String? prdvarinatname,
      String? igcode,
      String? invwarehousename,
      int? finvwarehouseno,
      String? skuid,
      String? preferredshippingmethod,
      String? shipmenttype,
      int? fshippmentno,
      dynamic customerprefferedshippingmethod,
      String? scharrivaldate,
      int? shipmentstatus,
      String? finalprefferedshippingmethod,
      String? barcode,
      int? fprdvariantno,
      int? total,
      int? fprdmasterno}) {
    _prdvarinatname = prdvarinatname;
    _igcode = igcode;
    _invwarehousename = invwarehousename;
    _finvwarehouseno = finvwarehouseno;
    _skuid = skuid;
    _preferredshippingmethod = preferredshippingmethod;
    _shipmenttype = shipmenttype;
    _fshippmentno = fshippmentno;
    _customerprefferedshippingmethod = customerprefferedshippingmethod;
    _scharrivaldate = scharrivaldate;
    _shipmentstatus = shipmentstatus;
    _finalprefferedshippingmethod = finalprefferedshippingmethod;
    _barcode = barcode;
    _fprdvariantno = fprdvariantno;
    _total = total;
    _fprdmasterno = fprdmasterno;
  }

  Stock_info.fromJson(dynamic json) {
    _prdvarinatname = json["PRD_VARINAT_NAME"];
    _igcode = json["IG_CODE"];
    _invwarehousename = json["INV_WAREHOUSE_NAME"];
    _finvwarehouseno = json["F_INV_WAREHOUSE_NO"];
    _skuid = json["SKUID"];
    _preferredshippingmethod = json["PREFERRED_SHIPPING_METHOD"];
    _shipmenttype = json["SHIPMENT_TYPE"];
    _fshippmentno = json["F_SHIPPMENT_NO"];
    _customerprefferedshippingmethod =
        json["CUSTOMER_PREFFERED_SHIPPING_METHOD"];
    _scharrivaldate = json["SCH_ARRIVAL_DATE"];
    _shipmentstatus = json["SHIPMENT_STATUS"];
    _finalprefferedshippingmethod = json["FINAL_PREFFERED_SHIPPING_METHOD"];
    _barcode = json["BARCODE"];
    _fprdvariantno = json["F_PRD_VARIANT_NO"];
    _total = json["TOTAL"];
    _fprdmasterno = json["F_PRD_MASTER_NO"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PRD_VARINAT_NAME"] = _prdvarinatname;
    map["IG_CODE"] = _igcode;
    map["INV_WAREHOUSE_NAME"] = _invwarehousename;
    map["F_INV_WAREHOUSE_NO"] = _finvwarehouseno;
    map["SKUID"] = _skuid;
    map["PREFERRED_SHIPPING_METHOD"] = _preferredshippingmethod;
    map["SHIPMENT_TYPE"] = _shipmenttype;
    map["F_SHIPPMENT_NO"] = _fshippmentno;
    map["CUSTOMER_PREFFERED_SHIPPING_METHOD"] =
        _customerprefferedshippingmethod;
    map["SCH_ARRIVAL_DATE"] = _scharrivaldate;
    map["SHIPMENT_STATUS"] = _shipmentstatus;
    map["FINAL_PREFFERED_SHIPPING_METHOD"] = _finalprefferedshippingmethod;
    map["BARCODE"] = _barcode;
    map["F_PRD_VARIANT_NO"] = _fprdvariantno;
    map["TOTAL"] = _total;
    map["F_PRD_MASTER_NO"] = _fprdmasterno;
    return map;
  }

  set igcode(String? value) {
    _igcode = value;
  }

  set invwarehousename(String? value) {
    _invwarehousename = value;
  }

  set skuid(String? value) {
    _skuid = value;
  }

  set preferredshippingmethod(String? value) {
    _preferredshippingmethod = value;
  }

  set shipmenttype(String? value) {
    _shipmenttype = value;
  }

  set fshippmentno(int? value) {
    _fshippmentno = value;
  }

  set customerprefferedshippingmethod(dynamic value) {
    _customerprefferedshippingmethod = value;
  }

  set scharrivaldate(String? value) {
    _scharrivaldate = value;
  }

  set shipmentstatus(int? value) {
    _shipmentstatus = value;
  }

  set finalprefferedshippingmethod(String? value) {
    _finalprefferedshippingmethod = value;
  }

  set barcode(String? value) {
    _barcode = value;
  }

  set fprdvariantno(int? value) {
    _fprdvariantno = value;
  }

  set total(int? value) {
    _total = value;
  }

  set fprdmasterno(int? value) {
    _fprdmasterno = value;
  }
}

/// COLOR_NAME : "MINI MERMAIDS"
/// VARIANT_NAME : "COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923"
/// VARIANT_ICON : "/media/images/products/132/prod_30112020_5fc403b43b573.jpg"
/// REGULAR_PRICE : 179
/// URL_SLUG : "cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923"
/// URL : "baby/bag/cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923"
/// isActive : 1

class Product_color {
  String? _colorname;
  String? _variantname;
  String? _primary_img_relative_path;
  double? _regularprice;
  String? _urlslug;
  String? _url;
  int? _isActive;
  int? _isCommon;

  String? get colorname => _colorname;
  String? get variantname => _variantname;
  String? get primary_img_relative_path => _primary_img_relative_path;
  double? get regularprice => _regularprice;
  String? get urlslug => _urlslug;
  String? get url => _url;
  int? get isActive => _isActive;
  int? get isCommon => _isCommon;

  set colorname(String? value) {
    _colorname = value;
  }

  set isCommon(int? value) {
    _isCommon = value;
  }

  Product_color(
      {String? colorname,
      String? variantname,
      String? primary_img_relative_path,
      double? regularprice,
      String? urlslug,
      String? url,
      int? isCommon,
      int? isActive}) {
    _colorname = colorname;
    _variantname = variantname;
    _primary_img_relative_path = primary_img_relative_path;
    _regularprice = regularprice;
    _urlslug = urlslug;
    _url = url;
    _isCommon = isCommon;
    _isActive = isActive;
  }

  Product_color.fromJson(dynamic json) {
    _colorname = json["COLOR"];
    _variantname = json["VARIANT_NAME"];
    _primary_img_relative_path = json["PRIMARY_IMG_RELATIVE_PATH"];
    _regularprice = json["REGULAR_PRICE"] is int
        ? (json['REGULAR_PRICE'] as int).toDouble()
        : json['REGULAR_PRICE'];
    _urlslug = json["URL_SLUG"];
    _url = json["URL"];
    _isCommon = json["IS_COMMON"];
    _isActive = json["IS_ACTIVE"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["COLOR_NAME"] = _colorname;
    map["VARIANT_NAME"] = _variantname;
    map["VARIANT_ICON"] = _primary_img_relative_path;
    map["REGULAR_PRICE"] = _regularprice;
    map["URL_SLUG"] = _urlslug;
    map["URL"] = _url;
    map["IS_ACTIVE"] = _isActive;
    map["IS_COMMON"] = _isCommon;
    return map;
  }

  set variantname(String? value) {
    _variantname = value;
  }

  set primary_img_relative_path(String? value) {
    _primary_img_relative_path = value;
  }

  set regularprice(double? value) {
    _regularprice = value;
  }

  set urlslug(String? value) {
    _urlslug = value;
  }

  set url(String? value) {
    _url = value;
  }

  set isActive(int? value) {
    _isActive = value;
  }
}

/// SIZE_NAME : "ONE SIZE"
/// VARIANT_NAME : "COSATTO SUPA CHANGING BAG - MINI MERMAIDS - ONE SIZE - CT3923"
/// URL_SLUG : "cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923"
/// REGULAR_PRICE : 179
/// URL : "baby/bag/cosatto-supa-changing-bag-mini-mermaids-one-size-ct3923"
/// isActive : 1

class Product_size {
  String? _sizename;
  String? _variantname;
  String? _urlslug;
  double? _regularprice;
  String? _url;
  int? _isActive;
  int? _isCommon;

  String? get sizename => _sizename;
  String? get variantname => _variantname;
  String? get urlslug => _urlslug;
  double? get regularprice => _regularprice;
  String? get url => _url;
  int? get isActive => _isActive;
  int? get isCommon => _isCommon;

  set sizename(String? value) {
    _sizename = value;
  }

  set isCommon(int? value) {
    _isCommon = value;
  }

  Product_size(
      {String? sizename,
      String? variantname,
      String? urlslug,
      double? regularprice,
      String? url,
      int? isCommon,
      int? isActive}) {
    _sizename = sizename;
    _variantname = variantname;
    _urlslug = urlslug;
    _regularprice = regularprice;
    _url = url;
    _isActive = isActive;
    _isCommon = isCommon;
  }

  Product_size.fromJson(dynamic json) {
    _sizename = json["SIZE_NAME"];
    _variantname = json["VARIANT_NAME"];
    _urlslug = json["URL_SLUG"];
    _regularprice = json["REGULAR_PRICE"] is int
        ? (json['REGULAR_PRICE'] as int).toDouble()
        : json['REGULAR_PRICE'];
    _url = json["URL"];
    _isCommon = json["IS_COMMON"];
    _isActive = json["IS_ACTIVE"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["SIZE_NAME"] = _sizename;
    map["VARIANT_NAME"] = _variantname;
    map["URL_SLUG"] = _urlslug;
    map["REGULAR_PRICE"] = _regularprice;
    map["URL"] = _url;
    map["IS_ACTIVE"] = _isActive;
    map["IS_COMMON"] = _isCommon;
    return map;
  }

  set variantname(String? value) {
    _variantname = value;
  }

  set urlslug(String? value) {
    _urlslug = value;
  }

  set regularprice(double? value) {
    _regularprice = value;
  }

  set url(String? value) {
    _url = value;
  }

  set isActive(int? value) {
    _isActive = value;
  }
}

class Offer {
  String? _url;
  String? _bundleNamePublic;

  String? get bundleNamePublic => _bundleNamePublic;
  String? get url => _url;

  set url(String? value) {
    _url = value;
  }

  set bundleNamePublic(String? value) {
    _bundleNamePublic = value;
  }

  Offer({String? url, String? bundleNamePublic}) {
    _url = url;
    _bundleNamePublic = bundleNamePublic;
  }

  Offer.fromJson(dynamic json) {
    _url = json["URL"];
    _bundleNamePublic = json["BUNDLE_NAME_PUBLIC"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["URL"] = _url;
    map["BUNDLE_NAME_PUBLIC"] = _bundleNamePublic;
    return map;
  }
}
