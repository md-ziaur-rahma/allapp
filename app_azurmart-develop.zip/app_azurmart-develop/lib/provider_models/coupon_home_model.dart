// To parse this JSON data, do
//
//     final couponHomeModel = couponHomeModelFromJson(jsonString);

import 'dart:convert';

CouponHomeModel couponHomeModelFromJson(String str) => CouponHomeModel.fromJson(json.decode(str));

String couponHomeModelToJson(CouponHomeModel data) => json.encode(data.toJson());

class CouponHomeModel {
  CouponHomeModel({
    this.status,
    this.success,
    this.code,
    this.message,
    this.description,
    this.data,
    this.errors,
    this.api,
  });

  int? status;
  bool? success;
  int? code;
  String? message;
  String? description;
  Data? data;
  dynamic errors;
  Api? api;

  factory CouponHomeModel.fromJson(Map<String, dynamic> json) => CouponHomeModel(
    status: json["status"],
    success: json["success"],
    code: json["code"],
    message: json["message"],
    description: json["description"],
    data: Data.fromJson(json["data"]),
    errors: json["errors"],
    api: Api.fromJson(json["api"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "code": code,
    "message": message,
    "description": description,
    "data": data!.toJson(),
    "errors": errors,
    "api": api!.toJson(),
  };
}

class Api {
  Api({
    this.version,
  });

  String? version;

  factory Api.fromJson(Map<String, dynamic> json) => Api(
    version: json["version"],
  );

  Map<String, dynamic> toJson() => {
    "version": version,
  };
}

class Data {
  Data({
    this.title,
    this.isShow,
    this.coupons,
  });

  String? title;
  int? isShow;
  List<Coupon>? coupons;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    title: json["title"],
    isShow: json["is_show"],
    coupons: List<Coupon>.from(json["coupons"].map((x) => Coupon.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "title": title,
    "is_show": isShow,
    "coupons": List<dynamic>.from(coupons!.map((x) => x.toJson())),
  };
}

class Coupon {
  Coupon({
    this.couponCode,
    this.discount,
    this.couponType,
    this.variantName,
    this.regularPrice,
    this.thumbPath,
    this.primaryImgRelativePath,
    this.pkNo,
    this.urlSlug,
    this.totalFreeStock,
  });

  String? couponCode;
  double? discount;
  int? couponType;
  String? variantName;
  double? regularPrice;
  String? thumbPath;
  String? primaryImgRelativePath;
  int? pkNo;
  String? urlSlug;
  int? totalFreeStock;

  factory Coupon.fromJson(Map<String, dynamic> json) => Coupon(
    couponCode: json["COUPON_CODE"],
    discount: json["DISCOUNT"] is int
      ? (json['DISCOUNT'] as int).toDouble()
      : json['DISCOUNT'],
    couponType: json["COUPON_TYPE"],
    variantName: json["VARIANT_NAME"],
    regularPrice: json["REGULAR_PRICE"] is int
        ? (json['REGULAR_PRICE'] as int).toDouble()
        : json['REGULAR_PRICE'],
    thumbPath: json["THUMB_PATH"],
    primaryImgRelativePath: json["PRIMARY_IMG_RELATIVE_PATH"],
    pkNo: json["PK_NO"],
    urlSlug: json["URL_SLUG"],
    totalFreeStock: json["TOTAL_FREE_STOCK"],
  );

  Map<String, dynamic> toJson() => {
    "COUPON_CODE": couponCode,
    "DISCOUNT": discount,
    "COUPON_TYPE": couponType,
    "VARIANT_NAME": variantName,
    "REGULAR_PRICE": regularPrice,
    "THUMB_PATH": thumbPath,
    "PRIMARY_IMG_RELATIVE_PATH": primaryImgRelativePath,
    "PK_NO": pkNo,
    "URL_SLUG": urlSlug,
    "TOTAL_FREE_STOCK": totalFreeStock,
  };
}
