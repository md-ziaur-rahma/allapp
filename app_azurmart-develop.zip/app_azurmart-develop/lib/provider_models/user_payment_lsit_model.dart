// To parse this JSON data, do
//
//     final userPaymentModel = userPaymentModelFromJson(jsonString);

import 'dart:convert';

UserPaymentModel userPaymentModelFromJson(String str) => UserPaymentModel.fromJson(json.decode(str));

String userPaymentModelToJson(UserPaymentModel data) => json.encode(data.toJson());

class UserPaymentModel {
  UserPaymentModel({
    this.status,
    this.success,
    this.code,
    this.message,
    this.description,
    this.data,
    this.errors,
    this.api,
  });

  int? status;
  bool? success;
  int? code;
  String? message;
  String? description;
  List<Data>? data;
  dynamic errors;
  Api? api;

  factory UserPaymentModel.fromJson(Map<String, dynamic> json) => UserPaymentModel(
    status: json["status"],
    success: json["success"],
    code: json["code"],
    message: json["message"],
    description: json["description"],
    data: List<Data>.from(json["data"].map((x) => Data.fromJson(x))),
    errors: json["errors"],
    api: Api.fromJson(json["api"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "code": code,
    "message": message,
    "description": description,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
    "errors": errors,
    "api": api!.toJson(),
  };
}

class Api {
  Api({
    this.version,
  });

  String? version;

  factory Api.fromJson(Map<String, dynamic> json) => Api(
    version: json["version"],
  );

  Map<String, dynamic> toJson() => {
    "version": version,
  };
}

class Data {
  Data({
    this.pkNo,
    this.isMatched,
    this.code,
    this.paymentPkNo,
    this.fPaymentAccNo,
    this.mrAmount,
    this.paymentDate,
    this.type,
    this.order,
  });

  int? pkNo;
  int? isMatched;
  int? code;
  int? paymentPkNo;
  int? fPaymentAccNo;
  double? mrAmount;
  String? paymentDate;
  String? type;
  List<Order>? order;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    pkNo: json["PK_NO"],
    isMatched: json["IS_MATCHED"],
    code: json["CODE"],
    paymentPkNo: json["PAYMENT_PK_NO"],
    fPaymentAccNo: json["F_PAYMENT_ACC_NO"],
    mrAmount: json["MR_AMOUNT"] is int
      ? (json['MR_AMOUNT'] as int).toDouble()
      : json['MR_AMOUNT'],
    paymentDate: json["PAYMENT_DATE"],
    type: json["type"] == null ? null : json["type"],
    order: json["order"] != null ? List<Order>.from(json["order"].map((x) => Order.fromJson(x))) : json["order"],
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "IS_MATCHED": isMatched,
    "CODE": code,
    "PAYMENT_PK_NO": paymentPkNo,
    "F_PAYMENT_ACC_NO": fPaymentAccNo,
    "MR_AMOUNT": mrAmount,
    "PAYMENT_DATE": paymentDate,
    "type": type == null ? null : type,
    "order": order == null ? [] : List<dynamic>.from(order!.map((x) => x.toJson())),
  };
}

class Order {
  Order({
    this.orderNo,
    this.amount,
    this.fBookingNo,
  });

  String? orderNo;
  double? amount;
  int? fBookingNo;

  factory Order.fromJson(Map<String, dynamic> json) => Order(
    orderNo: json["ORDER_NO"],
    amount: json["AMOUNT"] is int
      ? (json['AMOUNT'] as int).toDouble()
      : json['AMOUNT'],
    fBookingNo: json["F_BOOKING_NO"],
  );

  Map<String, dynamic> toJson() => {
    "ORDER_NO": orderNo,
    "AMOUNT": amount,
    "F_BOOKING_NO": fBookingNo,
  };
}
