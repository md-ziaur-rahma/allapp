/// status : 1
/// success : true
/// code : 200
/// message : "Data is available !"
/// description : ""
/// data : [{"STATUS":1,"PK_NO":20,"IMAGE":"http://dev.ukshop.my/media/images/bundle/20/bundle_15042021_60771b1bc8aa3.jpg","BUNDLE_NAME_PUBLIC":"Le Creuset Mini Ramekin set 6 for 259","VALIDITY_FROM":"2021-02-01","VALIDITY_TO":"2021-12-31","F_A_LIST_NO":20,"F_B_LIST_NO":6,"F_BUNDLE_TYPE":8,"P_AMOUNT":259,"P2_AMOUNT":299,"R_AMOUNT":0,"URL_SLUG":"le-creuset-mini-ramekin-set-6-for-259","URL":"offer/le-creuset-mini-ramekin-set-6-for-259/20"},null]
/// errors : null
/// api : {"version":"1.0"}

class OfferModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  List<Data>? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  List<Data>? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;


  set status(int? value) {
    _status = value;
  }

  OfferModel({
      int? status, 
      bool? success, 
      int? code, 
      String? message, 
      String? description, 
      List<Data>? data, 
      dynamic errors, 
      Api? api}){
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
}

  OfferModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    if (json["data"] != null) {
      _data = [];
      json["data"].forEach((v) {
        _data!.add(Data.fromJson(v));
      });
    }
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.map((v) => v.toJson()).toList();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }

  set success(bool? value) {
    _success = value;
  }

  set code(int? value) {
    _code = value;
  }

  set message(String? value) {
    _message = value;
  }

  set description(String? value) {
    _description = value;
  }

  set data(List<Data>? value) {
    _data = value;
  }

  set errors(dynamic value) {
    _errors = value;
  }

  set api(Api? value) {
    _api = value;
  }
}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;

  Api({
      String? version}){
    _version = version;
}

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }

}

/// STATUS : 1
/// PK_NO : 20
/// IMAGE : "http://dev.ukshop.my/media/images/bundle/20/bundle_15042021_60771b1bc8aa3.jpg"
/// BUNDLE_NAME_PUBLIC : "Le Creuset Mini Ramekin set 6 for 259"
/// VALIDITY_FROM : "2021-02-01"
/// VALIDITY_TO : "2021-12-31"
/// F_A_LIST_NO : 20
/// F_B_LIST_NO : 6
/// F_BUNDLE_TYPE : 8
/// P_AMOUNT : 259
/// P2_AMOUNT : 299
/// R_AMOUNT : 0
/// URL_SLUG : "le-creuset-mini-ramekin-set-6-for-259"
/// URL : "offer/le-creuset-mini-ramekin-set-6-for-259/20"

class Data {
  int? _status;
  int? _pkno;
  String? _image;
  String? _bundlenamepublic;
  String? _validityfrom;
  String? _validityto;
  int? _falistno;
  int? _fblistno;
  int? _fbundletype;
  int? _pamount;
  int? _p2amount;
  int? _ramount;
  String? _urlslug;
  String? _url;

  int? get status => _status;
  int? get pkno => _pkno;
  String? get image => _image;
  String? get bundlenamepublic => _bundlenamepublic;
  String? get validityfrom => _validityfrom;
  String? get validityto => _validityto;
  int? get falistno => _falistno;
  int? get fblistno => _fblistno;
  int? get fbundletype => _fbundletype;
  int? get pamount => _pamount;
  int? get p2amount => _p2amount;
  int? get ramount => _ramount;
  String? get urlslug => _urlslug;
  String? get url => _url;


  set status(int? value) {
    _status = value;
  }

  Data({
      int? status, 
      int? pkno, 
      String? image, 
      String? bundlenamepublic, 
      String? validityfrom, 
      String? validityto, 
      int? falistno, 
      int? fblistno, 
      int? fbundletype, 
      int? pamount, 
      int? p2amount, 
      int? ramount, 
      String? urlslug, 
      String? url}){
    _status = status;
    _pkno = pkno;
    _image = image;
    _bundlenamepublic = bundlenamepublic;
    _validityfrom = validityfrom;
    _validityto = validityto;
    _falistno = falistno;
    _fblistno = fblistno;
    _fbundletype = fbundletype;
    _pamount = pamount;
    _p2amount = p2amount;
    _ramount = ramount;
    _urlslug = urlslug;
    _url = url;
}

  Data.fromJson(dynamic json) {
    _status = json["STATUS"];
    _pkno = json["PK_NO"];
    _image = json["IMAGE"];
    _bundlenamepublic = json["BUNDLE_NAME_PUBLIC"];
    _validityfrom = json["VALIDITY_FROM"];
    _validityto = json["VALIDITY_TO"];
    _falistno = json["F_A_LIST_NO"];
    _fblistno = json["F_B_LIST_NO"];
    _fbundletype = json["F_BUNDLE_TYPE"];
    _pamount = json["P_AMOUNT"];
    _p2amount = json["P2_AMOUNT"];
    _ramount = json["R_AMOUNT"];
    _urlslug = json["URL_SLUG"];
    _url = json["URL"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["STATUS"] = _status;
    map["PK_NO"] = _pkno;
    map["IMAGE"] = _image;
    map["BUNDLE_NAME_PUBLIC"] = _bundlenamepublic;
    map["VALIDITY_FROM"] = _validityfrom;
    map["VALIDITY_TO"] = _validityto;
    map["F_A_LIST_NO"] = _falistno;
    map["F_B_LIST_NO"] = _fblistno;
    map["F_BUNDLE_TYPE"] = _fbundletype;
    map["P_AMOUNT"] = _pamount;
    map["P2_AMOUNT"] = _p2amount;
    map["R_AMOUNT"] = _ramount;
    map["URL_SLUG"] = _urlslug;
    map["URL"] = _url;
    return map;
  }

  set pkno(int? value) {
    _pkno = value;
  }

  set image(String? value) {
    _image = value;
  }

  set bundlenamepublic(String? value) {
    _bundlenamepublic = value;
  }

  set validityfrom(String? value) {
    _validityfrom = value;
  }

  set validityto(String? value) {
    _validityto = value;
  }

  set falistno(int? value) {
    _falistno = value;
  }

  set fblistno(int? value) {
    _fblistno = value;
  }

  set fbundletype(int? value) {
    _fbundletype = value;
  }

  set pamount(int? value) {
    _pamount = value;
  }

  set p2amount(int? value) {
    _p2amount = value;
  }

  set ramount(int? value) {
    _ramount = value;
  }

  set urlslug(String? value) {
    _urlslug = value;
  }

  set url(String? value) {
    _url = value;
  }
}