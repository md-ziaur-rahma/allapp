class AppSettingModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  Data? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  Data? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  AppSettingModel(
      {int? status,
      bool? success,
      int? code,
      String? message,
      String? description,
      Data? data,
      dynamic errors,
      Api? api}) {
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
  }

  AppSettingModel.fromJson(dynamic json) {
    _status = json['status'];
    _success = json['success'];
    _code = json['code'];
    _message = json['message'];
    _description = json['description'];
    _data = json['data'] != null ? Data.fromJson(json['data']) : null;
    _errors = json['errors'];
    _api = json['api'] != null ? Api.fromJson(json['api']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['status'] = _status;
    map['success'] = _success;
    map['code'] = _code;
    map['message'] = _message;
    map['description'] = _description;
    if (_data != null) {
      map['data'] = _data!.toJson();
    }
    map['errors'] = _errors;
    if (_api != null) {
      map['api'] = _api!.toJson();
    }
    return map;
  }
}

class Api {
  String? _version;

  String? get version => _version;

  Api({String? version}) {
    _version = version;
  }

  Api.fromJson(dynamic json) {
    _version = json['version'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['version'] = _version;
    return map;
  }
}

class Data {
  int? _pkno;
  String? _title;
  String? _description;
  String? _headerlogo;
  String? _footerlogo;
  String? _applogo;
  String? _metaimage;
  String? _favicon;
  String? _phone1;
  String? _phone2;
  String? _email1;
  String? _email2;
  String? _hqaddress;
  String? _url;
  String? _facebookurl;
  String? _twitterurl;
  String? _instagramurl;
  String? _youtubeurl;
  String? _pinteresturl;
  String? _whatsapp;
  String? _fbappid;
  String? _facebooksecretid;
  String? _googlemap;
  String? _googleappid;
  String? _googleclientid;
  String? _googleclientsecret;
  String? _androidapplink;
  String? _androidappversion;
  String? _analyticid;
  int? _languageid;
  String? _iphoneapplink;
  String? _iphoneappversion;
  String? _copyrighttext;
  String? _shippingreturn;
  String? _latitude;
  String? _longitude;

  int? get pkno => _pkno;
  String? get title => _title;
  String? get description => _description;
  String? get headerlogo => _headerlogo;
  String? get footerlogo => _footerlogo;
  String? get applogo => _applogo;
  String? get metaimage => _metaimage;
  String? get favicon => _favicon;
  String? get phone1 => _phone1;
  String? get phone2 => _phone2;
  String? get email1 => _email1;
  String? get email2 => _email2;
  String? get hqaddress => _hqaddress;
  String? get url => _url;
  String? get facebookurl => _facebookurl;
  String? get twitterurl => _twitterurl;
  String? get instagramurl => _instagramurl;
  String? get youtubeurl => _youtubeurl;
  String? get pinteresturl => _pinteresturl;
  String? get whatsapp => _whatsapp;
  String? get fbappid => _fbappid;
  String? get facebooksecretid => _facebooksecretid;
  String? get googlemap => _googlemap;
  String? get googleappid => _googleappid;
  String? get googleclientid => _googleclientid;
  String? get googleclientsecret => _googleclientsecret;
  String? get androidapplink => _androidapplink;
  String? get androidappversion => _androidappversion;
  String? get analyticid => _analyticid;
  int? get languageid => _languageid;
  String? get iphoneapplink => _iphoneapplink;
  String? get iphoneappversion => _iphoneappversion;
  String? get copyrighttext => _copyrighttext;
  String? get shippingreturn => _shippingreturn;
  String? get latitude => _latitude;
  String? get longitude => _longitude;

  Data(
      {int? pkno,
      String? title,
      String? description,
      String? headerlogo,
      String? footerlogo,
      String? applogo,
      String? metaimage,
      String? favicon,
      String? phone1,
      String? phone2,
      String? email1,
      String? email2,
      String? hqaddress,
      String? url,
      String? facebookurl,
      String? twitterurl,
      String? instagramurl,
      String? youtubeurl,
      String? pinteresturl,
      String? whatsapp,
      String? fbappid,
      String? facebooksecretid,
      String? googlemap,
      String? googleappid,
      String? googleclientid,
      String? googleclientsecret,
      String? androidapplink,
      String? androidappversion,
      String? analyticid,
      int? languageid,
      String? iphoneapplink,
      String? iphoneappversion,
      String? shippingreturn,
      String? latitude,
      String? longitude,
      String? copyrighttext}) {
    _pkno = pkno;
    _title = title;
    _description = description;
    _headerlogo = headerlogo;
    _footerlogo = footerlogo;
    _applogo = applogo;
    _metaimage = metaimage;
    _favicon = favicon;
    _phone1 = phone1;
    _phone2 = phone2;
    _email1 = email1;
    _email2 = email2;
    _hqaddress = hqaddress;
    _url = url;
    _facebookurl = facebookurl;
    _twitterurl = twitterurl;
    _instagramurl = instagramurl;
    _youtubeurl = youtubeurl;
    _pinteresturl = pinteresturl;
    _whatsapp = whatsapp;
    _fbappid = fbappid;
    _facebooksecretid = facebooksecretid;
    _googlemap = googlemap;
    _googleappid = googleappid;
    _googleclientid = googleclientid;
    _googleclientsecret = googleclientsecret;
    _androidapplink = androidapplink;
    _androidappversion = androidappversion;
    _analyticid = analyticid;
    _languageid = languageid;
    _iphoneapplink = iphoneapplink;
    _iphoneappversion = iphoneappversion;
    _copyrighttext = copyrighttext;
    _latitude = latitude;
    _longitude = longitude;
    _shippingreturn = shippingreturn;
  }

  Data.fromJson(dynamic json) {
    _pkno = json['PK_NO'];
    _title = json['TITLE'];
    _description = json['DESCRIPTION'];
    _headerlogo = json['HEADER_LOGO'];
    _footerlogo = json['FOOTER_LOGO'];
    _applogo = json['APP_LOGO'];
    _metaimage = json['META_IMAGE'];
    _favicon = json['FAVICON'];
    _phone1 = json['PHONE_1'];
    _phone2 = json['PHONE_2'];
    _email1 = json['EMAIL_1'];
    _email2 = json['EMAIL_2'];
    _hqaddress = json['HQ_ADDRESS'];
    _url = json['URL'];
    _facebookurl = json['FACEBOOK_URL'];
    _twitterurl = json['TWITTER_URL'];
    _instagramurl = json['INSTAGRAM_URL'];
    _youtubeurl = json['YOUTUBE_URL'];
    _pinteresturl = json['PINTEREST_URL'];
    _whatsapp = json['WHATS_APP'];
    _fbappid = json['FB_APP_ID'];
    _facebooksecretid = json['FACEBOOK_SECRET_ID'];
    _googlemap = json['GOOGLE_MAP'];
    _googleappid = json['GOOGLE_APP_ID'];
    _googleclientid = json['GOOGLE_CLIENT_ID'];
    _googleclientsecret = json['GOOGLE_CLIENT_SECRET'];
    _androidapplink = json['ANDROID_APP_LINK'];
    _androidappversion = json['ANDROID_APP_VERSION'];
    _analyticid = json['ANALYTIC_ID'];
    _languageid = json['LANGUAGE_ID'];
    _iphoneapplink = json['IPHONE_APP_LINK'];
    _iphoneappversion = json['IPHONE_APP_VERSION'];
    _copyrighttext = json['COPYRIGHT_TEXT'];
    _shippingreturn = json["SHIPPING_RETURN"];
    _latitude = json["LATITUDE"];
    _longitude = json["LONGITUDE"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['PK_NO'] = _pkno;
    map['TITLE'] = _title;
    map['DESCRIPTION'] = _description;
    map['HEADER_LOGO'] = _headerlogo;
    map['FOOTER_LOGO'] = _footerlogo;
    map['APP_LOGO'] = _applogo;
    map['META_IMAGE'] = _metaimage;
    map['FAVICON'] = _favicon;
    map['PHONE_1'] = _phone1;
    map['PHONE_2'] = _phone2;
    map['EMAIL_1'] = _email1;
    map['EMAIL_2'] = _email2;
    map['HQ_ADDRESS'] = _hqaddress;
    map['URL'] = _url;
    map['FACEBOOK_URL'] = _facebookurl;
    map['TWITTER_URL'] = _twitterurl;
    map['INSTAGRAM_URL'] = _instagramurl;
    map['YOUTUBE_URL'] = _youtubeurl;
    map['PINTEREST_URL'] = _pinteresturl;
    map['WHATS_APP'] = _whatsapp;
    map['FB_APP_ID'] = _fbappid;
    map['FACEBOOK_SECRET_ID'] = _facebooksecretid;
    map['GOOGLE_MAP'] = _googlemap;
    map['GOOGLE_APP_ID'] = _googleappid;
    map['GOOGLE_CLIENT_ID'] = _googleclientid;
    map['GOOGLE_CLIENT_SECRET'] = _googleclientsecret;
    map['ANDROID_APP_LINK'] = _androidapplink;
    map['ANDROID_APP_VERSION'] = _androidappversion;
    map['ANALYTIC_ID'] = _analyticid;
    map['LANGUAGE_ID'] = _languageid;
    map['IPHONE_APP_LINK'] = _iphoneapplink;
    map['IPHONE_APP_VERSION'] = _iphoneappversion;
    map['COPYRIGHT_TEXT'] = _copyrighttext;
    map["SHIPPING_RETURN"] = _shippingreturn;
    map['LATITUDE'] = _latitude;
    map["LONGITUDE"] = _longitude;
    return map;
  }
}
