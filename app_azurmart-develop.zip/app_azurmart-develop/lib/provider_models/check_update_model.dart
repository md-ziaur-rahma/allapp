import 'dart:convert';

CheckUpdateModel checkUpdateModelFromJson(String str) => CheckUpdateModel.fromJson(json.decode(str));

String checkUpdateModelToJson(CheckUpdateModel data) => json.encode(data.toJson());

class CheckUpdateModel {
  CheckUpdateModel({
    this.status,
    this.success,
    this.code,
    this.message,
    this.description,
    this.data,
    this.errors,
    this.api,
  });

  int? status;
  bool? success;
  int? code;
  String? message;
  String? description;
  Data? data;
  dynamic errors;
  Api? api;

  factory CheckUpdateModel.fromJson(Map<String, dynamic> json) => CheckUpdateModel(
    status: json["status"],
    success: json["success"],
    code: json["code"],
    message: json["message"],
    description: json["description"],
    data: Data.fromJson(json["data"]),
    errors: json["errors"],
    api: Api.fromJson(json["api"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "code": code,
    "message": message,
    "description": description,
    "data": data!.toJson(),
    "errors": errors,
    "api": api!.toJson(),
  };
}

class Api {
  Api({
    this.version,
  });

  String? version;

  factory Api.fromJson(Map<String, dynamic> json) => Api(
    version: json["version"],
  );

  Map<String, dynamic> toJson() => {
    "version": version,
  };
}

class Data {
  Data({
    this.playStoreLink,
    this.appStoreLink,
    this.androidVersion,
    this.androidVersionName,
    this.iosVersion,
    this.iosVersionName,
    this.isMandatory,
  });

  String? playStoreLink;
  String? appStoreLink;
  String? androidVersion;
  String? iosVersion;
  String? androidVersionName;
  String? iosVersionName;
  int? isMandatory;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    playStoreLink: json["ANDROID_APP_LINK"],
    appStoreLink: json["IPHONE_APP_LINK"],
    androidVersion: json["ANDROID_APP_VERSION"],
    androidVersionName: json["ANDROID_VERSION_NAME"],
    iosVersion: json["IPHONE_APP_VERSION"],
    iosVersionName: json["IPHONE_VERSION_NAME"],
    isMandatory: json["APP_UPDATE_MANDATORY"],
  );

  Map<String, dynamic> toJson() => {
    "ANDROID_APP_LINK": playStoreLink,
    "IPHONE_APP_LINK": appStoreLink,
    "ANDROID_APP_VERSION": androidVersion,
    "ANDROID_VERSION_NAME": androidVersionName,
    "IPHONE_APP_VERSION": iosVersion,
    "IPHONE_VERSION_NAME": iosVersionName,
    "APP_UPDATE_MANDATORY": isMandatory,
  };
}
