class OrderListModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  List<Data>? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  List<Data>? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  OrderListModel(
      {int? status,
      bool? success,
      int? code,
      String? message,
      String? description,
      List<Data>? data,
      dynamic errors,
      Api? api}) {
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
  }

  OrderListModel.fromJson(dynamic json) {
    _status = json['status'];
    _success = json['success'];
    _code = json['code'];
    _message = json['message'];
    _description = json['description'];
    if (json['data'] != null) {
      _data = [];
      json['data'].forEach((v) {
        _data!.add(Data.fromJson(v));
      });
    }
    _errors = json['errors'];
    _api = json['api'] != null ? Api.fromJson(json['api']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['status'] = _status;
    map['success'] = _success;
    map['code'] = _code;
    map['message'] = _message;
    map['description'] = _description;
    if (_data != null) {
      map['data'] = _data!.map((v) => v.toJson()).toList();
    }
    map['errors'] = _errors;
    if (_api != null) {
      map['api'] = _api!.toJson();
    }
    return map;
  }
}

class Api {
  String? _version;

  String? get version => _version;

  Api({String? version}) {
    _version = version;
  }

  Api.fromJson(dynamic json) {
    _version = json['version'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['version'] = _version;
    return map;
  }
}

class Data {
  int? _pkno;
  int? _fbookingno;
  int? _fcustomerno;
  dynamic _fresellerno;
  String? _customername;
  int? _isready;
  String? _sscreatedon;
  String? _username;
  String? _bookingsalesagentname;
  int? _bookingno;
  dynamic _resellername;
  int? _slsbookingpkno;
  int? _isreseller;
  int? _issystemhold;
  int? _isadminhold;
  int? _dispatchstatus;
  int? _iscancel;
  dynamic _cancelrequestby;
  dynamic _cancelrequestat;
  int? _isselfpickup;
  int? _isadminapproval;
  String? _bookingnotes;
  int? _isreadbookingnotes;
  int? _isbundlematched;
  String? _reconfirmtime;
  int? _isdefault;
  double? _penaltyfee;
  int? _defaulttype;
  int? _ordergroupid;
  String? _orderto;
  int? _bookingPks;
  double? _totalprice;
  int? _orderactualtopup;
  int? _orderbuffertopup;
  double? _discount;
  double? _totalvalue;
  int? _isorderingroup;
  String? _orderid;
  String? _orderdate;
  String? _createdby;
  double? _varifiedpayment;
  double? _paidbutnotverified;
  double? _duepayment;
  String? _status;

  int? get pkno => _pkno;
  int? get fbookingno => _fbookingno;
  int? get fcustomerno => _fcustomerno;
  dynamic get fresellerno => _fresellerno;
  String? get customername => _customername;
  int? get isready => _isready;
  String? get sscreatedon => _sscreatedon;
  String? get username => _username;
  String? get bookingsalesagentname => _bookingsalesagentname;
  int? get bookingno => _bookingno;
  dynamic get resellername => _resellername;
  int? get slsbookingpkno => _slsbookingpkno;
  int? get isreseller => _isreseller;
  int? get issystemhold => _issystemhold;
  int? get isadminhold => _isadminhold;
  int? get dispatchstatus => _dispatchstatus;
  int? get iscancel => _iscancel;
  dynamic get cancelrequestby => _cancelrequestby;
  dynamic get cancelrequestat => _cancelrequestat;
  int? get isselfpickup => _isselfpickup;
  int? get isadminapproval => _isadminapproval;
  String? get bookingnotes => _bookingnotes;
  int? get isreadbookingnotes => _isreadbookingnotes;
  int? get isbundlematched => _isbundlematched;
  String? get reconfirmtime => _reconfirmtime;
  int? get isdefault => _isdefault;
  double? get penaltyfee => _penaltyfee;
  int? get defaulttype => _defaulttype;
  int? get ordergroupid => _ordergroupid;
  String? get orderto => _orderto;
  int? get bookingPks => _bookingPks;
  double? get totalprice => _totalprice;
  int? get orderactualtopup => _orderactualtopup;
  int? get orderbuffertopup => _orderbuffertopup;
  double? get discount => _discount;
  double? get totalvalue => _totalvalue;
  int? get isorderingroup => _isorderingroup;
  String? get orderid => _orderid;
  String? get orderdate => _orderdate;
  String? get createdby => _createdby;
  double? get varifiedpayment => _varifiedpayment;
  double? get paidbutnotverified => _paidbutnotverified;
  double? get duepayment => _duepayment;
  String? get status => _status;

  Data(
      {int? pkno,
      int? fbookingno,
      int? fcustomerno,
      dynamic fresellerno,
      String? customername,
      int? isready,
      String? sscreatedon,
      String? username,
      String? bookingsalesagentname,
      int? bookingno,
      dynamic resellername,
      int? slsbookingpkno,
      int? isreseller,
      int? issystemhold,
      int? isadminhold,
      int? dispatchstatus,
      int? iscancel,
      dynamic cancelrequestby,
      dynamic cancelrequestat,
      int? isselfpickup,
      int? isadminapproval,
      String? bookingnotes,
      int? isreadbookingnotes,
      int? isbundlematched,
      String? reconfirmtime,
      int? isdefault,
        double? penaltyfee,
      int? defaulttype,
      int? ordergroupid,
      String? orderto,
      int? bookingPks,
        double? totalprice,
      int? orderactualtopup,
      int? orderbuffertopup,
        double? discount,
        double? totalvalue,
      int? isorderingroup,
      String? orderid,
      String? orderdate,
      String? createdby,
        double? varifiedpayment,
        double? paidbutnotverified,
        double? duepayment,
      String? status}) {
    _pkno = pkno;
    _fbookingno = fbookingno;
    _fcustomerno = fcustomerno;
    _fresellerno = fresellerno;
    _customername = customername;
    _isready = isready;
    _sscreatedon = sscreatedon;
    _username = username;
    _bookingsalesagentname = bookingsalesagentname;
    _bookingno = bookingno;
    _resellername = resellername;
    _slsbookingpkno = slsbookingpkno;
    _isreseller = isreseller;
    _issystemhold = issystemhold;
    _isadminhold = isadminhold;
    _dispatchstatus = dispatchstatus;
    _iscancel = iscancel;
    _cancelrequestby = cancelrequestby;
    _cancelrequestat = cancelrequestat;
    _isselfpickup = isselfpickup;
    _isadminapproval = isadminapproval;
    _bookingnotes = bookingnotes;
    _isreadbookingnotes = isreadbookingnotes;
    _isbundlematched = isbundlematched;
    _reconfirmtime = reconfirmtime;
    _isdefault = isdefault;
    _penaltyfee = penaltyfee;
    _defaulttype = defaulttype;
    _ordergroupid = ordergroupid;
    _orderto = orderto;
    _bookingPks = bookingPks;
    _totalprice = totalprice;
    _orderactualtopup = orderactualtopup;
    _orderbuffertopup = orderbuffertopup;
    _discount = discount;
    _totalvalue = totalvalue;
    _isorderingroup = isorderingroup;
    _orderid = orderid;
    _orderdate = orderdate;
    _createdby = createdby;
    _varifiedpayment = varifiedpayment;
    _paidbutnotverified = paidbutnotverified;
    _duepayment = duepayment;
    _status = status;
  }

  Data.fromJson(dynamic json) {
    _pkno = json['PK_NO'];
    _fbookingno = json['F_BOOKING_NO'];
    _fcustomerno = json['F_CUSTOMER_NO'];
    _fresellerno = json['F_RESELLER_NO'];
    _customername = json['CUSTOMER_NAME'];
    _isready = json['IS_READY'];
    _sscreatedon = json['SS_CREATED_ON'];
    _username = json['USERNAME'];
    _bookingsalesagentname = json['BOOKING_SALES_AGENT_NAME'];
    _bookingno = json['BOOKING_NO'];
    _resellername = json['RESELLER_NAME'];
    _slsbookingpkno = json['SLS_BOOKING_PK_NO'];
    _isreseller = json['IS_RESELLER'];
    _issystemhold = json['IS_SYSTEM_HOLD'];
    _isadminhold = json['IS_ADMIN_HOLD'];
    _dispatchstatus = json['DISPATCH_STATUS'];
    _iscancel = json['IS_CANCEL'];
    _cancelrequestby = json['CANCEL_REQUEST_BY'];
    _cancelrequestat = json['CANCEL_REQUEST_AT'];
    _isselfpickup = json['IS_SELF_PICKUP'];
    _isadminapproval = json['IS_ADMIN_APPROVAL'];
    _bookingnotes = json['BOOKING_NOTES'];
    _isreadbookingnotes = json['IS_READ_BOOKING_NOTES'];
    _isbundlematched = json['IS_BUNDLE_MATCHED'];
    _reconfirmtime = json['RECONFIRM_TIME'];
    _isdefault = json['IS_DEFAULT'];
    _penaltyfee = json["PENALTY_FEE"] is int
        ? (json['PENALTY_FEE'] as int).toDouble()
        : json['PENALTY_FEE'];
    _defaulttype = json['DEFAULT_TYPE'];
    _ordergroupid = json['ORDER_GROUP_ID'];
    _orderto = json['ORDER_TO'];
    _bookingPks = json['booking_pks'];
    _totalprice = json["TOTAL_PRICE"] is int
        ? (json['TOTAL_PRICE'] as int).toDouble()
        : json['TOTAL_PRICE'];
    _orderactualtopup = json['ORDER_ACTUAL_TOPUP'];
    _orderbuffertopup = json['ORDER_BUFFER_TOPUP'];
    _discount = json["DISCOUNT"] is int
        ? (json['DISCOUNT'] as int).toDouble()
        : json['DISCOUNT'];
    _totalvalue = json["TOTAL_VALUE"] is int
        ? (json['TOTAL_VALUE'] as int).toDouble()
        : json['TOTAL_VALUE'];
    _isorderingroup = json['IS_ORDER_IN_GROUP'];
    _orderid = json['ORDER_ID'];
    _orderdate = json['ORDER_DATE'];
    _createdby = json['CREATED_BY'];
    _varifiedpayment = json["VARIFIED_PAYMENT"] is int
        ? (json['VARIFIED_PAYMENT'] as int).toDouble()
        : json['VARIFIED_PAYMENT'];
    _paidbutnotverified = json["PAID_BUT_NOT_VERIFIED"] is int
        ? (json['PAID_BUT_NOT_VERIFIED'] as int).toDouble()
        : json['PAID_BUT_NOT_VERIFIED'];
    _duepayment = json["DUE_PAYMENT"] is int
        ? (json['DUE_PAYMENT'] as int).toDouble()
        : json['DUE_PAYMENT'];
    _status = json['STATUS'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['PK_NO'] = _pkno;
    map['F_BOOKING_NO'] = _fbookingno;
    map['F_CUSTOMER_NO'] = _fcustomerno;
    map['F_RESELLER_NO'] = _fresellerno;
    map['CUSTOMER_NAME'] = _customername;
    map['IS_READY'] = _isready;
    map['SS_CREATED_ON'] = _sscreatedon;
    map['USERNAME'] = _username;
    map['BOOKING_SALES_AGENT_NAME'] = _bookingsalesagentname;
    map['BOOKING_NO'] = _bookingno;
    map['RESELLER_NAME'] = _resellername;
    map['SLS_BOOKING_PK_NO'] = _slsbookingpkno;
    map['IS_RESELLER'] = _isreseller;
    map['IS_SYSTEM_HOLD'] = _issystemhold;
    map['IS_ADMIN_HOLD'] = _isadminhold;
    map['DISPATCH_STATUS'] = _dispatchstatus;
    map['IS_CANCEL'] = _iscancel;
    map['CANCEL_REQUEST_BY'] = _cancelrequestby;
    map['CANCEL_REQUEST_AT'] = _cancelrequestat;
    map['IS_SELF_PICKUP'] = _isselfpickup;
    map['IS_ADMIN_APPROVAL'] = _isadminapproval;
    map['BOOKING_NOTES'] = _bookingnotes;
    map['IS_READ_BOOKING_NOTES'] = _isreadbookingnotes;
    map['IS_BUNDLE_MATCHED'] = _isbundlematched;
    map['RECONFIRM_TIME'] = _reconfirmtime;
    map['IS_DEFAULT'] = _isdefault;
    map['PENALTY_FEE'] = _penaltyfee;
    map['DEFAULT_TYPE'] = _defaulttype;
    map['ORDER_GROUP_ID'] = _ordergroupid;
    map['ORDER_TO'] = _orderto;
    map['booking_pks'] = _bookingPks;
    map['TOTAL_PRICE'] = _totalprice;
    map['ORDER_ACTUAL_TOPUP'] = _orderactualtopup;
    map['ORDER_BUFFER_TOPUP'] = _orderbuffertopup;
    map['DISCOUNT'] = _discount;
    map['TOTAL_VALUE'] = _totalvalue;
    map['IS_ORDER_IN_GROUP'] = _isorderingroup;
    map['ORDER_ID'] = _orderid;
    map['ORDER_DATE'] = _orderdate;
    map['CREATED_BY'] = _createdby;
    map['VARIFIED_PAYMENT'] = _varifiedpayment;
    map['PAID_BUT_NOT_VERIFIED'] = _paidbutnotverified;
    map['DUE_PAYMENT'] = _duepayment;
    map['STATUS'] = _status;
    return map;
  }
}
