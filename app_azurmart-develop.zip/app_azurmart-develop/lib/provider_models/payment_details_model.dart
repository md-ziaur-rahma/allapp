// To parse this JSON data, do
//
//     final paymentDetailsModel = paymentDetailsModelFromJson(jsonString);

import 'dart:convert';

PaymentDetailsModel paymentDetailsModelFromJson(String str) => PaymentDetailsModel.fromJson(json.decode(str));

String paymentDetailsModelToJson(PaymentDetailsModel data) => json.encode(data.toJson());

class PaymentDetailsModel {
  PaymentDetailsModel({
    this.status,
    this.success,
    this.code,
    this.message,
    this.description,
    this.data,
    this.errors,
    this.api,
  });

  int? status;
  bool? success;
  int? code;
  String? message;
  String? description;
  Data? data;
  dynamic errors;
  Api? api;

  factory PaymentDetailsModel.fromJson(Map<String, dynamic> json) => PaymentDetailsModel(
    status: json["status"],
    success: json["success"],
    code: json["code"],
    message: json["message"],
    description: json["description"],
    data: Data.fromJson(json["data"]),
    errors: json["errors"],
    api: Api.fromJson(json["api"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "code": code,
    "message": message,
    "description": description,
    "data": data!.toJson(),
    "errors": errors,
    "api": api!.toJson(),
  };
}

class Api {
  Api({
    this.version,
  });

  String? version;

  factory Api.fromJson(Map<String, dynamic> json) => Api(
    version: json["version"],
  );

  Map<String, dynamic> toJson() => {
    "version": version,
  };
}

class Data {
  Data({
    this.orderPayments,
    this.txn,
  });

  List<OrderPayment>? orderPayments;
  Txn? txn;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    orderPayments: List<OrderPayment>.from(json["order_payments"].map((x) => OrderPayment.fromJson(x))),
    txn: Txn.fromJson(json["txn"]),
  );

  Map<String, dynamic> toJson() => {
    "order_payments": List<dynamic>.from(orderPayments!.map((x) => x.toJson())),
    "txn": txn!.toJson(),
  };
}

class OrderPayment {
  OrderPayment({
    this.pkNo,
    this.code,
    this.orderNo,
    this.customerNo,
    this.resellerNo,
    this.isCustomer,
    this.fAccCustomerPaymentNo,
    this.fAccResellerPaymentNo,
    this.paymentAmount,
    this.totalPrice,
    this.due,
    this.fBookingNo,
    this.bookingNo,
    this.reconfirmTime,
    this.agent,
  });

  int? pkNo;
  int? code;
  int? orderNo;
  int? customerNo;
  int? resellerNo;
  int? isCustomer;
  int? fAccCustomerPaymentNo;
  int? fAccResellerPaymentNo;
  double? paymentAmount;
  double? totalPrice;
  double? due;
  int? bookingNo;
  int? fBookingNo;
  String? reconfirmTime;
  String? agent;

  factory OrderPayment.fromJson(Map<String, dynamic> json) => OrderPayment(
    pkNo: json["PK_NO"] == null ? 0 : json["PK_NO"],
    code: json["CODE"] == null ? 0 : json["CODE"],
    orderNo: json["ORDER_NO"] == null ? 0 : json["ORDER_NO"],
    customerNo: json["CUSTOMER_NO"] == null ? 0 : json["CUSTOMER_NO"],
    resellerNo: json["RESELLER_NO"] == null ? 0 : json["RESELLER_NO"],
    isCustomer: json["IS_CUSTOMER"] == null ? 0 : json["IS_CUSTOMER"],
    fAccCustomerPaymentNo: json["F_ACC_CUSTOMER_PAYMENT_NO"] == null ? 0 : json["F_ACC_CUSTOMER_PAYMENT_NO"],
    fAccResellerPaymentNo: json["F_ACC_RESELLER_PAYMENT_NO"] == null ? 0 : json["F_ACC_RESELLER_PAYMENT_NO"],
    paymentAmount: json["PAYMENT_AMOUNT"] is int
      ? (json['PAYMENT_AMOUNT'] as int).toDouble()
      : json['PAYMENT_AMOUNT'],
    totalPrice: json["TOTAL_PRICE"] is int
        ? (json['TOTAL_PRICE'] as int).toDouble()
        : json['TOTAL_PRICE'],
    due: json["DUE"] is int
        ? (json['DUE'] as int).toDouble()
        : json['DUE'],
    bookingNo: json["BOOKING_NO"],
    fBookingNo: json["F_BOOKING_NO"],
    reconfirmTime: json["RECONFIRM_TIME"],
    agent: json["AGENT"],
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "CODE": code,
    "ORDER_NO": orderNo,
    "CUSTOMER_NO": customerNo,
    "RESELLER_NO": resellerNo,
    "IS_CUSTOMER": isCustomer,
    "F_ACC_CUSTOMER_PAYMENT_NO": fAccCustomerPaymentNo,
    "F_ACC_RESELLER_PAYMENT_NO": fAccResellerPaymentNo,
    "PAYMENT_AMOUNT": paymentAmount,
    "TOTAL_PRICE": totalPrice,
    "DUE": due,
    "BOOKING_NO": bookingNo,
    "RECONFIRM_TIME": reconfirmTime,
    "F_BOOKING_NO": fBookingNo,
    "AGENT": agent,
  };
}

class Txn {
  Txn({
    this.pkNo,
    this.code,
    this.txnTypeInOut,
    this.txnDate,
    this.amountActual,
    this.amountBuffer,
    this.fAccPaymentBankNo,
    this.fCustomerNo,
    this.fCustomerPaymentNo,
    this.isMatched,
    this.fSsCreatedBy,
    this.ssCreatedOn,
    this.isCod,
    this.paymentType,
    this.amountToOrder,
    this.amountToCredited,
    this.paymentRemainingMr,
    this.slipNumber
  });

  int? pkNo;
  int? code;
  int? txnTypeInOut;
  String? txnDate;
  double? amountActual;
  double? amountBuffer;
  int? fAccPaymentBankNo;
  int? fCustomerNo;
  int? fCustomerPaymentNo;
  int? isMatched;
  int? fSsCreatedBy;
  String? ssCreatedOn;
  int? isCod;
  int? paymentType;
  double? amountToOrder;
  double? amountToCredited;
  int? paymentRemainingMr;
  String? slipNumber;

  factory Txn.fromJson(Map<String, dynamic> json) => Txn(
    pkNo: json["PK_NO"],
    code: json["CODE"],
    txnTypeInOut: json["TXN_TYPE_IN_OUT"],
    txnDate: json["TXN_DATE"],
    amountActual: json["AMOUNT_ACTUAL"] is int
      ? (json['AMOUNT_ACTUAL'] as int).toDouble()
      : json['AMOUNT_ACTUAL'],
    amountBuffer: json["AMOUNT_BUFFER"] is int
      ? (json['AMOUNT_BUFFER'] as int).toDouble()
      : json['AMOUNT_BUFFER'],
    fAccPaymentBankNo: json["F_ACC_PAYMENT_BANK_NO"],
    fCustomerNo: json["F_CUSTOMER_NO"],
    fCustomerPaymentNo: json["F_CUSTOMER_PAYMENT_NO"],
    isMatched: json["IS_MATCHED"],
    fSsCreatedBy: json["F_SS_CREATED_BY"],
    ssCreatedOn: json["SS_CREATED_ON"],
    isCod: json["IS_COD"],
    paymentType: json["PAYMENT_TYPE"],
    paymentRemainingMr: json["PAYMENT_REMAINING_MR"],
    amountToOrder: json["AMOUNT_TO_ORDER"] is int
        ? (json['AMOUNT_TO_ORDER'] as int).toDouble()
        : json['AMOUNT_TO_ORDER'],
    amountToCredited: json["AMOUNT_TO_CREDIT"] is int
        ? (json['AMOUNT_TO_CREDIT'] as int).toDouble()
        : json['AMOUNT_TO_CREDIT'],
    slipNumber: json["SLIP_NUMBER"],
  );

  Map<String, dynamic> toJson() => {
    "PK_NO": pkNo,
    "CODE": code,
    "TXN_TYPE_IN_OUT": txnTypeInOut,
    "TXN_DATE": txnDate,
    "AMOUNT_ACTUAL": amountActual,
    "AMOUNT_BUFFER": amountBuffer,
    "F_ACC_PAYMENT_BANK_NO": fAccPaymentBankNo,
    "F_CUSTOMER_NO": fCustomerNo,
    "F_CUSTOMER_PAYMENT_NO": fCustomerPaymentNo,
    "IS_MATCHED": isMatched,
    "F_SS_CREATED_BY": fSsCreatedBy,
    "SS_CREATED_ON": ssCreatedOn,
    "IS_COD": isCod,
    "PAYMENT_TYPE": paymentType,
    "AMOUNT_TO_ORDER": amountToOrder,
    "AMOUNT_TO_CREDIT": amountToCredited,
    "PAYMENT_REMAINING_MR": paymentRemainingMr,
    "SLIP_NUMBER": slipNumber,
  };
}
