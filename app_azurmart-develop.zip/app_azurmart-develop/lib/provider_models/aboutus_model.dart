class AboutUsModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  Data? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  Data? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  AboutUsModel({
      int? status, 
      bool? success, 
      int? code, 
      String? message, 
      String? description, 
      Data? data, 
      dynamic errors, 
      Api? api}){
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
}

  AboutUsModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    _data = json["data"] != null ? Data.fromJson(json["data"]) : null;
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.toJson();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }

}

class Api {
  String? _version;

  String? get version => _version;

  Api({
      String? version}){
    _version = version;
}

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }

}

class Data {
  int? _pkno;
  String? _title;
  String? _body;
  String? _featureimage;
  String? _banner;

  int? get pkno => _pkno;
  String? get title => _title;
  String? get body => _body;
  String? get featureimage => _featureimage;
  String? get banner => _banner;

  Data({
      int? pkno, 
      String? title, 
      String? body, 
      String? featureimage, 
      String? banner}){
    _pkno = pkno;
    _title = title;
    _body = body;
    _featureimage = featureimage;
    _banner = banner;
}

  Data.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _title = json["TITLE"];
    _body = json["BODY"];
    _featureimage = json["FEATURE_IMAGE"];
    _banner = json["BANNER"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["TITLE"] = _title;
    map["BODY"] = _body;
    map["FEATURE_IMAGE"] = _featureimage;
    map["BANNER"] = _banner;
    return map;
  }

}