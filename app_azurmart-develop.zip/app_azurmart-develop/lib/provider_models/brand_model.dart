/// status : 1
/// success : true
/// code : 200
/// message : "Data is available !"
/// description : ""
/// data : [{"PK_NO":1,"NAME":"Le Creuset","BRAND_LOGO":"/media/images/banner/prod_08052021_609651da97840.jpg","SLUG":"le-creuset","product_brand_count":168},{"PK_NO":29,"NAME":"KATE SPADE","BRAND_LOGO":"/media/images/banner/prod_08052021_6096511e9a6c0.jpg","SLUG":"kate-spade","product_brand_count":112},{"PK_NO":22,"NAME":"FURLA","BRAND_LOGO":"/media/images/banner/prod_08052021_60964ea5928ed.jpg","SLUG":"furla","product_brand_count":70},{"PK_NO":21,"NAME":"FOSSIL","BRAND_LOGO":"/media/images/banner/prod_08052021_60964e9d39b6f.jpg","SLUG":"fossil","product_brand_count":65},{"PK_NO":82,"NAME":"PORTMEIRION","BRAND_LOGO":"/media/images/banner/prod_08052021_60965352da2ca.jpg","SLUG":"portmeirion","product_brand_count":56},{"PK_NO":2,"NAME":"Staub","BRAND_LOGO":"/media/images/banner/prod_08052021_6096550112751.jpg","SLUG":"staub","product_brand_count":50},{"PK_NO":28,"NAME":"KARL LAGERFELD","BRAND_LOGO":"/media/images/banner/prod_08052021_609650de6fbb8.jpg","SLUG":"karl-lagerfeld","product_brand_count":49},{"PK_NO":10,"NAME":"CATH KIDSTON","BRAND_LOGO":null,"SLUG":null,"product_brand_count":45},{"PK_NO":55,"NAME":"TORY BURCH","BRAND_LOGO":"/media/images/banner/prod_08052021_60965596d0910.jpg","SLUG":"tory-burch","product_brand_count":42},{"PK_NO":30,"NAME":"KENZO","BRAND_LOGO":"/media/images/banner/prod_08052021_60965161a1f61.jpg","SLUG":"kenzo","product_brand_count":32}]
/// errors : null
/// api : {"version":"1.0"}

class BrandModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  List<Data>? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  List<Data>? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;


  set status(int? value) {
    _status = value;
  }

  BrandModel({
      int? status, 
      bool? success, 
      int? code, 
      String? message, 
      String? description, 
      List<Data>? data, 
      dynamic errors, 
      Api? api}){
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
}

  BrandModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    if (json["data"] != null) {
      _data = [];
      json["data"].forEach((v) {
        _data!.add(Data.fromJson(v));
      });
    }
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.map((v) => v.toJson()).toList();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }

  set success(bool? value) {
    _success = value;
  }

  set code(int? value) {
    _code = value;
  }

  set message(String? value) {
    _message = value;
  }

  set description(String? value) {
    _description = value;
  }

  set data(List<Data>? value) {
    _data = value;
  }

  set errors(dynamic value) {
    _errors = value;
  }

  set api(Api? value) {
    _api = value;
  }
}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;

  Api({
      String? version}){
    _version = version;
}

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }

}

/// PK_NO : 1
/// NAME : "Le Creuset"
/// BRAND_LOGO : "/media/images/banner/prod_08052021_609651da97840.jpg"
/// SLUG : "le-creuset"
/// product_brand_count : 168

class Data {
  int? _pkno;
  String? _name;
  String? _brandlogo;
  String? _slug;
  int? _productBrandCount;

  int? get pkno => _pkno;
  String? get name => _name;
  String? get brandlogo => _brandlogo;
  String? get slug => _slug;
  int? get productBrandCount => _productBrandCount;


  set pkno(int? value) {
    _pkno = value;
  }

  Data({
      int? pkno, 
      String? name, 
      String? brandlogo, 
      String? slug, 
      int? productBrandCount}){
    _pkno = pkno;
    _name = name;
    _brandlogo = brandlogo;
    _slug = slug;
    _productBrandCount = productBrandCount;
}

  Data.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _name = json["NAME"];
    _brandlogo = json["BRAND_LOGO"];
    _slug = json["SLUG"];
    _productBrandCount = json["product_brand_count"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["NAME"] = _name;
    map["BRAND_LOGO"] = _brandlogo;
    map["SLUG"] = _slug;
    map["product_brand_count"] = _productBrandCount;
    return map;
  }

  set name(String? value) {
    _name = value;
  }

  set brandlogo(String? value) {
    _brandlogo = value;
  }

  set slug(String? value) {
    _slug = value;
  }

  set productBrandCount(int? value) {
    _productBrandCount = value;
  }
}