/// status : 1
/// success : true
/// code : 200
/// message : "Data is available !"
/// description : ""
/// data : {"brand":{"PK_NO":1,"NAME":"Le Creuset","BRAND_LOGO":"/media/images/banner/prod_08052021_609651da97840.jpg"},"category":[{"subcat_id":1,"NAME":"Cookware","BANNER_PATH":null},{"subcat_id":2,"NAME":"Stoneware","BANNER_PATH":null},{"subcat_id":3,"NAME":"Kitchen Utensil & Gadgets","BANNER_PATH":null},{"subcat_id":30,"NAME":"Kitchen Appliances (Non-electric)","BANNER_PATH":null}]}
/// errors : null
/// api : {"version":"1.0"}

class BrandDetailsModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  Data? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  Data? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  BrandDetailsModel(
      {int? status,
      bool? success,
      int? code,
      String? message,
      String? description,
      Data? data,
      dynamic errors,
      Api? api}) {
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
  }

  BrandDetailsModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    _data = json["data"] != null ? Data.fromJson(json["data"]) : null;
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.toJson();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }
}

/// version : "1.0"

class Api {
  String? _version;

  String? get version => _version;

  Api({String? version}) {
    _version = version;
  }

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }
}

/// brand : {"PK_NO":1,"NAME":"Le Creuset","BRAND_LOGO":"/media/images/banner/prod_08052021_609651da97840.jpg"}
/// category : [{"subcat_id":1,"NAME":"Cookware","BANNER_PATH":null},{"subcat_id":2,"NAME":"Stoneware","BANNER_PATH":null},{"subcat_id":3,"NAME":"Kitchen Utensil & Gadgets","BANNER_PATH":null},{"subcat_id":30,"NAME":"Kitchen Appliances (Non-electric)","BANNER_PATH":null}]

class Data {
  Brand? _brand;
  List<Category>? _category;

  Brand? get brand => _brand;
  List<Category>? get category => _category;

  Data({Brand? brand, List<Category>? category}) {
    _brand = brand;
    _category = category;
  }

  Data.fromJson(dynamic json) {
    _brand = json["brand"] != null ? Brand.fromJson(json["brand"]) : null;
    if (json["category"] != null) {
      _category = [];
      json["category"].forEach((v) {
        _category!.add(Category.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_brand != null) {
      map["brand"] = _brand!.toJson();
    }
    if (_category != null) {
      map["category"] = _category!.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// subcat_id : 1
/// NAME : "Cookware"
/// BANNER_PATH : null

class Category {
  int? _subcatId;
  String? _name;
  String? _bannerpath;
  String? _thumbnail_path;
  String? _icon;

  int? get subcatId => _subcatId;
  String? get name => _name;
  String? get bannerpath => _bannerpath;
  String? get thumbnail_path => _thumbnail_path;
  String? get icon => _icon;

  Category({int? subcatId, String? name, String? bannerpath, String? thumbnail_path, String? icon}) {
    _subcatId = subcatId;
    _name = name;
    _bannerpath = bannerpath;
    _thumbnail_path = thumbnail_path;
    _icon = icon;
  }

  Category.fromJson(dynamic json) {
    _subcatId = json["subcat_id"];
    _name = json["NAME"];
    _bannerpath = json["BANNER_PATH"];
    _thumbnail_path = json['THUMBNAIL_PATH'];
    _icon = json['ICON'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["subcat_id"] = _subcatId;
    map["NAME"] = _name;
    map["BANNER_PATH"] = _bannerpath;
    map["THUMBNAIL_PATH"] = _thumbnail_path;
    map["ICON"] = _icon;
    return map;
  }
}

/// PK_NO : 1
/// NAME : "Le Creuset"
/// BRAND_LOGO : "/media/images/banner/prod_08052021_609651da97840.jpg"

class Brand {
  int? _pkno;
  String? _name;
  String? _brandlogo;

  int? get pkno => _pkno;
  String? get name => _name;
  String? get brandlogo => _brandlogo;

  Brand({int? pkno, String? name, String? brandlogo}) {
    _pkno = pkno;
    _name = name;
    _brandlogo = brandlogo;
  }

  Brand.fromJson(dynamic json) {
    _pkno = json["PK_NO"];
    _name = json["NAME"];
    _brandlogo = json["BRAND_LOGO"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["PK_NO"] = _pkno;
    map["NAME"] = _name;
    map["BRAND_LOGO"] = _brandlogo;
    return map;
  }
}
