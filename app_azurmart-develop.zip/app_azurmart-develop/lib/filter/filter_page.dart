import 'package:azuramartmy/filter/filter_body.dart';
import 'package:flutter/material.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/services.dart';

class FilterPage extends StatefulWidget {
  const FilterPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const FilterPage());
  }

  @override
  _FilterPageState createState() => _FilterPageState();
}

class _FilterPageState extends State<FilterPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'Filters',
          style: TextStyle(color: Colors.black87),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        backgroundColor: Colors.white,

        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
        elevation: 0,
        actions: [
          IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.close,
                color: Colors.black87,
              ))
        ],
      ),
      body: const SafeArea(
        child: FilterBody(),
      ),
      bottomNavigationBar: SizedBox(
        height: 50,
        width: double.infinity,
        child: Row(
          children: [
            Expanded(
                flex: 1,
                child: SizedBox(
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        primary: Colors.white,
                        elevation: 0,
                        onPrimary: Colors.red.withOpacity(0.4)),
                    onPressed: () {},
                    child: const Text(
                      'Reset',
                      style: TextStyle(color: Colors.black, fontSize: 12),
                    ),
                  ),
                )),
            Expanded(
                flex: 1,
                child: SizedBox(
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        primary: AppsColors.buttonColor,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(0))),
                    onPressed: () {},
                    child: const Text(
                      'Apply',
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
