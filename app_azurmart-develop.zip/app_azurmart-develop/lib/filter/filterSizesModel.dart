class FilterSizesModel {
  String size;
  bool isChecked;
  FilterSizesModel(this.size,this.isChecked);
}

List<FilterSizesModel> filterSizeModelList = [
  FilterSizesModel('S', false),
  FilterSizesModel('M', false),
  FilterSizesModel('L', false),
  FilterSizesModel('XL', false),
  FilterSizesModel('XXL', false),
];