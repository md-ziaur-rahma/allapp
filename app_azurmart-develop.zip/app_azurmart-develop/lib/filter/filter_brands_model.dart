class FilterBrandsModel {
  String brand;
  bool? isChecked;
  FilterBrandsModel(this.brand, this.isChecked);
}

List<FilterBrandsModel> filterBrandsList = [
  FilterBrandsModel("Italian", false),
  FilterBrandsModel("American", true),
  FilterBrandsModel("Lotto", false),
  FilterBrandsModel("Apex", false),
  FilterBrandsModel("Easy", false),
];
