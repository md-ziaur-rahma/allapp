import 'package:azuramartmy/filter/filterSizesModel.dart';
import 'package:azuramartmy/filter/filter_brands_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class FilterBody extends StatefulWidget {
  const FilterBody({Key? key}) : super(key: key);

  @override
  _FilterBodyState createState() => _FilterBodyState();
}

class _FilterBodyState extends State<FilterBody> {
  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.only(left: 12, right: 12, top: 10, bottom: 0),
      child: CustomScrollView(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        slivers: [
          SliverToBoxAdapter(
            child: FilterCategoryView(),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 20,
            ),
          ),
          SliverToBoxAdapter(
            child: FilterPricing(),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 20,
            ),
          ),
          SliverToBoxAdapter(
            child: FilterBrands(),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 20,
            ),
          ),
          SliverToBoxAdapter(
            child: FilterColor(),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 20,
            ),
          ),
          SliverToBoxAdapter(
            child: FilterSize(),
          )
        ],
      ),
    );
  }
}

class FilterCategoryView extends StatefulWidget {
  const FilterCategoryView({Key? key}) : super(key: key);

  @override
  _FilterCategoryViewState createState() => _FilterCategoryViewState();
}

class _FilterCategoryViewState extends State<FilterCategoryView> {
  List<String> categories = [
    "Accessories",
    "Cloths",
    "Decor",
    "Fashion",
    "Electronics",
    "Men",
    "Women",
    "Baby",
  ];

  List<String> subCategories = [
    'Men\'s Clothing',
    'Women\'s Clothing',
    'Kid\'s Clothing',
    'Men\'s T-Shirt',
    'Men\'s Shirt',
  ];

  String? categoryValue;

  @override
  void initState() {
    categoryValue = categories[1];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Flexible(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Categories',
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 14,
                  fontWeight: FontWeight.w600),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: DropdownButton<String>(
                value: categoryValue,
                icon: const Icon(
                  Icons.arrow_drop_down,
                ),
                iconSize: 24,
                elevation: 3,
                underline: Container(
                  height: 2,
                  color: const Color(0xFFF4F4F4),
                ),
                onChanged: (newValue) {
                  setState(() {
                    categoryValue = newValue;
                  });
                },
                items: categories.map((String category) {
                  return DropdownMenuItem<String>(
                    value: category,
                    child: Text(
                      category,
                      style: const TextStyle(color: Colors.black87, fontSize: 14),
                    ),
                  );
                }).toList(),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Wrap(
                spacing: 10,
                runSpacing: 10,
                direction: Axis.horizontal,
                children: [
                  ...List.generate(subCategories.length, (index) {
                    return Flexible(
                        child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: Colors.pinkAccent),
                          color: Colors.transparent),
                      child: Text(
                        subCategories[index],
                        style: const TextStyle(color: Color(0xFFF68721), fontSize: 10),
                      ),
                    ));
                  }),
                ],
              ),
            )
          ],
        ));
  }
}

class FilterPricing extends StatefulWidget {
  const FilterPricing({Key? key}) : super(key: key);

  @override
  _FilterPricingState createState() => _FilterPricingState();
}

class _FilterPricingState extends State<FilterPricing> {
  RangeValues _rangeSliderDiscreteValues = const RangeValues(0, 50);
  int? upper;
  int? lower;
  @override
  Widget build(BuildContext context) {
    return Flexible(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Price',
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 14,
                  fontWeight: FontWeight.w600),
            ),
            const SizedBox(
              height: 16,
            ),
            Row(
              children: [
                const Text(
                  'min',
                  style: TextStyle(color: Colors.black87, fontSize: 12),
                ),
                Expanded(
                  child: RangeSlider(
                    values: _rangeSliderDiscreteValues,
                    min: 0,
                    max: 100,
                    activeColor: const Color(0xFFF68721),
                    inactiveColor: const Color(0xFFF68721).withOpacity(0.3),
                    labels: RangeLabels(
                      _rangeSliderDiscreteValues.start.round().toString(),
                      _rangeSliderDiscreteValues.end.round().toString(),
                    ),
                    onChanged: (values) {
                      setState(() {
                        _rangeSliderDiscreteValues = values;
                      });
                    },
                  ),
                ),
                const Text(
                  'max',
                  style: TextStyle(color: Colors.black87, fontSize: 12),
                ),
              ],
            )
          ],
        ));
  }
}

class FilterBrands extends StatefulWidget {
  const FilterBrands({Key? key}) : super(key: key);

  @override
  _FilterBrandsState createState() => _FilterBrandsState();
}

class _FilterBrandsState extends State<FilterBrands> {
  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                const Text(
                  'Brands',
                  style: TextStyle(
                      color: Colors.black87,
                      fontSize: 14,
                      fontWeight: FontWeight.w600),
                ),
                const Spacer(),
                TextButton(
                    onPressed: () {
                      setState(() {
                        for (var i = 0; i < filterBrandsList.length; i++) {
                          filterBrandsList[i].isChecked = true;
                        }
                      });
                    },
                    child: const Text(
                      'Select All',
                      style: TextStyle(color: Colors.black54, fontSize: 14),
                    ))
              ],
            ),
            Flexible(
              child: Container(
                width: double.infinity,
                margin: const EdgeInsets.symmetric(vertical: 16),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                decoration: BoxDecoration(
                    color: const Color(0xFFF3F5F4),
                    borderRadius: BorderRadius.circular(3)),
                child: ListView.builder(
                    itemCount: filterBrandsList.length,
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(
                          filterBrandsList[index].brand,
                          style: TextStyle(
                              color: filterBrandsList[index].isChecked!
                                  ? Colors.primaries[index]
                                  : const Color(0xFF999A9C)),
                        ),
                        trailing: Checkbox(
                          value: filterBrandsList[index].isChecked,
                          activeColor: Colors.primaries[index],
                          onChanged: (bool? newValue) {
                            setState(() {
                              filterBrandsList[index].isChecked = newValue;
                            });
                          },
                        ),
                      );
                    }),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class FilterColor extends StatefulWidget {
  const FilterColor({Key? key}) : super(key: key);

  @override
  _FilterColorState createState() => _FilterColorState();
}

class _FilterColorState extends State<FilterColor> {
  List<String> colors = [
    'BLACK',
    'RED',
    'GREEN',
    'BLUE',
    'WHITE',
    'MAGENTA',
    'YELLOW',
  ];

  @override
  Widget build(BuildContext context) {
    return Flexible(
        child: SizedBox(
      width: double.infinity,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Colors',
            style: TextStyle(
                color: Colors.black87,
                fontSize: 14,
                fontWeight: FontWeight.w600),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Wrap(
              spacing: 16,
              runSpacing: 10,
              direction: Axis.horizontal,
              children: [
                ...List.generate(colors.length, (index) {
                  return Flexible(
                      child: Text(
                        colors[index],
                        style: const TextStyle(
                            color: Colors.black54,
                            fontSize: 14,
                            fontWeight: FontWeight.w400),
                      ));
                })
              ],
            ),
          ),
        ],
      ),
    ));
  }
}

class FilterSize extends StatefulWidget {
  const FilterSize({Key? key}) : super(key: key);

  @override
  _FilterSizeState createState() => _FilterSizeState();
}

class _FilterSizeState extends State<FilterSize> {
  @override
  Widget build(BuildContext context) {
    return Flexible(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Size',
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 16,
                  fontWeight: FontWeight.w600),
            ),
            Wrap(
              spacing: 16,
              runSpacing: 10,
              direction: Axis.horizontal,
              children: [
                ...List.generate(filterSizeModelList.length, (index) {
                  return GestureDetector(
                    onTap: (){
                      setState(() {
                        filterSizeModelList[index].isChecked = !filterSizeModelList[index].isChecked;
                      });
                    },
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(
                        maxHeight: 40,
                        minWidth: 35,
                        maxWidth: 60,
                        minHeight: 40,
                      ),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: ShapeDecoration(
                          shape: const CircleBorder(),
                          color: filterSizeModelList[index].isChecked ? const Color(0xFFF68721) : Colors.transparent,
                        ),
                        child: Center(
                          child: Text(filterSizeModelList[index].size,style: TextStyle(color: filterSizeModelList[index].isChecked ? Colors.white : const Color(0xFFF68721),),),
                        ),
                      ),
                    ),
                  );
                })
              ],
            )
          ],
        ));
  }
}
