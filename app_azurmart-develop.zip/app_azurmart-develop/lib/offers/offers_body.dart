import 'package:azuramartmy/common_notifier/common_notifier.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/home/home_offer_card.dart';
import 'package:azuramartmy/my_bloc/offers_bloc.dart';
import 'package:azuramartmy/provider_models/offer_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
// import 'package:azuramartmy/countdown_timer_controller.dart';
// import 'package:azuramartmy/current_remaining_time.dart';
// import 'package:azuramartmy/flutter_countdown_timer.dart';
import 'package:provider/provider.dart';

class OffersBody extends StatefulWidget {
  const OffersBody({Key? key}) : super(key: key);

  @override
  _OffersBodyState createState() => _OffersBodyState();
}

class _OffersBodyState extends State<OffersBody> {
  OfferModel offerModel = OfferModel();
  bool canLoading = true;

  @override
  void initState() {
    offerModel.data = [];
    offerBloc.page = 1;
    canLoading = true;
    offerBloc.fetchAllOffer(0);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return StreamBuilder(
        stream: offerBloc.allOffer,
        builder: (context, AsyncSnapshot<OfferModel> snapshot) {
          if (snapshot.hasData) {
            // context.read<CommonNotifier>().changeLoading(false);
            Provider.of<CommonNotifier>(context,listen: false).changeLoading(false);
            if (snapshot.data!.data!.isEmpty) {
              canLoading = false;
            }else {
              if (snapshot.data!.data!.length < 10) {
                canLoading = false;
              }
              for (var i = 0; i < snapshot.data!.data!.length; i++) {
                offerModel.data!.add(snapshot.data!.data![i]);
              }
            }
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 0),
              child: CustomScrollView(
                scrollDirection: Axis.vertical,
                slivers: [
                  // SliverToBoxAdapter(
                  //   child: Stack(
                  //     alignment: Alignment.topCenter,
                  //     children: [
                  //       Container(
                  //         height: 60,
                  //         padding: EdgeInsets.symmetric(horizontal: 0),
                  //         decoration: BoxDecoration(
                  //             color: Color(0xFFF68721),
                  //             borderRadius: BorderRadius.only(
                  //                 bottomLeft: Radius.circular(16.0),
                  //                 bottomRight: Radius.circular(16.0))),
                  //       ),
                  //       Container(
                  //         height: 100,
                  //         margin: const EdgeInsets.symmetric(horizontal: 20,vertical: 16),
                  //         padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
                  //         decoration: BoxDecoration(
                  //             borderRadius: BorderRadius.circular(10.0),
                  //             color: Colors.white,
                  //             boxShadow: [
                  //               BoxShadow(
                  //                   offset: Offset(1,0),
                  //                   blurRadius: 6.0,
                  //                   color: Colors.grey.withOpacity(0.5)
                  //               ),
                  //             ]
                  //         ),
                  //         child: Center(
                  //           child: RichText(
                  //             text: TextSpan(
                  //                 text: 'AZURAMART ',
                  //                 style: TextStyle(color: Colors.black87,fontWeight: FontWeight.w800,fontSize: 18),
                  //                 children: <TextSpan>[
                  //                   TextSpan(
                  //                     text: '| BELIEVE IN YOU',
                  //                     style: TextStyle(color: Colors.black87,fontWeight: FontWeight.normal,fontSize: 18),
                  //                   )
                  //                 ]
                  //             ),
                  //           ),
                  //         ),
                  //       ),
                  //     ],
                  //   ),
                  // ),
                  const SliverToBoxAdapter(
                    child: SizedBox(
                      height: 16,
                    ),
                  ),
                  SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      crossAxisCount: MediaQuery.of(context).orientation ==
                          Orientation.portrait
                          ? 2
                          : MediaQuery.of(context).size.width > 740 ? 4 : 3,
                      childAspectRatio:
                      MediaQuery.of(context).orientation ==
                          Orientation.portrait
                          ? screenWidth / 150.0
                          : screenHeight / 130.0,
                    ),
                    delegate: SliverChildBuilderDelegate(
                          (BuildContext context, int index) {
                        if (index == (offerModel.data!.length - 1) &&
                            canLoading) {
                          Provider.of<CommonNotifier>(context,listen: false).changeLoading(true);
                          // context.read<CommonNotifier>().changeLoading(true);
                          offerBloc.fetchPagingData();
                        }
                        return HomeOfferCard(snapshot: offerModel, index: index,);
                      },
                      childCount: offerModel.data!.length,
                    ),
                  ),
                  SliverLayoutBuilder(
                    builder: (BuildContext context, SliverConstraints constraints) {
                      if (Provider.of<CommonNotifier>(context, listen: false).isLoading) {
                        return SliverToBoxAdapter(
                          child: Center(
                            child: Container(
                              margin: const EdgeInsets.symmetric(vertical: 16),
                              height: 20,
                              width: 20,
                              child: const CupertinoActivityIndicator(
                                animating: true,
                                radius: 12,
                              ),
                            ),
                          ),
                        );
                      }  else{
                        return const SliverToBoxAdapter(
                          child: Center(
                              child: SizedBox(
                                height: 6,
                              )
                          ),
                        );
                      }
                    },
                  ),
                ],
              ),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text(snapshot.error.toString()),
            );
          }
          return LoadingWidget(color: AppsColors.buttonColor,);
        });
  }
}


class OffersBodyOld extends StatelessWidget {
  const OffersBodyOld({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 0),
      child: CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          const SliverToBoxAdapter(
            child: OffersAddView(),
          ),
          SliverToBoxAdapter(
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.only(top: 20),
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: const BoxDecoration(
                  gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFFF3F3F3),
                  Color(0xFFF1F2F2),
                  Color(0xFFF0F1F3),
                ],
              )),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const SizedBox(
                    width: double.infinity,
                    height: 1,
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Text(
                          'Sunday Special',
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        margin: const EdgeInsets.symmetric(horizontal: 10),
                        color: Colors.pinkAccent,
                        child: const Text(
                          'View All',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                  // const CountdownView(),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 5),
                    child: GridView.count(
                      controller: ScrollController(keepScrollOffset: false),
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      crossAxisCount: 2,
                      children:
                      List.generate(4, (index) => const OffersItemCartView()),
                    ),
                  )
                ],
              ),
            ),
          ),
          const SliverToBoxAdapter(
            child: OffersAddView(),
          ),
        ],
      ),
    );
  }
}

///..................... Horizontal Offer View ......................
class OffersAddView extends StatelessWidget {
  const OffersAddView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 20),
      decoration: const BoxDecoration(color: Color(0xFFF4F4F4)),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          Expanded(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(
                      maxHeight: 100,
                      minHeight: 70,
                      maxWidth: 70,
                      minWidth: 60),
                  child: const Image(
                    fit: BoxFit.fitHeight,
                    image: AssetImage(''),
                  ),
                ),
              )),
          Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: const [
                  SizedBox(
                    width: double.infinity,
                    child: Text(
                      '70%',
                      //textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.w900,
                          fontSize: 24),
                    ),
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: Text(
                      'SAVE',
                      //textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.w900,
                          fontSize: 24),
                    ),
                  ),
                  SizedBox(
                    height: 8,
                  ),
                ],
              )),
          Expanded(
              child: Positioned(
                right: 0,
                top: 0,
                bottom: 0,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(
                      maxHeight: 150,
                      minHeight: 80,
                      maxWidth: 70,
                      minWidth: 60),
                  child: const Image(
                    fit: BoxFit.fitHeight,
                    image: AssetImage('images/shoes_1.png'),
                  ),
                ),
              )),
        ],
      ),
    );
  }
}

///..................... Countdown timer......................
// class CountdownView extends StatefulWidget {
//   const CountdownView({Key? key}) : super(key: key);
//
//   @override
//   _CountdownViewState createState() => _CountdownViewState();
// }
//
// class _CountdownViewState extends State<CountdownView> {
//   int zero = 0;
//   late CountdownTimerController controller;
//   int endTime = DateTime(
//     2021,
//     4,
//     2,
//   ).millisecondsSinceEpoch;
//
//   @override
//   void initState() {
//     super.initState();
//     controller = CountdownTimerController(endTime: endTime, onEnd: onEnd);
//   }
//
//   @override
//   void dispose() {
//     controller.dispose();
//     super.dispose();
//   }
//
//   void onEnd() {
//     controller.disposeTimer();
//     // print('onEnd');
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return CountdownTimer(
//       endTime: endTime,
//       widgetBuilder: (_, CurrentRemainingTime? time) {
//         if (time == null) {
//           return const Text(
//             'Time Over',
//             style: TextStyle(
//                 color: Colors.black, fontSize: 30, fontWeight: FontWeight.bold),
//           );
//         } else {
//           return Container(
//             margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
//             child: SizedBox(
//               width: double.infinity,
//               child: Text(
//                 '${time.hours ?? 00} : ${time.min ?? 00} : ${time.sec ?? 00}',
//                 style: const TextStyle(
//                     color: Colors.black54,
//                     fontSize: 30,
//                     fontWeight: FontWeight.bold),
//               ),
//             ),
//           );
//         }
//       },
//     );
//   }
// }

///..................... Grid Offer Item View ......................
class OffersItemCartView extends StatelessWidget {
  const OffersItemCartView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        color: Colors.pinkAccent,
        width: MediaQuery.of(context).size.width * 0.36,
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Flexible(
              child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                  color: const Color(0xFFE8E8E8),
                  child: ConstrainedBox(
                    constraints:
                    const BoxConstraints(minHeight: 50, maxHeight: 120),
                    child: const Center(
                      child: Image(
                        image: AssetImage('images/_1.png'),
                      ),
                    ),
                  )),
            ),
            const SizedBox(
              height: 8,
            ),
            const SizedBox(
              width: double.infinity,
              child: Text(
                'Slim T-Shirt',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black87, fontSize: 16),
              ),
            ),
            const SizedBox(
              height: 6,
            ),
            const SizedBox(
              width: double.infinity,
              child: Text(
                'off 25%',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.green, fontSize: 11),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
