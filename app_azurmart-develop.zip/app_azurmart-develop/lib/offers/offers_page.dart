import 'dart:io';

import 'package:azuramartmy/cart/cart_page.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/home/home_page.dart';
import 'package:azuramartmy/my_bloc/cart_count_bloc.dart';
import 'package:azuramartmy/offers/offers_body.dart';
import 'package:azuramartmy/provider_models/cart_count_model.dart';
import 'package:azuramartmy/search/search_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class OffersPage extends StatelessWidget {
  const OffersPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const OffersPage());
  }

  @override
  Widget build(BuildContext context) {
    cartCountBloc.fetchAllCartCount();
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Offer',
          style: TextStyle(color: Colors.black87),
        ),
        backgroundColor: const Color(0xFFFFFFFF),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Color(0xFFFFFFFF),
            statusBarIconBrightness: Brightness.dark),
        actions: [
          IconButton(
              onPressed: () {
                Navigator.push(context, SearchPage.route());
              },
              icon: const Icon(
                Icons.search,
                size: 20,
                color: Colors.black,
              )),
          Stack(
            children: [
              SizedBox(
                height: double.infinity,
                child: Ink(
                  decoration: const ShapeDecoration(
                    color: Color(0xFFFFFFFF),
                    shape: CircleBorder(),
                  ),
                  child: IconButton(
                      onPressed: () async {
                        try {
                          final result =
                              await InternetAddress.lookup('example.com');
                          if (result.isNotEmpty &&
                              result[0].rawAddress.isNotEmpty) {
                            Navigator.push(context, CartPage.route());
                          }
                        } on SocketException catch (_) {
                          Common.toastMsg('No Internet Connection');
                        }
                      },
                      icon: const Icon(
                        Icons.shopping_cart_outlined,
                        size: 20,
                        color: Colors.black87,
                      )),
                ),
              ),
              Positioned(
                right: 12,
                bottom: 12,
                child: StreamBuilder(
                  stream: cartCountBloc.allCartCount,
                  builder: (context, AsyncSnapshot<CartCountModel> snapshot) {
                    if (snapshot.hasData) {
                      return Container(
                        padding: const EdgeInsets.all(4.0),
                        decoration: const ShapeDecoration(
                            shape: CircleBorder(), color: Color(0xFFF68721)),
                        child: Text(
                          '${snapshot.data!.data!.cartqtycount}',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 8, color: Colors.white),
                        ),
                      );
                    }
                    return const Text('');
                  },
                ),
              )
            ],
          ),
        ],
      ),
      body: const SafeArea(
        child: OffersBody(),
      ),
      bottomNavigationBar: const HomeBottomNavBar(isHome: 0,),
    );
  }
}
