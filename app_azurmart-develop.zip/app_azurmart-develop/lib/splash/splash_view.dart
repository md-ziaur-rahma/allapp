import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:upgrader/upgrader.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute<void>(builder: (_) => const SplashScreen());
  }
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  startTime() async {
    try {
      final result = await InternetAddress.lookup('example.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        // connected
        var _duration = const Duration(seconds: 2);
        return Timer(_duration, navigationPage);
      }else{
        // not connected
        var _duration = const Duration(seconds: 2);
        return Timer(_duration, noInternetPage);
      }
    } on SocketException catch (_) {
      print('not connected');
      var _duration = const Duration(seconds: 2);
      return Timer(_duration, noInternetPage);
    }

  }

  void navigationPage() {
    Navigator.of(context).pushReplacementNamed('/HomeScreen');
  }

  void noInternetPage() {
    Navigator.of(context).pushReplacementNamed('/NoInternetPage');
  }

  @override
  void initState() {
    // SystemChrome.setSystemUIOverlayStyle(
    //     SystemUiOverlayStyle(
    //     statusBarColor: Colors.lightBlueAccent,
    //     statusBarIconBrightness: Brightness.light));
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
    super.initState();
    startTime();
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: SystemUiOverlay.values);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.lightBlueAccent,
      body: SplashView(),
    );
  }
}

class SplashView extends StatelessWidget {
  final Shader linearGradient = LinearGradient(
    // colors: <Color>[Color(0xffDA44bb), Color(0xff8921aa)],
    colors: <Color>[const Color(0xFF000000), const Color(0xFF000000).withOpacity(0.6)],
  ).createShader(const Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  SplashView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: const [
        Expanded(
            flex: 1,
            child: Center(
              child: Image(image: AssetImage('images/azura_logo_medium.png'),color: Colors.black,),
            )
        ),
        // SizedBox(height: 8,),
        // Text('Azura Mart',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold,foreground: Paint()..shader = linearGradient),)
      ],
    );
  }
}

