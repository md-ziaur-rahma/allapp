import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_notifier/common_notifier.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/common_widgets/no_items.dart';
import 'package:azuramartmy/my_bloc/search_bloc.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/search_models.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/wishlist/add_to_wish.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';

class SearchResultBody extends StatefulWidget {
  const SearchResultBody({Key? key, this.keyword}) : super(key: key);
  final String? keyword;

  @override
  _SearchResultBodyState createState() => _SearchResultBodyState();
}

class _SearchResultBodyState extends State<SearchResultBody> {
  SearchModels searchModels = SearchModels();
  bool canLoading = true;

  @override
  void initState() {
    searchModels.data = [];
    canLoading = true;
    searchBloc.page = 1;
    searchBloc.fetchAllSearch(widget.keyword);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: StreamBuilder(
          stream: searchBloc.allSearchResult,
          builder: (context, AsyncSnapshot<SearchModels> snapshot) {
            if (snapshot.hasData) {
              Provider.of<CommonNotifier>(context, listen: false)
                  .changeLoading(false);
              if (snapshot.data!.data!.isEmpty) {
                canLoading = false;
              } else {
                if (snapshot.data!.data!.length < 10) {
                  canLoading = false;
                }
                for (var i = 0; i < snapshot.data!.data!.length; i++) {
                  searchModels.data!.add(snapshot.data!.data![i]);
                }
              }
              return searchModels.data!.isEmpty
                  ? const NoItemsCard()
                  : CustomScrollView(
                      scrollDirection: Axis.vertical,
                      slivers: [
                        SliverGrid(
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: MediaQuery.of(context)
                                              .orientation ==
                                          Orientation.portrait
                                      ? 2
                                      : MediaQuery.of(context).size.width > 750
                                          ? 4
                                          : 3,
                                  childAspectRatio:
                                      MediaQuery.of(context).orientation ==
                                              Orientation.portrait
                                          ? screenWidth / 180.0
                                          : screenHeight / 160.0,
                                  crossAxisSpacing: 12,
                                  mainAxisSpacing: 12),
                          delegate: SliverChildBuilderDelegate(
                            (BuildContext context, int index) {
                              if (index == (searchModels.data!.length - 1) &&
                                  canLoading) {
                                Provider.of<CommonNotifier>(context,
                                        listen: false)
                                    .changeLoading(true);
                                searchBloc.fetchPagingAllSearch(widget.keyword);
                              }
                              return Container(
                                width: double.infinity,
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 0),
                                child: SearchGridItem(searchModels, index),
                              );
                            },
                            childCount: searchModels.data!.length,
                          ),
                        ),
                        SliverLayoutBuilder(
                          builder: (BuildContext context,
                              SliverConstraints constraints) {
                            if (Provider.of<CommonNotifier>(context,
                                    listen: false)
                                .isLoading) {
                              return SliverToBoxAdapter(
                                child: Center(
                                  child: Container(
                                    margin:
                                        const EdgeInsets.symmetric(vertical: 6),
                                    height: 20,
                                    width: 20,
                                    child: const CupertinoActivityIndicator(
                                      animating: true,
                                      radius: 12,
                                    ),
                                  ),
                                ),
                              );
                            } else {
                              return const SliverToBoxAdapter(
                                child: Center(
                                    child: SizedBox(
                                  height: 6,
                                )),
                              );
                            }
                          },
                        ),
                      ],
                    );
            } else if (snapshot.hasError) {
              return Center(
                child: Text(snapshot.error.toString()),
              );
            }
            return LoadingWidget(
              color: AppsColors.buttonColor,
            );
          }),
    );
  }
}

class SearchGridItem extends StatefulWidget {
  final SearchModels snapshot;
  final int index;

  const SearchGridItem(this.snapshot, this.index);

  @override
  _SearchGridItemState createState() => _SearchGridItemState();
}

class _SearchGridItemState extends State<SearchGridItem> {
  int isWish = 0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ProductDetailsPage.productUrl =
                widget.snapshot.data![widget.index].url;
            ProductDetailsPage.variantPk =
                widget.snapshot.data![widget.index].pkno;
            ProductDetailsPage.isWish =
                widget.snapshot.data![widget.index].isWish;
            Navigator.of(context).push(
                CustomRoutePageBuilder.createPageRouteLeft(
                    context, const ProductDetailsPage()));
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: Card(
        elevation: 4,
        shadowColor: Colors.black12,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              child: Container(
                padding: const EdgeInsets.all(0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  // color: Color(0xFFFFFFFF).withOpacity(0.2),
                ),
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                          padding: const EdgeInsets.symmetric(
                              vertical: 0, horizontal: 0),
                          child: ConstrainedBox(
                              constraints: const BoxConstraints(
                                  minHeight: 60, maxHeight: 120),
                              child: widget.snapshot.data![widget.index]
                                          .primaryimgrelativepath ==
                                      null
                                  ? const NoImageWidget(
                                      text: 'No Image',
                                    )
                                  : CacheImageProvide(
                                      url: widget.snapshot.data![widget.index]
                                          .primaryimgrelativepath,
                                    ))),
                    ),
                    Align(
                      alignment: Alignment.topRight,
                      child: Material(
                        color: Colors.transparent,
                        child: Ink(
                          decoration: ShapeDecoration(
                            color:
                                widget.snapshot.data![widget.index].isWish == 0
                                    ? const Color(0xFFF4F4F4).withOpacity(0.4)
                                    : const Color(0xFFF68721).withOpacity(0.1),
                            shape: const CircleBorder(),
                          ),
                          child: IconButton(
                            onPressed: () async {
                              try {
                                final result =
                                    await InternetAddress.lookup('example.com');
                                if (result.isNotEmpty &&
                                    result[0].rawAddress.isNotEmpty) {
                                  setState(() {
                                    widget.snapshot.data![widget.index].isWish =
                                        widget.snapshot.data![widget.index]
                                                    .isWish ==
                                                0
                                            ? 1
                                            : 0;
                                    AddToWish addWish = AddToWish();
                                    addWish.addToWish(widget
                                        .snapshot.data![widget.index].pkno);
                                  });
                                }
                              } on SocketException catch (_) {
                                Common.toastMsg('No Internet Connection');
                              }
                            },
                            icon:
                                widget.snapshot.data![widget.index].isWish == 0
                                    ? const Icon(
                                        Icons.favorite_outline,
                                        size: 16,
                                        color: Colors.black87,
                                      )
                                    : const Icon(
                                        Icons.favorite,
                                        size: 16,
                                        color: Color(0xFFF68721),
                                      ),
                          ),
                        ),
                      ),
                    ),
                    LayoutBuilder(
                      builder:
                          (BuildContext context, BoxConstraints constraints) {
                        if (widget.snapshot.data![widget.index].offer != 0) {
                          return GestureDetector(
                            onTap: () {
                              // setState(() {
                              //   toggleMsg = toggleMsg == 1 ? 0 : 1;
                              // });
                            },
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                height: 45,
                                width: 45,
                                padding: const EdgeInsets.all(3.0),
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.red,
                                ),
                                child: const Center(
                                  child: Text(
                                    'In \nOffer',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 12),
                                  ),
                                ),
                              ),
                            ),
                          );
                        } else {
                          return const Align(
                            alignment: Alignment.topLeft,
                            child: SizedBox(
                              height: 2,
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              // width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.only(left: 10, right: 10, bottom: 0),
                child: RichText(
                  text: TextSpan(
                    text: widget.snapshot.data![widget.index].totalfreestock! >
                            0
                        ? 'RM${widget.snapshot.data![widget.index].regularprice!.toStringAsFixed(2)}'
                        : 'Out Of Stock',
                    style: const TextStyle(
                        color: Color(0xFFF68721),
                        fontSize: 12,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                child: Text(
                  '${widget.snapshot.data![widget.index].variantname}',
                  textAlign: TextAlign.center,
                  maxLines: 3,
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87),
                ),
              ),
            ),
            const SizedBox(
              height: 8,
            )
          ],
        ),
      ),
    );
  }
}
