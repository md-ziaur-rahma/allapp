import 'package:flutter/material.dart';

class ShimmerEffectBanner extends StatelessWidget {
  const ShimmerEffectBanner({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: (MediaQuery.of(context).size.width - 32) * 0.4,
            // height: MediaQuery.of(context).orientation == Orientation.portrait
            //     ? MediaQuery.of(context).size.width * 0.42
            //     : MediaQuery.of(context).size.width > 740 ? MediaQuery.of(context).size.height * 0.86 : MediaQuery.of(context).size.height * 0.72,
            width: double.infinity,
            color: Colors.grey.withOpacity(0.2),
            child: Center(
              child: Image(image:const  AssetImage('images/azura_logo_black.png'),height: 65,width: 65,color: Colors.grey[700]),
            ),
          ),
          const SizedBox(height: 8,),
          Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 6,
                width: 6,
                margin: const EdgeInsets.only(right: 8),
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(30)
                ),
              ),
              Container(
                height: 6,
                width: 6,
                margin: const EdgeInsets.only(right: 8),
                decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(30)
                ),
              ),
              Container(
                height: 6,
                width: 6,
                margin: const EdgeInsets.only(right: 8),
                decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(30)
                ),
              ),
              Container(
                height: 6,
                width: 6,
                margin: const EdgeInsets.only(right: 8),
                decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(30)
                ),
              ),
            ],
          ),
          const SizedBox(height: 8,),
        ],
      ),
    );
  }
}
