import 'dart:io';

import 'package:azuramartmy/provider_models/whatsapp_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:optimized_cached_image/optimized_cached_image.dart';
import 'package:url_launcher/url_launcher.dart';

class MyFloatingActionButton extends StatefulWidget {
  const MyFloatingActionButton({Key? key,this.snapshot}) : super(key: key);
  // final BuildContext context;
  final WhatsappModel? snapshot;

  @override
  _MyFloatingActionButtonState createState() => _MyFloatingActionButtonState();
}

class _MyFloatingActionButtonState extends State<MyFloatingActionButton> {
  bool _isVisible = true;
  openWhatsApp(String? phone, String? message) async {
    String profile = url(phone, message);
    if (canLaunch(profile) != null) {
      await launch(profile, forceSafariVC: false, forceWebView: false);
    } else {
      throw 'Could not launch $profile';
    }
  }

  String url(String? phone, String? message) {
    if (Platform.isAndroid) {
      return "https://wa.me/$phone/?text=${Uri.parse(message!)}"; // new line
    } else {
      return "https://api.whatsapp.com/send?phone=$phone=${Uri.parse(message!)}"; // new line
    }
  }
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        GestureDetector(
          onTap: () {
            setState(() {
              _isVisible = !_isVisible;
            });
          },
          child: _isVisible
              ? const Icon(Icons.arrow_forward_ios_sharp)
              : const Icon(Icons.arrow_back_ios_sharp),
        ),
        const SizedBox(
          width: 4,
        ),
        Visibility(
          visible: _isVisible,
          child: FloatingActionButton(
            onPressed: () {
              showModalBottomSheet(
                enableDrag: true,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(16),
                          topRight: Radius.circular(16))),
                  isScrollControlled: true,
                  isDismissible: true,
                  context: context,
                  builder: (context) {
                    return DraggableScrollableSheet(
                      expand: false,
                      builder: (context, scrollController){
                        return CustomScrollView(
                          shrinkWrap: true,
                          scrollDirection: Axis.vertical,
                          controller: scrollController,
                          slivers: [
                            SliverToBoxAdapter(
                              child: Container(
                                  height: 60,
                                  width: double.infinity,
                                  decoration:
                                  const BoxDecoration(color: Color(0xFF128C7E),
                                      borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(16),
                                          topRight: Radius.circular(16))
                                  ),
                                  child: Column(
                                    mainAxisAlignment:
                                    MainAxisAlignment.center,
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: const [
                                      Text(
                                        'Need Help? Chat with us',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 18),
                                      ),
                                      Text(
                                        'Typically replies within 15 minutes',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.normal,
                                            fontSize: 16),
                                      ),
                                    ],
                                  )),
                            ),
                            SliverList(
                                delegate: SliverChildBuilderDelegate((BuildContext context, index) {
                                  return GestureDetector(
                                    onTap: () {
                                      openWhatsApp(
                                          widget.snapshot!.data![index]
                                              .phonenumber,
                                          widget.snapshot!.data![index]
                                              .defaultmsg);
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                                      margin: const EdgeInsets.symmetric(vertical: 6,horizontal: 8),
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius:
                                          BorderRadius.circular(
                                              6.0)),
                                      child: Column(
                                        mainAxisSize:
                                        MainAxisSize.min,
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .start,
                                            mainAxisSize:
                                            MainAxisSize.min,
                                            children: [
                                              Expanded(
                                                flex: 1,
                                                child: Center(
                                                  child: CircleAvatar(
                                                    radius: 30,
                                                    child: widget.snapshot!.data![index].photo == null ? const Icon(Icons.person) : OptimizedCacheImage(
                                                      imageUrl: Urls
                                                          .basePictureUrl +
                                                          widget.snapshot!.data![index].photo!,
                                                      imageBuilder:
                                                          (context,
                                                          imageProvider) =>
                                                          Container(
                                                            decoration:
                                                            BoxDecoration(
                                                              shape: BoxShape.circle,
                                                              image:
                                                              DecorationImage(
                                                                image:
                                                                imageProvider,
                                                                fit: BoxFit.cover,
                                                                // colorFilter: ColorFilter.mode(Colors.transparent, BlendMode.clear)
                                                              ),
                                                            ),
                                                          ),
                                                      placeholder:
                                                          (context,
                                                          url) =>
                                                          const Center(
                                                            child:
                                                            SizedBox(
                                                              height:
                                                              16,
                                                              width: 16,
                                                              child:
                                                              CircularProgressIndicator(
                                                                strokeWidth:
                                                                2.0,
                                                                valueColor:
                                                                AlwaysStoppedAnimation(Color(0xFFF68721)),
                                                              ),
                                                            ),
                                                          ),
                                                      errorWidget: (context,
                                                          url,
                                                          error) =>
                                                          const Icon(Icons
                                                              .error),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(
                                                width: 16,
                                              ),
                                              Expanded(
                                                flex: 4,
                                                child: Column(
                                                  children: [
                                                    SizedBox(
                                                      width: double
                                                          .infinity,
                                                      child: Text(
                                                        '${widget.snapshot!.data![index].name}',
                                                        textAlign:
                                                        TextAlign
                                                            .start,
                                                        style: const TextStyle(
                                                            color: Colors
                                                                .black87,
                                                            fontSize:
                                                            18,
                                                            fontWeight:
                                                            FontWeight.w600),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                        width: double
                                                            .infinity,
                                                        child: Text(
                                                          '${widget.snapshot!.data![index].designation}',
                                                          textAlign:
                                                          TextAlign
                                                              .start,
                                                        ))
                                                  ],
                                                ),
                                              ),
                                              Align(
                                                  alignment:
                                                  Alignment
                                                      .topRight,
                                                  child: Container(
                                                    height: 6,
                                                    width: 6,
                                                    decoration: const BoxDecoration(
                                                        color: Colors
                                                            .green,
                                                        shape: BoxShape
                                                            .circle),
                                                  ))
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                }, childCount: widget.snapshot!.data!.length,)
                            )
                          ],
                        );
                      },
                    );
                  }
              );



              // showDialog(
              //   useSafeArea: true,
              //     context: context,
              //     builder: (context) {
              //       return AlertDialog(
              //         // contentPadding: const EdgeInsets.all(2),
              //         titlePadding: const EdgeInsets.all(0),
              //         backgroundColor: Color(0xFFF4F4F4),
              //         title: Container(
              //             height: 60,
              //             width: double.infinity,
              //             decoration:
              //             BoxDecoration(color: Color(0xFF128C7E)),
              //             child: Column(
              //               mainAxisAlignment:
              //               MainAxisAlignment.center,
              //               crossAxisAlignment:
              //               CrossAxisAlignment.center,
              //               mainAxisSize: MainAxisSize.min,
              //               children: [
              //                 Text(
              //                   'Need Help? Chat with us',
              //                   style: TextStyle(
              //                       color: Colors.white,
              //                       fontWeight: FontWeight.bold,
              //                       fontSize: 18),
              //                 ),
              //                 Text(
              //                   'Typically replies within 15 minutes',
              //                   style: TextStyle(
              //                       color: Colors.white,
              //                       fontWeight: FontWeight.normal,
              //                       fontSize: 16),
              //                 ),
              //               ],
              //             )),
              //         contentPadding: const EdgeInsets.all(0),
              //         content: CustomScrollView(
              //           // shrinkWrap: true,
              //           scrollDirection: Axis.vertical,
              //           slivers: [
              //             SliverList(
              //                 delegate: SliverChildBuilderDelegate((BuildContext context, index) {
              //                   return GestureDetector(
              //                     onTap: () {
              //                       openWhatsApp(
              //                           widget.snapshot.data[index]
              //                               .phonenumber,
              //                           widget.snapshot.data[index]
              //                               .defaultmsg);
              //                     },
              //                     child: Container(
              //                       padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              //                       margin: const EdgeInsets.symmetric(vertical: 6,horizontal: 8),
              //                       decoration: BoxDecoration(
              //                           color: Colors.white,
              //                           borderRadius:
              //                           BorderRadius.circular(
              //                               6.0)),
              //                       child: Column(
              //                         mainAxisSize:
              //                         MainAxisSize.min,
              //                         children: [
              //                           Row(
              //                             mainAxisAlignment:
              //                             MainAxisAlignment
              //                                 .start,
              //                             mainAxisSize:
              //                             MainAxisSize.min,
              //                             children: [
              //                               Expanded(
              //                                 flex: 1,
              //                                 child: Center(
              //                                   child: CircleAvatar(
              //                                     radius: 30,
              //                                     child: widget.snapshot.data[index].photo == null ? Icon(Icons.person) : OptimizedCacheImage(
              //                                       imageUrl: Urls
              //                                           .basePictureUrl +
              //                                           widget.snapshot.data[index].photo,
              //                                       imageBuilder:
              //                                           (context,
              //                                           imageProvider) =>
              //                                           Container(
              //                                             decoration:
              //                                             BoxDecoration(
              //                                               shape: BoxShape.circle,
              //                                               image:
              //                                               DecorationImage(
              //                                                 image:
              //                                                 imageProvider,
              //                                                 fit: BoxFit.cover,
              //                                                 // colorFilter: ColorFilter.mode(Colors.transparent, BlendMode.clear)
              //                                               ),
              //                                             ),
              //                                           ),
              //                                       placeholder:
              //                                           (context,
              //                                           url) =>
              //                                           Center(
              //                                             child:
              //                                             SizedBox(
              //                                               height:
              //                                               16,
              //                                               width: 16,
              //                                               child:
              //                                               CircularProgressIndicator(
              //                                                 strokeWidth:
              //                                                 2.0,
              //                                                 valueColor:
              //                                                 AlwaysStoppedAnimation(Color(0xFFF68721)),
              //                                               ),
              //                                             ),
              //                                           ),
              //                                       errorWidget: (context,
              //                                           url,
              //                                           error) =>
              //                                           Icon(Icons
              //                                               .error),
              //                                     ),
              //                                   ),
              //                                 ),
              //                               ),
              //                               SizedBox(
              //                                 width: 16,
              //                               ),
              //                               Expanded(
              //                                 flex: 4,
              //                                 child: Column(
              //                                   children: [
              //                                     SizedBox(
              //                                       width: double
              //                                           .infinity,
              //                                       child: Text(
              //                                         '${widget.snapshot.data[index].name}',
              //                                         textAlign:
              //                                         TextAlign
              //                                             .start,
              //                                         style: TextStyle(
              //                                             color: Colors
              //                                                 .black87,
              //                                             fontSize:
              //                                             18,
              //                                             fontWeight:
              //                                             FontWeight.w600),
              //                                       ),
              //                                     ),
              //                                     SizedBox(
              //                                         width: double
              //                                             .infinity,
              //                                         child: Text(
              //                                           '${widget.snapshot.data[index].designation}',
              //                                           textAlign:
              //                                           TextAlign
              //                                               .start,
              //                                         ))
              //                                   ],
              //                                 ),
              //                               ),
              //                               Align(
              //                                   alignment:
              //                                   Alignment
              //                                       .topRight,
              //                                   child: Container(
              //                                     height: 6,
              //                                     width: 6,
              //                                     decoration: BoxDecoration(
              //                                         color: Colors
              //                                             .green,
              //                                         shape: BoxShape
              //                                             .circle),
              //                                   ))
              //                             ],
              //                           ),
              //                         ],
              //                       ),
              //                     ),
              //                   );
              //                 }, childCount: widget.snapshot.data.length,)
              //             )
              //           ],
              //         ),
              //       );
              //     });
            },
            backgroundColor: const Color(0xFF25D366),
            child: const FaIcon(
              FontAwesomeIcons.whatsapp,
              color: Colors.white,
            ),
          ),
        )
      ],
    );
  }
}
