import 'package:flutter/material.dart';

class DefaultGridView extends StatelessWidget {
  const DefaultGridView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const SizedBox(
          height: 16,
        ),
        Row(
          children: [
            Expanded(
              flex: 1,
              child: Container(
                height: 140,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(6.0)
                ),
                child: Center(
                  child: Image(image: const AssetImage('images/azura_logo_black.png'),height: 35,width: 35,color: Colors.grey[700]),
                ),
              ),
            ),
            const SizedBox(
              width: 16,
            ),
            Expanded(
              flex: 1,
              child: Container(
                height: 140,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6.0)
                ),
                child: Center(
                  child: Image(image: const AssetImage('images/azura_logo_black.png'),height: 24,width: 24,color: Colors.grey[700]),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 16,
        ),
        Row(
          children: [
            Expanded(
              flex: 1,
              child: Container(
                height: 140,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6.0)
                ),
                child: Center(
                  child: Image(image: const AssetImage('images/azura_logo_black.png'),height: 35,width: 35,color: Colors.grey[700]),
                ),
              ),
            ),
            const  SizedBox(
              width: 16,
            ),
            Expanded(
              flex: 1,
              child: Container(
                height: 140,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6.0)
                ),
                child: Center(
                  child: Image(image: const AssetImage('images/azura_logo_black.png'),height: 24,width: 24,color: Colors.grey[700]),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 16,
        ),
        Row(
          children: [
            Expanded(
              flex: 1,
              child: Container(
                height: 140,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6.0)
                ),
                child: Center(
                  child: Image(image:const  AssetImage('images/azura_logo_black.png'),height: 35,width: 35,color: Colors.grey[700]),
                ),
              ),
            ),
            const SizedBox(
              width: 16,
            ),
            Expanded(
              flex: 1,
              child: Container(
                height: 140,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6.0)
                ),
                child: Center(
                  child: Image(image: const AssetImage('images/azura_logo_black.png'),height: 24,width: 24,color: Colors.grey[700]),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
