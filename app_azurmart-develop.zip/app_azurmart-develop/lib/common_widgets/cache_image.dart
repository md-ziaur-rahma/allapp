import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:optimized_cached_image/optimized_cached_image.dart';

class CacheImageProvide extends StatelessWidget {
  const CacheImageProvide({Key? key,this.url}) : super(key: key);
  final String? url;

  @override
  Widget build(BuildContext context) {
    return OptimizedCacheImage(
      imageUrl: Urls.basePictureUrl + url!,
      imageBuilder:
          (context, imageProvider) =>
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: imageProvider,
                // fit: BoxFit.cover,
                // colorFilter: ColorFilter.mode(Colors.transparent, BlendMode.clear)
              ),
            ),
          ),
      placeholder: (context, url) =>
          Center(
            child: SizedBox(
              height: 16,
              width: 16,
              child:
              CircularProgressIndicator(
                strokeWidth: 2.0,
                valueColor:
                AlwaysStoppedAnimation(
                    AppsColors.buttonColor),
              ),
            ),
          ),
      errorWidget:
          (context, url, error) =>
          const Icon(Icons.error),
    );
  }
}
