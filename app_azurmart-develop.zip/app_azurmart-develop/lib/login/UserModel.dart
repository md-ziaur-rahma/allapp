class UserModel {
  int? _status;
  bool? _success;
  int? _code;
  String? _message;
  String? _description;
  Data? _data;
  dynamic _errors;
  Api? _api;

  int? get status => _status;
  bool? get success => _success;
  int? get code => _code;
  String? get message => _message;
  String? get description => _description;
  Data? get data => _data;
  dynamic get errors => _errors;
  Api? get api => _api;

  UserModel(
      {int? status,
      bool? success,
      int? code,
      String? message,
      String? description,
      Data? data,
      dynamic errors,
      Api? api}) {
    _status = status;
    _success = success;
    _code = code;
    _message = message;
    _description = description;
    _data = data;
    _errors = errors;
    _api = api;
  }

  UserModel.fromJson(dynamic json) {
    _status = json["status"];
    _success = json["success"];
    _code = json["code"];
    _message = json["message"];
    _description = json["description"];
    _data = json["data"] != null ? Data.fromJson(json["data"]) : null;
    _errors = json["errors"];
    _api = json["api"] != null ? Api.fromJson(json["api"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["status"] = _status;
    map["success"] = _success;
    map["code"] = _code;
    map["message"] = _message;
    map["description"] = _description;
    if (_data != null) {
      map["data"] = _data!.toJson();
    }
    map["errors"] = _errors;
    if (_api != null) {
      map["api"] = _api!.toJson();
    }
    return map;
  }
}

class Api {
  String? _version;

  String? get version => _version;

  Api({String? version}) {
    _version = version;
  }

  Api.fromJson(dynamic json) {
    _version = json["version"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["version"] = _version;
    return map;
  }
}
class Data {
  String? _token;
  String? _userName;
  String? _email;
  String? _mobileNo;
  int? _authId;
  String? _lastName;
  String? _profilePic;

  String? get token => _token;
  String? get userName => _userName;
  String? get email => _email;
  String? get mobileNo => _mobileNo;
  int? get authId => _authId;
  String? get lastName => _lastName;
  String? get profilePic => _profilePic;

  Data({
    String? token,
    String? userName,
    String? email,
    String? mobileNo,
    int? authId,
    String? lastName,
    String? profilePic,
  }) {
    _token = token;
    _userName = userName;
    _email = email;
    _mobileNo = mobileNo;
    _authId = authId;
    _lastName = lastName;
    _profilePic = profilePic;
  }

  Data.fromJson(dynamic json) {
    _token = json["token"];
    _userName = json["user_name"];
    _email = json["email"];
    _mobileNo = json["mobile_no"];
    _authId = json["auth_id"];
    _lastName = json["last_name"];
    _profilePic = json["profile_pic"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["token"] = _token;
    map["user_name"] = _userName;
    map["email"] = _email;
    map["mobile_no"] = _mobileNo;
    map["auth_id"] = _authId;
    map["last_name"] = _lastName;
    map["profile_pic"] = _profilePic;
    return map;
  }
}
