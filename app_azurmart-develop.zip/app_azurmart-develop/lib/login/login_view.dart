import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/forgot_password/forgot_password_page.dart';
import 'package:azuramartmy/forgot_password/opt_notifier.dart';
import 'package:azuramartmy/home/home_page.dart';
import 'package:azuramartmy/login/UserModel.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/ip_address.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_facebook_login/flutter_facebook_login.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' show Client;
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';

class LoginView extends StatefulWidget {
  const LoginView({Key? key}) : super(key: key);

  @override
  _LoginViewState createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final _usernameFocusNode = FocusNode();
  final _passwordFocusNode = FocusNode();

  final GlobalKey<FormState> _loginFormKey = GlobalKey<FormState>();
  var userController = TextEditingController();
  var passwordController = TextEditingController();
  String? email;
  String? password;
  bool canLoading = false;

  String? validationUserName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Mobile/Email!';
    } else {
      return null;
    }
  }

  String? validationPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Password!';
    } else if (value.length < 5) {
      return 'Enter minimum 5 digit';
    } else {
      return null;
    }
  }

  bool _obscureText = true;
  void _toggle() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  @override
  void initState() {
    canLoading = false;
    super.initState();
  }

  Future<UserModel?> login(String? username, String? password) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    final ipAddress = await IpInfoApi.getIPAddress();
    print(ipAddress);
    Map<String, dynamic> data = {
      'email': username,
      'password': password,
      'ip_address': ipAddress,
      'session': '$session',
      'type': '${Provider.of<OtpNotifier>(context, listen: false).userType}',
    };
    var requestBody = json.encode(data);
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.login);
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      final Map<String, dynamic> body = await json.decode(response.body);
      setState(() {
        canLoading = false;
      });
      UserModel userModel = UserModel.fromJson(body);
      print(userModel.message);
      if (userModel.status == 1) {
        SharedPreferences localStorage = await SharedPreferences.getInstance();
        localStorage.setString(
            SharedPreferenceUtils.TOKEN, userModel.data!.token!);
        localStorage.setInt(
            SharedPreferenceUtils.USER_ID, userModel.data!.authId!);
        localStorage.setString(
            SharedPreferenceUtils.USER_NAME, userModel.data!.userName!);
        localStorage.setString(SharedPreferenceUtils.LAST_NAME,
            userModel.data!.lastName != null ? userModel.data!.lastName! : "");
        localStorage.setString(
            SharedPreferenceUtils.EMAIL, userModel.data!.email!);
        localStorage.setString(SharedPreferenceUtils.MOBILE,
            userModel.data!.mobileNo != null ? userModel.data!.mobileNo! : "");
        localStorage.setString(
            SharedPreferenceUtils.profilePic,
            userModel.data!.profilePic != null
                ? userModel.data!.profilePic!
                : "");
        // localStorage.setInt(SharedPreferenceUtils.ROLE_ID, userModel.data.roleId);
        // localStorage.setInt(SharedPreferenceUtils.LOCATION, userModel.data.userLocation);

        SharedPreferenceUtils.userIdF = userModel.data!.authId;
        SharedPreferenceUtils.usernameF = userModel.data!.userName;
        SharedPreferenceUtils.mobileF = userModel.data!.mobileNo;
        SharedPreferenceUtils.emailF = userModel.data!.email;
        SharedPreferenceUtils.lastNameF = userModel.data!.lastName;
        SharedPreferenceUtils.profilePicF = userModel.data!.profilePic;

        Navigator.pushAndRemoveUntil(
            context, HomePage.route(), (route) => false);
      } else {
        Common.toastMsg('${userModel.message}');
      }

      return userModel;
    } on FormatException catch (e) {
      print(e);
    }

    return null;
  }

  // ......... getApple ID data .........
  void getAppleData() async {
    final credential = await SignInWithApple.getAppleIDCredential(
      scopes: [
        AppleIDAuthorizationScopes.email,
        AppleIDAuthorizationScopes.fullName,
      ],
    );

    print('${credential.email}');

    print(credential);

    // _googleSignIn.signIn().then((GoogleSignInAccount? acc) async {
    //   GoogleSignInAuthentication auth = await acc!.authentication;
    //   print(acc.id);
    //   print(acc.email);
    //   print(acc.displayName);
    //   print(acc.photoUrl);
    //
    //   googleLogin(acc.id,acc.displayName, acc.email, acc.photoUrl);
    //
    //   acc.authentication.then((GoogleSignInAuthentication auth) async {
    //     print('Auth id token'+auth.idToken!);
    //     print('Auth access token'+auth.accessToken!);
    //   });
    // });
  }

  void getGoogleData() async {
    GoogleSignIn _googleSignIn = GoogleSignIn(
      scopes: [
        'email',
        // you can add extras if you require
      ],
    );

    _googleSignIn.signIn().then((GoogleSignInAccount? acc) async {
      GoogleSignInAuthentication auth = await acc!.authentication;
      print(acc.id);
      print(acc.email);
      print(acc.displayName);
      print(acc.photoUrl);

      googleLogin(acc.id, acc.displayName, acc.email, acc.photoUrl);

      acc.authentication.then((GoogleSignInAuthentication auth) async {
        print('Auth id token' + auth.idToken!);
        print('Auth access token' + auth.accessToken!);
      });
    });
  }

  Future<UserModel?> googleLogin(
      String id, String? username, String email, String? photoUrl) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    final ipAddress = await IpInfoApi.getIPAddress();
    print(ipAddress);
    print('ip');
    Map<String, dynamic> data = {
      'google_id': '$id',
      'email': '$email',
      'username': '$username',
      'photo_url': '$photoUrl',
      'ip_address': ipAddress,
      'session': '$session',
      'type': '${Provider.of<OtpNotifier>(context, listen: false).userType}',
    };
    print('post');
    var requestBody = json.encode(data);
    Client client = Client();
    print('body');
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.googleLogin);
      print('url');
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      print('parsed');
      UserModel userModel = UserModel.fromJson(body);
      print(userModel.message);
      if (userModel.status == 1) {
        SharedPreferences localStorage = await SharedPreferences.getInstance();
        localStorage.setString(
            SharedPreferenceUtils.TOKEN, userModel.data!.token!);
        localStorage.setInt(
            SharedPreferenceUtils.USER_ID, userModel.data!.authId!);
        localStorage.setString(
            SharedPreferenceUtils.USER_NAME, userModel.data!.userName!);
        localStorage.setString(SharedPreferenceUtils.LAST_NAME,
            userModel.data!.lastName != null ? userModel.data!.lastName! : "");
        localStorage.setString(
            SharedPreferenceUtils.EMAIL, userModel.data!.email!);
        localStorage.setString(SharedPreferenceUtils.MOBILE,
            userModel.data!.mobileNo != null ? userModel.data!.mobileNo! : "");
        localStorage.setString(
            SharedPreferenceUtils.profilePic,
            userModel.data!.profilePic != null
                ? userModel.data!.profilePic!
                : '');
        // localStorage.setInt(SharedPreferenceUtils.ROLE_ID, userModel.data.roleId);
        // localStorage.setInt(SharedPreferenceUtils.LOCATION, userModel.data.userLocation);

        SharedPreferenceUtils.userIdF = userModel.data!.authId;
        SharedPreferenceUtils.usernameF = userModel.data!.userName;
        SharedPreferenceUtils.mobileF = userModel.data!.mobileNo;
        SharedPreferenceUtils.emailF = userModel.data!.email;
        SharedPreferenceUtils.lastNameF = userModel.data!.lastName;
        SharedPreferenceUtils.profilePicF = userModel.data!.profilePic;

        Navigator.pushAndRemoveUntil(
            context, HomePage.route(), (route) => false);
      } else {
        Common.toastMsg('${userModel.message}');
        // ScaffoldMessenger.of(context)
        //   ..hideCurrentSnackBar()
        //   ..showSnackBar(SnackBar(content: Text('${userModel.message}')));
      }

      return userModel;
    } on FormatException catch (e) {
      print(e);
    }

    return null;
  }

  // void facebookLogin() async {
  //   final facebookLogin = FacebookLogin();
  //   final facebookLoginResult = await facebookLogin.logIn(['email', 'public_profile']);
  //
  //   print(facebookLoginResult.accessToken);
  //   print(facebookLoginResult.accessToken.token);
  //   print(facebookLoginResult.accessToken.expires);
  //   print(facebookLoginResult.accessToken.permissions);
  //   print(facebookLoginResult.accessToken.userId);
  //   print(facebookLoginResult.accessToken.isValid());
  //
  //   print(facebookLoginResult.errorMessage);
  //   print(facebookLoginResult.status);
  //
  //   final token = facebookLoginResult.accessToken.token;
  //
  //   /// for profile details also use the below code
  //   final url = Uri.parse('https://graph.facebook.com/v2.12/me?fields=name,first_name,last_name,email&access_token=$token');
  //   Client client = Client();
  //   final graphResponse = await client.get(url);
  //   final profile = json.decode(graphResponse.body);
  //   print(profile);
  //   /*
  //   from profile you will get the below params
  //   {
  //    "name": "Iiro Krankka",
  //    "first_name": "Iiro",
  //    "last_name": "Krankka",
  //    "email": "iiro.krankka\u0040gmail.com",
  //    "id": "<user id here>"
  //   }
  //  */
  // }

  @override
  void dispose() {
    _usernameFocusNode.dispose();
    _passwordFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      scrollDirection: Axis.vertical,
      slivers: [
        SliverToBoxAdapter(
          child: Align(
            alignment: Alignment.topLeft,
            child: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.close,
                size: 24,
              ),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 16,
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            width: double.infinity,
            child: Center(
              child: Image(
                image: AssetImage('images/azura_logo_large.png'),
                width: 80,
                height: 80,
              ),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 50,
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Form(
              key: _loginFormKey,
              child: Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      style: const TextStyle(
                          color: Colors.black87,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                      controller: userController,
                      validator: validationUserName,
                      cursorColor: Colors.black87,
                      textInputAction: TextInputAction.next,
                      onSaved: (String? val) {
                        email = val;
                      },
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        alignLabelWithHint: true,
                        prefixIcon: const Icon(
                          Icons.person_outline,
                          color: Colors.black54,
                        ),
                        filled: true,
                        fillColor: const Color(0xFFD1D2D3).withOpacity(0.4),
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 16),
                        hintText: 'Phone/Email',
                        hintStyle: const TextStyle(
                            color: Colors.black54, fontSize: 18),
                        focusedBorder: InputBorder.none,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        errorBorder: InputBorder.none,
                        disabledBorder: InputBorder.none,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      textAlign: TextAlign.start,
                      style: const TextStyle(
                          color: Colors.black87,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                      controller: passwordController,
                      validator: validationPassword,
                      textInputAction: TextInputAction.done,
                      keyboardType: TextInputType.visiblePassword,
                      obscureText: _obscureText,
                      maxLines: 1,
                      cursorColor: Colors.black87,
                      onSaved: (String? val) {
                        password = val;
                      },
                      decoration: InputDecoration(
                        // icon: Icon(Icons.vpn_key_outlined),
                        prefixIcon: const Icon(
                          Icons.vpn_key_outlined,
                          color: Colors.black54,
                        ),
                        suffixIcon: GestureDetector(
                          onTap: () {
                            _toggle();
                          },
                          child: _obscureText
                              ? const Icon(
                                  Icons.visibility_off,
                                  color: Colors.black54,
                                )
                              : const Icon(
                                  Icons.visibility,
                                  color: Colors.black54,
                                ),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 16),
                        fillColor: const Color(0xFFD1D2D3).withOpacity(0.4),
                        filled: true,
                        hintText: 'Password',
                        focusedBorder: InputBorder.none,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        errorBorder: InputBorder.none,
                        disabledBorder: InputBorder.none,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(context, ForgotPasswordPage.route());
                      },
                      child: const Text(
                        'Forgot Your Password?',
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    height: 50,
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        if (_loginFormKey.currentState!.validate()) {
                          _loginFormKey.currentState!.save();
                          setState(() {
                            canLoading = true;
                          });
                          try {
                            final result =
                                await InternetAddress.lookup('example.com');
                            if (result.isNotEmpty &&
                                result[0].rawAddress.isNotEmpty) {
                              login(email, password);
                            }
                          } on SocketException catch (_) {
                            Common.toastMsg('No Internet Connection');
                            setState(() {
                              canLoading = false;
                            });
                          }
                        }
                      },
                      style: ElevatedButton.styleFrom(
                          primary: AppsColors.buttonColor,
                          shape: const RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(6.0)))),
                      child: !canLoading
                          ? const Text(
                              'Log in',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600),
                            )
                          : const Center(
                              child: SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Radio(
                                activeColor: AppsColors.buttonColor,
                                value: 1,
                                groupValue:
                                    context.watch<OtpNotifier>().userType,
                                onChanged: (dynamic value) {
                                  context
                                      .read<OtpNotifier>()
                                      .changeUserType(value);
                                }),
                            const SizedBox(
                              width: 0,
                            ),
                            GestureDetector(
                              onTap: () {
                                context.read<OtpNotifier>().changeUserType(1);
                              },
                              child: Text(
                                'Customer',
                                style: TextStyle(
                                    color:
                                        context.watch<OtpNotifier>().userType ==
                                                1
                                            ? Colors.black
                                            : Colors.black45,
                                    fontSize: 14),
                              ),
                            )
                          ],
                        ),
                        const SizedBox(
                          width: 16,
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Radio(
                                activeColor: AppsColors.buttonColor,
                                value: 2,
                                groupValue:
                                    context.watch<OtpNotifier>().userType,
                                onChanged: (dynamic value) {
                                  context
                                      .read<OtpNotifier>()
                                      .changeUserType(value);
                                }),
                            const SizedBox(
                              width: 0,
                            ),
                            GestureDetector(
                              onTap: () {
                                context.read<OtpNotifier>().changeUserType(2);
                              },
                              child: Text(
                                'Reseller',
                                style: TextStyle(
                                    color:
                                        context.watch<OtpNotifier>().userType ==
                                                1
                                            ? Colors.black45
                                            : Colors.black,
                                    fontSize: 14),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  LayoutBuilder(builder:
                      (BuildContext context, BoxConstraints constraints) {
                    if (Platform.isIOS) {
                      return const SizedBox(
                        height: 0,
                      );
                    } else {
                      return const SizedBox(
                        width: double.infinity,
                        child: Text(
                          'or Sign in with',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.black54,
                            fontSize: 16,
                          ),
                        ),
                      );
                    }
                  }),
                  const SizedBox(
                    height: 16,
                  ),
                  LayoutBuilder(builder:
                      (BuildContext context, BoxConstraints constraints) {
                    if (Platform.isIOS) {
                      return const SizedBox(
                        height: 0,
                      );

                      // return SizedBox(
                      //   width: double.infinity,
                      //   child: OutlinedButton(
                      //     onPressed: (){
                      //       getAppleData();
                      //     },
                      //     child: Row(
                      //       mainAxisSize: MainAxisSize.max,
                      //       crossAxisAlignment: CrossAxisAlignment.center,
                      //       mainAxisAlignment: MainAxisAlignment.center,
                      //       children: const [
                      //         FaIcon(
                      //           FontAwesomeIcons.apple,
                      //           color: Color(0xFFA1A1A1),
                      //           size: 20,
                      //         ),
                      //         SizedBox(
                      //           width: 16,
                      //         ),
                      //         Text('Sign up with Apple ID',style: TextStyle(color: Colors.black87,fontSize: 14),)
                      //       ],
                      //     ),
                      //   ),
                      // );
                    } else {
                      return SizedBox(
                        width: double.infinity,
                        child: OutlinedButton(
                          onPressed: () {
                            getGoogleData();
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              FaIcon(
                                FontAwesomeIcons.google,
                                color: Color(0xFFDB4437),
                                size: 20,
                              ),
                              SizedBox(
                                width: 16,
                              ),
                              Text(
                                'Sign up with Google',
                                style: TextStyle(
                                    color: Colors.black87, fontSize: 14),
                              )
                            ],
                          ),
                        ),
                      );
                    }
                  }),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
