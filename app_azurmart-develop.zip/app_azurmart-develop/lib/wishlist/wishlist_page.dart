import 'dart:io';

import 'package:azuramartmy/cart/cart_page.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/login/login_page.dart';
import 'package:azuramartmy/my_account/account_page.dart';
import 'package:azuramartmy/my_bloc/cart_count_bloc.dart';
import 'package:azuramartmy/my_bloc/wishlist_bloc.dart';
import 'package:azuramartmy/provider_models/cart_count_model.dart';
import 'package:azuramartmy/search/search_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/wishlist/wishlist_body.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class WishListPage extends StatefulWidget {
  const WishListPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const WishListPage());
  }

  @override
  _WishListPageState createState() => _WishListPageState();
}

class _WishListPageState extends State<WishListPage> {

  Future<void> reload() async {
    try {
      final result = await InternetAddress.lookup('example.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        return wishListBloc.fetchAllWishLists();
      }
    } on SocketException catch (_) {
      Common.toastMsg('No Internet Connection');
      return;
    }
  }
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
  GlobalKey<RefreshIndicatorState>();

  @override
  Widget build(BuildContext context) {
    cartCountBloc.fetchAllCartCount();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarBrightness: Brightness.dark,
            statusBarIconBrightness: Brightness.dark),
        iconTheme: const IconThemeData(color: Colors.black87),
        title: const Text(
          'Wishlist',
          style: TextStyle(color: Colors.black),
        ),
        actions: [
          IconButton(
              onPressed: () {
                Navigator.push(context, SearchPage.route());
              },
              icon: const Icon(
                Icons.search,
                size: 20,
                color: Colors.black,
              )),
          // IconButton(
          //     onPressed: () {
          //       Navigator.push(context, FilterPage.route());
          //     },
          //     icon: Icon(
          //       Icons.filter_alt_outlined,
          //       size: 20,
          //       color: Colors.black,
          //     )),
          Stack(
            children: [
              SizedBox(
                height: double.infinity,
                child: Ink(
                  decoration: const ShapeDecoration(
                    color: Color(0xFFFFFFFF),
                    shape: CircleBorder(),
                  ),
                  child: IconButton(
                      onPressed: () async {
                        try {
                          final result = await InternetAddress.lookup('example.com');
                          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                            Navigator.push(context, CartPage.route());
                          }
                        } on SocketException catch (_) {
                          Common.toastMsg('No Internet Connection');
                        }
                      },
                      icon: const Icon(
                        Icons.shopping_cart_outlined,
                        size: 20,
                        color: Colors.black,
                      )),
                ),
              ),
              Positioned(
                right: 12,
                bottom: 12,
                child: StreamBuilder(
                  stream: cartCountBloc.allCartCount,
                  builder: (context, AsyncSnapshot<CartCountModel> snapshot) {
                    if (snapshot.hasData) {
                      return Container(
                        padding: const EdgeInsets.all(4.0),
                        decoration: const ShapeDecoration(
                            shape: CircleBorder(), color: Color(0xFFF68721)),
                        child: Text(
                          '${snapshot.data!.data!.cartqtycount}',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 8, color: Colors.white),
                        ),
                      );
                    }
                    return const Text('');
                  },
                ),
              )
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: RefreshIndicator(
          key: _refreshIndicatorKey,
          color: AppsColors.buttonColor,
          onRefresh: reload,
          child: const WishListBody(),
        ),
      ),
      bottomNavigationBar: const WishListBottomNavBar(),
    );
  }
}

class WishListBottomNavBar extends StatefulWidget {
  const WishListBottomNavBar({Key? key}) : super(key: key);
  @override
  _WishListBottomNavBarState createState() => _WishListBottomNavBarState();
}

class _WishListBottomNavBarState extends State<WishListBottomNavBar> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 55,
      width: double.infinity,
      decoration: const BoxDecoration(
        color: Color(0xFFFFFFFF),
        borderRadius: BorderRadius.only(
            topRight: Radius.circular(0), topLeft: Radius.circular(0)),
        boxShadow: [
          BoxShadow(
            color: Colors.grey,
            offset: Offset(1.0, 0.0), //(x,y)
            blurRadius: 10.0,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Flexible(
            flex: 1,
            child: Center(
              child: Material(
                color: Colors.transparent,
                child: Ink(
                  decoration: ShapeDecoration(
                    color: const Color(0xFFFFFFFF).withOpacity(0.1),
                    shape: const CircleBorder(),
                  ),
                  child: IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.home_outlined,
                      size: 24,
                      color: Colors.black87,
                    ),
                  ),
                ),
              ),
            ),
          ),
          Flexible(
            flex: 1,
            child: Center(
              child: Material(
                color: Colors.transparent,
                child: Ink(
                  decoration: ShapeDecoration(
                    color: const Color(0xFFF68721).withOpacity(0.1),
                    shape: const CircleBorder(),
                  ),
                  child: IconButton(
                    onPressed: () {

                    },
                    icon: const Icon(
                      Icons.favorite_border_sharp,
                      size: 24,
                      color: Color(0xFFF68721),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Flexible(
            flex: 1,
            child: Center(
              child: Material(
                color: Colors.transparent,
                child: Ink(
                  decoration: const ShapeDecoration(
                    color: Colors.white,
                    shape: CircleBorder(),
                  ),
                  child: IconButton(
                    onPressed: () async {
                      try {
                        final result =
                        await InternetAddress.lookup('example.com');
                        if (result.isNotEmpty &&
                            result[0].rawAddress.isNotEmpty) {
                          Navigator.of(context).push(
                              CustomRoutePageBuilder.createPageRoute(
                                  context, CartPage()));
                        }
                      } on SocketException catch (_) {
                        Common.toastMsg('No internet Connection');
                      }
                    },
                    icon: const Icon(
                      Icons.shopping_cart_outlined,
                      size: 24,
                      color: Colors.black87,
                    ),
                  ),
                ),
              )
            ),
          ),
          Flexible(
            flex: 1,
            child: Center(
              child: Material(
                color: Colors.transparent,
                child: Ink(
                  decoration: ShapeDecoration(
                    color: const Color(0xFFFFFFFF).withOpacity(0.1),
                    shape: const CircleBorder(),
                  ),
                  child: IconButton(
                    onPressed: () {
                      if (SharedPreferenceUtils.userIdF == 0) {
                        Navigator.of(context).push(
                            CustomRoutePageBuilder.createPageRoute(
                                context, const LoginPage()));
                      } else {
                        Navigator.of(context).push(
                            CustomRoutePageBuilder.createPageRoute(
                                context, const MyAccountPage()));
                      }
                    },
                    icon: const Icon(
                      Icons.person_outline_outlined,
                      size: 24,
                      color:Colors.black87,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
