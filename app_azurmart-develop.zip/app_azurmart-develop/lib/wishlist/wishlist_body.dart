import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/common_widgets/no_items.dart';
import 'package:azuramartmy/my_bloc/wishlist_bloc.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/wishlist/add_to_wish.dart';
import 'package:azuramartmy/wishlist/wishlist_notifier.dart';
import 'package:flutter/material.dart';
import 'package:azuramartmy/provider_models/wish_list_model.dart';
import 'package:flutter/rendering.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:provider/provider.dart';

class WishListBody extends StatefulWidget {
  const WishListBody({Key? key}) : super(key: key);

  @override
  State<WishListBody> createState() => _WishListBodyState();
}

class _WishListBodyState extends State<WishListBody> {

  @override
  void initState() {
    wishListBloc.fetchAllWishLists();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return StreamBuilder(
        stream: wishListBloc.allWishLists,
        builder: (context, AsyncSnapshot<WishListModel> snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data!.data!.isNotEmpty) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: CustomScrollView(
                  scrollDirection: Axis.vertical,
                  slivers: [
                    SliverToBoxAdapter(
                      child: Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: const BoxDecoration(
                              color: Colors.white, shape: BoxShape.circle),
                          child: GestureDetector(
                            onTap: () {
                              context
                                  .read<WishListNotifier>()
                                  .changeListStyle();
                            },
                            child: context.watch<WishListNotifier>().isList == 1
                                ? const FaIcon(FontAwesomeIcons.borderAll)
                                : const FaIcon(FontAwesomeIcons.solidListAlt),
                          ),
                        ),
                      ),
                    ),
                    SliverLayoutBuilder(
                      builder: (BuildContext context,
                          SliverConstraints constraints) {
                        if (context.watch<WishListNotifier>().isList == 1) {
                          return SliverList(
                              delegate: SliverChildBuilderDelegate(
                                  (BuildContext context, index) {
                            return ListItemLayout(snapshot, index);
                          }, childCount: snapshot.data!.data!.length));
                        } else {
                          return SliverGrid(
                            delegate: SliverChildBuilderDelegate(
                                (BuildContext context, int index) {
                              return WishListProductCard(
                                  snapshot: snapshot, index: index);
                            }, childCount: snapshot.data!.data!.length),
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount:
                                  MediaQuery.of(context).orientation ==
                                          Orientation.portrait
                                      ? 2
                                      : MediaQuery.of(context).size.width > 740
                                          ? 4
                                          : 3,
                              mainAxisSpacing: 12,
                              childAspectRatio:
                                  MediaQuery.of(context).orientation ==
                                          Orientation.portrait
                                      ? screenWidth / 180.0
                                      : screenHeight / 150.0,
                              crossAxisSpacing: 12,
                            ),
                          );
                        }
                      },
                    )
                  ],
                ),
              );
            } else {
              return const Center(
                child: NoItemsCard(),
              );
            }
          } else if (snapshot.hasError) {
            return Center(
              child: Text(snapshot.error.toString()),
            );
          }
          return LoadingWidget(color: AppsColors.buttonColor,);
        });
  }
}

class ListItemLayout extends StatefulWidget {
  final AsyncSnapshot<WishListModel> snapshot;
  final int index;
  const ListItemLayout(this.snapshot, this.index, {Key? key}) : super(key: key);

  @override
  _ListItemLayoutState createState() => _ListItemLayoutState();
}

class _ListItemLayoutState extends State<ListItemLayout> {

  final f = DateFormat('MMM-dd  hh:mm aa');

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ProductDetailsPage.productUrl =
                widget.snapshot.data!.data![widget.index].url;
            ProductDetailsPage.variantPk =
                widget.snapshot.data!.data![widget.index].pkno;
            ProductDetailsPage.isWish =
                widget.snapshot.data!.data![widget.index].isWish;
            Navigator.of(context).push(
                CustomRoutePageBuilder
                    .createPageRouteLeft(
                    context, const ProductDetailsPage()));
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: Card(
        color: Colors.white,
        elevation: 4,
        shadowColor: Colors.black12,
        margin: const EdgeInsets.symmetric(vertical: 5),
        child: Container(
          width: double.infinity,
          color: Colors.transparent,
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                flex: 1,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(6),
                          bottomLeft: Radius.circular(6))),
                  child: ConstrainedBox(
                      constraints: const BoxConstraints(
                        maxHeight: 120,
                        minHeight: 60,
                      ),
                      child: widget.snapshot.data!.data![widget.index]
                          .primaryimgrelativepath ==
                          null
                          ? const NoImageWidget(
                        text: 'No Image',
                      )
                          : CacheImageProvide(
                        url: widget.snapshot.data!.data![widget.index]
                            .primaryimgrelativepath,
                      )),
                ),
              ),
              Expanded(
                flex: 2,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          '${widget.snapshot.data!.data![widget.index].variantname}',
                          textAlign: TextAlign.start,
                          maxLines: 2,
                          style: const TextStyle(
                              color: Colors.black87,
                              fontSize: 16,
                              fontWeight: FontWeight.w500),
                        ),
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          f.format(DateTime.parse(widget.snapshot.data!.data![widget.index].createdOn!)),
                          style: const TextStyle(color: Colors.black87, fontSize: 14),
                        ),
                      ),
                      // SizedBox(
                      //   width: double.infinity,
                      //   child: Text(
                      //     'Color : ${widget.snapshot.data.data[widget.index].color}',
                      //     style: TextStyle(color: Colors.black87, fontSize: 14),
                      //   ),
                      // ),
                      // SizedBox(
                      //   height: 4,
                      // ),
                      // SizedBox(
                      //   width: double.infinity,
                      //   child: Text(
                      //     'Size : ${widget.snapshot.data.data[widget.index].sizename}',
                      //     style: TextStyle(color: Colors.black87, fontSize: 14),
                      //   ),
                      // ),
                      const SizedBox(
                        height: 4,
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          widget.snapshot.data!.data![widget.index].totalfreestock! >
                              0
                              ? 'Stock Available'
                              : 'Out Of Stock',
                          style: const TextStyle(
                              color: Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.w500),
                        ),
                      ),
                      const SizedBox(
                        height: 4,
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            'RM${widget.snapshot.data!.data![widget.index].regularprice!.toStringAsFixed(2)}',
                            style: const TextStyle(
                                color: Color(0xFFF68721),
                                fontSize: 16,
                                fontWeight: FontWeight.w500),
                          ),
                          const Spacer(),
                          Ink(
                            height: 40,
                            width: 40,
                            decoration: ShapeDecoration(
                              color: const Color(0xFFF68721).withOpacity(0.1),
                              shape: const CircleBorder(),
                            ),
                            child: IconButton(
                              onPressed: () async {
                                try {
                                  final result =
                                  await InternetAddress.lookup('example.com');
                                  if (result.isNotEmpty &&
                                      result[0].rawAddress.isNotEmpty) {
                                    setState(() {
                                      widget.snapshot.data!.data![widget.index]
                                          .isWish = widget.snapshot.data!
                                          .data![widget.index].isWish ==
                                          0
                                          ? 1
                                          : 0;
                                      AddToWish addWish = AddToWish();
                                      addWish.addToWish(widget
                                          .snapshot.data!.data![widget.index].pkno);
                                    });
                                  }
                                } on SocketException catch (_) {
                                  Common.toastMsg('No Internet Connection');
                                }
                              },
                              icon: widget.snapshot.data!.data![widget.index]
                                  .isWish ==
                                  0
                                  ? const Icon(
                                Icons.favorite_outline,
                                size: 16,
                                color: Colors.black87,
                              )
                                  : const Icon(
                                Icons.favorite,
                                size: 16,
                                color: Color(0xFFF68721),
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class WishListProductCard extends StatefulWidget {
  const WishListProductCard({Key? key, this.snapshot, this.index})
      : super(key: key);
  final AsyncSnapshot<WishListModel>? snapshot;
  final int? index;
  @override
  _WishListProductCardState createState() => _WishListProductCardState();
}

class _WishListProductCardState extends State<WishListProductCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ProductDetailsPage.productUrl =
                widget.snapshot!.data!.data![widget.index!].url;
            ProductDetailsPage.variantPk =
                widget.snapshot!.data!.data![widget.index!].pkno;
            ProductDetailsPage.isWish =
                widget.snapshot!.data!.data![widget.index!].isWish;
            Navigator.of(context).push(
                CustomRoutePageBuilder
                    .createPageRouteLeft(
                    context, const ProductDetailsPage()));
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(10.0)),
        width: MediaQuery.of(context).orientation == Orientation.portrait
            ? MediaQuery.of(context).size.width * 0.4
            : MediaQuery.of(context).size.height * 0.4,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Stack(
              children: [
                Align(
                  alignment: Alignment.center,
                  child: ConstrainedBox(
                      constraints: const BoxConstraints(
                        maxHeight: 140,
                        minHeight: 60,
                      ),
                      child: widget.snapshot!.data!.data![widget.index!]
                                  .thumbPath ==
                              null
                          ? const NoImageWidget(
                              text: 'No Image',
                            )
                          : CacheImageProvide(
                              url: widget.snapshot!.data!.data![widget.index!]
                                  .thumbPath,
                            )),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: Material(
                    color: Colors.transparent,
                    child: Ink(
                      decoration: ShapeDecoration(
                        color:
                            widget.snapshot!.data!.data![widget.index!].isWish == 0
                                ? const Color(0xFFF4F4F4).withOpacity(0.4)
                                : const Color(0xFFF68721).withOpacity(0.1),
                        shape: const CircleBorder(),
                      ),
                      child: IconButton(
                        onPressed: () async {
                          try {
                            final result =
                                await InternetAddress.lookup('example.com');
                            if (result.isNotEmpty &&
                                result[0].rawAddress.isNotEmpty) {
                              setState(() {
                                widget.snapshot!.data!.data![widget.index!].isWish =
                                    widget.snapshot!.data!.data![widget.index!]
                                                .isWish ==
                                            0
                                        ? 1
                                        : 0;
                                AddToWish addWish = AddToWish();
                                addWish.addToWish(widget
                                    .snapshot!.data!.data![widget.index!].pkno);
                              });
                            }
                          } on SocketException catch (_) {
                            Common.toastMsg('No Internet Connection');
                          }
                        },
                        icon:
                            widget.snapshot!.data!.data![widget.index!].isWish == 0
                                ? const Icon(
                                    Icons.favorite_outline,
                                    size: 16,
                                    color: Colors.black87,
                                  )
                                : const Icon(
                                    Icons.favorite,
                                    size: 16,
                                    color: Color(0xFFF68721),
                                  ),
                      ),
                    ),
                  ),
                ),
                // LayoutBuilder(
                //   builder:
                //       (BuildContext context, BoxConstraints constraints) {
                //     if (widget.snapshot.data.data[widget.index].offer !=
                //         0) {
                //       return GestureDetector(
                //         onTap: () {
                //           // setState(() {
                //           //   toggleMsg = toggleMsg == 1 ? 0 : 1;
                //           // });
                //         },
                //         child: Align(
                //           alignment: Alignment.topLeft,
                //           child: Container(
                //             height: 45,
                //             width: 45,
                //             padding: const EdgeInsets.all(3.0),
                //             decoration: BoxDecoration(
                //               shape: BoxShape.circle,
                //               color: Colors.red,
                //             ),
                //             child: Center(
                //               child: Text(
                //                 'In \nOffer',
                //                 textAlign: TextAlign.center,
                //                 style: TextStyle(
                //                     color: Colors.white,fontWeight: FontWeight.w600, fontSize: 12),
                //               ),
                //             ),
                //           ),
                //         ),
                //       );
                //     } else {
                //       return Align(
                //         alignment: Alignment.topLeft,
                //         child: SizedBox(
                //           height: 2,
                //         ),
                //       );
                //     }
                //   },
                // ),
              ],
            ),
            const SizedBox(
              height: 8,
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  widget.snapshot!.data!.data![widget.index!].totalfreestock! > 0
                      ? 'RM${widget.snapshot!.data!.data![widget.index!].regularprice!.toStringAsFixed(2)}'
                      // : 'Out Of Stock',
                      : 'RM${widget.snapshot!.data!.data![widget.index!].regularprice!.toStringAsFixed(2)}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Color(0xFFF68721), fontSize: 16),
                ),
              ),
            ),
            const SizedBox(
              height: 4,
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  '${widget.snapshot!.data!.data![widget.index!].variantname}',
                  maxLines: 3,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.black87, fontSize: 14),
                ),
              ),
            ),
            const SizedBox(
              height: 4,
            ),
            SizedBox(
              width: double.infinity,
              child: Text(
                widget.snapshot!.data!.data![widget.index!].totalfreestock! > 0
                    ? 'Stock Available'
                    : 'Out Of Stock',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 14,
                    fontWeight: FontWeight.w500),
              ),
            ),
            const SizedBox(
              height: 8,
            ),
          ],
        ),
      ),
    );
  }
}
