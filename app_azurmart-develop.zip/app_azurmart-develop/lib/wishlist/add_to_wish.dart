import 'dart:convert';

import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AddToWish {
  Future<void> addToWish(int? variantNo) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    print('add-to-wish ($session / $userId)');
    Map<String, dynamic> data = {
      'session': "$session",
      'user_id': '$userId',
      'token': '$token',
      'F_PRD_VARIANT_NO': '$variantNo'
    };
    var requestBody = json.encode(data);
    Uri url = Uri.parse(Urls.baseUrl + Urls.ADD_TO_WISH);
    Client client = Client();
    try {
      var response = await client.post(url, body: data);
      if (response.statusCode == 200) {
        final Map<String, dynamic>? body = await json.decode(response.body);
        if (response.body.isNotEmpty) {
          print('${body!['message']}');
          //Common.toastMsg('${body['message']}');
        }
      } else {
        throw Exception('Failed to load post');
      }
    } on Exception catch (e) {
      print(e);
    }
  }
}
