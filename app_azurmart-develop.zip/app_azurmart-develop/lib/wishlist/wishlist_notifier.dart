import 'package:flutter/foundation.dart';

class WishListNotifier extends ChangeNotifier {
  int isList = 1;
  void changeListStyle(){
    isList = isList == 1 ? 0 : 1;
    notifyListeners();
  }
}