import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/coupon/coupon_screen.dart';
import 'package:azuramartmy/my_bloc/coupon_list_bloc.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/coupon_list_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
class CouponListScreen extends StatefulWidget {
  const CouponListScreen({Key? key}) : super(key: key);
  static Route route(){
    return MaterialPageRoute(builder: (_) => const CouponListScreen());
  }

  @override
  State<CouponListScreen> createState() => _CouponListScreenState();
}

class _CouponListScreenState extends State<CouponListScreen> {
  @override
  void initState() {
    couponListBloc.fetchAllCouponList();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        title: const Text(
          'Coupons',style: TextStyle(color: Colors.black87),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        systemOverlayStyle: Platform.isIOS
            ? SystemUiOverlayStyle.dark
            : const SystemUiOverlayStyle(
          statusBarColor: Colors.white,
          statusBarIconBrightness: Brightness.dark,
        ),
      ),
      body: CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 0,
            ),
          ),
          StreamBuilder(
            stream: couponListBloc.allCouponList,
            builder: (context, AsyncSnapshot<CouponListModel> snapshot){
              if(snapshot.hasData){
                return SliverList(
                  delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index) {
                    return Padding(
                      padding: const EdgeInsets.only(left: 0, bottom: 0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    height: 45,
                                    width: 6,
                                    decoration: const BoxDecoration(
                                        color: Colors.amber,
                                        borderRadius: BorderRadius.only(
                                            bottomLeft: Radius.circular(6.0),
                                            topLeft: Radius.circular(6.0))),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  GestureDetector(
                                    onTap: (){
                                      Clipboard.setData( ClipboardData(text: "${snapshot.data!.data![index].couponCode}"));
                                      Common.toastMsg('Copied to Clipboard');
                                    },
                                    child: Text(
                                      '${snapshot.data!.data![index].couponCode}',
                                      style: const TextStyle(
                                          color: Colors.black87,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600),
                                    ),
                                  ),
                                  IconButton(
                                    onPressed: (){
                                      Clipboard.setData( ClipboardData(text: "${snapshot.data!.data![index].couponCode}"));
                                      Common.toastMsg('Copied to Clipboard');
                                    },
                                    icon: const Icon(Icons.copy,size: 20,),
                                  ),
                                ],
                              ),
                              const Spacer(),
                              TextButton(
                                  onPressed: () async {
                                    try {
                                      final result =
                                      await InternetAddress.lookup('example.com');
                                      if (result.isNotEmpty &&
                                          result[0].rawAddress.isNotEmpty) {
                                        Navigator.of(context).push(
                                            CustomRoutePageBuilder.createPageRouteLeft(
                                                context, CouponPage(couponCode: snapshot.data!.data![index].couponCode,)));
                                        // Navigator.push(context, FeaturePage.route());
                                      }
                                    } on SocketException catch (_) {
                                      Common.toastMsg('No Internet Connection');
                                    }
                                  },
                                  child: Text(
                                    'See All',
                                    style: TextStyle(color: AppsColors.buttonColor),
                                  ))
                            ],
                          ),
                          GridView.count(
                            controller: ScrollController(keepScrollOffset: false),
                            shrinkWrap: true,
                            scrollDirection: Axis.vertical,
                            crossAxisCount: MediaQuery.of(context).orientation == Orientation.portrait
                                ? MediaQuery.of(context).size.width > 740
                                ? 2
                                : 2
                                : MediaQuery.of(context).size.width > 740
                                ? 4
                                : 3,
                            mainAxisSpacing: 12,
                            crossAxisSpacing: 12,
                            childAspectRatio: MediaQuery.of(context).orientation == Orientation.portrait
                                ? screenWidth / 200.0
                                : screenHeight / 170.0,
                            children: List.generate(snapshot.data!.data![index].products!.length, (productsIndex) {
                              return GestureDetector(
                                onTap: () async{
                                  try {
                                    final result = await InternetAddress.lookup('example.com');
                                    if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                                      ProductDetailsPage.productUrl =
                                          snapshot.data!.data![index].products![productsIndex].urlSlug;
                                      ProductDetailsPage.variantPk =
                                          snapshot.data!.data![index].products![productsIndex].pkNo;
                                      ProductDetailsPage.isWish = 0;
                                      Navigator.of(context).push(
                                          CustomRoutePageBuilder
                                              .createPageRouteLeft(
                                              context, const ProductDetailsPage()));
                                      // Navigator.push(context, ProductDetailsPage.route());
                                    }
                                  } on SocketException catch (_) {
                                    Common.toastMsg('No Internet Connection');
                                  }
                                },
                                child: Container(
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(6),
                                        color: Colors.white.withOpacity(0.7)
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Expanded(
                                          flex: 1,
                                          child: CacheImageProvide(url: snapshot.data!.data![index].products![productsIndex].thumbPath),
                                        ),
                                        Expanded(
                                          flex: 1,
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 8),
                                            decoration: const BoxDecoration(
                                                borderRadius: BorderRadius.only(topLeft: Radius.circular(10),topRight: Radius.circular(10)),
                                                // color: Color(0xffFEDBD0),
                                                color: Colors.white

                                            ),
                                            child: Stack(
                                              clipBehavior: Clip.none,
                                              children: [
                                                Positioned(
                                                  top: -24,
                                                  right: 0,
                                                  child: Container(
                                                    padding: const EdgeInsets.all(8),
                                                    decoration: BoxDecoration(
                                                      color: Colors.red,
                                                      borderRadius: BorderRadius.circular(6),
                                                    ),
                                                    child: Text(snapshot.data!.data![index].couponType == 1 ?'-${snapshot.data!.data![index].discount!.toStringAsFixed(0)}%' : '-RM${snapshot.data!.data![index].discount!.toStringAsFixed(0)}',style: const TextStyle(color: Colors.white),),
                                                  ),
                                                ),
                                                Column(
                                                  mainAxisSize: MainAxisSize.min,
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  children: [
                                                    const SizedBox(
                                                      height: 8,
                                                    ),
                                                    SizedBox(
                                                      width: double.infinity,
                                                      child: Text('RM${(Common.getCouponAppliedPrice(snapshot.data!.data![index].products![productsIndex].regularPrice!, snapshot.data!.data![index].products![productsIndex].discount!, snapshot.data!.data![index].products![productsIndex].couponType!)).toStringAsFixed(2)}',textAlign: TextAlign.start,style: const TextStyle(color: Colors.deepOrange,fontWeight: FontWeight.w600),),
                                                    ),
                                                    SizedBox(
                                                      width: double.infinity,
                                                      child: Text(snapshot.data!.data![index].products![productsIndex].regularPrice!.toStringAsFixed(2),textAlign: TextAlign.start,style: const TextStyle(color: Colors.black54,fontWeight: FontWeight.w600,decoration: TextDecoration.lineThrough, ),),
                                                    ),
                                                    SizedBox(
                                                      width: double.infinity,
                                                      child: Text('${snapshot.data!.data![index].products![productsIndex].variantName}',textAlign: TextAlign.start,style: const TextStyle(color: Colors.black87,fontWeight: FontWeight.w600,overflow: TextOverflow.ellipsis),maxLines: 3,),
                                                    ),
                                                  ],
                                                )
                                              ],
                                            ),
                                          ),
                                        )
                                      ],
                                    )
                                ),
                              );
                            } ),
                          ),
                        ],
                      ),
                    );
                },childCount: snapshot.data!.data!.length,
                  ),
                );
              }else if (snapshot.hasError) {
                return SliverToBoxAdapter(child: LoadingWidget(color: AppsColors.buttonColor,));
              }
              return const SliverToBoxAdapter(
                child: Center(
                  child: SizedBox(
                    height: 20.0,
                    width: 20,
                    child: CircularProgressIndicator(
                      color: Color(0xFFF68721),
                      strokeWidth: 2.0,
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
