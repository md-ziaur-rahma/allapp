import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_notifier/common_notifier.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/my_bloc/coupon_product_bloc.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/coupon_product_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

class CouponPage extends StatefulWidget {
  const CouponPage({Key? key, this.couponCode}) : super(key: key);
  final String? couponCode;
  static Route route(String couponCode){
    return MaterialPageRoute(builder: (_) => CouponPage(couponCode: couponCode,));
  }

  @override
  State<CouponPage> createState() => _CouponPageState();
}

class _CouponPageState extends State<CouponPage> {
  CouponProductModel couponProductModel = CouponProductModel();
  bool canLoading = true;

  @override
  void initState() {
    couponProductBloc.page = 1;
    couponProductModel.data = [];
    couponProductBloc.fetchAllCouponProducts(widget.couponCode);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        title: Text(
          '${widget.couponCode}',style: const TextStyle(color: Colors.black87),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        systemOverlayStyle: Platform.isIOS
            ? SystemUiOverlayStyle.dark
            : const SystemUiOverlayStyle(
                statusBarColor: Colors.white,
                statusBarIconBrightness: Brightness.dark,
              ),
        actions: [
          IconButton(
              onPressed: (){
                Clipboard.setData( ClipboardData(text: "${widget.couponCode}"));
                Common.toastMsg('Copied to Clipboard');
              },
              tooltip: "Click to get coupon code",
              icon: const Icon(Icons.copy,size: 20)
          )
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: CustomScrollView(
            scrollDirection: Axis.vertical,
            slivers: [
              const SliverToBoxAdapter(
                child: SizedBox(
                  height: 16,
                ),
              ),
              StreamBuilder(
                stream: couponProductBloc.allCouponProduct,
                builder: (context, AsyncSnapshot<CouponProductModel> snapshot){
                  if(snapshot.hasData){
                    Provider.of<CommonNotifier>(context,listen: false).changeLoading(false);
                    if (snapshot.data!.data!.isEmpty) {
                      couponProductBloc.page = 1;
                      couponProductBloc.fetchAllCouponProducts(widget.couponCode);
                      canLoading = false;
                    } else {
                      if (snapshot.data!.data!.length < 10) {
                        canLoading = false;
                      }
                      for (var i = 0; i < snapshot.data!.data!.length; i++) {
                        couponProductModel.data!.add(snapshot.data!.data![i]);
                      }
                    }
                    return SliverGrid(
                      delegate: SliverChildBuilderDelegate(
                              (BuildContext context, int index) {
                                if (index == (couponProductModel.data!.length - 1) &&
                                    canLoading) {
                                  Provider.of<CommonNotifier>(context,listen: false).changeLoading(true);
                                  couponProductBloc.fetchPagingData(widget.couponCode);
                                }
                            return GestureDetector(
                              onTap: () async {
                                try {
                                  final result = await InternetAddress.lookup('example.com');
                                  if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                                    ProductDetailsPage.productUrl =
                                        couponProductModel.data![index].urlSlug;
                                    ProductDetailsPage.variantPk =
                                        couponProductModel.data![index].pkNo;
                                    ProductDetailsPage.isWish = 0;
                                    Navigator.of(context).push(
                                        CustomRoutePageBuilder
                                            .createPageRouteLeft(
                                            context, const ProductDetailsPage()));
                                    // Navigator.push(context, ProductDetailsPage.route());
                                  }
                                } on SocketException catch (_) {
                                  Common.toastMsg('No Internet Connection');
                                }
                              },
                              child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      color: Colors.white.withOpacity(0.7)
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Expanded(
                                        flex: 1,
                                        child: CacheImageProvide(url: couponProductModel.data![index].thumbPath),
                                      ),
                                      Expanded(
                                        flex: 1,
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 8),
                                          decoration: const BoxDecoration(
                                              borderRadius: BorderRadius.only(topLeft: Radius.circular(10),topRight: Radius.circular(10)),
                                              // color: Color(0xffFEDBD0),
                                              color: Colors.white

                                          ),
                                          child: Stack(
                                            clipBehavior: Clip.none,
                                            children: [
                                              Positioned(
                                                top: -24,
                                                right: 0,
                                                child: Container(
                                                  padding: const EdgeInsets.all(8),
                                                  decoration: BoxDecoration(
                                                    color: Colors.red,
                                                    borderRadius: BorderRadius.circular(6),
                                                  ),
                                                  child: Text(couponProductModel.data![index].couponType == 1 ?'-${couponProductModel.data![index].discount!.toStringAsFixed(0)}%' : '-RM${couponProductModel.data![index].discount!.toStringAsFixed(0)}',style: const TextStyle(color: Colors.white),),
                                                ),
                                              ),
                                              Column(
                                                mainAxisSize: MainAxisSize.min,
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                children: [
                                                  const SizedBox(
                                                    height: 8,
                                                  ),
                                                  SizedBox(
                                                    width: double.infinity,
                                                    child: Text('RM${(Common.getCouponAppliedPrice(couponProductModel.data![index].regularPrice, couponProductModel.data![index].discount, couponProductModel.data![index].couponType)).toStringAsFixed(2)}',textAlign: TextAlign.start,style: const TextStyle(color: Colors.deepOrange,fontWeight: FontWeight.w600),),
                                                  ),
                                                  SizedBox(
                                                    width: double.infinity,
                                                    child: Text(couponProductModel.data![index].regularPrice!.toStringAsFixed(2),textAlign: TextAlign.start,style: const TextStyle(color: Colors.black54,fontWeight: FontWeight.w600,decoration: TextDecoration.lineThrough, ),),
                                                  ),
                                                  SizedBox(
                                                    width: double.infinity,
                                                    child: Text('${couponProductModel.data![index].variantName}',textAlign: TextAlign.start,style: const TextStyle(color: Colors.black87,fontWeight: FontWeight.w600,overflow: TextOverflow.ellipsis),maxLines: 3,),
                                                  ),
                                                ],
                                              )
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  )
                              ),
                            );
                          }, childCount: couponProductModel.data!.length),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount:
                        MediaQuery.of(context).orientation == Orientation.portrait
                            ? 2
                            : MediaQuery.of(context).size.width > 740
                            ? 4
                            : 3,
                        mainAxisSpacing: 12,
                        childAspectRatio:
                        MediaQuery.of(context).orientation == Orientation.portrait
                            ? screenWidth / 200.0
                            : screenHeight / 160.0,
                        crossAxisSpacing: 12,
                      ),
                    );
                  }else if (snapshot.hasError) {
                    return SliverToBoxAdapter(child: LoadingWidget(color: AppsColors.buttonColor,));
                  }
                  return const SliverToBoxAdapter(
                    child: Center(
                      child: SizedBox(
                        height: 20.0,
                        width: 20,
                        child: CircularProgressIndicator(
                          color: Color(0xFFF68721),
                          strokeWidth: 2.0,
                        ),
                      ),
                    ),
                  );
                },
              ),
              SliverLayoutBuilder(
                builder: (BuildContext context, SliverConstraints constraints) {
                  if (Provider.of<CommonNotifier>(context, listen: false).isLoading) {
                    return SliverToBoxAdapter(
                      child: Center(
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 16),
                          height: 20,
                          width: 20,
                          child: const CupertinoActivityIndicator(
                            animating: true,
                            radius: 12,
                          ),
                        ),
                      ),
                    );
                  }  else{
                    return const SliverToBoxAdapter(
                      child: Center(
                          child: SizedBox(
                            height: 6,
                          )
                      ),
                    );
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
