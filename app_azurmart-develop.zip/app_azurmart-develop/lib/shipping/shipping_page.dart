import 'package:azuramartmy/shipping/shipping_body.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ShippingPage extends StatelessWidget {
  const ShippingPage({Key? key}) : super(key: key);

  static Route route(){
    return MaterialPageRoute(builder: (_) => const ShippingPage());
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          title: const Text('Shipping',style: TextStyle(color: Colors.black87),),

          iconTheme: const IconThemeData(color: Colors.black87),
          systemOverlayStyle: const SystemUiOverlayStyle(
              statusBarColor: Colors.white,
              statusBarBrightness: Brightness.dark,
              statusBarIconBrightness: Brightness.dark),
        ),
        body: const ShippingBody(),
    ));
  }
}
