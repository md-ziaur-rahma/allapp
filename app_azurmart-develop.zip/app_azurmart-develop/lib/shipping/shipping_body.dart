import 'package:azuramartmy/my_bloc/cart_bloc.dart';
import 'package:azuramartmy/payment/payment_page.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ShippingBody extends StatefulWidget {
  const ShippingBody({Key? key}) : super(key: key);

  @override
  _ShippingBodyState createState() => _ShippingBodyState();
}

class _ShippingBodyState extends State<ShippingBody> {

  String? email;
  String? firstNameS;
  String? lastNameS;
  String? addressS;
  String? postCodeS;
  String? mobileS;
  String? apartmentS;
  String? cityS;
  String? stateS;
  int? statePkS;
  int? cityPkS;

  double postage = 0;

  void getAllData() async {
    SharedPreferences localStorage =await SharedPreferences.getInstance();
    email =  localStorage.getString(SharedPreferenceUtils.EMAIL);
    firstNameS =  localStorage.getString(SharedPreferenceUtils.FIRSTNAME);
    lastNameS =  localStorage.getString(SharedPreferenceUtils.LASTNAME);
    addressS =  localStorage.getString(SharedPreferenceUtils.ADDRESS);
    apartmentS =  localStorage.getString(SharedPreferenceUtils.APARTMENT);
    cityS =  localStorage.getString(SharedPreferenceUtils.CITY);
    stateS =  localStorage.getString(SharedPreferenceUtils.STATE);
    mobileS =  localStorage.getString(SharedPreferenceUtils.MOBILE);
    postCodeS =  localStorage.getString(SharedPreferenceUtils.POSTCODE);
    statePkS =  localStorage.getInt(SharedPreferenceUtils.STATEPK);
    cityPkS =  localStorage.getInt(SharedPreferenceUtils.CITYPK);
  }

  // double getTotal(AsyncSnapshot<CartModel> snapshot) {
  //   double total = 0;
  //   for (var i = 0; i < snapshot.data.data.length; i++) {
  //     total += (snapshot.data.data[i].regularprice *
  //         snapshot.data.data[i].totalitemqty);
  //   }
  //   return total;
  // }
  //
  // double getPostageCost(AsyncSnapshot<CartModel> snapshot){
  //   double postageCost = 0;
  //   double ss = 0;
  //   double sm = 0;
  //   for (var i = 0; i < snapshot.data.data.length; i++) {
  //     if (int.parse(postCodeS) < 87000 ) {
  //       sm += (snapshot.data.data[i].products.localpostage *
  //           snapshot.data.data[i].totalitemqty);
  //       print('${snapshot.data.data[i].products.localpostage}');
  //     }  else {
  //       ss += (snapshot.data.data[i].products.interdistrictpostage *
  //           snapshot.data.data[i].totalitemqty);
  //       print('${snapshot.data.data[i].products.interdistrictpostage}');
  //     }
  //   }
  //   postageCost = sm + ss;
  //   postage = postageCost;
  //   return postageCost;
  // }

  @override
  void initState() {
    setState(() {
      getAllData();
    });
    cartBloc.fetchAllCarts();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      scrollDirection: Axis.vertical,
      slivers: [
        // StreamBuilder(
        //     stream: cartBloc.allCarts,
        //     builder: (context, AsyncSnapshot<CartModel> snapshot) {
        //       if (snapshot.hasData) {
        //         if (snapshot.data.data.length != 0) {
        //           return SliverToBoxAdapter(
        //             child: ExpandablePanel(
        //               header: ListTile(
        //                 leading: Icon(
        //                   Icons.shopping_cart_outlined,
        //                   color: Colors.black87,
        //                   size: 24,
        //                 ),
        //                 trailing: Text(
        //                   'RM${(getTotal(snapshot)+getPostageCost(snapshot)).toStringAsFixed(2)}',
        //                   style: TextStyle(
        //                       color: Colors.black87,
        //                       fontSize: 16,
        //                       fontWeight: FontWeight.w600),
        //                 ),
        //                 title: Text(
        //                   'Show Order Summery',
        //                   style: TextStyle(color: Colors.black54, fontSize: 14),
        //                 ),
        //               ),
        //               expanded: Container(
        //                 padding: const EdgeInsets.symmetric(horizontal: 16),
        //                 width: double.infinity,
        //                 decoration: BoxDecoration(
        //                   color: Color(0xFFF4F4F4),
        //                 ),
        //                 child: Column(
        //                   mainAxisAlignment: MainAxisAlignment.start,
        //                   mainAxisSize: MainAxisSize.min,
        //                   children: [
        //                     ...List.generate(
        //                         snapshot.data.data.length,
        //                             (index) =>
        //                             OrderSummeryInfoProduct(snapshot, index)),
        //                     Divider(
        //                       height: 30,
        //                       thickness: 1,
        //                     ),
        //                     Row(
        //                       mainAxisSize: MainAxisSize.max,
        //                       children: [
        //                         Expanded(
        //                           flex: 4,
        //                           child: TextFormField(
        //                             decoration: InputDecoration(
        //                               contentPadding:
        //                               EdgeInsets.symmetric(horizontal: 20),
        //                               hintText: 'Gift card or discount code',
        //                               fillColor: Colors.white,
        //                               filled: true,
        //                               focusedBorder: OutlineInputBorder(
        //                                   borderRadius:
        //                                   BorderRadius.circular(6),
        //                                   borderSide:
        //                                   BorderSide(color: Colors.black)),
        //                               border: OutlineInputBorder(
        //                                   borderRadius:
        //                                   BorderRadius.circular(10),
        //                                   borderSide: BorderSide(
        //                                       color: Color(0xFFD0D1D2))),
        //                             ),
        //                           ),
        //                         ),
        //                         SizedBox(
        //                           width: 8,
        //                         ),
        //                         Expanded(
        //                           flex: 1,
        //                           child: Container(
        //                             height: 45,
        //                             child: ElevatedButton(
        //                               onPressed: () {
        //                                 print(postCodeS);
        //                                 print(getPostageCost(snapshot));
        //                               },
        //                               style: ElevatedButton.styleFrom(
        //                                   primary: AppsColors.buttonColor),
        //                               child: Icon(
        //                                 Icons.arrow_forward,
        //                                 color: Colors.white,
        //                               ),
        //                             ),
        //                           ),
        //                         )
        //                       ],
        //                     ),
        //                     Divider(
        //                       height: 30,
        //                       thickness: 1,
        //                     ),
        //                     Row(
        //                       children: [
        //                         Text(
        //                           'Subtotal',
        //                           style: TextStyle(fontSize: 16),
        //                         ),
        //                         Spacer(),
        //                         Text(
        //                           'RM${getTotal(snapshot).toStringAsFixed(2)}',
        //                           style: TextStyle(
        //                               color: Colors.black87,
        //                               fontSize: 16,
        //                               fontWeight: FontWeight.bold),
        //                         ),
        //                       ],
        //                     ),
        //                     SizedBox(
        //                       height: 16,
        //                     ),
        //                     Row(
        //                       children: [
        //                         Text('Shipping',
        //                           style: TextStyle(fontSize: 16),
        //                         ),
        //                         Spacer(),
        //                         Text('RM${getPostageCost(snapshot).toStringAsFixed(2)}',
        //                           style: TextStyle(
        //                               color: Colors.black87, fontSize: 16),
        //                         ),
        //                       ],
        //                     ),
        //                     Divider(
        //                       height: 30,
        //                       thickness: 1,
        //                     ),
        //                     Row(
        //                       children: [
        //                         Text(
        //                           'Total',
        //                           style: TextStyle(fontSize: 16),
        //                         ),
        //                         Spacer(),
        //                         Text(
        //                           'RM${(getTotal(snapshot)+getPostageCost(snapshot)).toStringAsFixed(2)}',
        //                           style: TextStyle(
        //                               color: Colors.black87,
        //                               fontSize: 16,
        //                               fontWeight: FontWeight.bold),
        //                         ),
        //                       ],
        //                     ),
        //                     Divider(
        //                       height: 30,
        //                       thickness: 1,
        //                     ),
        //                   ],
        //                 ),
        //               ),
        //             ),
        //           );
        //         } else {
        //           return SliverToBoxAdapter(
        //               child: Center(
        //                 child: Text('empty cart!'),
        //               ));
        //         }
        //       } else if (snapshot.hasError) {
        //         return SliverToBoxAdapter(
        //           child: Center(
        //             child: Text('${snapshot.error.toString()}'),
        //           ),
        //         );
        //       }
        //       return SliverToBoxAdapter(
        //         child: Center(
        //           child: SizedBox(
        //             height: 20,
        //             width: 20,
        //             child: CircularProgressIndicator(
        //               strokeWidth: 2,
        //               color: Color(0xFFF68721),
        //             ),
        //           ),
        //         ),
        //       );
        //     }),
        SliverToBoxAdapter(
          child: Container(
            padding: const EdgeInsets.all(16.0),
            margin: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                border: Border.all(color: const Color(0xFFD0D1D2), width: 1.0)),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text(
                      'Contact',
                      style: TextStyle(color: Colors.black54, fontSize: 16),
                    ),
                    const Spacer(),
                    TextButton(
                        onPressed: () {},
                        child: const Text(
                          'Change',
                          style: TextStyle(color: Color(0xFFF68721)),
                        ))
                  ],
                ),
                SizedBox(
                  width: double.infinity,
                  child: Text('$email'),
                ),
                const Divider(
                  height: 30,
                  thickness: 1,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Ship to',
                      style: TextStyle(color: Colors.black54, fontSize: 16),
                    ),
                    const Spacer(),
                    TextButton(
                        onPressed: () {},
                        child: const Text(
                          'Change',
                          style: TextStyle(color: Color(0xFFF68721)),
                        ))
                  ],
                ),
                SizedBox(
                    width: double.infinity,
                    child: Text(
                      '$addressS, $apartmentS, $postCodeS $cityS, $stateS, Malaysia',)),
              ],
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 24,
          ),
        ),
        const SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SizedBox(
              width: double.infinity,
              child: Text(
                'Shipping Method',
                style: TextStyle(
                    color: Colors.black87,
                    fontSize: 20,
                    fontWeight: FontWeight.w600),
              ),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 16,
          ),
        ),
        SliverToBoxAdapter(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            padding: const EdgeInsets.symmetric(vertical: 16.0),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                border: Border.all(color: const Color(0xFFD0D1D2), width: 1.0)),
            child: ListTile(
              leading: Center(
                child: Icon(Icons.circle,size: 16,color: AppsColors.buttonColor,),
              ),
              trailing: Text(
                'RM${postage.toStringAsFixed(2)}',
                style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 16,
                    fontWeight: FontWeight.w600),
              ),
              title: const SizedBox(
                width: double.infinity,
                child: Text(
                  'Postage',
                  style: TextStyle(color: Colors.black87, fontSize: 16),
                ),
              ),
              subtitle: const SizedBox(
                child: Text(
                  'Fullfil with Azura Mart guaranteed sate packaging. Delivery 7 to 10 Business days',
                  style: TextStyle(color: Colors.black54, fontSize: 14),
                ),
              ),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 24,
          ),
        ),
        SliverToBoxAdapter(
          child: Container(
            width: double.infinity,
            margin: const EdgeInsets.symmetric(horizontal: 16),
            height: 50,
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(context, PaymentPage.route());
              },
              style: ElevatedButton.styleFrom(primary: AppsColors.buttonColor,shape: StadiumBorder()),
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  'Continue to payment',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 24,
          ),
        ),
      ],
    );
  }
}
