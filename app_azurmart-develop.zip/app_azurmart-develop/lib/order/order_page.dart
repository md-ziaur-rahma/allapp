import 'dart:io';

import 'package:azuramartmy/order/order_body.dart';
import 'package:azuramartmy/order/order_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class OrderPage extends StatelessWidget {
  const OrderPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => OrderPage());
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 7,
      child: Scaffold(
        body: SafeArea(
          child: NestedScrollView(
            headerSliverBuilder:
                (BuildContext context, bool innerBoxIsScrolled) {
              return <Widget>[
                SliverAppBar(
                  title: const Text(
                    'Order List',
                    style: TextStyle(color: Colors.black87),
                  ),
                  elevation: 0,
                  titleSpacing: 0,
                  systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
                      statusBarBrightness: Brightness.dark,
                      statusBarIconBrightness: Brightness.dark,
                      statusBarColor: Colors.white),
                  backgroundColor: Colors.white,
                  iconTheme: const IconThemeData(color: Colors.black87),
                  pinned: true,
                  floating: true,
                  bottom: const TabBar(
                    isScrollable: true,
                    tabs: [
                      Tab(
                          child: Text(
                        'ALL',
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                      )),
                      Tab(
                          child: Text(
                        'PENDING',
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                      )),
                      Tab(
                          child: Text(
                        'CONFIRMED',
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                      )),
                      Tab(
                          child: Text(
                        'PROCESSING',
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                      )),
                      Tab(
                          child: Text(
                        'PICKED',
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                      )),
                      Tab(
                          child: Text(
                        'SHIPPED',
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                      )),
                      Tab(
                          child: Text(
                        'DELIVERED',
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                      )),
                    ],
                  ),
                ),
              ];
            },
            body: const TabBarView(
              children: [
                OrderCard(),
                Center(
                  child: Text('PENDING'),
                ),
                Center(
                  child: Text('CONFIRMED'),
                ),
                Center(
                  child: Text('PROCESSING'),
                ),
                Center(
                  child: Text('PICKED'),
                ),
                Center(
                  child: Text('SHIPPED'),
                ),
                Center(
                  child: Text('DELIVERED'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
