import 'package:azuramartmy/order_details/order_details_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';

class OrderCard extends StatefulWidget {
  const OrderCard({Key? key}) : super(key: key);

  @override
  _OrderCardState createState() => _OrderCardState();
}

class _OrderCardState extends State<OrderCard> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemBuilder: (BuildContext context, int index) {
        return GestureDetector(
          onTap: (){
            Navigator.push(context, OrderDetailsPage.route());
          },
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(6.0)),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    const Text(
                      '#ORDER-61274695',
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 20,
                          fontWeight: FontWeight.w700),
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: index%2 == 0 ? Colors.lightBlue : Colors.redAccent,
                                borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(4.0),
                                    bottomLeft: Radius.circular(4.0))),
                            child: Text(index%2 == 0 ? 'Picked' : 'Cancelled',style: const TextStyle(color: Colors.white,fontSize: 14,),),
                          ),
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: index%2 == 0 ? Colors.green : Colors.amberAccent,
                                borderRadius: const BorderRadius.only(
                                    topRight: Radius.circular(4.0),
                                    bottomRight: Radius.circular(4.0))),
                            child: Text(index%2 == 0 ?'Paid' : 'Unpaid',style: const TextStyle(color: Colors.white,fontSize: 14,),),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  mainAxisSize: MainAxisSize.max,
                  children: const [
                    Text('RM1234.00',style: TextStyle(color: Color(0xFFF68721),fontSize: 18,fontWeight: FontWeight.w600),),
                    Text('26 May, 03:00 PM',style: TextStyle(color: Colors.black54,fontSize: 18,fontWeight: FontWeight.normal),)
                  ],
                )
              ],
            ),
          ),
        );
      },
      itemCount: 10,
    );

  }
}
