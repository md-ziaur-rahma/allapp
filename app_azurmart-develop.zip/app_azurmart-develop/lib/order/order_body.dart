import 'package:azuramartmy/order/order_card.dart';
import 'package:azuramartmy/order_details/order_details_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class OrderBody extends StatelessWidget {
  const OrderBody({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 40,
      shrinkWrap: true,
      scrollDirection: Axis.vertical,
      itemBuilder: (context, index) {
        return OrderDeliveredItemView(index);
      },
    );
  }
}

class OrderItemView extends StatelessWidget {
  bool isCancelled = false;

  OrderItemView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6), color: const Color(0xFFF4F4F4)),
        child: Row(
          children: [
            Flexible(
              flex: 1,
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(6),
                        bottomLeft: Radius.circular(6))),
                child: const Center(
                  child: Image(
                    image: AssetImage(''),
                  ),
                ),
              ),
            ),
            Flexible(
              flex: 2,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Column(
                  children: [
                    const SizedBox(
                      width: double.infinity,
                      child: Text(
                        'Slim Men T-Shirt',
                        textAlign: TextAlign.start,
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 16,
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: const [
                        Text(
                          '\$100',
                          style: TextStyle(color: Color(0xFFF68721), fontSize: 12),
                        ),
                        SizedBox(
                          width: 4,
                        ),
                        Text(
                          '\$150',
                          style: TextStyle(color: Colors.black26, fontSize: 10),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Container(
                              height: 6,
                              width: 6,
                              decoration: const ShapeDecoration(
                                  shape: CircleBorder(), color: Colors.red),
                            ),
                            Container(
                              height: 2,
                              width: 2,
                              margin: const EdgeInsets.symmetric(
                                  vertical: 1, horizontal: 1.5),
                              decoration: const ShapeDecoration(
                                  shape: CircleBorder(), color: Colors.red),
                            ),
                            Container(
                              height: 2,
                              width: 2,
                              margin: const EdgeInsets.symmetric(
                                  vertical: 1, horizontal: 1.5),
                              decoration: const ShapeDecoration(
                                  shape: CircleBorder(), color: Colors.red),
                            ),
                            Container(
                              height: 2,
                              width: 2,
                              margin: const EdgeInsets.symmetric(
                                  vertical: 1, horizontal: 1.5),
                              decoration: const ShapeDecoration(
                                  shape: CircleBorder(), color: Colors.red),
                            ),
                            Container(
                              height: 2,
                              width: 2,
                              margin: const EdgeInsets.symmetric(
                                  vertical: 1, horizontal: 1.5),
                              decoration: const ShapeDecoration(
                                  shape: CircleBorder(), color: Colors.red),
                            ),
                            Container(
                              height: 2,
                              width: 2,
                              margin: const EdgeInsets.symmetric(
                                  vertical: 1, horizontal: 1.5),
                              decoration: const ShapeDecoration(
                                  shape: CircleBorder(), color: Colors.red),
                            ),
                            Container(
                              height: 2,
                              width: 2,
                              margin: const EdgeInsets.symmetric(
                                  vertical: 1, horizontal: 1.5),
                              decoration: const ShapeDecoration(
                                  shape: CircleBorder(), color: Colors.red),
                            ),
                            Container(
                              height: 2,
                              width: 2,
                              margin: const EdgeInsets.symmetric(
                                  vertical: 1, horizontal: 1.5),
                              decoration: const ShapeDecoration(
                                  shape: CircleBorder(), color: Colors.red),
                            ),
                            Container(
                              height: 2,
                              width: 2,
                              margin: const EdgeInsets.symmetric(
                                  vertical: 1, horizontal: 1.5),
                              decoration: const ShapeDecoration(
                                  shape: CircleBorder(), color: Colors.red),
                            ),
                            Container(
                              height: 2,
                              width: 2,
                              margin: const EdgeInsets.symmetric(
                                  vertical: 1, horizontal: 1.5),
                              decoration: const ShapeDecoration(
                                  shape: CircleBorder(), color: Colors.red),
                            ),
                            Container(
                              height: 6,
                              width: 6,
                              decoration: const ShapeDecoration(
                                  shape: CircleBorder(), color: Colors.red),
                            )
                          ],
                        ),
                        const SizedBox(
                          width: 20,
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            LayoutBuilder(builder: (BuildContext context,
                                BoxConstraints constraints) {
                              if (isCancelled) {
                                return const Text(
                                  '17-07-2020',
                                  style: TextStyle(
                                      color: Colors.black87, fontSize: 9),
                                );
                              } else {
                                return RichText(
                                    text: const TextSpan(
                                        text: "item",
                                        style: TextStyle(
                                            color: Colors.black54, fontSize: 7),
                                        children: <TextSpan>[
                                      TextSpan(
                                        text: "Shipped",
                                        style: TextStyle(
                                            color: Colors.green, fontSize: 9),
                                      ),
                                      TextSpan(
                                        text: "Monday",
                                        style: TextStyle(
                                            color: Colors.black87, fontSize: 8),
                                      )
                                    ]));
                              }
                            }),
                            const SizedBox(
                              height: 4,
                            ),
                            const Text(
                              'Order Cancelled',
                              style:
                                  TextStyle(color: Colors.black87, fontSize: 9),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            LayoutBuilder(builder: (BuildContext context,
                                BoxConstraints constraints) {
                              if (isCancelled) {
                                return const Text(
                                  'Order Cancelled',
                                  style: TextStyle(
                                      color: Colors.black87, fontSize: 9),
                                );
                              } else {
                                return RichText(
                                    text: const TextSpan(
                                        text: "Arriving",
                                        style: TextStyle(
                                            color: Colors.green, fontSize: 10),
                                        children: <TextSpan>[
                                      TextSpan(
                                        text: "17-07-2020",
                                        style: TextStyle(
                                            color: Colors.green, fontSize: 10),
                                      ),
                                    ]));
                              }
                            }),
                          ],
                        )
                      ],
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      );
  }
}

class OrderDeliveredItemView extends StatelessWidget {
  OrderDeliveredItemView(this.index, {Key? key}) : super(key: key);
  final int index;
  bool isCancelled = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        Navigator.push(context, OrderDetailsPage.route());
      },
      child: Container(
          width: double.infinity,
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6), color: const Color(0xFFF4F4F4)),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                flex: 1,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(
                        maxHeight: 120,
                        maxWidth: 120,
                        minHeight: 60,
                        minWidth: 60
                    ),
                    child: const Center(
                      child: Image(
                        fit: BoxFit.fitHeight,
                        image: AssetImage(''),
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                flex: 2,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      const SizedBox(
                        width: double.infinity,
                        child: Text(
                          'Slim Men T-Shirt',
                          textAlign: TextAlign.start,
                          style: TextStyle(
                              color: Colors.black87,
                              fontSize: 14,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: RichText(
                            text: const TextSpan(
                                text: "Delivered On ",
                                style: TextStyle(color: Colors.black54, fontSize: 12),
                                children: <TextSpan>[
                              TextSpan(
                                text: "17-Mar-2021",
                                style: TextStyle(color: Colors.black, fontSize: 13),
                              )
                            ])),
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: RichText(
                            text: const TextSpan(
                                text: "\$150",
                                style: TextStyle(fontSize: 10, color: Colors.red),
                                children: <TextSpan>[
                              TextSpan(
                                text: "\$200",
                                style: TextStyle(fontSize: 10, color: Colors.black54),
                              )
                            ])),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
    );
  }
}
