import 'package:flutter/foundation.dart';

class OrderDetailsInfoNotifier extends ChangeNotifier {
  /// delivery Method 1 = shipping, 0 = self pick up...............
  int? deliveryMethod = 1;
  int? sameAsBilling = 1;
  int? addressPkNo = 0;

  /// ............. payment order button click response .............
  int isPress = 0;
  void changePressValue(int value) {
    isPress = value;
    notifyListeners();
  }

  void changeDeliveryMethod(int? value){
    deliveryMethod = value;
    notifyListeners();
  }
  void changeSameAsBilling(int? value){
    sameAsBilling = value;
    notifyListeners();
  }
  void changeAddressPkNo(int? value){
    addressPkNo = value;
    notifyListeners();
  }
}