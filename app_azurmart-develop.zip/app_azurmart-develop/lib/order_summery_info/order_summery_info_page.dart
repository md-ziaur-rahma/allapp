import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/floating_action_button.dart';
import 'package:azuramartmy/my_bloc/cart_bloc.dart';
import 'package:azuramartmy/order_summery_info/order_summery_info_body.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class OrderSummeryInfoPage extends StatelessWidget {
  OrderSummeryInfoPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => OrderSummeryInfoPage());
  }

  Future<void> reload() async {
    try {
      final result = await InternetAddress.lookup('example.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        return cartBloc.fetchAllCarts();
      }
    } on SocketException catch (_) {
      Common.toastMsg('No Internet Connection');
      return;
    }
  }

  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
      GlobalKey<RefreshIndicatorState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: const Text(
          'Order Summary',
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: Colors.white,

        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarBrightness: Brightness.dark,
            statusBarIconBrightness: Brightness.dark),
      ),
      body: SafeArea(
        child: RefreshIndicator(
          key: _refreshIndicatorKey,
          color: const Color(0xFFF68721),
          onRefresh: reload,
          child: const OrderSummeryInfoBody(),
        ),
      ),
      floatingActionButton: MyFloatingActionButton(
        snapshot: SharedPreferenceUtils.whatsappModel,
      ),
    );
  }
}
