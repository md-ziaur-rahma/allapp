import 'dart:convert';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/create_address/create_address_page.dart';
import 'package:azuramartmy/email_number_validation/email_number_validation_page.dart';
import 'package:azuramartmy/login/login_page.dart';
import 'package:azuramartmy/my_bloc/cart_bloc.dart';
import 'package:azuramartmy/order_summery_info/order_details_info_notifier.dart';
import 'package:azuramartmy/payment/payment_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/provider_models/address_list_model.dart';
import 'package:azuramartmy/provider_models/cart_model.dart';
import 'package:azuramartmy/provider_models/post_code_model.dart';
import 'package:azuramartmy/provider_models/temp_post_code_model.dart';
import 'package:azuramartmy/provider_models/temp_state_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';

class OrderSummeryInfoBody extends StatefulWidget {
  const OrderSummeryInfoBody({Key? key}) : super(key: key);

  @override
  _OrderSummeryInfoBodyState createState() => _OrderSummeryInfoBodyState();
}

class _OrderSummeryInfoBodyState extends State<OrderSummeryInfoBody> {
  late SharedPreferences localStorage;
  int? userId;

  bool isKeepEmail = false;

  List<TempPostCodeModel> tempPostCodeModel = [];
  List<TempStateModel> tempStateModel = [];
  final TextEditingController _typeAheadController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  TextEditingController cityController = TextEditingController();
  TextEditingController firstNameController =
  TextEditingController();
  TextEditingController lastNameController =
  TextEditingController();
  TextEditingController addressLine1Controller =
  TextEditingController();
  TextEditingController addressLine2Controller =
  TextEditingController();
  TextEditingController postCodeController =
  TextEditingController();
  TextEditingController mobileController =
  TextEditingController();

  List<String?> tempPostCodes = [];
  List<String?> states = [];
  List<String> cities = [];
  int? statePk;
  int? cityPk;

  final _emailRegex = RegExp(
    r'^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$',
  );
  final GlobalKey<FormState> _addressKey = GlobalKey<FormState>();
  final GlobalKey<FormState> _emailKey = GlobalKey<FormState>();

  String? email;
  String? password;

  String? firstName;
  String? lastName;
  String? address;
  String? postCode;
  String? mobile;
  String? addressLine2;
  String? city;
  String? state = 'Select a state';
  String? country;

  /// ............. For Shipping variable .........
  final TextEditingController _typeAheadControllerForShipping = TextEditingController();
  TextEditingController cityControllerForShipping = TextEditingController();
  TextEditingController firstNameControllerForShipping =
  TextEditingController();
  TextEditingController lastNameControllerForShipping =
  TextEditingController();
  TextEditingController addressLine1ControllerForShipping =
  TextEditingController();
  TextEditingController addressLine2ControllerForShipping =
  TextEditingController();
  TextEditingController mobileControllerForShipping =
  TextEditingController();

  final GlobalKey<FormState> _addressKeyS = GlobalKey<FormState>();

  int billingAddressFlag = 0;

  String? emailS;
  String? firstNameS;
  String? lastNameS;
  String? addressS;
  String? postCodeS;
  String? mobileS;
  String? apartmentS;
  String? cityS;
  String? stateS = 'Select a state';
  String? countryS;
  int? statePkS;
  int? cityPkS;

  String? validationEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Enter an email address!';
    } else if (!_emailRegex.hasMatch(value)) {
      return 'Enter a valid email!';
    } else {
      return null;
    }
  }

  String? validationPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Password!';
    } else if (value.length < 5) {
      return 'Enter minimum 5 digit';
    } else {
      return null;
    }
  }

  String? validationFirstName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty First Name!';
    } else {
      return null;
    }
  }

  String? validationLastName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Last Name!';
    } else {
      return null;
    }
  }

  String? validationAddress(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Address!';
    } else {
      return null;
    }
  }

  String? validationCity(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty City!';
    } else {
      return null;
    }
  }

  String? validationMobile(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Mobile!';
    }else if (value.length < 9) {
      return 'Enter valid contact no';
    } else {
      return null;
    }
  }

  String? validationCountry(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Country!';
    } else {
      return null;
    }
  }

  String? validationPostCode(String value) {
    if (value.isEmpty) {
      return 'Empty Post Code!';
    } else {
      return null;
    }
  }

  //......................................................
  void getPostCode() async {
    Client client = Client();
    Uri url = Uri.parse('${Urls.baseUrl}${Urls.POST_CODE}');
    try {
      final response = await client.post(url);
      print('................... ${response.body}.............');
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        PostCodeModel postCodeModel = PostCodeModel.fromJson(body);
        states.add('Select a state');
        for (var i = 0; i < postCodeModel.data!.length; i++) {
          int m = 0;
          if (postCodeModel.data![i].statename != null && postCodeModel.data![i].fstateno != null && postCodeModel.data![i].pocode != null) {
            TempPostCodeModel temp = TempPostCodeModel(
                postCodeModel.data![i].pocode,
                postCodeModel.data![i].fcityno,
                postCodeModel.data![i].cityname,
                postCodeModel.data![i].statename,
                postCodeModel.data![i].fstateno);
            tempPostCodeModel.add(temp);
            tempPostCodes.add(postCodeModel.data![i].pocode);
          }
          for (var x = 0; x < states.length; x++) {
            if (states[x] == postCodeModel.data![i].statename || postCodeModel.data![i].statename == null || postCodeModel.data![i].fstateno == null || postCodeModel.data![i].pocode == null) {
              m = 1;
            }
          }
          if (m == 0) {
            states.add(postCodeModel.data![i].statename);
            TempStateModel temp = TempStateModel(
                postCodeModel.data![i].statename,
                postCodeModel.data![i].fstateno);
            tempStateModel.add(temp);
          }
        }
      }
    } on Exception catch (e) {
      print(e);
    }
  }
  //......................................................

  void saveAddress() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    String? userId = localStorage.getString(SharedPreferenceUtils.USER_ID);
    Client client = Client();
    Map<String, dynamic> data = {
      'session': '$session',
      'user_id': '$userId',
      'firstName': '$firstName',
      'lastName': '$lastName',
      'address': '$address',
      'postCode': '$postCode',
      'mobile': '$mobile',
      'apartment': '$addressLine2',
      'city': '$cityPk',
      'state': '$statePk',
      'country': '$country',
    };
    var requestBody = json.encode(data);
    print(requestBody);
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.SAVE_ADDRESS);
      print('url');
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      print('${body['message']}');
      Common.toastMsg('${body['message']}');
      if (body['status'] == 1) {
        //todo change........
        setState(() {
          _addressKey.currentState!.reset();
          _addressKeyS.currentState!.reset();
          _typeAheadController.clear();
          states = [];
          cities = [];
          state = '';
          city = '';
        });
      }
    } on FormatException catch (e) {
      print(e);
      Common.toastMsg(e.toString());
    } on Exception catch (e) {
      print(e);
      Common.toastMsg(e.toString());
    }
  }

  void clearData() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    localStorage.remove(SharedPreferenceUtils.USER_ID);
    localStorage.remove(SharedPreferenceUtils.EMAIL);
    SharedPreferenceUtils.userIdF = 0;
    SharedPreferenceUtils.usernameF = '';
    localStorage.remove(SharedPreferenceUtils.TOKEN);
    SharedPreferenceUtils.emailF = '';
    SharedPreferenceUtils.mobileF = '';
    SharedPreferenceUtils.lastNameF = '';
    SharedPreferenceUtils.profilePicF = '';
    getData();
  }

  void getData() async {
    localStorage = await SharedPreferences.getInstance();
    userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    email = localStorage.getString(SharedPreferenceUtils.EMAIL);
    emailS = localStorage.getString(SharedPreferenceUtils.EMAIL);
  }

  void saveEmail() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    localStorage.setString(SharedPreferenceUtils.EMAIL, email!);
  }

  void saveBillingAddress() async {
    // SharedPreferences localStorage = await SharedPreferences.getInstance();
    localStorage.setString(SharedPreferenceUtils.EMAIL, email!);
    // localStorage.setString(SharedPreferenceUtils.FIRSTNAME, firstName);
    // localStorage.setString(SharedPreferenceUtils.LASTNAME, lastName);
    // localStorage.setString(SharedPreferenceUtils.ADDRESS, address);
    // localStorage.setString(SharedPreferenceUtils.POSTCODE, postCode);
    // localStorage.setString(SharedPreferenceUtils.CITY, city);
    // localStorage.setString(SharedPreferenceUtils.STATE, state);
    // localStorage.setInt(SharedPreferenceUtils.STATEPK, statePk);
    // localStorage.setInt(SharedPreferenceUtils.CITYPK, cityPk);
    // localStorage.setString(SharedPreferenceUtils.APARTMENT, addressLine2);
    // localStorage.setString(SharedPreferenceUtils.MOBILE, mobile);

    SharedPreferenceUtils.firstNameBL = firstName;
    SharedPreferenceUtils.lastnameBL = lastName;
    SharedPreferenceUtils.addressBL = address;
    SharedPreferenceUtils.address2BL = addressLine2;
    SharedPreferenceUtils.postcodeBL = int.parse(postCode!);
    SharedPreferenceUtils.cityBL = city;
    SharedPreferenceUtils.stateBL = state;
    SharedPreferenceUtils.cityPkBL = cityPk;
    SharedPreferenceUtils.statePkBL = statePk;
    SharedPreferenceUtils.mobileBL = mobile;
  }

  void saveShippingAddress(int type) async {
    localStorage.setString(SharedPreferenceUtils.EMAIL, email!);
    SharedPreferenceUtils.emailF = email;
    if (type == 1) {
      SharedPreferenceUtils.firstNameBL = firstName;
      SharedPreferenceUtils.lastnameBL = lastName;
      SharedPreferenceUtils.addressBL = address;
      SharedPreferenceUtils.address2BL = addressLine2;
      SharedPreferenceUtils.postcodeBL = int.parse(postCode!);
      SharedPreferenceUtils.cityBL = city;
      SharedPreferenceUtils.stateBL = state;
      SharedPreferenceUtils.cityPkBL = cityPk;
      SharedPreferenceUtils.statePkBL = statePk;
      SharedPreferenceUtils.mobileBL = mobile;
    }  else if (type == 2) {
      SharedPreferenceUtils.firstNameSP = firstNameS;
      SharedPreferenceUtils.lastnameSP = lastNameS;
      SharedPreferenceUtils.addressSP = addressS;
      SharedPreferenceUtils.address2SP  = apartmentS;
      SharedPreferenceUtils.postcodeSP  = int.parse(postCodeS!);
      SharedPreferenceUtils.citySP  = cityS;
      SharedPreferenceUtils.stateSP  = stateS;
      SharedPreferenceUtils.cityPkSP  = cityPkS;
      SharedPreferenceUtils.statePkSP  = statePkS;
      SharedPreferenceUtils.mobileSP  = mobileS;
    }  else if (type == 3) {
      SharedPreferenceUtils.firstNameBL = firstName;
      SharedPreferenceUtils.lastnameBL = lastName;
      SharedPreferenceUtils.addressBL = address;
      SharedPreferenceUtils.address2BL = addressLine2;
      SharedPreferenceUtils.postcodeBL = int.parse(postCode!);
      SharedPreferenceUtils.cityBL = city;
      SharedPreferenceUtils.stateBL = state;
      SharedPreferenceUtils.cityPkBL = cityPk;
      SharedPreferenceUtils.statePkBL = statePk;
      SharedPreferenceUtils.mobileBL = mobile;

      SharedPreferenceUtils.firstNameSP = firstNameS;
      SharedPreferenceUtils.lastnameSP = lastNameS;
      SharedPreferenceUtils.addressSP = addressS;
      SharedPreferenceUtils.address2SP  = apartmentS;
      SharedPreferenceUtils.postcodeSP  = int.parse(postCodeS!);
      SharedPreferenceUtils.citySP  = cityS;
      SharedPreferenceUtils.stateSP  = stateS;
      SharedPreferenceUtils.cityPkSP  = cityPkS;
      SharedPreferenceUtils.statePkSP  = statePkS;
      SharedPreferenceUtils.mobileSP  = mobileS;
    }

    /// billing address................
    // SharedPreferenceUtils.firstNameBL = firstName;
    // SharedPreferenceUtils.lastnameBL = lastName;
    // SharedPreferenceUtils.addressBL = address;
    // SharedPreferenceUtils.address2BL = addressLine2;
    // SharedPreferenceUtils.postcodeBL = int.parse(postCode);
    // SharedPreferenceUtils.cityBL = city;
    // SharedPreferenceUtils.stateBL = state;
    // SharedPreferenceUtils.cityPkBL = cityPk;
    // SharedPreferenceUtils.statePkBL = statePk;
    // SharedPreferenceUtils.mobileBL = mobile;
    //
    // /// shipping address................
    // SharedPreferenceUtils.firstNameSP = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).sameAsBilling == 1 ? firstName : firstNameS;
    // SharedPreferenceUtils.lastnameSP = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).sameAsBilling == 1 ? lastName : lastNameS;
    // SharedPreferenceUtils.addressSP = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).sameAsBilling == 1 ? address : addressS;
    // SharedPreferenceUtils.address2SP  = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).sameAsBilling == 1 ? addressLine2 : apartmentS;
    // SharedPreferenceUtils.postcodeSP  = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).sameAsBilling == 1 ? int.parse(postCode) : int.parse(postCodeS);
    // SharedPreferenceUtils.citySP  = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).sameAsBilling == 1 ? city : cityS;
    // SharedPreferenceUtils.stateSP  = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).sameAsBilling == 1 ? state : stateS;
    // SharedPreferenceUtils.cityPkSP  = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).sameAsBilling == 1 ? cityPk : cityPkS;
    // SharedPreferenceUtils.statePkSP  = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).sameAsBilling == 1 ? statePk : statePkS;
    // SharedPreferenceUtils.mobileSP  = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).sameAsBilling == 1 ? mobile : mobileS;
  }

  /// ............... Get All Address ...................
  AddressListModel addressListModel = AddressListModel();
  List<String> addressListString = [];
  String? addressDropdown;

  void getAllAddress() async {
    Client client = Client();
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    print('.................................................................');
    Uri url = Uri.parse(Urls.baseUrl + Urls.ADDRESS);
    print('user id : $userId, all Address ($url)');
    try {
      final response = await client.post(url, body: {'user_id': '$userId','token': '$token'});
      print('Addresses : ${response.body}');
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        print(body);
        AddressListModel addresss = AddressListModel.fromJson(body);
        if (response.body.isNotEmpty) {
          print('parsed address');
          addressListModel = addresss;
          addressListString = [];
          if (addressListModel.data!.shippingAddress!.isNotEmpty) {
            for (var i = 0; i < addressListModel.data!.shippingAddress!.length; i++) {
              if (addressListModel.data!.shippingAddress![i].name != null) {
                addressListString.add('$i${addressListModel.data!.shippingAddress![i].name}, ${addressListModel.data!.shippingAddress![i].lastname}, ${addressListModel.data!.shippingAddress![i].addressline1}');
              }
            }
            addressListString.add('0Create a new address');
          }

          /// ..........fill up  billing addresses data fields
          if (body["data"]["billing_address"] != "") {
            print('//////////////////////////////////////////////////');
            firstNameController.text = addressListModel.data!.billingAddress!.name!;
            lastNameController.text = addressListModel.data!.billingAddress!.lastname!;
            addressLine2Controller.text = addressListModel.data!.billingAddress!.addressline2!;
            addressLine1Controller.text = addressListModel.data!.billingAddress!.addressline1!;
            mobileController.text = addressListModel.data!.billingAddress!.telno!;
            cityController.text = addressListModel.data!.billingAddress!.city!;
            _typeAheadController.text = addressListModel.data!.billingAddress!.postcode!;
            billingAddressFlag = 1;
            firstName = addressListModel.data!.billingAddress!.name;
            lastName = addressListModel.data!.billingAddress!.lastname;
            address = addressListModel.data!.billingAddress!.addressline1;
            addressLine2 = addressListModel.data!.billingAddress!.addressline2;
            postCode = addressListModel.data!.billingAddress!.postcode;
            city = addressListModel.data!.billingAddress!.city;
            state = addressListModel.data!.billingAddress!.state;
            cityPk = addressListModel.data!.billingAddress!.fcityno;
            statePk = addressListModel.data!.billingAddress!.fstateno;
            mobile = addressListModel.data!.billingAddress!.telno;
            print('//////////////////////////////////////////////////');
          }

        }
        // setState(() {});
      } else {
        throw Exception('Failed to load post');
      }
    } on Exception catch (e) {
      print(e);
    }
  }

  void saveAddressInLocal(int type) async {
    var billingAddress = {};
    billingAddress["email"] = email;
    billingAddress["firstname"] = firstName;
    billingAddress["lastname"] = lastName;
    billingAddress["address1"] = address;
    billingAddress["address2"] = addressLine2;
    billingAddress["postcode"] = postCode;
    billingAddress["city"] = city;
    billingAddress["city_pk"] = cityPk;
    billingAddress["state"] = state;
    billingAddress["state_pk"] = statePk;
    billingAddress["country"] = "Malaysia";
    billingAddress["mobile"] = mobile;

    // var sameAsShippingAddress = {};
    // sameAsShippingAddress["email"] = email;
    // sameAsShippingAddress["firstname"] = firstName;
    // sameAsShippingAddress["lastname"] = lastName;
    // sameAsShippingAddress["address1"] = address;
    // sameAsShippingAddress["address2"] = addressLine2;
    // sameAsShippingAddress["postcode"] = postCode;
    // sameAsShippingAddress["city"] = city;
    // sameAsShippingAddress["city_pk"] = cityPk;
    // sameAsShippingAddress["state"] = state;
    // sameAsShippingAddress["state_pk"] = statePk;
    // sameAsShippingAddress["country"] = "Malaysia";
    // sameAsShippingAddress["mobile"] = mobile;

    var shippingAddress = {};
    shippingAddress["email"] = emailS;
    shippingAddress["firstname"] = firstNameS;
    shippingAddress["lastname"] = lastNameS;
    shippingAddress["address1"] = addressS;
    shippingAddress["address2"] = apartmentS;
    shippingAddress["postcode"] = postCodeS;
    shippingAddress["city"] = cityS;
    shippingAddress["city_pk"] = '$cityPkS';
    shippingAddress["state"] = stateS;
    shippingAddress["state_pk"] = '$statePkS';
    shippingAddress["country"] = "Malaysia";
    shippingAddress["mobile"] = mobileS;

    if (type == 1) {
      SharedPreferenceUtils.billingAddress = billingAddress;
      SharedPreferenceUtils.shippingAddress = billingAddress;
    } else if (type == 2) {
      SharedPreferenceUtils.billingAddress = shippingAddress;
      SharedPreferenceUtils.shippingAddress = shippingAddress;
    } else if (type == 3) {
      SharedPreferenceUtils.billingAddress = billingAddress;
      SharedPreferenceUtils.shippingAddress = shippingAddress;
    }
  }

  @override
  void initState() {
    cartBloc.fetchAllCarts();
    // context.read<OrderDetailsInfoNotifier>().changeAddressPkNo(0);
    addressListString = [];
    emailController.text = SharedPreferenceUtils.emailF!;
    getData();
    getPostCode();
    getAllAddress();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      scrollDirection: Axis.vertical,
      slivers: [
        /// ................. Cart Product .................
        StreamBuilder(
            stream: cartBloc.allCarts,
            builder: (context, AsyncSnapshot<CartModel> snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!.data!.bundle!.isNotEmpty || snapshot.data!.data!.nonBundle!.isNotEmpty || snapshot.data!.data!.cart!.isNotEmpty) {
                  // getPostageCost(snapshot);
                  return SliverToBoxAdapter(
                    child: ExpandablePanel(
                      collapsed: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 20),
                        child: Text(snapshot.data!.data!.cartQtyCount > 1 ? '${snapshot.data!.data!.cartQtyCount} Items in your cart' : '${snapshot.data!.data!.cartQtyCount} Item in your cart'),
                      ),
                      theme: const ExpandableThemeData(
                        iconColor: Colors.black87,
                        tapHeaderToExpand: true,
                        useInkWell: true,
                      ),
                      header: ListTile(
                        tileColor: Colors.transparent,

                        leading: const Icon(
                          Icons.shopping_cart_outlined,
                          color: Colors.black87,
                          size: 24,
                        ),
                        trailing: Text(
                          'RM${snapshot.data!.data!.totalPrice.toStringAsFixed(2)}',
                          style: const TextStyle(
                              color: Colors.black87,
                              fontSize: 16,
                              fontWeight: FontWeight.w600),
                        ),
                        title: const Text(
                          'Show Order Summery',
                          style: TextStyle(color: Colors.black54, fontSize: 14),
                        ),
                      ),
                      expanded: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        width: double.infinity,
                        decoration: const BoxDecoration(
                          color: Color(0xFFF4F4F4),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            /// ...... applying bundle product.......
                            for(int i = 0; i < snapshot.data!.data!.bundle!.length; i++)
                              ...List.generate(snapshot.data!.data!.bundle![i].length, (index) => Container(
                                width: double.infinity,
                                margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(width: 1,color: AppsColors.buttonColor),
                                    color: const Color(0xFFFFFFFF)
                                ),
                                child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: double.infinity,
                                      padding: const EdgeInsets.symmetric(vertical: 8,horizontal: 8),
                                      decoration: BoxDecoration(
                                        color: AppsColors.buttonColor,
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          SizedBox(
                                            width: double.infinity,
                                            child: Text('${snapshot.data!.data!.bundle![i][index].bundleNamePublic} for ${snapshot.data!.data!.bundle![i][index].totalRegularBundlePrice}',style: const TextStyle(color: Colors.white,fontSize: 16,fontWeight: FontWeight.w500),),
                                          ),
                                          SizedBox(
                                            width: double.infinity,
                                            child: Text('You Saved RM${snapshot.data!.data!.bundle![i][index].totalRegularPrice! - snapshot.data!.data!.bundle![i][index].totalRegularBundlePrice!}',style: const TextStyle(color: Colors.white,fontSize: 16,fontWeight: FontWeight.w500),),
                                          ),
                                        ],
                                      ),
                                    ),
                                    ...List.generate(snapshot.data!.data!.bundle![i][index].bundleBreakdown!.length, (productIndex) => OrderSummeryBundleProduct(snapshot,i,index,productIndex,1))
                                  ],
                                ),
                              )),

                            /// ...... applying Non bundle product.......
                            for(int i = 0; i < snapshot.data!.data!.nonBundle!.length; i++)
                              ...List.generate(snapshot.data!.data!.nonBundle![i].length, (index) => OrderSummeryNonBundleProduct(snapshot, i, index,1)),

                            /// ...... applying bundle product.......
                            ...List.generate(snapshot.data!.data!.cart!.length, (index) => OrderSummeryCartProduct(snapshot, index,1)),

                            // Divider(
                            //   height: 30,
                            //   thickness: 1,
                            // ),
                            // Row(
                            //   mainAxisSize: MainAxisSize.max,
                            //   children: [
                            //     Expanded(
                            //       flex: 4,
                            //       child: TextFormField(
                            //         decoration: InputDecoration(
                            //           contentPadding:
                            //               EdgeInsets.symmetric(horizontal: 20),
                            //           hintText: 'Gift card or discount code',
                            //           fillColor: Colors.white,
                            //           filled: true,
                            //           focusedBorder: OutlineInputBorder(
                            //               borderRadius:
                            //                   BorderRadius.circular(6),
                            //               borderSide:
                            //                   BorderSide(color: Colors.black)),
                            //           border: OutlineInputBorder(
                            //               borderRadius:
                            //                   BorderRadius.circular(10),
                            //               borderSide: BorderSide(
                            //                   color: Color(0xFFD0D1D2))),
                            //         ),
                            //       ),
                            //     ),
                            //     SizedBox(
                            //       width: 8,
                            //     ),
                            //     Expanded(
                            //       flex: 1,
                            //       child: Container(
                            //         height: 45,
                            //         child: ElevatedButton(
                            //           onPressed: () {},
                            //           style: ElevatedButton.styleFrom(
                            //               primary: AppsColors.buttonColor),
                            //           child: Icon(
                            //             Icons.arrow_forward,
                            //             color: Colors.white,
                            //           ),
                            //         ),
                            //       ),
                            //     )
                            //   ],
                            // ),
                            const Divider(
                              height: 30,
                              thickness: 1,
                            ),
                            Row(
                              children: [
                                const Text(
                                  'Subtotal',
                                  style: TextStyle(fontSize: 16),
                                ),
                                const Spacer(),
                                Text(
                                  'RM${snapshot.data!.data!.totalPrice.toStringAsFixed(2)}',
                                  style: const TextStyle(
                                      color: Colors.black87,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            Row(
                              children: [
                                Text(
                                  context.watch<OrderDetailsInfoNotifier>().deliveryMethod == 1 ? 'Shipping' : 'Pickup',
                                  style: const TextStyle(fontSize: 16),
                                ),
                                const Spacer(),
                                Text(
                                  context.watch<OrderDetailsInfoNotifier>().deliveryMethod == 1
                                      ? 'Calculated at next step'
                                      : 'Free',
                                  style: const TextStyle(
                                      color: Colors.black87, fontSize: 16),
                                ),
                              ],
                            ),
                            const Divider(
                              height: 30,
                              thickness: 1,
                            ),
                            Row(
                              children: [
                                const Text(
                                  'Total',
                                  style: TextStyle(fontSize: 16),
                                ),
                                const Spacer(),
                                Text(
                                  'RM${snapshot.data!.data!.totalPrice.toStringAsFixed(2)}',
                                  style: const TextStyle(
                                      color: Colors.black87,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            const Divider(
                              height: 30,
                              thickness: 1,
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                } else {
                  return const SliverToBoxAdapter(
                      child: Center(
                    child: Text('empty cart!'),
                  ));
                }
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Center(
                    child: Text(snapshot.error.toString()),
                  ),
                );
              }
              return SliverToBoxAdapter(
                child: LoadingWidget(color: AppsColors.buttonColor,),
              );
            }),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 20,
          ),
        ),
        /// ................. Contact Information/ Email ...........
        const SliverToBoxAdapter(
          child: SizedBox(
            width: double.infinity,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Contact Information',
                style: TextStyle(color: Colors.black87, fontSize: 18),
              ),
            ),
          ),
        ),
        SliverLayoutBuilder(
            builder: (BuildContext context, SliverConstraints constraints) {
          if (userId == null) {
            return SliverToBoxAdapter(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Row(
                  children: [
                    const Text('Already have an account?',
                        style: TextStyle(color: Colors.black87, fontSize: 16)),
                    TextButton(
                        onPressed: () {
                          Navigator.push(context, LoginPage.route());
                        },
                        child: Text(
                          'Log in',
                          style: TextStyle(color: AppsColors.highlightedColor),
                        )
                    )
                  ],
                ),
              ),
            );
          } else {
            return const SliverToBoxAdapter(
              child: SizedBox(
                height: 16,
              ),
            );
          }
        }),
        SliverLayoutBuilder(
            builder: (BuildContext context, SliverConstraints constraints) {
          if (userId != null) {
            return SliverToBoxAdapter(
              child: Container(
                margin: const EdgeInsets.only(right: 8),
                child: Row(
                  children: [
                    Expanded(
                        flex: 1,
                        child: Container(
                          height: 45,
                          width: 45,
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFDDCA).withOpacity(0.7),
                            shape: BoxShape.circle
                          ),
                          child: Center(
                            child: FaIcon(FontAwesomeIcons.userAlt,color: AppsColors.highlightedColor,size: 20,),
                          ),
                        )
                    ),
                    Expanded(
                        flex: 3,
                        child: SizedBox(
                          width: double.infinity,
                          child: Text(
                            '$email',
                            textAlign: TextAlign.start,
                            style: const TextStyle(
                              color: Colors.black87,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                    ),
                    Expanded(
                      flex: 1,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(primary: const Color(0xFFFFDDCA).withOpacity(0.7),elevation: 0),
                          onPressed: () {
                            setState(() {
                              clearData();
                              Navigator.pop(context);
                              Navigator.push(context, EmailNumberValidationPage.route());
                            });
                          },
                          child: Text(
                            'Log out',
                            style: TextStyle(
                                color: AppsColors.highlightedColor, fontSize: 14),
                          )
                      ),
                    )
                  ],
                ),
              ),
            );
          } else {
            return SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Form(
                  key: _emailKey,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextFormField(
                        validator: validationEmail,
                        controller: emailController,
                        keyboardType: TextInputType.emailAddress,
                        maxLines: 1,
                        onSaved: (String? val) {
                          email = val;
                          emailS = val;
                        },
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.grey.withOpacity(0.1),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                          hintText: 'Email',
                          labelText: 'Email',
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(2),
                              borderSide: const BorderSide(color: Colors.black)),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(2),
                              borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                        ),
                      ),
                      const SizedBox(height: 12,),
                      const SizedBox(
                        width: double.infinity,
                        child: Text('Password For Next Time Log in',textAlign: TextAlign.start,style: TextStyle(color: Colors.black87,fontSize: 16,fontWeight: FontWeight.normal),),
                      ),
                      const SizedBox(height: 12,),
                      TextFormField(
                        validator: validationPassword,
                        controller: passwordController,
                        keyboardType: TextInputType.visiblePassword,
                        maxLines: 1,
                        onSaved: (String? val) {
                          password = val;
                        },
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.grey.withOpacity(0.1),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                          hintText: 'Password*',
                          labelText: 'Password*',
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(2),
                              borderSide: const BorderSide(color: Colors.black)),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(2),
                              borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                        ),
                      ),
                    ],
                  )
                ),
              ),
            );
          }
        }),

        /// ............ email checkbox ...................
        // SliverToBoxAdapter(
        //   child: Padding(
        //     padding: const EdgeInsets.symmetric(horizontal: 16),
        //     child: Row(
        //       children: [
        //         Checkbox(
        //             value: isKeepEmail,
        //             activeColor: Color(0xFFF68721),
        //             checkColor: Colors.white,
        //             onChanged: (bool value) {
        //               setState(() {
        //                 isKeepEmail = value;
        //               });
        //             }),
        //         SizedBox(
        //           width: 0,
        //         ),
        //         Expanded(
        //             child: Text(
        //           'Keep me up to date on news and exclusive offers',
        //           style: TextStyle(fontSize: 14, color: Colors.black87),
        //         ))
        //       ],
        //     ),
        //   ),
        // ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 24,
          ),
        ),

        /// .............. Delivery method container ..............
        const SliverToBoxAdapter(
            child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            'Delivery Method',
            style: TextStyle(color: Colors.black87, fontSize: 18),
          ),
        )),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 20,
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(2.0),
                  border: Border.all(color: const Color(0xFFD0D1D2), width: 1.0)),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                    onTap: () {
                      Provider.of<OrderDetailsInfoNotifier>(context, listen: false).changeDeliveryMethod(1);
                      // context.read<OrderDetailsInfoNotifier>().changeDeliveryMethod(1);
                    },
                    child: ListTile(
                      leading: Radio(
                          value: 1,
                          groupValue: context.watch<OrderDetailsInfoNotifier>().deliveryMethod,
                          activeColor: AppsColors.highlightedColor,
                          onChanged: (int? value) {
                            Provider.of<OrderDetailsInfoNotifier>(context, listen: false).changeDeliveryMethod(value);
                          }),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(
                            Icons.local_shipping_outlined,
                            color: context.watch<OrderDetailsInfoNotifier>().deliveryMethod == 1
                                ? Colors.black87
                                : Colors.black54,
                          ),
                          const SizedBox(
                            width: 8,
                          ),
                          Text(
                            'Courier',
                            style: TextStyle(
                                color: context.watch<OrderDetailsInfoNotifier>().deliveryMethod == 1
                                    ? Colors.black87
                                    : Colors.black54,
                                fontSize: 14),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    thickness: 1,
                  ),
                  GestureDetector(
                    onTap: () {
                      Provider.of<OrderDetailsInfoNotifier>(context, listen: false).changeDeliveryMethod(0);
                      Provider.of<OrderDetailsInfoNotifier>(context,listen: false).changeSameAsBilling(1);
                      // context.read<OrderDetailsInfoNotifier>().changeDeliveryMethod(0);
                    },
                    child: ListTile(
                      leading: Radio(
                          value: 0,
                          activeColor: AppsColors.highlightedColor,
                          groupValue: context.watch<OrderDetailsInfoNotifier>().deliveryMethod,
                          onChanged: (int? value) {
                            context.read<OrderDetailsInfoNotifier>().changeDeliveryMethod(value);
                            context.read<OrderDetailsInfoNotifier>().changeSameAsBilling(1);
                          }),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(
                            Icons.wallet_giftcard_outlined,
                            color: context.watch<OrderDetailsInfoNotifier>().deliveryMethod == 0
                                ? AppsColors.highlightedColor
                                : Colors.black54,
                          ),
                          const SizedBox(
                            width: 8,
                          ),
                          Text(
                            'Self-Collect',
                            style: TextStyle(
                                color: context.watch<OrderDetailsInfoNotifier>().deliveryMethod == 0
                                    ? AppsColors.highlightedColor
                                    : Colors.black54,
                                fontSize: 14),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),

        const SliverToBoxAdapter(
          child: SizedBox(
            height: 16,
          ),
        ),

        /// .............. Shipping  and billing Address .................
        SliverLayoutBuilder(
            builder: (BuildContext context, SliverConstraints constraints) {
              if (context.watch<OrderDetailsInfoNotifier>().deliveryMethod == 1) {
                return SliverToBoxAdapter(
                  child: Container(
                    padding: const EdgeInsets.all(16.0),
                    decoration: const BoxDecoration(
                        color: Color(0xFFFAFAFA),
                        borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(2.0),
                            bottomLeft: Radius.circular(2.0))),
                    child: Form(
                      key: _addressKeyS,
                      autovalidateMode:
                      AutovalidateMode.always,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(
                              width: double.infinity,
                              child: Text(
                                'Shipping Address',
                                style: TextStyle(
                                    color: Colors.black87, fontSize: 18),
                              )
                          ),
                          const SizedBox(
                            height: 10,
                          ),

                          ///////////////////////////////////////////////////
                          LayoutBuilder(builder: (BuildContext context,
                              BoxConstraints constraints) {
                            if (userId != null &&
                                addressListString.isNotEmpty) {
                              return Column(
                                children: [
                                  Container(
                                    margin: const EdgeInsets.symmetric(
                                        vertical: 8),
                                    width: double.infinity,
                                    child: const Text(
                                      'Suggested You',
                                      style: TextStyle(
                                          color: Colors.black87,
                                          fontSize: 16),
                                    ),
                                  ),
                                  SizedBox(
                                    width: double.infinity,
                                    child:
                                    DropdownButtonFormField<String>(
                                      hint: const Text('Choose an address'),
                                      decoration: InputDecoration(
                                        contentPadding:
                                        const EdgeInsets.symmetric(
                                            horizontal: 20),
                                        focusedBorder: OutlineInputBorder(
                                            borderRadius:
                                            BorderRadius.circular(2),
                                            borderSide: const BorderSide(
                                                color: Colors.black)),
                                        border: OutlineInputBorder(
                                            borderRadius:
                                            BorderRadius.circular(2),
                                            borderSide: const BorderSide(
                                                color:
                                                Color(0xFFD0D1D2))),
                                      ),
                                      focusColor: AppsColors.highlightedColor,
                                      value: addressDropdown,
                                      icon: const Icon(
                                        Icons.arrow_drop_down,
                                      ),
                                      iconSize: 24,
                                      elevation: 3,
                                      //underline: SizedBox(),
                                      onChanged: (newValue) {
                                        setState(() {
                                          addressDropdown = newValue;
                                          for(var i = 0; i < addressListString.length; i++) {
                                            if (newValue == addressListString[i] && i != addressListString.length -1) {
                                              firstNameControllerForShipping.text = addressListModel.data!.shippingAddress![i].name!;
                                              lastNameControllerForShipping.text = addressListModel.data!.shippingAddress![i].lastname!;
                                              addressLine1ControllerForShipping
                                                  .text =
                                                  addressListModel
                                                      .data!
                                                      .shippingAddress![
                                                  i]
                                                      .addressline1!;
                                              addressLine2ControllerForShipping
                                                  .text =
                                              addressListModel
                                                  .data!
                                                  .shippingAddress![
                                              i]
                                                  .addressline2!;
                                              mobileControllerForShipping
                                                  .text =
                                                  addressListModel
                                                      .data!
                                                      .shippingAddress![
                                                  i]
                                                      .telno!;
                                              _typeAheadControllerForShipping
                                                  .text =
                                                  addressListModel
                                                      .data!
                                                      .shippingAddress![
                                                  i]
                                                      .postcode!;
                                              postCodeS =
                                                  addressListModel
                                                      .data!
                                                      .shippingAddress![
                                                  i]
                                                      .postcode;
                                              cityPkS = addressListModel
                                                  .data!
                                                  .shippingAddress![i]
                                                  .fcityno;
                                              statePkS =
                                                  addressListModel
                                                      .data!
                                                      .shippingAddress![
                                                  i]
                                                      .fstateno;
                                              cityControllerForShipping
                                                  .text =
                                                  addressListModel
                                                      .data!
                                                      .shippingAddress![
                                                  i]
                                                      .city!;
                                              stateS = addressListModel.data!.shippingAddress![i].state;
                                              context.read<OrderDetailsInfoNotifier>().changeAddressPkNo(addressListModel.data!.shippingAddress![i].pkno);
                                            }
                                          }
                                          if (newValue == addressListString[addressListString.length - 1]) {
                                            Navigator.push(context, CreateAddressPage.route());
                                          }
                                        });
                                      },
                                      items: addressListString
                                          .map<DropdownMenuItem<String>>(
                                              (String value) {
                                            return DropdownMenuItem<String>(
                                              value: value,
                                              child: Text(value.substring(1),
                                              ),
                                            );
                                          }).toList(),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                ],
                              );
                            } else {
                              return const SizedBox(
                                height: 4,
                              );
                            }
                          }),
                          ///////////////////////////////////////////////////
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              validator: validationFirstName,
                              textInputAction: TextInputAction.next,
                              controller: firstNameControllerForShipping,
                              onSaved: (String? val) {
                                firstNameS = val;
                              },
                              keyboardType: TextInputType.text,
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                hintText: 'First Name',
                                labelText: 'First Name',
                                focusedBorder: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide: const BorderSide(
                                        color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              validator: validationLastName,
                              textInputAction: TextInputAction.next,
                              controller: lastNameControllerForShipping,
                              onSaved: (String? val) {
                                lastNameS = val;
                              },
                              keyboardType: TextInputType.text,
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                hintText: 'Last Name',
                                labelText: 'Last Name',
                                focusedBorder: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide: const BorderSide(
                                        color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              validator: validationAddress,
                              textInputAction: TextInputAction.next,
                              controller:
                              addressLine1ControllerForShipping,
                              onSaved: (String? val) {
                                addressS = val;
                              },
                              keyboardType: TextInputType.text,
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                hintText: 'Address line 1',
                                labelText: 'Address line 1',
                                focusedBorder: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide: const BorderSide(
                                        color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              textInputAction: TextInputAction.next,
                              controller:
                              addressLine2ControllerForShipping,
                              onSaved: (val) {
                                setState(() {
                                  apartmentS = val;
                                });
                              },
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                hintText: 'Address line 2. (Optional)',
                                labelText: 'Address line 2',
                                focusedBorder: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide: const BorderSide(
                                        color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            child: TypeAheadField(
                              textFieldConfiguration: TextFieldConfiguration(
                                controller: _typeAheadControllerForShipping,
                                  autofocus: false,
                                  style: DefaultTextStyle.of(context).style.copyWith(
                                      fontStyle: FontStyle.italic
                                  ),
                                  decoration: const InputDecoration(
                                      labelText: 'post code',
                                      border: OutlineInputBorder()
                                  )
                              ),
                              transitionBuilder: (context, suggestionsBox, controller) {
                                return suggestionsBox;
                              },
                              suggestionsCallback: (pattern) async {
                                return tempPostCodes
                                    .where((item) =>
                                    item!.toLowerCase().startsWith(pattern.toLowerCase()))
                                    .toList();
                              },
                              itemBuilder: (context, dynamic suggestion) {
                                return ListTile(
                                  leading: const Icon(Icons.shopping_cart,size: 20,),
                                  title: Text('$suggestion'),
                                );
                              },
                              onSuggestionSelected: (dynamic suggestion) {
                                for (var item in tempPostCodeModel) {
                                  if (suggestion.toString().toLowerCase() == item.pocode) {
                                    setState(() {
                                      _typeAheadControllerForShipping.text =
                                          item.pocode!;
                                      print('${item.pocode}');
                                      postCodeS = item.pocode;
                                      print('$postCodeS');
                                      cityPkS = item.fcityno;
                                      statePkS = item.fstateno;
                                      stateS = item.statename;
                                      cityS = item.cityname;
                                      cityControllerForShipping.text =
                                          item.cityname!;
                                    });
                                  }
                                }
                              },
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              controller: cityControllerForShipping,
                              validator: validationCity,
                              textInputAction: TextInputAction.next,
                              onSaved: (String? val) {
                                cityS = val;
                              },
                              keyboardType: TextInputType.text,
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                hintText: 'City',
                                labelText: 'City',
                                focusedBorder: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide: const BorderSide(
                                        color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: DropdownButtonFormField<String>(
                              hint: const Text('Select a state'),
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide: const BorderSide(
                                        color: Color(0xFFD0D1D2))),
                              ),
                              focusColor: AppsColors.highlightedColor,
                              value: stateS,
                              icon: const Icon(
                                Icons.arrow_drop_down,
                              ),
                              iconSize: 24,
                              elevation: 3,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Select a state';
                                } else if (value == 'Select a state') {
                                  return 'Select a state';
                                } else {
                                  return null;
                                }
                              },
                              //underline: SizedBox(),
                              onChanged: (newValue) {
                                setState(() {
                                  stateS = newValue;
                                });
                              },
                              items: states.map<DropdownMenuItem<String>>(
                                      (String? value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value!),
                                    );
                                  }).toList(),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              enabled: false,
                              initialValue: 'Malaysia',
                              validator: validationCountry,
                              onSaved: (val) {
                                setState(() {
                                  countryS = val;
                                });
                              },
                              decoration: InputDecoration(
                                labelText: 'Country',
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide: const BorderSide(
                                        color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              validator: validationMobile,
                              textInputAction: TextInputAction.next,
                              maxLength: 10,
                              controller: mobileControllerForShipping,
                              onSaved: (String? val) {
                                mobileS = val;
                              },
                              keyboardType: TextInputType.number,
                              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                hintText: 'Mobile No',
                                labelText: 'Mobile No',
                                prefix: const Text('+60 '),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius:
                                    BorderRadius.circular(2),
                                    borderSide: const BorderSide(
                                        color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),

                          /// ................ checkboxe email
                          // Padding(
                          //   padding:
                          //       const EdgeInsets.symmetric(vertical: 0),
                          //   child: Row(
                          //     children: [
                          //       Checkbox(
                          //           value: isKeepEmail,
                          //           activeColor: Color(0xFFF68721),
                          //           checkColor: Colors.white,
                          //           onChanged: (bool value) {
                          //             setState(() {
                          //               isKeepEmail = value;
                          //             });
                          //           }),
                          //       SizedBox(
                          //         width: 0,
                          //       ),
                          //       Expanded(
                          //           child: Text(
                          //         'Keep me up to date on news and exclusive offers',
                          //         style: TextStyle(
                          //             fontSize: 14,
                          //             color: Colors.black87),
                          //       ))
                          //     ],
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ),
                );
              }else if (context.watch<OrderDetailsInfoNotifier>().deliveryMethod == 0) {
                return SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Form(
                      key: _addressKey,
                      autovalidateMode: AutovalidateMode.always,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(
                              width: double.infinity,
                              child: Text(
                                'Billing Address',
                                style: TextStyle(
                                    color: Colors.black87, fontSize: 18),
                              )),
                          const SizedBox(
                            height: 12,
                          ),
                          const SizedBox(
                              width: double.infinity,
                              child: Text(
                                'Select the address that matches your card or payment method',
                                style: TextStyle(
                                    color: Colors.black87, fontSize: 14),
                              )),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              validator: validationFirstName,
                              textInputAction: TextInputAction.next,
                              controller: firstNameController,
                              onSaved: (String? val) {
                                firstName = val;
                              },
                              keyboardType: TextInputType.text,
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                hintText: 'First Name',
                                labelText: 'First Name',
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              controller: lastNameController,
                              validator: validationLastName,
                              textInputAction: TextInputAction.next,
                              onSaved: (String? val) {
                                lastName = val;
                              },
                              keyboardType: TextInputType.text,
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                hintText: 'Last Name',
                                labelText: 'Last Name',
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              controller: addressLine1Controller,
                              validator: validationAddress,
                              textInputAction: TextInputAction.next,
                              onSaved: (String? val) {
                                address = val;
                              },
                              keyboardType: TextInputType.text,
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                hintText: 'Address',
                                labelText: 'Address',
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              controller: addressLine2Controller,
                              textInputAction: TextInputAction.next,
                              onSaved: (val) {
                                setState(() {
                                  addressLine2 = val;
                                });
                              },
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                hintText: 'Address line 2(Optional)',
                                labelText: 'Address line 2',
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),

                          SizedBox(
                            child: TypeAheadField(
                              textFieldConfiguration: TextFieldConfiguration(
                                  controller: _typeAheadController,
                                  autofocus: false,
                                  style: DefaultTextStyle.of(context).style.copyWith(
                                      fontStyle: FontStyle.italic
                                  ),
                                  decoration: const InputDecoration(
                                      labelText: 'post code',
                                      border: OutlineInputBorder()
                                  )
                              ),
                              transitionBuilder: (context, suggestionsBox, controller) {
                                return suggestionsBox;
                              },
                              suggestionsCallback: (pattern) async {
                                return tempPostCodes
                                    .where((item) =>
                                    item!.toLowerCase().startsWith(pattern.toLowerCase()))
                                    .toList();
                              },
                              itemBuilder: (context, dynamic suggestion) {
                                return ListTile(
                                  leading: const Icon(Icons.shopping_cart,size: 20,),
                                  title: Text('$suggestion'),
                                );
                              },
                              onSuggestionSelected: (dynamic suggestion) {
                                for (var item in tempPostCodeModel) {
                                  if (suggestion.toString().toLowerCase() == item.pocode) {
                                    setState(() {
                                      _typeAheadController.text = item.pocode!;
                                      print('${item.pocode}');
                                      postCode = item.pocode;
                                      cityPk = item.fcityno;
                                      statePk = item.fstateno;
                                      state = item.statename;
                                      city = item.cityname;
                                      cityController.text = item.cityname!;
                                    });
                                  }
                                }
                              },
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              controller: cityController,
                              validator: validationCity,
                              textInputAction: TextInputAction.next,
                              onSaved: (String? val) {
                                city = val;
                              },
                              keyboardType: TextInputType.text,
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                hintText: 'City',
                                labelText: 'City',
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: DropdownButtonFormField<String>(
                              hint: const Text('Select a state'),
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Color(0xFFD0D1D2))),
                              ),
                              focusColor: AppsColors.highlightedColor,
                              value: state,
                              icon: const Icon(
                                Icons.arrow_drop_down,
                              ),
                              iconSize: 24,
                              elevation: 3,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Select a state';
                                } else if (value == 'Select a state') {
                                  return 'Select a state';
                                } else {
                                  return null;
                                }
                              },
                              //underline: SizedBox(),
                              onChanged: (newValue) {
                                setState(() {
                                  state = newValue;
                                  for (var i = 0;
                                  i < tempStateModel.length;
                                  i++) {
                                    if (newValue == tempStateModel[i].state) {
                                      statePk = tempStateModel[i].state_pk;
                                    }
                                  }
                                });
                              },
                              items: states.map<DropdownMenuItem<String>>(
                                      (String? value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value!),
                                    );
                                  }).toList(),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              enabled: false,
                              initialValue: 'Malaysia',
                              validator: validationCountry,
                              onSaved: (val) {
                                setState(() {
                                  country = val;
                                });
                              },
                              decoration: InputDecoration(
                                labelText: 'Country',
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextFormField(
                              controller: mobileController,
                              validator: validationMobile,
                              textInputAction: TextInputAction.done,
                              maxLength: 10,
                              onSaved: (String? val) {
                                mobile = val;
                              },
                              keyboardType: TextInputType.number,
                              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                              decoration: InputDecoration(
                                contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                                hintText: 'Mobile No',
                                labelText: 'Mobile No',
                                prefix: const Text('+60'),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Colors.black)),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(2),
                                    borderSide:
                                    const BorderSide(color: Color(0xFFD0D1D2))),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          // Padding(
                          //   padding: const EdgeInsets.symmetric(vertical: 0),
                          //   child: Row(
                          //     children: [
                          //       Checkbox(
                          //           value: isKeepEmail,
                          //           activeColor: Color(0xFFF68721),
                          //           checkColor: Colors.white,
                          //           onChanged: (bool value) {
                          //             setState(() {
                          //               isKeepEmail = value;
                          //             });
                          //           }),
                          //       SizedBox(
                          //         width: 0,
                          //       ),
                          //       Expanded(
                          //           child: Text(
                          //             'Keep me up to date on news and exclusive offers',
                          //             style: TextStyle(fontSize: 14, color: Colors.black87),
                          //           ))
                          //     ],
                          //   ),
                          // ),
                          // SizedBox(
                          //   width: double.infinity,
                          //   child: Container(
                          //     width: double.infinity,
                          //     height: 50,
                          //     child: ElevatedButton(
                          //       style: ElevatedButton.styleFrom(
                          //           primary: Color(0xFFF68721), shape: StadiumBorder()),
                          //       onPressed: () {
                          //         if (userId != null) {
                          //           if (_addressKey.currentState.validate()) {
                          //             _addressKey.currentState.save();
                          //             saveBillingAddress();
                          //             PaymentPage.isShipping = 1;
                          //             Navigator.push(context, PaymentPage.route());
                          //           }
                          //         } else {
                          //           if (_emailKey.currentState.validate() &&
                          //               _addressKey.currentState.validate()) {
                          //             _emailKey.currentState.save();
                          //             _addressKey.currentState.save();
                          //
                          //             saveBillingAddress();
                          //             // Navigator.push(context, ShippingPage.route());
                          //             PaymentPage.isShipping = 1;
                          //             Navigator.push(context, PaymentPage.route());
                          //             //saveAddress();
                          //           }
                          //         }
                          //       },
                          //       child: Text('Save Address'),
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ),
                );
              }
              return const SliverToBoxAdapter(
                child: Text(''),
              );
            }
        ),

        //.............................. Billing Address Old system .................................
        // StreamBuilder(
        //     stream: addressBloc.allAddress,
        //     builder: (context, AsyncSnapshot<AddressListModel> snapshot) {
        //       if (snapshot.hasData) {
        //         if (userId != null &&
        //             snapshot.data.data.billingAddress != null) {
        //           billingAddressFlag = 1;
        //           firstName = snapshot.data.data.billingAddress.name;
        //           lastName = snapshot.data.data.billingAddress.lastname;
        //           address = snapshot.data.data.billingAddress.addressline1;
        //           addressLine2 = snapshot.data.data.billingAddress.addressline2;
        //           postCode = snapshot.data.data.billingAddress.postcode;
        //           city = snapshot.data.data.billingAddress.city;
        //           state = snapshot.data.data.billingAddress.state;
        //           cityPk = snapshot.data.data.billingAddress.fcityno;
        //           statePk = snapshot.data.data.billingAddress.fstateno;
        //           mobile = snapshot.data.data.billingAddress.telno;
        //           return SliverToBoxAdapter(
        //             child: Padding(
        //               padding: const EdgeInsets.symmetric(horizontal: 16),
        //               child: Column(
        //                 mainAxisSize: MainAxisSize.min,
        //                 mainAxisAlignment: MainAxisAlignment.start,
        //                 crossAxisAlignment: CrossAxisAlignment.start,
        //                 children: [
        //                   SizedBox(
        //                       width: double.infinity,
        //                       child: Text(
        //                         'Billing Address',
        //                         style: TextStyle(
        //                             color: Colors.black87, fontSize: 18),
        //                       )
        //                   ),
        //                   SizedBox(
        //                     height: 4,
        //                   ),
        //                   SizedBox(
        //                       width: double.infinity,
        //                       child: Text(
        //                         'Select the address that matches your card or payment method',
        //                         style: TextStyle(
        //                             color: Colors.black87, fontSize: 14),
        //                       )),
        //                   SizedBox(
        //                     height: 16,
        //                   ),
        //                   SizedBox(
        //                       width: double.infinity,
        //                       child: Text(
        //                         'Name : ${snapshot.data.data.billingAddress.name} ${snapshot.data.data.billingAddress.lastname}',
        //                         style: TextStyle(
        //                             color: Colors.black87, fontSize: 16),
        //                       )),
        //                   SizedBox(
        //                     height: 8,
        //                   ),
        //                   SizedBox(
        //                       width: double.infinity,
        //                       child: Text(
        //                         'Address Line 1 : ${snapshot.data.data.billingAddress.addressline1}',
        //                         style: TextStyle(
        //                             color: Colors.black87, fontSize: 16),
        //                       )),
        //                   SizedBox(
        //                     height: 8,
        //                   ),
        //                   SizedBox(
        //                       width: double.infinity,
        //                       child: Text(
        //                         'Address Line 2 : ${snapshot.data.data.billingAddress.addressline2}',
        //                         style: TextStyle(
        //                             color: Colors.black87, fontSize: 16),
        //                       )),
        //                   SizedBox(
        //                     height: 8,
        //                   ),
        //                   SizedBox(
        //                       width: double.infinity,
        //                       child: Text(
        //                         'Post Code : ${snapshot.data.data.billingAddress.postcode}',
        //                         style: TextStyle(
        //                             color: Colors.black87, fontSize: 16),
        //                       )),
        //                   SizedBox(
        //                     height: 8,
        //                   ),
        //                   SizedBox(
        //                       width: double.infinity,
        //                       child: Text(
        //                         'City : ${snapshot.data.data.billingAddress.city}',
        //                         style: TextStyle(
        //                             color: Colors.black87, fontSize: 16),
        //                       )),
        //                   SizedBox(
        //                     height: 8,
        //                   ),
        //                   SizedBox(
        //                       width: double.infinity,
        //                       child: Text(
        //                         'State : ${snapshot.data.data.billingAddress.state}',
        //                         style: TextStyle(
        //                             color: Colors.black87, fontSize: 16),
        //                       )),
        //                   SizedBox(
        //                     height: 8,
        //                   ),
        //                   SizedBox(
        //                       width: double.infinity,
        //                       child: Text(
        //                         snapshot.data.data.billingAddress.country !=
        //                             null
        //                             ? 'Country : ${snapshot.data.data.billingAddress.country}'
        //                             : 'Malaysia',
        //                         style: TextStyle(
        //                             color: Colors.black87, fontSize: 16),
        //                       )),
        //                   SizedBox(
        //                     height: 8,
        //                   ),
        //                   SizedBox(
        //                       width: double.infinity,
        //                       child: Text(
        //                         'Mobile No : ${snapshot.data.data.billingAddress.telno}',
        //                         style: TextStyle(
        //                             color: Colors.black87, fontSize: 16),
        //                       )),
        //                   SizedBox(
        //                     height: 8,
        //                   ),
        //                   TextButton.icon(
        //                       onPressed: () {
        //                         Navigator.push(
        //                             context, AddressManagerPage.route());
        //                       },
        //                       icon: Icon(
        //                         Icons.edit,
        //                         color: AppsColors.highlightedColor,
        //                       ),
        //                       label: Text(
        //                         'Edit Address',
        //                         style: TextStyle(color: AppsColors.highlightedColor),
        //                       ))
        //                 ],
        //               ),
        //             ),
        //           );
        //         } else {
        //           return SliverToBoxAdapter(
        //             child: Padding(
        //               padding: const EdgeInsets.symmetric(horizontal: 16),
        //               child: Form(
        //                 key: _addressKey,
        //                 autovalidateMode: AutovalidateMode.always,
        //                 child: Column(
        //                   mainAxisAlignment: MainAxisAlignment.start,
        //                   mainAxisSize: MainAxisSize.min,
        //                   children: [
        //                     SizedBox(
        //                         width: double.infinity,
        //                         child: Text(
        //                           'Billing Address',
        //                           style: TextStyle(
        //                               color: Colors.black87, fontSize: 18),
        //                         )),
        //                     SizedBox(
        //                       height: 4,
        //                     ),
        //                     SizedBox(
        //                         width: double.infinity,
        //                         child: Text(
        //                           'Select the address that matches your card or payment method',
        //                           style: TextStyle(
        //                               color: Colors.black87, fontSize: 14),
        //                         )),
        //                     SizedBox(
        //                       height: 16,
        //                     ),
        //                     SizedBox(
        //                       width: double.infinity,
        //                       child: TextFormField(
        //                         validator: validationFirstName,
        //                         textInputAction: TextInputAction.next,
        //                         onSaved: (String val) {
        //                           firstName = val;
        //                         },
        //                         keyboardType: TextInputType.text,
        //                         decoration: InputDecoration(
        //                           contentPadding:
        //                           EdgeInsets.symmetric(horizontal: 20),
        //                           hintText: 'First Name',
        //                           labelText: 'First Name',
        //                           focusedBorder: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Colors.black)),
        //                           border: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Color(0xFFD0D1D2))),
        //                         ),
        //                       ),
        //                     ),
        //                     SizedBox(
        //                       height: 16,
        //                     ),
        //                     SizedBox(
        //                       width: double.infinity,
        //                       child: TextFormField(
        //                         validator: validationLastName,
        //                         textInputAction: TextInputAction.next,
        //                         onSaved: (String val) {
        //                           lastName = val;
        //                         },
        //                         keyboardType: TextInputType.text,
        //                         decoration: InputDecoration(
        //                           contentPadding:
        //                           EdgeInsets.symmetric(horizontal: 20),
        //                           hintText: 'Last Name',
        //                           labelText: 'Last Name',
        //                           focusedBorder: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Colors.black)),
        //                           border: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Color(0xFFD0D1D2))),
        //                         ),
        //                       ),
        //                     ),
        //                     SizedBox(
        //                       height: 16,
        //                     ),
        //                     SizedBox(
        //                       width: double.infinity,
        //                       child: TextFormField(
        //                         validator: validationAddress,
        //                         textInputAction: TextInputAction.next,
        //                         onSaved: (String val) {
        //                           address = val;
        //                         },
        //                         keyboardType: TextInputType.text,
        //                         decoration: InputDecoration(
        //                           contentPadding:
        //                           EdgeInsets.symmetric(horizontal: 20),
        //                           hintText: 'Address',
        //                           labelText: 'Address',
        //                           focusedBorder: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Colors.black)),
        //                           border: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Color(0xFFD0D1D2))),
        //                         ),
        //                       ),
        //                     ),
        //                     SizedBox(
        //                       height: 16,
        //                     ),
        //                     SizedBox(
        //                       width: double.infinity,
        //                       child: TextFormField(
        //                         textInputAction: TextInputAction.next,
        //                         onSaved: (val) {
        //                           setState(() {
        //                             addressLine2 = val;
        //                           });
        //                         },
        //                         decoration: InputDecoration(
        //                           contentPadding:
        //                           EdgeInsets.symmetric(horizontal: 20),
        //                           hintText: 'Address line 2(Optional)',
        //                           labelText: 'Address line 2',
        //                           focusedBorder: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Colors.black)),
        //                           border: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Color(0xFFD0D1D2))),
        //                         ),
        //                       ),
        //                     ),
        //                     SizedBox(
        //                       height: 16,
        //                     ),
        //                     SizedBox(
        //                       width: double.infinity,
        //                       child: AutoCompleteTextField<TempPostCodeModel>(
        //                         key: _autoCompleteKey,
        //                         controller: autoCompleteController,
        //                         textInputAction: TextInputAction.next,
        //                         itemBuilder: (context, item) {
        //                           return Padding(
        //                             padding: const EdgeInsets.symmetric(
        //                                 horizontal: 20, vertical: 8),
        //                             child: Text(
        //                               '${item.pocode}',
        //                               style: TextStyle(
        //                                   color: Colors.black87, fontSize: 16),
        //                             ),
        //                           );
        //                         },
        //                         itemFilter: (item, query) {
        //                           return item.pocode
        //                               .toLowerCase()
        //                               .startsWith(query.toLowerCase());
        //                         },
        //                         itemSorter: (a, b) {
        //                           return a.pocode.compareTo(b.pocode);
        //                         },
        //                         itemSubmitted: (item) {
        //                           setState(() {
        //                             autoCompleteController.text = item.pocode;
        //                             print('${item.pocode}');
        //                             postCode = item.pocode;
        //                             cityPk = item.fcityno;
        //                             statePk = item.fstateno;
        //                             state = item.statename;
        //                             city = item.cityname;
        //                             cityController.text = item.cityname;
        //                           });
        //                         },
        //                         suggestions: tempPostCodeModel,
        //                         clearOnSubmit: false,
        //                         keyboardType: TextInputType.number,
        //                         suggestionsAmount: 10,
        //                         style: new TextStyle(
        //                             color: Colors.black, fontSize: 16.0),
        //                         decoration: InputDecoration(
        //                             contentPadding:
        //                             EdgeInsets.symmetric(horizontal: 20),
        //                             hintText: 'Post Code',
        //                             labelText: 'Post Code',
        //                             focusedBorder: OutlineInputBorder(
        //                                 borderRadius: BorderRadius.circular(2),
        //                                 borderSide:
        //                                 BorderSide(color: Colors.black)),
        //                             border: OutlineInputBorder(
        //                                 borderRadius: BorderRadius.circular(2),
        //                                 borderSide: BorderSide(
        //                                     color: Color(0xFFD0D1D2))),
        //                             filled: true,
        //                             hintStyle: TextStyle(color: Colors.black)),
        //                       ),
        //                     ),
        //                     SizedBox(
        //                       height: 16,
        //                     ),
        //                     SizedBox(
        //                       width: double.infinity,
        //                       child: TextFormField(
        //                         controller: cityController,
        //                         validator: validationCity,
        //                         textInputAction: TextInputAction.next,
        //                         onSaved: (String val) {
        //                           city = val;
        //                         },
        //                         keyboardType: TextInputType.text,
        //                         decoration: InputDecoration(
        //                           contentPadding:
        //                           EdgeInsets.symmetric(horizontal: 20),
        //                           hintText: 'City',
        //                           labelText: 'City',
        //                           focusedBorder: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Colors.black)),
        //                           border: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Color(0xFFD0D1D2))),
        //                         ),
        //                       ),
        //                     ),
        //                     SizedBox(
        //                       height: 16,
        //                     ),
        //                     SizedBox(
        //                       width: double.infinity,
        //                       child: DropdownButtonFormField<String>(
        //                         hint: Text('Select a state'),
        //                         decoration: InputDecoration(
        //                           contentPadding:
        //                           EdgeInsets.symmetric(horizontal: 20),
        //                           focusedBorder: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Colors.black)),
        //                           border: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Color(0xFFD0D1D2))),
        //                         ),
        //                         focusColor: AppsColors.highlightedColor,
        //                         value: state,
        //                         icon: const Icon(
        //                           Icons.arrow_drop_down,
        //                         ),
        //                         iconSize: 24,
        //                         elevation: 3,
        //                         validator: (value) {
        //                           if (value == null || value.isEmpty) {
        //                             return 'Select a state';
        //                           } else if (value == 'Select a state') {
        //                             return 'Select a state';
        //                           } else {
        //                             return null;
        //                           }
        //                         },
        //                         //underline: SizedBox(),
        //                         onChanged: (newValue) {
        //                           setState(() {
        //                             state = newValue;
        //                             for (var i = 0;
        //                             i < tempStateModel.length;
        //                             i++) {
        //                               if (newValue == tempStateModel[i].state) {
        //                                 statePk = tempStateModel[i].state_pk;
        //                               }
        //                             }
        //                           });
        //                         },
        //                         items: states.map<DropdownMenuItem<String>>(
        //                                 (String value) {
        //                               return DropdownMenuItem<String>(
        //                                 value: value,
        //                                 child: Text(value),
        //                               );
        //                             }).toList(),
        //                       ),
        //                     ),
        //                     SizedBox(
        //                       height: 16,
        //                     ),
        //                     SizedBox(
        //                       width: double.infinity,
        //                       child: TextFormField(
        //                         enabled: false,
        //                         initialValue: 'Malaysia',
        //                         validator: validationCountry,
        //                         onSaved: (val) {
        //                           setState(() {
        //                             country = val;
        //                           });
        //                         },
        //                         decoration: InputDecoration(
        //                           labelText: 'Country',
        //                           contentPadding:
        //                           EdgeInsets.symmetric(horizontal: 20),
        //                           focusedBorder: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Colors.black)),
        //                           border: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Color(0xFFD0D1D2))),
        //                         ),
        //                       ),
        //                     ),
        //                     SizedBox(
        //                       height: 16,
        //                     ),
        //                     SizedBox(
        //                       width: double.infinity,
        //                       child: TextFormField(
        //                         validator: validationMobile,
        //                         textInputAction: TextInputAction.done,
        //                         maxLength: 10,
        //                         onSaved: (String val) {
        //                           mobile = val;
        //                         },
        //                         keyboardType: TextInputType.number,
        //                         decoration: InputDecoration(
        //                           contentPadding:
        //                           EdgeInsets.symmetric(horizontal: 20),
        //                           hintText: 'Mobile No',
        //                           labelText: 'Mobile No',
        //                           focusedBorder: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Colors.black)),
        //                           border: OutlineInputBorder(
        //                               borderRadius: BorderRadius.circular(2),
        //                               borderSide:
        //                               BorderSide(color: Color(0xFFD0D1D2))),
        //                         ),
        //                       ),
        //                     ),
        //                     SizedBox(
        //                       height: 16,
        //                     ),
        //                     // Padding(
        //                     //   padding: const EdgeInsets.symmetric(vertical: 0),
        //                     //   child: Row(
        //                     //     children: [
        //                     //       Checkbox(
        //                     //           value: isKeepEmail,
        //                     //           activeColor: Color(0xFFF68721),
        //                     //           checkColor: Colors.white,
        //                     //           onChanged: (bool value) {
        //                     //             setState(() {
        //                     //               isKeepEmail = value;
        //                     //             });
        //                     //           }),
        //                     //       SizedBox(
        //                     //         width: 0,
        //                     //       ),
        //                     //       Expanded(
        //                     //           child: Text(
        //                     //             'Keep me up to date on news and exclusive offers',
        //                     //             style: TextStyle(fontSize: 14, color: Colors.black87),
        //                     //           ))
        //                     //     ],
        //                     //   ),
        //                     // ),
        //                     // SizedBox(
        //                     //   width: double.infinity,
        //                     //   child: Container(
        //                     //     width: double.infinity,
        //                     //     height: 50,
        //                     //     child: ElevatedButton(
        //                     //       style: ElevatedButton.styleFrom(
        //                     //           primary: Color(0xFFF68721), shape: StadiumBorder()),
        //                     //       onPressed: () {
        //                     //         if (userId != null) {
        //                     //           if (_addressKey.currentState.validate()) {
        //                     //             _addressKey.currentState.save();
        //                     //             saveBillingAddress();
        //                     //             PaymentPage.isShipping = 1;
        //                     //             Navigator.push(context, PaymentPage.route());
        //                     //           }
        //                     //         } else {
        //                     //           if (_emailKey.currentState.validate() &&
        //                     //               _addressKey.currentState.validate()) {
        //                     //             _emailKey.currentState.save();
        //                     //             _addressKey.currentState.save();
        //                     //
        //                     //             saveBillingAddress();
        //                     //             // Navigator.push(context, ShippingPage.route());
        //                     //             PaymentPage.isShipping = 1;
        //                     //             Navigator.push(context, PaymentPage.route());
        //                     //             //saveAddress();
        //                     //           }
        //                     //         }
        //                     //       },
        //                     //       child: Text('Save Address'),
        //                     //     ),
        //                     //   ),
        //                     // ),
        //                   ],
        //                 ),
        //               ),
        //             ),
        //           );
        //         }
        //       } else if (snapshot.hasError) {
        //         return SliverToBoxAdapter(
        //           child: Center(
        //             child: Text('${snapshot.error.toString()}'),
        //           ),
        //         );
        //       }
        //       return SliverToBoxAdapter(
        //         child: Center(
        //           child: Text(''),
        //         ),
        //       );
        //     })
        SliverLayoutBuilder(
          builder: (BuildContext context, SliverConstraints constraints) {
            if (context.watch<OrderDetailsInfoNotifier>().deliveryMethod == 1) {
              return SliverToBoxAdapter(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 16,
                    ),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16),
                      child: SizedBox(
                        width: double.infinity,
                        child: Text(
                          'Billing Address',
                          style: TextStyle(color: Colors.black87, fontSize: 18),
                        ),
                      ),
                    ),
                    Container(
                      margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                      decoration: BoxDecoration(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(2.0),
                          border: Border.all(color: const Color(0xFFD0D1D2), width: 1)),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          GestureDetector(
                            onTap: () {
                              context.read<OrderDetailsInfoNotifier>().changeSameAsBilling(1);
                            },
                            child: ListTile(
                              leading: Radio(
                                value: 1,
                                groupValue: context.watch<OrderDetailsInfoNotifier>().sameAsBilling,
                                activeColor: AppsColors.highlightedColor,
                                onChanged: (int? value) {
                                  context.read<OrderDetailsInfoNotifier>().changeSameAsBilling(value);
                                },
                              ),
                              title: const Text(
                                'Same as Shipping address',
                                style: TextStyle(color: Colors.black87, fontSize: 16),
                              ),
                            ),
                          ),
                          const Divider(
                            height: 10,
                            thickness: 1,
                          ),
                          GestureDetector(
                            onTap: () {
                              context.read<OrderDetailsInfoNotifier>().changeSameAsBilling(2);
                            },
                            child: ListTile(
                              leading: Radio(
                                value: 2,
                                groupValue: context.watch<OrderDetailsInfoNotifier>().sameAsBilling,
                                activeColor: AppsColors.highlightedColor,
                                onChanged: (int? value) {
                                  context.read<OrderDetailsInfoNotifier>().changeSameAsBilling(value);
                                },
                              ),
                              title: const Text(
                                'Use a different billing address',
                                style: TextStyle(color: Colors.black87, fontSize: 16),
                              ),
                            ),
                          ),
                          const Divider(
                            height: 0,
                            thickness: 1,
                          ),
                          LayoutBuilder(builder:
                              (BuildContext context, BoxConstraints constraints) {
                            if (context.watch<OrderDetailsInfoNotifier>().sameAsBilling == 2) {
                              return Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16),
                                child: Form(
                                  key: _addressKey,
                                  autovalidateMode: AutovalidateMode.always,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const SizedBox(
                                        height: 16,
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: TextFormField(
                                          controller: firstNameController,
                                          validator: validationFirstName,
                                          textInputAction: TextInputAction.next,
                                          onSaved: (String? val) {
                                            firstName = val;
                                          },
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                            contentPadding:
                                            const EdgeInsets.symmetric(horizontal: 20),
                                            hintText: 'First Name',
                                            labelText: 'First Name',
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Colors.black)),
                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Color(0xFFD0D1D2))),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 16,
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: TextFormField(
                                          controller: lastNameController,
                                          validator: validationLastName,
                                          textInputAction: TextInputAction.next,
                                          onSaved: (String? val) {
                                            lastName = val;
                                          },
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                            contentPadding:
                                            const EdgeInsets.symmetric(horizontal: 20),
                                            hintText: 'Last Name',
                                            labelText: 'Last Name',
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Colors.black)),
                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Color(0xFFD0D1D2))),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 16,
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: TextFormField(
                                          controller: addressLine1Controller,
                                          validator: validationAddress,
                                          textInputAction: TextInputAction.next,
                                          onSaved: (String? val) {
                                            address = val;
                                          },
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                            contentPadding:
                                            const EdgeInsets.symmetric(horizontal: 20),
                                            hintText: 'Address',
                                            labelText: 'Address',
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Colors.black)),
                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Color(0xFFD0D1D2))),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 16,
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: TextFormField(
                                          controller: addressLine2Controller,
                                          textInputAction: TextInputAction.next,
                                          onSaved: (val) {
                                            setState(() {
                                              addressLine2 = val;
                                            });
                                          },
                                          decoration: InputDecoration(
                                            contentPadding:
                                            const EdgeInsets.symmetric(horizontal: 20),
                                            hintText: 'Address line 2(Optional)',
                                            labelText: 'Address line 2',
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Colors.black)),
                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Color(0xFFD0D1D2))),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 16,
                                      ),

                                      SizedBox(
                                        child: TypeAheadField(
                                          textFieldConfiguration: TextFieldConfiguration(
                                              controller: _typeAheadController,
                                              autofocus: false,
                                              style: DefaultTextStyle.of(context).style.copyWith(
                                                  fontStyle: FontStyle.italic
                                              ),
                                              decoration: const InputDecoration(
                                                  labelText: 'post code',
                                                  border: OutlineInputBorder()
                                              )
                                          ),
                                          transitionBuilder: (context, suggestionsBox, controller) {
                                            return suggestionsBox;
                                          },
                                          suggestionsCallback: (pattern) async {
                                            return tempPostCodes
                                                .where((item) =>
                                                item!.toLowerCase().startsWith(pattern.toLowerCase()))
                                                .toList();
                                          },
                                          itemBuilder: (context, dynamic suggestion) {
                                            return ListTile(
                                              leading: const Icon(Icons.shopping_cart,size: 20,),
                                              title: Text('$suggestion'),
                                            );
                                          },
                                          onSuggestionSelected: (dynamic suggestion) {
                                            for (var item in tempPostCodeModel) {
                                              if (suggestion.toString().toLowerCase() == item.pocode) {
                                                setState(() {
                                                  _typeAheadController.text = item.pocode!;
                                                  print('${item.pocode}');
                                                  postCode = item.pocode;
                                                  cityPk = item.fcityno;
                                                  statePk = item.fstateno;
                                                  state = item.statename;
                                                  city = item.cityname;
                                                  cityController.text = item.cityname!;
                                                });
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 16,
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: TextFormField(
                                          controller: cityController,
                                          validator: validationCity,
                                          textInputAction: TextInputAction.next,
                                          onSaved: (String? val) {
                                            city = val;
                                          },
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                            contentPadding:
                                            const EdgeInsets.symmetric(horizontal: 20),
                                            hintText: 'City',
                                            labelText: 'City',
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Colors.black)),
                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Color(0xFFD0D1D2))),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 16,
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: DropdownButtonFormField<String>(
                                          hint: const Text('Select a state'),
                                          decoration: InputDecoration(
                                            contentPadding:
                                            const EdgeInsets.symmetric(horizontal: 20),
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Colors.black)),
                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Color(0xFFD0D1D2))),
                                          ),
                                          focusColor: AppsColors.highlightedColor,
                                          value: state,
                                          icon: const Icon(
                                            Icons.arrow_drop_down,
                                          ),
                                          iconSize: 24,
                                          elevation: 3,
                                          validator: (value) {
                                            if (value == null || value.isEmpty) {
                                              return 'Select a state';
                                            } else if (value == 'Select a state') {
                                              return 'Select a state';
                                            } else {
                                              return null;
                                            }
                                          },
                                          //underline: SizedBox(),
                                          onChanged: (newValue) {
                                            setState(() {
                                              state = newValue;
                                              for (var i = 0;
                                              i < tempStateModel.length;
                                              i++) {
                                                if (newValue == tempStateModel[i].state) {
                                                  statePk = tempStateModel[i].state_pk;
                                                }
                                              }
                                            });
                                          },
                                          items: states.map<DropdownMenuItem<String>>(
                                                  (String? value) {
                                                return DropdownMenuItem<String>(
                                                  value: value,
                                                  child: Text(value!),
                                                );
                                              }).toList(),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 16,
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: TextFormField(
                                          enabled: false,
                                          initialValue: 'Malaysia',
                                          validator: validationCountry,
                                          onSaved: (val) {
                                            setState(() {
                                              country = val;
                                            });
                                          },
                                          decoration: InputDecoration(
                                            labelText: 'Country',
                                            contentPadding:
                                            const EdgeInsets.symmetric(horizontal: 20),
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Colors.black)),
                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Color(0xFFD0D1D2))),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 16,
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: TextFormField(
                                          controller: mobileController,
                                          validator: validationMobile,
                                          textInputAction: TextInputAction.done,
                                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                                          maxLength: 10,
                                          onSaved: (String? val) {
                                            mobile = val;
                                          },
                                          keyboardType: TextInputType.number,
                                          decoration: InputDecoration(
                                            contentPadding:
                                            const EdgeInsets.symmetric(horizontal: 20),
                                            hintText: 'Mobile No',
                                            labelText: 'Mobile No',
                                            prefix: const Text('+60 '),
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Colors.black)),
                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(2),
                                                borderSide:
                                                const BorderSide(color: Color(0xFFD0D1D2))),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 16,
                                      ),
                                      // Padding(
                                      //   padding: const EdgeInsets.symmetric(vertical: 0),
                                      //   child: Row(
                                      //     children: [
                                      //       Checkbox(
                                      //           value: isKeepEmail,
                                      //           activeColor: Color(0xFFF68721),
                                      //           checkColor: Colors.white,
                                      //           onChanged: (bool value) {
                                      //             setState(() {
                                      //               isKeepEmail = value;
                                      //             });
                                      //           }),
                                      //       SizedBox(
                                      //         width: 0,
                                      //       ),
                                      //       Expanded(
                                      //           child: Text(
                                      //             'Keep me up to date on news and exclusive offers',
                                      //             style: TextStyle(fontSize: 14, color: Colors.black87),
                                      //           ))
                                      //     ],
                                      //   ),
                                      // ),
                                      // SizedBox(
                                      //   width: double.infinity,
                                      //   child: Container(
                                      //     width: double.infinity,
                                      //     height: 50,
                                      //     child: ElevatedButton(
                                      //       style: ElevatedButton.styleFrom(
                                      //           primary: Color(0xFFF68721), shape: StadiumBorder()),
                                      //       onPressed: () {
                                      //         if (userId != null) {
                                      //           if (_addressKey.currentState.validate()) {
                                      //             _addressKey.currentState.save();
                                      //             saveBillingAddress();
                                      //             PaymentPage.isShipping = 1;
                                      //             Navigator.push(context, PaymentPage.route());
                                      //           }
                                      //         } else {
                                      //           if (_emailKey.currentState.validate() &&
                                      //               _addressKey.currentState.validate()) {
                                      //             _emailKey.currentState.save();
                                      //             _addressKey.currentState.save();
                                      //
                                      //             saveBillingAddress();
                                      //             // Navigator.push(context, ShippingPage.route());
                                      //             PaymentPage.isShipping = 1;
                                      //             Navigator.push(context, PaymentPage.route());
                                      //             //saveAddress();
                                      //           }
                                      //         }
                                      //       },
                                      //       child: Text('Save Address'),
                                      //     ),
                                      //   ),
                                      // ),
                                    ],
                                  ),
                                ),
                              );
                            } else {
                              return Container(
                                height: 0,
                              );
                            }
                          }),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }else if (context.watch<OrderDetailsInfoNotifier>().deliveryMethod == 0) {
              return const SliverToBoxAdapter(
                child: SizedBox(
                  height: 2,
                ),
              );
            }
            return const SliverToBoxAdapter(
              child: Text(''),
            );
          }
        ),

        /// ............... pickup location Container .............
        SliverLayoutBuilder(
            builder: (BuildContext context, SliverConstraints constraints) {
          if (context.watch<OrderDetailsInfoNotifier>().deliveryMethod == 1) {
            return const SliverToBoxAdapter(
              child: SizedBox(
                height: 2,
              ),
            );
          } else if (context.watch<OrderDetailsInfoNotifier>().deliveryMethod == 0) {
            return SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                      height: 20,
                    ),
                    const SizedBox(
                        width: double.infinity,
                        child: Text(
                          'Pickup Location',
                          style: TextStyle(color: Colors.black87, fontSize: 18),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(2.0),
                            border: Border.all(
                                color: const Color(0xFFD0D1D2), width: 1.0)),
                        child: ListTile(
                          horizontalTitleGap: 0,
                          // leading: Icon(Icons.circle,size: 16,color: AppsColors.buttonColor,),
                          trailing: Text(
                            'Free',
                            style: TextStyle(
                                fontSize: 14, color: AppsColors.highlightedColor),
                          ),
                          title: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: const [
                              Text(
                                'Azura Mart',
                                style: TextStyle(
                                    color: Colors.black87,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500),
                              ),
                              SizedBox(
                                width: double.infinity,
                                child: Text(
                                  'No. 8 Pintas Tuna 3 \nSeberang Jaya \nPerai 13700 \nPulau Pinang',
                                  style: TextStyle(
                                      color: Colors.black54, fontSize: 16),
                                ),
                              ),
                              Text(
                                'Usually Ready in 1 hour',
                                style: TextStyle(
                                    color: Colors.black54, fontSize: 16),
                              ),
                            ],
                          ),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            );
          }
          return const SliverToBoxAdapter(
            child: SizedBox(height: 0,),
          );
        }),

        /// .............. SizeBox height .........................
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 20,
          ),
        ),

        /// .................... submit button..................
        SliverToBoxAdapter(
          child: SizedBox(
              width: double.infinity,
              child: Container(
                width: double.infinity,
                height: 50,
                margin:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 6.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: AppsColors.buttonColor, shape: StadiumBorder()),
                  onPressed: () {
                    if (userId != null) {
                      if (Provider.of<OrderDetailsInfoNotifier>(context, listen: false).deliveryMethod == 0) {
                        if (_addressKey.currentState!.validate()) {
                          _addressKey.currentState!.save();
                          saveAddressInLocal(1);
                          // saveBillingAddress();
                          saveShippingAddress(1);
                          SharedPreferenceUtils.isShipping = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).deliveryMethod;
                          Navigator.push(context, PaymentPage.route());
                        }
                      }  else {
                        if (Provider.of<OrderDetailsInfoNotifier>(context, listen: false).sameAsBilling == 1) {
                          if (_addressKeyS.currentState!.validate()) {
                            _addressKeyS.currentState!.save();
                            saveAddressInLocal(2);
                            // saveBillingAddress();
                            saveShippingAddress(2);
                            SharedPreferenceUtils.isShipping = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).deliveryMethod;
                            Navigator.push(context, PaymentPage.route());
                          }
                        } else {
                          if (_addressKey.currentState!.validate() && _addressKeyS.currentState!.validate()) {
                            _addressKeyS.currentState!.save();
                            _addressKey.currentState!.save();
                            saveAddressInLocal(3);
                            // saveBillingAddress();
                            saveShippingAddress(3);
                            SharedPreferenceUtils.isShipping = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).deliveryMethod;
                            Navigator.push(context, PaymentPage.route());
                          }
                        }
                      }
                    } else {
                      if (Provider.of<OrderDetailsInfoNotifier>(context, listen: false).deliveryMethod == 0) {
                        if (_emailKey.currentState!.validate() && _addressKey.currentState!.validate()) {
                          _addressKey.currentState!.save();
                          _emailKey.currentState!.save();
                          saveAddressInLocal(1);
                          // saveBillingAddress();
                          saveShippingAddress(1);
                          SharedPreferenceUtils.password = password;
                          SharedPreferenceUtils.isShipping = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).deliveryMethod;
                          Navigator.push(context, PaymentPage.route());
                        }
                      }  else {
                        if (Provider.of<OrderDetailsInfoNotifier>(context, listen: false).sameAsBilling == 1) {
                          if (_emailKey.currentState!.validate() && _addressKeyS.currentState!.validate()) {
                            _addressKeyS.currentState!.save();
                            _emailKey.currentState!.save();
                            saveAddressInLocal(2);
                            // saveBillingAddress();
                            saveShippingAddress(2);
                            SharedPreferenceUtils.password = password;
                            SharedPreferenceUtils.isShipping = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).deliveryMethod;
                            Navigator.push(context, PaymentPage.route());
                          }
                        } else {
                          if (_emailKey.currentState!.validate() && _addressKey.currentState!.validate() && _addressKeyS.currentState!.validate()) {
                            _addressKeyS.currentState!.save();
                            _addressKey.currentState!.save();
                            _emailKey.currentState!.save();
                            saveAddressInLocal(3);
                            // saveBillingAddress();
                            saveShippingAddress(3);
                            SharedPreferenceUtils.password = password;
                            SharedPreferenceUtils.isShipping = Provider.of<OrderDetailsInfoNotifier>(context, listen: false).deliveryMethod;
                            Navigator.push(context, PaymentPage.route());
                          }
                        }
                      }
                    }
                  },
                  child: const Text('Continue to payment',style: TextStyle(color: Colors.white),),
                ),
              )),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 50,
          ),
        )
      ],
    );
  }
}

/// ............... Bundle Product .....................
class OrderSummeryBundleProduct extends StatelessWidget {
  final AsyncSnapshot<CartModel> snapshot;
  final int index;
  final int i;
  final int productIndex;
  final paymentRG;
  const OrderSummeryBundleProduct(this.snapshot,this.i, this.index,this.productIndex,this.paymentRG);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        horizontalTitleGap: 4,
        title: SizedBox(
          width: double.infinity,
          child: Text(
            '${snapshot.data!.data!.bundle![i][index].bundleBreakdown![productIndex].prdVarinatName}',
            maxLines: 3,
            style: const TextStyle(
                color: Colors.black87,
                fontWeight: FontWeight.w500,
                fontSize: 15),
          ),
        ),
        leading: Stack(
          clipBehavior: Clip.none,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(2.0),
              child: Container(
                height: 60,
                width: 60,
                child: Center(
                  child: CacheImageProvide(url: snapshot.data!.data!.bundle![i][index].bundleBreakdown![productIndex].prdVariantImagePath,)
                ),
              ),
            ),
            Positioned(
                right: -5,
                top: -5,
                child: Container(
                  height: 16,
                  width: 16,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.0),
                      color: Colors.black54.withOpacity(0.6)),
                  child: Center(
                    child: Text(
                      '${snapshot.data!.data!.bundle![i][index].bundleBreakdown![productIndex].variantCount}',
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w600),
                    ),
                  ),
                )),
          ],
        ),
        trailing: Text(
          'RM${snapshot.data!.data!.bundle![i][index].bundleBreakdown![productIndex].currentRegularPrice!.toStringAsFixed(2)}',
          style: const TextStyle(
              color: Colors.black87, fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
/// ............... Non Bundle Product .....................
class OrderSummeryNonBundleProduct extends StatelessWidget {
  final AsyncSnapshot<CartModel> snapshot;
  final int index;
  final int i;
  final int paymentRG;
  const OrderSummeryNonBundleProduct(this.snapshot,this.i, this.index,this.paymentRG);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        horizontalTitleGap: 4,
        title: SizedBox(
          width: double.infinity,
          child: Text(
            '${snapshot.data!.data!.nonBundle![i][index].prdVarinatName}',
            maxLines: 3,
            style: const TextStyle(
                color: Colors.black87,
                fontWeight: FontWeight.w500,
                fontSize: 15),
          ),
        ),
        leading: Stack(
          clipBehavior: Clip.none,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(2.0),
              child: SizedBox(
                height: 60,
                width: 60,
                child: Center(
                    child: CacheImageProvide(url: snapshot.data!.data!.nonBundle![i][index].prdVariantImagePath,)
                ),
              ),
            ),
            Positioned(
                right: -5,
                top: -5,
                child: Container(
                  height: 16,
                  width: 16,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.0),
                      color: Colors.black54.withOpacity(0.6)),
                  child: Center(
                    child: Text(
                      '${snapshot.data!.data!.nonBundle![i][index].itemQty}',
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w600),
                    ),
                  ),
                )),
          ],
        ),
        trailing: Text(
          'RM${snapshot.data!.data!.nonBundle![i][index].currentRegularPrice!.toStringAsFixed(2)}',
          style: const TextStyle(
              color: Colors.black87, fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
/// ............... Cart Product .....................
class OrderSummeryCartProduct extends StatelessWidget {
  final AsyncSnapshot<CartModel> snapshot;
  final int index;
  final int paymentRG;
  const OrderSummeryCartProduct(this.snapshot,this.index,this.paymentRG);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        horizontalTitleGap: 4,
        title: SizedBox(
          width: double.infinity,
          child: Text(
            '${snapshot.data!.data!.cart![index].products!.variantName}',
            maxLines: 3,
            style: const TextStyle(
                color: Colors.black87,
                fontWeight: FontWeight.w500,
                fontSize: 15),
          ),
        ),
        leading: Stack(
          clipBehavior: Clip.none,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(6.0),
              child: Container(
                height: 60,
                width: 60,
                child: Center(
                    child: CacheImageProvide(url: snapshot.data!.data!.cart![index].products!.primaryImgRelativePath,)
                ),
              ),
            ),
            Positioned(
                right: -5,
                top: -5,
                child: Container(
                  height: 16,
                  width: 16,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4.0),
                      color: Colors.black54.withOpacity(0.6)),
                  child: Center(
                    child: Text(
                      '${snapshot.data!.data!.cart![index].totalItemQty}',
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w600),
                    ),
                  ),
                )),
          ],
        ),
        trailing: Text(
          paymentRG == 3
              ? 'RM${snapshot.data!.data!.cart![index].installmentPrice!.toStringAsFixed(2)}'
              : 'RM${snapshot.data!.data!.cart![index].regularPrice!.toStringAsFixed(2)}',
          style: const TextStyle(
              color: Colors.black87, fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
