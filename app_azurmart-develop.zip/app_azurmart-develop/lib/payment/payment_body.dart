import 'package:flutter/material.dart';

class PaymentBody extends StatelessWidget {
  const PaymentBody({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.infinity,
      width: double.infinity,
      margin: const EdgeInsets.only(left: 20, right: 20, bottom: 20),
      decoration: const BoxDecoration(
          borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(3), bottomRight: Radius.circular(3)),
          color: Colors.white),
      child: const CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          SliverToBoxAdapter(
            child: PaymentWithPayPal(),
          ),
          SliverToBoxAdapter(
            child: CashOnDelivery(),
          ),
          SliverToBoxAdapter(
            child: PaymentDetail(),
          )
        ],
      ),
    );
  }
}

class PaymentWithPayPal extends StatelessWidget {
  const PaymentWithPayPal({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('PayPal')));
      },
      child: Container(
        width: double.infinity,
        height: 40,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        margin: const EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 10),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(3),
            color: Colors.transparent,
            border: Border.all(color: const Color(0xFFF4F4F4), width: 2)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: const [
            Icon(
              Icons.payment,
              color: Colors.black87,
              size: 24,
            ),
            SizedBox(
              width: 16,
            ),
            Text(
              'PayPal',
              style: TextStyle(color: Colors.black87, fontSize: 14),
            )
          ],
        ),
      ),
    );
  }
}

class CashOnDelivery extends StatelessWidget {
  const CashOnDelivery({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Cash On Delivery')));
      },
      child: Container(
        width: double.infinity,
        height: 40,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        margin: const EdgeInsets.only(left: 20, right: 20, top: 0, bottom: 10),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(3),
            color: Colors.transparent,
            border: Border.all(color: const Color(0xFFF4F4F4), width: 2)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: const [
            Icon(
              Icons.money,
              color: Colors.black87,
              size: 24,
            ),
            SizedBox(
              width: 16,
            ),
            Text(
              'Cash On Delivery',
              style: TextStyle(color: Colors.black87, fontSize: 14),
            )
          ],
        ),
      ),
    );
  }
}

class PaymentDetail extends StatelessWidget {
  const PaymentDetail({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Flexible(
        child: Container(
      width: double.infinity,
      margin: const EdgeInsets.only(left: 20, right: 20, top: 10, bottom: 10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(3),
          color: Colors.transparent,
          border: Border.all(color: const Color(0xFFF4F4F4), width: 2)),
      child: Column(
        children: [
          const SizedBox(
            width: double.infinity,
            child: Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                'Payment Detail',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.black87),
              ),
            ),
          ),
          const SizedBox(
            width: double.infinity,
            child: Divider(
              color: Color(0xFFF4F4F4),
              thickness: 2,
            ),
          ),
          SizedBox(
            width: double.infinity,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: RichText(
                text: const TextSpan(
                  text: 'Offers - ',
                  style: TextStyle(color: Colors.black54, fontSize: 11),
                  children: <TextSpan>[
                    TextSpan(
                      text: '0',style: TextStyle(color: Colors.black, fontSize: 13),
                    )
                  ]
                ),
              ),
            ),
          ),
          SizedBox(
            width: double.infinity,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: RichText(
                text: const TextSpan(
                    text: 'Shipping Charges - ',
                    style: TextStyle(color: Colors.black54, fontSize: 11),
                    children: <TextSpan>[
                      TextSpan(
                        text: '\$0',style: TextStyle(color: Colors.green, fontSize: 13),
                      )
                    ]
                ),
              ),
            ),
          ),
          const SizedBox(
            width: double.infinity,
            child: Divider(
              color: Color(0xFFF4F4F4),
              thickness: 2,
            ),
          ),
          SizedBox(
            width: double.infinity,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: RichText(
                text: const TextSpan(
                    text: 'Shipping Charges - ',
                    style: TextStyle(color: Colors.black87, fontSize: 12),
                    children: <TextSpan>[
                      TextSpan(
                        text: '\$100',style: TextStyle(color: Colors.red, fontSize: 14),
                      )
                    ]
                ),
              ),
            ),
          ),
        ],
      ),
    ));
  }
}
