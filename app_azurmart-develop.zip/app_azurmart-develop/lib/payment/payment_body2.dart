import 'dart:convert';
import 'dart:io';
import 'package:azuramartmy/billplz/redirect_url.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/login/UserModel.dart';
import 'package:azuramartmy/my_bloc/cart_bloc.dart';
import 'package:azuramartmy/order_summery_info/order_details_info_notifier.dart';
import 'package:azuramartmy/order_summery_info/order_summery_info_body.dart';
import 'package:azuramartmy/provider_models/cart_model.dart';
import 'package:azuramartmy/provider_models/post_code_model.dart';
import 'package:azuramartmy/provider_models/temp_post_code_model.dart';
import 'package:azuramartmy/provider_models/temp_state_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:expandable/expandable.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:http/http.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PaymentBody2 extends StatefulWidget {
  const PaymentBody2({Key? key}) : super(key: key);

  @override
  _PaymentBody2State createState() => _PaymentBody2State();
}

class _PaymentBody2State extends State<PaymentBody2> {
  final f = DateFormat('dd-MMM-yyyy');
  double totalPrice = 0;
  double totalPriceIns = 0;
  int downPrice = 0;
  int first3Ins = 0;
  int second3Ins = 0;
  int third3Ins = 0;

  int? paymentRG = 1;
  String? specialNote;
  var specialNoteController = TextEditingController();

  //............................................
  List<TempPostCodeModel> tempPostCodeModel = [];
  List<TempStateModel> tempStateModel = [];
  TextEditingController autoCompleteController = TextEditingController();
  TextEditingController cityController = TextEditingController();

  double postage = 0;

  List<String?> states = [];
  List<String> cities = [];
  int? statePk;
  int? cityPk;

  String? email;
  String? firstNameS;
  String? lastNameS;
  String? addressS;
  String? postCodeS;
  String? mobileS;
  String? apartmentS;
  String? cityS;
  String? stateS;
  int? statePkS;
  int? cityPkS;

  //......................................................
  void getPostCode() async {
    Client client = Client();
    Uri url = Uri.parse('${Urls.baseUrl}${Urls.POST_CODE}');
    try {
      final response = await client.post(url);
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        PostCodeModel postCodeModel = PostCodeModel.fromJson(body);
        states.add('Select a state');
        for (var i = 0; i < postCodeModel.data!.length; i++) {
          int m = 0;
          TempPostCodeModel temp = TempPostCodeModel(
              postCodeModel.data![i].pocode,
              postCodeModel.data![i].fcityno,
              postCodeModel.data![i].cityname,
              postCodeModel.data![i].statename,
              postCodeModel.data![i].fstateno);
          tempPostCodeModel.add(temp);
          for (var x = 0; x < states.length; x++) {
            if (states[x] == postCodeModel.data![i].statename) {
              m = 1;
            }
          }
          if (m == 0) {
            states.add(postCodeModel.data![i].statename);
            TempStateModel temp = TempStateModel(
                postCodeModel.data![i].statename,
                postCodeModel.data![i].fstateno);
            tempStateModel.add(temp);
          }
        }
      }
    } on Exception catch (e) {
      print(e);
    }
  }

  void getEmail() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    email = localStorage.getString(SharedPreferenceUtils.EMAIL);
  }

  void getAllData() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    email = localStorage.getString(SharedPreferenceUtils.EMAIL);
    firstNameS = localStorage.getString(SharedPreferenceUtils.FIRSTNAME);
    lastNameS = localStorage.getString(SharedPreferenceUtils.LASTNAME);
    addressS = localStorage.getString(SharedPreferenceUtils.ADDRESS);
    apartmentS = localStorage.getString(SharedPreferenceUtils.APARTMENT);
    cityS = localStorage.getString(SharedPreferenceUtils.CITY);
    stateS = localStorage.getString(SharedPreferenceUtils.STATE);
    mobileS = localStorage.getString(SharedPreferenceUtils.MOBILE);
    postCodeS = localStorage.getString(SharedPreferenceUtils.POSTCODE);
    statePkS = localStorage.getInt(SharedPreferenceUtils.STATEPK);
    cityPkS = localStorage.getInt(SharedPreferenceUtils.CITYPK);
  }

  final GlobalKey<FormState> _azura3InsFormKey = GlobalKey<FormState>();
  final TextEditingController _down3PaymentTextController =
      TextEditingController();
  final TextEditingController _first3PaymentTextController =
      TextEditingController();
  final TextEditingController _second3PaymentTextController =
      TextEditingController();
  final TextEditingController _third3PaymentTextController =
      TextEditingController();

  /// .............. 6 installment variables .................
  final GlobalKey<FormState> _azura6InsFormKey = GlobalKey<FormState>();
  final TextEditingController _down6PaymentTextController =
      TextEditingController();
  final TextEditingController _first6PaymentTextController =
      TextEditingController();
  final TextEditingController _second6PaymentTextController =
      TextEditingController();
  final TextEditingController _third6PaymentTextController =
      TextEditingController();
  final TextEditingController _forth6PaymentTextController =
      TextEditingController();
  final TextEditingController _fifth6PaymentTextController =
      TextEditingController();
  final TextEditingController _sixth6PaymentTextController =
      TextEditingController();

  String? validationDownPayment(String? payment) {
    if (payment!.isNotEmpty || payment != '') {
      int newPayment = int.parse(payment);
      if ((totalPrice * 0.2) > newPayment) {
        return 'Enter minimum 20% of Amount';
      } else if (newPayment > totalPrice) {
        return 'Enter less than of Amount';
      } else {
        return null;
      }
    } else {
      return 'empty';
    }
  }

  String? validationInstallmentDownPayment(String? payment) {
    if (payment!.isNotEmpty || payment != '') {
      int newPayment = int.parse(payment);
      if ((totalPriceIns * 0.2) > newPayment) {
        return 'Enter minimum 20% of Amount';
      } else if (newPayment > totalPriceIns) {
        return 'Enter less than of Amount';
      } else {
        return null;
      }
    } else {
      return 'empty';
    }
  }

  List<int> getInsPayment(int insCount, double totalPrice, int downPayment) {
    List<int> values = [];
    double spareAmount = totalPrice - downPayment;
    int insAmount = (spareAmount / insCount).floor();
    for (var i = 1; i < insCount; i++) {
      values.add(insAmount);
    }
    double x = totalPrice - ((insAmount * insCount) + downPayment);
    values.add((x.ceil()) + insAmount);

    return values;
  }

  @override
  void initState() {
    cartBloc.fetchAllCarts();
    totalPrice = SharedPreferenceUtils.postcodeSP >= 87000
        ? SharedPreferenceUtils.totalPrice! +
            SharedPreferenceUtils.postageCostSS!
        : SharedPreferenceUtils.totalPrice! +
            SharedPreferenceUtils.postageCostSM!;
    totalPriceIns = SharedPreferenceUtils.postcodeSP >= 87000
        ? SharedPreferenceUtils.totalInsPrice! +
            SharedPreferenceUtils.postageCostSS!
        : SharedPreferenceUtils.totalInsPrice! +
            SharedPreferenceUtils.postageCostSM!;
    _down3PaymentTextController.text = (totalPrice * 0.2).ceil().toString();
    _down6PaymentTextController.text = (totalPriceIns * 0.2).ceil().toString();
    List<int> insPayment3 = getInsPayment(
        3, totalPrice, int.parse(_down3PaymentTextController.text));
    _first3PaymentTextController.text = insPayment3[0].toString();
    _second3PaymentTextController.text = insPayment3[1].toString();
    _third3PaymentTextController.text = insPayment3[2].toString();

    List<int> insPayment6 = getInsPayment(
        6, totalPriceIns, int.parse(_down6PaymentTextController.text));
    _first6PaymentTextController.text = insPayment6[0].toString();
    _second6PaymentTextController.text = insPayment6[1].toString();
    _third6PaymentTextController.text = insPayment6[2].toString();
    _forth6PaymentTextController.text = insPayment6[3].toString();
    _fifth6PaymentTextController.text = insPayment6[4].toString();
    _sixth6PaymentTextController.text = insPayment6[5].toString();

    specialNoteController.text = '';

    getEmail();
    super.initState();
  }

  // full data double quotation er moddhe jabe
  // payment_method 1 hole down_payment 0 hobe
  // url name: make-order
  // is_shipping 1 hole shipping 2 hole self-collect
  // payment_method 1 = billPlz,
  //  2 = 3 installment azura mart,
  // 3 = 6 installment azuramart
  Future<void> makeOrder() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    int? pkNo = Provider.of<OrderDetailsInfoNotifier>(context, listen: false)
        .addressPkNo;
    int? differentBilling =
        Provider.of<OrderDetailsInfoNotifier>(context, listen: false)
            .sameAsBilling;
    Client client = Client();

    var requestJson = {};
    requestJson["session"] = session;
    requestJson["token"] = token;
    requestJson["user_id"] = userId;
    requestJson["special_note"] = specialNote;
    requestJson["address_pk_no"] = pkNo;
    requestJson["billing_address"] = SharedPreferenceUtils.billingAddress;
    requestJson["shipping_address"] = SharedPreferenceUtils.shippingAddress;
    requestJson["is_shipping"] = SharedPreferenceUtils.isShipping;
    requestJson["password"] = SharedPreferenceUtils.password;
    requestJson["payment_method"] = paymentRG;
    requestJson["down_payment"] = downPrice;
    requestJson["coupon_code"] = couponCode;
    requestJson["different_billing"] = differentBilling;

    var requestBody = json.encode(requestJson);

    print('........................' + requestBody + '.......................');

    try {
      final url = Uri.parse(Urls.baseUrl + Urls.MAKE_ORDER);
      print('url');
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      Provider.of<OrderDetailsInfoNotifier>(context, listen: false)
          .changePressValue(0);
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      Common.toastMsg('${body["message"]}');
      if (body["status"] == 1) {
        UserModel userModel = UserModel.fromJson(body);
        print(userModel.message);
        SharedPreferences localStorage = await SharedPreferences.getInstance();
        localStorage.setString(
            SharedPreferenceUtils.TOKEN, userModel.data!.token!);
        localStorage.setInt(
            SharedPreferenceUtils.USER_ID, userModel.data!.authId!);
        localStorage.setString(
            SharedPreferenceUtils.USER_NAME, userModel.data!.userName!);
        localStorage.setString(SharedPreferenceUtils.LAST_NAME,
            userModel.data!.lastName != null ? userModel.data!.lastName! : "");
        localStorage.setString(
            SharedPreferenceUtils.EMAIL, userModel.data!.email!);
        localStorage.setString(SharedPreferenceUtils.MOBILE,
            userModel.data!.mobileNo != null ? userModel.data!.mobileNo! : "");
        // localStorage.setInt(SharedPreferenceUtils.ROLE_ID, userModel.data.roleId);
        // localStorage.setInt(SharedPreferenceUtils.LOCATION, userModel.data.userLocation);

        SharedPreferenceUtils.userIdF = userModel.data!.authId;
        SharedPreferenceUtils.usernameF = userModel.data!.userName;
        SharedPreferenceUtils.lastNameF = userModel.data!.lastName;
        SharedPreferenceUtils.mobileF = userModel.data!.mobileNo;
        SharedPreferenceUtils.emailF = userModel.data!.email;

        SharedPreferenceUtils.postageCostSM = 0;
        SharedPreferenceUtils.postageCostSS = 0;
        SharedPreferenceUtils.totalPrice = 0;
        SharedPreferenceUtils.totalInsPrice = 0;

        Common.toastMsg('Redirecting...');

        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => RedirectUrl(
                      redirectUrl: userModel.description,
                    )));
      }
    } on FormatException catch (e) {
      print(e);
      Provider.of<OrderDetailsInfoNotifier>(context, listen: false)
          .changePressValue(0);
      Common.toastMsg(e.toString());
    } on Exception catch (e) {
      print(e);
      Provider.of<OrderDetailsInfoNotifier>(context, listen: false)
          .changePressValue(0);
      Common.toastMsg(e.toString());
    }
  }

  final GlobalKey<FormState> _couponFormKey = GlobalKey<FormState>();
  final TextEditingController _couponController = TextEditingController();
  int isCouponApplied = 0;
  int couponPercentage = 0;
  int couponAmount = 0;
  String? couponCode = '';
  int couponType = 1;
  bool isLoading = false;
  String? validationCouponCode(String? value) {
    if (value == null || value.isEmpty) {
      return 'Enter Coupon Code!';
    } else {
      return null;
    }
  }
  Future<void> applyCoupon() async {
    Client client = Client();
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Uri url = Uri.parse(Urls.baseUrl + Urls.applyCoupon);
    print('$session/$userId/$token/$couponCode');
    try {
      var response = await client.post(url, body: {
        'session': '$session',
        'user_id': '$userId',
        'token': '$token',
        'coupon_code': couponCode,
      });
      setState(() {
        isLoading = false;
      });
      print(response.body);
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        Common.toastMsg('${body["message"]}');
        if(body["status"] == 1){
          setState(() {
            isCouponApplied = 1;
            paymentRG = 1;
            couponPercentage = body["data"]["discount_percent"];
            couponAmount = body["data"]["discount_amount"];
            couponType = body["data"]["coupon_type"];
          });
        }
      } else {
        throw Exception('Failed to load post');
      }
    } on Exception catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      scrollDirection: Axis.vertical,
      slivers: [
        /// ................. Cart Product .................
        StreamBuilder(
            stream: cartBloc.allCarts,
            builder: (context, AsyncSnapshot<CartModel> snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!.data!.bundle!.isNotEmpty ||
                    snapshot.data!.data!.nonBundle!.isNotEmpty ||
                    snapshot.data!.data!.cart!.isNotEmpty) {
                  return SliverToBoxAdapter(
                    child: ExpandablePanel(
                      collapsed: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 20),
                        child: Text(snapshot.data!.data!.cartQtyCount > 1
                            ? '${snapshot.data!.data!.cartQtyCount} Items in your cart'
                            : '${snapshot.data!.data!.cartQtyCount} Item in your cart'),
                      ),
                      theme: const ExpandableThemeData(
                        iconColor: Colors.black87,
                        tapHeaderToExpand: true,
                        useInkWell: true,
                      ),
                      header: ListTile(
                        tileColor: Colors.transparent,
                        leading: const Icon(
                          Icons.shopping_cart_outlined,
                          color: Colors.black87,
                          size: 24,
                        ),
                        trailing: Text(
                          paymentRG == 3
                              ? 'RM${(totalPriceIns - couponAmount).toStringAsFixed(2)}'
                              : 'RM${(totalPrice - couponAmount).toStringAsFixed(2)}',
                          style: const TextStyle(
                              color: Colors.black87,
                              fontSize: 16,
                              fontWeight: FontWeight.w600),
                        ),
                        title: const Text(
                          'Show Order Summery',
                          style: TextStyle(color: Colors.black54, fontSize: 14),
                        ),
                      ),
                      expanded: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        width: double.infinity,
                        decoration: const BoxDecoration(
                          color: Color(0xFFF4F4F4),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            /// ...... applying bundle product.......
                            for (int i = 0;
                                i < snapshot.data!.data!.bundle!.length;
                                i++)
                              ...List.generate(
                                  snapshot.data!.data!.bundle![i].length,
                                  (index) => Container(
                                        width: double.infinity,
                                        margin: const EdgeInsets.symmetric(
                                            vertical: 5, horizontal: 8),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(4),
                                            border: Border.all(
                                                width: 1,
                                                color: AppsColors.buttonColor),
                                            color: const Color(0xFFFFFFFF)),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Container(
                                              width: double.infinity,
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      vertical: 8,
                                                      horizontal: 8),
                                              decoration: BoxDecoration(
                                                color: AppsColors.buttonColor,
                                              ),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                children: [
                                                  SizedBox(
                                                    width: double.infinity,
                                                    child: Text(
                                                      '${snapshot.data!.data!.bundle![i][index].bundleNamePublic} for ${snapshot.data!.data!.bundle![i][index].totalRegularBundlePrice}',
                                                      style: const TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.w500),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: double.infinity,
                                                    child: Text(
                                                      'You Saved RM${snapshot.data!.data!.bundle![i][index].totalRegularPrice! - snapshot.data!.data!.bundle![i][index].totalRegularBundlePrice!}',
                                                      style: const TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.w500),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            ...List.generate(
                                                snapshot
                                                    .data!
                                                    .data!
                                                    .bundle![i][index]
                                                    .bundleBreakdown!
                                                    .length,
                                                (productIndex) =>
                                                    OrderSummeryBundleProduct(
                                                        snapshot,
                                                        i,
                                                        index,
                                                        productIndex,
                                                        paymentRG))
                                          ],
                                        ),
                                      )),

                            /// ...... applying Non bundle product.......
                            for (int i = 0;
                                i < snapshot.data!.data!.nonBundle!.length;
                                i++)
                              ...List.generate(
                                  snapshot.data!.data!.nonBundle![i].length,
                                  (index) => OrderSummeryNonBundleProduct(
                                      snapshot, i, index, paymentRG!)),

                            /// ...... applying normal cart product.......
                            ...List.generate(
                                snapshot.data!.data!.cart!.length,
                                (index) => OrderSummeryCartProduct(
                                    snapshot, index, paymentRG!)),

                            // const Divider(
                            //   height: 30,
                            //   thickness: 1,
                            // ),
                            // const SizedBox(
                            //   width: double.infinity,
                            //   child: Text(
                            //     'Promo code / coupon',
                            //     textAlign: TextAlign.start,
                            //     style: TextStyle(
                            //         color: Colors.black87, fontSize: 16),
                            //   ),
                            // ),
                            // const SizedBox(
                            //   height: 16,
                            // ),
                            // Row(
                            //   mainAxisSize: MainAxisSize.max,
                            //   children: [
                            //     Expanded(
                            //       flex: 4,
                            //       child: TextFormField(
                            //         decoration: InputDecoration(
                            //           contentPadding:
                            //               const EdgeInsets.symmetric(
                            //                   horizontal: 20),
                            //           hintText: 'Promo code / coupon',
                            //           fillColor: Colors.white,
                            //           filled: true,
                            //           focusedBorder: OutlineInputBorder(
                            //               borderRadius:
                            //                   BorderRadius.circular(6),
                            //               borderSide: const BorderSide(
                            //                   color: Colors.black)),
                            //           border: OutlineInputBorder(
                            //               borderRadius:
                            //                   BorderRadius.circular(10),
                            //               borderSide: const BorderSide(
                            //                   color: Color(0xFFD0D1D2))),
                            //         ),
                            //       ),
                            //     ),
                            //     const SizedBox(
                            //       width: 8,
                            //     ),
                            //     Expanded(
                            //       flex: 1,
                            //       child: SizedBox(
                            //         height: 45,
                            //         child: ElevatedButton(
                            //           onPressed: () {},
                            //           style: ElevatedButton.styleFrom(
                            //               primary: AppsColors.buttonColor),
                            //           child: const Icon(
                            //             Icons.arrow_forward,
                            //             color: Colors.white,
                            //           ),
                            //         ),
                            //       ),
                            //     )
                            //   ],
                            // ),
                            // const SizedBox(
                            //   height: 16,
                            // ),
                            const Divider(
                              height: 30,
                              thickness: 1,
                            ),
                            Row(
                              children: [
                                const Text(
                                  'Subtotal',
                                  style: TextStyle(fontSize: 16),
                                ),
                                const Spacer(),
                                Text(
                                  paymentRG == 3
                                      ? 'RM${snapshot.data!.data!.totalInsPrice!.toStringAsFixed(2)}'
                                      : 'RM${snapshot.data!.data!.totalPrice.toStringAsFixed(2)}',
                                  style: const TextStyle(
                                      color: Colors.black87,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            Row(
                              children: [
                                Text(
                                  context
                                              .watch<OrderDetailsInfoNotifier>()
                                              .deliveryMethod ==
                                          1
                                      ? 'Shipping'
                                      : 'Pickup',
                                  style: const TextStyle(fontSize: 16),
                                ),
                                const Spacer(),
                                Text(
                                  context
                                              .watch<OrderDetailsInfoNotifier>()
                                              .deliveryMethod ==
                                          1
                                      ? SharedPreferenceUtils.postcodeSP >=
                                              87000
                                          ? 'RM${snapshot.data!.data!.totalSSCost!.toStringAsFixed(2)}'
                                          : 'RM${snapshot.data!.data!.totalSMCost!.toStringAsFixed(2)}'
                                      : 'Free',
                                  style: const TextStyle(
                                      color: Colors.black87, fontSize: 16),
                                ),
                              ],
                            ),
                            /// ........... COUPON ............
                            LayoutBuilder(
                              builder: (BuildContext context, BoxConstraints constraints){
                              if(isCouponApplied == 1){
                                return Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Divider(
                                    height: 30,
                                    thickness: 1,
                                  ),
                                    Row(
                                      children: [
                                        const Text(
                                          'Coupon Discount',
                                          style: TextStyle(fontSize: 16,color: Colors.green),
                                        ),
                                        const Spacer(),
                                        Text('(-)RM$couponAmount',
                                          style: const TextStyle(
                                              color: Colors.green,
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                  ],
                                );
                              }else {
                                return const SizedBox(
                                  height: 0,
                                );
                              }
                              }
                            ),

                            const Divider(
                              height: 30,
                              thickness: 1,
                            ),
                            Row(
                              children: [
                                const Text(
                                  'Total',
                                  style: TextStyle(fontSize: 16),
                                ),
                                const Spacer(),
                                Text(
                                  paymentRG == 3
                                      ? 'RM${(totalPriceIns - couponAmount).toStringAsFixed(2)}'
                                      : 'RM${(totalPrice - couponAmount).toStringAsFixed(2)}',
                                  style: const TextStyle(
                                      color: Colors.black87,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            const Divider(
                              height: 30,
                              thickness: 1,
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                } else {
                  return const SliverToBoxAdapter(
                      child: Center(
                    child: Text('empty cart!'),
                  ));
                }
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Center(
                    child: Text(snapshot.error.toString()),
                  ),
                );
              }
              return SliverToBoxAdapter(
                child: LoadingWidget(
                  color: AppsColors.buttonColor,
                ),
              );
            }),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 20,
          ),
        ),

        SliverToBoxAdapter(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: const Text(
              'Promo code / coupon',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.black87,
                  fontWeight: FontWeight.w600,
                  fontSize: 16),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 16,
          ),
        ),
        SliverLayoutBuilder(
          builder: (BuildContext context, SliverConstraints constraints){
            if(isCouponApplied == 0){
              return SliverToBoxAdapter(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: Form(
                    key: _couponFormKey,
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 3,
                          child: TextFormField(
                            controller: _couponController,
                            validator: validationCouponCode,
                            enabled: isCouponApplied == 0 ? true : false,
                            onSaved: (String? val) {
                              couponCode = val;
                            },
                            decoration: InputDecoration(
                              contentPadding:
                              const EdgeInsets.symmetric(horizontal: 20),
                              hintText: 'Promo code / coupon',
                              fillColor: Colors.white,
                              filled: true,
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(color: Colors.black)),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide:
                                  const BorderSide(color: Color(0xFFD0D1D2))),
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 8,
                        ),
                        Expanded(
                          flex: 1,
                          child: SizedBox(
                            height: 45,
                            child: ElevatedButton(
                              onPressed: () async {
                                if(_couponFormKey.currentState!.validate()){
                                  _couponFormKey.currentState!.save();
                                  setState(() {
                                    isLoading = true;
                                  });
                                    applyCoupon();
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                  primary: AppsColors.buttonColor),
                              child: !isLoading ? const Text('Apply',
                                style: TextStyle(color: Colors.white),
                              ) : const SizedBox(
                                height: 16,
                                width: 16,
                                child: CircularProgressIndicator(
                                    color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              );
            }else {
              return SliverToBoxAdapter(
                child: Container(
                  padding: const EdgeInsets.all(4),
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: Colors.green,width: 1.0)
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Expanded(
                        flex: 1,
                        child: Icon(Icons.check_circle_outline_rounded,color: Colors.green,size: 30,),
                      ),
                      Expanded(
                        flex: 3,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            RichText(
                              text: TextSpan(
                                  text: '$couponCode',
                                  style: const TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w600),
                                  children: const <TextSpan>[
                                    TextSpan(
                                      text: '  Applied',
                                      style: TextStyle(color: Colors.black,fontSize: 12,fontWeight: FontWeight.normal),
                                    )
                                  ]
                              ),
                            ),
                            Text(couponType == 1 ? '-RM$couponAmount ($couponPercentage)% off' : '-RM$couponAmount',style: const TextStyle(color: Colors.black54,fontSize: 14),),
                          ],
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: TextButton(
                          onPressed: (){
                            setState(() {
                              isCouponApplied = 0;
                              couponAmount = 0;
                              couponPercentage = 0;
                              _couponController.text = "";
                              couponCode = "";
                            });
                          },
                          child: const Text('Remove',style: TextStyle(color: Colors.redAccent),),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }
          },
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 16,
          ),
        ),

        SliverLayoutBuilder(
            builder: (BuildContext context, SliverConstraints constraints) {
          if (SharedPreferenceUtils.isShipping == 0) {
            return SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.all(16.0),
                margin: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(2.0),
                    border:
                        Border.all(color: const Color(0xFFD0D1D2), width: 1.0)),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text(
                          'Contact',
                          style: TextStyle(color: Colors.black54, fontSize: 16),
                        ),
                        const Spacer(),
                        TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text(
                              'Change',
                              style: TextStyle(color: AppsColors.buttonColor),
                            ))
                      ],
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: Text('${SharedPreferenceUtils.emailF}'),
                    ),
                    const Divider(
                      height: 30,
                      thickness: 1,
                    ),
                    Row(
                      children: [
                        const Text(
                          'Method',
                          style: TextStyle(color: Colors.black54, fontSize: 16),
                        ),
                        const Spacer(),
                        TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text(
                              'Change',
                              style: TextStyle(color: AppsColors.buttonColor),
                            ))
                      ],
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: RichText(
                        text: const TextSpan(
                            text: 'Pick up in store . ',
                            style: TextStyle(
                                color: Colors.black54,
                                fontWeight: FontWeight.normal,
                                fontSize: 16),
                            children: <TextSpan>[
                              TextSpan(
                                  text: 'Azura Mart',
                                  style: TextStyle(
                                      color: Colors.black87,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16))
                            ]),
                      ),
                    ),
                    const SizedBox(
                      width: double.infinity,
                      child: Text(
                        'No. 8 Pintas Tuna 3 Seberang Jaya Perai 13700 Pulau Pinang',
                        style: TextStyle(color: Colors.black54, fontSize: 16),
                      ),
                    ),
                  ],
                ),
              ),
            );
          } else {
            return SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.all(16.0),
                margin: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(2.0),
                    border:
                        Border.all(color: const Color(0xFFD0D1D2), width: 1.0)),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text(
                          'Contact',
                          style: TextStyle(color: Colors.black54, fontSize: 18),
                        ),
                        const Spacer(),
                        TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text(
                              'Change',
                              style: TextStyle(color: AppsColors.buttonColor),
                            ))
                      ],
                    ),
                    SizedBox(
                        width: double.infinity,
                        child: Text(
                          '${SharedPreferenceUtils.emailF}',
                          style: const TextStyle(
                              color: Colors.black87, fontSize: 16),
                        )),
                    const Divider(
                      height: 30,
                      thickness: 1,
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Ship to',
                          style: TextStyle(color: Colors.black54, fontSize: 18),
                        ),
                        const Spacer(),
                        TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text(
                              'Change',
                              style: TextStyle(color: AppsColors.buttonColor),
                            ))
                      ],
                    ),
                    SizedBox(
                        width: double.infinity,
                        child: Text(
                          '${SharedPreferenceUtils.addressSP}, ${SharedPreferenceUtils.address2SP},${SharedPreferenceUtils.postcodeSP} ${SharedPreferenceUtils.citySP}, ${SharedPreferenceUtils.stateSP}, Malaysia',
                          style: const TextStyle(
                              color: Colors.black87, fontSize: 16),
                        )),
                    const Divider(
                      height: 30,
                      thickness: 1,
                    ),
                    const SizedBox(
                      width: double.infinity,
                      child: Text(
                        'Method',
                        style: TextStyle(color: Colors.black54, fontSize: 16),
                      ),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: RichText(
                        text: TextSpan(
                            text: 'Postage . ',
                            style: const TextStyle(
                                color: Colors.black54, fontSize: 16),
                            children: <TextSpan>[
                              TextSpan(
                                text: SharedPreferenceUtils.postcodeSP >= 87000
                                    ? 'RM${SharedPreferenceUtils.postageCostSS!.toStringAsFixed(2)}'
                                    : 'RM${SharedPreferenceUtils.postageCostSM!.toStringAsFixed(2)}',
                                style: const TextStyle(
                                    color: Colors.black87,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500),
                              )
                            ]),
                      ),
                    )
                  ],
                ),
              ),
            );
          }
        }),
        // SliverToBoxAdapter(
        //   child: SizedBox(
        //     height: 20,
        //   ),
        // ),
        // SliverToBoxAdapter(
        //   child: Padding(
        //     padding: const EdgeInsets.symmetric(horizontal: 16),
        //     child: SizedBox(
        //       width: double.infinity,
        //       child: Text(
        //         'Gift card or discount code',
        //         style: TextStyle(
        //             color: Colors.black87,
        //             fontSize: 20,
        //             fontWeight: FontWeight.w600),
        //       ),
        //     ),
        //   ),
        // ),
        // SliverToBoxAdapter(
        //   child: SizedBox(
        //     height: 16,
        //   ),
        // ),
        // SliverToBoxAdapter(
        //   child: Padding(
        //     padding: const EdgeInsets.symmetric(horizontal: 20),
        //     child: Row(
        //       mainAxisSize: MainAxisSize.max,
        //       children: [
        //         Expanded(
        //           flex: 4,
        //           child: TextFormField(
        //             decoration: InputDecoration(
        //               contentPadding: EdgeInsets.symmetric(horizontal: 20),
        //               hintText: 'Gift card or discount code',
        //               fillColor: Colors.white,
        //               filled: true,
        //               focusedBorder: OutlineInputBorder(
        //                   borderRadius: BorderRadius.circular(6),
        //                   borderSide: BorderSide(color: Colors.black)),
        //               border: OutlineInputBorder(
        //                   borderRadius: BorderRadius.circular(2),
        //                   borderSide: BorderSide(color: Color(0xFFD0D1D2))),
        //             ),
        //           ),
        //         ),
        //         SizedBox(
        //           width: 8,
        //         ),
        //         Expanded(
        //           flex: 1,
        //           child: Container(
        //             height: 45,
        //             child: ElevatedButton(
        //               onPressed: () {
        //
        //               },
        //               style:
        //                   ElevatedButton.styleFrom(primary: AppsColors.buttonColor),
        //               child: Icon(
        //                 Icons.arrow_forward,
        //                 color: Colors.white,
        //               ),
        //             ),
        //           ),
        //         )
        //       ],
        //     ),
        //   ),
        // ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 20,
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            width: double.infinity,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Payment',
                style: TextStyle(
                    color: Colors.black87,
                    fontSize: 18,
                    fontWeight: FontWeight.w600),
              ),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 8,
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            width: double.infinity,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'All transactions are secure and encrypted',
                style: TextStyle(color: Colors.black54, fontSize: 14),
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
                color: Colors.transparent,
                border: Border.all(
                    color: const Color(0xFFD0D1D2).withOpacity(0.7), width: 1),
                borderRadius: BorderRadius.circular(2.0)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                ExpandablePanel(
                  collapsed: const SizedBox(
                    height: 0,
                  ),
                  header: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Expanded(
                        flex: 1,
                        child: Center(
                          child: Radio(
                            value: 1,
                            groupValue: paymentRG,
                            activeColor: AppsColors.buttonColor,
                            onChanged: (int? value) {
                              setState(() {
                                paymentRG = value;
                              });
                            },
                          ),
                        ),
                      ),
                      Expanded(
                          flex: 6,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const SizedBox(
                                height: 12,
                              ),
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: const [
                                  Text(
                                    'Billplz',
                                    textAlign: TextAlign.start,
                                    style: TextStyle(
                                        color: Colors.blue,
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    'Pay in full',
                                    style: TextStyle(
                                        color: Colors.black87,
                                        fontSize: 16,
                                        fontWeight: FontWeight.normal),
                                  ),
                                  SizedBox(
                                    height: 2,
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 12,
                              ),
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Expanded(
                                    flex: 1,
                                    child: Container(
                                      height: 35,
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 5),
                                      margin: const EdgeInsets.only(right: 3),
                                      decoration: BoxDecoration(
                                          color: Colors.transparent,
                                          borderRadius:
                                              BorderRadius.circular(4.0),
                                          border: Border.all(
                                              color: const Color(0xFFD0D1D2)
                                                  .withOpacity(0.5),
                                              width: 1)),
                                      child: const Image(
                                        image: AssetImage(
                                          'images/visa.png',
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Container(
                                      height: 35,
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 5),
                                      margin: const EdgeInsets.only(right: 3),
                                      decoration: BoxDecoration(
                                          color: Colors.transparent,
                                          borderRadius:
                                              BorderRadius.circular(4.0),
                                          border: Border.all(
                                              color: const Color(0xFFD0D1D2)
                                                  .withOpacity(0.5),
                                              width: 1)),
                                      child: const Image(
                                        image: AssetImage(
                                          'images/mastercard.png',
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Container(
                                      height: 35,
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 5),
                                      margin: const EdgeInsets.only(right: 3),
                                      decoration: BoxDecoration(
                                          color: Colors.transparent,
                                          borderRadius:
                                              BorderRadius.circular(4.0),
                                          border: Border.all(
                                              color: const Color(0xFFD0D1D2)
                                                  .withOpacity(0.5),
                                              width: 1)),
                                      child: const Image(
                                        image: AssetImage(
                                          'images/amex.png',
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Container(
                                      height: 35,
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 5),
                                      margin: const EdgeInsets.only(right: 3),
                                      decoration: BoxDecoration(
                                          color: Colors.transparent,
                                          borderRadius:
                                              BorderRadius.circular(4.0),
                                          border: Border.all(
                                              color: const Color(0xFFD0D1D2)
                                                  .withOpacity(0.5),
                                              width: 1)),
                                      child: const Image(
                                        image: AssetImage(
                                          'images/pfx.png',
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              )
                            ],
                          )),
                    ],
                  ),
                  expanded: Container(
                    decoration: BoxDecoration(
                        color: const Color(0xFFFAFAFA),
                        borderRadius: BorderRadius.circular(2.0)),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        SizedBox(
                          height: 8,
                        ),
                        Icon(
                          Icons.credit_card,
                          size: 60,
                          color: Colors.black54,
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20),
                            child: Text(
                              'Pay securely with VISA, Mastercard, FPX, Maybank2u, CIMBClicks, GrabPay, Boost, Touch\'nGo, eWallet and more. By clicking Pay now, You agree with our Privacy Policy and Terms and Condition',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.black54, fontSize: 16),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                  ),
                  theme: ExpandableThemeData(
                    iconColor: Colors.black,
                    fadeCurve: Curves.easeInOut,
                    useInkWell: true,
                    inkWellBorderRadius: BorderRadius.circular(24),
                  ),
                  // collapsed: Text('Click here for more'),
                ),
                LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints){
                    if(isCouponApplied == 0 || isCouponApplied == 1){
                      return Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const SizedBox(
                            child: Divider(
                              height: 20,
                              thickness: 1,
                            ),
                          ),
                          /// ........... 90 days installment azura mart..............
                          ExpandablePanel(
                            collapsed: const SizedBox(
                              height: 0,
                            ),
                            header: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      flex: 1,
                                      child: Center(
                                        child: Radio(
                                          value: 2,
                                          groupValue: paymentRG,
                                          activeColor: AppsColors.buttonColor,
                                          onChanged: (int? value) {
                                            setState(() {
                                              paymentRG = value;
                                            });
                                          },
                                        ),
                                      ),
                                    ),
                                    const Expanded(
                                      flex: 3,
                                      child: Image(
                                        image: AssetImage('images/azura_logo_v.png'),
                                      ),
                                    ),
                                    const Expanded(
                                      flex: 3,
                                      child: SizedBox(
                                        width: double.infinity,
                                        child: Text(
                                          'Pay within 90 days (0% Interest)',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: Colors.black87,
                                              fontSize: 14,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 8),
                                  child: const Text(
                                    'We will dispatch your order, once balance settle in FULL',
                                    style: TextStyle(
                                        color: Colors.black87,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                              ],
                            ),
                            expanded: Container(
                              decoration: BoxDecoration(
                                  color: const Color(0xFFFAFAFA),
                                  borderRadius: BorderRadius.circular(2.0)),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const SizedBox(
                                    child: Divider(
                                      height: 16,
                                      thickness: 1,
                                    ),
                                  ),
                                  const SizedBox(
                                    width: double.infinity,
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 20),
                                      child: Text(
                                        'Pay minimum 20% remaining balance pay within 90 days (3 months).',
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            color: Colors.black87, fontSize: 16),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  Container(
                                    width: double.infinity,
                                    padding: const EdgeInsets.symmetric(horizontal: 16),
                                    child: Form(
                                      key: _azura3InsFormKey,
                                      autovalidateMode:
                                      AutovalidateMode.onUserInteraction,
                                      child: Wrap(
                                        direction: Axis.horizontal,
                                        alignment: WrapAlignment.start,
                                        spacing: 20,
                                        runSpacing: 20,
                                        children: [
                                          SizedBox(
                                            height: 50,
                                            width: 130,
                                            child: TextFormField(
                                              validator: validationDownPayment,
                                              autovalidateMode: AutovalidateMode.always,
                                              controller: _down3PaymentTextController,
                                              keyboardType: TextInputType.number,
                                              maxLines: 1,
                                              onSaved: (String? val) {
                                                if (val!.isNotEmpty || val != '') {
                                                  downPrice = int.parse(val);
                                                }
                                              },
                                              onEditingComplete: () {
                                                if (_down3PaymentTextController
                                                    .text.isNotEmpty ||
                                                    _down3PaymentTextController.text !=
                                                        '') {
                                                  int value = int.parse(
                                                      _down3PaymentTextController.text);
                                                  if (value > totalPrice) {
                                                    value = totalPrice.toInt();
                                                    _down3PaymentTextController.text =
                                                        value.toString();
                                                  } else if (value < (totalPrice * 0.2)) {
                                                    value = (totalPrice * 0.2).ceil();
                                                    _down3PaymentTextController.text =
                                                        value.toString();
                                                  }
                                                  List<int> xx =
                                                  getInsPayment(3, totalPrice, value);
                                                  _first3PaymentTextController.text =
                                                      xx[0].toString();
                                                  _second3PaymentTextController.text =
                                                      xx[1].toString();
                                                  _third3PaymentTextController.text =
                                                      xx[2].toString();
                                                  _azura3InsFormKey.currentState!.save();
                                                }
                                              },
                                              onChanged: (String val) {
                                                if (val.isNotEmpty || val != '') {
                                                  int value = int.parse(val);
                                                  if (value > totalPrice) {
                                                    value = totalPrice.toInt();
                                                    _down3PaymentTextController.text =
                                                        value.toString();
                                                  }
                                                  // else if (value < (totalPrice * 0.2)) {
                                                  //   value = (totalPrice * 0.2).ceil();
                                                  //   _down3PaymentTextController.text = value.toString();
                                                  // }
                                                  List<int> xx =
                                                  getInsPayment(3, totalPrice, value);
                                                  _first3PaymentTextController.text =
                                                      xx[0].toString();
                                                  _second3PaymentTextController.text =
                                                      xx[1].toString();
                                                  _third3PaymentTextController.text =
                                                      xx[2].toString();
                                                  _azura3InsFormKey.currentState!.save();
                                                }
                                              },
                                              decoration: InputDecoration(
                                                contentPadding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 20),
                                                hintText: 'Down Payment',
                                                labelText: 'Down Payment',
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(2),
                                                    borderSide: const BorderSide(
                                                        color: Colors.black)),
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(2),
                                                    borderSide: const BorderSide(
                                                        color: Color(0xFFD0D1D2))),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 50,
                                            width: 130,
                                            child: TextFormField(
                                              // validator: validationDownPayment,
                                              // controller: _downPaymentTextController,
                                              keyboardType: TextInputType.number,
                                              enabled: false,
                                              controller: _first3PaymentTextController,
                                              maxLines: 1,
                                              onSaved: (String? val) {
                                                first3Ins = int.parse(val!);
                                              },
                                              decoration: InputDecoration(
                                                contentPadding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 20),
                                                hintText: '1st Installment',
                                                labelText: '1st Installment',
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(2),
                                                    borderSide: const BorderSide(
                                                        color: Colors.black)),
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(2),
                                                    borderSide: const BorderSide(
                                                        color: Color(0xFFD0D1D2))),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 50,
                                            width: 130,
                                            child: TextFormField(
                                              // validator: validationDownPayment,
                                              // controller: _downPaymentTextController,
                                              keyboardType: TextInputType.number,
                                              enabled: false,
                                              maxLines: 1,
                                              controller: _second3PaymentTextController,
                                              onSaved: (String? val) {
                                                second3Ins = int.parse(val!);
                                              },
                                              decoration: InputDecoration(
                                                contentPadding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 20),
                                                hintText: '2nd Installment',
                                                labelText: '2nd Installment',
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(2),
                                                    borderSide: const BorderSide(
                                                        color: Colors.black)),
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(2),
                                                    borderSide: const BorderSide(
                                                        color: Color(0xFFD0D1D2))),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 50,
                                            width: 130,
                                            child: TextFormField(
                                              // validator: validationDownPayment,
                                              // controller: _downPaymentTextController,
                                              keyboardType: TextInputType.number,
                                              enabled: false,
                                              maxLines: 1,
                                              controller: _third3PaymentTextController,
                                              onSaved: (String? val) {
                                                third3Ins = int.parse(val!);
                                              },
                                              decoration: InputDecoration(
                                                contentPadding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 20),
                                                hintText: '3rd Installment',
                                                labelText: '3rd Installment',
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(2),
                                                    borderSide: const BorderSide(
                                                        color: Colors.black)),
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(2),
                                                    borderSide: const BorderSide(
                                                        color: Color(0xFFD0D1D2))),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  const SizedBox(
                                    width: double.infinity,
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 20),
                                      child: Text(
                                        'Warning!',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(color: Colors.red, fontSize: 16),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 16),
                                    child: RichText(
                                      text: TextSpan(
                                          text:
                                          'You must settle your balance before or by ',
                                          style: const TextStyle(
                                              color: Colors.black54, fontSize: 14),
                                          children: <TextSpan>[
                                            TextSpan(
                                              text: f.format(DateTime.now()
                                                  .add(const Duration(days: 90))),
                                              style: TextStyle(
                                                  color: AppsColors.buttonColor,
                                                  fontSize: 14),
                                            ),
                                            const TextSpan(
                                              text:
                                              ', failed to settle in FULL within agreed time, we will cancel your order and no refund will make...',
                                              style: TextStyle(
                                                  color: Colors.black54, fontSize: 14),
                                            ),
                                          ]),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  const Icon(
                                    Icons.credit_card,
                                    size: 60,
                                    color: Colors.black54,
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  const SizedBox(
                                    width: double.infinity,
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 20),
                                      child: Text(
                                        'Pay securely with VISA, Mastercard, FPX, Maybank2u, CIMBClicks, GrabPay, Boost, Touch\'nGo, eWallet and more. By clicking Pay now, You agree with our Privacy Policy and Terms and Condition',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            color: Colors.black54, fontSize: 16),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                ],
                              ),
                            ),
                            theme: ExpandableThemeData(
                              iconColor: Colors.black,
                              fadeCurve: Curves.easeInOut,
                              useInkWell: true,
                              inkWellBorderRadius: BorderRadius.circular(24),
                            ),
                            // collapsed: Text('Click here for more'),
                          ),
                          const SizedBox(
                            child: Divider(
                              height: 30,
                              thickness: 1,
                            ),
                          ),

                          /// ........... 180 days installment azura mart
                          ExpandablePanel(
                            collapsed: const SizedBox(
                              height: 0,
                            ),
                            header: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      flex: 1,
                                      child: Center(
                                        child: Radio(
                                          value: 3,
                                          groupValue: paymentRG,
                                          activeColor: AppsColors.buttonColor,
                                          onChanged: (int? value) {
                                            setState(() {
                                              paymentRG = value;
                                            });
                                          },
                                        ),
                                      ),
                                    ),
                                    const Expanded(
                                      flex: 3,
                                      child: Image(
                                        image: AssetImage('images/azura_logo_v.png'),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 3,
                                      child: SizedBox(
                                        width: double.infinity,
                                        child: RichText(
                                          text: TextSpan(
                                              text: 'Pay within 180 days',
                                              style: const TextStyle(
                                                  color: Colors.black87,
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold),
                                              children: <TextSpan>[
                                                TextSpan(
                                                  text: '(Fee Applies)',
                                                  style: TextStyle(
                                                      color: AppsColors.buttonColor,
                                                      fontSize: 14,
                                                      fontWeight: FontWeight.bold),
                                                )
                                              ]),
                                        ),
                                        // child: Text('Pay within 180 days',textAlign: TextAlign.center,style: TextStyle(color: Colors.black87,fontSize: 14,fontWeight: FontWeight.bold),),
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 8),
                                  child: const Text(
                                    'We will dispatch your order, once balance settle in FULL',
                                    style: TextStyle(
                                        color: Colors.black87,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                              ],
                            ),
                            expanded: Container(
                              decoration: BoxDecoration(
                                  color: const Color(0xFFFAFAFA),
                                  borderRadius: BorderRadius.circular(10.0)),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const SizedBox(
                                    child: Divider(
                                      height: 16,
                                      thickness: 1,
                                    ),
                                  ),
                                  const SizedBox(
                                    width: double.infinity,
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 20),
                                      child: Text(
                                        'Pay minimum 20% now and remaining balance pay within 180 days (6 months)',
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            color: Colors.black87, fontSize: 16),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  Container(
                                    width: double.infinity,
                                    padding: const EdgeInsets.symmetric(horizontal: 16),
                                    child: Form(
                                      key: _azura6InsFormKey,
                                      autovalidateMode: AutovalidateMode.always,
                                      child: Wrap(
                                        direction: Axis.horizontal,
                                        alignment: WrapAlignment.start,
                                        spacing: 20,
                                        runSpacing: 20,
                                        children: [
                                          SizedBox(
                                            height: 50,
                                            width: 130,
                                            child: TextFormField(
                                              validator: validationInstallmentDownPayment,
                                              controller: _down6PaymentTextController,
                                              autovalidateMode: AutovalidateMode.always,
                                              keyboardType: TextInputType.number,
                                              maxLines: 1,
                                              onSaved: (String? val) {
                                                if (val!.isNotEmpty || val != '') {
                                                  downPrice = int.parse(val);
                                                }
                                              },
                                              onEditingComplete: () {
                                                if (_down6PaymentTextController
                                                    .text.isNotEmpty ||
                                                    _down6PaymentTextController.text !=
                                                        '') {
                                                  int value = int.parse(
                                                      _down6PaymentTextController.text);
                                                  if (value > totalPriceIns) {
                                                    value = totalPriceIns.toInt();
                                                    _down6PaymentTextController.text =
                                                        value.toString();
                                                  } else if (value <
                                                      (totalPriceIns * 0.2)) {
                                                    value = (totalPriceIns * 0.2).ceil();
                                                    _down6PaymentTextController.text =
                                                        value.toString();
                                                  }
                                                  List<int> insPayment6 = getInsPayment(
                                                      6, totalPriceIns, value);
                                                  _first6PaymentTextController.text =
                                                      insPayment6[0].toString();
                                                  _second6PaymentTextController.text =
                                                      insPayment6[1].toString();
                                                  _third6PaymentTextController.text =
                                                      insPayment6[2].toString();
                                                  _forth6PaymentTextController.text =
                                                      insPayment6[3].toString();
                                                  _fifth6PaymentTextController.text =
                                                      insPayment6[4].toString();
                                                  _sixth6PaymentTextController.text =
                                                      insPayment6[5].toString();
                                                  _azura6InsFormKey.currentState!.save();
                                                }
                                              },
                                              onChanged: (String val) {
                                                if (val.isNotEmpty || val != '') {
                                                  int value = int.parse(val);
                                                  if (value > totalPriceIns) {
                                                    value = totalPriceIns.toInt();
                                                    _down6PaymentTextController.text =
                                                        value.toString();
                                                  }
                                                  List<int> insPayment6 = getInsPayment(
                                                      6, totalPriceIns, value);
                                                  _first6PaymentTextController.text =
                                                      insPayment6[0].toString();
                                                  _second6PaymentTextController.text =
                                                      insPayment6[1].toString();
                                                  _third6PaymentTextController.text =
                                                      insPayment6[2].toString();
                                                  _forth6PaymentTextController.text =
                                                      insPayment6[3].toString();
                                                  _fifth6PaymentTextController.text =
                                                      insPayment6[4].toString();
                                                  _sixth6PaymentTextController.text =
                                                      insPayment6[5].toString();
                                                  _azura6InsFormKey.currentState!.save();
                                                }
                                              },
                                              decoration: InputDecoration(
                                                contentPadding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 20),
                                                hintText: 'Down Payment',
                                                labelText: 'Down Payment',
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Colors.black)),
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Color(0xFFD0D1D2))),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 50,
                                            width: 130,
                                            child: TextFormField(
                                              // validator: validationDownPayment,
                                              // controller: _downPaymentTextController,
                                              keyboardType: TextInputType.number,
                                              enabled: false,
                                              controller: _first6PaymentTextController,
                                              maxLines: 1,
                                              onSaved: (String? val) {
                                                first3Ins = int.parse(val!);
                                              },
                                              decoration: InputDecoration(
                                                contentPadding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 20),
                                                hintText: '1st Installment',
                                                labelText: '1st Installment',
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Colors.black)),
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Color(0xFFD0D1D2))),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 50,
                                            width: 130,
                                            child: TextFormField(
                                              // validator: validationDownPayment,
                                              // controller: _downPaymentTextController,
                                              keyboardType: TextInputType.number,
                                              enabled: false,
                                              maxLines: 1,
                                              controller: _second6PaymentTextController,
                                              onSaved: (String? val) {
                                                second3Ins = int.parse(val!);
                                              },
                                              decoration: InputDecoration(
                                                contentPadding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 20),
                                                hintText: '2nd Installment',
                                                labelText: '2nd Installment',
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Colors.black)),
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Color(0xFFD0D1D2))),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 50,
                                            width: 130,
                                            child: TextFormField(
                                              // validator: validationDownPayment,
                                              // controller: _downPaymentTextController,
                                              keyboardType: TextInputType.number,
                                              enabled: false,
                                              maxLines: 1,
                                              controller: _third6PaymentTextController,
                                              onSaved: (String? val) {
                                                third3Ins = int.parse(val!);
                                              },
                                              decoration: InputDecoration(
                                                contentPadding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 20),
                                                hintText: '3rd Installment',
                                                labelText: '3rd Installment',
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Colors.black)),
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Color(0xFFD0D1D2))),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 50,
                                            width: 130,
                                            child: TextFormField(
                                              // validator: validationDownPayment,
                                              // controller: _downPaymentTextController,
                                              keyboardType: TextInputType.number,
                                              enabled: false,
                                              controller: _forth6PaymentTextController,
                                              maxLines: 1,
                                              onSaved: (String? val) {
                                                first3Ins = int.parse(val!);
                                              },
                                              decoration: InputDecoration(
                                                contentPadding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 20),
                                                hintText: '4th Installment',
                                                labelText: '4th Installment',
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Colors.black)),
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Color(0xFFD0D1D2))),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 50,
                                            width: 130,
                                            child: TextFormField(
                                              // validator: validationDownPayment,
                                              // controller: _downPaymentTextController,
                                              keyboardType: TextInputType.number,
                                              enabled: false,
                                              maxLines: 1,
                                              controller: _fifth6PaymentTextController,
                                              onSaved: (String? val) {
                                                second3Ins = int.parse(val!);
                                              },
                                              decoration: InputDecoration(
                                                contentPadding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 20),
                                                hintText: '5th Installment',
                                                labelText: '5th Installment',
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Colors.black)),
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Color(0xFFD0D1D2))),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 50,
                                            width: 130,
                                            child: TextFormField(
                                              // validator: validationDownPayment,
                                              // controller: _downPaymentTextController,
                                              keyboardType: TextInputType.number,
                                              enabled: false,
                                              maxLines: 1,
                                              controller: _sixth6PaymentTextController,
                                              onSaved: (String? val) {
                                                third3Ins = int.parse(val!);
                                              },
                                              decoration: InputDecoration(
                                                contentPadding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 20),
                                                hintText: '6th Installment',
                                                labelText: '6th Installment',
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Colors.black)),
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(10),
                                                    borderSide: const BorderSide(
                                                        color: Color(0xFFD0D1D2))),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  const SizedBox(
                                    width: double.infinity,
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 20),
                                      child: Text(
                                        'Warning!',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(color: Colors.red, fontSize: 16),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 16),
                                    child: RichText(
                                      text: TextSpan(
                                          text:
                                          'You must settle your balance before or by ',
                                          style: const TextStyle(
                                              color: Colors.black54, fontSize: 14),
                                          children: <TextSpan>[
                                            TextSpan(
                                              text: f.format(DateTime.now()
                                                  .add(const Duration(days: 180))),
                                              style: TextStyle(
                                                  color: AppsColors.buttonColor,
                                                  fontSize: 14),
                                            ),
                                            const TextSpan(
                                              text:
                                              ', failed to settle in FULL within agreed time, we will cancel your order and no refund will make...',
                                              style: TextStyle(
                                                  color: Colors.black54, fontSize: 14),
                                            ),
                                          ]),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  const Icon(
                                    Icons.credit_card,
                                    size: 60,
                                    color: Colors.black54,
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  const SizedBox(
                                    width: double.infinity,
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 20),
                                      child: Text(
                                        'Pay securely with VISA, Mastercard, FPX, Maybank2u, CIMBClicks, GrabPay, Boost, Touch\'nGo, eWallet and more. By clicking Pay now, You agree with our Privacy Policy and Terms and Condition',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            color: Colors.black54, fontSize: 16),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                ],
                              ),
                            ),
                            theme: ExpandableThemeData(
                              iconColor: Colors.black,
                              fadeCurve: Curves.easeInOut,
                              useInkWell: true,
                              inkWellBorderRadius: BorderRadius.circular(24),
                            ),
                            // collapsed: Text('Click here for more'),
                          ),
                          // SizedBox(
                          //   child: Divider(
                          //     height: 30,
                          //     thickness: 1,
                          //   ),
                          // ),
                          // /// ........... hoolah ..............
                          // ExpandablePanel(
                          //   collapsed: SizedBox(height: 0,),
                          //   header: Row(
                          //     mainAxisSize: MainAxisSize.max,
                          //     mainAxisAlignment: MainAxisAlignment.start,
                          //     children: [
                          //       Expanded(
                          //         flex: 1,
                          //         child: Center(
                          //           child: Radio(
                          //             value: 4,
                          //             groupValue: paymentRG,
                          //             activeColor: AppsColors.buttonColor,
                          //             onChanged: (int value) {
                          //               setState(() {
                          //                 paymentRG = value;
                          //               });
                          //             },
                          //           ),
                          //         ),
                          //       ),
                          //       Expanded(
                          //         flex: 3,
                          //         child: Image(
                          //           height: 24,
                          //           image: AssetImage('images/hoolahh.png',),
                          //         ),
                          //       ),
                          //       Expanded(
                          //         flex: 3,
                          //         child: SizedBox(
                          //           width: double.infinity,
                          //           child: Text('3 Installments 0% Interest',textAlign: TextAlign.center,style: TextStyle(color: Colors.black87,fontSize: 14,fontWeight: FontWeight.bold),),
                          //         ),
                          //       )
                          //     ],
                          //   ),
                          //   expanded: Container(
                          //     decoration: BoxDecoration(
                          //         color: Color(0xFFFAFAFA),
                          //         borderRadius: BorderRadius.circular(10.0)),
                          //     child: Column(
                          //       mainAxisAlignment: MainAxisAlignment.start,
                          //       crossAxisAlignment: CrossAxisAlignment.center,
                          //       mainAxisSize: MainAxisSize.min,
                          //       children: [
                          //         SizedBox(
                          //           height: 8,
                          //         ),
                          //         Icon(
                          //           Icons.credit_card,
                          //           size: 60,
                          //           color: Colors.black54,
                          //         ),
                          //         SizedBox(
                          //           height: 8,
                          //         ),
                          //         SizedBox(
                          //           width: double.infinity,
                          //           child: Padding(
                          //             padding: const EdgeInsets.symmetric(horizontal: 20),
                          //             child: Text(
                          //               'Pay securely with VISA, Mastercard, FPX, Maybank2u, CIMBClicks, GrabPay, Boost, Touch\'nGo, eWallet and more. By clicking Pay now, You agree with our Privacy Policy and Terms and Condition',
                          //               textAlign: TextAlign.center,
                          //               style:
                          //               TextStyle(color: Colors.black54, fontSize: 16),
                          //             ),
                          //           ),
                          //         ),
                          //         SizedBox(
                          //           height: 10,
                          //         ),
                          //       ],
                          //     ),
                          //   ),
                          //   // collapsed: Text('Click here for more'),
                          // ),
                          // SizedBox(
                          //   child: Divider(
                          //     height: 30,
                          //     thickness: 1,
                          //   ),
                          // ),
                          // /// ........... grab ................
                          // ExpandablePanel(
                          //   collapsed: SizedBox(height: 0,),
                          //   header: Row(
                          //     mainAxisSize: MainAxisSize.max,
                          //     mainAxisAlignment: MainAxisAlignment.start,
                          //     children: [
                          //       Expanded(
                          //         flex: 1,
                          //         child: Center(
                          //           child: Radio(
                          //             value: 5,
                          //             groupValue: paymentRG,
                          //             activeColor: AppsColors.buttonColor,
                          //             onChanged: (int value) {
                          //               setState(() {
                          //                 paymentRG = value;
                          //               });
                          //             },
                          //           ),
                          //         ),
                          //       ),
                          //       Expanded(
                          //         flex: 4,
                          //         child: Image(
                          //           image: AssetImage('images/grab.png'),
                          //         ),
                          //       ),
                          //       Expanded(
                          //         flex: 2,
                          //         child: Row(
                          //           mainAxisAlignment: MainAxisAlignment.center,
                          //           children: [
                          //             Container(
                          //               padding: const EdgeInsets.symmetric(horizontal: 5),
                          //               margin: const EdgeInsets.only(right: 3),
                          //               decoration: BoxDecoration(
                          //                   color: Colors.transparent,
                          //                   borderRadius: BorderRadius.circular(4.0),
                          //                   border: Border.all(
                          //                       color: Color(0xFFD0D1D2).withOpacity(0.5),
                          //                       width: 1)),
                          //               child: Image(
                          //                 image: AssetImage(
                          //                   'images/grabpay.png',
                          //                 ),
                          //               ),
                          //             ),
                          //           ],
                          //         ),
                          //       )
                          //     ],
                          //   ),
                          //   expanded: Container(
                          //     decoration: BoxDecoration(
                          //         color: Color(0xFFFAFAFA),
                          //         borderRadius: BorderRadius.circular(10.0)),
                          //     child: Column(
                          //       mainAxisAlignment: MainAxisAlignment.start,
                          //       crossAxisAlignment: CrossAxisAlignment.center,
                          //       mainAxisSize: MainAxisSize.min,
                          //       children: [
                          //         SizedBox(
                          //           height: 8,
                          //         ),
                          //         Icon(
                          //           Icons.credit_card,
                          //           size: 60,
                          //           color: Colors.black54,
                          //         ),
                          //         SizedBox(
                          //           height: 8,
                          //         ),
                          //         SizedBox(
                          //           width: double.infinity,
                          //           child: Padding(
                          //             padding: const EdgeInsets.symmetric(horizontal: 20),
                          //             child: Text(
                          //               'Pay securely with VISA, Mastercard, FPX, Maybank2u, CIMBClicks, GrabPay, Boost, Touch\'nGo, eWallet and more. By clicking Pay now, You agree with our Privacy Policy and Terms and Condition',
                          //               textAlign: TextAlign.center,
                          //               style:
                          //               TextStyle(color: Colors.black54, fontSize: 16),
                          //             ),
                          //           ),
                          //         ),
                          //         SizedBox(
                          //           height: 10,
                          //         ),
                          //       ],
                          //     ),
                          //   ),
                          //   // collapsed: Text('Click here for more'),
                          // ),
                        ],
                      );
                    } else {
                      return const SizedBox(
                        height: 0,
                      );
                    }
                  },
                ),
              ],
            ),
          ),
        ),

        /// ................. Special note................
        SliverToBoxAdapter(
          child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8.0)),
              child: Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: Text(
                      'Special Note',
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        color: AppsColors.buttonColor,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      maxLines: 3,
                      textInputAction: TextInputAction.done,
                      controller: specialNoteController,
                      onChanged: (value) {
                        specialNote = value;
                      },
                      onSaved: (value) {
                        specialNote = value;
                      },
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        hintText: 'Special Note For Order (Optional)',
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(6),
                            borderSide: const BorderSide(color: Colors.black)),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(6),
                            borderSide:
                                const BorderSide(color: Color(0xFFD0D1D2))),
                      ),
                    ),
                  ),
                ],
              )),
        ),
        SliverToBoxAdapter(
          child: Container(
            height: 50,
            width: double.infinity,
            margin: const EdgeInsets.symmetric(horizontal: 16),
            child: ElevatedButton(
              onPressed: () async {
                try {
                  final result = await InternetAddress.lookup('example.com');
                  if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                    if (Provider.of<OrderDetailsInfoNotifier>(context,
                                listen: false)
                            .isPress ==
                        0) {
                      Provider.of<OrderDetailsInfoNotifier>(context,
                              listen: false)
                          .changePressValue(1);
                      if (paymentRG == 1) {
                        downPrice = 0;
                        makeOrder();
                      } else if (paymentRG == 2) {
                        if (_azura3InsFormKey.currentState!.validate()) {
                          _azura3InsFormKey.currentState!.save();
                          downPrice =
                              int.parse(_down3PaymentTextController.text);
                          makeOrder();
                        }
                      } else if (paymentRG == 3) {
                        if (_azura6InsFormKey.currentState!.validate()) {
                          _azura6InsFormKey.currentState!.save();
                          downPrice =
                              int.parse(_down6PaymentTextController.text);
                          makeOrder();
                        }
                      }
                    } else {}
                  }
                } on SocketException catch (_) {
                  Common.toastMsg('No internet Connection');
                }
              },
              style: ElevatedButton.styleFrom(
                  primary: AppsColors.buttonColor,
                  shape: const StadiumBorder()),
              child:
                  Provider.of<OrderDetailsInfoNotifier>(context, listen: false)
                              .isPress ==
                          0
                      ? const Text(
                          'Pay Now',
                          style: TextStyle(
                            color: Colors.white,
                          ),
                        )
                      : const Center(
                          child: SizedBox(
                            height: 16,
                            width: 16,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 1,
                            ),
                          ),
                        ),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 30,
          ),
        ),
      ],
    );
  }
}
