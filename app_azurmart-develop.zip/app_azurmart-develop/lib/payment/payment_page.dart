import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/floating_action_button.dart';
import 'package:azuramartmy/my_bloc/cart_bloc.dart';
import 'package:azuramartmy/payment/payment_body2.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PaymentPage extends StatelessWidget {
   PaymentPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => PaymentPage());
  }

  Future<void> reload() async {
    try {
      final result = await InternetAddress.lookup('example.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        return cartBloc.fetchAllCarts();
      }
    } on SocketException catch (_) {
      Common.toastMsg('No Internet Connection');
      return;
    }
  }

  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
  GlobalKey<RefreshIndicatorState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFB),
      appBar: AppBar(
        title: const Text(
          'Payment',
          style: TextStyle(color: Colors.black87),
        ),
        backgroundColor: const Color(0xFFFAFAFB),

        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
        elevation: 0,
      ),
      body: SafeArea(
        child: RefreshIndicator(
          key: _refreshIndicatorKey,
          color: const Color(0xFFF68721),
          onRefresh: reload,
          child: const PaymentBody2(),
        ),
      ),
      floatingActionButton: MyFloatingActionButton(
        snapshot: SharedPreferenceUtils.whatsappModel,
      ),
    );
  }
}
