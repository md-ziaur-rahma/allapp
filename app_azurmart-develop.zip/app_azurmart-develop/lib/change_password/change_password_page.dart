import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/login/login_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/ip_address.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({Key? key}) : super(key: key);

  static Route route(){
    return MaterialPageRoute(builder: (_) => ChangePassword());
  }

  @override
  _ChangePasswordState createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {

  final GlobalKey<FormState> _changePasswordFormKey = GlobalKey<FormState>();
  var oldPasswordController = TextEditingController();
  var passwordController = TextEditingController();
  var confirmPasswordController = TextEditingController();
  String? oldPassword;
  String? password;
  String? confirmPassword;

  String? validationOldPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Old Password!';
    } else if (value.length < 5) {
      return 'Enter minimum 5 digit';
    } else {
      return null;
    }
  }
  String? validationPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Password!';
    } else if (value.length < 5) {
      return 'Enter minimum 5 digit';
    } else {
      return null;
    }
  }
  String? validationConfirmPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Confirm Password!';
    } else if (value.compareTo(passwordController.text.toString()) == 0) {
      return null;
    } else {
      return 'Doesn\'t match with password';
    }
  }

  bool _obscureText = true;
  void _toggle() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  Future<void> changePassword() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    Map<String, dynamic> data = {
      'current_password': '$oldPassword',
      'new_password': '$password',
      'user_id': '$userId',
      'token': '$token',
      'session': '$session',
    };
    var requestBody = json.encode(data);
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.changePassword);
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      print('parsed');
      if (body["status"] == 1) {
        /// arif vai er suggestion e redirect to login page...
        Common.toastMsg('${body["message"]}');
        Navigator.pushAndRemoveUntil(
            context, LoginPage.route(), (route) => false);
      } else {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(content: Text('${body["message"]}')));
      }
    } on FormatException catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    _obscureText = true;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 0),
          child: CustomScrollView(
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            slivers: [
              SliverToBoxAdapter(
                child: Align(
                  alignment: Alignment.topLeft,
                  child: IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.close,
                      size: 24,
                    ),
                  ),
                ),
              ),
              const SliverToBoxAdapter(
                child: SizedBox(
                  height: 16,
                ),
              ),
              const SliverToBoxAdapter(
                child: SizedBox(
                  width: double.infinity,
                  child: Center(
                    child: Image(
                      image: AssetImage('images/azura_logo_large.png'),
                      width: 80,
                      height: 80,
                    ),
                  ),
                ),
              ),
              const SliverToBoxAdapter(
                child: SizedBox(
                  height: 50,
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Form(
                    key: _changePasswordFormKey,
                    child: Column(
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: TextFormField(
                            textAlign: TextAlign.start,
                            style: const TextStyle(
                                color: Colors.black87,
                                fontSize: 18,
                                fontWeight: FontWeight.w600),
                            controller: oldPasswordController,
                            validator: validationOldPassword,
                            textInputAction: TextInputAction.next,
                            keyboardType: TextInputType.visiblePassword,
                            obscureText: _obscureText,
                            maxLines: 1,
                            cursorColor: Colors.black87,
                            onSaved: (String? val) {
                              oldPassword = val;
                            },
                            decoration: InputDecoration(
                              suffixIcon: GestureDetector(
                                onTap: () {
                                  _toggle();
                                },
                                child: _obscureText
                                    ? const Icon(
                                  Icons.visibility_off,
                                  color: Colors.black54,
                                )
                                    : const Icon(
                                  Icons.visibility,
                                  color: Colors.black54,
                                ),
                              ),
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 16),
                              fillColor: const Color(0xFFD1D2D3).withOpacity(0.4),
                              filled: true,
                              hintText: 'Current Password',
                              focusedBorder: InputBorder.none,
                              border: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                            ),
                          ),
                        ),

                        const SizedBox(
                          height: 20,
                        ),
                        const SizedBox(
                          width: double.infinity,
                          child: Text('Please enter your new password below',style: TextStyle(color: Colors.black,fontSize: 16),),
                        ),

                        const SizedBox(
                          height: 16,
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: TextFormField(
                            textAlign: TextAlign.start,
                            style: const TextStyle(
                                color: Colors.black87,
                                fontSize: 18,
                                fontWeight: FontWeight.w600),
                            controller: passwordController,
                            validator: validationPassword,
                            textInputAction: TextInputAction.next,
                            keyboardType: TextInputType.visiblePassword,
                            obscureText: _obscureText,
                            maxLines: 1,
                            cursorColor: Colors.black87,
                            onSaved: (String? val) {
                              password = val;
                            },
                            decoration: InputDecoration(
                              suffixIcon: GestureDetector(
                                onTap: () {
                                  _toggle();
                                },
                                child: _obscureText
                                    ? const Icon(
                                  Icons.visibility_off,
                                  color: Colors.black54,
                                )
                                    : const Icon(
                                  Icons.visibility,
                                  color: Colors.black54,
                                ),
                              ),
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 16),
                              fillColor: const Color(0xFFD1D2D3).withOpacity(0.4),
                              filled: true,
                              hintText: 'New Password',
                              focusedBorder: InputBorder.none,
                              border: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: TextFormField(
                            textAlign: TextAlign.start,
                            style: const TextStyle(
                                color: Colors.black87,
                                fontSize: 18,
                                fontWeight: FontWeight.w600),
                            controller: confirmPasswordController,
                            validator: validationConfirmPassword,
                            textInputAction: TextInputAction.done,
                            keyboardType: TextInputType.visiblePassword,
                            obscureText: _obscureText,
                            maxLines: 1,
                            cursorColor: Colors.black87,
                            onSaved: (String? val) {
                              confirmPassword = val;
                            },
                            decoration: InputDecoration(
                              suffixIcon: GestureDetector(
                                onTap: () {
                                  _toggle();
                                },
                                child: _obscureText
                                    ? const Icon(
                                  Icons.visibility_off,
                                  color: Colors.black54,
                                )
                                    : const Icon(
                                  Icons.visibility,
                                  color: Colors.black54,
                                ),
                              ),
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 16),
                              fillColor: const Color(0xFFD1D2D3).withOpacity(0.4),
                              filled: true,
                              hintText: 'Confirm New Password',
                              focusedBorder: InputBorder.none,
                              border: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                            ),
                          ),
                        ),

                        const SizedBox(
                          height: 16,
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        SizedBox(
                          height: 50,
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () async {
                              if (_changePasswordFormKey.currentState!.validate()) {
                                _changePasswordFormKey.currentState!.save();
                                try {
                                  final result = await InternetAddress.lookup('example.com');
                                  if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                                    changePassword();
                                  }
                                } on SocketException catch (_) {
                                  Common.toastMsg('No Internet Connection');
                                }
                              }
                            },
                            style: ElevatedButton.styleFrom(
                                primary: AppsColors.buttonColor,
                                shape: const RoundedRectangleBorder(
                                    borderRadius:
                                    BorderRadius.all(Radius.circular(6.0)))),
                            child: const Text(
                              'Change Password',
                              style: TextStyle(
                                  color: Colors.white, fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
