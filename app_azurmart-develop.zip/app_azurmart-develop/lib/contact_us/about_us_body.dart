import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactUsBody extends StatefulWidget {
  const ContactUsBody({Key? key}) : super(key: key);

  @override
  _ContactUsBodyState createState() => _ContactUsBodyState();
}

class _ContactUsBodyState extends State<ContactUsBody> {
  Future<void> _makePhoneCall(String url) async {
    Common.toastMsg('entered call method');
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  _makeEmail() async {
    String mailUrl = 'mailto:ziariyad018@gmail.com?subject=&body=';
    if (canLaunch(mailUrl) != null) {
      await launch(mailUrl);
    } else {
      throw 'Could not launch $mailUrl';
    }
  }

  openFacebookApp() async {
    String profile = 'https://www.facebook.com/ziariyadfeni/';
    if (canLaunch(profile) != null) {
      await launch(profile, forceSafariVC: false, forceWebView: false);
    } else {
      throw 'Could not launch $profile';
    }
  }

  openInstagramApp() async {
    String profile = 'https://www.instagram.com/azuramart/';
    if (canLaunch(profile) != null) {
      await launch(profile, forceSafariVC: false, forceWebView: false);
    } else {
      throw 'Could not launch $profile';
    }
  }

  launchURL() async {
    const String homeLat = "5.393481";
    const String homeLng = "100.404347";

    const String googleMapsLocationUrl =
        "https://www.google.com/maps/search/?api=1&query=$homeLat,$homeLng";
    final String encodedURl = Uri.encodeFull(googleMapsLocationUrl);
    if (await canLaunch(encodedURl)) {
      await launch(encodedURl);
    } else {
      print('Could not launch $encodedURl');
      throw 'Could not launch $encodedURl';
    }
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      scrollDirection: Axis.vertical,
      slivers: [
        SliverToBoxAdapter(
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              GestureDetector(
                onTap: () {
                  // MapUtils.openMap(-3.823216,-38.481700);
                },
                child: Container(
                  width: double.infinity,
                  height:
                      MediaQuery.of(context).orientation == Orientation.portrait
                          ? MediaQuery.of(context).size.width * 0.7
                          : MediaQuery.of(context).size.height * 0.7,
                  color: Colors.amber,
                  child: GestureDetector(
                    onTap: () {
                      if (SharedPreferenceUtils.appSettingModel.data!.googlemap != null) {
                        setState(() {
                          Common.openMap();
                        });
                      }  else {
                        Common.toastMsg('Location Not Found');
                      }
                    },
                    child: const Image(
                      image: AssetImage('images/app_images/azura_map.PNG'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: -20,
                left: 0,
                right: 0,
                child: Container(
                  width: double.infinity,
                  height: 80,
                  margin: const EdgeInsets.symmetric(horizontal: 17),
                  // padding: EdgeInsets.symmetric(vertical: 20),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10.0)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Flexible(
                        flex: 1,
                        child: Center(
                          child: Material(
                            color: Colors.transparent,
                            child: Ink(
                              decoration: const ShapeDecoration(
                                color: Colors.green,
                                shape: CircleBorder(),
                              ),
                              child: IconButton(
                                onPressed: () {
                                  if (SharedPreferenceUtils.appSettingModel.data!.phone1 != null) {
                                    setState(() {
                                      Common.makePhoneCall(SharedPreferenceUtils.appSettingModel.data!.phone1);
                                    });
                                  }  else {
                                    Common.toastMsg('Contact Number Not Found');
                                  }
                                },
                                icon: const FaIcon(
                                  FontAwesomeIcons.phone,
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),

                      Flexible(
                        flex: 1,
                        child: Center(
                          child: Material(
                            color: Colors.transparent,
                            child: Ink(
                              decoration: const ShapeDecoration(
                                color: Colors.orangeAccent,
                                shape: CircleBorder(),
                              ),
                              child: IconButton(
                                onPressed: () {
                                  if (SharedPreferenceUtils.appSettingModel.data!.googlemap != null) {
                                    setState(() {
                                      Common.openMap();
                                    });
                                  }  else {
                                    Common.toastMsg('Location Not Found');
                                  }
                                },
                                icon: const Icon(
                                  Icons.location_on_outlined,
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Flexible(
                        flex: 1,
                        child: Center(
                          child: Material(
                            color: Colors.transparent,
                            child: Ink(
                              decoration: const ShapeDecoration(
                                color: Colors.deepOrange,
                                shape: CircleBorder(),
                              ),
                              child: IconButton(
                                onPressed: () {
                                  if (SharedPreferenceUtils.appSettingModel.data!.instagramurl != null) {
                                    setState(() {
                                      Common.openFacebookApp(SharedPreferenceUtils.appSettingModel.data!.instagramurl!);
                                    });

                                  }  else {
                                    Common.toastMsg('Url Not Found');
                                  }
                                },
                                icon: const FaIcon(
                                  FontAwesomeIcons.instagram,
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Flexible(
                        flex: 1,
                        child: Center(
                          child: Material(
                            color: Colors.transparent,
                            child: Ink(
                              decoration: const ShapeDecoration(
                                color: Colors.blueAccent,
                                shape: CircleBorder(),
                              ),
                              child: IconButton(
                                onPressed: () {
                                  if (SharedPreferenceUtils.appSettingModel.data!.facebookurl != null) {
                                    setState(() {
                                      Common.openInstagramApp(SharedPreferenceUtils.appSettingModel.data!.facebookurl!);
                                    });
                                  }  else {
                                    Common.toastMsg('Url Not Found');
                                  }
                                },
                                icon: const FaIcon(
                                  FontAwesomeIcons.facebook,
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: ListTile(
                  tileColor: Colors.transparent,
                  leading: IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.arrow_back,
                      color: Colors.black,
                    ),
                  ),
                  title: const Text(
                    'Contact Us',
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                        fontSize: 20),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 35,
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Expanded(
                      flex: 1,
                      child: Icon(
                        Icons.location_on_outlined,
                        color: Colors.black54,
                        size: 20,
                      )),
                  Expanded(
                    flex: 6,
                    child: Column(
                      children: [
                        const SizedBox(
                          width: double.infinity,
                          child: Text(
                            'Malaysia Address',
                            textAlign: TextAlign.start,
                            style:
                                TextStyle(color: Colors.black54, fontSize: 16),
                          ),
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        SizedBox(
                            width: double.infinity,
                            child: Text(
                              '${SharedPreferenceUtils.appSettingModel.data!.hqaddress}',
                              style: const TextStyle(
                                  color: Colors.black87,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600),
                            ))
                      ],
                    ),
                  )
                ],
              )),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 16,
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Expanded(
                      flex: 1,
                      child: Icon(
                        Icons.location_on_outlined,
                        color: Colors.black54,
                        size: 20,
                      )),
                  Expanded(
                    flex: 6,
                    child: Column(
                      children: const [
                        SizedBox(
                          width: double.infinity,
                          child: Text(
                            'UK Address',
                            textAlign: TextAlign.start,
                            style:
                                TextStyle(color: Colors.black54, fontSize: 16),
                          ),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        SizedBox(
                            width: double.infinity,
                            child: Text(
                              '3 Brookside Court, Bucknell Road, Bicester, OX26 2AB, UK.',
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600),
                            ))
                      ],
                    ),
                  )
                ],
              )),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 16,
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Expanded(
                      flex: 1,
                      child: Icon(
                        Icons.email_outlined,
                        color: Colors.black54,
                        size: 20,
                      )),
                  Expanded(
                    flex: 6,
                    child: Column(
                      children: [
                        const SizedBox(
                          width: double.infinity,
                          child: Text(
                            'Email',
                            textAlign: TextAlign.start,
                            style:
                                TextStyle(color: Colors.black54, fontSize: 16),
                          ),
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: GestureDetector(
                            onTap: () {
                              if (SharedPreferenceUtils.appSettingModel.data!.email1 != null) {
                                setState(() {
                                  Common.makeEmail(SharedPreferenceUtils.appSettingModel.data!.email1,"","");
                                });
                              }  else {
                                Common.toastMsg('Url Not Found');
                              }
                            },
                            child: Text(
                              '${SharedPreferenceUtils.appSettingModel.data!.email1}',
                              style: const TextStyle(
                                  color: Colors.deepOrangeAccent,
                                  fontSize: 18,
                                  // decoration: TextDecoration.underline,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              )),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 16,
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Expanded(
                      flex: 1,
                      child: Icon(
                        Icons.call_rounded,
                        color: Colors.black54,
                        size: 20,
                      )),
                  Expanded(
                    flex: 6,
                    child: Column(
                      children: [
                        const SizedBox(
                          width: double.infinity,
                          child: Text(
                            'Customer Care',
                            textAlign: TextAlign.start,
                            style:
                                TextStyle(color: Colors.black54, fontSize: 16),
                          ),
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: GestureDetector(
                            onTap: () {
                              if (SharedPreferenceUtils.appSettingModel.data!.phone1 != null) {
                                setState(() {
                                  Common.makePhoneCall(SharedPreferenceUtils.appSettingModel.data!.phone1);
                                });
                              }  else {
                                Common.toastMsg('Contact Number Not Found');
                              }
                            },
                            child: Text(
                              '+${SharedPreferenceUtils.appSettingModel.data!.phone1}',
                              style: const TextStyle(
                                  color: Colors.green,
                                  fontSize: 18,
                                  // decoration: TextDecoration.underline,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              )),
        ),
      ],
    );
  }
}
