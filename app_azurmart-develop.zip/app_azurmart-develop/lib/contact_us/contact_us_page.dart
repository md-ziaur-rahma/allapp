import 'package:azuramartmy/common_widgets/floating_action_button.dart';
import 'package:azuramartmy/contact_us/about_us_body.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';

class ContactUsPage extends StatefulWidget {
  const ContactUsPage({Key? key}) : super(key: key);
  static Route route(){
    return MaterialPageRoute(builder: (_) => const ContactUsPage());
  }

  @override
  _ContactUsPageState createState() => _ContactUsPageState();
}

class _ContactUsPageState extends State<ContactUsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: const SafeArea(
        child: ContactUsBody(),
      ),
      floatingActionButton: MyFloatingActionButton(snapshot: SharedPreferenceUtils.whatsappModel,),
    );
  }
}
