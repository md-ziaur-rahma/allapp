import 'dart:io';

import 'package:azuramartmy/cart/cart_page.dart';
import 'package:azuramartmy/common_widgets/floating_action_button.dart';
import 'package:azuramartmy/home/home_page.dart';
import 'package:azuramartmy/my_bloc/cart_count_bloc.dart';
import 'package:azuramartmy/newest_screen/newest_view.dart';
import 'package:azuramartmy/provider_models/cart_count_model.dart';
import 'package:azuramartmy/search/search_page.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class NewestPage extends StatefulWidget {
  const NewestPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const NewestPage());
  }

  @override
  _NewestPageState createState() => _NewestPageState();
}

class _NewestPageState extends State<NewestPage> {

  // void _portraitModeOnly() {
  //   SystemChrome.setPreferredOrientations([
  //     DeviceOrientation.portraitUp,
  //     DeviceOrientation.portraitDown,
  //   ]);
  // }

  @override
  void initState() {
    // _portraitModeOnly();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    cartCountBloc.fetchAllCartCount();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
        title: const Text(
          'New Arrival',
          style: TextStyle(color: Colors.black),
        ),
        actions: [
          IconButton(
              onPressed: () {
                Navigator.push(context, SearchPage.route());
              },
              icon: const Icon(
                Icons.search,
                size: 20,
                color: Colors.black,
              )),
          // IconButton(
          //     onPressed: () {},
          //     icon: Icon(
          //       Icons.filter_alt_outlined,
          //       size: 20,
          //       color: Colors.black,
          //     )),
          Stack(
            children: [
              SizedBox(
                height: double.infinity,
                child: Ink(
                  decoration: const ShapeDecoration(
                    color: Color(0xFFFFFFFF),
                    shape: CircleBorder(),
                  ),
                  child: IconButton(
                      onPressed: () {
                        Navigator.push(context, CartPage.route());
                      },
                      icon: const Icon(
                        Icons.shopping_cart_outlined,
                        size: 20,
                        color: Colors.black,
                      )),
                ),
              ),
              Positioned(
                right: 12,
                bottom: 12,
                child: StreamBuilder(
                  stream: cartCountBloc.allCartCount,
                  builder: (context, AsyncSnapshot<CartCountModel> snapshot) {
                    if (snapshot.hasData) {
                      return Container(
                        padding: const EdgeInsets.all(4.0),
                        decoration: const ShapeDecoration(
                            shape: CircleBorder(), color: Color(0xFFF68721)),
                        child: Text(
                          '${snapshot.data!.data!.cartqtycount}',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 8, color: Colors.white),
                        ),
                      );
                    }
                    return const Text('');
                  },
                ),
              )
            ],
          ),
        ],
      ),
      body: const SafeArea(
        child: NewestBody(),
      ),
      floatingActionButton: MyFloatingActionButton(snapshot: SharedPreferenceUtils.whatsappModel,),
      bottomNavigationBar: const HomeBottomNavBar(isHome: 0,),
    );
  }
}
