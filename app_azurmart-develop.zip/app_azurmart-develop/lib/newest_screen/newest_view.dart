import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_notifier/common_notifier.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/wishlist/add_to_wish.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:azuramartmy/my_bloc/new_arrival_product_bloc.dart';
import 'package:azuramartmy/provider_models/new_arrival_item_model.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';

class NewestBody extends StatefulWidget {
  const NewestBody({Key? key}) : super(key: key);

  @override
  _NewestBodyState createState() => _NewestBodyState();
}

class _NewestBodyState extends State<NewestBody> {
  NewArrivalItemModel latestProductModel = NewArrivalItemModel();
  bool canLoading = true;

  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
      GlobalKey<RefreshIndicatorState>();

  Future<void> reload() async {
    try {
      final result = await InternetAddress.lookup('example.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        latestProductModel.data = [];
        newProductBloc.page = 1;
        return newProductBloc.fetchAllNewProduct();
      }
    } on SocketException catch (_) {
      Common.toastMsg('No Internet Connection');
      return;
    }
  }

  @override
  void initState() {
    latestProductModel.data = [];
    canLoading = true;
    newProductBloc.page = 1;
    newProductBloc.fetchAllNewProduct();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    return RefreshIndicator(
      key: _refreshIndicatorKey,
      child: StreamBuilder(
          stream: newProductBloc.allNewProduct,
          builder: (context, AsyncSnapshot<NewArrivalItemModel> snapshot) {
            if (snapshot.hasData) {
              // context.read<CommonNotifier>().changeLoading(false);
              Provider.of<CommonNotifier>(context,listen: false).changeLoading(false);
              if (snapshot.data!.data!.isEmpty) {
                canLoading = false;
              } else {
                if (snapshot.data!.data!.length < 10) {
                  canLoading = false;
                }
                for (var i = 0; i < snapshot.data!.data!.length; i++) {
                  latestProductModel.data!.add(snapshot.data!.data![i]);
                }
              }
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12.0),
                child: CustomScrollView(
                  scrollDirection: Axis.vertical,
                  slivers: [
                    const SliverToBoxAdapter(
                      child: SizedBox(
                        height: 12,
                      ),
                    ),
                    SliverGrid(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: MediaQuery.of(context).orientation ==
                                Orientation.portrait
                            ? 2
                            : MediaQuery.of(context).size.width > 740
                                ? 4
                                : 3,
                        childAspectRatio: screenWidth / 180.0,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                      ),
                      delegate: SliverChildBuilderDelegate(
                        (BuildContext context, int index) {
                          if (index == (latestProductModel.data!.length - 1) &&
                              canLoading) {
                            Provider.of<CommonNotifier>(context,listen: false).changeLoading(true);
                            // context.read<CommonNotifier>().changeLoading(true);
                            newProductBloc.fetchLatestPagingProduct();
                          }
                          return LatestProductCard(
                            latestProductModel: latestProductModel,
                            index: index,
                          );
                        },
                        childCount: latestProductModel.data!.length,
                      ),
                    ),
                    SliverLayoutBuilder(
                      builder: (BuildContext context, SliverConstraints constraints) {
                        if (Provider.of<CommonNotifier>(context, listen: false).isLoading) {
                          return SliverToBoxAdapter(
                            child: Center(
                              child: Container(
                                margin: const EdgeInsets.symmetric(vertical: 16),
                                height: 20,
                                width: 20,
                                child: const CupertinoActivityIndicator(
                                  animating: true,
                                  radius: 12,
                                ),
                              ),
                            ),
                          );
                        }  else{
                          return const SliverToBoxAdapter(
                            child: Center(
                              child: SizedBox(
                                height: 6,
                              )
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              );
            } else if (snapshot.hasError) {
              return Center(
                child: Text(snapshot.error.toString()),
              );
            }
            return LoadingWidget(color: AppsColors.buttonColor,);
          }),
      onRefresh: reload,
    );
  }
}

class NewestChangeLayoutBtns extends StatelessWidget {
  const NewestChangeLayoutBtns({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
            margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: const Text(
              'Collection 2019',
              style: TextStyle(color: Colors.black),
            )),
        const Spacer(),
        IconButton(
            onPressed: () {
              Common.isGrid = 1;
            },
            icon: const Icon(
              Icons.grid_view,
              color: Colors.black,
              size: 16,
            )),
        IconButton(
            onPressed: () {
              Common.isGrid = 0;
            },
            icon: const Icon(
              Icons.list,
              color: Colors.black,
              size: 16,
            )),
      ],
    );
  }
}

class LatestProductCard extends StatefulWidget {
  const LatestProductCard({Key? key, this.latestProductModel, required this.index})
      : super(key: key);

  final NewArrivalItemModel? latestProductModel;
  final int index;

  @override
  _LatestProductCardState createState() => _LatestProductCardState();
}

class _LatestProductCardState extends State<LatestProductCard> {
  int toggleMsg = 0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ProductDetailsPage.productUrl =
                widget.latestProductModel!.data![widget.index].url;
            ProductDetailsPage.variantPk =
                widget.latestProductModel!.data![widget.index].pkno;
            ProductDetailsPage.isWish =
                widget.latestProductModel!.data![widget.index].isWish;
            Navigator.of(context).push(
                CustomRoutePageBuilder
                    .createPageRouteLeft(
                    context, const ProductDetailsPage()));
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: Container(
        padding: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(6.0),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Flexible(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: const Color(0xFFFFFFFF).withOpacity(0.2),
                ),
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: ConstrainedBox(
                        constraints:
                        const BoxConstraints(minHeight: 80, maxHeight: 120),
                        child: Container(
                            //widget.latestProductModel.data[widget.index].primaryimgrelativepath,
                            child: widget.latestProductModel!.data![widget.index]
                                        .primaryimgrelativepath ==
                                    null
                                ? const NoImageWidget(
                                    text: 'No Image',
                                  )
                                : CacheImageProvide(
                                    url: widget
                                        .latestProductModel!
                                        .data![widget.index]
                                        .primaryimgrelativepath,
                                  )),
                      ),
                    ),
                    Align(
                      alignment: Alignment.topRight,
                      child: Ink(
                        decoration: const ShapeDecoration(
                          color: Color(0xFFF4F4F4),
                          shape: CircleBorder(),
                        ),
                        child: IconButton(
                          onPressed: () async {
                            try {
                              final result =
                                  await InternetAddress.lookup('example.com');
                              if (result.isNotEmpty &&
                                  result[0].rawAddress.isNotEmpty) {
                                setState(() {
                                  widget.latestProductModel!.data![widget.index]
                                      .isWish = widget.latestProductModel!
                                              .data![widget.index].isWish ==
                                          0
                                      ? 1
                                      : 0;
                                  AddToWish addWish = AddToWish();
                                  addWish.addToWish(widget.latestProductModel!
                                      .data![widget.index].pkno);
                                });
                              }
                            } on SocketException catch (_) {
                              Common.toastMsg('No Internet Connection');
                            }
                          },
                          icon: widget.latestProductModel!.data![widget.index]
                                      .isWish ==
                                  0
                              ? const Icon(
                                  Icons.favorite_outline,
                                  size: 16,
                                  color: Colors.black87,
                                )
                              : Icon(
                                  Icons.favorite,
                                  size: 16,
                                  color: AppsColors.highlightedColor,
                                ),
                        ),
                      ),
                    ),
                    LayoutBuilder(
                      builder:
                          (BuildContext context, BoxConstraints constraints) {
                        if (widget
                                .latestProductModel!.data![widget.index].offer !=
                            0) {
                          return GestureDetector(
                            onTap: () {
                              // setState(() {
                              //   toggleMsg = toggleMsg == 1 ? 0 : 1;
                              // });
                            },
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                height: 45,
                                width: 45,
                                padding: const EdgeInsets.all(3.0),
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.red,
                                ),
                                child: const Center(
                                  child: Text(
                                    'In \nOffer',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 10),
                                  ),
                                ),
                              ),
                            ),
                          );
                        } else {
                          return const Align(
                            alignment: Alignment.topLeft,
                            child: SizedBox(
                              height: 2,
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              //width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.only(left: 10, right: 10, bottom: 0),
                child: RichText(
                  text: TextSpan(
                    text:
                        'RM${widget.latestProductModel!.data![widget.index].regularprice!.toStringAsFixed(2)}',
                    style: TextStyle(
                        color: AppsColors.highlightedColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w600),
                    // children: <TextSpan>[
                    //   TextSpan(
                    //     text:
                    //         '   RM${widget.latestProductModel.data[widget.index].insPrice}',
                    //     style: TextStyle(
                    //         color: Colors.black38,
                    //         fontSize: 10,
                    //         fontWeight: FontWeight.normal),
                    //   )
                    // ]
                  ),
                ),
              ),
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                child: Text(
                  '${widget.latestProductModel!.data![widget.index].variantname}',
                  textAlign: TextAlign.center,
                  maxLines: 3,
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
