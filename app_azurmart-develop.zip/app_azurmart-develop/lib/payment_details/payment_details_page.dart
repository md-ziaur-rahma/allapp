import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/order_details/order_details_page.dart';
import 'package:azuramartmy/provider_models/payment_details_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PaymentDetailsPage extends StatelessWidget {
  const PaymentDetailsPage({Key? key,this.txnId}) : super(key: key);
  final int? txnId;
  Future<PaymentDetailsModel?> fetchPaymentDetails() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Client client = Client();
    var url = Uri.parse(Urls.baseUrl + Urls.paymentDetails);
    print('user balance list ($url)/$token/$txnId');
    try{
      var response = await client.post(url, body: {
        'session': '$session',
        'user_id': '$userId',
        'token': '$token',
        'txn_id': '$txnId',
      });
      print(response.body);
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        PaymentDetailsModel paymentDetailsModel = PaymentDetailsModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return paymentDetailsModel;
        }
      } else {
        throw Exception('Failed to load post');
      }
    } on Exception catch (e) {
      print(e);
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Payment Details',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: AppsColors.buttonColor,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : SystemUiOverlayStyle(
            statusBarColor: AppsColors.buttonColor,
            statusBarIconBrightness: Brightness.light),
      ),
      body: SafeArea(
        child: FutureBuilder(
            future: fetchPaymentDetails(),
            builder: (BuildContext context, AsyncSnapshot<PaymentDetailsModel?> snapshot) {
              if (snapshot.hasData) {
                return CustomScrollView(
                  scrollDirection: Axis.vertical,
                  slivers: [
                    const SliverToBoxAdapter(
                      child: SizedBox(
                        height: 16,
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: PaymentDetailsCard(snapshot: snapshot,),
                    ),
                    SliverLayoutBuilder(
                      builder: (BuildContext context, SliverConstraints constraints){
                        if (snapshot.data!.data!.orderPayments!.isNotEmpty) {
                          return SliverToBoxAdapter(
                            child: Container(
                              margin: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
                              child: const Text('Payment Applied Orders#',style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),),
                            ),
                          );
                        }  else {
                          return const SliverToBoxAdapter(
                            child: SizedBox(
                              height: 16,
                            ),
                          );
                        }
                      },
                    ),
                    SliverList(
                      delegate: SliverChildBuilderDelegate(
                            (BuildContext context, index){
                          if (snapshot.data!.data!.orderPayments!.isNotEmpty) {
                            return OrderListItemPayment(snapshot: snapshot,index: index,);
                          }  else {
                            return const Center(
                              child: Text('Not Found Payments!',style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),),
                            );
                          }
                        },childCount: snapshot.data!.data!.orderPayments!.length,
                      ),
                    )
                  ],
                );
              }  else if (snapshot.hasError) {
                return Center(
                  child: Text(snapshot.error.toString()),
                );
              }
              return LoadingWidget(color: AppsColors.buttonColor,);
            }
         ),
      ),
    );
  }
}

class PaymentDetailsCard extends StatelessWidget {
  PaymentDetailsCard({Key? key, required this.snapshot,}) : super(key: key);
  final AsyncSnapshot<PaymentDetailsModel?> snapshot;

  final f = DateFormat('MMM-dd-yyyy  hh:mm aa');

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      margin: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(6.0),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: const Color(0xFFF4F4F4),
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'PAY ID #',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  '${snapshot.data!.data!.txn!.code}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Source',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  snapshot.data!.data!.txn!.paymentRemainingMr == 0 ?
                  'Credit' : 'Cash',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Date',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  f.format(DateTime.parse(snapshot.data!.data!.txn!.ssCreatedOn!)),
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Pay Amount',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  'RM${snapshot.data!.data!.txn!.amountBuffer!.toStringAsFixed(2)}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Amount to Apply For Order (s)',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  'RM${snapshot.data!.data!.txn!.amountToOrder!.toStringAsFixed(2)}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Amount to Credit',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  'RM${snapshot.data!.data!.txn!.amountToCredited!.toStringAsFixed(2)}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Slip Number',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  '${snapshot.data!.data!.txn!.slipNumber}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Expanded(
                  flex: 1,
                  child: Text(
                    'Status',
                    style: TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                        fontSize: 16),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Text(
                    snapshot.data!.data!.txn!.isMatched == 1 ?
                    ' Verified ' : ' Not Verified ',
                    textAlign: TextAlign.end,
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.normal,
                        backgroundColor: snapshot.data!.data!.txn!.isMatched == 1 ? Colors.green : Colors.amber,
                        fontSize: 16),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class OrderListItemPayment extends StatelessWidget {
  OrderListItemPayment({Key? key, required this.snapshot, this.index}) : super(key: key);
  final AsyncSnapshot<PaymentDetailsModel?> snapshot;
  final int? index;

  final f = DateFormat('MMM-dd-yyyy  hh:mm aa');

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      margin: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(6.0),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: const Color(0xFFF4F4F4),
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Order #',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  '${snapshot.data!.data!.orderPayments![index!].code}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Source',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  '${snapshot.data!.data!.orderPayments![index!].agent}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Date',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  f.format(DateTime.parse(snapshot.data!.data!.orderPayments![index!].reconfirmTime!)),
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Duo Amount',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  snapshot.data!.data!.orderPayments![index!].due!.toStringAsFixed(2),
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Expanded(
                  flex: 1,
                  child: Text(
                    'Order Total',
                    style: TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                        fontSize: 16),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Text(
                    snapshot.data!.data!.orderPayments![index!].totalPrice!.toStringAsFixed(2),
                    textAlign: TextAlign.end,
                    style: const TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.normal,
                        fontSize: 16),
                  ),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Amount To Apply',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  'RM${snapshot.data!.data!.orderPayments![index!].paymentAmount!.toStringAsFixed(2)}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                TextButton(
                  onPressed: () {
                      Navigator.of(context).push(
                          CustomRoutePageBuilder.createPageRouteLeft(
                              context,
                              OrderDetailsPage(
                                  orderId:
                                  snapshot.data!.data!.orderPayments![index!].fBookingNo)));
                  },
                  child: Text(
                    'Order Details',
                    style: TextStyle(color: AppsColors.blueGreenX),
                  ),
                ),
                const Text(''),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
