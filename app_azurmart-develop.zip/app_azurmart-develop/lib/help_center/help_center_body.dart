import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:azuramartmy/utils/colors.dart';

class HelpCenterBody extends StatelessWidget {
  const HelpCenterBody({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      child: CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          SliverToBoxAdapter(
            child: HelpCenterView(),
          )
        ],
      ),
    );
  }
}

class HelpCenterView extends StatefulWidget {
  const HelpCenterView({Key? key}) : super(key: key);

  @override
  _HelpCenterViewState createState() => _HelpCenterViewState();
}

class _HelpCenterViewState extends State<HelpCenterView> {
  @override
  Widget build(BuildContext context) {
    return Flexible(
        child: Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        TextFormField(
          // initialValue: 'Input text',
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(horizontal: 30),
            hintText: 'Enter your contact number',
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: const BorderSide(color: Colors.black)),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        TextFormField(
          // initialValue: 'Input text',
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(horizontal: 30),
            hintText: 'Enter your email id',
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: const BorderSide(color: Colors.black)),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        TextFormField(
          // initialValue: 'Input text',
          maxLines: 5,
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
            hintText: 'Enter your email id',
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: const BorderSide(color: Colors.black)),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
          ),
        ),
        Container(
          width: double.infinity,
          height: 40,
          margin: const EdgeInsets.symmetric(vertical: 50),
          child: ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
                primary: AppsColors.buttonColor,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30))),
            child: const Text(
              'Submit',
              style: TextStyle(color: Colors.white),
            ),
          ),
        )
      ],
    ));
  }
}
