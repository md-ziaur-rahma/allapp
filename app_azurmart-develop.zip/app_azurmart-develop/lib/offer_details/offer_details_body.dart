import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/common_widgets/no_items.dart';
import 'package:azuramartmy/my_bloc/offer_details_bloc.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/offer_details_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:azuramartmy/utils/custom_route.dart';

class OfferDetailsBody extends StatefulWidget {
  const OfferDetailsBody({Key? key, this.offerName}) : super(key: key);
  final String? offerName;

  @override
  _OfferDetailsBodyState createState() => _OfferDetailsBodyState();
}

class _OfferDetailsBodyState extends State<OfferDetailsBody> {

  @override
  void initState() {
    offerDetailsBloc.fetchAllOfferDetails(widget.offerName!);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return StreamBuilder(
      stream: offerDetailsBloc.allOfferDetails,
      builder: (context, AsyncSnapshot<OfferDetailsModel> snapshot) {
        if (snapshot.hasData) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: CustomScrollView(
              scrollDirection: Axis.vertical,
              slivers: [
                // SliverToBoxAdapter(
                //   child: Stack(
                //     alignment: Alignment.topCenter,
                //     children: [
                //       Container(
                //         height: 60,
                //         decoration: BoxDecoration(
                //             color: Color(0xFFF68721),
                //             borderRadius: BorderRadius.only(
                //                 bottomLeft: Radius.circular(16.0),
                //                 bottomRight: Radius.circular(16.0))),
                //       ),
                //       Container(
                //         height: 100,
                //         margin: const EdgeInsets.symmetric(
                //             horizontal: 20, vertical: 16),
                //         padding: const EdgeInsets.symmetric(
                //             horizontal: 16, vertical: 8),
                //         decoration: BoxDecoration(
                //             borderRadius: BorderRadius.circular(10.0),
                //             color: Colors.white,
                //             boxShadow: [
                //               BoxShadow(
                //                   offset: Offset(1, 0),
                //                   blurRadius: 6.0,
                //                   color: Colors.grey.withOpacity(0.5)),
                //             ]),
                //
                //         child: Center(
                //           child: RichText(
                //             text: TextSpan(
                //                 text: 'AZURAMART ',
                //                 style: TextStyle(color: Colors.black87,fontWeight: FontWeight.w800,fontSize: 18),
                //                 children: <TextSpan>[
                //                   TextSpan(
                //                     text: '| BELIEVE IN YOU',
                //                     style: TextStyle(color: Colors.black87,fontWeight: FontWeight.normal,fontSize: 18),
                //                   )
                //                 ]
                //             ),
                //           ),
                //         ),
                //
                //         // child: Center(
                //         //   child: RichText(
                //         //     text: TextSpan(
                //         //         text: 'Offer : ',
                //         //         style: TextStyle(
                //         //             color: Color(0xFFF68721),
                //         //             fontWeight: FontWeight.w600,
                //         //             fontSize: 18),
                //         //         children: <TextSpan>[
                //         //           TextSpan(
                //         //             text:
                //         //                 '${snapshot.data.data.offer.bundlenamepublic}',
                //         //             style: TextStyle(
                //         //                 color: Colors.black87,
                //         //                 fontWeight: FontWeight.w500,
                //         //                 fontSize: 16),
                //         //           )
                //         //         ]),
                //         //   ),
                //         // ),
                //       ),
                //     ],
                //   ),
                // ),
                const SliverToBoxAdapter(
                  child: SizedBox(
                    height: 16,
                  ),
                ),
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index){
                        return Container(
                          margin: const EdgeInsets.symmetric(vertical: 6),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Expanded(
                                flex: 1,
                                child: Container(
                                  height: 60,
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    // color: Color(0xFFF68721),
                                      gradient: LinearGradient(
                                        colors: [
                                          AppsColors.offerColor,
                                          AppsColors.offerColor.withOpacity(0.8),
                                        ],
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                      ),
                                      borderRadius: const BorderRadius.only(
                                        topLeft: Radius.circular(6.0),
                                        bottomLeft: Radius.circular(6.0),
                                      )),
                                  child: Center(
                                    child: Text(
                                      snapshot.data!.data!.productB!.isNotEmpty
                                          ? 'A List'
                                          : 'Offer',
                                      textAlign: TextAlign.start,
                                      style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 18,
                                          fontWeight: FontWeight.w800),
                                    ),
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 4,
                                child: Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 8),
                                  height: 60,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: const BorderRadius.only(
                                        topRight: Radius.circular(6.0),
                                        bottomRight: Radius.circular(6.0),
                                      ),
                                    border: Border.all(color: AppsColors.offerColor)
                                  ),
                                  child: Text(
                                    '${snapshot.data!.data!.offer![index].bundlenamepublic}',
                                    textAlign: TextAlign.start,
                                    style: TextStyle(
                                        color: AppsColors.offerColor,
                                        fontSize: 16,
                                        fontFamily: 'Lato',
                                        fontWeight: FontWeight.w600),
                                  ),
                                ),
                              )
                            ],
                          ),
                        );
                      },childCount: snapshot.data!.data!.offer!.length
                  ),
                ),
                const SliverToBoxAdapter(
                  child: SizedBox(
                    height: 12,
                  ),
                ),
                SliverGrid(
                  delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) {
                    return Container(
                      child: snapshot.data!.data!.productA!.isEmpty
                          ? const NoItemsCard()
                          : OfferProductsA(snapshot: snapshot, index: index),
                    );
                  }, childCount: snapshot.data!.data!.productA!.length),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: MediaQuery.of(context).orientation ==
                            Orientation.portrait
                        ? 2
                        : MediaQuery.of(context).size.width > 740
                            ? 4
                            : 3,
                    mainAxisSpacing: 16,
                    childAspectRatio: MediaQuery.of(context).orientation ==
                            Orientation.portrait
                        ? screenWidth / 170.0
                        : screenHeight / 140.0,
                    crossAxisSpacing: 16,
                  ),
                ),
                const SliverToBoxAdapter(
                  child: SizedBox(
                    height: 16,
                  ),
                ),
                SliverGrid(
                  delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) {
                    return Container(
                      child: snapshot.data!.data!.productB!.isEmpty
                          ? const NoItemsCard()
                          : OfferProductsA(snapshot: snapshot, index: index),
                    );
                  }, childCount: snapshot.data!.data!.productB!.length),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: MediaQuery.of(context).orientation ==
                            Orientation.portrait
                        ? 2
                        : MediaQuery.of(context).size.width > 740
                            ? 4
                            : 3,
                    mainAxisSpacing: 16,
                    childAspectRatio: MediaQuery.of(context).orientation ==
                            Orientation.portrait
                        ? screenWidth / 170.0
                        : screenHeight / 140.0,
                    crossAxisSpacing: 16,
                  ),
                ),
              ],
            ),
          );
        } else if (snapshot.hasError) {
          return Center(
            child: Text(
              snapshot.error.toString(),
              style: const TextStyle(
                  color: Colors.black87,
                  fontSize: 18,
                  fontWeight: FontWeight.w600),
            ),
          );
        }
        return LoadingWidget(color: AppsColors.buttonColor,);
      },
    );
  }
}

class OfferProductsA extends StatefulWidget {
  const OfferProductsA({Key? key, this.snapshot, this.index}) : super(key: key);
  final AsyncSnapshot<OfferDetailsModel>? snapshot;
  final int? index;

  @override
  _OfferProductsAState createState() => _OfferProductsAState();
}

class _OfferProductsAState extends State<OfferProductsA> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        ProductDetailsPage.productUrl =
            widget.snapshot!.data!.data!.productA![widget.index!].urlslug;
        ProductDetailsPage.variantPk =
            widget.snapshot!.data!.data!.productA![widget.index!].pkno;
        // ProductDetailsPage.isWish = widget.snapshot.data.data.productA[widget.index].isWish;
        Navigator.of(context).push(CustomRoutePageBuilder.createPageRouteLeft(
            context, const ProductDetailsPage()));
      },
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(10.0)),
        width: MediaQuery.of(context).orientation == Orientation.portrait
            ? MediaQuery.of(context).size.width * 0.4
            : MediaQuery.of(context).size.height * 0.4,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ConstrainedBox(
                constraints: const BoxConstraints(
                  maxHeight: 140,
                  minHeight: 60,
                ),
                child: widget.snapshot!.data!.data!.productA![widget.index!]
                            .thumbPath ==
                        null
                    ? const NoImageWidget(
                        text: 'No Image',
                      )
                    : CacheImageProvide(
                        url: widget.snapshot!.data!.data!.productA![widget.index!]
                            .thumbPath,
                      )),
            const SizedBox(
              height: 8,
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  widget.snapshot!.data!.data!.productA![widget.index!].stock! > 0
                      ? 'RM${widget.snapshot!.data!.data!.productA![widget.index!].regularprice!.toStringAsFixed(2)}'
                      : 'Out Of Stock',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppsColors.highlightedColor, fontSize: 16),
                ),
              ),
            ),
            const SizedBox(
              height: 4,
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  '${widget.snapshot!.data!.data!.productA![widget.index!].variantname}',
                  maxLines: 2,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.black87, fontSize: 14),
                ),
              ),
            ),
            const SizedBox(
              height: 8,
            ),
          ],
        ),
      ),
    );
  }
}

class OfferProductsB extends StatefulWidget {
  const OfferProductsB({Key? key, this.snapshot, this.index}) : super(key: key);
  final AsyncSnapshot<OfferDetailsModel>? snapshot;
  final int? index;
  @override
  _OfferProductsBState createState() => _OfferProductsBState();
}

class _OfferProductsBState extends State<OfferProductsB> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        ProductDetailsPage.productUrl =
            widget.snapshot!.data!.data!.productB![widget.index!].urlslug;
        ProductDetailsPage.variantPk =
            widget.snapshot!.data!.data!.productB![widget.index!].pkno;
        // ProductDetailsPage.isWish = widget.snapshot.data.data.productB[widget.index].isWish;
        Navigator.of(context).push(CustomRoutePageBuilder.createPageRouteLeft(
            context, const ProductDetailsPage()));
      },
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(10.0)),
        width: MediaQuery.of(context).orientation == Orientation.portrait
            ? MediaQuery.of(context).size.width * 0.4
            : MediaQuery.of(context).size.height * 0.4,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ConstrainedBox(
                constraints: const BoxConstraints(
                  maxHeight: 140,
                  minHeight: 60,
                ),
                child: widget.snapshot!.data!.data!.productB![widget.index!]
                            .primaryimgrelativepath ==
                        null
                    ? const NoImageWidget(
                        text: 'No Image',
                      )
                    : CacheImageProvide(
                        url: widget.snapshot!.data!.data!.productB![widget.index!]
                            .primaryimgrelativepath,
                      )),
            const SizedBox(
              height: 8,
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  widget.snapshot!.data!.data!.productB![widget.index!].stock! > 0
                      ? 'RM${widget.snapshot!.data!.data!.productB![widget.index!].regularprice!.toStringAsFixed(2)}'
                      : 'Out Of Stock',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppsColors.highlightedColor, fontSize: 16),
                ),
              ),
            ),
            const SizedBox(
              height: 4,
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  '${widget.snapshot!.data!.data!.productB![widget.index!].variantname}',
                  maxLines: 2,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.black87),
                ),
              ),
            ),
            const SizedBox(
              height: 8,
            ),
          ],
        ),
      ),
    );
  }
}
