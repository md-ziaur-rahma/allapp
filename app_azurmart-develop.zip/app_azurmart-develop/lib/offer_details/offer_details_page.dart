import 'dart:io';

import 'package:azuramartmy/common_widgets/floating_action_button.dart';
import 'package:azuramartmy/offer_details/offer_details_body.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class OfferDetailsPage extends StatefulWidget {
  const OfferDetailsPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const OfferDetailsPage());
  }

  static String? offerName = '';

  @override
  _OfferDetailsPageState createState() => _OfferDetailsPageState();
}

class _OfferDetailsPageState extends State<OfferDetailsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: const Text(
          'Offer',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
        ),
        backgroundColor: AppsColors.buttonColor,
        elevation: 3,
        iconTheme: const IconThemeData(color: Colors.white),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.light : SystemUiOverlayStyle(
            statusBarColor: AppsColors.buttonColor,
            statusBarIconBrightness: Brightness.light),
      ),
      body: SafeArea(
        child: OfferDetailsBody(
          offerName: OfferDetailsPage.offerName,
        ),
      ),
      floatingActionButton: MyFloatingActionButton(
        snapshot: SharedPreferenceUtils.whatsappModel,
      ),
    );
  }
}
