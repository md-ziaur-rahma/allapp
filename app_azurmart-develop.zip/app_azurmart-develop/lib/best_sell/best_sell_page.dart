import 'dart:io';

import 'package:azuramartmy/best_sell/best_sell_body.dart';
import 'package:azuramartmy/home/home_page.dart';
import 'package:azuramartmy/search/search_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class BestSellPage extends StatefulWidget {
  const BestSellPage({Key? key}) : super(key: key);

  static Route route(){
    return MaterialPageRoute(builder: (_) => BestSellPage());
  }

  @override
  _BestSellPageState createState() => _BestSellPageState();
}

class _BestSellPageState extends State<BestSellPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'Best Sellers',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: AppsColors.buttonColor,

        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.light : SystemUiOverlayStyle(
            statusBarColor: AppsColors.buttonColor,
            statusBarIconBrightness: Brightness.light),
        actions: [
          IconButton(
              onPressed: () {
                Navigator.push(context, SearchPage.route());
              },
              icon: const Icon(
                Icons.search,
                size: 20,
                color: Colors.white,
              )),
        ],
      ),
      body: const SafeArea(
        child: BestSellBody(),
      ),
      bottomNavigationBar: HomeBottomNavBar(isHome: 0,),
    );
  }
}
