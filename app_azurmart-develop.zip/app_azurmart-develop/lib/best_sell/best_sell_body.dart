import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_notifier/common_notifier.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/common_widgets/no_items.dart';
import 'package:azuramartmy/my_bloc/best_sell_bloc.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/best_sell_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class BestSellBody extends StatefulWidget {
  const BestSellBody({Key? key}) : super(key: key);

  @override
  _BestSellBodyState createState() => _BestSellBodyState();
}

class _BestSellBodyState extends State<BestSellBody>{
  BestSellModel bestSellModel = BestSellModel();
  bool canLoading = true;

  @override
  void initState() {
    bestSellBloc.page = 1;
    bestSellModel.data = [];
    bestSellBloc.fetchAllBestSellProducts();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return StreamBuilder(
      stream: bestSellBloc.allBestSellProduct,
      builder: (context, AsyncSnapshot<BestSellModel> snapshot) {
        if (snapshot.hasData) {
          Provider.of<CommonNotifier>(context,listen: false).changeLoading(false);
          if (snapshot.data!.data!.isEmpty) {
            bestSellBloc.page = 1;
            bestSellBloc.fetchAllBestSellProducts();
            canLoading = false;
          } else {
            if (snapshot.data!.data!.length < 10) {
              canLoading = false;
            }
            for (var i = 0; i < snapshot.data!.data!.length; i++) {
              bestSellModel.data!.add(snapshot.data!.data![i]);
            }
          }
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: CustomScrollView(
              scrollDirection: Axis.vertical,
              slivers: [
                const SliverToBoxAdapter(
                  child: SizedBox(
                    height: 12,
                  ),
                ),
                SliverGrid(
                  delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) {
                    if (index == (bestSellModel.data!.length - 1) &&
                        canLoading) {
                      Provider.of<CommonNotifier>(context,listen: false).changeLoading(true);
                      // context.read<CommonNotifier>().changeLoading(true);
                      bestSellBloc.fetchPagingData();
                    }
                    return Container(
                      child: bestSellModel.data!.isEmpty
                          ? const NoItemsCard()
                          : BestSellProductCard(
                              snapshot: bestSellModel, index: index),
                    );
                  }, childCount: bestSellModel.data!.length),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: MediaQuery.of(context).orientation ==
                            Orientation.portrait
                        ? 2
                        : MediaQuery.of(context).size.width > 740 ? 4 : 3,
                    mainAxisSpacing: 12,
                    childAspectRatio: MediaQuery.of(context).orientation ==
                            Orientation.portrait
                        ? screenWidth / 190.0
                        : screenHeight / 160.0,
                    crossAxisSpacing: 12,
                  ),
                ),
                SliverLayoutBuilder(
                  builder: (BuildContext context, SliverConstraints constraints) {
                    if (Provider.of<CommonNotifier>(context, listen: false).isLoading) {
                      return SliverToBoxAdapter(
                        child: Center(
                          child: Container(
                                margin: const EdgeInsets.symmetric(vertical: 16),
                                height: 20,
                                width: 20,
                                child: const CupertinoActivityIndicator(
                                  animating: true,
                                  radius: 12,
                                ),
                              ),
                        ),
                      );
                    }  else{
                      return const SliverToBoxAdapter(
                        child: Center(
                            child: SizedBox(
                              height: 6,
                            )
                        ),
                      );
                    }
                  },
                ),
              ],
            ),
          );
        } else if (snapshot.hasError) {
          return LoadingWidget(color: AppsColors.buttonColor,);
        }
        return const Center(
          child: SizedBox(
            height: 20.0,
            width: 20,
            child: CircularProgressIndicator(
              color: Color(0xFFF68721),
              strokeWidth: 2.0,
            ),
          ),
        );
      },
    );
  }

}

class BestSellProductCard extends StatefulWidget {
  const BestSellProductCard({Key? key, this.snapshot, this.index})
      : super(key: key);
  final BestSellModel? snapshot;
  final int? index;
  @override
  _BestSellProductCardState createState() => _BestSellProductCardState();
}

class _BestSellProductCardState extends State<BestSellProductCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ProductDetailsPage.productUrl =
                widget.snapshot!.data![widget.index!].url;
            ProductDetailsPage.variantPk =
                widget.snapshot!.data![widget.index!].pkno;
            ProductDetailsPage.isWish =
                widget.snapshot!.data![widget.index!].isWish;
            Navigator.of(context).push(
                CustomRoutePageBuilder
                    .createPageRouteLeft(
                    context, ProductDetailsPage()));
            // Navigator.push(context, ProductDetailsPage.route());
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(10.0),
        ),
        width: MediaQuery.of(context).orientation == Orientation.portrait
            ? MediaQuery.of(context).size.width * 0.4
            : MediaQuery.of(context).size.height * 0.4,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Stack(
              children: [
                Align(
                  alignment: Alignment.center,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(
                      maxHeight: 140,
                      minHeight: 60,
                    ),
                    child: widget.snapshot!.data![widget.index!]
                                .thumbPath ==
                            null
                        ? Center(
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 8),
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: const Color(0xFFF4F4F4), width: 1)),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  Icon(Icons.camera_alt_outlined,size: 20,),
                                  SizedBox(width: 8,),
                                  Text(
                                    'No Image',
                                    style: TextStyle(
                                        color: Colors.black87,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w800),
                                  )
                                ],
                              ),
                            ),
                          )
                        : CacheImageProvide(url: widget.snapshot!.data![widget.index!].thumbPath,),
                  ),
                ),
                LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                    if (widget.snapshot!.data![widget.index!].offer != 0) {
                      return GestureDetector(
                        onTap: () {
                          // setState(() {
                          //   toggleMsg = toggleMsg == 1 ? 0 : 1;
                          // });
                        },
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            height: 45,
                            width: 45,
                            padding: const EdgeInsets.all(3.0),
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.red,
                            ),
                            child: const Center(
                              child: Text(
                                'In \nOffer',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12),
                              ),
                            ),
                          ),
                        ),
                      );
                    } else {
                      return const Align(
                        alignment: Alignment.topLeft,
                        child: SizedBox(
                          height: 2,
                        ),
                      );
                    }
                  },
                ),
              ],
            ),

            const SizedBox(
              height: 8,
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  widget.snapshot!.data![widget.index!].totalfreestock! > 0
                      ? 'RM${widget.snapshot!.data![widget.index!].regularprice!.toStringAsFixed(2)}'
                      : 'Out Of Stock',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppsColors.highlightedColor, fontSize: 14),
                ),
              ),
            ),
            const SizedBox(
              height: 4,
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  '${widget.snapshot!.data![widget.index!].variantname}',
                  maxLines: 3,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.black87,fontSize: 14),
                ),
              ),
            ),
            // const SizedBox(
            //   height: 4,
            // ),
            // SizedBox(
            //   width: double.infinity,
            //   child: Text(
            //     '${widget.snapshot!.data![widget.index!].sellqty} time sell',
            //     textAlign: TextAlign.center,
            //     style: const TextStyle(
            //         color: Colors.black87,
            //         fontSize: 12,
            //         fontWeight: FontWeight.w500),
            //   ),
            // ),
            const SizedBox(
              height: 4,
            ),
          ],
        ),
      ),
    );
  }
}
