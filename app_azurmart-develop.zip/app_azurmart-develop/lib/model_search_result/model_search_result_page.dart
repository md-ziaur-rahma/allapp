import 'dart:io';

import 'package:azuramartmy/model_search_result/model_search_result_body.dart';
import 'package:azuramartmy/my_bloc/model_search_result_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ModelSearchResultPage extends StatefulWidget {
  const ModelSearchResultPage({Key? key}) : super(key: key);

  static int? modelNo;
  static String? keyword;

  static Route route() {
    return MaterialPageRoute(builder: (_) => const ModelSearchResultPage());
  }

  @override
  _ModelSearchResultPageState createState() => _ModelSearchResultPageState();
}

class _ModelSearchResultPageState extends State<ModelSearchResultPage> {
  @override
  void initState() {
    modelSearchResultBloc.page = 1;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: 0,
          titleSpacing: 0,
          backgroundColor: const Color(0xFFFFFFFF),

          iconTheme: const IconThemeData(color: Colors.black87),
          systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
              statusBarColor: Colors.white,
              statusBarIconBrightness: Brightness.dark),
          title: Container(
            height: 42,
            width: double.infinity,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6.0),
                color: const Color(0xFFF2F2F2)),
            child: ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                  primary: const Color(0xFFF2F2F2), elevation: 0),
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  '${ModelSearchResultPage.keyword}',
                  textAlign: TextAlign.start,
                  style: const TextStyle(color: Colors.black87, fontSize: 16),
                ),
              ),
            ),
          ),
        ),
        body: SafeArea(
          child: ModelSearchResultBody(
            modelNo: ModelSearchResultPage.modelNo,
          ),
        )
    );
  }
}
