import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_notifier/common_notifier.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/common_widgets/no_items.dart';
import 'package:azuramartmy/my_bloc/model_search_result_bloc.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/model_search_result_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:provider/provider.dart';

class ModelSearchResultBody extends StatefulWidget {
  const ModelSearchResultBody({Key? key, this.modelNo}) : super(key: key);
  final int? modelNo;

  @override
  _ModelSearchResultBodyState createState() => _ModelSearchResultBodyState();
}

class _ModelSearchResultBodyState extends State<ModelSearchResultBody> {
  ModelSearchResultModel searchModels = ModelSearchResultModel();
  bool canLoading = true;

  @override
  void initState() {
    searchModels.data = [];
    canLoading = true;
    modelSearchResultBloc.fetchAllModelSearchResult(widget.modelNo);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: StreamBuilder(
          stream: modelSearchResultBloc.allModelSearchResult,
          builder: (context, AsyncSnapshot<ModelSearchResultModel> snapshot) {
            if (snapshot.hasData) {
              Provider.of<CommonNotifier>(context, listen: false)
                  .changeLoading(false);
              if (snapshot.data!.data!.isEmpty) {
                canLoading = false;
              } else {
                if (snapshot.data!.data!.length < 10) {
                  canLoading = false;
                }
                for (var i = 0; i < snapshot.data!.data!.length; i++) {
                  searchModels.data!.add(snapshot.data!.data![i]);
                }
              }
              return searchModels.data!.isEmpty
                  ? const NoItemsCard()
                  : CustomScrollView(
                      scrollDirection: Axis.vertical,
                      slivers: [
                        SliverGrid(
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: MediaQuery.of(context)
                                              .orientation ==
                                          Orientation.portrait
                                      ? 2
                                      : MediaQuery.of(context).size.width > 750
                                          ? 4
                                          : 3,
                                  childAspectRatio:
                                      MediaQuery.of(context).orientation ==
                                              Orientation.portrait
                                          ? screenWidth / 180.0
                                          : screenHeight / 160.0,
                                  crossAxisSpacing: 12,
                                  mainAxisSpacing: 12),
                          delegate: SliverChildBuilderDelegate(
                            (BuildContext context, int index) {
                              if (index == (searchModels.data!.length - 1) &&
                                  canLoading) {
                                Provider.of<CommonNotifier>(context,
                                        listen: false)
                                    .changeLoading(true);
                                modelSearchResultBloc
                                    .fetchPagingAllSearch(widget.modelNo);
                              }
                              return Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(horizontal: 0),
                                child: SearchGridItem(searchModels, index),
                              );
                            },
                            childCount: searchModels.data!.length,
                          ),
                        ),
                        SliverLayoutBuilder(
                          builder: (BuildContext context,
                              SliverConstraints constraints) {
                            if (Provider.of<CommonNotifier>(context,
                                    listen: false)
                                .isLoading) {
                              return SliverToBoxAdapter(
                                child: Center(
                                  child: Container(
                                    margin:
                                        const EdgeInsets.symmetric(vertical: 6),
                                    height: 20,
                                    width: 20,
                                    child: const CupertinoActivityIndicator(
                                      animating: true,
                                      radius: 12,
                                    ),
                                  ),
                                ),
                              );
                            } else {
                              return const SliverToBoxAdapter(
                                child: Center(
                                    child: SizedBox(
                                  height: 6,
                                )),
                              );
                            }
                          },
                        ),
                      ],
                    );
            } else if (snapshot.hasError) {
              return Center(
                child: Text(snapshot.error.toString()),
              );
            }
            return LoadingWidget(
              color: AppsColors.buttonColor,
            );
          }),
    );
  }
}

class SearchGridItem extends StatefulWidget {
  final ModelSearchResultModel snapshot;
  final int index;
  const SearchGridItem(this.snapshot, this.index);
  @override
  _SearchGridItemState createState() => _SearchGridItemState();
}

class _SearchGridItemState extends State<SearchGridItem> {
  int isWish = 0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ProductDetailsPage.productUrl =
                widget.snapshot.data![widget.index].url;
            ProductDetailsPage.variantPk =
                widget.snapshot.data![widget.index].pkno;
            ProductDetailsPage.isWish =
                widget.snapshot.data![widget.index].isWish;
            Navigator.of(context).push(
                CustomRoutePageBuilder.createPageRouteLeft(
                    context, ProductDetailsPage()));
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: Container(
        //height: MediaQuery.of(context).size.width * 0.6,
        width: MediaQuery.of(context).size.width * 0.4,
        padding: const EdgeInsets.only(bottom: 8, right: 4, left: 4),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(6.0),
          border:
              Border.all(color: const Color(0xFFD0D1D2).withOpacity(0.3), width: 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              child: Container(
                //height: MediaQuery.of(context).size.width * 0.4,
                width: MediaQuery.of(context).size.width * 0.4,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: const Color(0xFFFFFFFF).withOpacity(0.2),
                ),
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                          padding:
                          const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
                          child: ConstrainedBox(
                              constraints: const BoxConstraints(
                                  minHeight: 60, maxHeight: 120),
                              child: widget.snapshot.data![widget.index]
                                          .primaryimgrelativepath ==
                                      null
                                  ? const NoImageWidget(
                                      text: 'No Image',
                                    )
                                  : CacheImageProvide(
                                      url: widget.snapshot.data![widget.index]
                                          .primaryimgrelativepath,
                                    ))),
                    ),
                    LayoutBuilder(
                      builder:
                          (BuildContext context, BoxConstraints constraints) {
                        if (widget.snapshot.data![widget.index].offer != 0) {
                          return GestureDetector(
                            onTap: () {
                              // setState(() {
                              //   toggleMsg = toggleMsg == 1 ? 0 : 1;
                              // });
                            },
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                height: 45,
                                width: 45,
                                padding: const EdgeInsets.all(3.0),
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.red,
                                ),
                                child: const Center(
                                  child: Text(
                                    'In \nOffer',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 12),
                                  ),
                                ),
                              ),
                            ),
                          );
                        } else {
                          return const Align(
                            alignment: Alignment.topLeft,
                            child: SizedBox(
                              height: 2,
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              child: Padding(
                padding: const EdgeInsets.only(left: 10, right: 10, bottom: 3),
                child: RichText(
                  text: TextSpan(
                    text: widget.snapshot.data![widget.index].totalfreestock! > 0
                        ? 'RM${widget.snapshot.data![widget.index].regularprice!.toStringAsFixed(2)}'
                        : 'Out Of Stock',
                    style: TextStyle(
                        color: AppsColors.highlightedColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                child: Text(
                  '${widget.snapshot.data![widget.index].variantname}',
                  textAlign: TextAlign.center,
                  maxLines: 3,
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
