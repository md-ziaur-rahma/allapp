import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../common.dart';
import '../../utils/url.dart';

class AccountDeletionScreen extends StatefulWidget {
  const AccountDeletionScreen({Key? key}) : super(key: key);

  @override
  State<AccountDeletionScreen> createState() => _AccountDeletionScreenState();
}

class _AccountDeletionScreenState extends State<AccountDeletionScreen> {

  final formKey = GlobalKey<FormState>();

  int intReason = 0;
  int intType = 0;

  bool isChecked = false;
  String type = "Select Type";
  String reason = "Select Reason";
  List<String> typeList = ["Select Type","Deactivation","Deletion"];
  List<String> reasonList = ["Select Reason","I have a duplication account",
    "I no longer want to use azuramart",
    "I am not confident about how treats my private data",
    "Others",];

  bool isLoading = false;
  void changeLoading(bool value){
    setState((){
      isLoading = value;
    });
  }

  void deleteAccount()async{
    changeLoading(true);
    Client client = Client();
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);

    Uri url = Uri.parse("${Urls.baseUrl}${Urls.accountDeletion}");
    try{
      // var response = await client.post(url,body: {"KEYWORD": keyword,"f_shop_no": "${locationController.outletDataModel.data!.fShopNo}","ATTR": "","REQUEST_FOR": "APP"});
      var response = await client.post(url,body: {"user_id": "$userId","type": "$intType","reason": "$intReason","token": "$token"});
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      if (response.statusCode == 200) {
        if (response.body.isNotEmpty) {
          if(body["status"] == 1){
            print("${body["message"]}");

            showDialog(
              context: context,
              builder: (context){
                return CupertinoAlertDialog(
                  title: const Text("Deletion Message"),
                  content: Text("${body["message"]}"),
                  actions: [
                    // SizedBox(),
                    TextButton(
                        onPressed: (){
                          Navigator.pop(context);
                        }, child: const Text("Done"))
                  ],
                );
                // return AlertDialog(
                //   title: const Text("Deletion Message"),
                //   content: Text("${body["message"]}"),
                //   actions: [
                //     ElevatedButton(onPressed: (){
                //       Navigator.pop(context);
                //     }, child: Text("Done"))
                //   ],
                // );
              }
            );

          }else {
            print("Doesn't delete the account!");
            showDialog(
                context: context,
                builder: (context){
                  return CupertinoAlertDialog(
                    title: const Text("Deletion Message"),
                    content: Text("${body["message"]}"),
                    actions: [
                      // SizedBox(),
                      TextButton(
                          onPressed: (){
                        Navigator.pop(context);
                      }, child: const Text("Done"))
                    ],
                  );
                  // return AlertDialog(
                  //   title: const Text("Deletion Message"),
                  //   content: Text("${body["message"]}"),
                  //   actions: [
                  //     ElevatedButton(onPressed: (){
                  //       Navigator.pop(context);
                  //     }, child: Text("Done"))
                  //   ],
                  // );
                }
            );
          }
        }
      }else {
        // Get.snackbar("Error", "Something Went Wrong? Try Again");
        throw Exception('Failed to load post');
      }
      changeLoading(false);
    }on Exception catch(e){
      changeLoading(false);
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Account Deactivation',
          style: TextStyle(color: Colors.black87),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarBrightness: Brightness.dark,
            statusBarIconBrightness: Brightness.dark),
      ),
      body: SafeArea(
        child: ModalProgressHUD(
          inAsyncCall: isLoading,
          child: CustomScrollView(
            slivers: [
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
                sliver: SliverToBoxAdapter(
                  child: Form(
                    key: formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("Important Note",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w500),),
                        const SizedBox(height: 10,),
                        const Text("(1) Your account should not have any active orders or pending refunds",style: TextStyle(color: Colors.black54,fontSize: 14,fontWeight: FontWeight.w400),),
                        const Text("(2) Your account should not have any active installment plans",style: TextStyle(color: Colors.black54,fontSize: 14,fontWeight: FontWeight.w400),),
                        const Text("(3) Any existing vouchers and Coins/Gems in your account will be forfeited",style: TextStyle(color: Colors.black54,fontSize: 14,fontWeight: FontWeight.w400),),
                        const Text("(4) Our customer agent will contact you to verify your identity for security purposes",style: TextStyle(color: Colors.black54,fontSize: 14,fontWeight: FontWeight.w400),),
                        const Text("(5) After successful deactivation/deletion of your account, you will not be able to log in to the account. Account deletion is permanent and will not be reversible.",style: TextStyle(color: Colors.black54,fontSize: 14,fontWeight: FontWeight.w400),),
                        const SizedBox(height: 10,),
                        const Text("***azuramart reserves to reject deactivation/deletion request if any of the criteria has not been met.",style: TextStyle(color: Colors.black54,fontSize: 14,fontWeight: FontWeight.w400),),
                        const SizedBox(height: 10,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            FormField(
                              validator: (value) {
                                if (value == false) {
                                  return 'Required.';
                                }else {
                                  return null;
                                }
                              },
                              builder: (FormFieldState<bool> field) {
                                return Checkbox(
                                    value: isChecked,
                                    checkColor: AppsColors.white,
                                    activeColor: AppsColors.onyxBlack,
                                    onChanged: (value){
                                      setState(() {
                                        isChecked = value!;
                                      });
                                    });
                              },
                            ),

                            const Text("Do you have read the above note?",style: TextStyle(color: Colors.black54,fontSize: 14,fontWeight: FontWeight.w400),),
                          ],
                        ),
                        const SizedBox(height: 10,),
                        const Text("Modification Type*",style: TextStyle(color: Colors.black54,fontSize: 14,fontWeight: FontWeight.w400),),
                        const SizedBox(height: 8,),
                        Container(
                          width: double.infinity,
                          margin: const EdgeInsets.symmetric(horizontal: 0),
                          child: DropdownButtonFormField<String>(
                            // hint: const Text('Select a state'),
                            isExpanded: true,
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.symmetric(horizontal: 10),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(0),
                                  borderSide: const BorderSide(color: Colors.black)),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                            ),
                            focusColor: const Color(0xFFF68721),
                            value: type,
                            icon: const Icon(
                              Icons.arrow_drop_down,
                            ),
                            iconSize: 24,
                            elevation: 3,
                            validator: (value) {
                              if(value == "Select Type"){
                                return "Please select type";
                              } else {
                                return null;
                              }
                            },
                            //underline: SizedBox(),
                            onChanged: (newValue) {
                              intType = typeList.indexOf(newValue!);
                            },
                            items: typeList.map<DropdownMenuItem<String>>((String? value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value!),
                              );
                            }).toList(),
                          ),
                        ),
                        const SizedBox(height: 10,),
                        const Text("Reasons for Deactivation/Deletion*",style: TextStyle(color: Colors.black54,fontSize: 14,fontWeight: FontWeight.w400),),
                        const SizedBox(height: 8,),
                        Container(
                          width: double.infinity,
                          margin: const EdgeInsets.symmetric(horizontal: 0),
                          child: DropdownButtonFormField<String>(
                            // hint: const Text('Select reason'),
                            isExpanded: true,
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.symmetric(horizontal: 10),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(0),
                                  borderSide: const BorderSide(color: Colors.black)),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                            ),
                            focusColor: const Color(0xFFF68721),
                            value: reason,
                            icon: const Icon(
                              Icons.arrow_drop_down,
                            ),
                            iconSize: 24,
                            elevation: 3,
                            validator: (value) {
                              if(value == "Select Reason"){
                                return "Please select reason";
                              } else {
                                return null;
                              }
                            },
                            //underline: SizedBox(),
                            onChanged: (newValue) {
                              intReason = reasonList.indexOf(newValue!);
                            },
                            items: reasonList.map<DropdownMenuItem<String>>((String? value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value!),
                              );
                            }).toList(),
                          ),
                        ),
                        const SizedBox(height: 16,),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(primary: AppsColors.onyxBlack),
                            onPressed: ()async {
                              try {
                                final result =
                                await InternetAddress.lookup('example.com');
                                if (result.isNotEmpty &&
                                    result[0].rawAddress.isNotEmpty) {
                                  if(formKey.currentState!.validate()){
                                    if(isChecked){
                                      deleteAccount();
                                    }else{
                                      Common.toastMsg("Please read note and check");
                                    }
                                  }
                                }
                              } on SocketException catch (_) {
                                Common.toastMsg('No Internet Connection');
                              }
                            },
                            child: const Text("Submit"),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
