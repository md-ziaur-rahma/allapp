import 'dart:io';

import 'package:azuramartmy/common_widgets/floating_action_button.dart';
import 'package:azuramartmy/home/home_page.dart';
import 'package:azuramartmy/login/login_page.dart';
import 'package:azuramartmy/my_account/account_body.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

class MyAccountPage extends StatelessWidget {
  const MyAccountPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const MyAccountPage());
  }

  void clear() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    localStorage.setString(SharedPreferenceUtils.SESSION, const Uuid().v4());
    localStorage.remove(SharedPreferenceUtils.USER_ID);
    localStorage.remove(SharedPreferenceUtils.TOKEN);
    localStorage.remove(SharedPreferenceUtils.EMAIL);
    SharedPreferenceUtils.userIdF = 0;
    SharedPreferenceUtils.emailF = '';
    SharedPreferenceUtils.mobileF = '';
    SharedPreferenceUtils.usernameF = '';
    SharedPreferenceUtils.lastNameF = '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'My Account',
          style: TextStyle(color: Colors.black87),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarBrightness: Brightness.dark,
            statusBarIconBrightness: Brightness.dark),
      ),
      body: const SafeArea(
        child: MyAccountBody(),
      ),
      floatingActionButton: MyFloatingActionButton(snapshot: SharedPreferenceUtils.whatsappModel,),
    );
  }
}
