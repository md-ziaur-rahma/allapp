import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/address_manager/address_manager_page.dart';
import 'package:azuramartmy/cart/cart_page.dart';
import 'package:azuramartmy/change_password/change_password_page.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/edit_profile/edit_profile_page.dart';
import 'package:azuramartmy/login/login_page.dart';
import 'package:azuramartmy/my_account/account_settings/account_setting_screen.dart';
import 'package:azuramartmy/my_payments/my_payments_page.dart';
import 'package:azuramartmy/offers/offers_page.dart';
import 'package:azuramartmy/order_details/order_details_page.dart';
import 'package:azuramartmy/order/order_page.dart';
import 'package:azuramartmy/payment_details/payment_details_page.dart';
import 'package:azuramartmy/provider_models/get_payment_order_model.dart';
import 'package:azuramartmy/provider_models/user_balance_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/order_list/order_list_page.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:azuramartmy/wishlist/wishlist_page.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

class MyAccountBody extends StatelessWidget {
  const MyAccountBody({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          if (MediaQuery.of(context).orientation == Orientation.portrait) {
            return CustomScrollView(
              scrollDirection: Axis.vertical,
              slivers: [
                SliverToBoxAdapter(
                  child: AccountProfileView(),
                ),
                SliverToBoxAdapter(
                  child: Container(
                    height: 45,
                    width: double.infinity,
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    child: OutlinedButton(
                      onPressed: () async {
                        try {
                          final result =
                          await InternetAddress.lookup('example.com');
                          if (result.isNotEmpty &&
                              result[0].rawAddress.isNotEmpty) {
                            Navigator.of(context).push(
                                CustomRoutePageBuilder.createPageRouteLeft(
                                    context, const AccountSettingScreen()));
                          }
                        } on SocketException catch (_) {
                          Common.toastMsg('No Internet Connection');
                        }
                      },
                      child: Row(
                        children: const [
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Text(
                              'Account Settings',
                              style: TextStyle(
                                color: Colors.black87,
                              ),
                            ),
                          ),
                          Spacer(),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Icon(
                              Icons.keyboard_arrow_right,
                              color: Colors.black87,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Container(
                    height: 45,
                    width: double.infinity,
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    child: OutlinedButton(
                      onPressed: () async {
                        try {
                          final result =
                              await InternetAddress.lookup('example.com');
                          if (result.isNotEmpty &&
                              result[0].rawAddress.isNotEmpty) {
                            Navigator.of(context).push(
                                CustomRoutePageBuilder.createPageRouteLeft(
                                    context, const OrderListPage()));
                            // Navigator.push(context, OrderListPage.route());
                          }
                        } on SocketException catch (_) {
                          Common.toastMsg('No Internet Connection');
                        }
                      },
                      child: Row(
                        children: const [
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Text(
                              'My Orders',
                              style: TextStyle(
                                color: Colors.black87,
                              ),
                            ),
                          ),
                          Spacer(),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Icon(
                              Icons.keyboard_arrow_right,
                              color: Colors.black87,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Container(
                    height: 45,
                    width: double.infinity,
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    child: OutlinedButton(
                      onPressed: () async {
                        try {
                          final result =
                              await InternetAddress.lookup('example.com');
                          if (result.isNotEmpty &&
                              result[0].rawAddress.isNotEmpty) {
                            Navigator.of(context).push(
                                CustomRoutePageBuilder.createPageRoute(
                                    context, CartPage()));
                            // Navigator.push(context, CartPage.route());
                          }
                        } on SocketException catch (_) {
                          Common.toastMsg('No Internet Connection');
                        }
                      },
                      child: Row(
                        children: const [
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Text(
                              'My Cart',
                              style: TextStyle(
                                color: Colors.black87,
                              ),
                            ),
                          ),
                          Spacer(),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Icon(
                              Icons.keyboard_arrow_right,
                              color: Colors.black87,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Container(
                    height: 45,
                    width: double.infinity,
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    child: OutlinedButton(
                      onPressed: () async {
                        try {
                          final result =
                              await InternetAddress.lookup('example.com');
                          if (result.isNotEmpty &&
                              result[0].rawAddress.isNotEmpty) {
                            Navigator.of(context).push(
                                CustomRoutePageBuilder.createPageRoute(
                                    context, const WishListPage()));
                            // Navigator.push(context, WishListPage.route());
                          }
                        } on SocketException catch (_) {
                          Common.toastMsg('No Internet Connection');
                        }
                      },
                      child: Row(
                        children: const [
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Text(
                              'My Wishlist',
                              style: TextStyle(
                                color: Colors.black87,
                              ),
                            ),
                          ),
                          Spacer(),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Icon(
                              Icons.keyboard_arrow_right,
                              color: Colors.black87,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Container(
                    height: 45,
                    width: double.infinity,
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    child: OutlinedButton(
                      onPressed: () async {
                        try {
                          final result =
                              await InternetAddress.lookup('example.com');
                          if (result.isNotEmpty &&
                              result[0].rawAddress.isNotEmpty) {
                            Navigator.of(context).push(
                                CustomRoutePageBuilder.createPageRouteLeft(
                                    context, const AddressManagerPage()));
                            // Navigator.push(context, AddressManagerPage.route());
                          }
                        } on SocketException catch (_) {
                          Common.toastMsg('No Internet Connection');
                        }
                      },
                      child: Row(
                        children: const [
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Text(
                              'Address Manager',
                              style: TextStyle(
                                color: Colors.black87,
                              ),
                            ),
                          ),
                          Spacer(),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Icon(
                              Icons.keyboard_arrow_right,
                              color: Colors.black87,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Container(
                    height: 45,
                    width: double.infinity,
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    child: OutlinedButton(
                      onPressed: () async {
                        try {
                          final result =
                              await InternetAddress.lookup('example.com');
                          if (result.isNotEmpty &&
                              result[0].rawAddress.isNotEmpty) {
                            Navigator.of(context).push(
                                CustomRoutePageBuilder.createPageRoute(
                                    context, const OffersPage()));
                            // Navigator.push(context, OffersPage.route());
                          }
                        } on SocketException catch (_) {
                          Common.toastMsg('No Internet Connection');
                        }

                        // Navigator.push(context, CreateAddressPage.route());
                      },
                      child: Row(
                        children: const [
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Text(
                              'My Offers',
                              style: TextStyle(
                                color: Colors.black87,
                              ),
                            ),
                          ),
                          Spacer(),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Icon(
                              Icons.keyboard_arrow_right,
                              color: Colors.black87,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Container(
                    height: 45,
                    width: double.infinity,
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    child: OutlinedButton(
                      onPressed: () async {
                        try {
                          final result =
                          await InternetAddress.lookup('example.com');
                          if (result.isNotEmpty &&
                              result[0].rawAddress.isNotEmpty) {
                            Navigator.of(context).push(
                                CustomRoutePageBuilder.createPageRouteLeft(
                                    context, const MyPayments()));
                            // Navigator.push(context, OffersPage.route());
                          }
                        } on SocketException catch (_) {
                          Common.toastMsg('No Internet Connection');
                        }

                        // Navigator.push(context, CreateAddressPage.route());
                      },
                      child: Row(
                        children: const [
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Text(
                              'My Payments',
                              style: TextStyle(
                                color: Colors.black87,
                              ),
                            ),
                          ),
                          Spacer(),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Icon(
                              Icons.keyboard_arrow_right,
                              color: Colors.black87,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                const SliverToBoxAdapter(
                  child: AccountLogoutBtn(),
                )
              ],
            );
          } else {
            return CustomScrollView(
              scrollDirection: Axis.vertical,
              slivers: [
                SliverToBoxAdapter(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Expanded(
                        flex: 1,
                        child: Column(
                          children: [
                            AccountProfileView(),
                            const AccountLogoutBtn()
                          ],
                        ),
                      ),
                      const SizedBox(
                        width: 16,
                      ),
                      Expanded(
                        flex: 1,
                        child: Column(
                          children: [
                            Container(
                              height: 45,
                              width: double.infinity,
                              margin: const EdgeInsets.symmetric(vertical: 5),
                              child: OutlinedButton(
                                onPressed: () async {
                                  try {
                                    final result =
                                    await InternetAddress.lookup('example.com');
                                    if (result.isNotEmpty &&
                                        result[0].rawAddress.isNotEmpty) {
                                      Navigator.of(context).push(
                                          CustomRoutePageBuilder.createPageRouteLeft(
                                              context, const EditProfilePage()));
                                    }
                                  } on SocketException catch (_) {
                                    Common.toastMsg('No Internet Connection');
                                  }
                                },
                                child: Row(
                                  children: const [
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Text(
                                        'My Profile',
                                        style: TextStyle(
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Icon(
                                        Icons.keyboard_arrow_right,
                                        color: Colors.black87,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              height: 45,
                              width: double.infinity,
                              margin: const EdgeInsets.symmetric(vertical: 5),
                              child: OutlinedButton(
                                onPressed: () async {
                                  try {
                                    final result =
                                    await InternetAddress.lookup('example.com');
                                    if (result.isNotEmpty &&
                                        result[0].rawAddress.isNotEmpty) {
                                      Navigator.of(context).push(
                                          CustomRoutePageBuilder.createPageRoute(
                                              context, const OrderListPage()));
                                      // Navigator.push(context, OrderListPage.route());
                                    }
                                  } on SocketException catch (_) {
                                    Common.toastMsg('No Internet Connection');
                                  }
                                },
                                child: Row(
                                  children: const [
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Text(
                                        'My Orders',
                                        style: TextStyle(
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Icon(
                                        Icons.keyboard_arrow_right,
                                        color: Colors.black87,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              height: 45,
                              width: double.infinity,
                              margin: const EdgeInsets.symmetric(vertical: 5),
                              child: OutlinedButton(
                                onPressed: () async {
                                  try {
                                    final result =
                                    await InternetAddress.lookup('example.com');
                                    if (result.isNotEmpty &&
                                        result[0].rawAddress.isNotEmpty) {
                                      Navigator.of(context).push(
                                          CustomRoutePageBuilder.createPageRoute(
                                              context, CartPage()));
                                      // Navigator.push(context, CartPage.route());
                                    }
                                  } on SocketException catch (_) {
                                    Common.toastMsg('No Internet Connection');
                                  }
                                },
                                child: Row(
                                  children: const [
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Text(
                                        'My Cart',
                                        style: TextStyle(
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Icon(
                                        Icons.keyboard_arrow_right,
                                        color: Colors.black87,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              height: 45,
                              width: double.infinity,
                              margin: const EdgeInsets.symmetric(vertical: 5),
                              child: OutlinedButton(
                                onPressed: () async {
                                  try {
                                    final result =
                                    await InternetAddress.lookup('example.com');
                                    if (result.isNotEmpty &&
                                        result[0].rawAddress.isNotEmpty) {
                                      Navigator.of(context).push(
                                          CustomRoutePageBuilder.createPageRoute(
                                              context, const WishListPage()));
                                      // Navigator.push(context, WishListPage.route());
                                    }
                                  } on SocketException catch (_) {
                                    Common.toastMsg('No Internet Connection');
                                  }
                                },
                                child: Row(
                                  children: const [
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Text(
                                        'My Wishlist',
                                        style: TextStyle(
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Icon(
                                        Icons.keyboard_arrow_right,
                                        color: Colors.black87,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              height: 45,
                              width: double.infinity,
                              margin: const EdgeInsets.symmetric(vertical: 5),
                              child: OutlinedButton(
                                onPressed: () async {
                                  try {
                                    final result =
                                    await InternetAddress.lookup('example.com');
                                    if (result.isNotEmpty &&
                                        result[0].rawAddress.isNotEmpty) {
                                      Navigator.of(context).push(
                                          CustomRoutePageBuilder.createPageRoute(
                                              context, const AddressManagerPage()));
                                      // Navigator.push(context, AddressManagerPage.route());
                                    }
                                  } on SocketException catch (_) {
                                    Common.toastMsg('No Internet Connection');
                                  }
                                },
                                child: Row(
                                  children: const [
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Text(
                                        'Address Manager',
                                        style: TextStyle(
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Icon(
                                        Icons.keyboard_arrow_right,
                                        color: Colors.black87,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              height: 45,
                              width: double.infinity,
                              margin: const EdgeInsets.symmetric(vertical: 5),
                              child: OutlinedButton(
                                onPressed: () async {
                                  try {
                                    final result =
                                    await InternetAddress.lookup('example.com');
                                    if (result.isNotEmpty &&
                                        result[0].rawAddress.isNotEmpty) {
                                      Navigator.of(context).push(
                                          CustomRoutePageBuilder.createPageRoute(
                                              context, const OffersPage()));
                                      // Navigator.push(context, OffersPage.route());
                                    }
                                  } on SocketException catch (_) {
                                    Common.toastMsg('No Internet Connection');
                                  }

                                  // Navigator.push(context, CreateAddressPage.route());
                                },
                                child: Row(
                                  children: const [
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Text(
                                        'My Offers',
                                        style: TextStyle(
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Icon(
                                        Icons.keyboard_arrow_right,
                                        color: Colors.black87,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              height: 45,
                              width: double.infinity,
                              margin: const EdgeInsets.symmetric(vertical: 5),
                              child: OutlinedButton(
                                onPressed: () async {
                                  try {
                                    final result =
                                    await InternetAddress.lookup('example.com');
                                    if (result.isNotEmpty &&
                                        result[0].rawAddress.isNotEmpty) {
                                      Navigator.of(context).push(
                                          CustomRoutePageBuilder.createPageRouteLeft(
                                              context, const MyPayments()));
                                      // Navigator.push(context, OffersPage.route());
                                    }
                                  } on SocketException catch (_) {
                                    Common.toastMsg('No Internet Connection');
                                  }

                                  // Navigator.push(context, CreateAddressPage.route());
                                },
                                child: Row(
                                  children: const [
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Text(
                                        'My Payments',
                                        style: TextStyle(
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: Icon(
                                        Icons.keyboard_arrow_right,
                                        color: Colors.black87,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ],
            );
          }
        },
      ),
    );
  }
}

class AccountProfileView extends StatelessWidget {
  final f = DateFormat('MMM-dd-yyyy');
  AccountProfileView({Key? key}) : super(key: key);
  Future<UserBalanceModel?> fetchUserBalanceList() async {
    SharedPreferences localStorage =
    await SharedPreferences.getInstance();
    String? session =
    localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId =
    localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token =
    localStorage.getString(SharedPreferenceUtils.TOKEN);
    Client client = Client();
    var url = Uri.parse(Urls.baseUrl+Urls.userBalanceList);
    print('user balance list ($url)');
    var response = await client.post(url,body: {
      'session': '$session',
      'user_id': '$userId',
      'token': '$token',
    });
    print(response.body);
    if (response.statusCode == 200) {
      final Map<String, dynamic> body = await json.decode(response.body);
      UserBalanceModel userBalanceModel = UserBalanceModel.fromJson(body);
      if (response.body.isNotEmpty) {
        return userBalanceModel;
      }
    }else {
      throw Exception('Failed to load post');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 55,
            backgroundColor: const Color(0xFFF4F4F4),
            child: CircleAvatar(
              radius: 50,
              backgroundColor: Colors.transparent,
              backgroundImage: SharedPreferenceUtils.profilePicF!.isNotEmpty ? NetworkImage(SharedPreferenceUtils.profilePicF!) : const NetworkImage("https://img.freepik.com/free-icon/important-person_318-10744.jpg?size=338&ext=jpg"),
            ),
          ),
          const SizedBox(
            height: 8,
          ),
          SizedBox(
              width: double.infinity,
              child: Text(
                '${SharedPreferenceUtils.usernameF} ${SharedPreferenceUtils.lastNameF}',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 18,
                    fontWeight: FontWeight.w600),
              )
          ),
          SizedBox(
              width: double.infinity,
              child: Text(
                '+60 ${SharedPreferenceUtils.mobileF}',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: Colors.black54,
                    fontSize: 16,
                    fontWeight: FontWeight.w500),
              )),
          const SizedBox(
            height: 16,
          ),
          GestureDetector(
            onTap: () {
              showModalBottomSheet(
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(16),
                          topRight: Radius.circular(16))),
                  isScrollControlled: true,
                  isDismissible: true,
                  context: context,
                  builder: (context) {
                    return FutureBuilder(
                        future: fetchUserBalanceList(),
                        builder: (BuildContext context,AsyncSnapshot<UserBalanceModel?> snapshot){
                          if (snapshot.hasData) {
                            return DraggableScrollableSheet(
                              expand: false,
                                builder: (context, scrollController){
                                  return CustomScrollView(
                                    scrollDirection: Axis.vertical,
                                    controller: scrollController,
                                    shrinkWrap: true,
                                    slivers: [
                                      SliverToBoxAdapter(
                                        child: ListTile(
                                          tileColor: AppsColors.buttonColor,
                                          onTap: () {},
                                          leading: const FaIcon(
                                            FontAwesomeIcons.dollarSign,
                                            color: Colors.white,
                                          ),
                                          horizontalTitleGap: 8,
                                          title: Text(
                                            'My Balance',
                                            style: Theme.of(context)
                                                .textTheme
                                                .headline5!
                                                .copyWith(color: Colors.white),
                                          ),
                                        ),
                                      ),
                                      const SliverToBoxAdapter(
                                        child: SizedBox(
                                          height: 8,
                                        ),
                                      ),
                                      SliverToBoxAdapter(
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                                          children: [
                                            Text('Credit Balance : RM${snapshot.data!.data!.credit!.toStringAsFixed(2)}',style: const TextStyle(color: Colors.green,fontSize: 14),),
                                            Text('Due Balance : RM${snapshot.data!.data!.due!.toStringAsFixed(2)}',style: const TextStyle(color: Colors.red,fontSize: 14),)
                                          ],
                                        ),
                                      ),
                                      const SliverToBoxAdapter(
                                        child: SizedBox(
                                          height: 16,
                                        ),
                                      ),
                                      SliverLayoutBuilder(
                                        builder: (BuildContext context, SliverConstraints boxConstraints){
                                          if (snapshot.data!.data!.history!.isNotEmpty) {
                                            return SliverList(
                                              delegate: SliverChildBuilderDelegate(
                                                    (BuildContext context, int index){
                                                  return Container(
                                                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                                                    margin: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
                                                    decoration: BoxDecoration(
                                                      color: Colors.white,
                                                      borderRadius: BorderRadius.circular(6.0),
                                                    ),
                                                    child: Column(
                                                      mainAxisSize: MainAxisSize.min,
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                                                          decoration: BoxDecoration(
                                                            color: const Color(0xFFF4F4F4),
                                                            borderRadius: BorderRadius.circular(6.0),
                                                          ),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Text(snapshot.data!.data!.history![index].type == 'Payment' ? 'PAY ID #': 'ORD #',
                                                                style: const TextStyle(
                                                                    color: Colors.black87,
                                                                    fontWeight: FontWeight.bold,
                                                                    fontSize: 16),
                                                              ),
                                                              Text(
                                                                snapshot.data!.data!.history![index].type == 'Payment' ? '${snapshot.data!.data!.history![index].paymentNo}': '${snapshot.data!.data!.history![index].bookingNo}',
                                                                style: const TextStyle(
                                                                    color: Colors.black87,
                                                                    fontWeight: FontWeight.normal,
                                                                    fontSize: 16),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                                                          decoration: BoxDecoration(
                                                            color: Colors.transparent,
                                                            borderRadius: BorderRadius.circular(6.0),
                                                          ),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              const Text(
                                                                'Date',
                                                                style: TextStyle(
                                                                    color: Colors.black87,
                                                                    fontWeight: FontWeight.bold,
                                                                    fontSize: 16),
                                                              ),
                                                              Text(
                                                                f.format(DateTime.parse(snapshot.data!.data!.history![index].dateAt!)),
                                                                style: const TextStyle(
                                                                    color: Colors.black87,
                                                                    fontWeight: FontWeight.normal,
                                                                    fontSize: 16),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        const Divider(
                                                          height: 3,
                                                          thickness: 1.0,
                                                          color: Color(0xFFF4F4F4),
                                                        ),
                                                        Container(
                                                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                                                          decoration: BoxDecoration(
                                                            color: Colors.transparent,
                                                            borderRadius: BorderRadius.circular(6.0),
                                                          ),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Expanded(
                                                                flex: 1,
                                                                child: Text(
                                                                  snapshot.data!.data!.history![index].type == 'Payment' ?  'In' : 'Out',
                                                                  style: const TextStyle(
                                                                      color: Colors.black87,
                                                                      fontWeight: FontWeight.bold,
                                                                      fontSize: 16),
                                                                ),
                                                              ),
                                                              Expanded(
                                                                flex: 3,
                                                                child: Text(
                                                                  snapshot.data!.data!.history![index].type == 'Payment' ?  'RM${snapshot.data!.data!.history![index].payAmount!.toStringAsFixed(2)}' : 'RM${snapshot.data!.data!.history![index].orderValue!.toStringAsFixed(2)}',
                                                                  textAlign: TextAlign.end,
                                                                  style: const TextStyle(
                                                                      color: Colors.black87,
                                                                      fontWeight: FontWeight.normal,
                                                                      fontSize: 16),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        const Divider(
                                                          height: 3,
                                                          thickness: 1.0,
                                                          color: Color(0xFFF4F4F4),
                                                        ),
                                                        Container(
                                                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                                                          decoration: BoxDecoration(
                                                            color: Colors.transparent,
                                                            borderRadius: BorderRadius.circular(6.0),
                                                          ),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              const Text(
                                                                'Balance',
                                                                style: TextStyle(
                                                                    color: Colors.black87,
                                                                    fontWeight: FontWeight.bold,
                                                                    fontSize: 16),
                                                              ),
                                                              Text(
                                                                'RM${snapshot.data!.data!.history![index].balance!.toStringAsFixed(2)}',
                                                                style: const TextStyle(
                                                                    color: Colors.black87,
                                                                    fontWeight: FontWeight.normal,
                                                                    fontSize: 16),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        const Divider(
                                                          height: 3,
                                                          thickness: 1.0,
                                                          color: Color(0xFFF4F4F4),
                                                        ),
                                                        Container(
                                                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                                                          decoration: BoxDecoration(
                                                            color: Colors.transparent,
                                                            borderRadius: BorderRadius.circular(6.0),
                                                          ),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              TextButton(
                                                                onPressed: () async {
                                                                  if (snapshot.data!.data!.history![index].type == 'Payment') {
                                                                    Navigator.of(context)
                                                                        .push(CustomRoutePageBuilder.createPageRouteLeft(
                                                                        context,
                                                                        PaymentDetailsPage(
                                                                          txnId: snapshot.data!.data!.history![index].txPkNo,
                                                                        )));
                                                                  }  else {
                                                                    Navigator.of(context).push(
                                                                        CustomRoutePageBuilder.createPageRouteLeft(
                                                                            context,
                                                                            OrderDetailsPage(
                                                                                orderId: snapshot.data!.data!.history![index].bookingPkNo)));
                                                                  }
                                                                },
                                                                child: Text(
                                                                  snapshot.data!.data!.history![index].type == 'Payment' ? 'Payment Details': 'Order Details',
                                                                  style: TextStyle(color: AppsColors.blueGreenX),
                                                                ),
                                                              ),
                                                              const Text('')
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  );
                                                },childCount: snapshot.data!.data!.history!.length,
                                              ),
                                            );
                                          }  else {
                                            return const SliverToBoxAdapter(
                                              child: SizedBox(
                                                height: 200,
                                                width: double.infinity,
                                                child: Center(
                                                  child: Text('Balance Not Found!'),
                                                ),
                                              ),
                                            );
                                          }
                                        },
                                      ),
                                      const SliverToBoxAdapter(
                                        child: SizedBox(
                                          height: 20,
                                        ),
                                      ),
                                    ],
                                  );
                                }
                            );
                          } else if (snapshot.hasError) {
                            return SizedBox(
                              height: 200,
                              width: double.infinity,
                              child: Center(
                                child: Text(snapshot.error.toString()),
                              ),
                            );
                          }
                          return SizedBox(
                            height: 200,
                            width: double.infinity,
                            child: Center(
                              child: SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  color: AppsColors.buttonColor,
                                  strokeWidth: 2,
                                ),
                              ),
                            ),
                          );
                        }
                    );
                  });
            },
            child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                decoration: BoxDecoration(
                    color: const Color(0xFFFFFFFF),
                    border: Border.all(color: AppsColors.buttonColor, width: 1.0),
                    borderRadius: BorderRadius.circular(6.0)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  FaIcon(
                    FontAwesomeIcons.searchDollar,
                    color: AppsColors.buttonColor,
                    size: 20,
                  ),
                  const SizedBox(
                    width: 8,
                  ),
                  Text(
                    'Check Balance',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: AppsColors.buttonColor,
                    ),
                  )
                ])),
          )
        ],
      ),
    );
  }
}

class AccountMobileVerifyView extends StatefulWidget {
  const AccountMobileVerifyView({Key? key}) : super(key: key);

  @override
  _AccountMobileVerifyViewState createState() =>
      _AccountMobileVerifyViewState();
}

class _AccountMobileVerifyViewState extends State<AccountMobileVerifyView> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12.0),
      margin: const EdgeInsets.symmetric(vertical: 5),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(3),
          border: Border.all(color: const Color(0xFFF4F4F4), width: 2),
          color: Colors.transparent),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              const Spacer(),
              const Text(
                'Please Verify Your Number Or Email',
                style: TextStyle(
                  color: Colors.black87,
                  fontSize: 12,
                ),
              ),
              const Spacer(),
              CircleAvatar(
                radius: 4,
                backgroundColor: AppsColors.buttonColor,
              )
            ],
          ),
          const SizedBox(
            height: 4,
          ),
          const SizedBox(
            width: double.infinity,
            child: Text(
              'Get newest offer',
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.black54,
                  fontSize: 10,
                  fontStyle: FontStyle.italic),
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          Container(
            width: double.infinity,
            height: 50,
            margin: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFFF4F4F4), width: 2),
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(30.0)),
            child: TextField(
                textAlign: TextAlign.start,
                decoration: InputDecoration(
                    suffixIcon: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                          primary: AppsColors.buttonColor,
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30))),
                      child: const Text(
                        'Verify Now',
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                    alignLabelWithHint: true,
                    hintText: "Phone or email",
                    border: const OutlineInputBorder(borderSide: BorderSide.none)),
                autofocus: false,
                maxLines: 1,
                style: const TextStyle(
                    fontSize: 12,
                    color: Colors.black,
                    fontWeight: FontWeight.normal)),
          ),
        ],
      ),
    );
  }
}

// ignore: must_be_immutable
class TextExpandable extends StatelessWidget {
  final String text;
  TextExpandable(this.text, {Key? key}) : super(key: key);
  String loremIpsum =
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(6),
      margin: const EdgeInsets.symmetric(vertical: 5),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(3),
          border: Border.all(color: const Color(0xFFF4F4F4), width: 2),
          color: Colors.transparent),
      child: ExpandablePanel(
        collapsed: const SizedBox(height: 0,),
        header: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
          child: Text(
            text,
            style: const TextStyle(
                color: Colors.black87,
                fontSize: 14,
                fontWeight: FontWeight.w400),
          ),
        ),
        // collapsed: Text('$loremIpsum', softWrap: true, maxLines: 2, overflow: TextOverflow.ellipsis,),
        expanded: Text(
          loremIpsum,
          softWrap: true,
        ),
      ),
    );
  }
}

class AccountLogoutBtn extends StatelessWidget {
  const AccountLogoutBtn({Key? key}) : super(key: key);

  void clear() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    localStorage.setString(SharedPreferenceUtils.SESSION, const Uuid().v4());
    localStorage.remove(SharedPreferenceUtils.USER_ID);
    localStorage.remove(SharedPreferenceUtils.TOKEN);
    localStorage.remove(SharedPreferenceUtils.EMAIL);
    localStorage.remove(SharedPreferenceUtils.profilePic);
    SharedPreferenceUtils.userIdF = 0;
    SharedPreferenceUtils.emailF = '';
    SharedPreferenceUtils.mobileF = '';
    SharedPreferenceUtils.usernameF = '';
    SharedPreferenceUtils.lastNameF = '';
    SharedPreferenceUtils.profilePicF = '';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      // width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 16),
      padding: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(6.0),
          border: Border.all(color: AppsColors.buttonColor, width: 1)),
      child: SizedBox(
        // width: double.infinity,
        child: TextButton(
          onPressed: () {
            // Navigator.of(context).push(
            //     CustomRoutePageBuilder.createPageRouteLeft(
            //         context, const ChangePassword()));
            // Navigator.push(context, ChangePassword.route());
            clear();
            Navigator.pop(context);
            Navigator.push(context, LoginPage.route());
          },
          child: Text('Log out',
              style: TextStyle(
                  color: AppsColors.buttonColor, fontWeight: FontWeight.w600)),
        ),
      ),
    );
  }
}
