import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../common.dart';
import '../../edit_profile/edit_profile_page.dart';
import '../../utils/custom_route.dart';
import '../account_deletion/account_deletion_screen.dart';

class AccountSettingScreen extends StatelessWidget {
  const AccountSettingScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Account Settings',
          style: TextStyle(color: Colors.black87),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarBrightness: Brightness.dark,
            statusBarIconBrightness: Brightness.dark),
      ),
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
              sliver: SliverToBoxAdapter(
                child: Container(
                  height: 45,
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(vertical: 5),
                  child: OutlinedButton(
                    onPressed: () async {
                      try {
                        final result =
                        await InternetAddress.lookup('example.com');
                        if (result.isNotEmpty &&
                            result[0].rawAddress.isNotEmpty) {
                          Navigator.of(context).push(
                              CustomRoutePageBuilder.createPageRouteLeft(
                                  context, const EditProfilePage()));
                        }
                      } on SocketException catch (_) {
                        Common.toastMsg('No Internet Connection');
                      }
                    },
                    child: Row(
                      children: const [
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 10),
                          child: Text(
                            'Edit Profile',
                            style: TextStyle(
                              color: Colors.black87,
                            ),
                          ),
                        ),
                        Spacer(),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 10),
                          child: Icon(
                            Icons.keyboard_arrow_right,
                            color: Colors.black87,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverToBoxAdapter(
                child: Container(
                  height: 45,
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(vertical: 5),
                  child: OutlinedButton(
                    onPressed: () async {
                      try {
                        final result =
                        await InternetAddress.lookup('example.com');
                        if (result.isNotEmpty &&
                            result[0].rawAddress.isNotEmpty) {
                          Navigator.of(context).push(
                              CustomRoutePageBuilder.createPageRouteLeft(
                                  context, const AccountDeletionScreen()));
                        }
                      } on SocketException catch (_) {
                        Common.toastMsg('No Internet Connection');
                      }
                    },
                    child: Row(
                      children: const [
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 10),
                          child: Text(
                            'Account Deletion',
                            style: TextStyle(
                              color: Colors.black87,
                            ),
                          ),
                        ),
                        Spacer(),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 10),
                          child: Icon(
                            Icons.keyboard_arrow_right,
                            color: Colors.black87,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
