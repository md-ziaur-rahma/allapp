import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/common_widgets/no_items.dart';
import 'package:azuramartmy/model_search_result/model_search_result_page.dart';
import 'package:azuramartmy/my_bloc/model_search_bloc.dart';
import 'package:azuramartmy/provider_models/model_search_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/material.dart';

class ModelSearchBody extends StatefulWidget {
  const ModelSearchBody({Key? key, this.keyword}) : super(key: key);
  final String? keyword;

  @override
  _ModelSearchBodyState createState() => _ModelSearchBodyState();
}

class _ModelSearchBodyState extends State<ModelSearchBody> {

  @override
  void initState() {
    modelSearchBloc.fetchAllModelSearch(widget.keyword);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: StreamBuilder(
          stream: modelSearchBloc.allModelSearchResult,
          builder: (context, AsyncSnapshot<ModelSearchModel> snapshot) {
            if (snapshot.hasData) {
              if (snapshot.data!.data!.isNotEmpty) {
                return CustomScrollView(
                  scrollDirection: Axis.vertical,
                  slivers: [
                    SliverGrid(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: MediaQuery.of(context).orientation ==
                              Orientation.portrait
                              ? 2
                              : MediaQuery.of(context).size.width > 750
                              ? 4
                              : 3,
                          childAspectRatio: MediaQuery.of(context).orientation ==
                              Orientation.portrait
                              ? screenWidth / 150.0
                              : screenHeight / 140.0,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12),
                      delegate: SliverChildBuilderDelegate(
                            (BuildContext context, int index) {
                          return SearchGridItem(snapshot, index);
                        },
                        childCount: snapshot.data!.data!.length,
                      ),
                    )
                  ],
                );
              }  else{
                return const Center(
                  child: NoItemsCard()
                );
              }
            } else if (snapshot.hasError) {
              return Center(
                child: Text(snapshot.error.toString()),
              );
            }
            return LoadingWidget(color: AppsColors.buttonColor,);
          }),
    );
  }
}

class SearchGridItem extends StatefulWidget {
  final AsyncSnapshot<ModelSearchModel> snapshot;
  final int index;
  const SearchGridItem(this.snapshot, this.index);
  @override
  _SearchGridItemState createState() => _SearchGridItemState();
}

class _SearchGridItemState extends State<SearchGridItem> {
  int isWish = 0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ModelSearchResultPage.modelNo = widget.snapshot.data!.data![widget.index].pkno;
            ModelSearchResultPage.keyword = widget.snapshot.data!.data![widget.index].modelname;
            Navigator.push(context, ModelSearchResultPage.route());
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }

      },
      child: Card(
        elevation: 4,
        shadowColor: Colors.black12,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: const Color(0xFFFFFFFF).withOpacity(0.2),
                ),
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                          padding:
                          const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(
                                minHeight: 60, maxHeight: 120),
                            child: widget.snapshot.data!.data![widget.index].primaryimgrelativepath == null
                                ? const NoImageWidget(text: 'No Image',)
                                : CacheImageProvide(url: widget.snapshot.data!.data![widget.index].primaryimgrelativepath,)
                          )),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                child: Text(
                  '${widget.snapshot.data!.data![widget.index].modelname}',
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87),
                ),
              ),
            ),
            const SizedBox(
              height: 8,
            )
          ],
        ),
      ),
    );
  }
}