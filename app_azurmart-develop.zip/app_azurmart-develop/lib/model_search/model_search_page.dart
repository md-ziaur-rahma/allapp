import 'dart:io';

import 'package:azuramartmy/model_search/model_search_body.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ModelSearchPage extends StatefulWidget {
  const ModelSearchPage({Key? key}) : super(key: key);

  static String? keyword;

  static Route route() {
    return MaterialPageRoute(builder: (_) => const ModelSearchPage());
  }

  @override
  _ModelSearchPageState createState() => _ModelSearchPageState();
}

class _ModelSearchPageState extends State<ModelSearchPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        titleSpacing: 0,
        backgroundColor: const Color(0xFFFFFFFF),
        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
        title: Container(
          height: 42,
          width: double.infinity,
          margin: const EdgeInsets.only(right: 10),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6.0),
              color: const Color(0xFFF2F2F2)),
          child: ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
                primary: const Color(0xFFF2F2F2), elevation: 0),
            child: SizedBox(
              width: double.infinity,
              child: Text(
                '${ModelSearchPage.keyword}',
                textAlign: TextAlign.start,
                style: const TextStyle(color: Colors.black87, fontSize: 16),
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: ModelSearchBody(
          keyword: ModelSearchPage.keyword,
        ),
      ),
    );
  }
}
