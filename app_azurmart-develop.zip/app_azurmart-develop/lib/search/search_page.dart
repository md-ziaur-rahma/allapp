import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/model_search/model_search_page.dart';
import 'package:azuramartmy/my_bloc/short_search_bloc.dart';
import 'package:azuramartmy/provider_models/short_search_models.dart';
import 'package:azuramartmy/search_result/search_result_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const SearchPage());
  }

  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _searchController = TextEditingController();

  @override
  void initState() {
    shortSearchBloc.fetchAllBrands('');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leadingWidth: 35,
          backgroundColor: const Color(0xFFFFFFFF),
          iconTheme: const IconThemeData(color: Colors.black87),
          systemOverlayStyle: Platform.isIOS
              ? SystemUiOverlayStyle.dark
              : const SystemUiOverlayStyle(
                  statusBarColor: Colors.white,
                  statusBarIconBrightness: Brightness.dark),
          title: SizedBox(
            height: 42,
            child: TextFormField(
              cursorColor: Colors.black87,
              autofocus: true,
              controller: _searchController,
              textInputAction: TextInputAction.search,
              onFieldSubmitted: (value) {
                SearchResultPage.keyword = _searchController.text.toString();
                Navigator.push(context, SearchResultPage.route());
              },
              onChanged: (value) {
                shortSearchBloc.fetchAllBrands(value);
              },
              decoration: const InputDecoration(
                contentPadding: EdgeInsets.symmetric(horizontal: 10),
                hintText: 'Search in Azura Mart',
                filled: true,
                fillColor: Color(0xFFF2F2F2),
                labelStyle: TextStyle(
                  color: Colors.black87,
                  fontSize: 16,
                ),
                focusedBorder: InputBorder.none,
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                errorBorder: InputBorder.none,
                disabledBorder: InputBorder.none,
                // suffixIcon: IconButton(
                //   onPressed: () {
                //     _searchController.clear();
                //     shortSearchBloc.fetchAllBrands('');
                //   },
                //   icon: Icon(
                //     Icons.clear,
                //     size: 16,
                //     color: _searchController.text.isNotEmpty
                //         ? Colors.black87
                //         : Colors.transparent,
                //   ),
                // )
              ),
            ),
          ),
          actions: [
            IconButton(
              onPressed: () async {
                try {
                  final result = await InternetAddress.lookup('example.com');
                  if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                    // SearchResultPage.keyword = _searchController.text.toString();
                    // Navigator.push(context, SearchResultPage.route());
                    if (_searchController.text.isNotEmpty) {
                      ModelSearchPage.keyword =
                          _searchController.text.toString();
                      Navigator.push(context, ModelSearchPage.route());
                    }
                  }
                } on SocketException catch (_) {
                  Common.toastMsg('No Internet Connection');
                }
              },
              icon: const Icon(
                Icons.search,
                color: Colors.black87,
              ),
            )
          ],
        ),
        body: SafeArea(
          child: StreamBuilder(
              stream: shortSearchBloc.shortSearch,
              builder: (context, AsyncSnapshot<ShortSearchModels> snapshot) {
                if (snapshot.hasData) {
                  return ListView.builder(
                      shrinkWrap: true,
                      itemCount: snapshot.data!.data!.length,
                      itemBuilder: (context, index) {
                        return Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            ListTile(
                              onTap: () {
                                SearchResultPage.keyword =
                                    snapshot.data!.data![index].defaultname;
                                Navigator.push(
                                    context, SearchResultPage.route());
                              },
                              title: Text(
                                '${snapshot.data!.data![index].defaultname}',
                                textAlign: TextAlign.start,
                                style: const TextStyle(
                                    color: Colors.black87,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                            const Divider(
                              thickness: 0.5,
                              height: 0,
                            )
                          ],
                        );
                      });
                }
                return const Text('');
              }),
        ));
  }
}
