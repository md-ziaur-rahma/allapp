import 'dart:io';

import 'package:azuramartmy/blog_details/blog_details_page.dart';
import 'package:azuramartmy/common_notifier/common_notifier.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/common_widgets/no_items.dart';
import 'package:azuramartmy/my_bloc/news_bloc.dart';
import 'package:azuramartmy/provider_models/news_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:optimized_cached_image/optimized_cached_image.dart';
import 'package:provider/provider.dart';

class OurNewsPage extends StatefulWidget {
  const OurNewsPage({Key? key}) : super(key: key);
  static Route route() {
    return MaterialPageRoute(builder: (_) => const OurNewsPage());
  }

  @override
  _OurNewsPageState createState() => _OurNewsPageState();
}

class _OurNewsPageState extends State<OurNewsPage> {
  NewsModel newsModel = NewsModel();
  bool canLoading = true;

  @override
  void initState() {
    newsBloc.page = 1;
    newsModel.data = [];
    newsBloc.fetchAllNews();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F4),
      appBar: AppBar(
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
        title: const Text(
          'From Our News',
          style: TextStyle(color: Colors.black87),
        ),
        centerTitle: true,
        elevation: 0,
      ),
      body: SafeArea(
        child: StreamBuilder(
          stream: newsBloc.allNews,
          builder: (BuildContext context, AsyncSnapshot<NewsModel> snapshot) {
            if (snapshot.hasData) {
              // context.read<CommonNotifier>().changeLoading(false);
              Provider.of<CommonNotifier>(context, listen: false)
                  .changeLoading(false);
              if (snapshot.data!.data!.isEmpty) {
                canLoading = false;
              } else {
                if (snapshot.data!.data!.length < 10) {
                  canLoading = false;
                }
                for (var i = 0; i < snapshot.data!.data!.length; i++) {
                  newsModel.data!.add(snapshot.data!.data![i]);
                }
              }
              if (newsModel.data!.isEmpty) {
                return const NoItemsCard();
              } else {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 0),
                  child: CustomScrollView(
                    scrollDirection: Axis.vertical,
                    slivers: [
                      SliverList(
                        delegate: SliverChildBuilderDelegate(
                            (BuildContext context, index) {
                          if (index == (newsModel.data!.length - 1) &&
                              canLoading) {
                            Provider.of<CommonNotifier>(context, listen: false)
                                .changeLoading(true);
                            // context.read<CommonNotifier>().changeLoading(true);
                            newsBloc.fetchPagingData();
                          }
                          return BlogMaterialCard(newsModel: newsModel,index: index,);
                          // return Container(
                          //   margin: const EdgeInsets.only(bottom: 16),
                          //   decoration: BoxDecoration(
                          //     color: Colors.white,
                          //   ),
                          //   child: Column(
                          //     mainAxisSize: MainAxisSize.max,
                          //     children: [
                          //       Container(
                          //         width: double.infinity,
                          //         child: ConstrainedBox(
                          //           constraints: BoxConstraints(
                          //             maxHeight: MediaQuery.of(context).orientation == Orientation.portrait ? MediaQuery.of(context).size.width * 0.8 : MediaQuery.of(context).size.height * 0.8,
                          //             minHeight: MediaQuery.of(context).orientation == Orientation.portrait ? MediaQuery.of(context).size.width * 0.5 : MediaQuery.of(context).size.height * 0.5,
                          //           ),
                          //           child: newsModel.data[index].featureimage == null
                          //               ? NoImageWidget(text: 'No Image')
                          //               : CacheImageProvide(url: newsModel.data[index].featureimage,),
                          //         ),
                          //       ),
                          //
                          //       Container(
                          //         width: double.infinity,
                          //         margin: const EdgeInsets.symmetric(
                          //             horizontal: 16, vertical: 4),
                          //         child: Text(
                          //           '${newsModel.data[index].publishdate}',
                          //           textAlign: TextAlign.center,
                          //           style: TextStyle(
                          //               color: Colors.black54, fontSize: 16),
                          //         ),
                          //       ),
                          //       Container(
                          //         width: double.infinity,
                          //         margin: const EdgeInsets.symmetric(
                          //             horizontal: 16, vertical: 4),
                          //         child: Text(
                          //           '${newsModel.data[index].title}',
                          //           textAlign: TextAlign.center,
                          //           style: TextStyle(
                          //               color: Colors.black87, fontSize: 20),
                          //         ),
                          //       ),
                          //       Container(
                          //         width: double.infinity,
                          //         margin: const EdgeInsets.symmetric(
                          //             horizontal: 16, vertical: 4),
                          //         child: Text(
                          //           '${newsModel.data[index].summary}',
                          //           maxLines: 4,
                          //           textAlign: TextAlign.center,
                          //           style: TextStyle(
                          //               color: Colors.black87, fontSize: 18),
                          //         ),
                          //       ),
                          //       Align(
                          //         alignment: Alignment.bottomRight,
                          //         child: SizedBox(
                          //           child: TextButton(
                          //             onPressed: () {
                          //               Navigator.of(context).push(
                          //                   CustomRoutePageBuilder.createPageRouteLeft(
                          //                       context, BlogDetailsPage(slug: newsModel.data[index].urlslug,)));
                          //             },
                          //             child: const Text(
                          //               '  Learn more  ',
                          //               style:
                          //                   TextStyle(color: Color(0xFFF68721)),
                          //             ),
                          //           ),
                          //         ),
                          //       )
                          //     ],
                          //   ),
                          // );
                        }, childCount: newsModel.data!.length),
                      ),
                      SliverLayoutBuilder(
                        builder: (BuildContext context,
                            SliverConstraints constraints) {
                          if (Provider.of<CommonNotifier>(context,
                                  listen: false)
                              .isLoading) {
                            return SliverToBoxAdapter(
                              child: Center(
                                child: Container(
                                  margin: const EdgeInsets.symmetric(vertical: 16),
                                  height: 20,
                                  width: 20,
                                  child: const CupertinoActivityIndicator(
                                    animating: true,
                                    radius: 12,
                                  ),
                                ),
                              ),
                            );
                          } else {
                            return const SliverToBoxAdapter(
                              child: Center(
                                  child: SizedBox(
                                height: 6,
                              )),
                            );
                          }
                        },
                      ),
                    ],
                  ),
                );
              }
            } else if (snapshot.hasError) {
              return Center(
                child: Text(snapshot.error.toString()),
              );
            }
            return LoadingWidget(color: AppsColors.buttonColor,);
          },
        ),
      ),
    );
  }
}

class BlogMaterialCard extends StatelessWidget {
  BlogMaterialCard({Key? key,this.newsModel,this.index}) : super(key: key);
  final NewsModel? newsModel;
  final int? index;

  final Shader linearGradient = const LinearGradient(
    // colors: <Color>[Color(0xffDA44bb), Color(0xff8921aa)],
    colors: <Color>[Color(0xffff0080), Color(0xff8928ca)],
  ).createShader(const Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      elevation: 4,
      shadowColor: Colors.black12,
      margin: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(16.0),
            height: MediaQuery.of(context).orientation == Orientation.portrait ? MediaQuery.of(context).size.width * 0.65 : MediaQuery.of(context).size.height * 1,
            width: double.infinity,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8.0),
              child: newsModel!.data![index!].featureimage == null
                  ? const NoImageWidget(text: 'No Image')
                  : OptimizedCacheImage(
                imageUrl: Urls.basePictureUrl + newsModel!.data![index!].featureimage!,
                imageBuilder:
                    (context, imageProvider) =>
                    Container(
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: imageProvider,
                          fit: BoxFit.cover,
                          // colorFilter: ColorFilter.mode(Colors.transparent, BlendMode.clear)
                        ),
                      ),
                    ),
                placeholder: (context, url) =>
                const Center(
                      child: SizedBox(
                        height: 16,
                        width: 16,
                        child:
                        CircularProgressIndicator(
                          strokeWidth: 2.0,
                          valueColor:
                          AlwaysStoppedAnimation(
                              Color(0xFFF68721)),
                        ),
                      ),
                    ),
                errorWidget:
                    (context, url, error) =>
                    const Icon(Icons.error),
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text('TRENDING',style: TextStyle(fontSize: 14,fontWeight: FontWeight.bold,foreground: Paint()..shader = linearGradient),),
          ),

          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text('${newsModel!.data![index!].title}',textAlign: TextAlign.start,style: const TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: Colors.black),),
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text('${newsModel!.data![index!].publishdate}',textAlign: TextAlign.start,style: const TextStyle(fontSize: 14,fontWeight: FontWeight.normal,color: Colors.black54),),
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            height: 16,
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text('${newsModel!.data![index!].summary}',textAlign: TextAlign.start,style: const TextStyle(fontSize: 14,fontWeight: FontWeight.normal,color: Colors.black54),),
          ),
          Align(
            alignment: Alignment.bottomRight,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              child: OutlinedButton(
                onPressed: (){
                  Navigator.of(context).push(
                      CustomRoutePageBuilder.createPageRouteLeft(
                          context, BlogDetailsPage(slug: newsModel!.data![index!].urlslug,)));
                },
                style: OutlinedButton.styleFrom(side: const BorderSide(width: 1.0, color: Color(0xff8928ca)),),
                child: Text('READ MORE',style: TextStyle(foreground: Paint()..shader = linearGradient,fontSize: 14),),
              ),
            ),
          ),
          const SizedBox(height: 12,)
        ],
      ),
    );
  }
}

