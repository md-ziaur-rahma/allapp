import 'package:azuramartmy/provider_models/brand_product_model.dart';
import 'package:flutter/foundation.dart';

class BrandDetailsNotifier extends ChangeNotifier{
  String? categoryName = "All Products";
  int buttonClear = 1;
  String catUrl = '';

  BrandProductModel brandProductModel = BrandProductModel();
  bool canLoading = true;

  void changeCategoryName(String? value){
    categoryName = value;
    notifyListeners();
  }

  void changeBtnClear(int value){
    buttonClear = value;
    notifyListeners();
  }

}