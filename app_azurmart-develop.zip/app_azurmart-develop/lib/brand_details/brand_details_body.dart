import 'dart:io';
import 'dart:ui';

import 'package:azuramartmy/brand_details/brand_details_chngenotifier.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_notifier/common_notifier.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/common_widgets/no_items.dart';
import 'package:azuramartmy/common_widgets/shimmer_effect_grid.dart';
import 'package:azuramartmy/my_bloc/brand_details_bloc.dart';
import 'package:azuramartmy/my_bloc/brand_product_bloc.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/brand_details_model.dart';
import 'package:azuramartmy/provider_models/brand_product_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:provider/provider.dart';

class BrandDetailsBody extends StatefulWidget {
  const BrandDetailsBody({Key? key, this.branPk}) : super(key: key);
  final int? branPk;

  @override
  _BrandDetailsBodyState createState() => _BrandDetailsBodyState();
}

class _BrandDetailsBodyState extends State<BrandDetailsBody> {
  String categoryName = "All Products";
  int buttonClear = 1;
  String catUrl = '';

  BrandProductModel brandProductModel = BrandProductModel();
  bool canLoading = true;

  @override
  void initState() {
    brandProductModel.data = [];
    canLoading = true;
    catUrl = '';
    brandProductBloc.page = 1;
    brandDetailsBloc.fetchAllBrandDetails(widget.branPk);
    brandProductBloc.fetchAllBrandProducts(widget.branPk, catUrl);
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          StreamBuilder(
              stream: brandDetailsBloc.allBrandDetails,
              builder: (context, AsyncSnapshot<BrandDetailsModel> snapshot) {
                if (snapshot.hasData) {
                  return SliverToBoxAdapter(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: double.infinity,
                          margin:
                              const EdgeInsets.only(left: 2, right: 2, top: 16),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            color: Colors.white,
                            // boxShadow: [
                            //   BoxShadow(
                            //     color: Colors.grey,
                            //     offset: Offset(1.0, 0), //(x,y)
                            //     blurRadius: 0.1,
                            //   ),
                            // ]
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Expanded(
                                flex: 1,
                                child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 0, horizontal: 0),
                                    child: ConstrainedBox(
                                        constraints: const BoxConstraints(
                                            minHeight: 24, maxHeight: 50),
                                        child: snapshot.data!.data!.brand!
                                                    .brandlogo ==
                                                null
                                            ? const NoImageWidget(
                                                text: 'No Image',
                                              )
                                            : CacheImageProvide(
                                                url: snapshot
                                                    .data!.data!.brand!.brandlogo,
                                              ))),
                              ),
                              Expanded(
                                flex: 2,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        '${snapshot.data!.data!.brand!.name}',
                                        style: const TextStyle(
                                            color: Colors.black87,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 18,
                                            fontStyle: FontStyle.normal),
                                      ),
                                      const SizedBox(
                                        height: 8,
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: 2, vertical: 14),
                          child: SizedBox(
                            width: double.infinity,
                            child: Text(
                              'Categories',
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                  color: Colors.black54,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 100,
                          width: double.infinity,
                          child: Row(
                            children: [
                              Expanded(
                                  child: ListView(
                                    scrollDirection: Axis.horizontal,
                                    children: [
                                      ...List.generate(
                                          snapshot.data!.data!.category!.length,
                                          (index) {
                                        return GestureDetector(
                                          onTap: () async {
                                            try {
                                              final result =
                                                  await InternetAddress.lookup(
                                                      'example.com');
                                              if (result.isNotEmpty &&
                                                  result[0]
                                                      .rawAddress
                                                      .isNotEmpty) {
                                                brandProductModel.data = [];
                                                catUrl = snapshot.data!.data!
                                                    .category![index].subcatId
                                                    .toString();
                                                brandProductBloc.page = 1;
                                                brandProductBloc
                                                    .fetchAllBrandProducts(
                                                        widget.branPk,
                                                        snapshot
                                                            .data!
                                                            .data!
                                                            .category![index]
                                                            .subcatId
                                                            .toString());
                                                context
                                                    .read<BrandDetailsNotifier>()
                                                    .changeCategoryName(snapshot
                                                        .data!
                                                        .data!
                                                        .category![index]
                                                        .name);
                                                context
                                                    .read<BrandDetailsNotifier>()
                                                    .changeBtnClear(0);
                                              }
                                            } on SocketException catch (_) {
                                              Common.toastMsg(
                                                  'No Internet Connection');
                                            }
                                          },
                                          child: Container(
                                            height: 100,
                                            width: 100,
                                            margin:
                                                const EdgeInsets.only(right: 12),
                                            decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                    BorderRadius.circular(10.0)),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Expanded(
                                                  flex: 2,
                                                  child: Center(
                                                    child: ClipRRect(
                                                      borderRadius:
                                                      const BorderRadius.only(
                                                        topLeft:
                                                            Radius.circular(10),
                                                        topRight:
                                                            Radius.circular(10),
                                                        bottomLeft:
                                                            Radius.circular(10),
                                                        bottomRight:
                                                            Radius.circular(10),
                                                      ),
                                                      child: Container(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(8.0),
                                                          child: ConstrainedBox(
                                                              constraints:
                                                              const BoxConstraints(
                                                                      minHeight:
                                                                          50,
                                                                      maxHeight:
                                                                          50),
                                                              child: snapshot
                                                                          .data!
                                                                          .data!
                                                                          .category![
                                                                              index]
                                                                          .icon ==
                                                                      null
                                                                  ? const NoImageWidget(
                                                                      text:
                                                                          'No \nImage',
                                                                    )
                                                                  : CacheImageProvide(
                                                                      url: snapshot
                                                                          .data!
                                                                          .data!
                                                                          .category![
                                                                              index]
                                                                          .icon,
                                                                    ))),
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 1,
                                                  child: Center(
                                                    child: SizedBox(
                                                      child: Text(
                                                        '${snapshot.data!.data!.category![index].name}',
                                                        maxLines: 2,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: const TextStyle(
                                                            color: Colors.black87,
                                                            fontSize: 12),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      })
                                    ],
                                  ))
                            ],
                          ),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 2, vertical: 20),
                              child: Text(
                                '${context.watch<BrandDetailsNotifier>().categoryName}',
                                style: const TextStyle(
                                    color: Colors.black54,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                            LayoutBuilder(builder: (BuildContext context,
                                BoxConstraints constraints) {
                              if (context
                                      .watch<BrandDetailsNotifier>()
                                      .buttonClear ==
                                  0) {
                                return GestureDetector(
                                  onTap: () async {
                                    try {
                                      final result =
                                          await InternetAddress.lookup(
                                              'example.com');
                                      if (result.isNotEmpty &&
                                          result[0].rawAddress.isNotEmpty) {
                                        context
                                            .read<BrandDetailsNotifier>()
                                            .changeCategoryName('All Product');
                                        brandProductModel.data = [];
                                        catUrl = '';
                                        brandProductBloc.page = 1;
                                        context
                                            .read<BrandDetailsNotifier>()
                                            .changeBtnClear(1);
                                        brandProductBloc.fetchAllBrandProducts(
                                            widget.branPk, '');
                                      }
                                    } on SocketException catch (_) {
                                      Common.toastMsg('No Internet Connection');
                                    }
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 16, vertical: 20),
                                    padding: const EdgeInsets.all(6.0),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(16),
                                        border: Border.all(
                                            color: const Color(0xFFD0D1D2))),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: const [
                                        Icon(
                                          Icons.clear,
                                          size: 16,
                                          color: Colors.black87,
                                        ),
                                        SizedBox(
                                          width: 4,
                                        ),
                                        Text(
                                          'Reset',
                                          style: TextStyle(
                                              color: Colors.black87,
                                              fontSize: 14,
                                              fontWeight: FontWeight.normal),
                                        )
                                      ],
                                    ),
                                  ),
                                );
                              } else {
                                return const Text('');
                              }
                            })
                          ],
                        ),
                      ],
                    ),
                  );
                } else if (snapshot.hasError) {
                  return SliverToBoxAdapter(
                    child: Center(
                      child: Text(snapshot.error.toString()),
                    ),
                  );
                }
                return SliverToBoxAdapter(
                  child: Container(
                    width: double.infinity,
                    height: 100,
                    decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(6.0)),
                    child: Center(
                      child: Image(
                        image: const AssetImage('images/azura_logo_black.png'),
                        height: 35,
                        width: 35,
                        color: Colors.grey[700],
                      ),
                    ),
                  ),
                );
              }),
          StreamBuilder(
              stream: brandProductBloc.allBrandProducts,
              builder:
                  (context, AsyncSnapshot<BrandProductModel> productsSnapshot) {
                if (productsSnapshot.hasData) {
                  // context.read<CommonNotifier>().changeLoading(false);
                  Provider.of<CommonNotifier>(context, listen: false)
                      .changeLoading(false);
                  if (productsSnapshot.data!.data!.isEmpty) {
                    canLoading = false;
                  } else {
                    if (productsSnapshot.data!.data!.length < 10) {
                      canLoading = false;
                    }
                    for (var i = 0; i < productsSnapshot.data!.data!.length; i++) {
                      brandProductModel.data!.add(productsSnapshot.data!.data![i]);
                    }
                  }
                  return brandProductModel.data!.isEmpty
                      ? const SliverToBoxAdapter(
                          child: NoItemsCard(),
                        )
                      : SliverGrid(
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount:
                                MediaQuery.of(context).orientation ==
                                        Orientation.portrait
                                    ? 2
                                    : MediaQuery.of(context).size.width > 740
                                        ? 4
                                        : 3,
                            mainAxisSpacing: 16,
                            childAspectRatio:
                                MediaQuery.of(context).orientation ==
                                        Orientation.portrait
                                    ? screenWidth / 180.0
                                    : screenHeight / 180.0,
                            crossAxisSpacing: 16,
                          ),
                          delegate: SliverChildBuilderDelegate(
                              (BuildContext context, int index) {
                            if (index == (brandProductModel.data!.length - 1) &&
                                canLoading) {
                              Provider.of<CommonNotifier>(context,
                                      listen: false)
                                  .changeLoading(true);
                              // context.read<CommonNotifier>().changeLoading(true);
                              brandProductBloc.fetchPagingProduct(
                                  widget.branPk, catUrl);
                            }
                            return Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(horizontal: 0),
                              child: BrandProductCard(
                                snapshot: brandProductModel,
                                index: index,
                              ),
                            );
                          }, childCount: brandProductModel.data!.length),
                        );
                } else if (productsSnapshot.hasError) {
                  return SliverToBoxAdapter(
                    child: Center(
                      child: Text(productsSnapshot.error.toString()),
                    ),
                  );
                }
                return const SliverToBoxAdapter(
                  child: DefaultGridView(),
                );
              }),
          SliverLayoutBuilder(
            builder: (BuildContext context, SliverConstraints constraints) {
              if (Provider.of<CommonNotifier>(context, listen: false)
                  .isLoading) {
                return SliverToBoxAdapter(
                  child: Center(
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 16),
                      height: 20,
                      width: 20,
                      child: const CupertinoActivityIndicator(
                        animating: true,
                        radius: 12,
                      ),
                    ),
                  ),
                );
              } else {
                return const SliverToBoxAdapter(
                  child: Center(
                      child: SizedBox(
                    height: 6,
                  )),
                );
              }
            },
          ),
        ],
      ),
    );
  }
}

class BrandProductCard extends StatefulWidget {
  const BrandProductCard({Key? key, this.snapshot, this.index})
      : super(key: key);
  final BrandProductModel? snapshot;
  final int? index;

  @override
  _BrandProductCardState createState() => _BrandProductCardState();
}

class _BrandProductCardState extends State<BrandProductCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ProductDetailsPage.productUrl =
                widget.snapshot!.data![widget.index!].url;
            ProductDetailsPage.variantPk =
                widget.snapshot!.data![widget.index!].pkno;
            ProductDetailsPage.isWish =
                widget.snapshot!.data![widget.index!].isWish;
            Navigator.of(context).push(
                CustomRoutePageBuilder.createPageRouteLeft(
                    context, const ProductDetailsPage()));
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(10.0)),
        width: MediaQuery.of(context).orientation == Orientation.portrait
            ? MediaQuery.of(context).size.width * 0.41
            : MediaQuery.of(context).size.height * 0.41,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Stack(
              children: [
                Align(
                  alignment: Alignment.center,
                  child: ConstrainedBox(
                      constraints: const BoxConstraints(
                        maxHeight: 140,
                        minHeight: 60,
                      ),
                      child: widget.snapshot!.data![widget.index!]
                                  .thumbPath ==
                              null
                          ? const NoImageWidget(
                              text: 'No Image',
                            )
                          : CacheImageProvide(
                              url: widget.snapshot!.data![widget.index!]
                                  .thumbPath,
                            )),
                ),
                LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                    if (widget.snapshot!.data![widget.index!].offer != 0) {
                      return GestureDetector(
                        onTap: () {
                          // setState(() {
                          //   toggleMsg = toggleMsg == 1 ? 0 : 1;
                          // });
                        },
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            height: 45,
                            width: 45,
                            padding: const EdgeInsets.all(3.0),
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.red,
                            ),
                            child: const Center(
                              child: Text(
                                'In \nOffer',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12),
                              ),
                            ),
                          ),
                        ),
                      );
                    } else {
                      return const Align(
                        alignment: Alignment.topLeft,
                        child: SizedBox(
                          height: 2,
                        ),
                      );
                    }
                  },
                ),
              ],
            ),
            const SizedBox(
              height: 8,
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  widget.snapshot!.data![widget.index!].totalfreestock! > 0
                      ? 'RM${widget.snapshot!.data![widget.index!].regularprice!.toStringAsFixed(2)}'
                      : 'Out of Stock',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppsColors.highlightedColor),
                ),
              ),
            ),
            const SizedBox(
              height: 4,
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  'RM${widget.snapshot!.data![widget.index!].variantname}',
                  maxLines: 3,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.black87),
                ),
              ),
            ),
            const SizedBox(
              height: 8,
            ),
          ],
        ),
      ),
    );
  }
}
