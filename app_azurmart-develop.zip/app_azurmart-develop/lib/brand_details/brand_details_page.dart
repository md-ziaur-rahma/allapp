import 'dart:io';

import 'package:azuramartmy/brand_details/brand_details_body.dart';
import 'package:azuramartmy/common_widgets/floating_action_button.dart';
import 'package:azuramartmy/home/home_page.dart';
import 'package:azuramartmy/search/search_page.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class BrandDetailsPage extends StatefulWidget {
  const BrandDetailsPage({Key? key}) : super(key: key);
  static int? brandPk;

  static Route route(){
    return MaterialPageRoute(builder: (_) => BrandDetailsPage());
  }

  @override
  _BrandDetailsPageState createState() => _BrandDetailsPageState();
}


class _BrandDetailsPageState extends State<BrandDetailsPage> {

  var scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        elevation: 0,
        titleSpacing: 0,
        backgroundColor: const Color(0xFFFFFFFF),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.light
        ),
        title: Container(
          height: 42,
          width: double.infinity,
          margin: const EdgeInsets.only(right: 12),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6.0), color: Colors.white),
          child: ElevatedButton(
            onPressed: () {
              Navigator.push(context,SearchPage.route());
            },
            style: ElevatedButton.styleFrom(primary: const Color(0xFFF2F2F2),elevation: 0),
            child: const SizedBox(
              width: double.infinity,
              child: Text(
                'Search...',
                textAlign: TextAlign.start,
                style: TextStyle(color: Colors.black54,fontSize: 16),
              ),
            ),
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      body: SafeArea(
        child: BrandDetailsBody(branPk: BrandDetailsPage.brandPk,),
      ),
      floatingActionButton: MyFloatingActionButton(snapshot: SharedPreferenceUtils.whatsappModel,),
      bottomNavigationBar: HomeBottomNavBar(isHome: 0,),
    );
  }
}
