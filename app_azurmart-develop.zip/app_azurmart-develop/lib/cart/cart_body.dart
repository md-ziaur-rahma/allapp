import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/common_widgets/no_items.dart';
import 'package:azuramartmy/my_bloc/cart_bloc.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:azuramartmy/provider_models/cart_model.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CartBody extends StatefulWidget {
  const CartBody({Key? key}) : super(key: key);

  @override
  _CartBodyState createState() => _CartBodyState();
}

class _CartBodyState extends State<CartBody> {

  @override
  void initState() {
    cartBloc.fetchAllCarts();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 0),
      child: StreamBuilder(
        stream: cartBloc.allCarts,
        builder: (context, AsyncSnapshot<CartModel> snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data!.data!.bundle!.isNotEmpty || snapshot.data!.data!.nonBundle!.isNotEmpty || snapshot.data!.data!.cart!.isNotEmpty) {
              return CartDetails(
                snapshot: snapshot,
              );
            } else {
              return CustomScrollView(
                scrollDirection: Axis.vertical,
                slivers: [
                  SliverAppBar(
                    title: const Text(
                      'My Cart (0)',
                      style: TextStyle(color: Colors.black87),
                    ),
                    backgroundColor: Colors.white,
                    systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
                        statusBarColor: Colors.white,
                        statusBarIconBrightness: Brightness.dark),
                    iconTheme: const IconThemeData(color: Colors.black87),
                    pinned: true,
                  ),
                  const SliverToBoxAdapter(
                    child: Center(
                      child: NoItemsCard(),
                    ),
                  )
                ],
              );
            }
          } else if (snapshot.hasError) {
            return Center(
              child: Text(snapshot.error.toString()),
            );
          }
          return LoadingWidget(color: AppsColors.buttonColor,);
        },
      ),
    );
  }
}


class CartDetails extends StatefulWidget {
  const CartDetails({Key? key, this.snapshot}) : super(key: key);
  final AsyncSnapshot<CartModel>? snapshot;

  @override
  _CartDetailsState createState() => _CartDetailsState();
}

class _CartDetailsState extends State<CartDetails> {

  String getDays(String date) {
    DateTime dob = DateTime.parse(date);
    Duration dur = dob.difference(DateTime.now());
    int differenceDays = dur.inDays;
    return differenceDays < 0 ? '7' : differenceDays.toString();
  }

  void cartAddRemove(int? variantNo,int isRemove,int? qty) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Map<String, dynamic> data = {
      'qty': '$qty',
      'user_id': '$userId',
      'token': '$token',
      'session': session,
      'IS_REMOVE': '$isRemove',
      'F_PRD_VARIANT_NO': '$variantNo',
    };
    var requestBody = json.encode(data);
    print(requestBody);
    Client client = Client();
    try{
      final url = Uri.parse(Urls.baseUrl + Urls.CARTQTYUPDATE);
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      print('${body['message']}');
      cartBloc.fetchAllCarts();
      Common.toastMsg(body['message']);
      if (body['status'] == 1) {
        // cartBloc.fetchAllCarts();
      }
    } on FormatException catch (e){
      print(e);
    } on Exception catch (e){
      print(e);
    }
  }

  void cartLocationChange(int? variantNo,int? wareHouseNo,int? shipmentNo) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Map<String, dynamic> data = {
      'user_id': '$userId',
      'token': '$token',
      'session': session,
      'F_PRD_VARIANT_NO': '$variantNo',
      'F_INV_WAREHOUSE_NO': '$wareHouseNo',
      'F_SHIPPMENT_NO': '$shipmentNo',
    };
    var requestBody = json.encode(data);
    print(requestBody);
    Client client = Client();
    try{
      final url = Uri.parse(Urls.baseUrl + Urls.CARTLOCATIONUPDATE);
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      print('${body['message']}');
      if (body['status'] == 1) {
        cartBloc.fetchAllCarts();
      }
    } on FormatException catch (e){
      print(e);
    } on Exception catch (e){
      print(e);
    }
  }

  @override
  void initState() {
    super.initState();
  }

  final Shader linearGradient = const LinearGradient(
    colors: <Color>[Color(0xffDA44bb), Color(0xff8921aa)],
    // colors: <Color>[Color(0xFF000000), Color(0xFF000000).withOpacity(0.6)],
  ).createShader(const Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      scrollDirection: Axis.vertical,
      slivers: [
        SliverAppBar(
          title: Text(
            'My Cart (${widget.snapshot!.data!.data!.cartQtyCount}) - RM${widget.snapshot!.data!.data!.totalPrice}',
            style: const TextStyle(color: Colors.black87),
          ),
          backgroundColor: Colors.white,
          systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
              statusBarColor: Colors.white,
              statusBarIconBrightness: Brightness.dark),
          iconTheme: const IconThemeData(color: Colors.black87),
          pinned: true,
        ),
        // SliverToBoxAdapter(
        //   child: Container(
        //     margin: const EdgeInsets.only(left: 16,top: 16,bottom: 8),
        //     width: double.infinity,
        //     child: Text('Applied Offer',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold,foreground: Paint()..shader = linearGradient),),
        //   ),
        // ),

        /// .............. Applied bundle list ................
        for(int i = 0; i < widget.snapshot!.data!.data!.bundle!.length; i++)
          SliverList(
            delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index){
                return Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(width: 1,color: AppsColors.buttonColor),
                      color: const Color(0xFFFFFFFF)
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 8,horizontal: 8),
                        decoration: BoxDecoration(
                          color: AppsColors.buttonColor,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: Text(widget.snapshot!.data!.data!.bundle![i][index].bundleQty! > 1 ? '${widget.snapshot!.data!.data!.bundle![i][index].bundleQty} X ${widget.snapshot!.data!.data!.bundle![i][index].bundleNamePublic} for ${widget.snapshot!.data!.data!.bundle![i][index].totalRegularBundlePrice}' :'${widget.snapshot!.data!.data!.bundle![i][index].bundleNamePublic} for ${widget.snapshot!.data!.data!.bundle![i][index].totalRegularBundlePrice}',style: const TextStyle(color: Colors.white,fontSize: 16,fontWeight: FontWeight.w500),),
                            ),
                            SizedBox(
                              width: double.infinity,
                              child: Text('You Saved RM${widget.snapshot!.data!.data!.bundle![i][index].totalRegularPrice! - widget.snapshot!.data!.data!.bundle![i][index].totalRegularBundlePrice!}',style: const TextStyle(color: Colors.white,fontSize: 16,fontWeight: FontWeight.w500),),
                            ),
                          ],
                        ),
                      ),
                      ...List.generate(widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown!.length, (productIndex) => Container(
                        width: double.infinity,
                        margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                        decoration: const BoxDecoration(
                            color: Colors.white
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Align(
                              alignment: Alignment.topRight,
                              child: GestureDetector(
                                onTap: () async {
                                  try {
                                    final result =
                                    await InternetAddress.lookup('example.com');
                                    if (result.isNotEmpty &&
                                        result[0].rawAddress.isNotEmpty) {
                                      //int newIndex = index;
                                      showModalBottomSheet(
                                          enableDrag: true,
                                          shape: const RoundedRectangleBorder(
                                              borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(16),
                                                  topRight: Radius.circular(16))),
                                          isScrollControlled: true,
                                          isDismissible: true,
                                          context: context,
                                          builder: (context){
                                            return Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Row(
                                                  mainAxisSize: MainAxisSize.max,
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  children: [
                                                    Expanded(
                                                      flex: 1,
                                                      child: Padding(
                                                        padding: const EdgeInsets.all(4),
                                                        child: ConstrainedBox(
                                                          constraints: const BoxConstraints(
                                                              maxHeight: 100,
                                                              maxWidth: 100,
                                                              minHeight: 60,
                                                              minWidth: 60),
                                                          child: Center(
                                                              child: widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].prdVariantImagePath == null
                                                                  ? const NoImageWidget(text: 'No \nImage',)
                                                                  : CacheImageProvide(url: widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].prdVariantImagePath)
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      flex: 2,
                                                      child: Container(
                                                        width: double.infinity,
                                                        margin: const EdgeInsets.symmetric(horizontal: 8),
                                                        child: Text(
                                                          '${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].prdVarinatName}',
                                                          textAlign: TextAlign.start,
                                                          style: const TextStyle(
                                                              color: Colors.black87,
                                                              fontSize: 14,
                                                              fontWeight: FontWeight.w600),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                Container(
                                                  margin: const EdgeInsets.symmetric(horizontal: 12),
                                                  child: const Text('Are you sure you want to delete the product from cart?',style: TextStyle(color: Colors.black87),),
                                                ),
                                                const SizedBox(
                                                  height: 24,
                                                ),
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                                                  children: [
                                                      OutlinedButton(
                                                          onPressed: () {
                                                            setState(() {
                                                              Navigator.pop(context);
                                                            });
                                                          },
                                                          child: Text(
                                                            'Cancel',
                                                            style: TextStyle(
                                                                color: AppsColors.buttonColor),
                                                          )),
                                                      OutlinedButton(
                                                        style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.red)),
                                                          onPressed: (){
                                                            ///..............................................................
                                                            cartAddRemove(widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].fPrdVariantNo,1,widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].variantCount);
                                                            Common.toastMsg('Deleting...');
                                                            Navigator.pop(context);
                                                          },
                                                          child: Text(
                                                            'Ok',
                                                            style: TextStyle(
                                                                color: AppsColors.buttonColor),
                                                          )),
                                                  ],
                                                )
                                              ],
                                            );
                                          }
                                      );
                                    }
                                  } on SocketException catch (_) {
                                    Common.toastMsg('No Internet Connection');
                                  }
                                },
                                child: const Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 6, vertical: 2),
                                  child: Icon(
                                    Icons.delete_outline,
                                    color: Colors.black54,
                                  ),
                                ),
                              ),
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: GestureDetector(
                                    onTap: () async {
                                      try {
                                        final result =
                                        await InternetAddress.lookup('example.com');
                                        if (result.isNotEmpty &&
                                            result[0].rawAddress.isNotEmpty) {
                                          ProductDetailsPage.productUrl =
                                          '${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].url}';
                                          ProductDetailsPage.variantPk =
                                              widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].fPrdVariantNo;
                                          Navigator.push(
                                              context, ProductDetailsPage.route());
                                        }
                                      } on SocketException catch (_) {
                                        Common.toastMsg('No Internet Connection');
                                      }
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(12),
                                      child: ConstrainedBox(
                                        constraints: const BoxConstraints(
                                            maxHeight: 100,
                                            maxWidth: 100,
                                            minHeight: 60,
                                            minWidth: 60),
                                        child: Center(
                                            child: widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].prdVariantImagePath == null
                                                ? const NoImageWidget(text: 'No \nImage',)
                                                : CacheImageProvide(url: widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].prdVariantImagePath)
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 8),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        SizedBox(
                                          width: double.infinity,
                                          child: Text(
                                            '${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].prdVarinatName}',
                                            textAlign: TextAlign.start,
                                            style: const TextStyle(
                                                color: Colors.black87,
                                                fontSize: 16,
                                                fontWeight: FontWeight.w600),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 4,
                                        ),
                                        Row(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                                padding: const EdgeInsets.all(2),
                                                decoration: ShapeDecoration(
                                                    shape: const CircleBorder(),
                                                    color: widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].isStockOut ==
                                                        0
                                                        ? Colors.green
                                                        : Colors.amber),
                                                child: widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].isStockOut ==
                                                    0
                                                    ? const Icon(
                                                  Icons.check,
                                                  color: Colors.white,
                                                  size: 14,
                                                )
                                                    : const Icon(
                                                  Icons.warning_amber_outlined,
                                                  color: Colors.white,
                                                  size: 14,
                                                )),
                                            const SizedBox(
                                              width: 12,
                                            ),
                                            const Text(
                                              'Color',
                                              style: TextStyle(
                                                  color: Colors.black87,
                                                  fontWeight: FontWeight.normal,
                                                  fontSize: 12),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 4,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            SizedBox(
                                              // width: double.infinity,
                                              child: RichText(
                                                text: TextSpan(
                                                  text:
                                                  'RM${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].currentRegularPrice!.toStringAsFixed(2)}',
                                                  style: TextStyle(
                                                      color: AppsColors.buttonColor,
                                                      fontSize: 14,
                                                      fontWeight: FontWeight.w600),
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              child: Container(
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                    BorderRadius.circular(3),
                                                    border: Border.all(
                                                        color: Colors.transparent,
                                                        width: 1),
                                                    color: Colors.transparent),
                                                child: Row(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.min,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                                  children: [
                                                    IconButton(
                                                        onPressed: widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].variantCount > 1 ? (){
                                                          ///..............................................................
                                                          cartAddRemove(widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].fPrdVariantNo,1,1);
                                                          // Common.toastMsg('removing...');
                                                          setState(() {
                                                            widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].variantCount -=1;
                                                            widget.snapshot!.data!.data!.cartQtyCount -=1;
                                                            widget.snapshot!.data!.data!.totalPrice -= widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].currentRegularPrice!.toInt();
                                                          });
                                                        } : null,
                                                        icon: const FaIcon(FontAwesomeIcons.minusCircle,size: 18,color: Colors.black54,)),
                                                    const SizedBox(
                                                      width: 4,
                                                    ),
                                                    Text(
                                                      '${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].variantCount}',
                                                      style: const TextStyle(
                                                          color: Colors.black87,
                                                          fontSize: 18,
                                                          fontWeight:
                                                          FontWeight.normal),
                                                    ),
                                                    const SizedBox(
                                                      width: 4,
                                                    ),
                                                    IconButton(
                                                        onPressed: widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].maxOrder! > widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].variantCount
                                                            ? (){
                                                          ///..............................................................
                                                          cartAddRemove(widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].fPrdVariantNo,0,1);
                                                          // Common.toastMsg('adding...');
                                                          setState(() {
                                                            widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].variantCount +=1;
                                                            widget.snapshot!.data!.data!.cartQtyCount +=1;
                                                            widget.snapshot!.data!.data!.totalPrice += widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].currentRegularPrice!.toInt();
                                                          });
                                                        } : null,
                                                        icon: const FaIcon(FontAwesomeIcons.plusCircle,size: 18,color: Colors.black54,)),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                for (var x = 0;
                                x < widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo!.length;
                                x++)
                                  if (widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x]
                                      .selected ==
                                      1)
                                    ListTile(
                                      title: Text(
                                        widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x]
                                            .shipmentType ==
                                            null
                                            ? widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex]
                                            .stockInfo![x]
                                            .fInvWarehouseNo ==
                                            1
                                            ? 'Uk Estimated Time of Arrival 90+ days (${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x].total} available'})'
                                            : 'Ready Stock (${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x].total} available'})'
                                            : widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex]
                                            .stockInfo![x]
                                            .fInvWarehouseNo ==
                                            2
                                            ? 'Ready Stock ( ${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x].total} available'} )'
                                            : widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex]
                                            .stockInfo![x]
                                            .shipmentStatus ==
                                            10
                                            ? 'Uk Estimated Time of Arrival 90+ days (${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x].total} available'})'
                                            : 'In Transit Estimated Time of Arrival ${getDays(widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x].schArrivalDate!)} days (${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![x].total} available'})',
                                        style: const TextStyle(
                                            color: Colors.black87),
                                      ),
                                      leading: widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex]
                                          .stockInfo![x].shipmentType ==
                                          null
                                          ? widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex]
                                          .stockInfo![x].fInvWarehouseNo ==
                                          1
                                          ? const Image(
                                        image: AssetImage(
                                          'images/british_icon.gif',
                                        ),
                                        width: 24,
                                        height: 16,
                                      )
                                          : const Image(
                                        image: AssetImage(
                                          'images/malaysia_icon.gif',
                                        ),
                                        width: 24,
                                        height: 16,
                                      )
                                          : widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex]
                                          .stockInfo![x].fInvWarehouseNo ==
                                          2
                                          ? const Image(
                                        image: AssetImage(
                                          'images/malaysia_icon.gif',
                                        ),
                                        width: 24,
                                        height: 16,
                                      )
                                          : widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex]
                                          .stockInfo![x]
                                          .shipmentStatus ==
                                          10
                                          ? Row(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                        MainAxisAlignment.center,
                                        children: const [
                                          Image(
                                            image: AssetImage(
                                              'images/british_icon.gif',
                                            ),
                                            width: 24,
                                            height: 16,
                                          ),
                                          Image(
                                            image: AssetImage(
                                              'images/box.png',
                                            ),
                                            width: 24,
                                            height: 16,
                                          )
                                        ],
                                      )
                                          : widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex]
                                          .stockInfo![x]
                                          .shipmentType ==
                                          "AIR"
                                          ? const Icon(
                                        (Icons.airplanemode_active),
                                        size: 20,
                                        color: Colors.black87,
                                      )
                                          : const Image(
                                        image: AssetImage(
                                          'images/ship_icon.png',
                                        ),
                                        width: 24,
                                        height: 16,
                                      ),
                                      trailing: TextButton(
                                          onPressed: () async {
                                            int? radioGp;
                                            for(var mm = 0; mm < widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo!.length; mm++) {
                                              if (widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![mm].selected == 1) {
                                                radioGp = int.parse(widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![mm].groupValue!);
                                              }
                                            }

                                            try {
                                              final result =
                                              await InternetAddress.lookup(
                                                  'example.com');
                                              if (result.isNotEmpty &&
                                                  result[0].rawAddress.isNotEmpty) {
                                                showDialog(
                                                    barrierColor: Colors.deepOrange.withOpacity(0.1),
                                                    context: context,
                                                    builder: (context) {
                                                      return AlertDialog(
                                                        contentPadding:
                                                        const EdgeInsets.only(
                                                            top: 0, bottom: 10,left: 8),
                                                        content: Column(
                                                          mainAxisAlignment:
                                                          MainAxisAlignment.start,
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                          mainAxisSize:
                                                          MainAxisSize.min,
                                                          children: [
                                                            const SizedBox(
                                                              height: 8,
                                                              width: double.infinity,
                                                            ),
                                                            // Container(
                                                            //     height: 4,
                                                            //     width: 100,
                                                            //     decoration: BoxDecoration(
                                                            //       color: Color(0xFFF4F4F4),
                                                            //       // borderRadius: BorderRadius.circular(16.0)
                                                            //     ),
                                                            //   ),

                                                            SizedBox(
                                                              height: 45,
                                                              child: Stack(
                                                                children: [
                                                                  // Align(
                                                                  //   alignment: Alignment.topLeft,
                                                                  //   child: Image(
                                                                  //     image: AssetImage('images/azura_logo_small.png'),
                                                                  //     height: 24,
                                                                  //     // width:
                                                                  //     // MediaQuery.of(context).orientation == Orientation.portrait
                                                                  //     //     ? MediaQuery.of(context).size.width * 0.6
                                                                  //     //     : MediaQuery.of(context).size.height * 0.6,
                                                                  //   ),
                                                                  // ),
                                                                  Align(
                                                                    alignment: Alignment.topRight,
                                                                    child: IconButton(
                                                                      onPressed: () {
                                                                        Navigator.pop(context);
                                                                      },
                                                                      icon: const Icon(
                                                                        Icons.close,
                                                                        size: 20,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  const Align(
                                                                    alignment: Alignment.center,
                                                                    child: Text(
                                                                      'Change Location',
                                                                      style: TextStyle(
                                                                          color: Colors.blue,
                                                                          fontSize: 18,
                                                                          fontWeight:
                                                                          FontWeight
                                                                              .w600),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            const SizedBox(
                                                              height: 8,
                                                            ),
                                                            for (var y = 0;
                                                            y <
                                                                widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex]
                                                                    .stockInfo!
                                                                    .length;
                                                            y++)
                                                              GestureDetector(
                                                                onTap: () {
                                                                  cartLocationChange(widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].fPrdVariantNo, widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].fInvWarehouseNo, widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].fShippmentNo);
                                                                  Common.toastMsg('Changing location..');
                                                                  Navigator.pop(context);
                                                                },
                                                                child: ListTile(
                                                                  contentPadding: const EdgeInsets.only(left: 0,right: 8),
                                                                  title: Text(
                                                                    widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].shipmentType ==
                                                                        null
                                                                        ? widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].fInvWarehouseNo ==
                                                                        1
                                                                        ? 'Uk Estimated Time of Arrival 90+ days (${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].total} available'})'
                                                                        : 'Ready Stock (${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].total} available'})'
                                                                        :widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex]
                                                                        .stockInfo![y]
                                                                        .fInvWarehouseNo ==
                                                                        2
                                                                        ? 'Ready Stock ( ${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].total} available'} )'
                                                                        : widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].shipmentStatus == 10
                                                                        ? 'Uk Estimated Time of Arrival 90+ days (${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].total} available'})'
                                                                        : 'In Transit Estimated Time of Arrival ${getDays(widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].schArrivalDate!)} days (${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].total} available'})',
                                                                    style: TextStyle(
                                                                        color: widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].selected == 1
                                                                            ? AppsColors.buttonColor
                                                                            : Colors
                                                                            .black87),
                                                                  ),
                                                                  leading: Radio(
                                                                    value: int.parse(widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y]
                                                                        .groupValue!),
                                                                    groupValue: radioGp,
                                                                    activeColor: AppsColors.buttonColor,
                                                                    onChanged: widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].selected == 1
                                                                        ? null
                                                                        : (int?
                                                                    value) {
                                                                      cartLocationChange(widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].fPrdVariantNo, widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].fInvWarehouseNo, widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].fShippmentNo);
                                                                      Common.toastMsg('Changing location..');
                                                                      Navigator.pop(context);
                                                                    },
                                                                  ),
                                                                  trailing: widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex]
                                                                      .stockInfo![
                                                                  y]
                                                                      .shipmentType ==
                                                                      null
                                                                      ? widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].fInvWarehouseNo ==
                                                                      1
                                                                      ? const Image(
                                                                    image:
                                                                    AssetImage(
                                                                      'images/british_icon.gif',
                                                                    ),
                                                                    width:
                                                                    24,
                                                                    height:
                                                                    16,
                                                                  )
                                                                      : const Image(
                                                                    image:
                                                                    AssetImage(
                                                                      'images/malaysia_icon.gif',
                                                                    ),
                                                                    width:
                                                                    24,
                                                                    height:
                                                                    16,
                                                                  )
                                                                      : widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex]
                                                                      .stockInfo![
                                                                  y]
                                                                      .fInvWarehouseNo ==
                                                                      2
                                                                      ? const Image(
                                                                    image:
                                                                    AssetImage(
                                                                      'images/malaysia_icon.gif',
                                                                    ),
                                                                    width:
                                                                    24,
                                                                    height:
                                                                    16,
                                                                  )
                                                                      : widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].shipmentStatus ==
                                                                      10
                                                                      ? Row(
                                                                    mainAxisSize:
                                                                    MainAxisSize.min,
                                                                    mainAxisAlignment:
                                                                    MainAxisAlignment.center,
                                                                    children: const [
                                                                      Image(
                                                                        image: AssetImage(
                                                                          'images/british_icon.gif',
                                                                        ),
                                                                        width: 24,
                                                                        height: 16,
                                                                      ),
                                                                      Image(
                                                                        image: AssetImage(
                                                                          'images/box.png',
                                                                        ),
                                                                        width: 24,
                                                                        height: 16,
                                                                      )
                                                                    ],
                                                                  )
                                                                      : widget.snapshot!.data!.data!.bundle![i][index].bundleBreakdown![productIndex].stockInfo![y].shipmentType ==
                                                                      "AIR"
                                                                      ? const Icon(
                                                                    (Icons.airplanemode_active),
                                                                    size: 20,
                                                                    color: Colors.black87,
                                                                  )
                                                                      : const Image(
                                                                    image: AssetImage(
                                                                      'images/ship_icon.png',
                                                                    ),
                                                                    width: 24,
                                                                    height: 16,
                                                                  ),
                                                                  minLeadingWidth: 24,
                                                                  horizontalTitleGap:
                                                                  0,
                                                                  hoverColor: AppsColors.buttonColor
                                                                      .withOpacity(
                                                                      0.5),
                                                                  focusColor: AppsColors.buttonColor
                                                                      .withOpacity(
                                                                      0.5),
                                                                ),
                                                              ),
                                                          ],
                                                        ),
                                                      );
                                                    });
                                              }
                                            } on SocketException catch (_) {
                                              Common.toastMsg(
                                                  'No internet Connection');
                                            }
                                          },
                                          child: GestureDetector(
                                            child: FaIcon(
                                              FontAwesomeIcons.exchangeAlt,
                                              color: AppsColors.buttonColor,
                                              size: 20,
                                            ),
                                          )),
                                      minLeadingWidth: 24,
                                      // horizontalTitleGap: 0,
                                      hoverColor: AppsColors.buttonColor.withOpacity(0.5),
                                      focusColor: AppsColors.buttonColor.withOpacity(0.5),
                                    ),
                              ],
                            ),
                          ],
                        ),
                      )),
                    ],
                  ),
                );
              },
              childCount: widget.snapshot!.data!.data!.bundle![i].length,
            ),
          ),
        /// .............. Applied bundle list ................

        /// .............. Non bundle list ................
        for(int i = 0; i < widget.snapshot!.data!.data!.nonBundle!.length; i++)
          SliverList(
            delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index){
                return Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                  decoration: const BoxDecoration(
                      color: Colors.white
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: GestureDetector(
                          onTap: () async {
                            try {
                              final result =
                              await InternetAddress.lookup('example.com');
                              if (result.isNotEmpty &&
                                  result[0].rawAddress.isNotEmpty) {
                                //int newIndex = index;
                                showModalBottomSheet(
                                    enableDrag: true,
                                    shape: const RoundedRectangleBorder(
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(16),
                                            topRight: Radius.circular(16))),
                                    isScrollControlled: true,
                                    isDismissible: true,
                                    context: context,
                                    builder: (context){
                                      return Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: [
                                              Expanded(
                                                flex: 1,
                                                child: Padding(
                                                  padding: const EdgeInsets.all(4),
                                                  child: ConstrainedBox(
                                                    constraints: const BoxConstraints(
                                                        maxHeight: 100,
                                                        maxWidth: 100,
                                                        minHeight: 60,
                                                        minWidth: 60),
                                                    child: Center(
                                                        child: widget.snapshot!.data!.data!.nonBundle![i][index].prdVariantImagePath == null
                                                            ? const NoImageWidget(text: 'No \nImage',)
                                                            : CacheImageProvide(url: widget.snapshot!.data!.data!.nonBundle![i][index].prdVariantImagePath)
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                flex: 2,
                                                child: Container(
                                                  width: double.infinity,
                                                  margin: const EdgeInsets.symmetric(horizontal: 8),
                                                  child: Text(
                                                    '${widget.snapshot!.data!.data!.nonBundle![i][index].prdVarinatName}',
                                                    textAlign: TextAlign.start,
                                                    style: const TextStyle(
                                                        color: Colors.black87,
                                                        fontSize: 14,
                                                        fontWeight: FontWeight.w600),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Container(
                                            margin: const EdgeInsets.symmetric(horizontal: 12),
                                            child: const Text('Are you sure you want to delete the product from cart?'),
                                          ),
                                          const SizedBox(
                                            height: 24,
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                                            children: [
                                              OutlinedButton(
                                                  onPressed: () {
                                                    setState(() {
                                                      Navigator.pop(context);
                                                    });
                                                  },
                                                  child: Text(
                                                    'Cancel',
                                                    style: TextStyle(
                                                        color: AppsColors.buttonColor),
                                                  )),
                                              OutlinedButton(
                                                  style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.red)),
                                                  onPressed: (){
                                                    ///..............................................................
                                                    cartAddRemove(widget.snapshot!.data!.data!.nonBundle![i][index].fPrdVariantNo,1,widget.snapshot!.data!.data!.nonBundle![i][index].itemQty);
                                                    widget.snapshot!.data!.data!.nonBundle![i].removeAt(index);
                                                    setState(() {
                                                    });
                                                    Common.toastMsg('Deleting...');
                                                    Navigator.pop(context);
                                                  },
                                                  child: Text(
                                                    'Ok',
                                                    style: TextStyle(
                                                        color: AppsColors.buttonColor),
                                                  )
                                              ),
                                            ],
                                          )
                                        ],
                                      );
                                    }
                                );
                              }
                            } on SocketException catch (_) {
                              Common.toastMsg('No Internet Connection');
                            }
                          },
                          child: const Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            child: Icon(
                              Icons.delete_outline,
                              color: Colors.black54,
                            ),
                          ),
                        ),
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 1,
                            child: GestureDetector(
                              onTap: () async {
                                try {
                                  final result =
                                  await InternetAddress.lookup('example.com');
                                  if (result.isNotEmpty &&
                                      result[0].rawAddress.isNotEmpty) {
                                    ProductDetailsPage.productUrl =
                                    '${widget.snapshot!.data!.data!.nonBundle![i][index].url}';
                                    ProductDetailsPage.variantPk =
                                        widget.snapshot!.data!.data!.nonBundle![i][index].fPrdVariantNo;
                                    Navigator.push(
                                        context, ProductDetailsPage.route());
                                  }
                                } on SocketException catch (_) {
                                  Common.toastMsg('No Internet Connection');
                                }
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: ConstrainedBox(
                                  constraints: const BoxConstraints(
                                      maxHeight: 100,
                                      maxWidth: 100,
                                      minHeight: 60,
                                      minWidth: 60),
                                  child: Center(
                                      child: widget.snapshot!.data!.data!.nonBundle![i][index].prdVariantImagePath == null
                                          ? const NoImageWidget(text: 'No \nImage',)
                                          : CacheImageProvide(url: widget.snapshot!.data!.data!.nonBundle![i][index].prdVariantImagePath)
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 2,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 8),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    width: double.infinity,
                                    child: Text(
                                      '${widget.snapshot!.data!.data!.nonBundle![i][index].prdVarinatName}',
                                      textAlign: TextAlign.start,
                                      style: const TextStyle(
                                          color: Colors.black87,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 4,
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                          padding: const EdgeInsets.all(2),
                                          decoration: ShapeDecoration(
                                              shape: const CircleBorder(),
                                              color: widget.snapshot!.data!.data!.nonBundle![i][index].isStockOut ==
                                                  0
                                                  ? Colors.green
                                                  : Colors.amber),
                                          child: widget.snapshot!.data!.data!.nonBundle![i][index].isStockOut ==
                                              0
                                              ? const Icon(
                                            Icons.check,
                                            color: Colors.white,
                                            size: 14,
                                          )
                                              : const Icon(
                                            Icons.warning_amber_outlined,
                                            color: Colors.white,
                                            size: 14,
                                          )),
                                      const SizedBox(
                                        width: 12,
                                      ),
                                      const Text(
                                        'Color',
                                        style: TextStyle(
                                            color: Colors.black87,
                                            fontWeight: FontWeight.normal,
                                            fontSize: 12),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 4,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      SizedBox(
                                        // width: double.infinity,
                                        child: RichText(
                                          text: TextSpan(
                                            text:
                                            'RM${widget.snapshot!.data!.data!.nonBundle![i][index].currentRegularPrice!.toStringAsFixed(2)}',
                                            style: TextStyle(
                                                color: AppsColors.buttonColor,
                                                fontSize: 14,
                                                fontWeight: FontWeight.w600),
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        child: Container(
                                          decoration: BoxDecoration(
                                              borderRadius:
                                              BorderRadius.circular(3),
                                              border: Border.all(
                                                  color: Colors.transparent,
                                                  width: 1),
                                              color: Colors.transparent),
                                          child: Row(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                            MainAxisAlignment.center,
                                            children: [
                                              IconButton(
                                                  onPressed: widget.snapshot!.data!.data!.nonBundle![i][index].itemQty > 1 ? (){
                                                    ///..............................................................
                                                    cartAddRemove(widget.snapshot!.data!.data!.nonBundle![i][index].fPrdVariantNo,1,1);
                                                    // Common.toastMsg('removing...');
                                                    setState(() {
                                                      widget.snapshot!.data!.data!.nonBundle![i][index].itemQty -=1;
                                                      widget.snapshot!.data!.data!.cartQtyCount -=1;
                                                      widget.snapshot!.data!.data!.totalPrice -= widget.snapshot!.data!.data!.nonBundle![i][index].currentRegularPrice!.toInt();
                                                    });
                                                  } : null,
                                                  icon: const FaIcon(FontAwesomeIcons.minusCircle,size: 18,color: Colors.black54,)
                                              ),
                                              const SizedBox(
                                                width: 4,
                                              ),
                                              Text(
                                                '${widget.snapshot!.data!.data!.nonBundle![i][index].itemQty}',
                                                style: const TextStyle(
                                                    color: Colors.black87,
                                                    fontSize: 18,
                                                    fontWeight:
                                                    FontWeight.normal),
                                              ),
                                              const SizedBox(
                                                width: 4,
                                              ),
                                              IconButton(
                                                  onPressed: widget.snapshot!.data!.data!.nonBundle![i][index].maxOrder! > widget.snapshot!.data!.data!.nonBundle![i][index].itemQty
                                                      ? (){
                                                    ///..............................................................
                                                    cartAddRemove(widget.snapshot!.data!.data!.nonBundle![i][index].fPrdVariantNo,0,1);
                                                    setState(() {
                                                      widget.snapshot!.data!.data!.nonBundle![i][index].itemQty +=1;
                                                      widget.snapshot!.data!.data!.cartQtyCount +=1;
                                                      widget.snapshot!.data!.data!.totalPrice += widget.snapshot!.data!.data!.nonBundle![i][index].currentRegularPrice!.toInt();
                                                    });
                                                  } : null,
                                                  icon: const FaIcon(FontAwesomeIcons.plusCircle,size: 18,color: Colors.black54,)),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      ///................ offer.............
                      LayoutBuilder(
                        builder: (BuildContext context, BoxConstraints constraints){
                          if (widget.snapshot!.data!.data!.nonBundle![i][index].checkOfferVariant != null) {
                            return Container(
                              width: double.infinity,
                              height: 45,
                              margin: const EdgeInsets.symmetric(vertical: 4,horizontal: 10),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: const BorderRadius.only(
                                    bottomLeft: Radius.circular(6.0),
                                    topLeft: Radius.circular(6.0)),
                                border: Border.all(color: AppsColors.buttonColor, width: 1),
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Material(
                                      color: AppsColors.buttonColor,
                                      shape: const BeveledRectangleBorder(
                                          borderRadius: BorderRadius.only(
                                              bottomRight: Radius.circular(6.0),
                                              topRight: Radius.circular(6.0))),
                                      type: MaterialType.canvas,
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 4),
                                        height: double.infinity,
                                        decoration: const BoxDecoration(
                                          // color: Colors.pink,
                                          // gradient: LinearGradient(
                                          //     colors: [
                                          //       Colors.red,
                                          //       Colors.redAccent,
                                          //     ],
                                          //     begin: Alignment.topCenter,
                                          //     end: Alignment.bottomCenter),
                                          // shape: BeveledRectangleBorder(borderRadius: BorderRadius.only(bottomRight: Radius.circular(50.0)))
                                          // borderRadius: BorderRadius.only(
                                          //     bottomRight: Radius.circular(16))
                                        ),
                                        child: Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.min,
                                          children: const [
                                            Icon(
                                              Icons.local_offer,
                                              color: Colors.white,
                                              size: 16,
                                            ),
                                            SizedBox(
                                              width: 8,
                                            ),
                                            Text(
                                              'Offer',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w600),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 3,
                                    child: Container(
                                      width: double.infinity,
                                      padding:
                                      const EdgeInsets.symmetric(horizontal: 4),
                                      child: Text(
                                        '${widget.snapshot!.data!.data!.nonBundle![i][index].checkOfferVariant!.bundleNamePublic}',
                                        style: const TextStyle(
                                            color: Colors.black54,
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            );
                          }  else{
                            return const SizedBox(
                              height: 0,
                            );
                          }
                        },
                      ),
                      ///................ offer ...............
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          for (var x = 0;
                          x < widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo!.length;
                          x++)
                            if (widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x]
                                .selected ==
                                1)
                              ListTile(
                                title: Text(
                                  widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x]
                                      .shipmentType ==
                                      null
                                      ? widget.snapshot!.data!.data!.nonBundle![i][index]
                                      .stockInfo![x]
                                      .fInvWarehouseNo ==
                                      1
                                      ? 'Uk Estimated Time of Arrival 90+ days (${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total} available'})'
                                      : 'Ready Stock (${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total} available'})'
                                      : widget.snapshot!.data!.data!.nonBundle![i][index]
                                      .stockInfo![x]
                                      .fInvWarehouseNo ==
                                      2
                                      ? 'Ready Stock ( ${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total} available'} )'
                                      : widget.snapshot!.data!.data!.nonBundle![i][index]
                                      .stockInfo![x]
                                      .shipmentStatus ==
                                      10
                                      ? 'Uk Estimated Time of Arrival 90+ days (${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total} available'})'
                                      : 'In Transit Estimated Time of Arrival ${getDays(widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].schArrivalDate!)} days (${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total} available'})',
                                  style: const TextStyle(
                                      color:
                                      // stockInfoRG2[index] ==
                                      //     int.parse(widget.snapshot.data.data.bundle[i][index]
                                      //         .stockInfo[i]
                                      //         .groupValue)
                                      // // ? Color(0xFFF68721)
                                      //     ? Color(0xFF000000)
                                      //     :
                                      Colors.black87),
                                ),
                                leading: widget.snapshot!.data!.data!.nonBundle![i][index]
                                    .stockInfo![x].shipmentType ==
                                    null
                                    ? widget.snapshot!.data!.data!.nonBundle![i][index]
                                    .stockInfo![x].fInvWarehouseNo ==
                                    1
                                    ? const Image(
                                  image: AssetImage(
                                    'images/british_icon.gif',
                                  ),
                                  width: 24,
                                  height: 16,
                                )
                                    : const Image(
                                  image: AssetImage(
                                    'images/malaysia_icon.gif',
                                  ),
                                  width: 24,
                                  height: 16,
                                )
                                    : widget.snapshot!.data!.data!.nonBundle![i][index]
                                    .stockInfo![x].fInvWarehouseNo ==
                                    2
                                    ? const Image(
                                  image: AssetImage(
                                    'images/malaysia_icon.gif',
                                  ),
                                  width: 24,
                                  height: 16,
                                )
                                    : widget.snapshot!.data!.data!.nonBundle![i][index]
                                    .stockInfo![x]
                                    .shipmentStatus ==
                                    10
                                    ? Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment:
                                  MainAxisAlignment.center,
                                  children: const [
                                    Image(
                                      image: AssetImage(
                                        'images/british_icon.gif',
                                      ),
                                      width: 24,
                                      height: 16,
                                    ),
                                    Image(
                                      image: AssetImage(
                                        'images/box.png',
                                      ),
                                      width: 24,
                                      height: 16,
                                    )
                                  ],
                                )
                                    : widget.snapshot!.data!.data!.nonBundle![i][index]
                                    .stockInfo![x]
                                    .shipmentType ==
                                    "AIR"
                                    ? const Icon(
                                  (Icons.airplanemode_active),
                                  size: 20,
                                  color: Colors.black87,
                                )
                                    : const Image(
                                  image: AssetImage(
                                    'images/ship_icon.png',
                                  ),
                                  width: 24,
                                  height: 16,
                                ),
                                trailing: TextButton(
                                    onPressed: () async {
                                      int? radioGp;
                                      for(var mm = 0; mm < widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo!.length; mm++) {
                                        if (widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![mm].selected == 1) {
                                          radioGp = int.parse(widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![mm].groupValue!);
                                        }
                                      }
                                      try {
                                        final result =
                                        await InternetAddress.lookup(
                                            'example.com');
                                        if (result.isNotEmpty &&
                                            result[0].rawAddress.isNotEmpty) {
                                          showDialog(
                                              context: context,
                                              barrierColor: Colors.deepOrange.withOpacity(0.1),
                                              builder: (context) {
                                                return AlertDialog(
                                                  contentPadding:
                                                  const EdgeInsets.only(
                                                      top: 0, bottom: 10,left: 8),
                                                  content: Column(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .center,
                                                    mainAxisSize:
                                                    MainAxisSize.min,
                                                    children: [
                                                      const SizedBox(
                                                        height: 8,
                                                        width: double.infinity,
                                                      ),
                                                      // Container(
                                                      //     height: 4,
                                                      //     width: 100,
                                                      //     decoration: BoxDecoration(
                                                      //       color: Color(0xFFF4F4F4),
                                                      //       // borderRadius: BorderRadius.circular(16.0)
                                                      //     ),
                                                      //   ),

                                                      SizedBox(
                                                        height: 45,
                                                        child: Stack(
                                                          children: [
                                                            // Align(
                                                            //   alignment: Alignment.topLeft,
                                                            //   child: Image(
                                                            //     image: AssetImage('images/azura_logo_small.png'),
                                                            //     height: 24,
                                                            //     // width:
                                                            //     // MediaQuery.of(context).orientation == Orientation.portrait
                                                            //     //     ? MediaQuery.of(context).size.width * 0.6
                                                            //     //     : MediaQuery.of(context).size.height * 0.6,
                                                            //   ),
                                                            // ),
                                                            Align(
                                                              alignment: Alignment.topRight,
                                                              child: IconButton(
                                                                onPressed: () {
                                                                  Navigator.pop(context);
                                                                },
                                                                icon: const Icon(
                                                                  Icons.close,
                                                                  size: 20,
                                                                ),
                                                              ),
                                                            ),
                                                            const Align(
                                                              alignment: Alignment.center,
                                                              child: Text(
                                                                'Change Location',
                                                                style: TextStyle(
                                                                    color: Colors.blue,
                                                                    fontSize: 18,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w600),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                        height: 8,
                                                      ),
                                                      for (var x = 0;
                                                      x <
                                                          widget.snapshot!.data!.data!.nonBundle![i][index]
                                                              .stockInfo!
                                                              .length;
                                                      x++)
                                                        GestureDetector(
                                                          onTap: () {
                                                            ///.................................................
                                                            cartLocationChange(widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].fPrdVariantNo, widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].fInvWarehouseNo, widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].fShippmentNo);
                                                            Common.toastMsg('Changing location..');
                                                            Navigator.pop(context);
                                                          },
                                                          child: ListTile(
                                                            contentPadding: const EdgeInsets.only(left: 0,right: 8),
                                                            title: Text(
                                                              widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].shipmentType ==
                                                                  null
                                                                  ? widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].fInvWarehouseNo ==
                                                                  1
                                                                  ? 'Uk Estimated Time of Arrival 90+ days (${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total} available'})'
                                                                  : 'Ready Stock (${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total} available'})'
                                                                  :widget.snapshot!.data!.data!.nonBundle![i][index]
                                                                  .stockInfo![x]
                                                                  .fInvWarehouseNo ==
                                                                  2
                                                                  ? 'Ready Stock ( ${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total} available'} )'
                                                                  : widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].shipmentStatus == 10
                                                                  ? 'Uk Estimated Time of Arrival 90+ days (${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total} available'})'
                                                                  : 'In Transit Estimated Time of Arrival ${getDays(widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].schArrivalDate!)} days (${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].total} available'})',
                                                              style: TextStyle(
                                                                  color: widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].selected == 1
                                                                      ? AppsColors.buttonColor
                                                                      : Colors
                                                                      .black87),
                                                            ),
                                                            leading: Radio(
                                                              value: int.parse(widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x]
                                                                  .groupValue!),
                                                              groupValue: radioGp,
                                                              activeColor: AppsColors.buttonColor,
                                                              onChanged: widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].selected == 1
                                                                  ? null
                                                                  : (int?
                                                              value) {
                                                                cartLocationChange(widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].fPrdVariantNo, widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].fInvWarehouseNo, widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].fShippmentNo);
                                                                Common.toastMsg('Changing location..');
                                                                Navigator.pop(context);
                                                              },
                                                            ),
                                                            trailing: widget.snapshot!.data!.data!.nonBundle![i][index]
                                                                .stockInfo![
                                                            x]
                                                                .shipmentType ==
                                                                null
                                                                ? widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].fInvWarehouseNo ==
                                                                1
                                                                ? const Image(
                                                              image:
                                                              AssetImage(
                                                                'images/british_icon.gif',
                                                              ),
                                                              width:
                                                              24,
                                                              height:
                                                              16,
                                                            )
                                                                : const Image(
                                                              image:
                                                              AssetImage(
                                                                'images/malaysia_icon.gif',
                                                              ),
                                                              width:
                                                              24,
                                                              height:
                                                              16,
                                                            )
                                                                : widget.snapshot!.data!.data!.nonBundle![i][index]
                                                                .stockInfo![
                                                            x]
                                                                .fInvWarehouseNo ==
                                                                2
                                                                ? const Image(
                                                              image:
                                                              AssetImage(
                                                                'images/malaysia_icon.gif',
                                                              ),
                                                              width:
                                                              24,
                                                              height:
                                                              16,
                                                            )
                                                                : widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].shipmentStatus ==
                                                                10
                                                                ? Row(
                                                              mainAxisSize:
                                                              MainAxisSize.min,
                                                              mainAxisAlignment:
                                                              MainAxisAlignment.center,
                                                              children: const [
                                                                Image(
                                                                  image: AssetImage(
                                                                    'images/british_icon.gif',
                                                                  ),
                                                                  width: 24,
                                                                  height: 16,
                                                                ),
                                                                Image(
                                                                  image: AssetImage(
                                                                    'images/box.png',
                                                                  ),
                                                                  width: 24,
                                                                  height: 16,
                                                                )
                                                              ],
                                                            )
                                                                : widget.snapshot!.data!.data!.nonBundle![i][index].stockInfo![x].shipmentType ==
                                                                "AIR"
                                                                ? const Icon(
                                                              (Icons.airplanemode_active),
                                                              size: 20,
                                                              color: Colors.black87,
                                                            )
                                                                : const Image(
                                                              image: AssetImage(
                                                                'images/ship_icon.png',
                                                              ),
                                                              width: 24,
                                                              height: 16,
                                                            ),
                                                            minLeadingWidth: 24,
                                                            horizontalTitleGap:
                                                            0,
                                                            hoverColor: AppsColors.buttonColor
                                                                .withOpacity(
                                                                0.5),
                                                            focusColor: AppsColors.buttonColor
                                                                .withOpacity(
                                                                0.5),
                                                          ),
                                                        ),
                                                    ],
                                                  ),
                                                );
                                              });
                                        }
                                      } on SocketException catch (_) {
                                        Common.toastMsg(
                                            'No internet Connection');
                                      }
                                    },
                                    child: GestureDetector(
                                      child: FaIcon(
                                        FontAwesomeIcons.exchangeAlt,
                                        color: AppsColors.buttonColor,
                                        size: 20,
                                      ),
                                    )),
                                minLeadingWidth: 24,
                                // horizontalTitleGap: 0,
                                hoverColor: AppsColors.buttonColor.withOpacity(0.5),
                                focusColor: AppsColors.buttonColor.withOpacity(0.5),
                              ),
                        ],
                      ),
                    ],
                  ),
                );
              },
              childCount: widget.snapshot!.data!.data!.nonBundle![i].length,
            ),
          ),

        /// .............. Normal cart list ................
        SliverList(
          delegate: SliverChildBuilderDelegate(
              (BuildContext context, int index){
                return Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                  decoration: const BoxDecoration(
                      color: Colors.white
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: GestureDetector(
                          onTap: () async {
                            try {
                              final result =
                              await InternetAddress.lookup('example.com');
                              if (result.isNotEmpty &&
                                  result[0].rawAddress.isNotEmpty) {
                                //int newIndex = index;
                                showModalBottomSheet(
                                    enableDrag: true,
                                    shape: const RoundedRectangleBorder(
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(16),
                                            topRight: Radius.circular(16))),
                                    isScrollControlled: true,
                                    isDismissible: true,
                                    context: context,
                                    builder: (context){
                                      return Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: [
                                              Expanded(
                                                flex: 1,
                                                child: Padding(
                                                  padding: const EdgeInsets.all(4),
                                                  child: ConstrainedBox(
                                                    constraints: const BoxConstraints(
                                                        maxHeight: 100,
                                                        maxWidth: 100,
                                                        minHeight: 60,
                                                        minWidth: 60),
                                                    child: Center(
                                                        child: widget.snapshot!.data!.data!.cart![index].products!.primaryImgRelativePath == null &&  widget.snapshot!.data!.data!.cart![index].products!.thumbPath == null
                                                            ? const NoImageWidget(text: 'No \nImage',)
                                                            :  widget.snapshot!.data!.data!.cart![index].products!.thumbPath != null ? CacheImageProvide(url: widget.snapshot!.data!.data!.cart![index].products!.thumbPath) : CacheImageProvide(url: widget.snapshot!.data!.data!.cart![index].products!.primaryImgRelativePath)
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                flex: 2,
                                                child: Container(
                                                  width: double.infinity,
                                                  margin: const EdgeInsets.symmetric(horizontal: 8),
                                                  child: Text(
                                                    '${widget.snapshot!.data!.data!.cart![index].products!.variantName}',
                                                    textAlign: TextAlign.start,
                                                    style: const TextStyle(
                                                        color: Colors.black87,
                                                        fontSize: 14,
                                                        fontWeight: FontWeight.w600),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Container(
                                            margin: const EdgeInsets.symmetric(horizontal: 12),
                                            child: const Text('Are you sure you want to delete the product from cart?',style: TextStyle(color: Colors.black87),),
                                          ),
                                          const SizedBox(
                                            height: 24,
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                                            children: [
                                              OutlinedButton(
                                                  onPressed: () {
                                                    setState(() {
                                                      Navigator.pop(context);
                                                    });
                                                  },
                                                  child: Text(
                                                    'Cancel',
                                                    style: TextStyle(
                                                        color: AppsColors.buttonColor),
                                                  )),
                                              OutlinedButton(
                                                  style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.red)),
                                                  onPressed: (){
                                                    cartAddRemove(widget.snapshot!.data!.data!.cart![index].fPrdVariantNo,1,widget.snapshot!.data!.data!.cart![index].totalItemQty);
                                                    Common.toastMsg('Deleting...');
                                                    Navigator.pop(context);
                                                  },
                                                  child: Text(
                                                    'Ok',
                                                    style: TextStyle(
                                                        color: AppsColors.buttonColor),
                                                  )),
                                            ],
                                          )
                                        ],
                                      );
                                    }
                                );
                              }
                            } on SocketException catch (_) {
                              Common.toastMsg('No Internet Connection');
                            }
                          },
                          child: const Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            child: Icon(
                              Icons.delete_outline,
                              color: Colors.black54,
                            ),
                          ),
                        ),
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 1,
                            child: GestureDetector(
                              onTap: () async {
                                try {
                                  final result =
                                  await InternetAddress.lookup('example.com');
                                  if (result.isNotEmpty &&
                                      result[0].rawAddress.isNotEmpty) {
                                    ProductDetailsPage.productUrl =
                                    '${widget.snapshot!.data!.data!.cart![index].products!.url}';
                                    ProductDetailsPage.variantPk =
                                        widget.snapshot!.data!.data!.cart![index].products!.pkNo;
                                    Navigator.push(
                                        context, ProductDetailsPage.route());
                                  }
                                } on SocketException catch (_) {
                                  Common.toastMsg('No Internet Connection');
                                }
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: ConstrainedBox(
                                  constraints: const BoxConstraints(
                                      maxHeight: 100,
                                      maxWidth: 100,
                                      minHeight: 60,
                                      minWidth: 60),
                                  child: Center(
                                      child: widget.snapshot!.data!.data!.cart![index].products!.primaryImgRelativePath == null &&  widget.snapshot!.data!.data!.cart![index].products!.thumbPath == null
                                          ? const NoImageWidget(text: 'No \nImage',)
                                          :  widget.snapshot!.data!.data!.cart![index].products!.thumbPath != null ? CacheImageProvide(url: widget.snapshot!.data!.data!.cart![index].products!.thumbPath) : CacheImageProvide(url: widget.snapshot!.data!.data!.cart![index].products!.primaryImgRelativePath)
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 2,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 8),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    width: double.infinity,
                                    child: Text(
                                      '${widget.snapshot!.data!.data!.cart![index].products!.variantName}',
                                      textAlign: TextAlign.start,
                                      style: const TextStyle(
                                          color: Colors.black87,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 4,
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                          padding: const EdgeInsets.all(2),
                                          decoration: ShapeDecoration(
                                              shape: const CircleBorder(),
                                              color: widget.snapshot!.data!.data!.cart![index].totalItemQty >
                                                  0
                                                  ? Colors.green
                                                  : Colors.amber),
                                          child:  widget.snapshot!.data!.data!.cart![index].totalItemQty >
                                              0
                                              ? const Icon(
                                            Icons.check,
                                            color: Colors.white,
                                            size: 14,
                                          )
                                              : const Icon(
                                            Icons.warning_amber_outlined,
                                            color: Colors.white,
                                            size: 14,
                                          )),
                                      const SizedBox(
                                        width: 12,
                                      ),
                                      const Text(
                                        'Color',
                                        style: TextStyle(
                                            color: Colors.black87,
                                            fontWeight: FontWeight.normal,
                                            fontSize: 12),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 4,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      SizedBox(
                                        // width: double.infinity,
                                        child: RichText(
                                          text: TextSpan(
                                            text:
                                            'RM${ widget.snapshot!.data!.data!.cart![index].regularPrice!.toStringAsFixed(2)}',
                                            style: TextStyle(
                                                color: AppsColors.buttonColor,
                                                fontSize: 14,
                                                fontWeight: FontWeight.w600),
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        child: Container(
                                          decoration: BoxDecoration(
                                              borderRadius:
                                              BorderRadius.circular(3),
                                              border: Border.all(
                                                  color: Colors.transparent,
                                                  width: 1),
                                              color: Colors.transparent),
                                          child: Row(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                            MainAxisAlignment.center,
                                            children: [
                                              IconButton(
                                                  onPressed: widget.snapshot!.data!.data!.cart![index].totalItemQty > 1 ? (){
                                                    ///..............................................................
                                                    cartAddRemove(widget.snapshot!.data!.data!.cart![index].fPrdVariantNo,1,1);
                                                    // Common.toastMsg('removing...');
                                                    setState(() {
                                                      widget.snapshot!.data!.data!.cart![index].totalItemQty -=1;
                                                      widget.snapshot!.data!.data!.totalPrice -= widget.snapshot!.data!.data!.cart![index].regularPrice!.toInt();
                                                      widget.snapshot!.data!.data!.cartQtyCount -=1;
                                                    });
                                                  } : null,
                                                  icon: const FaIcon(FontAwesomeIcons.minusCircle,size: 18,color: Colors.black54,)),
                                              const SizedBox(
                                                width: 4,
                                              ),
                                              Text(
                                                '${widget.snapshot!.data!.data!.cart![index].totalItemQty}',
                                                style: const TextStyle(
                                                    color: Colors.black87,
                                                    fontSize: 18,
                                                    fontWeight:
                                                    FontWeight.normal),
                                              ),
                                              const SizedBox(
                                                width: 4,
                                              ),
                                              IconButton(
                                                  onPressed: widget.snapshot!.data!.data!.cart![index].products!.maxOrder! > widget.snapshot!.data!.data!.cart![index].totalItemQty
                                                      ? (){
                                                    ///..............................................................
                                                    cartAddRemove(widget.snapshot!.data!.data!.cart![index].fPrdVariantNo,0,1);
                                                    setState(() {
                                                      widget.snapshot!.data!.data!.cart![index].totalItemQty +=1;
                                                      widget.snapshot!.data!.data!.totalPrice += widget.snapshot!.data!.data!.cart![index].regularPrice!.toInt();
                                                      widget.snapshot!.data!.data!.cartQtyCount +=1;
                                                    });
                                                  } : null,
                                                  icon: const FaIcon(FontAwesomeIcons.plusCircle,size: 18,color: Colors.black54,)),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      LayoutBuilder(
                        builder: (BuildContext context, BoxConstraints constraints){
                          if (widget.snapshot!.data!.data!.cart![index].bundleNamePublic != "") {
                            return Container(
                              width: double.infinity,
                              height: 45,
                              margin: const EdgeInsets.symmetric(vertical: 4,horizontal: 10),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: const BorderRadius.only(
                                    bottomLeft: Radius.circular(6.0),
                                    topLeft: Radius.circular(6.0)),
                                border: Border.all(color: AppsColors.buttonColor, width: 1),
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Material(
                                      color: AppsColors.buttonColor,
                                      shape: const BeveledRectangleBorder(
                                          borderRadius: BorderRadius.only(
                                              bottomRight: Radius.circular(6.0),
                                              topRight: Radius.circular(6.0))),
                                      type: MaterialType.canvas,
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 4),
                                        height: double.infinity,
                                        decoration: const BoxDecoration(
                                          // color: Colors.pink,
                                          // gradient: LinearGradient(
                                          //     colors: [
                                          //       Colors.red,
                                          //       Colors.redAccent,
                                          //     ],
                                          //     begin: Alignment.topCenter,
                                          //     end: Alignment.bottomCenter),
                                          // shape: BeveledRectangleBorder(borderRadius: BorderRadius.only(bottomRight: Radius.circular(50.0)))
                                          // borderRadius: BorderRadius.only(
                                          //     bottomRight: Radius.circular(16))
                                        ),
                                        child: Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.min,
                                          children: const [
                                            Icon(
                                              Icons.local_offer,
                                              color: Colors.white,
                                              size: 16,
                                            ),
                                            SizedBox(
                                              width: 8,
                                            ),
                                            Text(
                                              'Offer',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w600),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 3,
                                    child: Container(
                                      width: double.infinity,
                                      padding:
                                      const EdgeInsets.symmetric(horizontal: 4),
                                      child: Text(
                                        '${widget.snapshot!.data!.data!.cart![index].bundleNamePublic}',
                                        style: const TextStyle(
                                            color: Colors.black54,
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            );
                          }  else{
                            return const SizedBox(
                              height: 0,
                            );
                          }
                        },
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          for (var i = 0;
                          i < widget.snapshot!.data!.data!.cart![index].stockInfo!.length;
                          i++)
                            if (widget.snapshot!.data!.data!.cart![index].stockInfo![i]
                                .selected ==
                                1)
                              ListTile(
                                title: Text(
                                  widget.snapshot!.data!.data!.cart![index].stockInfo![i]
                                      .shipmentType ==
                                      null
                                      ? widget.snapshot!.data!.data!.cart![index]
                                      .stockInfo![i]
                                      .fInvWarehouseNo ==
                                      1
                                      ? 'Uk Estimated Time of Arrival 90+ days (${widget.snapshot!.data!.data!.cart![index].stockInfo![i].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.cart![index].stockInfo![i].total} available'})'
                                      : 'Ready Stock (${widget.snapshot!.data!.data!.cart![index].stockInfo![i].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.cart![index].stockInfo![i].total} available'})'
                                      : widget.snapshot!.data!.data!.cart![index]
                                      .stockInfo![i]
                                      .fInvWarehouseNo ==
                                      2
                                      ? 'Ready Stock ( ${widget.snapshot!.data!.data!.cart![index].stockInfo![i].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.cart![index].stockInfo![i].total} available'} )'
                                      : widget.snapshot!.data!.data!.cart![index]
                                      .stockInfo![i]
                                      .shipmentStatus ==
                                      10
                                      ? 'Uk Estimated Time of Arrival 90+ days (${widget.snapshot!.data!.data!.cart![index].stockInfo![i].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.cart![index].stockInfo![i].total} available'})'
                                      : 'In Transit Estimated Time of Arrival ${getDays(widget.snapshot!.data!.data!.cart![index].stockInfo![i].schArrivalDate!)} days (${widget.snapshot!.data!.data!.cart![index].stockInfo![i].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.cart![index].stockInfo![i].total} available'})',
                                  style: const TextStyle(
                                      color:
                                      // stockInfoRG2[index] ==
                                      //     int.parse(widget.snapshot.data.data.bundle[i][index]
                                      //         .stockInfo[i]
                                      //         .groupValue)
                                      // // ? Color(0xFFF68721)
                                      //     ? Color(0xFF000000)
                                      //     :
                                      Colors.black87),
                                ),
                                leading: widget.snapshot!.data!.data!.cart![index]
                                    .stockInfo![i].shipmentType ==
                                    null
                                    ? widget.snapshot!.data!.data!.cart![index]
                                    .stockInfo![i].fInvWarehouseNo ==
                                    1
                                    ? const Image(
                                  image: AssetImage(
                                    'images/british_icon.gif',
                                  ),
                                  width: 24,
                                  height: 16,
                                )
                                    : const Image(
                                  image: AssetImage(
                                    'images/malaysia_icon.gif',
                                  ),
                                  width: 24,
                                  height: 16,
                                )
                                    : widget.snapshot!.data!.data!.cart![index]
                                    .stockInfo![i].fInvWarehouseNo ==
                                    2
                                    ? const Image(
                                  image: AssetImage(
                                    'images/malaysia_icon.gif',
                                  ),
                                  width: 24,
                                  height: 16,
                                )
                                    : widget.snapshot!.data!.data!.cart![index]
                                    .stockInfo![i]
                                    .shipmentStatus ==
                                    10
                                    ? Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment:
                                  MainAxisAlignment.center,
                                  children: const [
                                    Image(
                                      image: AssetImage(
                                        'images/british_icon.gif',
                                      ),
                                      width: 24,
                                      height: 16,
                                    ),
                                    Image(
                                      image: AssetImage(
                                        'images/box.png',
                                      ),
                                      width: 24,
                                      height: 16,
                                    )
                                  ],
                                )
                                    : widget.snapshot!.data!.data!.cart![index]
                                    .stockInfo![i]
                                    .shipmentType ==
                                    "AIR"
                                    ? const Icon(
                                  (Icons.airplanemode_active),
                                  size: 20,
                                  color: Colors.black87,
                                )
                                    : const Image(
                                  image: AssetImage(
                                    'images/ship_icon.png',
                                  ),
                                  width: 24,
                                  height: 16,
                                ),
                                trailing: TextButton(
                                    onPressed: () async {

                                      int? radioGp;
                                      for(var mm = 0; mm < widget.snapshot!.data!.data!.cart![index].stockInfo!.length; mm++) {
                                        if (widget.snapshot!.data!.data!.cart![index].stockInfo![mm].selected == 1) {
                                          radioGp = int.parse(widget.snapshot!.data!.data!.cart![index].stockInfo![mm].groupValue!);
                                        }
                                      }

                                      try {
                                        final result =
                                        await InternetAddress.lookup(
                                            'example.com');
                                        if (result.isNotEmpty &&
                                            result[0].rawAddress.isNotEmpty) {
                                          showDialog(
                                              barrierColor: Colors.deepOrange.withOpacity(0.2),
                                              context: context,
                                              builder: (context) {
                                                return AlertDialog(
                                                  contentPadding:
                                                  const EdgeInsets.only(
                                                      top: 0, bottom: 10,left: 8),
                                                  content: Column(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .center,
                                                    mainAxisSize:
                                                    MainAxisSize.min,
                                                    children: [
                                                      const SizedBox(
                                                        height: 8,
                                                        width: double.infinity,
                                                      ),
                                                      // Container(
                                                      //     height: 4,
                                                      //     width: 100,
                                                      //     decoration: BoxDecoration(
                                                      //       color: Color(0xFFF4F4F4),
                                                      //       // borderRadius: BorderRadius.circular(16.0)
                                                      //     ),
                                                      //   ),

                                                      SizedBox(
                                                        height: 45,
                                                        child: Stack(
                                                          children: [
                                                            // Align(
                                                            //   alignment: Alignment.topLeft,
                                                            //   child: Image(
                                                            //     image: AssetImage('images/azura_logo_small.png'),
                                                            //     height: 24,
                                                            //     // width:
                                                            //     // MediaQuery.of(context).orientation == Orientation.portrait
                                                            //     //     ? MediaQuery.of(context).size.width * 0.6
                                                            //     //     : MediaQuery.of(context).size.height * 0.6,
                                                            //   ),
                                                            // ),
                                                            Align(
                                                              alignment: Alignment.topRight,
                                                              child: IconButton(
                                                                onPressed: () {
                                                                  Navigator.pop(context);
                                                                },
                                                                icon: const Icon(
                                                                  Icons.close,
                                                                  size: 20,
                                                                ),
                                                              ),
                                                            ),
                                                            const Align(
                                                              alignment: Alignment.center,
                                                              child: Text(
                                                                'Change Location',
                                                                style: TextStyle(
                                                                    color: Colors.blue,
                                                                    fontSize: 18,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w600),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                        height: 8,
                                                      ),
                                                      for (var x = 0; x < widget.snapshot!.data!.data!.cart![index].stockInfo!.length; x++)
                                                        GestureDetector(
                                                          onTap: () {
                                                            ///.................................................
                                                            cartLocationChange(widget.snapshot!.data!.data!.cart![index].stockInfo![x].fPrdVariantNo, widget.snapshot!.data!.data!.cart![index].stockInfo![x].fInvWarehouseNo, widget.snapshot!.data!.data!.cart![index].stockInfo![x].fShippmentNo);
                                                            Common.toastMsg('Changing location...');
                                                            Navigator.pop(context);
                                                          },
                                                          child: ListTile(
                                                            contentPadding: const EdgeInsets.only(left: 0,right: 8),
                                                            title: Text(
                                                              widget.snapshot!.data!.data!.cart![index].stockInfo![x].shipmentType ==
                                                                  null
                                                                  ? widget.snapshot!.data!.data!.cart![index].stockInfo![x].fInvWarehouseNo ==
                                                                  1
                                                                  ? 'Uk Estimated Time of Arrival 90+ days (${widget.snapshot!.data!.data!.cart![index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.cart![index].stockInfo![x].total} available'})'
                                                                  : 'Ready Stock (${widget.snapshot!.data!.data!.cart![index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.cart![index].stockInfo![x].total} available'})'
                                                                  : widget.snapshot!.data!.data!.cart![index]
                                                                  .stockInfo![x]
                                                                  .fInvWarehouseNo ==
                                                                  2
                                                                  ? 'Ready Stock ( ${widget.snapshot!.data!.data!.cart![index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.cart![index].stockInfo![x].total} available'} )'
                                                                  : widget.snapshot!.data!.data!.cart![index].stockInfo![x].shipmentStatus == 10
                                                                  ? 'Uk Estimated Time of Arrival 90+ days (${widget.snapshot!.data!.data!.cart![index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.cart![index].stockInfo![x].total} available'})'
                                                                  : 'In Transit Estimated Time of Arrival ${getDays(widget.snapshot!.data!.data!.cart![index].stockInfo![x].schArrivalDate!)} days (${widget.snapshot!.data!.data!.cart![index].stockInfo![x].total! > 10 ? 'More than 10 available' : 'Only ${widget.snapshot!.data!.data!.cart![index].stockInfo![x].total} available'})',
                                                              style: TextStyle(
                                                                  color: widget.snapshot!.data!.data!.cart![index].stockInfo![x].selected == 1
                                                                      ? AppsColors.buttonColor
                                                                      : Colors
                                                                      .black87),
                                                            ),
                                                            leading: Radio(
                                                              value: int.parse(widget.snapshot!.data!.data!.cart![index].stockInfo![x]
                                                                  .groupValue!),
                                                              groupValue: radioGp,
                                                              activeColor: AppsColors.buttonColor,
                                                              onChanged: widget.snapshot!.data!.data!.cart![index].stockInfo![x].selected == 1
                                                                  ? null
                                                                  : (int?
                                                              value) {
                                                                cartLocationChange(widget.snapshot!.data!.data!.cart![index].stockInfo![x].fPrdVariantNo, widget.snapshot!.data!.data!.cart![index].stockInfo![x].fInvWarehouseNo, widget.snapshot!.data!.data!.cart![index].stockInfo![x].fShippmentNo);
                                                                Common.toastMsg('Changing location...');
                                                                Navigator.pop(
                                                                    context);
                                                              },
                                                            ),
                                                            trailing: widget.snapshot!.data!.data!.cart![index]
                                                                .stockInfo![
                                                            x]
                                                                .shipmentType ==
                                                                null
                                                                ?widget.snapshot!.data!.data!.cart![index].stockInfo![x].fInvWarehouseNo ==
                                                                1
                                                                ? const Image(
                                                              image:
                                                              AssetImage(
                                                                'images/british_icon.gif',
                                                              ),
                                                              width:
                                                              24,
                                                              height:
                                                              16,
                                                            )
                                                                : const Image(
                                                              image:
                                                              AssetImage(
                                                                'images/malaysia_icon.gif',
                                                              ),
                                                              width:
                                                              24,
                                                              height:
                                                              16,
                                                            )
                                                                : widget.snapshot!.data!.data!.cart![index]
                                                                .stockInfo![
                                                            x]
                                                                .fInvWarehouseNo ==
                                                                2
                                                                ? const Image(
                                                              image:
                                                              AssetImage(
                                                                'images/malaysia_icon.gif',
                                                              ),
                                                              width:
                                                              24,
                                                              height:
                                                              16,
                                                            )
                                                                : widget.snapshot!.data!.data!.cart![index].stockInfo![x].shipmentStatus ==
                                                                10
                                                                ? Row(
                                                              mainAxisSize:
                                                              MainAxisSize.min,
                                                              mainAxisAlignment:
                                                              MainAxisAlignment.center,
                                                              children: const [
                                                                Image(
                                                                  image: AssetImage(
                                                                    'images/british_icon.gif',
                                                                  ),
                                                                  width: 24,
                                                                  height: 16,
                                                                ),
                                                                Image(
                                                                  image: AssetImage(
                                                                    'images/box.png',
                                                                  ),
                                                                  width: 24,
                                                                  height: 16,
                                                                )
                                                              ],
                                                            )
                                                                : widget.snapshot!.data!.data!.cart![index].stockInfo![x].shipmentType ==
                                                                "AIR"
                                                                ? const Icon(
                                                              (Icons.airplanemode_active),
                                                              size: 20,
                                                              color: Colors.black87,
                                                            )
                                                                : const Image(
                                                              image: AssetImage(
                                                                'images/ship_icon.png',
                                                              ),
                                                              width: 24,
                                                              height: 16,
                                                            ),
                                                            minLeadingWidth: 24,
                                                            horizontalTitleGap:
                                                            0,
                                                            hoverColor: AppsColors.buttonColor
                                                                .withOpacity(
                                                                0.5),
                                                            focusColor: AppsColors.buttonColor
                                                                .withOpacity(
                                                                0.5),
                                                          ),
                                                        ),
                                                    ],
                                                  ),
                                                );
                                              });
                                        }
                                      } on SocketException catch (_) {
                                        Common.toastMsg(
                                            'No internet Connection');
                                      }
                                    },
                                    child: GestureDetector(
                                      child: FaIcon(
                                        FontAwesomeIcons.exchangeAlt,
                                        color: AppsColors.buttonColor,
                                        size: 20,
                                      ),
                                    )),
                                minLeadingWidth: 24,
                                // horizontalTitleGap: 0,
                                hoverColor: AppsColors.buttonColor.withOpacity(0.5),
                                focusColor: AppsColors.buttonColor.withOpacity(0.5),
                              ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            childCount: widget.snapshot!.data!.data!.cart!.length,
          ),
        ),
        SliverToBoxAdapter(
          child: Container(
            width: double.infinity,
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                color: Colors.white,
                border: Border.all(color: const Color(0xFFFFFFFF), width: 2)),
            child: Column(
              children: [
                const SizedBox(
                  width: double.infinity,
                  child: Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text(
                      'Payment Detail',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87),
                    ),
                  ),
                ),
                const SizedBox(
                  width: double.infinity,
                  child: Divider(
                    color: Color(0xFFF4F4F4),
                    thickness: 2,
                  ),
                ),
                SizedBox(
                  width: double.infinity,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: RichText(
                      text: TextSpan(
                          text:
                              'Total Items(${widget.snapshot!.data!.data!.cartQtyCount}) - ',
                          style: const TextStyle(color: Colors.black87, fontSize: 13),
                          children: <TextSpan>[
                            TextSpan(
                              text: 'RM${widget.snapshot!.data!.data!.totalPrice}',
                              style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600),
                            )
                          ]),
                    ),
                  ),
                ),
                SizedBox(
                  width: double.infinity,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: RichText(
                      text: const TextSpan(
                          text: 'Shipping Charges - ',
                          style: TextStyle(color: Colors.black87, fontSize: 13),
                          children: <TextSpan>[
                            TextSpan(
                              text:
                                  'Free shipping to peninsular(SM), for Sabah & Sarawak will calculated at next step',
                              style: TextStyle(
                                  color: Colors.black54, fontSize: 13),
                            )
                          ]),
                    ),
                  ),
                ),
                const SizedBox(
                  width: double.infinity,
                  child: Divider(
                    color: Color(0xFFF4F4F4),
                    thickness: 2,
                  ),
                ),
                SizedBox(
                  width: double.infinity,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: RichText(
                      text: TextSpan(
                          text: 'Total Amount - ',
                          style: const TextStyle(color: Colors.black87, fontSize: 12),
                          children: <TextSpan>[
                            TextSpan(
                              text: 'RM${widget.snapshot!.data!.data!.totalPrice}',
                              style: TextStyle(
                                  color: AppsColors.buttonColor, fontSize: 14),
                            )
                          ]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        )
      ],
    );
  }
}

