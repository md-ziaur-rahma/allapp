import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/cart/cart_body.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/floating_action_button.dart';
import 'package:azuramartmy/email_number_validation/email_number_validation_page.dart';
import 'package:azuramartmy/my_bloc/cart_bloc.dart';
import 'package:azuramartmy/order_summery_info/order_summery_info_page.dart';
import 'package:azuramartmy/provider_models/cart_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CartPage extends StatelessWidget {
  CartPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => CartPage());
  }

  static CartModel cartModel = CartModel();
  static int isCartData = 0;

  Future<void> reload() async {
    try {
      final result = await InternetAddress.lookup('example.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        return cartBloc.fetchAllCarts();
      }
    } on SocketException catch (_) {
      Common.toastMsg('No Internet Connection');
      return;
    }
  }
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
  GlobalKey<RefreshIndicatorState>();

  void _portraitModeOnly() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          key: _refreshIndicatorKey,
          color: AppsColors.buttonColor,
          onRefresh: reload,
          child: const CartBody(),
        ),
      ),
      bottomNavigationBar: const CartBottomNavBar(),
      floatingActionButton: MyFloatingActionButton(snapshot: SharedPreferenceUtils.whatsappModel,),
    );
  }
}

class CartBottomNavBar extends StatefulWidget {
  const CartBottomNavBar({Key? key}) : super(key: key);

  @override
  _CartBottomNavBarState createState() => _CartBottomNavBarState();
}

class _CartBottomNavBarState extends State<CartBottomNavBar> {
  Future<void> updateCart(BuildContext context) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Client client = Client();
    Map<String, dynamic> data = {
      'session': session,
      'user_id': '$userId',
      'token': '$token',
      'response': CartPage.cartModel,
    };
    var requestBody = json.encode(data);
    print(requestBody);
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.UPDATE_CART);
      print('url');
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      print('${body['message']}');
      Common.toastMsg('${body['message']}');
      if (body['status'] == 1) {
        //todo change........
        if (SharedPreferenceUtils.emailF == '' || SharedPreferenceUtils.emailF == null) {
          Navigator.push(context, EmailNumberValidationPage.route());
        }  else {
          Navigator.push(context, OrderSummeryInfoPage.route());
        }


      }
    } on FormatException catch (e) {
      print(e);
      Common.toastMsg(e.toString());
    } on Exception catch (e) {
      print(e);
      Common.toastMsg(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      width: double.infinity,
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
            topRight: Radius.circular(16.0),
            topLeft: Radius.circular(16.0))
      ),
      child: Row(
        children: [
          Expanded(
              flex: 1,
              child: SizedBox(
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: AppsColors.buttonColor,
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(0),
                              topLeft: Radius.circular(0)))),
                  onPressed: () async {
                    if(CartPage.isCartData != 0){
                      try {
                        final result = await InternetAddress.lookup('example.com');
                        if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                          if (SharedPreferenceUtils.emailF == '' || SharedPreferenceUtils.emailF == null) {
                            Navigator.push(context, EmailNumberValidationPage.route());
                          }  else {
                            Navigator.push(context, OrderSummeryInfoPage.route());
                          }
                        }
                      } on SocketException catch (_) {
                        Common.toastMsg('No Internet Connection');
                      }
                    }else {
                      Common.toastMsg("Your Cart is Empty!");
                    }
                  },
                  child: const Text(
                    'Proceed To Checkout',
                    style: TextStyle(color: Colors.white, fontSize: 14),
                  ),
                ),
              )),
        ],
      ),
    );
  }
}
