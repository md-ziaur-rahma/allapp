import 'package:azuramartmy/brand/brand_body.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/home/home_page.dart';
import 'package:azuramartmy/my_bloc/all_brand_bloc.dart';
import 'package:azuramartmy/provider_models/brand_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/material.dart';

class BrandPage extends StatefulWidget {
  const BrandPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const BrandPage());
  }

  @override
  _BrandPageState createState() => _BrandPageState();
}

class _BrandPageState extends State<BrandPage> {
  BrandModel brandModel = BrandModel();

  @override
  void initState() {
    brandModel.data = [];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    allBrandBloc.fetchAllBrands();
    return Scaffold(
      body: SafeArea(
        child: StreamBuilder(
            stream: allBrandBloc.allBrands,
            builder: (context, AsyncSnapshot<BrandModel> snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!.data!.isNotEmpty) {
                  print('..........${snapshot.data!.data!.length}.............');
                  for (var element in snapshot.data!.data!) {
                    brandModel.data!.add(element);
                  }
                  return BrandBody(
                    brandModel: brandModel,
                  );
                } else {
                  return const Center(
                    child: Text(
                      'Brand Not Found',
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                    ),
                  );
                }
              } else if (snapshot.hasError) {
                return Center(
                  child: Text(snapshot.error.toString()),
                );
              }
              return LoadingWidget(color: AppsColors.buttonColor,);
            }),
      ),
      bottomNavigationBar: HomeBottomNavBar(isHome: 0,),
    );
  }
}
