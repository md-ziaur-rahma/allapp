import 'dart:io';

import 'package:azuramartmy/brand_details/brand_details_chngenotifier.dart';
import 'package:azuramartmy/brand_details/brand_details_page.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/my_bloc/brand_product_bloc.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/brand_model.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:azuramartmy/wishlist/add_to_wish.dart';
import 'package:flutter/material.dart';
import 'package:azuramartmy/provider_models/brand_product_model.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

class BrandBody extends StatefulWidget {
  const BrandBody({Key? key, this.brandModel}) : super(key: key);
  final BrandModel? brandModel;

  @override
  _BrandBodyState createState() => _BrandBodyState();
}

class _BrandBodyState extends State<BrandBody> {
  TextEditingController textEditingController = TextEditingController();

  BrandModel brandModel = BrandModel();
  BrandModel brandModelSearch = BrandModel();

  void search() {
    brandModelSearch.data = [];
    for (var element in widget.brandModel!.data!) {
      if (element.name!
          .toLowerCase()
          .contains(textEditingController.text.toLowerCase())) {
        brandModelSearch.data!.add(element);
      }
    }
  }

  @override
  void initState() {
    // brandModel.data = [];
    brandModelSearch.data = [];
    for (var element in widget.brandModel!.data!) {
      if (element.name!
          .toLowerCase()
          .contains(textEditingController.text.toLowerCase())) {
        brandModelSearch.data!.add(element);
      }
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // allBrandBloc.fetchAllBrands();
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5),
      child: CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          SliverAppBar(
            leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.arrow_back,
                color: Colors.black87,
              ),
            ),
            backgroundColor: Colors.white,
            systemOverlayStyle: const SystemUiOverlayStyle(statusBarColor: Colors.white,statusBarIconBrightness: Brightness.dark),
            titleSpacing: 0,
            title: TextFormField(
              style: const TextStyle(fontSize: 16),
              controller: textEditingController,
              textInputAction: TextInputAction.search,
              onFieldSubmitted: (value) {
                setState(() {
                  search();
                });
              },
              keyboardType: TextInputType.text,
              maxLines: 1,
              cursorColor: Colors.black87,
              decoration: const InputDecoration(
                  fillColor: Color(0xFFFFFFFF),
                  filled: true,
                  contentPadding: EdgeInsets.symmetric(horizontal: 20),
                  hintText: 'Search brand',
                  hintStyle: TextStyle(fontSize: 16),
                  border: InputBorder.none),
            ),
            actions: [
              IconButton(
                  onPressed: () {
                    setState(() {
                      search();
                    });
                  },
                  icon: const Icon(
                    Icons.search,
                    color: Colors.black87,
                  ))
            ],
          ),
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 12,
            ),
          ),
          SliverGrid(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount:
                  MediaQuery.of(context).orientation == Orientation.portrait
                      ? 3
                      : 5,
              mainAxisSpacing: 12,
              childAspectRatio:
                  MediaQuery.of(context).orientation == Orientation.portrait
                      ? screenWidth / 120.0
                      : screenHeight / 100.0,
              crossAxisSpacing: 12,
            ),
            delegate:
                SliverChildBuilderDelegate((BuildContext context, int index) {
              return Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 0),
                child: CategoryBrandCard(
                  snapshot: brandModelSearch,
                  index: index,
                ),
              );
            }, childCount: brandModelSearch.data!.length),
          ),
        ],
      ),
    );
  }
}

class CategoryBrandCard extends StatefulWidget {
  const CategoryBrandCard({Key? key, this.snapshot, this.index})
      : super(key: key);
  final BrandModel? snapshot;
  final int? index;

  @override
  _CategoryBrandCardState createState() => _CategoryBrandCardState();
}

class _CategoryBrandCardState extends State<CategoryBrandCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            context.read<BrandDetailsNotifier>().changeCategoryName('All Product');
            brandProductBloc.page = 1;
            context.read<BrandDetailsNotifier>().changeBtnClear(1);
            BrandDetailsPage.brandPk = widget.snapshot!.data![widget.index!].pkno;
            Navigator.push(context, BrandDetailsPage.route());
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: Container(
        height: MediaQuery.of(context).size.width * 0.3,
        width: MediaQuery.of(context).size.width * 0.3,
        // margin: const EdgeInsets.only(left: 12),
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(10.0)),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
              flex: 2,
              child: Center(
                child: ClipRRect(
                  borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10)),
                  child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 2),
                      child: ConstrainedBox(
                        constraints: BoxConstraints(
                            minHeight: MediaQuery.of(context).size.width * 0.15,
                            maxHeight:
                                MediaQuery.of(context).size.width * 0.19),
                        child: widget.snapshot!.data![widget.index!].brandlogo ==
                                null
                            ? const NoImageWidget(text: 'No Image',)
                            : CacheImageProvide(url: widget.snapshot!.data![widget.index!].brandlogo,)
                      )),
                ),
              ),
            ),
            Expanded(
              flex: 1,
              child: Center(
                child: SizedBox(
                  child: Text(
                    '${widget.snapshot!.data![widget.index!].name}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.black87, fontSize: 12),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ................ rejected ...........................
class BrandItemCard extends StatefulWidget {
  final AsyncSnapshot<BrandProductModel> snapshot;
  final int index;
  const BrandItemCard(this.snapshot, this.index);
  @override
  _BrandItemCardState createState() => _BrandItemCardState();
}

class _BrandItemCardState extends State<BrandItemCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        ProductDetailsPage.productUrl =
            widget.snapshot.data!.data![widget.index].url;
        ProductDetailsPage.variantPk =
            widget.snapshot.data!.data![widget.index].pkno;
        ProductDetailsPage.isWish =
            widget.snapshot.data!.data![widget.index].isWish;
        Navigator.of(context).push(
                CustomRoutePageBuilder
                    .createPageRouteLeft(
                    context, ProductDetailsPage()));
      },
      child: SizedBox(
        //height: MediaQuery.of(context).size.width * 0.6,
        width: MediaQuery.of(context).size.width * 0.4,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              child: Container(
                //height: MediaQuery.of(context).size.width * 0.4,
                width: MediaQuery.of(context).size.width * 0.4,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: const Color(0xFFFFFFFF).withOpacity(0.2),
                ),
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                          padding:
                          const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(
                                minHeight: 60, maxHeight: 120),
                            child: Image(
                              image: NetworkImage(Urls.basePictureUrl +
                                  widget.snapshot.data!.data![widget.index]
                                      .primaryimgrelativepath!),
                            ),
                          )),
                    ),
                    Align(
                      alignment: Alignment.topRight,
                      child: Ink(
                        decoration: const ShapeDecoration(
                          color: Color(0xFFF4F4F4),
                          shape: CircleBorder(),
                        ),
                        child: IconButton(
                          onPressed: () {
                            setState(() {
                              widget.snapshot.data!.data![widget.index].isWish =
                                  widget.snapshot.data!.data![widget.index]
                                              .isWish ==
                                          0
                                      ? 1
                                      : 0;
                              AddToWish addWish = AddToWish();
                              addWish.addToWish(
                                  widget.snapshot.data!.data![widget.index].pkno);
                            });
                          },
                          icon:
                              widget.snapshot.data!.data![widget.index].isWish ==
                                      0
                                  ? const Icon(
                                      Icons.favorite_outline,
                                      size: 16,
                                      color: Colors.black87,
                                    )
                                  : const Icon(
                                      Icons.favorite,
                                      size: 16,
                                      color: Color(0xFFF68721),
                                    ),
                        ),
                      ),
                    ),
                    LayoutBuilder(
                      builder:
                          (BuildContext context, BoxConstraints constraints) {
                        if (widget.snapshot.data!.data![widget.index].offer !=
                            0) {
                          return GestureDetector(
                            onTap: () {
                              // setState(() {
                              //   toggleMsg = toggleMsg == 1 ? 0 : 1;
                              // });
                            },
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                height: 45,
                                width: 45,
                                padding: const EdgeInsets.all(3.0),
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.red,
                                ),
                                child: const Center(
                                  child: Text(
                                    'In \nOffer',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 12),
                                  ),
                                ),
                              ),
                            ),
                          );
                        } else {
                          return const Align(
                            alignment: Alignment.topLeft,
                            child: SizedBox(
                              height: 2,
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                child: Text(
                  '${widget.snapshot.data!.data![widget.index].variantname}',
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87),
                ),
              ),
            ),
            SizedBox(
              // width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.only(left: 10, right: 10, bottom: 6),
                child: RichText(
                  text: TextSpan(
                    text:
                        'RM${widget.snapshot.data!.data![widget.index].regularprice!.toStringAsFixed(2)}',
                    style: const TextStyle(
                        color: Color(0xFFF68721),
                        fontSize: 12,
                        fontWeight: FontWeight.w600),
                    // children: <TextSpan>[
                    //   TextSpan(
                    //     text: '   RM${widget.snapshot.data.data[widget.index].insPrice}',
                    //     style: TextStyle(
                    //         color: Colors.black38,
                    //         fontSize: 10,
                    //         fontWeight: FontWeight.normal),
                    //   )
                    // ]
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
