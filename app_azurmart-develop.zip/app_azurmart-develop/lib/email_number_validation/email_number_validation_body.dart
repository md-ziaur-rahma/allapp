import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/login/login_page.dart';
import 'package:azuramartmy/order_summery_info/order_summery_info_page.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EmailNumberValidationBody extends StatefulWidget {
  const EmailNumberValidationBody({Key? key}) : super(key: key);

  @override
  _EmailNumberValidationBodyState createState() =>
      _EmailNumberValidationBodyState();
}

class _EmailNumberValidationBodyState extends State<EmailNumberValidationBody> {
  TextEditingController emailController = TextEditingController();
  String? email;
  final _emailRegex = RegExp(
    r'^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$',
  );
  final GlobalKey<FormState> emailFormKey = GlobalKey<FormState>();
  String? validationEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Enter an email address!';
    } else if (!_emailRegex.hasMatch(value)) {
      return 'Enter a valid email!';
    } else {
      return null;
    }
  }

  bool canLoading = false;

  Future<void> checkEmail() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    Client client = Client();
    final url = Uri.parse(Urls.baseUrl + Urls.CHECK_EMAIL);
    print('url $url');
    try {
      final response = await client.post(url, body: {
        'email': '${emailController.text}',
        'mobile': ''
      });
      print(response.body);
      var body = await json.decode(response.body);
      canLoading = false;
      if (body['status'] == 1) {
        localStorage.setString(
            SharedPreferenceUtils.EMAIL, emailController.text);
        SharedPreferenceUtils.emailF = emailController.text;
        Navigator.push(context, OrderSummeryInfoPage.route());
      } else {
        Common.toastMsg('${body['message']}');
      }
      print('parsed');
    } on SocketException catch (e) {
      print(e);
    } on FormatException catch (e) {
      print(e);
    } on Exception catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    canLoading = false;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 8,
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              width: double.infinity,
              child: Text(
                'New Customer',
                style: TextStyle(
                    color: AppsColors.buttonColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w600),
              ),
            ),
          ),
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 8,
            ),
          ),
          const SliverToBoxAdapter(
            child: SizedBox(
              width: double.infinity,
              child: Text(
                'Automatically Creates An Account',
                style: TextStyle(
                    color: Colors.black54,
                    fontSize: 14,
                    fontWeight: FontWeight.normal),
              ),
            ),
          ),
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 24,
            ),
          ),
          SliverToBoxAdapter(
              child: Form(
                  key: emailFormKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: double.infinity,
                        child: TextFormField(
                          validator: validationEmail,
                          keyboardType: TextInputType.emailAddress,
                          maxLines: 1,
                          controller: emailController,
                          onSaved: (String? val) {
                            email = val;
                          },
                          decoration: InputDecoration(
                            contentPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                            hintText: 'Email',
                            labelText: 'Email',
                            labelStyle: TextStyle(color: AppsColors.buttonColor),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: const BorderSide(color: Colors.black)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide:
                                    const BorderSide(color: Color(0xFFD0D1D2))),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          onPressed: () async {
                            if (emailFormKey.currentState!.validate()) {
                              emailFormKey.currentState!.save();
                              try {
                                final result = await InternetAddress.lookup('example.com');
                                if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                                  canLoading = true;
                                  checkEmail();
                                }
                              } on SocketException catch (_) {
                                Common.toastMsg('No Internet Connection');
                              }
                            }
                          },
                          style: ElevatedButton.styleFrom(
                              primary: AppsColors.buttonColor,
                              shape: const StadiumBorder()),
                          child: canLoading
                              ? const SizedBox(
                                  height: 16,
                                  width: 16,
                                  child: CircularProgressIndicator(
                                    color: Colors.white,
                                    strokeWidth: 2.0,
                                  ),
                                )
                              : const Text(
                                  'Continue as a new customer',
                                  style: TextStyle(color: Colors.white),
                                ),
                        ),
                      ),
                    ],
                  ))),
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 30,
            ),
          ),
          const SliverToBoxAdapter(
            child: SizedBox(
              width: double.infinity,
              child: Text(
                'or',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.black54,
                    fontSize: 18,
                    fontWeight: FontWeight.normal),
              ),
            ),
          ),
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 20,
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton(
                onPressed: () {
                  Navigator.push(context, LoginPage.route());
                },
                style: OutlinedButton.styleFrom(
                    primary: AppsColors.buttonColor,
                    shape: const StadiumBorder(),
                    side: BorderSide(
                      color: AppsColors.buttonColor,
                      width: 1.0,
                    )),
                child: Text(
                  'Sign in',
                  style: TextStyle(color: AppsColors.buttonColor),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
