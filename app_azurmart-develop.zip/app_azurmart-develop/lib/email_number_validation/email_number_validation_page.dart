import 'dart:io';

import 'package:azuramartmy/email_number_validation/email_number_validation_body.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class EmailNumberValidationPage extends StatefulWidget {
  const EmailNumberValidationPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const EmailNumberValidationPage());
  }

  @override
  _EmailNumberValidationPageState createState() =>
      _EmailNumberValidationPageState();
}

class _EmailNumberValidationPageState extends State<EmailNumberValidationPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Checkout',
          style: TextStyle(color: Colors.black87),
        ),
        centerTitle: true,
        iconTheme: const IconThemeData(
          color: Colors.black87,
        ),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
      ),
      body: const SafeArea(
        child: EmailNumberValidationBody(),
      ),
    );
  }
}
