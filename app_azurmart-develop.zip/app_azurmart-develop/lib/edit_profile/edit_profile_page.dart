import 'dart:io';

import 'package:azuramartmy/edit_profile/edit_profile_bode.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class EditProfilePage extends StatelessWidget {
  const EditProfilePage({Key? key}) : super(key: key);
  static Route route(){
    return MaterialPageRoute(builder: (_) => const EditProfilePage());
  }

  @override
  Widget build(BuildContext context) {
    print(SharedPreferenceUtils.profilePicF);
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Edit Profile',
          style: TextStyle(
            color: Colors.black87,
          ),
        ),
        elevation: 0,
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
      ),
      body: const SafeArea(
        child: EditProfileBody(),
      ),
    );
  }
}
