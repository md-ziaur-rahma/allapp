import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EditProfileBody extends StatefulWidget {
  const EditProfileBody({Key? key}) : super(key: key);

  @override
  _EditProfileBodyState createState() => _EditProfileBodyState();
}

class _EditProfileBodyState extends State<EditProfileBody> {
  XFile? _image;
  PickedFile? img;

  _imageFromGallery() async {
    PickedFile? image = await (ImagePicker.platform.pickImage(source: ImageSource.gallery,imageQuality: 100));
    // print(image.openRead());
    addImage(File(image!.path));
    setState(() {
      img = image;
    });
  }

  _imageFromCamera() async {
    PickedFile? image = await (ImagePicker.platform.pickImage(source: ImageSource.camera,imageQuality: 100));
    // print(image.path);
    addImage(File(image!.path));
    setState(() {
      img = image;
    });
  }

  Future<bool> addImage(File? file) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userID = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Map<String, String> data = {
      'session': "$session",
      'user_id': '$userID',
      'token': '$token'
    };
    String filePath = file!.path;
    print('.............$filePath.............');
    String addImageUrl = Urls.baseUrl + Urls.uploadImage;
    Map<String, String> headers = {
      'Content-Type': 'multipart/form-data',
    };
    print(addImageUrl);
    var request = http.MultipartRequest('POST', Uri.parse(addImageUrl))
      ..headers.addAll(headers)
      ..fields.addAll(data)
      ..files.add(await http.MultipartFile.fromPath('image', filePath));
    var response = await request.send();
    response.stream.transform(utf8.decoder).listen((value) async {
      print('///////////////$value //////////////');
      final Map<String, dynamic>? body = await json.decode(value);
      setState(() {
        profilePic = body!["data"];
        SharedPreferenceUtils.profilePicF = body["data"];
        localStorage.setString(SharedPreferenceUtils.profilePic, body["data"]);
      });
    });
    if (response.statusCode == 201) {
      return true;
    } else {
      return false;
    }
  }

  String? firstName;
  String? lastName;
  String? mobile;
  String? profilePic;
  String? email;

  void getProfileData() async {
    // SharedPreferences localStorage = await SharedPreferences.getInstance();
    // firstName = localStorage.getString(SharedPreferenceUtils.USER_NAME);
    // lastName = localStorage.getString(SharedPreferenceUtils.LAST_NAME);
    // mobile = localStorage.getString(SharedPreferenceUtils.MOBILE);
    // email = localStorage.getString(SharedPreferenceUtils.EMAIL);
    // profilePic = localStorage.getString(SharedPreferenceUtils.profilePic);

    firstName = SharedPreferenceUtils.usernameF;
    lastName = SharedPreferenceUtils.lastNameF;
    mobile = SharedPreferenceUtils.mobileF;
    email = SharedPreferenceUtils.emailF;
    profilePic = SharedPreferenceUtils.profilePicF;
  }

  @override
  void initState() {
    getProfileData();
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 0),
      child: CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.only(bottom: 16),
                color: Colors.white,
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: const Color(0xFFF4F4F4),
                      backgroundImage: (img != null ? FileImage(File(img!.path)) : profilePic!.isNotEmpty ? NetworkImage(profilePic!) : const NetworkImage("https://img.freepik.com/free-icon/important-person_318-10744.jpg?size=338&ext=jpg")) as ImageProvider<Object>?,
                      child: Align(
                        alignment: Alignment.bottomRight,
                        child: GestureDetector(
                          onTap: (){
                            showModalBottomSheet(
                              shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(16),topRight: Radius.circular(16))),
                              isScrollControlled: true,
                              context: context,
                              builder: (context){
                                return Container(
                                  width: double.infinity,
                                  height: 120,
                                  padding: const EdgeInsets.symmetric(vertical: 16),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(16.0),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Expanded(
                                        child: Center(
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Material(
                                                color: Colors.transparent,
                                                child: Ink(
                                                  decoration: ShapeDecoration(
                                                    color: AppsColors.buttonColor,
                                                    shape: const CircleBorder(),
                                                  ),
                                                  child: IconButton(
                                                    onPressed: () {
                                                      _imageFromGallery();
                                                    },
                                                    icon: const Icon(
                                                      Icons.image_rounded,
                                                      size: 30,
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(height: 8,),
                                              const Text('Gallery')
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Center(
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Material(
                                                color: Colors.transparent,
                                                child: Ink(
                                                  decoration: ShapeDecoration(
                                                    color: AppsColors.buttonColor,
                                                    shape: const CircleBorder(),
                                                  ),
                                                  child: IconButton(
                                                    onPressed: () {
                                                      _imageFromCamera();
                                                    },
                                                    icon: const Icon(
                                                      Icons.camera,
                                                      size: 30,
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(height: 8,),
                                              const Text('Camera')
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              }
                            );
                            // _imageFromGallery();
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(30.0),
                              boxShadow: const [
                                BoxShadow(
                                  color: Colors.grey,
                                  offset: Offset(1.0, 0.0), //(x,y)
                                  blurRadius: 3.0,
                                ),
                              ],
                            ),
                            padding: const EdgeInsets.all(8),
                            child: const Icon(Icons.edit_outlined,size: 16,color: Colors.black54,),
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(
                      height: 10,
                    ),
                    Text('${SharedPreferenceUtils.usernameF} ${SharedPreferenceUtils.lastNameF}',
                      style: const TextStyle(
                          color: Colors.black,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                    )
                  ],
                ),
              )),
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 8,
            ),
          ),
          SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.only(
                  left: 16,
                ),
                color: Colors.white,
                child: Column(
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Personal Information',
                          style: TextStyle(
                              color: Colors.black87,
                              fontSize: 16,
                              fontWeight: FontWeight.w600),
                        ),
                        TextButton(
                          onPressed: () {
                            showModalBottomSheet(
                              backgroundColor: Colors.white,
                                enableDrag: true,
                                shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(16),
                                        topRight: Radius.circular(16))),
                                isScrollControlled: true,
                                isDismissible: true,
                                context: context,
                                builder: (context){
                                  return DraggableScrollableSheet(
                                      expand: false,
                                      builder: (context, scrollController){
                                        return ChangePersonalInfo(scrollController: scrollController,);
                                      }
                                  );
                                }
                            );
                          },
                          child: Text(
                            'Edit',
                            style:
                            TextStyle(color:AppsColors.buttonColor, fontSize: 14),
                          ),
                        )
                      ],
                    ),
                    ListTile(
                      minLeadingWidth: 30,
                      horizontalTitleGap: 0,
                      leading: const Icon(
                        Icons.person,
                        size: 16,
                        color: Colors.black54,
                      ),
                      title: const Text(
                        'Name',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w600),
                      ),
                      subtitle: Text('${SharedPreferenceUtils.usernameF} ${SharedPreferenceUtils.lastNameF}',
                        style: const TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                    ListTile(
                      minLeadingWidth: 30,
                      horizontalTitleGap: 0,
                      leading: const Icon(
                        Icons.call,
                        size: 16,
                        color: Colors.black54,
                      ),
                      title: const Text(
                        'Contact No',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w600),
                      ),
                      subtitle: Text(
                        '+60 ${SharedPreferenceUtils.mobileF}',
                        style: const TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                    // ListTile(
                    //   minVerticalPadding: 0,
                    //   minLeadingWidth: 30,
                    //   horizontalTitleGap: 0,
                    //   leading: Icon(Icons.transgender,size: 16,color: Colors.black54,),
                    //   title: const Text('Gender',style: TextStyle(color: Colors.black,fontSize: 16,fontWeight: FontWeight.w600),),
                    //   subtitle: Text('Male',style: TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w500),),
                    // ),
                    // ListTile(
                    //   minVerticalPadding: 0,
                    //   minLeadingWidth: 30,
                    //   horizontalTitleGap: 0,
                    //   leading: Icon(Icons.library_books,size: 16,color: Colors.black54,),
                    //   title: const Text('Date of Birth'),
                    //   subtitle: Text('23/12/2000'),
                    // ),
                  ],
                ),
              )),
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 8,
            ),
          ),
          SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.only(
                  left: 16,
                ),
                color: Colors.white,
                child: Column(
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Email Address',
                          style: TextStyle(
                              color: Colors.black87,
                              fontSize: 16,
                              fontWeight: FontWeight.w600),
                        ),
                        TextButton(
                          onPressed: () {
                            showModalBottomSheet(
                              backgroundColor: Colors.white,
                                enableDrag: true,
                                shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(16),
                                        topRight: Radius.circular(16))),
                                isScrollControlled: true,
                                isDismissible: true,
                                context: context,
                                builder: (context){
                                  return DraggableScrollableSheet(
                                      expand: false,
                                      builder: (context, scrollController){
                                        return ChangeEmail(scrollController: scrollController,);
                                      }
                                  );
                                }
                            );
                          },
                          child: Text(
                            'Edit',
                            style:
                            TextStyle(color: AppsColors.buttonColor, fontSize: 14),
                          ),
                        )
                      ],
                    ),
                    ListTile(
                      minLeadingWidth: 30,
                      horizontalTitleGap: 0,
                      leading: const Icon(
                        Icons.person,
                        size: 16,
                        color: Colors.black54,
                      ),
                      title: const Text(
                        'Email',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w600),
                      ),
                      subtitle: Text(
                        '${SharedPreferenceUtils.emailF}',
                        style: const TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                  ],
                ),
              )),
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 8,
            ),
          ),
          SliverToBoxAdapter(
            child: Container(
              padding: const EdgeInsets.only(left: 16,top: 16),
              color: Colors.white,
              child: Column(
                children: [
                  const SizedBox(
                    width: double.infinity,
                    child: Text(
                      'Change Password',
                      textAlign: TextAlign.start,
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      const Text(
                        '********',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                      ),
                      TextButton(
                        onPressed: () {
                          showModalBottomSheet(
                            backgroundColor: Colors.white,
                              enableDrag: true,
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(16),
                                      topRight: Radius.circular(16))),
                              isScrollControlled: true,
                              isDismissible: true,
                              context: context,
                              builder: (context){
                                return DraggableScrollableSheet(
                                    expand: false,
                                    builder: (context, scrollController){
                                      return ChangePasswordDialog(scrollController: scrollController,);
                                    }
                                );
                              }
                          );
                        },
                        child: Text(
                          'Edit',
                          style:
                          TextStyle(color:AppsColors.buttonColor, fontSize: 14),
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
          ),
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 8,
            ),
          ),
        ],
      ),
    );
  }
}

class ChangePersonalInfo extends StatefulWidget {
  const ChangePersonalInfo({Key? key,this.scrollController}) : super(key: key);
  final ScrollController? scrollController;

  @override
  _ChangePersonalInfoState createState() => _ChangePersonalInfoState();
}

class _ChangePersonalInfoState extends State<ChangePersonalInfo> {
  final GlobalKey<FormState> _personalInfoForKey = GlobalKey<FormState>();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController mobileController = TextEditingController();

  String? firstName;
  String? lastName;
  String? mobile;

  String? validationFirstName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty First Name!';
    } else {
      return null;
    }
  }

  String? validationLastName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Last Name!';
    } else {
      return null;
    }
  }

  String? validationMobile(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Mobile!';
    } else if (value.length < 9) {
      return 'Enter valid contact no';
    } else {
      return null;
    }
  }

  void getInfo() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    firstNameController.text = localStorage.getString(SharedPreferenceUtils.USER_NAME)!;
    lastNameController.text = localStorage.getString(SharedPreferenceUtils.LAST_NAME)!;
    mobileController.text = localStorage.getString(SharedPreferenceUtils.MOBILE)!;
  }

  void changeInfo(BuildContext context) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    Map<String, dynamic> data = {
      'first_name': firstName,
      'last_name': lastName,
      'mobile': mobile,
      'user_id': '$userId',
      'token': '$token',
      'session': '$session',
    };
    var requestBody = json.encode(data);
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.changePersonalInfo);
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      Common.toastMsg('${body["message"]}');
      if (body["status"] == 1) {
        SharedPreferences localStorage = await SharedPreferences.getInstance();
        localStorage.setString(
            SharedPreferenceUtils.USER_NAME, firstName!);
        localStorage.setString(
            SharedPreferenceUtils.LAST_NAME, lastName!);
        localStorage.setString(
            SharedPreferenceUtils.MOBILE, mobile!);

        SharedPreferenceUtils.usernameF = firstName;
        SharedPreferenceUtils.lastNameF = lastName;
        SharedPreferenceUtils.mobileF = mobile;
      }
      Navigator.pop(context);
    } on FormatException catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    getInfo();
    return CustomScrollView(
      shrinkWrap: true,
      scrollDirection: Axis.vertical,
      controller: widget.scrollController,
      slivers: [
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 8,
          ),
        ),
        SliverToBoxAdapter(
          child: Align(
            alignment: Alignment.center,
            child: Container(
              height: 4,
              width: 100,
              decoration: const BoxDecoration(
                color: Color(0xFFF4F4F4),
                // borderRadius: BorderRadius.circular(16.0)
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 45,
            child: Stack(
              children: [
                const Align(
                  alignment: Alignment.center,
                  child: Image(
                    image: AssetImage('images/azura_logo_small.png'),
                    height: 100,
                    width: 100,
                    // width:
                    // MediaQuery.of(context).orientation == Orientation.portrait
                    //     ? MediaQuery.of(context).size.width * 0.6
                    //     : MediaQuery.of(context).size.height * 0.6,
                  ),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.close,
                      size: 20,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 12,
          ),
        ),
        SliverToBoxAdapter(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(6.0),
                    topRight: Radius.circular(6.0))),
            child: Form(
              key: _personalInfoForKey,
              autovalidateMode: AutovalidateMode.always,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: const [
                      Expanded(
                        flex: 1,
                        child: Text(
                          'First Name',
                          textAlign: TextAlign.start,
                          style: TextStyle(
                              color: Colors.black87,
                              fontSize: 14,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                      SizedBox(
                        width: 12,
                      ),
                      Expanded(
                        flex: 1,
                        child: Text(
                          'Last Name',
                          textAlign: TextAlign.start,
                          style: TextStyle(
                              color: Colors.black87,
                              fontSize: 14,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Expanded(
                        flex: 1,
                        child: TextFormField(
                          validator: validationFirstName,
                          textInputAction: TextInputAction.next,
                          controller: firstNameController,
                          onSaved: (String? val) {
                            firstName = val;
                          },
                          keyboardType: TextInputType.text,
                          decoration: InputDecoration(
                            contentPadding:
                            const EdgeInsets.symmetric(horizontal: 16),
                            hintText: 'First Name',
                            // labelText: 'First Name',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(6),
                                borderSide:
                                const BorderSide(color: Color(0xFFF4F4F4))),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(6),
                                borderSide:
                                const BorderSide(color: Color(0xFFF4F4F4))),
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 12,
                      ),
                      Expanded(
                        flex: 1,
                        child: TextFormField(
                          validator: validationLastName,
                          textInputAction: TextInputAction.next,
                          controller: lastNameController,
                          onSaved: (String? val) {
                            lastName = val;
                          },
                          keyboardType: TextInputType.text,
                          decoration: InputDecoration(
                            contentPadding:
                            const EdgeInsets.symmetric(horizontal: 16),
                            hintText: 'Last Name',
                            // labelText: 'Last Name',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(6),
                                borderSide:
                                const BorderSide(color: Color(0xFFF9F9F9))),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(6),
                                borderSide:
                                const BorderSide(color: Color(0xFFF9F9F9))),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  const SizedBox(
                    width: double.infinity,
                    child: Text(
                      'Mobile No',
                      textAlign: TextAlign.start,
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 14,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      validator: validationMobile,
                      textInputAction: TextInputAction.done,
                      controller: mobileController,
                      maxLength: 11,
                      onSaved: (String? val) {
                        mobile = val;
                      },
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        contentPadding: EdgeInsets.symmetric(horizontal: 16),
                        hintText: 'Mobile No',
                        // labelText: 'Mobile No',
                        prefix: const Text('+60'),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(6),
                            borderSide: const BorderSide(color: Color(0xFFF9F9F9))),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(6),
                            borderSide: const BorderSide(color: Color(0xFFF9F9F9))),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                      width: double.infinity,
                      child: SizedBox(
                        width: double.infinity,
                        height: 45,
                        // margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6.0),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6.0)),
                            primary: AppsColors.buttonColor,
                          ),
                          onPressed: () {
                            if (_personalInfoForKey.currentState!.validate()) {
                              _personalInfoForKey.currentState!.save();
                              changeInfo(context);
                            }
                          },
                          child: const Text(
                            'Save Information',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      )),
                  const SizedBox(
                    height: 16,
                  ),
                ],
              ),
            ),
          ),
        )
      ],
    );
  }
}

class ChangeEmail extends StatefulWidget {
  const ChangeEmail({Key? key,this.scrollController}) : super(key: key);
  final ScrollController? scrollController;
  @override
  _ChangeEmailState createState() => _ChangeEmailState();
}

class _ChangeEmailState extends State<ChangeEmail> {
  final _emailRegex = RegExp(
    r'^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$',
  );
  final GlobalKey<FormState> _changeEmailKey = GlobalKey<FormState>();

  String? oldEmail;
  String? newEmail;
  String? oldMatchEmail;

  var oldEmailController = TextEditingController();
  var newEmailController = TextEditingController();

  String? validationEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Enter an email address!';
    } else if (!_emailRegex.hasMatch(value)) {
      return 'Enter a valid email!';
    } else if (value != oldMatchEmail) {
      return 'Does\'nt Match Current Email';
    } else {
      return null;
    }
  }

  String? validationNewEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Enter an email address!';
    } else if (!_emailRegex.hasMatch(value)) {
      return 'Enter a valid email!';
    } else {
      return null;
    }
  }

  void getEmail() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    oldMatchEmail = localStorage.getString(SharedPreferenceUtils.EMAIL);
  }

  void changeEmail(BuildContext context) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    Map<String, dynamic> data = {
      'old_email': '$oldEmail',
      'new_email': '$newEmail',
      'user_id': '$userId',
      'token': '$token',
      'session': '$session',
    };
    var requestBody = json.encode(data);
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.changeEmail);
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      Common.toastMsg('${body["message"]}');
      if (body["status"] == 1) {
        SharedPreferences localStorage = await SharedPreferences.getInstance();
        localStorage.setString(
            SharedPreferenceUtils.EMAIL, newEmail!);

        SharedPreferenceUtils.emailF = newEmail;
      }
      Navigator.pop(context);
    } on FormatException catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    getEmail();
    return CustomScrollView(
      scrollDirection: Axis.vertical,
      controller: widget.scrollController,
      shrinkWrap: true,
      slivers: [
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 8,
          ),
        ),
        SliverToBoxAdapter(
          child: Align(
            alignment: Alignment.center,
            child: Container(
              height: 4,
              width: 100,
              decoration: const BoxDecoration(
                color: Color(0xFFF4F4F4),
                // borderRadius: BorderRadius.circular(16.0)
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 45,
            child: Stack(
              children: [
                const Align(
                  alignment: Alignment.center,
                  child: Image(
                    image: AssetImage('images/azura_logo_small.png'),
                    height: 100,
                    width: 100,
                    // width:
                    // MediaQuery.of(context).orientation == Orientation.portrait
                    //     ? MediaQuery.of(context).size.width * 0.6
                    //     : MediaQuery.of(context).size.height * 0.6,
                  ),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.close,
                      size: 20,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 12,
          ),
        ),
        SliverToBoxAdapter(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(6.0), topRight: Radius.circular(6.0))),
            child: Form(
              key: _changeEmailKey,
              // autovalidateMode: AutovalidateMode.always,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(
                    width: double.infinity,
                    child: Text(
                      'Current Email',
                      textAlign: TextAlign.start,
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 14,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      validator: validationEmail,
                      controller: oldEmailController,
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      maxLines: 1,
                      onSaved: (String? val) {
                        oldEmail = val;
                      },
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                        hintText: 'example@gmail.com',
                        // labelText: 'Email',
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(6),
                            borderSide: const BorderSide(color: Color(0xFFF4F4F4))),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(6),
                            borderSide: const BorderSide(color: Color(0xFFF4F4F4))),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  const SizedBox(
                    width: double.infinity,
                    child: Text(
                      'New Email',
                      textAlign: TextAlign.start,
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 14,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      validator: validationNewEmail,
                      textInputAction: TextInputAction.done,
                      controller: newEmailController,
                      keyboardType: TextInputType.emailAddress,
                      maxLines: 1,
                      onSaved: (String? val) {
                        newEmail = val;
                      },
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                        hintText: 'newexample@gmail.com',
                        // labelText: 'Email',
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(6),
                            borderSide: const BorderSide(color: Color(0xFFF4F4F4))),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(6),
                            borderSide: const BorderSide(color: Color(0xFFF4F4F4))),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                      width: double.infinity,
                      child: SizedBox(
                        width: double.infinity,
                        height: 45,
                        // margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6.0),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6.0)),
                            primary: AppsColors.buttonColor,
                          ),
                          onPressed: () {
                            if (_changeEmailKey.currentState!.validate()) {
                              _changeEmailKey.currentState!.save();
                              changeEmail(context);
                            }
                          },
                          child: const Text(
                            'Save Email',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      )),
                  const SizedBox(
                    height: 16,
                  ),
                ],
              ),
            ),
          ),
        )
      ],
    );
  }
}

class ChangePasswordDialog extends StatefulWidget {
  const ChangePasswordDialog({Key? key,this.scrollController}) : super(key: key);
  final ScrollController? scrollController;

  @override
  _ChangePasswordDialogState createState() => _ChangePasswordDialogState();
}

class _ChangePasswordDialogState extends State<ChangePasswordDialog> {

  final GlobalKey<FormState> _changePasswordFormKey = GlobalKey<FormState>();
  var oldPasswordController = TextEditingController();
  var passwordController = TextEditingController();
  var confirmPasswordController = TextEditingController();
  String? oldPassword;
  String? password;
  String? confirmPassword;

  String? validationOldPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Old Password!';
    } else if (value.length < 5) {
      return 'Enter minimum 5 digit';
    } else {
      return null;
    }
  }
  String? validationPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Password!';
    } else if (value.length < 5) {
      return 'Enter minimum 5 digit';
    } else {
      return null;
    }
  }
  String? validationConfirmPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Confirm Password!';
    } else if (value.compareTo(passwordController.text.toString()) == 0) {
      return null;
    } else {
      return 'Doesn\'t match with password';
    }
  }

  bool _obscureText = true;
  void _toggle() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  Future<void> changePassword() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    Map<String, dynamic> data = {
      'current_password': '$oldPassword',
      'new_password': '$password',
      'user_id': '$userId',
      'token': '$token',
      'session': '$session',
    };
    var requestBody = json.encode(data);
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.changePassword);
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      print('parsed');
      if (body["status"] == 1) {
        /// arif vai er suggestion e redirect to login page...
        Common.toastMsg('${body["message"]}');
        // Navigator.pushAndRemoveUntil(
        //     context, LoginPage.route(), (route) => false);
      } else {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(content: Text('${body["message"]}')));
      }
    } on FormatException catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    _obscureText = true;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      scrollDirection: Axis.vertical,
      controller: widget.scrollController,
      shrinkWrap: true,
      slivers: [
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 8,
          ),
        ),
        SliverToBoxAdapter(
          child: Align(
            alignment: Alignment.center,
            child: Container(
              height: 4,
              width: 100,
              decoration: const BoxDecoration(
                color: Color(0xFFF4F4F4),
                // borderRadius: BorderRadius.circular(16.0)
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 45,
            child: Stack(
              children: [
                const Align(
                  alignment: Alignment.center,
                  child: Image(
                    image: AssetImage('images/azura_logo_small.png'),
                    height: 100,
                    width: 100,
                    // width:
                    // MediaQuery.of(context).orientation == Orientation.portrait
                    //     ? MediaQuery.of(context).size.width * 0.6
                    //     : MediaQuery.of(context).size.height * 0.6,
                  ),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.close,
                      size: 20,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 12,
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Form(
              key: _changePasswordFormKey,
              child: Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      textAlign: TextAlign.start,
                      style: const TextStyle(
                          color: Colors.black87,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                      controller: oldPasswordController,
                      validator: validationOldPassword,
                      textInputAction: TextInputAction.next,
                      keyboardType: TextInputType.visiblePassword,
                      obscureText: _obscureText,
                      maxLines: 1,
                      cursorColor: Colors.black87,
                      onSaved: (String? val) {
                        oldPassword = val;
                      },
                      decoration: InputDecoration(
                        suffixIcon: GestureDetector(
                          onTap: () {
                            _toggle();
                          },
                          child: _obscureText
                              ? const Icon(
                            Icons.visibility_off,
                            color: Colors.black54,
                          )
                              : const Icon(
                            Icons.visibility,
                            color: Colors.black54,
                          ),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 16),
                        fillColor: const Color(0xFFD1D2D3).withOpacity(0.4),
                        filled: true,
                        hintText: 'Current Password',
                        focusedBorder: InputBorder.none,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        errorBorder: InputBorder.none,
                        disabledBorder: InputBorder.none,
                      ),
                    ),
                  ),

                  const SizedBox(
                    height: 20,
                  ),
                  const SizedBox(
                    width: double.infinity,
                    child: Text('Please enter your new password below',style: TextStyle(color: Colors.black,fontSize: 16),),
                  ),

                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      textAlign: TextAlign.start,
                      style: const TextStyle(
                          color: Colors.black87,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                      controller: passwordController,
                      validator: validationPassword,
                      textInputAction: TextInputAction.next,
                      keyboardType: TextInputType.visiblePassword,
                      obscureText: _obscureText,
                      maxLines: 1,
                      cursorColor: Colors.black87,
                      onSaved: (String? val) {
                        password = val;
                      },
                      decoration: InputDecoration(
                        suffixIcon: GestureDetector(
                          onTap: () {
                            _toggle();
                          },
                          child: _obscureText
                              ? const Icon(
                            Icons.visibility_off,
                            color: Colors.black54,
                          )
                              : const Icon(
                            Icons.visibility,
                            color: Colors.black54,
                          ),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 16),
                        fillColor: const Color(0xFFD1D2D3).withOpacity(0.4),
                        filled: true,
                        hintText: 'New Password',
                        focusedBorder: InputBorder.none,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        errorBorder: InputBorder.none,
                        disabledBorder: InputBorder.none,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      textAlign: TextAlign.start,
                      style: const TextStyle(
                          color: Colors.black87,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                      controller: confirmPasswordController,
                      validator: validationConfirmPassword,
                      textInputAction: TextInputAction.done,
                      keyboardType: TextInputType.visiblePassword,
                      obscureText: _obscureText,
                      maxLines: 1,
                      cursorColor: Colors.black87,
                      onSaved: (String? val) {
                        confirmPassword = val;
                      },
                      decoration: InputDecoration(
                        suffixIcon: GestureDetector(
                          onTap: () {
                            _toggle();
                          },
                          child: _obscureText
                              ? const Icon(
                            Icons.visibility_off,
                            color: Colors.black54,
                          )
                              : const Icon(
                            Icons.visibility,
                            color: Colors.black54,
                          ),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 16),
                        fillColor: const Color(0xFFD1D2D3).withOpacity(0.4),
                        filled: true,
                        hintText: 'Confirm New Password',
                        focusedBorder: InputBorder.none,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        errorBorder: InputBorder.none,
                        disabledBorder: InputBorder.none,
                      ),
                    ),
                  ),

                  const SizedBox(
                    height: 16,
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    height: 45,
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        if (_changePasswordFormKey.currentState!.validate()) {
                          _changePasswordFormKey.currentState!.save();
                          try {
                            final result = await InternetAddress.lookup('example.com');
                            if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                              Common.toastMsg('Password updating...');
                              changePassword();
                              Navigator.pop(context);
                            }
                          } on SocketException catch (_) {
                            Common.toastMsg('No Internet Connection');
                          }
                        }
                      },
                      style: ElevatedButton.styleFrom(
                          primary: AppsColors.buttonColor,
                          shape: const RoundedRectangleBorder(
                              borderRadius:
                              BorderRadius.all(Radius.circular(6.0)))),
                      child: const Text(
                        'Change Password',
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}


