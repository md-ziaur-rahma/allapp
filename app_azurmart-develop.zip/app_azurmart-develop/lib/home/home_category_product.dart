import 'package:azuramartmy/my_bloc/category_product_bloc.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/category_product.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:azuramartmy/utils/custom_route.dart';

class HomeCategoryProduct extends StatelessWidget {
  final String categoryName;
  final String categorySlug;
  const HomeCategoryProduct(this.categoryName, this.categorySlug);

  @override
  Widget build(BuildContext context) {
    categoryProductBloc.fetchAllCategoryProduct(categorySlug, null, null);
    print(categorySlug);
    return StreamBuilder(
        stream: categoryProductBloc.allCategoryProduct,
        builder: (context, AsyncSnapshot<CategoryProduct> snapshot) {
          if (snapshot.hasData) {
            return Expanded(
              child: SizedBox(
                width: double.infinity,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          margin: const EdgeInsets.symmetric(horizontal: 20),
                          child: Text(
                            categoryName,
                            style: const TextStyle(
                                color: Colors.black,
                                fontSize: 15,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                        const Spacer(),
                        Container(
                          margin: const EdgeInsets.symmetric(horizontal: 20),
                          child: TextButton(
                              onPressed: () {
                                // Navigator.push(context, NewestPage.route());
                              },
                              child: const Text('See All',
                                  style: TextStyle(color: Colors.black87))),
                        )
                      ],
                    ),
                    const SizedBox(
                      height: 12,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: ConstrainedBox(
                            constraints: BoxConstraints(
                              maxHeight: MediaQuery.of(context).size.width * 0.4,
                              minHeight: MediaQuery.of(context).size.width * 0.3,
                            ),
                            child: ListView(
                              scrollDirection: Axis.horizontal,
                              children: [
                                ...List.generate(
                                    snapshot.data!.data!.length > 10
                                        ? 10
                                        : snapshot.data!.data!.length,
                                        (index) => HomeCategoryProductGridItemLayout(index, snapshot))
                              ],
                            ),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            );
          } else if (snapshot.hasError) {
            return Text(snapshot.error.toString());
          }
          return const Text('loading category');
        });

  }
}

class HomeCategoryProductGridItemLayout extends StatelessWidget {
  final int index;
  final AsyncSnapshot<CategoryProduct> snapshot;
  const HomeCategoryProductGridItemLayout(this.index, this.snapshot);
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        ProductDetailsPage.productUrl = snapshot.data!.data![index].url;
        ProductDetailsPage.variantPk = snapshot.data!.data![index].pkno;
        ProductDetailsPage.isWish = snapshot.data!.data![index].isWish;
        Navigator.of(context).push(
                CustomRoutePageBuilder
                    .createPageRouteLeft(
                    context, ProductDetailsPage()));
      },
      child: Flexible(
        child: Container(
          color: Colors.transparent,
          width: MediaQuery.of(context).size.width * 0.4,
          margin: const EdgeInsets.symmetric(horizontal: 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Flexible(
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.4,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    color: const Color(0xFFC2DFFF).withOpacity(0.2),
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                            padding: const EdgeInsets.symmetric(
                                vertical: 10, horizontal: 10),
                            child: ConstrainedBox(
                              constraints: const BoxConstraints(
                                  minHeight: 60, maxHeight: 130),
                              child: Image(
                                image: NetworkImage(Urls.basePictureUrl +
                                    snapshot.data!.data![index]
                                        .primaryimgrelativepath!),
                              ),
                            )),
                      ),
                      // Align(
                      //   alignment: Alignment.topRight,
                      //   child: Ink(
                      //     decoration: ShapeDecoration(
                      //       color: Color(0xFFF4F4F4),
                      //       shape: CircleBorder(),
                      //     ),
                      //     child: IconButton(
                      //       onPressed: () {},
                      //       icon: Icon(
                      //         Icons.favorite_outline,
                      //         size: 16,
                      //         color: Colors.black87,
                      //       ),
                      //     ),
                      //   ),
                      // ),
                      Align(
                        alignment: Alignment.bottomRight,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              margin: const EdgeInsets.all(0.5),
                              height: 6,
                              width: 6,
                              decoration: const ShapeDecoration(
                                shape: CircleBorder(),
                                color: Colors.red,
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.all(0.5),
                              height: 6,
                              width: 6,
                              decoration: const ShapeDecoration(
                                shape: CircleBorder(),
                                color: Colors.blue,
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.all(0.5),
                              height: 6,
                              width: 6,
                              decoration: const ShapeDecoration(
                                shape: CircleBorder(),
                                color: Colors.yellow,
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  child: Text(
                    '${snapshot.data!.data![index].variantname}',
                    maxLines: 1,
                    style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87),
                  ),
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: Padding(
                  padding:
                      const EdgeInsets.only(left: 10, right: 10, bottom: 6),
                  child: RichText(
                    text: TextSpan(
                        text: 'RM${snapshot.data!.data![index].regularprice}',
                        style: const TextStyle(
                            color: Color(0xFFF68721),
                            fontSize: 12,
                            fontWeight: FontWeight.w600),
                        children: <TextSpan>[
                          TextSpan(
                            text:
                                '    RM${snapshot.data!.data![index].regularprice}',
                            style: const TextStyle(
                                color: Colors.black38,
                                fontSize: 10,
                                fontWeight: FontWeight.normal),
                          )
                        ]),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
