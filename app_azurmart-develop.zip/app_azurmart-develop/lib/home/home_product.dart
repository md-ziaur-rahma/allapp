import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/newest_screen/newest_page.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/new_arrival_item_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:flutter/material.dart';

class HomeProduct extends StatelessWidget {
  final String type;
  final AsyncSnapshot<NewArrivalItemModel> snapshot;
  const HomeProduct(this.type, this.snapshot);
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 3),
      padding: const EdgeInsets.only(bottom: 0, right: 0, left: 0),
      decoration: const BoxDecoration(
        color: Colors.transparent,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 45,
                    width: 6,
                    decoration: const BoxDecoration(
                        color: Color(0xFF000000),
                        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(6.0),topLeft: Radius.circular(6.0))
                    ),
                  ),
                  const SizedBox(width: 10,),
                  Text(
                    type,
                    style: const TextStyle(
                        color: Colors.black,
                        fontSize: 15,
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              const Spacer(),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 0),
                child: TextButton(
                    onPressed: () async {
                      try {
                        final result = await InternetAddress.lookup('example.com');
                        if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                          Navigator.of(context).push(
                              CustomRoutePageBuilder.createPageRouteLeft(
                                  context, NewestPage()));
                          // Navigator.push(context, NewestPage.route());
                        }
                      } on SocketException catch (_) {
                        Common.toastMsg('No Internet Connection');
                      }
                    },
                    child: Text('See All',
                        style: TextStyle(color: AppsColors.buttonColor))),
              )
            ],
          ),
          Row(
            children: [
              Expanded(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(
                    maxHeight: 220,
                    minHeight: 16,
                  ),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      ...List.generate(snapshot.data!.data!.length,
                          (index) => HomeGridItemLayout(index, snapshot))
                    ],
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}

class HomeGridItemLayout extends StatefulWidget {
  final int index;
  final AsyncSnapshot<NewArrivalItemModel> snapshot;
  const HomeGridItemLayout(this.index, this.snapshot);

  @override
  _HomeGridItemLayoutState createState() => _HomeGridItemLayoutState();
}

class _HomeGridItemLayoutState extends State<HomeGridItemLayout> {
  int toggleMsg = 0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ProductDetailsPage.productUrl =
                widget.snapshot.data!.data![widget.index].url;
            ProductDetailsPage.variantPk =
                widget.snapshot.data!.data![widget.index].pkno;
            ProductDetailsPage.isWish =
                widget.snapshot.data!.data![widget.index].isWish;
            Navigator.of(context).push(
                CustomRoutePageBuilder
                    .createPageRouteLeft(
                    context, ProductDetailsPage()));
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }

      },
      child: Container(
        width: MediaQuery.of(context).orientation == Orientation.portrait
            ? MediaQuery.of(context).size.width * 0.4
            : MediaQuery.of(context).size.height * 0.4,
        margin: const EdgeInsets.symmetric(horizontal: 8),
        padding: const EdgeInsets.only(bottom: 8, right: 4, left: 4),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(6.0),
          // border:
          //     Border.all(color: Color(0xFFD0D1D2).withOpacity(0.3), width: 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Flexible(
              child: Container(
                width:
                    MediaQuery.of(context).orientation == Orientation.portrait
                        ? MediaQuery.of(context).size.width * 0.4
                        : MediaQuery.of(context).size.height * 0.4,
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: const Color(0xFFFFFFFF).withOpacity(0.2),
                ),
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                          padding:
                          const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(
                                minHeight: 60, maxHeight: 140),
                            child: widget.snapshot.data!.data![widget.index].thumbPath == null ? Center(
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 8),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: const Color(0xFFF4F4F4), width: 1)),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: const [
                                    Icon(Icons.camera_alt_outlined,size: 20,),
                                    SizedBox(width: 8,),
                                    Text(
                                      'No Image',
                                      style: TextStyle(
                                          color: Colors.black87,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w800),
                                    )
                                  ],
                                ),
                              ),
                            ) : CacheImageProvide(url: widget.snapshot.data!.data![widget.index].thumbPath,),
                          )),
                    ),
                    LayoutBuilder(
                      builder:
                          (BuildContext context, BoxConstraints constraints) {
                        if (widget.snapshot.data!.data![widget.index].offer !=
                            0) {
                          return GestureDetector(
                            onTap: () {
                              // setState(() {
                              //   toggleMsg = toggleMsg == 1 ? 0 : 1;
                              // });
                            },
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                height: 45,
                                width: 45,
                                padding: const EdgeInsets.all(3.0),
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.red,
                                ),
                                child: const Center(
                                  child: Text(
                                    'In \nOffer',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: Colors.white,fontWeight: FontWeight.w600, fontSize: 12),
                                  ),
                                ),
                              ),
                            ),
                          );
                        } else {
                          return const Align(
                            alignment: Alignment.topLeft,
                            child: SizedBox(
                              height: 2,
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),

            /// ................. price ......................
            SizedBox(
              // width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.only(left: 10, right: 10, bottom: 6),
                child: RichText(
                  text: TextSpan(
                    text: widget.snapshot.data!.data![widget.index]
                                .totalfreestock! >
                            0
                        ? 'RM${widget.snapshot.data!.data![widget.index].regularprice!.toStringAsFixed(2)}'
                        : 'Out Of Stock',
                    style: TextStyle(color: AppsColors.highlightedColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w600),
                    // children: <TextSpan>[
                    //   TextSpan(
                    //     text: '    RM${snapshot.data.data[index].insPrice}',
                    //     style: TextStyle(
                    //         color: Colors.black38,
                    //         fontSize: 10,
                    //         fontWeight: FontWeight.normal),
                    //   )
                    // ]
                  ),
                ),
              ),
            ),

            /// ................. variable name ......................
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                child: Text(
                  '${widget.snapshot.data!.data![widget.index].variantname}',
                  textAlign: TextAlign.center,
                  maxLines: 3,
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
