import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:optimized_cached_image/optimized_cached_image.dart';
import 'package:azuramartmy/provider_models/home_slider_model.dart';

class HomeSlider extends StatefulWidget {
  final AsyncSnapshot<HomeSliderModel> snapshot;
  const HomeSlider(this.snapshot);

  @override
  _HomeSliderState createState() => _HomeSliderState();
}

class _HomeSliderState extends State<HomeSlider> {
  int currentPage = 0;
  final PageController _pageController = PageController(
    initialPage: 0,
  );

  @override
  void initState() {
    // if (mounted) {
    //   Timer.periodic(Duration(seconds: 5), (Timer timer) {
    //     if (currentPage < (widget.snapshot.data.data.length - 1)) {
    //       currentPage++;
    //     } else {
    //       currentPage = 0;
    //     }
    //
    //     _pageController.animateToPage(
    //       currentPage,
    //       duration: Duration(milliseconds: 600),
    //       curve: Curves.easeIn,
    //     );
    //   });
    // }

    super.initState();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }
  

  @override
  Widget build(BuildContext context) {
    // print('bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb ${MediaQuery.of(context).size.width}/${MediaQuery.of(context).size.height} bbbbbbbbbbbbbbbbbbbbbbbbbbbb');
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          color: Colors.white,
          height: (MediaQuery.of(context).size.width - 32) * 0.4,
          // height: MediaQuery.of(context).orientation == Orientation.portrait (.... 0.31.....)
          //     ? (MediaQuery.of(context).size.width - 32) * 0.33
          //     : MediaQuery.of(context).size.width > 740 ? MediaQuery.of(context).size.height * 0.86 : MediaQuery.of(context).size.height * 0.5,
          width: double.infinity,
          child: PageView.builder(
            allowImplicitScrolling: true,
              scrollBehavior: const ScrollBehavior(),
              // reverse: true,
              // pageSnapping: false,
              scrollDirection: Axis.horizontal,
              // controller: _pageController,
              onPageChanged: (value) {
                setState(() {
                  currentPage = value;
                });
              },
              itemCount: widget.snapshot.data!.data!.length,
              itemBuilder: (context, index) =>
                  HomeImageSlider(index, widget.snapshot)),
        ),
        Positioned(
          bottom: 8,
          child: Container(
            margin: const EdgeInsets.only(top: 0),
            padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
            decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.5),
                borderRadius: BorderRadius.circular(30.0)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                ...List.generate(widget.snapshot.data!.data!.length,
                    (index) => buildDot(index))
              ],
            ),
          ),
        )
      ],
    );
  }

  AnimatedContainer buildDot(int index) {
    return AnimatedContainer(
      duration: const Duration(microseconds: 500),
      curve: Curves.easeInCubic,
      margin: const EdgeInsets.only(right: 5),
      height: 6,
      width: currentPage == index ? 12 : 6,
      decoration: ShapeDecoration(
          color: currentPage == index
              ? Colors.pink
              : const Color(0xffffffff).withOpacity(0.8),
          shape: const StadiumBorder()
      ),
    );
  }
}

class HomeImageSlider extends StatelessWidget {
  final int index;
  final AsyncSnapshot<HomeSliderModel> snapshot;
  const HomeImageSlider(this.index, this.snapshot);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: (MediaQuery.of(context).size.width - 32) * 0.4,
      // height: MediaQuery.of(context).orientation == Orientation.portrait
      //     ? MediaQuery.of(context).size.width * 0.25
      //     : MediaQuery.of(context).size.width > 740 ? MediaQuery.of(context).size.height * 0.86 : MediaQuery.of(context).size.height * 0.5,
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      child: Center(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(10.0),
          child: OptimizedCacheImage(
            imageUrl: Urls.basePictureUrl + snapshot.data!.data![index].banner!,
            imageBuilder: (context, imageProvider) => Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: imageProvider,
                  fit: BoxFit.cover,
                  // colorFilter: ColorFilter.mode(Colors.transparent, BlendMode.exclusion)
                ),
              ),
            ),
            placeholder: (context, url) => Center(
              child: SizedBox(
                height: 16,
                width: 16,
                child: CircularProgressIndicator(
                  strokeWidth: 2.0,
                  valueColor: AlwaysStoppedAnimation(AppsColors.buttonColor),
                ),
              ),
            ),
            errorWidget: (context, url, error) => const Icon(Icons.error),
          ),
        ),
      ),
    );
  }
}
