import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/offer_details/offer_details_page.dart';
import 'package:azuramartmy/provider_models/offer_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:optimized_cached_image/optimized_cached_image.dart';

class HomeOfferCard extends StatefulWidget {
  const HomeOfferCard({Key? key,this.snapshot,this.index}) : super(key: key);
  final OfferModel? snapshot;
  final int? index;

  @override
  _HomeOfferCardState createState() => _HomeOfferCardState();
}

class _HomeOfferCardState extends State<HomeOfferCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            OfferDetailsPage.offerName = widget.snapshot!.data![widget.index!].url;
            Navigator.push(context, OfferDetailsPage.route());
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }

      },
      child: Container(
        //height: MediaQuery.of(context).size.width * 0.6,
        // margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 0),
        padding: const EdgeInsets.only(bottom: 8, right: 4, left: 4),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(6.0),
          // border:
          // Border.all(color: Color(0xFFD0D1D2).withOpacity(0.3), width: 1),
        ),
        width: MediaQuery.of(context).orientation == Orientation.portrait
            ? MediaQuery.of(context).size.width * 0.4
            : MediaQuery.of(context).size.height * 0.4,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Flexible(
              child: Container(
                //height: MediaQuery.of(context).size.width * 0.4,
                width:
                MediaQuery.of(context).orientation == Orientation.portrait
                    ? MediaQuery.of(context).size.width * 0.4
                    : MediaQuery.of(context).size.height * 0.4,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: const Color(0xFFFFFFFF).withOpacity(0.2),
                ),
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                          padding:
                          const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(
                                minHeight: 60, maxHeight: 120),
                            child: widget.snapshot!.data![widget.index!].image == null
                                ? const NoImageWidget(text: 'No Image',)
                                :  CacheImageProvide(url: widget.snapshot!.data![widget.index!].image,),
                          )),
                    ),
                    // Align(
                    //   alignment: Alignment.topRight,
                    //   child: Material(
                    //     color: Colors.transparent,
                    //     child: Ink(
                    //       decoration: ShapeDecoration(
                    //         color:
                    //         widget.snapshot.data[widget.index].isWish == 0
                    //             ? Color(0xFFF4F4F4).withOpacity(0.4)
                    //             : Color(0xFFF68721).withOpacity(0.1),
                    //         shape: CircleBorder(),
                    //       ),
                    //       child: IconButton(
                    //         onPressed: () {
                    //           setState(() {
                    //             widget.snapshot.data[widget.index].isWish =
                    //             widget.snapshot.data[widget.index].isWish ==
                    //                 0
                    //                 ? 1
                    //                 : 0;
                    //             AddToWish addWish = AddToWish();
                    //             addWish.addToWish(widget
                    //                 .snapshot.data[widget.index].fprdvariantno);
                    //           });
                    //         },
                    //         icon: widget.snapshot.data[widget.index].isWish == 0
                    //             ? Icon(
                    //           Icons.favorite_outline,
                    //           size: 16,
                    //           color: Colors.black87,
                    //         )
                    //             : Icon(
                    //           Icons.favorite,
                    //           size: 16,
                    //           color: Color(0xFFF68721),
                    //         ),
                    //       ),
                    //     ),
                    //   ),
                    // ),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                child: Text(
                  '${widget.snapshot!.data![widget.index!].bundlenamepublic}',
                  maxLines: 3,
                  textAlign: TextAlign.center,
                  // maxLines: 2,
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87),
                ),
              ),
            ),
            // LayoutBuilder(builder:
            //     (BuildContext context, BoxConstraints constraints) {
            //   if (widget.snapshot.data[widget.index].price < 1000) {
            //     return Row(
            //       children: [
            //         Expanded(
            //             flex: 1,
            //             child: Padding(
            //               padding: const EdgeInsets.symmetric(
            //                   horizontal: 2, vertical: 3),
            //               child: Image(
            //                 image: AssetImage('images/grab-1.png'),
            //                 width: 26,
            //                 height:20,
            //               ),
            //             )),
            //         Expanded(
            //           flex: 1,
            //           child: Padding(
            //             padding:
            //             const EdgeInsets.symmetric(horizontal: 3, vertical: 3),
            //             child: Image(
            //               image: AssetImage('images/azura_logo_small.png'),
            //               width: 20,
            //               height: 20,
            //             ),
            //           ),
            //         ),
            //         Expanded(
            //           flex: 1,
            //           child: Padding(
            //             padding:
            //             const EdgeInsets.symmetric(horizontal: 3, vertical: 3),
            //             child: Image(
            //               image: AssetImage('images/hoolahh.png'),
            //               width: 32,
            //               height: 20,
            //             ),
            //           ),
            //         ),
            //       ],
            //     );
            //   } else {
            //     return Row(
            //       children: [
            //         Expanded(
            //           flex: 1,
            //           child: Padding(
            //             padding:
            //             const EdgeInsets.symmetric(horizontal: 3, vertical: 3),
            //             child: Image(
            //               image: AssetImage('images/azura_logo_small.png'),
            //               width: 20,
            //               height: 20,
            //             ),
            //           ),
            //         ),
            //         Expanded(
            //           flex: 1,
            //           child: Padding(
            //             padding:
            //             const EdgeInsets.symmetric(horizontal: 3, vertical: 3),
            //             child: Image(
            //               image: AssetImage('images/hoolahh.png'),
            //               width: 32,
            //               height: 20,
            //             ),
            //           ),
            //         ),
            //       ],
            //     );
            //   }
            // }),
          ],
        ),
      ),
    );
  }
}
