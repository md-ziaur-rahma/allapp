import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/about_us/aboutus_page.dart';
import 'package:azuramartmy/all_category/all_category_page.dart';
import 'package:azuramartmy/best_sell/best_sell_body.dart';
import 'package:azuramartmy/best_sell/best_sell_page.dart';
import 'package:azuramartmy/brand/brand_page.dart';
import 'package:azuramartmy/brand_details/brand_details_chngenotifier.dart';
import 'package:azuramartmy/brand_details/brand_details_page.dart';
import 'package:azuramartmy/category_evaly/category_evaly_page.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/common_widgets/shimmer_effect_horizontal.dart';
import 'package:azuramartmy/common_widgets/simmer_effect_banner.dart';
import 'package:azuramartmy/feature/feature_page.dart';
import 'package:azuramartmy/home/coupon_product.dart';
import 'package:azuramartmy/home/home_offer_card.dart';
import 'package:azuramartmy/home/home_product.dart';
import 'package:azuramartmy/home/home_slider.dart';
import 'package:azuramartmy/my_bloc/best_sell_bloc.dart';
import 'package:azuramartmy/my_bloc/brand_bloc.dart';
import 'package:azuramartmy/my_bloc/brand_product_bloc.dart';
import 'package:azuramartmy/my_bloc/category_bloc.dart';
import 'package:azuramartmy/my_bloc/coupon_home_bloc.dart';
import 'package:azuramartmy/my_bloc/feature_bloc.dart';
import 'package:azuramartmy/my_bloc/first_cat_bloc.dart';
import 'package:azuramartmy/my_bloc/home_slider_bloc.dart';
import 'package:azuramartmy/my_bloc/instagram_feed_bloc.dart';
import 'package:azuramartmy/my_bloc/new_arrival_product_bloc.dart';
import 'package:azuramartmy/my_bloc/offers_bloc.dart';
import 'package:azuramartmy/my_bloc/second_cat_bloc.dart';
import 'package:azuramartmy/my_bloc/third_cat_bloc.dart';
import 'package:azuramartmy/offers/offers_page.dart';
import 'package:azuramartmy/order_list/order_list_page.dart';
import 'package:azuramartmy/ournews/ournews_page.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/best_sell_model.dart';
import 'package:azuramartmy/provider_models/category_product.dart';
import 'package:azuramartmy/provider_models/check_update_model.dart';
import 'package:azuramartmy/provider_models/coupon_home_model.dart';
import 'package:azuramartmy/provider_models/home_slider_model.dart';
import 'package:azuramartmy/provider_models/instagram_feed_model.dart';
import 'package:azuramartmy/provider_models/new_arrival_item_model.dart';
import 'package:azuramartmy/provider_models/offer_model.dart';
import 'package:azuramartmy/provider_models/page_list_model.dart';
import 'package:azuramartmy/utils/apps_strings.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:azuramartmy/provider_models/category2.dart';
import 'package:azuramartmy/provider_models/brand_model.dart';
import 'package:azuramartmy/provider_models/feature_model.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' show Client;
import 'package:optimized_cached_image/optimized_cached_image.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

class HomePageBody extends StatefulWidget {
  const HomePageBody({Key? key}) : super(key: key);

  @override
  _HomePageBodyState createState() => _HomePageBodyState();
}

class _HomePageBodyState extends State<HomePageBody> {
  FeatureModel featureModel = FeatureModel();
  OfferModel offerModel = OfferModel();
  BestSellModel bestSellModel = BestSellModel();
  CouponHomeModel couponHomeModel = CouponHomeModel();

  @override
  void initState() {
    featureModel.data = [];
    offerModel.data = [];
    bestSellModel.data = [];
    super.initState();
  }

  final Shader linearGradient = const LinearGradient(
    // colors: <Color>[Color(0xffDA44bb), Color(0xff8921aa)],
    colors: <Color>[
      Color(0xff405DE6),
      Color(0xff833AB4),
      Color(0xffE1306C),
      Color(0xffF56040),
      Color(0xffFCAF45),
    ],
  ).createShader(const Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  final GlobalKey<FormState> _subscriptionFormKey = GlobalKey<FormState>();
  var subscriptionEmailController = TextEditingController();
  var subscriptionEmail;
  final _emailRegex = RegExp(
    r'^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$',
  );
  String? validationEmail(String? value) {
    if (value!.isEmpty) {
      return 'Enter an email!';
    } else if (!_emailRegex.hasMatch(value)) {
      return 'Enter a valid email!';
    } else {
      return null;
    }
  }

  void doSubscribe() async {
    Client client = Client();
    Map<String, dynamic> data = {
      'email': subscriptionEmail,
    };
    var requestBody = json.encode(data);
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.subscription);
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      final Map<String, dynamic> body = await json.decode(response.body);
      Common.toastMsg('${body["message"]}');
      subscriptionEmailController.clear();
    } on FormatException catch (e) {
      print(e);
    }
  }

  Future<PageListModel?> getPageList() async {
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.PAGE_LIST);
      var response = await client.post(url, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      final Map<String, dynamic> body = await json.decode(response.body);
      // PageListModel pageListModel = PageListModel.fromJson(body);
      return PageListModel.fromJson(body);
    } on FormatException catch (e) {
      print(e);
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    // showUpdateAlert(context);
    // checkUpdateAlert();
    categoryBloc.fetchAllCategory();
    homeSliderBloc.fetchAllHomeSliders();
    newProductBloc.fetchAllNewProduct();
    offerBloc.fetchAllOffer(1);
    bestSellBloc.fetchAllBestSellProducts();
    couponHomeBloc.fetchAllCouponHome();
    secondCategoryProductBloc.fetchAllSecondCategoryProduct(
        'fashion-accessories', '', '');
    thirdCategoryProductBloc.fetchAllThirdCategoryProduct(
        'home-kitchen', '', '');
    firstCategoryProductBloc.fetchAllFirstCategoryProduct('clothing', "", "");
    featureBloc.fetchAllFeatures();
    brandBloc.fetchAllBrands();
    instagramFeedBloc.fetchAllInstagramFeed();
    return CustomScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      scrollDirection: Axis.vertical,
      slivers: <Widget>[
        /// ......... Banner Slider .............
        StreamBuilder(
            stream: homeSliderBloc.allHomeSliders,
            builder: (context, AsyncSnapshot<HomeSliderModel> snapshot) {
              if (snapshot.hasData) {
                return SliverToBoxAdapter(
                  child: HomeSlider(snapshot),
                );
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Center(
                    child: Text(snapshot.error.toString()),
                  ),
                );
              }
              return const SliverToBoxAdapter(
                child: ShimmerEffectBanner(),
              );
            }),
        /// ......... Navigation IconButton .............
        SliverToBoxAdapter(
          child: Container(
            padding: const EdgeInsets.only(bottom: 8),
            decoration: const BoxDecoration(
              color: Colors.white,
            ),
            child: Material(
              color: Colors.transparent,
              type: MaterialType.canvas,
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Ink(
                        height: 70,
                        decoration: ShapeDecoration(
                          color: const Color(0xFFEAEAEA).withOpacity(0.5),
                          shape: const CircleBorder(),
                        ),
                        child: IconButton(
                          onPressed: () async {
                            try {
                              final result =
                                  await InternetAddress.lookup('example.com');
                              if (result.isNotEmpty &&
                                  result[0].rawAddress.isNotEmpty) {
                                Navigator.of(context).push(
                                    CustomRoutePageBuilder.createPageRouteLeft(
                                        context, const OurNewsPage()));
                                // Navigator.push(context, OurNewsPage.route());
                              }
                            } on SocketException catch (_) {
                              Common.toastMsg('No Internet Connection');
                            }
                          },
                          icon: Icon(
                            Icons.list_alt_outlined,
                            size: 24,
                            color: Colors.primaries[1],
                          ),
                        ),
                      ),
                      const Text('Our News'),
                    ],
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Ink(
                        height: 70,
                        decoration: ShapeDecoration(
                          color: const Color(0xFFEAEAEA).withOpacity(0.5),
                          shape: const CircleBorder(),
                        ),
                        child: IconButton(
                          onPressed: () async {
                            try {
                              final result =
                                  await InternetAddress.lookup('example.com');
                              if (result.isNotEmpty &&
                                  result[0].rawAddress.isNotEmpty) {
                                Navigator.of(context).push(
                                    CustomRoutePageBuilder.createPageRouteLeft(
                                        context, const AllCategoryPage()));
                                // Navigator.push(
                                //     context, AllCategoryPage.route());
                              }
                            } on SocketException catch (_) {
                              Common.toastMsg('No Internet Connection');
                            }
                          },
                          icon: Icon(
                            Icons.category_outlined,
                            size: 24,
                            color: Colors.primaries[2],
                          ),
                        ),
                      ),
                      const Text('Categories')
                    ],
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Ink(
                        height: 70,
                        decoration: ShapeDecoration(
                          color: const Color(0xFFEAEAEA).withOpacity(0.5),
                          shape: const CircleBorder(),
                        ),
                        child: IconButton(
                          onPressed: () async {
                            // Navigator.push(context, OrderPage.route());
                            try {
                              final result =
                                  await InternetAddress.lookup('example.com');
                              if (result.isNotEmpty &&
                                  result[0].rawAddress.isNotEmpty) {
                                Navigator.of(context).push(
                                    CustomRoutePageBuilder.createPageRouteLeft(
                                        context, OrderListPage()));
                              }
                            } on SocketException catch (_) {
                              Common.toastMsg('No Internet Connection');
                            }
                          },
                          icon: Icon(
                            Icons.book_outlined,
                            size: 24,
                            color: Colors.primaries[3],
                          ),
                        ),
                      ),
                      const Text('Orders')
                    ],
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Ink(
                        height: 70,
                        decoration: ShapeDecoration(
                          color: const Color(0xFFEAEAEA).withOpacity(0.5),
                          shape: const CircleBorder(),
                        ),
                        child: IconButton(
                          onPressed: () async {
                            try {
                              final result =
                                  await InternetAddress.lookup('example.com');
                              if (result.isNotEmpty &&
                                  result[0].rawAddress.isNotEmpty) {
                                Navigator.of(context).push(
                                    CustomRoutePageBuilder.createPageRouteLeft(
                                        context, const BrandPage()));
                                // Navigator.push(context, BrandPage.route());
                              }
                            } on SocketException catch (_) {
                              Common.toastMsg('No Internet Connection');
                            }
                          },
                          icon: FaIcon(
                            FontAwesomeIcons.bandAid,
                            size: 24,
                            color: Colors.primaries[4],
                          ),
                        ),
                      ),
                      const Text('Brands')
                    ],
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Ink(
                        height: 70,
                        decoration: ShapeDecoration(
                          color: const Color(0xFFEAEAEA).withOpacity(0.5),
                          shape: const CircleBorder(),
                        ),
                        child: IconButton(
                          onPressed: () async {
                            try {
                              final result =
                                  await InternetAddress.lookup('example.com');
                              if (result.isNotEmpty &&
                                  result[0].rawAddress.isNotEmpty) {
                                Navigator.of(context).push(
                                    CustomRoutePageBuilder.createPageRouteLeft(
                                        context, OffersPage()));
                              }
                            } on SocketException catch (_) {
                              Common.toastMsg('No Internet Connection');
                            }
                          },
                          icon: FaIcon(
                            FontAwesomeIcons.tags,
                            size: 24,
                            color: Colors.primaries[5],
                          ),
                        ),
                      ),
                      const Text('Offers')
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        /// ...............Coupon Product ...............
        StreamBuilder(
            stream: couponHomeBloc.allCouponHome,
            builder: (context, AsyncSnapshot<CouponHomeModel> snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!.data!.coupons!.isNotEmpty) {
                  return SliverToBoxAdapter(
                    child: HomeCouponProduct(
                      snapshot: snapshot,
                    ),
                  );
                } else {
                  return const SliverToBoxAdapter(
                    child: SizedBox(
                      height: 0,
                    ),
                  );
                }
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Center(
                    child: Text(snapshot.error.toString()),
                  ),
                );
              }
              return const SliverToBoxAdapter(
                child: Center(
                  child: ShimmerEffectHorizontal(),
                ),
              );
            }),
        /// ...............New Arrival Product ...............
        SliverToBoxAdapter(
          child: StreamBuilder(
            stream: newProductBloc.allNewProduct,
            builder: (context, AsyncSnapshot<NewArrivalItemModel> snapshot) {
              if (snapshot.hasData) {
                return HomeProduct("New Arrival", snapshot);
              } else if (snapshot.hasError) {
                return Center(
                  child: Text(snapshot.error.toString()),
                );
              }
              return const Center(
                child: ShimmerEffectHorizontal(),
              );
            },
          ),
        ),
        /// ................. Offer Product .......................
        StreamBuilder(
            stream: offerBloc.allOffer,
            builder: (context, AsyncSnapshot<OfferModel> snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!.data!.isNotEmpty) {
                  for (var i = 0; i < snapshot.data!.data!.length; i++) {
                    offerModel.data!.add(snapshot.data!.data![i]);
                  }
                  return SliverToBoxAdapter(
                    child: HomeOfferProductBar(
                      snapshot: offerModel,
                    ),
                  );
                }
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Center(
                    child: Text(snapshot.error.toString()),
                  ),
                );
              }
              return const SliverToBoxAdapter(
                child: Center(
                  child: ShimmerEffectHorizontal(),
                ),
              );
            }),
        /// ..............Best Sell Product ..............
        StreamBuilder(
            stream: bestSellBloc.allBestSellProduct,
            builder: (context, AsyncSnapshot<BestSellModel> snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!.data!.isNotEmpty) {
                  for (var i = 0; i < snapshot.data!.data!.length; i++) {
                    bestSellModel.data!.add(snapshot.data!.data![i]);
                  }
                  return SliverToBoxAdapter(
                    child: BestSellProductBar(
                      snapshot: bestSellModel,
                    ),
                  );
                }
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Center(
                    child: Text(snapshot.error.toString()),
                  ),
                );
              }
              return const SliverToBoxAdapter(
                child: Center(
                  child: ShimmerEffectHorizontal(),
                ),
              );
            }),
        /// category products ...........
        /// ...... Fashion and Accessories ........
        StreamBuilder(
            stream: secondCategoryProductBloc.allSecondCategoryProduct,
            builder: (context, AsyncSnapshot<CategoryProduct> snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!.data!.isNotEmpty) {
                  return SliverToBoxAdapter(
                    child: CategoryProductBar(
                        snapshot, "Fashion & Accessories", '2'),
                  );
                } else {
                  return const SliverToBoxAdapter(
                    child: Text(''),
                  );
                }
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Text(snapshot.error.toString()),
                );
              }
              return const SliverToBoxAdapter(
                child: Text(''),
              );
            }),

        /// ...... Home and Kitchen ........
        StreamBuilder(
            stream: thirdCategoryProductBloc.allThirdCategoryProduct,
            builder: (context, AsyncSnapshot<CategoryProduct> snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!.data!.isNotEmpty) {
                  return SliverToBoxAdapter(
                    child: CategoryProductBar(snapshot, "Home & Kitchen", '1'),
                  );
                } else {
                  return const SliverToBoxAdapter(
                    child: Text(''),
                  );
                }
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Text(snapshot.error.toString()),
                );
              }
              return const SliverToBoxAdapter(
                child: ShimmerEffectHorizontal(),
              );
            }),

        /// ...... Baby ........
        StreamBuilder(
            stream: firstCategoryProductBloc.allFirstCategoryProduct,
            builder: (context, AsyncSnapshot<CategoryProduct> snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!.data!.isNotEmpty) {
                  return SliverToBoxAdapter(
                    child: CategoryProductBar(snapshot, "Clothing ", "5"),
                  );
                } else {
                  return const SliverToBoxAdapter(
                    child: Text(''),
                  );
                }
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Text(snapshot.error.toString()),
                );
              }
              return const SliverToBoxAdapter(
                child: ShimmerEffectHorizontal(),
              );
            }),

        /// category products ...........

        /// ..............Feature Product ..............
        StreamBuilder(
            stream: featureBloc.allFeatures,
            builder: (context, AsyncSnapshot<FeatureModel> snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!.data!.isNotEmpty) {
                  for (var i = 0; i < snapshot.data!.data!.length; i++) {
                    featureModel.data!.add(snapshot.data!.data![i]);
                  }
                  return SliverToBoxAdapter(
                    child: FeatureProductBar(
                      snapshot: featureModel,
                    ),
                  );
                }
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Center(
                    child: Text(snapshot.error.toString()),
                  ),
                );
              }
              return const SliverToBoxAdapter(
                child: Center(
                  child: ShimmerEffectHorizontal(),
                ),
              );
            }),

        /// ............ All Category List ........
        SliverToBoxAdapter(
          child: SizedBox(
            width: double.infinity,
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Padding(
                  padding:
                      EdgeInsets.symmetric(vertical: 8, horizontal: 20),
                  child: Text(
                    'Shop By Category',
                    textAlign: TextAlign.start,
                    style: TextStyle(
                        color: Colors.black87,
                        fontSize: 16,
                        fontWeight: FontWeight.w600),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    try {
                      final result =
                          await InternetAddress.lookup('example.com');
                      if (result.isNotEmpty &&
                          result[0].rawAddress.isNotEmpty) {
                        Navigator.of(context).push(
                            CustomRoutePageBuilder.createPageRouteLeft(
                                context, const AllCategoryPage()));
                        // Navigator.push(context, AllCategoryPage.route());
                      }
                    } on SocketException catch (_) {
                      Common.toastMsg('No Internet Connection');
                    }
                  },
                  child: Text(
                    'See All',
                    style:
                        TextStyle(color: AppsColors.buttonColor, fontSize: 14),
                  ),
                )
              ],
            ),
          ),
        ),
        StreamBuilder(
          stream: categoryBloc.allCategory,
          builder: (context, AsyncSnapshot<Category2> snapshot) {
            if (snapshot.hasData) {
              return SliverToBoxAdapter(
                child: SizedBox(
                  height: 120,
                  width: double.infinity,
                  child: Row(
                    children: [
                      Expanded(
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              ...List.generate(snapshot.data!.data!.length,
                                  (index) {
                                return GestureDetector(
                                  onTap: () async {
                                    try {
                                      final result = await InternetAddress.lookup(
                                          'example.com');
                                      if (result.isNotEmpty &&
                                          result[0].rawAddress.isNotEmpty) {
                                        CategoryEPage.catPk = snapshot
                                            .data!.data![index].categoryId
                                            .toString();
                                        CategoryEPage.subCatPk = '';
                                        Navigator.of(context).push(
                                            CustomRoutePageBuilder
                                                .createPageRouteLeft(
                                                    context, const CategoryEPage()));
                                      }
                                    } on SocketException catch (_) {
                                      Common.toastMsg('No Internet Connection');
                                    }
                                  },
                                  child: Container(
                                    height: 120,
                                    width: 110,
                                    margin: const EdgeInsets.only(right: 12),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(10.0)),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          flex: 2,
                                          child: Center(
                                            child: ClipRRect(
                                              borderRadius: const BorderRadius.only(
                                                topLeft: Radius.circular(10),
                                                topRight: Radius.circular(10),
                                                bottomLeft: Radius.circular(10),
                                                bottomRight: Radius.circular(10),
                                              ),
                                              child: Container(
                                                  padding: const EdgeInsets.symmetric(
                                                      vertical: 2, horizontal: 2),
                                                  child: ConstrainedBox(
                                                    constraints:
                                                    const BoxConstraints(
                                                            minHeight: 30,
                                                            maxHeight: 82),
                                                    child: snapshot
                                                                .data!
                                                                .data![index]
                                                                .thumbnail_path ==
                                                            null
                                                        ? const NoImageWidget(
                                                            text: 'No \nImage',
                                                          )
                                                        : CacheImageProvide(
                                                            url: snapshot
                                                                .data!
                                                                .data![index]
                                                                .thumbnail_path,
                                                          ),
                                                  )),
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 1,
                                          child: Center(
                                            child: SizedBox(
                                              child: Text(
                                                '${snapshot.data!.data![index].categoryName}',
                                                textAlign: TextAlign.center,
                                                style: const TextStyle(
                                                    color: Colors.black87,
                                                    fontSize: 12),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              })
                            ],
                          ))
                    ],
                  ),
                ),
              );
            } else if (snapshot.hasError) {
              return SliverToBoxAdapter(
                child: Center(
                  child: Text(snapshot.error.toString()),
                ),
              );
            }
            return const SliverToBoxAdapter(
              child: Center(
                child: Text(''),
              ),
            );
          },
        ),

        /// ............ All Brand List .............
        SliverToBoxAdapter(
          child: SizedBox(
            width: double.infinity,
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Padding(
                  padding:
                  EdgeInsets.symmetric(vertical: 8, horizontal: 20),
                  child: Text(
                    'Shop By Brand',
                    textAlign: TextAlign.start,
                    style: TextStyle(
                        color: Colors.black87,
                        fontSize: 16,
                        fontWeight: FontWeight.w600),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    try {
                      final result =
                          await InternetAddress.lookup('example.com');
                      if (result.isNotEmpty &&
                          result[0].rawAddress.isNotEmpty) {
                        Navigator.of(context).push(
                            CustomRoutePageBuilder.createPageRouteLeft(
                                context, const BrandPage()));
                        // Navigator.push(context, BrandPage.route());
                      }
                    } on SocketException catch (_) {
                      Common.toastMsg('No Internet Connection');
                    }
                  },
                  child: Text(
                    'See All',
                    style:
                        TextStyle(color: AppsColors.buttonColor, fontSize: 14),
                  ),
                )
              ],
            ),
          ),
        ),
        StreamBuilder(
          stream: brandBloc.allBrands,
          builder: (context, AsyncSnapshot<BrandModel> snapshot) {
            if (snapshot.hasData) {
              return SliverToBoxAdapter(
                child: SizedBox(
                  height: 120,
                  width: double.infinity,
                  child: Row(
                    children: [
                      Expanded(
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              ...List.generate(snapshot.data!.data!.length,
                                  (index) {
                                return GestureDetector(
                                  onTap: () async {
                                    try {
                                      final result = await InternetAddress.lookup(
                                          'example.com');
                                      if (result.isNotEmpty &&
                                          result[0].rawAddress.isNotEmpty) {
                                        context
                                            .read<BrandDetailsNotifier>()
                                            .changeCategoryName('All Product');
                                        brandProductBloc.page = 1;
                                        context
                                            .read<BrandDetailsNotifier>()
                                            .changeBtnClear(1);
                                        BrandDetailsPage.brandPk =
                                            snapshot.data!.data![index].pkno;
                                        Navigator.of(context).push(
                                            CustomRoutePageBuilder
                                                .createPageRouteLeft(
                                                    context, const BrandDetailsPage()));
                                      }
                                    } on SocketException catch (_) {
                                      Common.toastMsg('No Internet Connection');
                                    }
                                  },
                                  child: Container(
                                    height: 120,
                                    width: 110,
                                    margin: const EdgeInsets.only(right: 12),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(10.0)),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          flex: 2,
                                          child: Center(
                                            child: ClipRRect(
                                              borderRadius: const BorderRadius.only(
                                                topLeft: Radius.circular(10),
                                                topRight: Radius.circular(10),
                                                bottomLeft: Radius.circular(10),
                                                bottomRight: Radius.circular(10),
                                              ),
                                              child: Container(
                                                  padding: const EdgeInsets.symmetric(
                                                      vertical: 2, horizontal: 2),
                                                  child: ConstrainedBox(
                                                      constraints:
                                                      const BoxConstraints(
                                                              minHeight: 30,
                                                              maxHeight: 82),
                                                      child: snapshot
                                                                  .data!
                                                                  .data![index]
                                                                  .brandlogo ==
                                                              null
                                                          ? const NoImageWidget(
                                                              text: 'No \nImage',
                                                            )
                                                          : CacheImageProvide(
                                                              url: snapshot
                                                                  .data!
                                                                  .data![index]
                                                                  .brandlogo))),
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 1,
                                          child: Center(
                                            child: SizedBox(
                                              child: Text(
                                                '${snapshot.data!.data![index].name}',
                                                textAlign: TextAlign.center,
                                                style: const TextStyle(
                                                    color: Colors.black87,
                                                    fontSize: 12),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              })
                            ],
                          ))
                    ],
                  ),
                ),
              );
            } else if (snapshot.hasError) {
              return SliverToBoxAdapter(
                child: Center(
                  child: Text(snapshot.error.toString()),
                ),
              );
            }
            return const SliverToBoxAdapter(
              child: Center(
                child: Text(''),
              ),
            );
          },
        ),

        /// ........... Instagram Feed ..................
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 12,
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Instagram',
              textAlign: TextAlign.start,
              style: TextStyle(
                  fontSize: 20,
                  foreground: Paint()..shader = linearGradient,
                  fontWeight: FontWeight.w600),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 6,
          ),
        ),
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Fashion & Accessories',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 16,
                  fontWeight: FontWeight.w600),
            ),
          ),
        ),
        StreamBuilder(
            stream: instagramFeedBloc.allInstagramFeed,
            builder: (context, AsyncSnapshot<InstagramFeedModel> snapshot) {
              if (snapshot.hasData) {
                return SliverPadding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) {
                        return GestureDetector(
                          onTap: () {
                            Common.openInstagramApp(snapshot
                                .data!.data!.azuramart!.data![index].permalink!);
                          },
                          child: SizedBox(
                            width: double.infinity,
                            height: double.infinity,
                            child: snapshot.data!.data!.azuramart!.data![index]
                                        .mediaUrl ==
                                    null
                                ? const NoImageWidget(
                                    text: 'No Image',
                                  )
                                : OptimizedCacheImage(
                                    imageUrl: snapshot.data!.data!.azuramart!
                                        .data![index].mediaUrl!,
                                    imageBuilder: (context, imageProvider) =>
                                        Container(
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: imageProvider,
                                          fit: BoxFit.cover,
                                          // colorFilter: ColorFilter.mode(Colors.transparent, BlendMode.clear)
                                        ),
                                      ),
                                    ),
                                    placeholder: (context, url) => Center(
                                      child: SizedBox(
                                        height: 16,
                                        width: 16,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2.0,
                                          valueColor: AlwaysStoppedAnimation(
                                              AppsColors.buttonColor),
                                        ),
                                      ),
                                    ),
                                    errorWidget: (context, url, error) =>
                                        const Icon(Icons.error),
                                  ),
                          ),
                        );
                      },
                      childCount: snapshot.data!.data!.azuramart!.data!.length,
                    ),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: MediaQuery.of(context).orientation ==
                              Orientation.portrait
                          ? 2
                          : MediaQuery.of(context).size.width > 740
                              ? 4
                              : 3,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                    ),
                  ),
                );
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Center(
                    child: Text(snapshot.error.toString()),
                  ),
                );
              }
              return const SliverToBoxAdapter(
                child: Center(
                  child: Text(''),
                ),
              );
            }),
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Home & Kitchen',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 16,
                  fontWeight: FontWeight.w600),
            ),
          ),
        ),
        StreamBuilder(
            stream: instagramFeedBloc.allInstagramFeed,
            builder: (context, AsyncSnapshot<InstagramFeedModel> snapshot) {
              if (snapshot.hasData) {
                return SliverPadding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) {
                        return GestureDetector(
                          onTap: () {
                            Common.openInstagramApp(snapshot
                                .data!.data!.azuramartHome!.data![index].permalink!);
                          },
                          child: SizedBox(
                            width: double.infinity,
                            height: double.infinity,
                            child: snapshot.data!.data!.azuramartHome!.data![index]
                                        .mediaUrl ==
                                    null
                                ? const NoImageWidget(
                                    text: 'No Image',
                                  )
                                : OptimizedCacheImage(
                                    imageUrl: snapshot.data!.data!.azuramartHome!
                                        .data![index].mediaUrl!,
                                    imageBuilder: (context, imageProvider) =>
                                        Container(
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: imageProvider,
                                          fit: BoxFit.cover,
                                          // colorFilter: ColorFilter.mode(Colors.transparent, BlendMode.clear)
                                        ),
                                      ),
                                    ),
                                    placeholder: (context, url) => Center(
                                      child: SizedBox(
                                        height: 16,
                                        width: 16,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2.0,
                                          valueColor: AlwaysStoppedAnimation(
                                              AppsColors.buttonColor),
                                        ),
                                      ),
                                    ),
                                    errorWidget: (context, url, error) =>
                                        const Icon(Icons.error),
                                  ),
                          ),
                        );
                      },
                      childCount: snapshot.data!.data!.azuramartHome!.data!.length,
                    ),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: MediaQuery.of(context).orientation ==
                              Orientation.portrait
                          ? 2
                          : MediaQuery.of(context).size.width > 740
                              ? 4
                              : 3,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                    ),
                  ),
                );
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Center(
                    child: Text(snapshot.error.toString()),
                  ),
                );
              }
              return const SliverToBoxAdapter(
                child: Center(
                  child: Text(''),
                ),
              );
            }),
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Customer Reviews',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 16,
                  fontWeight: FontWeight.w600),
            ),
          ),
        ),
        StreamBuilder(
            stream: instagramFeedBloc.allInstagramFeed,
            builder: (context, AsyncSnapshot<InstagramFeedModel> snapshot) {
              if (snapshot.hasData) {
                return SliverPadding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) {
                        return GestureDetector(
                          onTap: () {
                            Common.openInstagramApp(snapshot.data!.data!
                                .azuramartReview!.data![index].permalink!);
                          },
                          child: SizedBox(
                            width: double.infinity,
                            height: double.infinity,
                            child: snapshot.data!.data!.azuramartReview!
                                        .data![index].mediaUrl ==
                                    null
                                ? const NoImageWidget(
                                    text: 'No Image',
                                  )
                                : OptimizedCacheImage(
                                    imageUrl: snapshot.data!.data!.azuramartReview!
                                        .data![index].mediaUrl!,
                                    imageBuilder: (context, imageProvider) =>
                                        Container(
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: imageProvider,
                                          fit: BoxFit.cover,
                                          // colorFilter: ColorFilter.mode(Colors.transparent, BlendMode.clear)
                                        ),
                                      ),
                                    ),
                                    placeholder: (context, url) => Center(
                                      child: SizedBox(
                                        height: 16,
                                        width: 16,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2.0,
                                          valueColor: AlwaysStoppedAnimation(
                                              AppsColors.buttonColor),
                                        ),
                                      ),
                                    ),
                                    errorWidget: (context, url, error) =>
                                    const Icon(Icons.error),
                                  ),
                          ),
                        );
                      },
                      childCount:
                          snapshot.data!.data!.azuramartReview!.data!.length,
                    ),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: MediaQuery.of(context).orientation ==
                              Orientation.portrait
                          ? 2
                          : MediaQuery.of(context).size.width > 740
                              ? 4
                              : 3,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                    ),
                  ),
                );
              } else if (snapshot.hasError) {
                return SliverToBoxAdapter(
                  child: Center(
                    child: Text(snapshot.error.toString()),
                  ),
                );
              }
              return const SliverToBoxAdapter(
                child: Center(
                  child: Text(''),
                ),
              );
            }),

        /// ............ Footer-Top .................
        SliverToBoxAdapter(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: const BoxDecoration(
                  color: Colors.white,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Icon(Icons.refresh_outlined,color: Colors.orange,size: 40,),
                    const FaIcon(
                      FontAwesomeIcons.undoAlt,
                      color: Colors.orange,
                      size: 24,
                    ),
                    const SizedBox(
                      height: 12,
                    ),
                    const SizedBox(
                      width: double.infinity,
                      child: Text(
                        'Return and Refund Policy',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black87,
                            fontWeight: FontWeight.w600,
                            fontSize: 16),
                      ),
                    ),
                    TextButton(
                        onPressed: () async {
                          try {
                            final result =
                                await InternetAddress.lookup('example.com');
                            if (result.isNotEmpty &&
                                result[0].rawAddress.isNotEmpty) {
                              Urls.PAGE = 'page/return-and-refund-policy';
                              Navigator.push(context, AboutUs.route());
                            }
                          } on SocketException catch (_) {
                            Common.toastMsg('No internet Connection');
                            return;
                          }
                        },
                        child: const Text('Read More',
                            style: TextStyle(
                                color: Colors.lightBlueAccent,
                                fontWeight: FontWeight.w500,
                                fontSize: 14)))
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: const BoxDecoration(
                  color: Colors.white,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const FaIcon(
                      FontAwesomeIcons.cogs,
                      color: Colors.orange,
                      size: 24,
                    ),
                    const SizedBox(
                      height: 12,
                    ),
                    const SizedBox(
                      width: double.infinity,
                      child: Text(
                        'Terms and Conditions',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black87,
                            fontWeight: FontWeight.w600,
                            fontSize: 16),
                      ),
                    ),
                    TextButton(
                        onPressed: () async {
                          try {
                            final result =
                                await InternetAddress.lookup('example.com');
                            if (result.isNotEmpty &&
                                result[0].rawAddress.isNotEmpty) {
                              Urls.PAGE = 'page/terms-and-conditions';
                              Navigator.push(context, AboutUs.route());
                            }
                          } on SocketException catch (_) {
                            Common.toastMsg('No internet Connection');
                            return;
                          }
                        },
                        child: const Text('Read More',
                            style: TextStyle(
                                color: Colors.lightBlueAccent,
                                fontWeight: FontWeight.w500,
                                fontSize: 14)))
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: const BoxDecoration(
                  color: Colors.white,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const FaIcon(
                      FontAwesomeIcons.fighterJet,
                      color: Colors.orange,
                      size: 24,
                    ),
                    const SizedBox(
                      height: 12,
                    ),
                    const SizedBox(
                      width: double.infinity,
                      child: Text(
                        'Payment and Delivery',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black87,
                            fontWeight: FontWeight.w600,
                            fontSize: 16),
                      ),
                    ),
                    TextButton(
                        onPressed: () async {
                          try {
                            final result =
                                await InternetAddress.lookup('example.com');
                            if (result.isNotEmpty &&
                                result[0].rawAddress.isNotEmpty) {
                              Urls.PAGE = 'page/payment-and-delivery';
                              Navigator.push(context, AboutUs.route());
                            }
                          } on SocketException catch (_) {
                            Common.toastMsg('No internet Connection');
                            return;
                          }
                        },
                        child: const Text('Read More',
                            style: TextStyle(
                                color: Colors.lightBlueAccent,
                                fontWeight: FontWeight.w500,
                                fontSize: 14)))
                  ],
                ),
              ),
            ],
          ),
        ),

        /// ............... Footer-subscribe ...................
        SliverToBoxAdapter(
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: AppsColors.matteBlack,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(
                  width: double.infinity,
                  child: Text(
                    'Join our newsletter',
                    textAlign: TextAlign.start,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(
                  height: 8,
                ),
                const SizedBox(
                  width: double.infinity,
                  child: Text(AppsString.joiJourNewsLetterText,
                    textAlign: TextAlign.start,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                SizedBox(
                  // height: 48,
                  width: double.infinity,
                  child: Form(
                    key: _subscriptionFormKey,
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 4,
                          child: SizedBox(
                            // height: 48,
                            width: double.infinity,
                            child: TextFormField(
                              textAlign: TextAlign.start,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600),
                              controller: subscriptionEmailController,
                              validator: validationEmail,
                              textInputAction: TextInputAction.done,
                              maxLines: 1,
                              cursorColor: Colors.white,
                              onSaved: (String? val) {
                                subscriptionEmail = val;
                              },
                              decoration: InputDecoration(
                                // icon: Icon(Icons.vpn_key_outlined),
                                prefixIcon: const Icon(
                                  Icons.email_outlined,
                                  color: Colors.white54,
                                  size: 20,
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 16),
                                fillColor: const Color(0xFFD1D2D3).withOpacity(0.4),
                                filled: true,
                                hintText: 'Email',
                                hintStyle: const TextStyle(color: Colors.white54),
                                focusedBorder: InputBorder.none,
                                border: InputBorder.none,
                                enabledBorder: InputBorder.none,
                                errorBorder: InputBorder.none,
                                disabledBorder: InputBorder.none,
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                            flex: 1,
                            child: SizedBox(
                              height: 50,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(primary: Colors.orange,shape: const RoundedRectangleBorder()),
                                  onPressed: () async {
                                    if (_subscriptionFormKey.currentState!
                                        .validate()) {
                                      _subscriptionFormKey.currentState!.save();
                                      try {
                                        final result =
                                            await InternetAddress.lookup(
                                                'example.com');
                                        if (result.isNotEmpty &&
                                            result[0].rawAddress.isNotEmpty) {
                                          doSubscribe();
                                        }
                                      } on SocketException catch (_) {
                                        Common.toastMsg(
                                            'No Internet Connection');
                                      }
                                    }
                                  },
                                  child: const Icon(Icons.send)),
                            ))
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 8,
                ),
                const SizedBox(
                  width: double.infinity,
                  child: Text(
                    'By subscribing to our Newsletter, you agree to our Terms and Conditions*',
                    textAlign: TextAlign.start,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
        ),

        /// ............... Footer ................
        SliverToBoxAdapter(
          child: FutureBuilder(
            future: getPageList(),
            builder:
                (BuildContext context, AsyncSnapshot<PageListModel?> snapshot) {
              if (snapshot.hasData) {
                return Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 16),
                    decoration: BoxDecoration(
                      color: AppsColors.black.withOpacity(0.9),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              flex: 1,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8),
                                    child: const Text(
                                      'Pages',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 12,
                                  ),
                                  for (int i = 0;
                                  i < snapshot.data!.data!.length;
                                  i++)
                                    snapshot.data!.data![i].section == 1
                                        ? GestureDetector(
                                        onTap: () async {
                                          try {
                                            final result =
                                            await InternetAddress.lookup(
                                                'example.com');
                                            if (result.isNotEmpty &&
                                                result[0]
                                                    .rawAddress
                                                    .isNotEmpty) {
                                              Urls.PAGE = 'page/${snapshot.data!.data![i].urlslug}';
                                              Navigator.push(
                                                  context, AboutUs.route());
                                            }
                                          } on SocketException catch (_) {
                                            Common.toastMsg(
                                                'No internet Connection');
                                            return;
                                          }
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 4),
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8),
                                            child: Text(
                                              '${snapshot.data!.data![i].title}',
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 16,
                                                fontWeight: FontWeight.normal,
                                              ),
                                            ),
                                          ),
                                        )
                                    )
                                        : const SizedBox(
                                      height: 0,
                                    ),
                                ],
                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8),
                                    child: const Text(
                                      'Our Services',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 12,
                                  ),
                                  for (int i = 0;
                                  i < snapshot.data!.data!.length;
                                  i++)
                                    snapshot.data!.data![i].section == 2
                                        ? GestureDetector(
                                        onTap: () async {
                                          try {
                                            final result =
                                            await InternetAddress.lookup(
                                                'example.com');
                                            if (result.isNotEmpty &&
                                                result[0]
                                                    .rawAddress
                                                    .isNotEmpty) {
                                              Urls.PAGE = 'page/${snapshot.data!.data![i].urlslug}';
                                              Navigator.push(
                                                  context, AboutUs.route());
                                            }
                                          } on SocketException catch (_) {
                                            Common.toastMsg(
                                                'No internet Connection');
                                            return;
                                          }
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 4,horizontal: 8),
                                          child: Text(
                                            '${snapshot.data!.data![i].title}',
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 16,
                                              fontWeight: FontWeight.normal,
                                            ),
                                          ),
                                        ))
                                        : const SizedBox(
                                      height: 0,
                                    ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            IconButton(
                                onPressed: () {
                                  if (SharedPreferenceUtils.appSettingModel.data!.facebookurl !=
                                      null) {
                                    setState(() {
                                      Common.openFacebookApp(SharedPreferenceUtils
                                          .appSettingModel.data!.facebookurl!);
                                    });
                                  } else {
                                    Common.toastMsg('Url Not Found');
                                  }
                                },
                                icon: const FaIcon(
                                  FontAwesomeIcons.facebook,
                                  color: Colors.blueAccent,
                                )),
                            IconButton(
                                onPressed: () {
                                  if (SharedPreferenceUtils.appSettingModel.data!.instagramurl !=
                                      null) {
                                    setState(() {
                                      Common.openFacebookApp(SharedPreferenceUtils
                                          .appSettingModel.data!.instagramurl!);
                                    });
                                  } else {
                                    Common.toastMsg('Url Not Found');
                                  }
                                },
                                icon: const FaIcon(
                                  FontAwesomeIcons.instagram,
                                  color: Colors.deepOrangeAccent,
                                )),
                            IconButton(
                                onPressed: () {
                                  if (SharedPreferenceUtils.appSettingModel.data!.twitterurl !=
                                      null) {
                                    setState(() {
                                      Common.openFacebookApp(SharedPreferenceUtils
                                          .appSettingModel.data!.twitterurl!);
                                    });
                                  } else {
                                    Common.toastMsg('Url Not Found');
                                  }
                                },
                                icon: const FaIcon(
                                  FontAwesomeIcons.twitter,
                                  color: Colors.indigoAccent,
                                )),
                          ],
                        ),
                      ],
                    ),
                );
              } else if (snapshot.hasError) {
                return const SizedBox(
                  height: 0,
                );
              }
              return const SizedBox(
                height: 0,
              );
            },
          ),
        ),
        SliverToBoxAdapter(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
            decoration: BoxDecoration(
              color: AppsColors.matteBlack,
            ),
            child: Row(
              children: const [
                Expanded(
                  flex: 1,
                  child: Center(
                    child: Image(image: AssetImage('images/azura_logo_large.png'),color: Colors.white,height: 60,),
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Text('AzuraMart is a leading online store offering branded products and accessories at affordable prices. Rediscover a great shopping tradition and shop till you drop.',style: TextStyle(color: Colors.white),),
                ),
              ],
            ),
          ),
        )
      ],
    );
  }

  void checkUpdateAlert() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String appName = packageInfo.appName;
    String packageName = packageInfo.packageName;
    String version = packageInfo.version;
    String buildNumber = packageInfo.buildNumber;
    print(
        'app name $appName \npackage name $packageName \nversion $version \nbuild number $buildNumber');
    print('check-update');
    Uri url = Uri.parse(Urls.baseUrl + Urls.CHECK_UPDATE);
    Client client = Client();
    try {
      var response = await client.get(url);
      print('android version : $version');
      print('update response : ' + response.body);
      if (response.statusCode == 200) {
        final Map<String, dynamic>? body = await json.decode(response.body);
        CheckUpdateModel checkUpdateModel = CheckUpdateModel.fromJson(body!);
        if (checkUpdateModel.data!.androidVersion != buildNumber &&
            Platform.isAndroid) {
          showUpdateAlert(context, checkUpdateModel);
        } else if (checkUpdateModel.data!.iosVersion != buildNumber &&
            Platform.isIOS) {
          showUpdateAlert(context, checkUpdateModel);
        }
      } else {
        throw Exception('Failed to load post');
      }
    } on Exception catch (e) {
      print(e);
    }
  }

  void showUpdateAlert(
      BuildContext context, CheckUpdateModel checkUpdateModel) async {
    await Future.delayed(const Duration(seconds: 3));
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return WillPopScope(
              child: AlertDialog(
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                content: CustomScrollView(
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  slivers: [
                    SliverToBoxAdapter(
                      child: Container(
                        height: 115,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(6.0),
                                topRight: Radius.circular(6.0)),
                            gradient: LinearGradient(
                                colors: [
                                  const Color(0xFFF68721),
                                  const Color(0xFFF68721).withOpacity(0.7),
                                ],
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter)),
                        child: Stack(
                          children: [
                            Align(
                              alignment: Alignment.topCenter,
                              child: Icon(
                                Icons.star,
                                color: Colors.white.withOpacity(0.3),
                                size: 48,
                              ),
                            ),
                            const Align(
                              alignment: Alignment.center,
                              child: Text(
                                'UPDATE ALERT',
                                textAlign: TextAlign.start,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20),
                              ),
                            ),
                            Positioned(
                              bottom: 0,
                              right: 10,
                              child: Container(
                                height: 90,
                                width: 16,
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(20.0),
                                      topRight: Radius.circular(20.0)),
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 0,
                              left: 10,
                              child: Container(
                                height: 90,
                                width: 16,
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(20.0),
                                      topRight: Radius.circular(20.0)),
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 0,
                              right: 40,
                              child: Container(
                                height: 70,
                                width: 16,
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(20.0),
                                      topRight: Radius.circular(20.0)),
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 0,
                              left: 40,
                              child: Container(
                                height: 70,
                                width: 16,
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(20.0),
                                      topRight: Radius.circular(20.0)),
                                ),
                              ),
                            ),
                            Positioned(
                              top: 0,
                              left: 10,
                              child: Icon(
                                Icons.star,
                                color: Colors.white.withOpacity(0.2),
                                size: 24,
                              ),
                            ),
                            Positioned(
                              top: 0,
                              right: 10,
                              child: Icon(
                                Icons.star,
                                color: Colors.white.withOpacity(0.2),
                                size: 24,
                              ),
                            ),
                            Positioned(
                              bottom: -20,
                              left: -20,
                              child: Icon(
                                Icons.circle,
                                color: Colors.white.withOpacity(0.1),
                                size: 80,
                              ),
                            ),
                            Positioned(
                              bottom: -20,
                              right: -20,
                              child: Icon(
                                Icons.circle,
                                color: Colors.white.withOpacity(0.1),
                                size: 80,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SliverToBoxAdapter(
                      child: SizedBox(
                        height: 24,
                      ),
                    ),
                    SliverToBoxAdapter(
                        child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      width: double.infinity,
                      child: const Text(
                        'Hi! THERE',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black87,
                            fontWeight: FontWeight.w600,
                            fontSize: 18),
                      ),
                    )),
                    const SliverToBoxAdapter(
                      child: SizedBox(
                        height: 16,
                      ),
                    ),
                    SliverToBoxAdapter(
                        child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      width: double.infinity,
                      child: const Text(
                        'We improves speed and performance, etc',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black54, fontSize: 18),
                      ),
                    )),
                    const SliverToBoxAdapter(
                      child: SizedBox(
                        height: 16,
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: Container(
                        height: 1,
                        width: double.infinity,
                        color: Colors.grey.withOpacity(0.5),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Expanded(
                            flex: 1,
                            child: SizedBox(
                              height: 50,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  primary: Colors.white,
                                  elevation: 0,
                                ),
                                onPressed: () {
                                  if (checkUpdateModel.data!.isMandatory != 1) {
                                    Navigator.pop(context);
                                  } else {
                                    if (Platform.isAndroid) {
                                      Common.openPlayStore(
                                          checkUpdateModel.data!.playStoreLink!);
                                    } else if (Platform.isIOS) {
                                      Common.openPlayStore(
                                          checkUpdateModel.data!.appStoreLink!);
                                    }
                                  }
                                },
                                child: const Text(
                                  'ignore',
                                  style: TextStyle(color: Color(0xFFF68721)),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: SizedBox(
                              height: 50,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  primary: const Color(0xFFF68721),
                                  elevation: 0,
                                ),
                                onPressed: () {
                                  if (Platform.isAndroid) {
                                    Common.openPlayStore(
                                        checkUpdateModel.data!.playStoreLink!);
                                  } else if (Platform.isIOS) {
                                    Common.openPlayStore(
                                        checkUpdateModel.data!.appStoreLink!);
                                  }
                                },
                                child: const Text(
                                  'Update',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              onWillPop: () async {
                return checkUpdateModel.data!.isMandatory != 1;
              });
        });
  }
}

/// ................... Feature Product Bar ........................
class FeatureProductBar extends StatefulWidget {
  final FeatureModel? snapshot;
  const FeatureProductBar({Key? key, this.snapshot}) : super(key: key);

  @override
  _FeatureProductBarState createState() => _FeatureProductBarState();
}

class _FeatureProductBarState extends State<FeatureProductBar> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 3),
      padding: const EdgeInsets.symmetric(vertical: 0),
      decoration: const BoxDecoration(
        color: Colors.transparent,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 0, bottom: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: 45,
                      width: 6,
                      decoration: const BoxDecoration(
                          color: Colors.amber,
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(6.0),
                              topLeft: Radius.circular(6.0))),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    const Text(
                      'Feature Product',
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                const Spacer(),
                TextButton(
                    onPressed: () async {
                      try {
                        final result =
                            await InternetAddress.lookup('example.com');
                        if (result.isNotEmpty &&
                            result[0].rawAddress.isNotEmpty) {
                          Navigator.of(context).push(
                              CustomRoutePageBuilder.createPageRouteLeft(
                                  context, FeaturePage()));
                          // Navigator.push(context, FeaturePage.route());
                        }
                      } on SocketException catch (_) {
                        Common.toastMsg('No Internet Connection');
                      }
                    },
                    child: Text(
                      'See All',
                      style: TextStyle(color: AppsColors.buttonColor),
                    ))
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Expanded(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 220, minHeight: 16),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      ...List.generate(widget.snapshot!.data!.length, (index) {
                        return FeatureGridItem(widget.snapshot, index);
                      })
                    ],
                  ),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}

class FeatureGridItem extends StatefulWidget {
  final FeatureModel? snapshot;
  final int index;
  const FeatureGridItem(this.snapshot, this.index);
  @override
  _FeatureGridItemState createState() => _FeatureGridItemState();
}

class _FeatureGridItemState extends State<FeatureGridItem> {
  int isWish = 0;

  int toggleMsg = 0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ProductDetailsPage.productUrl =
                widget.snapshot!.data![widget.index].url;
            ProductDetailsPage.variantPk =
                widget.snapshot!.data![widget.index].pkno;
            ProductDetailsPage.isWish =
                widget.snapshot!.data![widget.index].isWish;
            Navigator.of(context).push(
                CustomRoutePageBuilder.createPageRouteLeft(
                    context, ProductDetailsPage()));
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: Container(
        //height: MediaQuery.of(context).size.width * 0.6,
        margin: const EdgeInsets.symmetric(horizontal: 8),
        width: MediaQuery.of(context).orientation == Orientation.portrait
            ? MediaQuery.of(context).size.width * 0.4
            : MediaQuery.of(context).size.height * 0.4,
        padding: const EdgeInsets.only(bottom: 8, right: 4, left: 4),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(6.0),
          // border:
          //     Border.all(color: Color(0xFFD0D1D2).withOpacity(0.3), width: 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              //height: MediaQuery.of(context).size.width * 0.4,
              width: MediaQuery.of(context).orientation == Orientation.portrait
                  ? MediaQuery.of(context).size.width * 0.4
                  : MediaQuery.of(context).size.height * 0.4,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                color: const Color(0xFFFFFFFF).withOpacity(0.2),
              ),
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Container(
                        padding:
                        const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
                        child: ConstrainedBox(
                          constraints:
                          const BoxConstraints(minHeight: 60, maxHeight: 120),
                          child: widget.snapshot!.data![widget.index]
                                      .thumbPath ==
                                  null
                              ? const NoImageWidget(
                                  text: 'No Image',
                                )
                              : CacheImageProvide(
                                  url: widget.snapshot!.data![widget.index]
                                      .thumbPath,
                                ),
                        )),
                  ),
                  // Align(
                  //   alignment: Alignment.topRight,
                  //   child: Material(
                  //     color: Colors.transparent,
                  //     child: Ink(
                  //       decoration: ShapeDecoration(
                  //         color: widget.snapshot.data[widget.index].isWish == 0
                  //             ? Color(0xFFF4F4F4).withOpacity(0.4)
                  //             : Color(0xFFF68721).withOpacity(0.1),
                  //         shape: CircleBorder(),
                  //       ),
                  //       child: IconButton(
                  //         onPressed: () async {
                  //           try {
                  //             final result =
                  //                 await InternetAddress.lookup('example.com');
                  //             if (result.isNotEmpty &&
                  //                 result[0].rawAddress.isNotEmpty) {
                  //               setState(() {
                  //                 widget.snapshot.data[widget.index].isWish =
                  //                     widget.snapshot.data[widget.index]
                  //                                 .isWish ==
                  //                             0
                  //                         ? 1
                  //                         : 0;
                  //                 AddToWish addWish = AddToWish();
                  //                 addWish.addToWish(
                  //                     widget.snapshot.data[widget.index].pkno);
                  //               });
                  //             }
                  //           } on SocketException catch (_) {
                  //             Common.toastMsg('No Internet Connection');
                  //           }
                  //         },
                  //         icon: widget.snapshot.data[widget.index].isWish == 0
                  //             ? Icon(
                  //                 Icons.favorite_outline,
                  //                 size: 16,
                  //                 color: Colors.black87,
                  //               )
                  //             : Icon(
                  //                 Icons.favorite,
                  //                 size: 16,
                  //                 color: Color(0xFFF68721),
                  //               ),
                  //       ),
                  //     ),
                  //   ),
                  // ),
                  LayoutBuilder(
                    builder:
                        (BuildContext context, BoxConstraints constraints) {
                      if (widget.snapshot!.data![widget.index].offer != 0) {
                        return GestureDetector(
                          onTap: () {
                            // setState(() {
                            //   toggleMsg = toggleMsg == 1 ? 0 : 1;
                            // });
                          },
                          child: Align(
                            alignment: Alignment.topLeft,
                            child: Container(
                              height: 45,
                              width: 45,
                              padding: const EdgeInsets.all(3.0),
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.red,
                              ),
                              child: const Center(
                                child: Text(
                                  'In \nOffer',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 12),
                                ),
                              ),
                            ),
                          ),
                        );
                      } else {
                        return const Align(
                          alignment: Alignment.topLeft,
                          child: SizedBox(
                            height: 2,
                          ),
                        );
                      }
                    },
                  ),
                ],
              ),
            ),

            /// ........................ price ...............
            SizedBox(
              // width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.only(left: 8, right: 8, bottom: 6),
                child: RichText(
                  text: TextSpan(
                    text: widget.snapshot!.data![widget.index].totalfreestock == 0
                        ? 'Out Of Stock'
                        : 'RM${widget.snapshot!.data![widget.index].regularprice!.toStringAsFixed(2)}',
                    style: TextStyle(
                        color: AppsColors.highlightedColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),

            /// ........................ variant name ...............
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                child: Text(
                  '${widget.snapshot!.data![widget.index].variantname}',
                  textAlign: TextAlign.center,
                  maxLines: 3,
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ................... Offers Product Bar ........................
class HomeOfferProductBar extends StatefulWidget {
  final OfferModel? snapshot;
  const HomeOfferProductBar({Key? key, this.snapshot}) : super(key: key);

  @override
  _HomeOfferProductBarState createState() => _HomeOfferProductBarState();
}

class _HomeOfferProductBarState extends State<HomeOfferProductBar> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 0),
      padding: const EdgeInsets.only(bottom: 0),
      decoration: const BoxDecoration(
        color: Colors.transparent,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            decoration: const BoxDecoration(
                // gradient: LinearGradient(
                //   colors: [
                //     Color(0xFFff5e62),
                //     Color(0xFFfc4a1a),
                //     Color(0xFF800080)
                //   ],
                //   tileMode: TileMode.clamp,
                //   begin: Alignment.topLeft,
                //   end: Alignment.bottomRight,
                // )
                ),
            padding: const EdgeInsets.only(left: 0, bottom: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: 45,
                      width: 6,
                      decoration: const BoxDecoration(
                          color: Colors.pink,
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(6.0),
                              topLeft: Radius.circular(6.0))),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    const Text(
                      'Offer',
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                const Spacer(),
                TextButton(
                    onPressed: () async {
                      try {
                        final result =
                            await InternetAddress.lookup('example.com');
                        if (result.isNotEmpty &&
                            result[0].rawAddress.isNotEmpty) {
                          Navigator.of(context).push(
                              CustomRoutePageBuilder.createPageRouteLeft(
                                  context, OffersPage()));
                          // Navigator.push(context, OffersPage.route());
                        }
                      } on SocketException catch (_) {
                        Common.toastMsg('No Internet Connection');
                      }
                    },
                    child: Text(
                      'See All',
                      style: TextStyle(color: AppsColors.buttonColor),
                    ))
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Expanded(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 220, minHeight: 16),
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    addRepaintBoundaries: true,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (BuildContext context, int index) {
                      return HomeOfferCard(
                        snapshot: widget.snapshot,
                        index: index,
                      );
                    },
                    itemCount: widget.snapshot!.data!.length,
                    separatorBuilder: (BuildContext context, int index) {
                      return const SizedBox(
                        width: 16,
                      );
                    },
                  ),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}

/// ................... Category Product Bar ........................
class CategoryProductBar extends StatefulWidget {
  final AsyncSnapshot<CategoryProduct> snapshot;
  final String categoryName;
  final String catId;
  const CategoryProductBar(this.snapshot, this.categoryName, this.catId);

  @override
  _CategoryProductBarState createState() => _CategoryProductBarState();
}

class _CategoryProductBarState extends State<CategoryProductBar> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 3),
      padding: const EdgeInsets.symmetric(vertical: 0),
      decoration: const BoxDecoration(
        color: Colors.transparent,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 0,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: 45,
                      width: 6,
                      decoration: const BoxDecoration(
                          color: Colors.deepOrange,
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(6.0),
                              topLeft: Radius.circular(6.0))),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Text(
                      widget.categoryName,
                      style: const TextStyle(
                          color: Colors.black87,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                const Spacer(),
                TextButton(
                    onPressed: () async {
                      try {
                        final result =
                            await InternetAddress.lookup('example.com');
                        if (result.isNotEmpty &&
                            result[0].rawAddress.isNotEmpty) {
                          CategoryEPage.catPk = widget.catId;
                          CategoryEPage.subCatPk = '';
                          Navigator.of(context).push(
                              CustomRoutePageBuilder.createPageRouteLeft(
                                  context, const CategoryEPage()));
                          // Navigator.push(context, CategoryEPage.route());
                        }
                      } on SocketException catch (_) {
                        Common.toastMsg('No Internet Connection');
                      }
                    },
                    child: Text(
                      'See All',
                      style: TextStyle(color: AppsColors.buttonColor),
                    ))
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Expanded(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 220, minHeight: 16),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      ...List.generate(widget.snapshot.data!.data!.length,
                          (index) => CategoryGridItem(widget.snapshot, index))
                    ],
                  ),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}

class CategoryGridItem extends StatefulWidget {
  final AsyncSnapshot<CategoryProduct> snapshot;
  final int index;
  const CategoryGridItem(this.snapshot, this.index);
  @override
  _CategoryGridItemState createState() => _CategoryGridItemState();
}

class _CategoryGridItemState extends State<CategoryGridItem> {
  int toggleMsg = 0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ProductDetailsPage.productUrl =
                widget.snapshot.data!.data![widget.index].url;
            ProductDetailsPage.variantPk =
                widget.snapshot.data!.data![widget.index].pkno;
            ProductDetailsPage.isWish =
                widget.snapshot.data!.data![widget.index].isWish;
            Navigator.of(context).push(
                CustomRoutePageBuilder.createPageRouteLeft(
                    context, ProductDetailsPage()));
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: Container(
        //height: MediaQuery.of(context).size.width * 0.6,
        margin: const EdgeInsets.symmetric(horizontal: 8),
        width: MediaQuery.of(context).orientation == Orientation.portrait
            ? MediaQuery.of(context).size.width * 0.4
            : MediaQuery.of(context).size.height * 0.4,
        padding: const EdgeInsets.only(bottom: 8, right: 4, left: 4),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(6.0),
          // border:
          //     Border.all(color: Color(0xFFD0D1D2).withOpacity(0.3), width: 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              child: Container(
                width:
                    MediaQuery.of(context).orientation == Orientation.portrait
                        ? MediaQuery.of(context).size.width * 0.4
                        : MediaQuery.of(context).size.height * 0.4,
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: const Color(0xFFFFFFFF).withOpacity(0.2),
                ),
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                          padding:
                          const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(
                                minHeight: 60, maxHeight: 120),
                            child: widget.snapshot.data!.data![widget.index]
                                        .thumbPath ==
                                    null
                                ? Center(
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 8),
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color: const Color(0xFFF4F4F4),
                                              width: 1)),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: const [
                                          Icon(
                                            Icons.camera_alt_outlined,
                                            size: 20,
                                          ),
                                          SizedBox(
                                            width: 8,
                                          ),
                                          Text(
                                            'No Image',
                                            style: TextStyle(
                                                color: Colors.black87,
                                                fontSize: 16,
                                                fontWeight: FontWeight.w800),
                                          )
                                        ],
                                      ),
                                    ),
                                  )
                                : CacheImageProvide(
                                    url: widget.snapshot.data!.data![widget.index]
                                        .thumbPath,
                                  ),
                          )),
                    ),
                    LayoutBuilder(
                      builder:
                          (BuildContext context, BoxConstraints constraints) {
                        if (widget.snapshot.data!.data![widget.index].offer !=
                            0) {
                          return GestureDetector(
                            onTap: () {
                              // setState(() {
                              //   toggleMsg = toggleMsg == 1 ? 0 : 1;
                              // });
                            },
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                height: 45,
                                width: 45,
                                padding: const EdgeInsets.all(3.0),
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.red,
                                ),
                                child: const Center(
                                  child: Text(
                                    'In \nOffer',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 12),
                                  ),
                                ),
                              ),
                            ),
                          );
                        } else {
                          return const Align(
                            alignment: Alignment.topLeft,
                            child: SizedBox(
                              height: 2,
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),

            /// ........................ price ...............
            SizedBox(
              // width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.only(left: 10, right: 10, bottom: 6),
                child: RichText(
                  text: TextSpan(
                    text: widget.snapshot.data!.data![widget.index]
                                .totalfreestock ==
                            0
                        ? 'Out Of Stock'
                        : 'RM${widget.snapshot.data!.data![widget.index].regularprice!.toStringAsFixed(2)}',
                    style: TextStyle(
                        color: AppsColors.highlightedColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w600),
                    // children: <TextSpan>[
                    //   TextSpan(
                    //     text:
                    //         '   RM${widget.snapshot.data.data[widget.index].insPrice}',
                    //     style: TextStyle(
                    //         color: Colors.black38,
                    //         fontSize: 10,
                    //         fontWeight: FontWeight.normal),
                    //   )
                    // ]
                  ),
                ),
              ),
            ),

            /// ........................ variant name ...............
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                child: Text(
                  '${widget.snapshot.data!.data![widget.index].variantname}',
                  textAlign: TextAlign.center,
                  maxLines: 3,
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class BestSellProductBar extends StatefulWidget {
  const BestSellProductBar({Key? key, this.snapshot}) : super(key: key);
  final BestSellModel? snapshot;

  @override
  _BestSellProductBarState createState() => _BestSellProductBarState();
}

class _BestSellProductBarState extends State<BestSellProductBar> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 3),
      // padding: const EdgeInsets.symmetric(vertical: 0),
      decoration: const BoxDecoration(
        color: Colors.transparent,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 0, bottom: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: 45,
                      width: 6,
                      decoration: const BoxDecoration(
                          color: Colors.blue,
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(6.0),
                              topLeft: Radius.circular(6.0))),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    const Text(
                      'Best Sellers',
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                const Spacer(),
                TextButton(
                    onPressed: () async {
                      try {
                        final result =
                            await InternetAddress.lookup('example.com');
                        if (result.isNotEmpty &&
                            result[0].rawAddress.isNotEmpty) {
                          Navigator.of(context).push(
                              CustomRoutePageBuilder.createPageRouteLeft(
                                  context, const BestSellPage()));
                          // Navigator.push(context, BestSellPage.route());
                        }
                      } on SocketException catch (_) {
                        Common.toastMsg('No Internet Connection');
                      }
                    },
                    child: Text(
                      'See All',
                      style: TextStyle(color: AppsColors.buttonColor),
                    ))
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Expanded(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 230, minHeight: 16),
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    addRepaintBoundaries: true,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (BuildContext context, int index) {
                      return BestSellProductCard(
                        snapshot: widget.snapshot,
                        index: index,
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) {
                      return const SizedBox(
                        width: 16,
                      );
                    },
                    itemCount: widget.snapshot!.data!.length,
                  ),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
