import 'dart:io';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/coupon/coupon_list_screen.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/coupon_home_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class HomeCouponProduct extends StatelessWidget {
  const HomeCouponProduct({Key? key,this.snapshot}) : super(key: key);
  final AsyncSnapshot<CouponHomeModel>? snapshot;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 3),
      decoration: const BoxDecoration(
        color: Colors.transparent
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 0, bottom: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: 45,
                      width: 6,
                      decoration: const BoxDecoration(
                          color: Colors.blue,
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(6.0),
                              topLeft: Radius.circular(6.0))),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Text(
                      '${snapshot!.data!.data!.title}',
                      style: const TextStyle(
                          color: Colors.black87,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                const Spacer(),
                TextButton(
                    onPressed: () async {
                      try {
                        final result =
                        await InternetAddress.lookup('example.com');
                        if (result.isNotEmpty &&
                            result[0].rawAddress.isNotEmpty) {
                          Navigator.of(context).push(
                              CustomRoutePageBuilder.createPageRouteLeft(
                                  context, const CouponListScreen()));
                          // Navigator.push(context, BestSellPage.route());
                        }
                      } on SocketException catch (_) {
                        Common.toastMsg('No Internet Connection');
                      }
                    },
                    child: Text(
                      'See All',
                      style: TextStyle(color: AppsColors.buttonColor),
                    ))
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Expanded(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 280, minHeight: 16),
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    addRepaintBoundaries: true,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (BuildContext context, int index) {
                      return CouponProductCard(
                        snapshot: snapshot,
                        index: index,
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) {
                      return const SizedBox(
                        width: 16,
                      );
                    },
                    itemCount: snapshot!.data!.data!.coupons!.length,
                  ),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}

class CouponProductCard extends StatelessWidget {
  const CouponProductCard({Key? key,this.snapshot,required this.index}) : super(key: key);
  final AsyncSnapshot<CouponHomeModel>? snapshot;
  final int index;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async{
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ProductDetailsPage.productUrl =
                snapshot!.data!.data!.coupons![index].urlSlug;
            ProductDetailsPage.variantPk =
                snapshot!.data!.data!.coupons![index].pkNo;
            ProductDetailsPage.isWish = 0;
            Navigator.of(context).push(
                CustomRoutePageBuilder
                    .createPageRouteLeft(
                    context, const ProductDetailsPage()));
            // Navigator.push(context, ProductDetailsPage.route());
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: Container(
          width: MediaQuery.of(context).orientation == Orientation.portrait
              ? MediaQuery.of(context).size.width * 0.4
              : MediaQuery.of(context).size.height * 0.4,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              color: Colors.white.withOpacity(0.7)
          ),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                flex: 2,
                child: CacheImageProvide(url: snapshot!.data!.data!.coupons![index].thumbPath),
              ),
              Expanded(
                flex: 3,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 8),
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.only(topLeft: Radius.circular(10),topRight: Radius.circular(10)),
                      // color: Color(0xffFEDBD0),
                      color: Colors.white

                  ),
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Positioned(
                        top: -24,
                        right: 0,
                        child: Container(

                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(snapshot!.data!.data!.coupons![index].couponType == 1 ?'-${snapshot!.data!.data!.coupons![index].discount!.toStringAsFixed(0)}%' : '-RM${snapshot!.data!.data!.coupons![index].discount!.toStringAsFixed(0)}',style: const TextStyle(color: Colors.white),),
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 8,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: Text('RM${(Common.getCouponAppliedPrice(snapshot!.data!.data!.coupons![index].regularPrice, snapshot!.data!.data!.coupons![index].discount!, snapshot!.data!.data!.coupons![index].couponType!)).toStringAsFixed(2)}',textAlign: TextAlign.start,style: const TextStyle(color: Colors.deepOrange,fontWeight: FontWeight.w600),),
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: Text(snapshot!.data!.data!.coupons![index].regularPrice!.toStringAsFixed(2),textAlign: TextAlign.start,style: const TextStyle(color: Colors.black54,fontWeight: FontWeight.w600,decoration: TextDecoration.lineThrough, ),),
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: Text('${snapshot!.data!.data!.coupons![index].variantName}',textAlign: TextAlign.start,style: const TextStyle(color: Colors.black87,fontWeight: FontWeight.w600,overflow: TextOverflow.ellipsis),maxLines: 3,),
                          ),
                          const SizedBox(
                            height: 4,
                          ),
                          const Spacer(),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton(
                              style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.deepOrange,width: 0.5),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6))),
                              onPressed: (){
                                Clipboard.setData( ClipboardData(text: "${snapshot!.data!.data!.coupons![index].couponCode}"));
                                Common.toastMsg('Copied to Clipboard');
                              },
                              child: Row(
                                children: const [
                                  FaIcon(FontAwesomeIcons.gift,size: 16,color: Colors.deepOrange,),
                                  SizedBox(
                                    width: 8,
                                  ),
                                  Text('Get Coupon',style: TextStyle(color: Colors.deepOrange),),
                                ],
                              ),
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                ),
              )
            ],
          )
      ),
    );
  }
}

