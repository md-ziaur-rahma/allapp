import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/about_us/aboutus_page.dart';
import 'package:azuramartmy/address_manager/address_manager_notifier.dart';
import 'package:azuramartmy/address_manager/address_manager_page.dart';
import 'package:azuramartmy/best_sell/best_sell_page.dart';
import 'package:azuramartmy/cart/cart_page.dart';
import 'package:azuramartmy/category_evaly/category_evaly_page.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/floating_action_button.dart';
import 'package:azuramartmy/contact_us/contact_us_page.dart';
import 'package:azuramartmy/coupon/coupon_list_screen.dart';
import 'package:azuramartmy/coupon/coupon_screen.dart';
import 'package:azuramartmy/home/home_body.dart';
import 'package:azuramartmy/login/login_page.dart';
import 'package:azuramartmy/my_account/account_page.dart';
import 'package:azuramartmy/my_bloc/best_sell_bloc.dart';
import 'package:azuramartmy/my_bloc/brand_bloc.dart';
import 'package:azuramartmy/my_bloc/category_bloc.dart';
import 'package:azuramartmy/my_bloc/feature_bloc.dart';
import 'package:azuramartmy/my_bloc/first_cat_bloc.dart';
import 'package:azuramartmy/my_bloc/home_slider_bloc.dart';
import 'package:azuramartmy/my_bloc/instagram_feed_bloc.dart';
import 'package:azuramartmy/my_bloc/new_arrival_product_bloc.dart';
import 'package:azuramartmy/my_bloc/offers_bloc.dart';
import 'package:azuramartmy/my_bloc/second_cat_bloc.dart';
import 'package:azuramartmy/my_bloc/third_cat_bloc.dart';
import 'package:azuramartmy/my_bloc/whatsapp_bloc.dart';
import 'package:azuramartmy/newest_screen/newest_page.dart';
import 'package:azuramartmy/offers/offers_page.dart';
import 'package:azuramartmy/order/order_page.dart';
import 'package:azuramartmy/provider_models/app_setting_model.dart';
import 'package:azuramartmy/provider_models/page_list_model.dart';
import 'package:azuramartmy/provider_models/whatsapp_model.dart';
import 'package:azuramartmy/search/search_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:azuramartmy/wishlist/wishlist_page.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' show Client;
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:upgrader/upgrader.dart';
import 'package:uuid/uuid.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const HomePage());
  }

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    pageList();
    getAppSettingData();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<PageListModel?> pageList() async {
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.PAGE_LIST);
      var response = await client.post(url, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      final Map<String, dynamic> body = await json.decode(response.body);
      PageListModel pageListModel = PageListModel.fromJson(body);
      SharedPreferenceUtils.pageListModel = pageListModel;
      return pageListModel;
    } on FormatException catch (e) {
      print(e);
    }
    return null;
  }

  Future<AppSettingModel?> getAppSettingData() async {
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.appSetting);
      var response = await client.get(url, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      final Map<String, dynamic> body = await json.decode(response.body);
      AppSettingModel appSettingModel = AppSettingModel.fromJson(body);
      SharedPreferenceUtils.appSettingModel = appSettingModel;
      return appSettingModel;
    } on FormatException catch (e) {
      print(e);
    }
    return null;
  }

  void callApi() {
    categoryBloc.fetchAllCategory();
    homeSliderBloc.fetchAllHomeSliders();
    newProductBloc.fetchAllNewProduct();
    offerBloc.fetchAllOffer(1);
    bestSellBloc.page = 1;
    bestSellBloc.fetchAllBestSellProducts();
    secondCategoryProductBloc.fetchAllSecondCategoryProduct(
        'fashion-accessories', '', '');
    thirdCategoryProductBloc.fetchAllThirdCategoryProduct(
        'home-kitchen', '', '');
    firstCategoryProductBloc.fetchAllFirstCategoryProduct('clothing', "", "");
    featureBloc.fetchAllFeatures();
    brandBloc.fetchAllBrands();
    instagramFeedBloc.fetchAllInstagramFeed();
    // pageList();
    // getAppSettingData();
  }

  Future<void> reload() async {
    try {
      final result = await InternetAddress.lookup('example.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        bestSellBloc.page = 1;
        return callApi();
      }
    } on SocketException catch (_) {
      Common.toastMsg('No internet Connection');
      return;
    }
  }


  Future<bool> _onBackPressed(BuildContext context) async {
    return (await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Are you sure you want to close the app?',style: TextStyle(
            color: Colors.black87,
            fontSize: 18,
            fontWeight: FontWeight.w500),),
        actions: <Widget>[
          TextButton(
              onPressed: () {
                Navigator.of(context).pop(false);
              },
              child: const Text(
                'No',
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 18,
                    fontWeight: FontWeight.w600),
              )),
          TextButton(
              onPressed: () {
                Navigator.of(context).pop(true);
              },
              child: const Text(
                'Yes',
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 18,
                    fontWeight: FontWeight.w600),
              )),
        ],
      ),
    )) ??
        false;
  }

  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
  GlobalKey<RefreshIndicatorState>();

  final Shader linearGradient = LinearGradient(
    // colors: <Color>[Color(0xffDA44bb), Color(0xff8921aa)],
    colors: <Color>[
      AppsColors.buttonColor,
      AppsColors.buttonColor.withOpacity(0.5)
    ],
  ).createShader(const Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  @override
  Widget build(BuildContext context) {
    whatsappBloc.fetchAllWhatsapp();
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        centerTitle: false,
        title: Text(
          'Azura Mart',
          style: TextStyle(
              fontWeight: FontWeight.bold,
              foreground: Paint()..shader = linearGradient),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
        elevation: 0,
        backgroundColor: Colors.white,
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark :  const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
        actions: [
          IconButton(
              onPressed: () {
                Navigator.of(context).push(
                    CustomRoutePageBuilder.createPageRouteLeft(
                        context, const SearchPage()));
              },
              icon: const Icon(
                Icons.search,
                color: Colors.black,
              ))
        ],
        leading: IconButton(
          icon: const Image(
            image: AssetImage('images/menu.png'),
          ),
          onPressed: () {
            if (SharedPreferenceUtils.pageListModel.data!.isNotEmpty && SharedPreferenceUtils.categoryList.data!.isNotEmpty) {
              _scaffoldKey.currentState!.openDrawer();
            }
          }
        ),
      ),
      body: SafeArea(
        child: WillPopScope(
          onWillPop: () => _onBackPressed(context),
          child: RefreshIndicator(
            key: _refreshIndicatorKey,
            color: Colors.black87,
            onRefresh: reload,
            child: UpgradeAlert(
              upgrader: Upgrader(
                dialogStyle: Platform.isIOS ? UpgradeDialogStyle.cupertino : UpgradeDialogStyle.material,
              ),
                child: const HomePageBody()),

          ),
        ),
      ),
      bottomNavigationBar: const HomeBottomNavBar(
        isHome: 1,
      ),
      drawer: const Drawer(
        child: HomeDrawerView(),
      ),
      floatingActionButton: StreamBuilder(
        stream: whatsappBloc.allWhatsapp,
        builder: (context, AsyncSnapshot<WhatsappModel> snapshot) {
          if (snapshot.hasData) {
            return MyFloatingActionButton(
              snapshot: SharedPreferenceUtils.whatsappModel,
            );
          } else if (snapshot.hasError) {
            return const SizedBox(
              height: 8,
            );
          }
          return const SizedBox(
            height: 10,
          );
        },
      ),
    );
  }
}

class HomeBottomNavBar extends StatefulWidget {
  const HomeBottomNavBar({Key? key, this.isHome}) : super(key: key);
  final int? isHome;

  @override
  _HomeBottomNavBarState createState() => _HomeBottomNavBarState();
}

class _HomeBottomNavBarState extends State<HomeBottomNavBar> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 55,
      width: double.infinity,
      decoration: const BoxDecoration(
        color: Color(0xFFFFFFFF),
        borderRadius: BorderRadius.only(
            topRight: Radius.circular(0), topLeft: Radius.circular(0)),
        boxShadow: [
          BoxShadow(
            color: Colors.grey,
            offset: Offset(1.0, 0.0), //(x,y)
            blurRadius: 10.0,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Flexible(
            flex: 1,
            child: Center(
              child: Material(
                color: Colors.transparent,
                child: Ink(
                  decoration: ShapeDecoration(
                    color: const Color(0xFFF68721).withOpacity(0.1),
                    shape: const CircleBorder(),
                  ),
                  child: IconButton(
                    onPressed: () {
                      if (widget.isHome == 0) {
                        Navigator.pop(context);
                      }
                    },
                    icon: const Icon(
                      Icons.home_outlined,
                      size: 24,
                      color: Color(0xFFF68721),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Flexible(
            flex: 1,
            child: Center(
                child: Material(
              color: Colors.transparent,
              child: Ink(
                decoration: const ShapeDecoration(
                  color: Colors.white,
                  shape: CircleBorder(),
                ),
                child: IconButton(
                  onPressed: () async {
                    try {
                      final result =
                          await InternetAddress.lookup('example.com');
                      if (result.isNotEmpty &&
                          result[0].rawAddress.isNotEmpty) {
                        Navigator.of(context).push(
                            CustomRoutePageBuilder.createPageRoute(
                                context, WishListPage()));
                      }
                    } on SocketException catch (_) {
                      Common.toastMsg('No internet Connection');
                    }
                  },
                  icon: const Icon(
                    Icons.favorite_border_sharp,
                    size: 24,
                    color: Colors.black87,
                  ),
                ),
              ),
            )),
          ),
          Flexible(
            flex: 1,
            child: Center(
                child: Material(
              color: Colors.transparent,
              child: Ink(
                decoration: const ShapeDecoration(
                  color: Colors.white,
                  shape: CircleBorder(),
                ),
                child: IconButton(
                  onPressed: () async {
                    try {
                      final result =
                          await InternetAddress.lookup('example.com');
                      if (result.isNotEmpty &&
                          result[0].rawAddress.isNotEmpty) {
                        Navigator.of(context).push(
                            CustomRoutePageBuilder.createPageRoute(
                                context, CartPage()));
                      }
                    } on SocketException catch (_) {
                      Common.toastMsg('No internet Connection');
                    }
                  },
                  icon: const Icon(
                    Icons.shopping_cart_outlined,
                    size: 24,
                    color: Colors.black87,
                  ),
                ),
              ),
            )),
          ),
          Flexible(
            flex: 1,
            child: Center(
                child: Material(
              color: Colors.transparent,
              child: Ink(
                decoration: const ShapeDecoration(
                  color: Colors.white,
                  shape: CircleBorder(),
                ),
                child: IconButton(
                  onPressed: () {
                    if (SharedPreferenceUtils.userIdF == 0) {
                      Navigator.of(context).push(
                          CustomRoutePageBuilder.createPageRoute(
                              context, const LoginPage()));
                    } else {
                      Navigator.of(context).push(
                          CustomRoutePageBuilder.createPageRoute(
                              context, MyAccountPage()));
                    }
                  },
                  icon: const Icon(
                    Icons.person_outline_outlined,
                    size: 24,
                    color: Colors.black87,
                  ),
                ),
              ),
            )),
          ),
        ],
      ),
    );
  }
}

class HomeDrawerView extends StatefulWidget {
  const HomeDrawerView({Key? key}) : super(key: key);

  @override
  _HomeDrawerViewState createState() => _HomeDrawerViewState();
}

class _HomeDrawerViewState extends State<HomeDrawerView> {
  int? userId;
  String? email;
  String? userName;

  void getData() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    localStorage = await SharedPreferences.getInstance();
    userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    email = localStorage.getString(SharedPreferenceUtils.EMAIL);
  }

  @override
  void initState() {
    getData();
    super.initState();
  }

  void clear() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    localStorage.setString(SharedPreferenceUtils.SESSION, const Uuid().v4());
    localStorage.remove(SharedPreferenceUtils.USER_ID);
    localStorage.remove(SharedPreferenceUtils.TOKEN);
    localStorage.remove(SharedPreferenceUtils.EMAIL);
    SharedPreferenceUtils.userIdF = 0;
    SharedPreferenceUtils.emailF = '';
    SharedPreferenceUtils.mobileF = '';
    SharedPreferenceUtils.usernameF = '';
    SharedPreferenceUtils.lastNameF = '';
  }

  @override
  Widget build(BuildContext context) {
    // categoryBloc.fetchAllCategory();
    return ListView(
      scrollDirection: Axis.vertical,
      shrinkWrap: true,
      children: <Widget>[
        Align(
          alignment: Alignment.topLeft,
          child: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.close,
                size: 18,
                color: Colors.black,
              )),
        ),
        // CircleAvatar(
        //   radius: 45,
        //   backgroundColor: Colors.white,
        //   child: CircleAvatar(
        //     radius: 40,
        //     backgroundImage: AssetImage('images/user_icon.png'),
        //   ),
        // ),

        const SizedBox(
          width: 80,
          height: 80,
          child: Image(
            image: AssetImage('images/azura_logo_large.png'),
            width: 100,
          ),
        ),
        const SizedBox(
          height: 8,
        ),
        SizedBox(
          width: double.infinity,
          child: Text(
            SharedPreferenceUtils.usernameF == null
                ? ''
                : '${SharedPreferenceUtils.usernameF}',
            textAlign: TextAlign.center,
            style: const TextStyle(
                color: Colors.black87,
                fontSize: 16,
                fontWeight: FontWeight.w600),
          ),
        ),
        SizedBox(
          width: double.infinity,
          child: Text(
            SharedPreferenceUtils.mobileF == null
                ? ''
                : '${SharedPreferenceUtils.mobileF}',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.black87, fontSize: 16),
          ),
        ),
        const SizedBox(
          height: 10,
        ),

        /// ............. Common tile ................
        Container(
          height: 40,
          margin: const EdgeInsets.only(left: 16, right: 16),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              primary: Colors.transparent,
              onPrimary: const Color(0xFFF4F4F4),
              animationDuration: const Duration(seconds: 1),
              padding: const EdgeInsets.symmetric(horizontal: 2),
              elevation: 0,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: const [
                Icon(
                  Icons.home_outlined,
                  size: 16,
                  color: Colors.black54,
                ),
                SizedBox(
                  width: 16,
                ),
                Text(
                  'Home',
                  style: TextStyle(color: Colors.black87, fontSize: 14),
                ),
                Spacer(),
                Icon(
                  Icons.arrow_right_alt,
                  size: 16,
                  color: Colors.black87,
                ),
              ],
            ),
          ),
        ),
        LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
          if (SharedPreferenceUtils.userIdF != 0) {
            return const SizedBox(
              height: 1,
            );
          } else {
            return Container(
              height: 40,
              margin: const EdgeInsets.only(left: 16, right: 16),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: Colors.transparent,
                  onPrimary: const Color(0xFFF4F4F4),
                  animationDuration: const Duration(seconds: 1),
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  elevation: 0,
                ),
                onPressed: () async {
                  Navigator.pop(context);
                  try {
                    final result = await InternetAddress.lookup('example.com');
                    if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                      Navigator.push(context, WishListPage.route());
                    }
                  } on SocketException catch (_) {
                    Common.toastMsg('No internet Connection');
                    return;
                  }
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: const [
                    Icon(
                      Icons.favorite_outline,
                      size: 16,
                      color: Colors.black54,
                    ),
                    SizedBox(
                      width: 16,
                    ),
                    Text(
                      'Wishlist',
                      style: TextStyle(color: Colors.black87, fontSize: 14),
                    ),
                    Spacer(),
                    Icon(
                      Icons.arrow_right_alt,
                      size: 16,
                      color: Colors.black87,
                    ),
                  ],
                ),
              ),
            );
          }
        }),

        Container(
          height: 40,
          margin: const EdgeInsets.only(left: 16, right: 16),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              primary: Colors.transparent,
              onPrimary: const Color(0xFFF4F4F4),
              animationDuration: const Duration(seconds: 1),
              padding: const EdgeInsets.symmetric(horizontal: 2),
              elevation: 0,
            ),
            onPressed: () async {
              Navigator.pop(context);
              try {
                final result = await InternetAddress.lookup('example.com');
                if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                  Navigator.push(context, NewestPage.route());
                }
              } on SocketException catch (_) {
                Common.toastMsg('No internet Connection');
                return;
              }
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: const [
                Icon(
                  Icons.new_releases,
                  size: 16,
                  color: Colors.black54,
                ),
                SizedBox(
                  width: 16,
                ),
                Text(
                  'New Arrival',
                  style: TextStyle(color: Colors.black87, fontSize: 14),
                ),
                Spacer(),
                Icon(
                  Icons.arrow_right_alt,
                  size: 16,
                  color: Colors.black87,
                ),
              ],
            ),
          ),
        ),
        Container(
          height: 40,
          margin: const EdgeInsets.only(left: 16, right: 16),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              primary: Colors.transparent,
              onPrimary: const Color(0xFFF4F4F4),
              animationDuration: const Duration(seconds: 1),
              padding: const EdgeInsets.symmetric(horizontal: 2),
              elevation: 0,
            ),
            onPressed: () async {
              Navigator.pop(context);
              try {
                final result = await InternetAddress.lookup('example.com');
                if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                  Navigator.push(context, OffersPage.route());
                }
              } on SocketException catch (_) {
                Common.toastMsg('No internet Connection');
                return;
              }
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: const [
                Icon(
                  Icons.local_offer_outlined,
                  size: 16,
                  color: Colors.black54,
                ),
                SizedBox(
                  width: 16,
                ),
                Text(
                  'Offer',
                  style: TextStyle(color: Colors.black87, fontSize: 14),
                ),
                Spacer(),
                Icon(
                  Icons.arrow_right_alt,
                  size: 16,
                  color: Colors.black87,
                ),
              ],
            ),
          ),
        ),
        Container(
          height: 40,
          margin: const EdgeInsets.only(left: 16, right: 16),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              primary: Colors.transparent,
              onPrimary: const Color(0xFFF4F4F4),
              animationDuration: const Duration(seconds: 1),
              padding: const EdgeInsets.symmetric(horizontal: 2),
              elevation: 0,
            ),
            onPressed: () async {
              Navigator.pop(context);
              try {
                final result = await InternetAddress.lookup('example.com');
                if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                  Navigator.push(context, CouponListScreen.route());
                }
              } on SocketException catch (_) {
                Common.toastMsg('No internet Connection');
                return;
              }
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: const [
                Icon(
                  Icons.local_offer_outlined,
                  size: 16,
                  color: Colors.black54,
                ),
                SizedBox(
                  width: 16,
                ),
                Text(
                  'Coupon',
                  style: TextStyle(color: Colors.black87, fontSize: 14),
                ),
                Spacer(),
                Icon(
                  Icons.arrow_right_alt,
                  size: 16,
                  color: Colors.black87,
                ),
              ],
            ),
          ),
        ),
        Container(
          height: 40,
          margin: const EdgeInsets.only(left: 16, right: 16),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              primary: Colors.transparent,
              onPrimary: const Color(0xFFF4F4F4),
              animationDuration: const Duration(seconds: 1),
              padding: const EdgeInsets.symmetric(horizontal: 2),
              elevation: 0,
            ),
            onPressed: () async {
              Navigator.pop(context);
              try {
                final result = await InternetAddress.lookup('example.com');
                if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                  Navigator.push(context, BestSellPage.route());
                }
              } on SocketException catch (_) {
                Common.toastMsg('No internet Connection');
                return;
              }
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: const [
                Icon(
                  Icons.new_releases,
                  size: 16,
                  color: Colors.black54,
                ),
                SizedBox(
                  width: 16,
                ),
                Text(
                  'Best Sellers',
                  style: TextStyle(color: Colors.black87, fontSize: 14),
                ),
                Spacer(),
                Icon(
                  Icons.arrow_right_alt,
                  size: 16,
                  color: Colors.black87,
                ),
              ],
            ),
          ),
        ),
        SizedBox(
          width: double.infinity,
          child: ExpandablePanel(
            header: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              height: 40,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.max,
                children: const [
                  FaIcon(
                    FontAwesomeIcons.shapes,
                    size: 16,
                    color: Colors.black54,
                  ),
                  SizedBox(
                    width: 16,
                  ),
                  Text(
                    'Categories',
                    style: TextStyle(color: Colors.black87, fontSize: 14),
                  ),
                ],
              ),
            ),
            expanded: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (int i = 0;
                    i < SharedPreferenceUtils.categoryList.data!.length;
                    i++)
                  Container(
                    height: 40,
                    margin: const EdgeInsets.only(left: 48, right: 16),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: Colors.transparent,
                        onPrimary: const Color(0xFFF4F4F4),
                        animationDuration: const Duration(seconds: 1),
                        padding: const EdgeInsets.symmetric(horizontal: 2),
                        elevation: 0,
                      ),
                      onPressed: () async {
                        try {
                          final result =
                              await InternetAddress.lookup('example.com');
                          if (result.isNotEmpty &&
                              result[0].rawAddress.isNotEmpty) {
                            CategoryEPage.catPk = SharedPreferenceUtils
                                .categoryList.data![i].categoryId
                                .toString();
                            CategoryEPage.subCatPk = '';
                            Navigator.of(context).push(
                                CustomRoutePageBuilder.createPageRoute(
                                    context, const CategoryEPage()));
                          }
                        } on SocketException catch (_) {
                          Common.toastMsg('No Internet Connection');
                        }
                      },
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          const Icon(
                            Icons.circle,
                            size: 12,
                            color: Colors.black54,
                          ),
                          const SizedBox(
                            width: 16,
                          ),
                          Text(
                            '${SharedPreferenceUtils.categoryList.data![i].categoryName}',
                            style:
                            const TextStyle(color: Colors.black87, fontSize: 14),
                          ),
                          const Spacer(),
                          const Icon(
                            Icons.arrow_right_alt,
                            size: 16,
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ), collapsed: const SizedBox(height: 0,),
          ),
        ),
        /// ..............log out/ login ...............
        LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
          if (SharedPreferenceUtils.userIdF == 0) {
            return Container(
              height: 40,
              margin: const EdgeInsets.only(left: 16, right: 16),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: Colors.transparent,
                  onPrimary: const Color(0xFFF4F4F4),
                  animationDuration: const Duration(seconds: 1),
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  elevation: 0,
                ),
                onPressed: () async {
                  Navigator.pop(context);
                  try {
                    final result = await InternetAddress.lookup('example.com');
                    if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                      Navigator.push(context, LoginPage.route());
                    }
                  } on SocketException catch (_) {
                    Common.toastMsg('No internet Connection');
                    return;
                  }
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: const [
                    Icon(
                      Icons.login,
                      size: 16,
                      color: Colors.black54,
                    ),
                    SizedBox(
                      width: 16,
                    ),
                    Text(
                      'Sign in',
                      style: TextStyle(color: Colors.black87, fontSize: 14),
                    ),
                    Spacer(),
                    Icon(
                      Icons.arrow_right_alt,
                      size: 16,
                      color: Colors.black54,
                    ),
                  ],
                ),
              ),
            );
          } else {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: double.infinity,
                  child: ExpandablePanel(
                    collapsed: const SizedBox(height: 0,),
                    header: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 16),
                      height: 40,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.max,
                        children: const [
                          Icon(
                            Icons.person_outline,
                            size: 16,
                            color: Colors.black54,
                          ),
                          SizedBox(
                            width: 16,
                          ),
                          Text(
                            'My Account',
                            style:
                                TextStyle(color: Colors.black87, fontSize: 14),
                          ),
                        ],
                      ),
                    ),
                    expanded: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ExpandablePanel(
                          collapsed: const SizedBox(height: 0,),
                          header: Container(
                            margin: const EdgeInsets.only(left: 32, right: 16),
                            height: 40,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisSize: MainAxisSize.max,
                              children: const [
                                Icon(
                                  Icons.person_outline,
                                  size: 16,
                                  color: Colors.black54,
                                ),
                                SizedBox(
                                  width: 16,
                                ),
                                Text(
                                  'My Details',
                                  style: TextStyle(
                                      color: Colors.black87, fontSize: 14),
                                ),
                              ],
                            ),
                          ),
                          expanded: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                height: 40,
                                margin:
                                    const EdgeInsets.only(left: 48, right: 16),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: Colors.transparent,
                                    onPrimary: const Color(0xFFF4F4F4),
                                    animationDuration: const Duration(seconds: 1),
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 2),
                                    elevation: 0,
                                  ),
                                  onPressed: () async {
                                    Navigator.pop(context);
                                    try {
                                      final result =
                                          await InternetAddress.lookup(
                                              'example.com');
                                      if (result.isNotEmpty &&
                                          result[0].rawAddress.isNotEmpty) {
                                        Navigator.push(
                                            context, MyAccountPage.route());
                                      }
                                    } on SocketException catch (_) {
                                      Common.toastMsg('No internet Connection');
                                      return;
                                    }
                                  },
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.max,
                                    children: const [
                                      Icon(
                                        Icons.contact_page_rounded,
                                        size: 16,
                                        color: Colors.black54,
                                      ),
                                      SizedBox(
                                        width: 16,
                                      ),
                                      Text(
                                        'Contact Details',
                                        style: TextStyle(
                                            color: Colors.black87,
                                            fontSize: 14),
                                      ),
                                      Spacer(),
                                      Icon(
                                        Icons.arrow_right_alt,
                                        size: 16,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                height: 40,
                                margin:
                                    const EdgeInsets.only(left: 48, right: 16),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: Colors.transparent,
                                    onPrimary: const Color(0xFFF4F4F4),
                                    animationDuration: const Duration(seconds: 1),
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 2),
                                    elevation: 0,
                                  ),
                                  onPressed: () async {
                                    Navigator.pop(context);
                                    try {
                                      final result =
                                          await InternetAddress.lookup(
                                              'example.com');
                                      if (result.isNotEmpty &&
                                          result[0].rawAddress.isNotEmpty) {
                                        Provider.of<AddressManagerNotifier>(context,listen: false).changeShippingGroupValue(0);
                                        Navigator.push(context,
                                            AddressManagerPage.route());
                                      }
                                    } on SocketException catch (_) {
                                      Common.toastMsg('No internet Connection');
                                      return;
                                    }
                                  },
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.max,
                                    children: const [
                                      Icon(
                                        Icons.book,
                                        size: 16,
                                        color: Colors.black54,
                                      ),
                                      SizedBox(
                                        width: 16,
                                      ),
                                      Text(
                                        'Address Book',
                                        style: TextStyle(
                                            color: Colors.black87,
                                            fontSize: 14),
                                      ),
                                      Spacer(),
                                      Icon(
                                        Icons.arrow_right_alt,
                                        size: 16,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                height: 40,
                                margin:
                                    const EdgeInsets.only(left: 48, right: 16),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: Colors.transparent,
                                    onPrimary: const Color(0xFFF4F4F4),
                                    animationDuration: const Duration(seconds: 1),
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 2),
                                    elevation: 0,
                                  ),
                                  onPressed: () async {
                                    Navigator.pop(context);
                                    try {
                                      final result =
                                          await InternetAddress.lookup(
                                              'example.com');
                                      if (result.isNotEmpty &&
                                          result[0].rawAddress.isNotEmpty) {
                                        // Navigator.push(context, MyAccountPage.route());
                                      }
                                    } on SocketException catch (_) {
                                      Common.toastMsg('No internet Connection');
                                      return;
                                    }
                                  },
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.max,
                                    children: const [
                                      Icon(
                                        Icons.info_outline_rounded,
                                        size: 16,
                                        color: Colors.black54,
                                      ),
                                      SizedBox(
                                        width: 16,
                                      ),
                                      Text(
                                        'Other account related info',
                                        style: TextStyle(
                                            color: Colors.black87,
                                            fontSize: 14),
                                      ),
                                      Spacer(),
                                      Icon(
                                        Icons.arrow_right_alt,
                                        size: 16,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 40,
                          margin: const EdgeInsets.only(left: 32, right: 16),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              primary: Colors.transparent,
                              onPrimary: const Color(0xFFF4F4F4),
                              animationDuration: const Duration(seconds: 1),
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 2),
                              elevation: 0,
                            ),
                            onPressed: () async {
                              Navigator.pop(context);
                              try {
                                final result =
                                    await InternetAddress.lookup('example.com');
                                if (result.isNotEmpty &&
                                    result[0].rawAddress.isNotEmpty) {
                                  Navigator.push(context, CartPage.route());
                                }
                              } on SocketException catch (_) {
                                Common.toastMsg('No internet Connection');
                                return;
                              }
                            },
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisSize: MainAxisSize.max,
                              children: const [
                                Icon(
                                  Icons.shopping_cart_outlined,
                                  size: 16,
                                  color: Colors.black54,
                                ),
                                SizedBox(
                                  width: 16,
                                ),
                                Text(
                                  'My Cart',
                                  style: TextStyle(
                                      color: Colors.black87, fontSize: 14),
                                ),
                                Spacer(),
                                Icon(
                                  Icons.arrow_right_alt,
                                  size: 16,
                                  color: Colors.black54,
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: 40,
                          margin: const EdgeInsets.only(left: 32, right: 16),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              primary: Colors.transparent,
                              onPrimary: const Color(0xFFF4F4F4),
                              animationDuration: const Duration(seconds: 1),
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 2),
                              elevation: 0,
                            ),
                            onPressed: () async {
                              Navigator.pop(context);
                              try {
                                final result =
                                    await InternetAddress.lookup('example.com');
                                if (result.isNotEmpty &&
                                    result[0].rawAddress.isNotEmpty) {
                                  Navigator.push(context, OrderPage.route());
                                }
                              } on SocketException catch (_) {
                                Common.toastMsg('No internet Connection');
                                return;
                              }
                            },
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisSize: MainAxisSize.max,
                              children: const [
                                Icon(
                                  Icons.bookmark_border_outlined,
                                  size: 16,
                                  color: Colors.black54,
                                ),
                                SizedBox(
                                  width: 16,
                                ),
                                Text(
                                  'My Orders',
                                  style: TextStyle(
                                      color: Colors.black87, fontSize: 14),
                                ),
                                Spacer(),
                                Icon(
                                  Icons.arrow_right_alt,
                                  size: 16,
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: 40,
                          margin: const EdgeInsets.only(left: 32, right: 16),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              primary: Colors.transparent,
                              onPrimary: const Color(0xFFF4F4F4),
                              animationDuration: const Duration(seconds: 1),
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 2),
                              elevation: 0,
                            ),
                            onPressed: () async {
                              Navigator.pop(context);
                              try {
                                final result =
                                    await InternetAddress.lookup('example.com');
                                if (result.isNotEmpty &&
                                    result[0].rawAddress.isNotEmpty) {
                                  Navigator.push(context, WishListPage.route());
                                }
                              } on SocketException catch (_) {
                                Common.toastMsg('No internet Connection');
                                return;
                              }
                            },
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisSize: MainAxisSize.max,
                              children: const [
                                Icon(
                                  Icons.favorite_border,
                                  size: 16,
                                  color: Colors.black54,
                                ),
                                SizedBox(
                                  width: 16,
                                ),
                                Text(
                                  'Wishlist',
                                  style: TextStyle(
                                      color: Colors.black87, fontSize: 14),
                                ),
                                Spacer(),
                                Icon(
                                  Icons.arrow_right_alt,
                                  size: 16,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          }
        }),
        LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
          if (SharedPreferenceUtils.userIdF == 0) {
            return const SizedBox(
              height: 0,
            );
          }else {
            return Container(
              height: 40,
              margin: const EdgeInsets.only(left: 16, right: 16),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: Colors.transparent,
                  onPrimary: const Color(0xFFF4F4F4),
                  animationDuration: const Duration(seconds: 1),
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  elevation: 0,
                ),
                onPressed: () async {
                  clear();
                  Navigator.pop(context);
                  Navigator.push(context, LoginPage.route());
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: const [
                    Icon(
                      Icons.logout,
                      size: 16,
                      color: Colors.black54,
                    ),
                    SizedBox(
                      width: 16,
                    ),
                    Text(
                      'Sign out',
                      style: TextStyle(color: Colors.black87, fontSize: 14),
                    ),
                    Spacer(),
                    Icon(
                      Icons.arrow_right_alt,
                      size: 16,
                      color: Colors.black54,
                    ),
                  ],
                ),
              ),
            );
          }
        }),

        const Divider(
          height: 10,
          thickness: 2,
        ),

        Container(
          height: 40,
          margin: const EdgeInsets.only(left: 16, right: 16),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              primary: Colors.transparent,
              onPrimary: const Color(0xFFF4F4F4),
              animationDuration: const Duration(seconds: 1),
              padding: const EdgeInsets.symmetric(horizontal: 2),
              elevation: 0,
            ),
            onPressed: () async {
              Navigator.pop(context);
              try {
                final result = await InternetAddress.lookup('example.com');
                if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                  Navigator.push(context, ContactUsPage.route());
                }
              } on SocketException catch (_) {
                Common.toastMsg('No internet Connection');
                return;
              }
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: const [
                Icon(
                  Icons.perm_contact_cal,
                  size: 16,
                  color: Colors.black54,
                ),
                SizedBox(
                  width: 16,
                ),
                Text(
                  'Contact Us',
                  style: TextStyle(color: Colors.black87, fontSize: 14),
                ),
                Spacer(),
                Icon(
                  Icons.arrow_right_alt,
                  size: 16,
                  color: Colors.black54,
                ),
              ],
            ),
          ),
        ),
        for (int i = 0;
            i < SharedPreferenceUtils.pageListModel.data!.length;
            i++)
          SharedPreferenceUtils.pageListModel.data![i].section == 1 ? Container(
            height: 40,
            margin: const EdgeInsets.only(left: 16, right: 16),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: Colors.transparent,
                onPrimary: const Color(0xFFF4F4F4),
                animationDuration: const Duration(seconds: 1),
                padding: const EdgeInsets.symmetric(horizontal: 2),
                elevation: 0,
              ),
              onPressed: () async {
                Navigator.pop(context);
                try {
                  final result = await InternetAddress.lookup('example.com');
                  if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                    Urls.PAGE =
                    'page/${SharedPreferenceUtils.pageListModel.data![i].urlslug}';
                    Navigator.push(context, AboutUs.route());
                  }
                } on SocketException catch (_) {
                  Common.toastMsg('No internet Connection');
                  return;
                }
              },
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.max,
                children: [
                  const Icon(
                    Icons.question_answer_outlined,
                    size: 16,
                    color: Colors.black54,
                  ),
                  const SizedBox(
                    width: 16,
                  ),
                  Text(
                    '${SharedPreferenceUtils.pageListModel.data![i].title}',
                    style: const TextStyle(color: Colors.black87, fontSize: 14),
                  ),
                  const Spacer(),
                  const Icon(
                    Icons.arrow_right_alt,
                    size: 16,
                  ),
                ],
              ),
            ),
          ) : const SizedBox(height: 0,),
        const SizedBox(
          height: 10,
        ),

        Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
                onPressed: () {
                  if (SharedPreferenceUtils.appSettingModel.data!.facebookurl !=
                      null) {
                    setState(() {
                      Common.openFacebookApp(SharedPreferenceUtils
                          .appSettingModel.data!.facebookurl!);
                    });
                  } else {
                    Common.toastMsg('Url Not Found');
                  }
                },
                icon: const FaIcon(
                  FontAwesomeIcons.facebook,
                  color: Colors.blueAccent,
                )),
            IconButton(
                onPressed: () {
                  if (SharedPreferenceUtils.appSettingModel.data!.instagramurl !=
                      null) {
                    setState(() {
                      Common.openFacebookApp(SharedPreferenceUtils
                          .appSettingModel.data!.instagramurl!);
                    });
                  } else {
                    Common.toastMsg('Url Not Found');
                  }
                },
                icon: const FaIcon(
                  FontAwesomeIcons.instagram,
                  color: Colors.deepOrangeAccent,
                )),
            IconButton(
                onPressed: () {
                  if (SharedPreferenceUtils.appSettingModel.data!.twitterurl !=
                      null) {
                    setState(() {
                      Common.openFacebookApp(SharedPreferenceUtils
                          .appSettingModel.data!.twitterurl!);
                    });
                  } else {
                    Common.toastMsg('Url Not Found');
                  }
                },
                icon: const FaIcon(
                  FontAwesomeIcons.twitter,
                  color: Colors.indigoAccent,
                )),
          ],
        ),

        const SizedBox(
          height: 30,
        ),
      ],
    );
  }
}
