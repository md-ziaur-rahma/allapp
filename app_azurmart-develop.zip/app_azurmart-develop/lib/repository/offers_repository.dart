import 'package:azuramartmy/api_provider/offers_provider.dart';
import 'package:azuramartmy/provider_models/offer_model.dart';

class OfferRepository{
  final offerProvider = OffersProvider();
  Future<OfferModel?> fetchOfferProducts(int page,int? limit) =>
      offerProvider.fetchOfferProduct(page,limit);
}