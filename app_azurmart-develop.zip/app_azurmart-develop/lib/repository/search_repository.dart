import 'package:azuramartmy/api_provider/search_provider.dart';
import 'package:azuramartmy/provider_models/search_models.dart';

class SearchRepository {
  final searchProvider = SearchProvider();
  Future<SearchModels?> fetchSearch(String? keyword,int page) =>
      searchProvider.fetchSearch(keyword,page);
}