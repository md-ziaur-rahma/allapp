import 'package:azuramartmy/api_provider/about_us_provider.dart';
import 'package:azuramartmy/provider_models/aboutus_model.dart';

class AboutUsRepository {
  final aboutUsProvider = AboutUsProvider();
  Future<AboutUsModel?> fetchAboutUs() =>
      aboutUsProvider.fetchAboutUs();
}