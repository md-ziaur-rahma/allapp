import 'package:azuramartmy/api_provider/wishlist_provider.dart';
import 'package:azuramartmy/provider_models/wish_list_model.dart';

class WishListRepository {
  final wishListProvider = WishListProvider();
  Future<WishListModel?> fetchWishLists() =>
      wishListProvider.fetchWishList();
}