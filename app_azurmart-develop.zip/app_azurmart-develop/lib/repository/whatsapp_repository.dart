import 'package:azuramartmy/api_provider/whatsapp_provider.dart';
import 'package:azuramartmy/provider_models/whatsapp_model.dart';

class WhatsappRepository {
  final whatsappProvider = WhatsappProvider();
  Future<WhatsappModel?> fetchWhatsapp() =>
      whatsappProvider.fetchAllWhatsapp();
}