import 'package:azuramartmy/api_provider/cart_provider.dart';
import 'package:azuramartmy/provider_models/cart_model.dart';

class CartRepository {
  final cartProvider = CartProvider();
  Future<CartModel?> fetchCarts() =>
      cartProvider.fetchCart();
}