import 'package:azuramartmy/api_provider/address_provider.dart';
import 'package:azuramartmy/provider_models/address_list_model.dart';

class AddressRepository {
  final allAddressProvider = AddressProvider();
  Future<AddressListModel?> fetchAllAddress() =>
      allAddressProvider.fetchAllAddress();
}