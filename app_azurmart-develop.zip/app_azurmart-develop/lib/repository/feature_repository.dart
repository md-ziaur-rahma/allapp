import 'package:azuramartmy/api_provider/feature_provider.dart';
import 'package:azuramartmy/provider_models/feature_model.dart';

class FeatureRepository{
  final featureProvider = FeatureProvider();
  Future<FeatureModel?> fetchFeatureProducts(int page) =>
      featureProvider.fetchFeatureProduct(page);
}