import 'package:azuramartmy/api_provider/blog_details_provider.dart';
import 'package:azuramartmy/provider_models/blog_details_model.dart';

class BlogDetailsRepository {
  final blogDetailsProvider = BlogDetailsProvider();
  Future<BlogDetailsModel?> fetchBlogDetails(String slug) =>
      blogDetailsProvider.fetchBlogDetails(slug);
}