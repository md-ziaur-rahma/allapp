import 'package:azuramartmy/api_provider/model_search_provider.dart';
import 'package:azuramartmy/provider_models/model_search_model.dart';

class ModelSearchRepository {
  final modelSearchProvider = ModelSearchProvider();
  Future<ModelSearchModel?> fetchModelSearch(String? keyword) =>
      modelSearchProvider.fetchModelSearch(keyword);
}