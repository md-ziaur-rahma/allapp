import 'package:azuramartmy/api_provider/category_product_provider.dart';
import 'package:azuramartmy/provider_models/category_product.dart';

class CategoryProductRepository {
  var categoryProductProvider = CategoryProductProvider();
  Future<CategoryProduct> fetchAllCategoryProducts(
          String cat, String? subCat, String? product, int page) =>
      categoryProductProvider.fetchCategoryProductList(
          cat, subCat, product, page);
}
