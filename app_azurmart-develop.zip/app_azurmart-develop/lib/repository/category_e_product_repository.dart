import 'package:azuramartmy/api_provider/category_evaly_provider.dart';
import 'package:azuramartmy/provider_models/category_evaly_product_model.dart';

class CategoryEProductsRepository {
  final brandProvider = CategoryEProductsProvider();
  Future<CategoryEProductModel?> fetchCategoryEProducts(String? catId,String? subCatID,int page) =>
      brandProvider.fetchCategoryProducts(catId, subCatID, page);
}