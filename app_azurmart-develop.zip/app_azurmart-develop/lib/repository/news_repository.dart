import 'package:azuramartmy/api_provider/news_provider.dart';
import 'package:azuramartmy/provider_models/news_model.dart';

class NewsRepository {
  final newsProvider = NewsProvider();
  Future<NewsModel?> fetchNews(int page) =>
      newsProvider.fetchNews(page);
}