import 'package:azuramartmy/api_provider/short_search_provider.dart';
import 'package:azuramartmy/provider_models/short_search_models.dart';

class ShortSearchRepository {
  final shortSearchProvider = ShortSearchProvider();
  Future<ShortSearchModels?> fetchShortSearch(String keyword) =>
      shortSearchProvider.fetchShortSearch(keyword);
}