import 'package:azuramartmy/api_provider/home_slider_provider.dart';
import 'package:azuramartmy/provider_models/home_slider_model.dart';

class HomeSliderRepository {
  final homeSliderApiProvider = HomeSliderProvider();
  Future<HomeSliderModel?> fetchHomeSliders() =>
      homeSliderApiProvider.fetchSliderList();
}
