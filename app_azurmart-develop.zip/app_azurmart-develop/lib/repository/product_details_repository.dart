import 'package:azuramartmy/api_provider/product_details_provider.dart';
import 'package:azuramartmy/provider_models/product_details_model.dart';

class ProductDetailsRepository {
  final productDetailsProvider = ProductDetailsProvider();
  Future<ProductDetailsModel?> fetchAllProductDetailsModel(String slug) =>
      productDetailsProvider.fetchProductDetails(slug);
}
