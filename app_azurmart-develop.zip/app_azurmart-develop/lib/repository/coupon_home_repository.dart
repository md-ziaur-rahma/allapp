import 'package:azuramartmy/api_provider/coupon_home_provider.dart';
import 'package:azuramartmy/provider_models/coupon_home_model.dart';

class CouponHomeRepository {
  final couponHomeProvider = CouponHomeProvider();
  Future<CouponHomeModel?> fetchCouponHome() =>
      couponHomeProvider.fetchCouponHome();
}