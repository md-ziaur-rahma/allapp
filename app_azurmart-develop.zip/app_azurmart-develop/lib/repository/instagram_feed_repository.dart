import 'package:azuramartmy/api_provider/instagram_feed_provider.dart';
import 'package:azuramartmy/provider_models/instagram_feed_model.dart';

class InstagramFeedRepository {
  final instagramFeedProvider = InstagramFeedProvider();
  Future<InstagramFeedModel?> fetchInstagramFeed() =>
      instagramFeedProvider.fetchInstagramFeed();
}