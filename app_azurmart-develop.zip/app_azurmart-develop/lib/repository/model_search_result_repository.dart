import 'package:azuramartmy/api_provider/model_search_result_provider.dart';
import 'package:azuramartmy/provider_models/model_search_result_model.dart';

class ModelSearchResultRepository {
  final modelSearchResultProvider = ModelSearchResultProvider();
  Future<ModelSearchResultModel?> fetchModelSearchResult(int? modelNo,int page) =>
      modelSearchResultProvider.fetchModelSearchResult(modelNo,page);
}