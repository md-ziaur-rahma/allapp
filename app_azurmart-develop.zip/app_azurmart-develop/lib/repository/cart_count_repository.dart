import 'package:azuramartmy/api_provider/cart_count_provider.dart';
import 'package:azuramartmy/provider_models/cart_count_model.dart';

class CartCountRepository {
  final cartCountProvider = CartCountProvider();
  Future<CartCountModel?> fetchCartCount() =>
      cartCountProvider.fetchCartCount();
}