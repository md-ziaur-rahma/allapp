import 'package:azuramartmy/api_provider/coupon_list_provider.dart';
import 'package:azuramartmy/provider_models/coupon_list_model.dart';

class CouponListRepository {
  final couponListProvider = CouponListProvider();
  Future<CouponListModel?> fetchCouponProduct() =>
      couponListProvider.fetchCouponList();
}