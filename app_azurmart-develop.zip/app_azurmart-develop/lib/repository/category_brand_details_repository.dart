import 'package:azuramartmy/api_provider/category_brand_details_provider.dart';
import 'package:azuramartmy/provider_models/category_brand_details_model.dart';

class CategoryBrandsDetailsRepository {
  final categoryBrandProvider = CategoryBrandDetailsProvider();
  Future<CategoryBrandDetailsModel?> fetchCategoryBrandDetails(String catId,String subCatID) =>
      categoryBrandProvider.fetchCategoriesBrands(catId, subCatID);
}