import 'package:azuramartmy/api_provider/new_arrival_product_api_provider.dart';
import 'package:azuramartmy/provider_models/new_arrival_item_model.dart';

class NewArrivalProductRepository{
  final newArrivalProductProvider = NewArrivalProductProvider();

  Future<NewArrivalItemModel?> fetchProduct(int page) => newArrivalProductProvider.fetchProduct(page);
}