import 'package:azuramartmy/api_provider/brand_details_provider.dart';
import 'package:azuramartmy/provider_models/brand_details_model.dart';

class BrandDetailsRepository {
  final brandDetailsProvider = BrandDetailsProvider();
  Future<BrandDetailsModel?> fetchBrandDetails(int? pkNo) =>
      brandDetailsProvider.fetchBrandDetails(pkNo);
}