import 'package:azuramartmy/api_provider/second_cat_provider.dart';
import 'package:azuramartmy/provider_models/category_product.dart';

class SecondCategoryProductRepository {
  var secondCategoryProductProvider = SecondCategoryProductProvider();
  Future<CategoryProduct> fetchAllSecondCategoryProducts(
      String cat,
      String subCat,
      String product,
      int page,
      ) =>
      secondCategoryProductProvider.fetchSecondCategoryProductList(cat, subCat, product,page);
}
