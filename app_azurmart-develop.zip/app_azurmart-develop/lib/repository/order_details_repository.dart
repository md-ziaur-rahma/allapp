import 'package:azuramartmy/api_provider/order_details_provider.dart';
import 'package:azuramartmy/provider_models/order_details_model.dart';

class OrderDetailsRepository {
  final orderDetailsProvider = OrderDetailsProvider();
  Future<OrderDetailsModel?> fetchOrderDetailsModel(int? orderId) =>
      orderDetailsProvider.fetchOrderDetails(orderId);
}
