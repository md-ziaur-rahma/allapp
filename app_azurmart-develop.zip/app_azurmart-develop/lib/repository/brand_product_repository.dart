import 'package:azuramartmy/api_provider/brand_product_provider.dart';
import 'package:azuramartmy/provider_models/brand_product_model.dart';

class BrandProductRepository {
  final brandProductProvider = BrandProductsProvider();
  Future<BrandProductModel?> fetchBrandProducts(int? brandPk, String categoryPk, int page) =>
      brandProductProvider.fetchBrandProduct(brandPk,categoryPk,page);
}