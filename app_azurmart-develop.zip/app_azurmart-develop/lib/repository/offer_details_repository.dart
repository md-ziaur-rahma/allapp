import 'package:azuramartmy/api_provider/offer_details_provider.dart';
import 'package:azuramartmy/provider_models/offer_details_model.dart';

class OfferDetailsRepository {
  final offerDetailsProvider = OfferDetailsProvider();
  Future<OfferDetailsModel?> fetchOfferDetails(String offerName) =>
      offerDetailsProvider.fetchOfferDetails(offerName);
}