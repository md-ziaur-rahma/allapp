import 'package:azuramartmy/api_provider/best_sell_provider.dart';
import 'package:azuramartmy/provider_models/best_sell_model.dart';

class BestSellRepository {
  final bestSellProvider = BestSellProvider();
  Future<BestSellModel?> fetchBestSellProduct(int page) =>
      bestSellProvider.fetchBestSellProduct(page);
}