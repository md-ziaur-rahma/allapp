import 'package:azuramartmy/api_provider/first_cat_provider.dart';
import 'package:azuramartmy/provider_models/category_product.dart';

class FirstCategoryProductRepository {
  var firstCategoryProductProvider = FirstCategoryProductProvider();
  Future<CategoryProduct?> fetchAllFirstCategoryProducts(
      String cat,
      String subCat,
      String product,
      int page,
      ) =>
      firstCategoryProductProvider.fetchFirstCategoryProductList(cat, subCat, product,page);
}
