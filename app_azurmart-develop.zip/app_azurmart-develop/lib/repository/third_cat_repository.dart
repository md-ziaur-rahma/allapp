import 'package:azuramartmy/api_provider/third_cat_provider.dart';
import 'package:azuramartmy/provider_models/category_product.dart';

class ThirdCategoryProductRepository {
  var thirdCategoryProductProvider = ThirdCategoryProductProvider();
  Future<CategoryProduct?> fetchAllThirdCategoryProducts(
      String cat,
      String subCat,
      String product,
      int page
      ) =>
      thirdCategoryProductProvider.fetchThirdCategoryProductList(cat, subCat, product,page);
}
