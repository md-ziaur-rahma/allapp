import 'package:azuramartmy/api_provider/cateogry_provider.dart';
import 'package:azuramartmy/provider_models/category2.dart';

class CategoryRepository {
  final categoryProvider = CategoryProvider();
  Future<Category2> fetchCategory() => categoryProvider.fetchCategoryList();
}
