import 'package:azuramartmy/api_provider/coupon_product_provider.dart';
import 'package:azuramartmy/provider_models/coupon_product_model.dart';

class CouponProductRepository {
  final couponProductProvider = CouponProductProvider();
  Future<CouponProductModel?> fetchCouponProduct(String? couponCode,int page) =>
      couponProductProvider.fetchCouponProduct(couponCode,page);
}