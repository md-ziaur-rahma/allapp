import 'package:azuramartmy/api_provider/all_brand_provider.dart';
import 'package:azuramartmy/provider_models/brand_model.dart';

class AllBrandRepository {
  final allBrandProvider = AllBrandProvider();
  Future<BrandModel?> fetchAllBrands() =>
      allBrandProvider.fetchAllBrand();
}