import 'package:azuramartmy/api_provider/orderlist_provider.dart';
import 'package:azuramartmy/provider_models/orderlist_model.dart';

class OrderListRepository {
  final orderListProvider = OrderListProvider();
  Future<OrderListModel?> fetchOrderList(int? groupId) =>
      orderListProvider.fetchOrderList(groupId);
}