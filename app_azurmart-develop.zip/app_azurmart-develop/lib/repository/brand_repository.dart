import 'package:azuramartmy/api_provider/brand_provider.dart';
import 'package:azuramartmy/provider_models/brand_model.dart';

class BrandRepository {
  final brandProvider = BrandProvider();
  Future<BrandModel?> fetchBrands() =>
      brandProvider.fetchBrand();
}