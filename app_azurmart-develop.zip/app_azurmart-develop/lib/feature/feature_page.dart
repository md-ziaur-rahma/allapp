import 'dart:io';

import 'package:azuramartmy/common_widgets/floating_action_button.dart';
import 'package:azuramartmy/feature/feature_body.dart';
import 'package:azuramartmy/home/home_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class FeaturePage extends StatefulWidget {
  const FeaturePage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const FeaturePage());
  }

  @override
  _FeaturePageState createState() => _FeaturePageState();
}

class _FeaturePageState extends State<FeaturePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Feature Products',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: AppsColors.buttonColor,

        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.light : SystemUiOverlayStyle(
            statusBarColor: AppsColors.buttonColor,
            statusBarIconBrightness: Brightness.light),
      ),
      body: const SafeArea(
        child: FeatureBody(),
      ),
      floatingActionButton: MyFloatingActionButton(snapshot: SharedPreferenceUtils.whatsappModel,),
      bottomNavigationBar: const HomeBottomNavBar(isHome: 0,),
    );
  }
}
