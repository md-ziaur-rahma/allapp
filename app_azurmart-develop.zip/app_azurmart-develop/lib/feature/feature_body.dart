import 'package:azuramartmy/common_notifier/common_notifier.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/home/home_body.dart';
import 'package:azuramartmy/my_bloc/feature_bloc.dart';
import 'package:azuramartmy/provider_models/feature_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';

class FeatureBody extends StatefulWidget {
  const FeatureBody({Key? key}) : super(key: key);

  @override
  _FeatureBodyState createState() => _FeatureBodyState();
}

class _FeatureBodyState extends State<FeatureBody> {
  FeatureModel featureModel = FeatureModel();
  bool canLoading = true;

  @override
  void initState() {
    featureModel.data = [];
    featureBloc.page = 1;
    canLoading = true;
    featureBloc.fetchAllFeatures();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return StreamBuilder(
        stream: featureBloc.allFeatures,
        builder: (context, AsyncSnapshot<FeatureModel> snapshot) {
          if (snapshot.hasData) {
            // context.read<CommonNotifier>().changeLoading(false);
            Provider.of<CommonNotifier>(context,listen: false).changeLoading(false);
            if (snapshot.data!.data!.isEmpty) {
              canLoading = false;
            }else {
              if (snapshot.data!.data!.length < 10) {
                canLoading = false;
              }
              for (var i = 0; i < snapshot.data!.data!.length; i++) {
                featureModel.data!.add(snapshot.data!.data![i]);
              }
            }
            return CustomScrollView(
              scrollDirection: Axis.vertical,
              slivers: [
                SliverToBoxAdapter(
                  child: Stack(
                    alignment: Alignment.topCenter,
                    children: [
                      Container(
                        height: 60,
                        decoration: BoxDecoration(
                            color: AppsColors.buttonColor,
                            borderRadius: const BorderRadius.only(
                                bottomLeft: Radius.circular(16.0),
                                bottomRight: Radius.circular(16.0))),
                      ),
                      Container(
                          height: 100,
                          margin: const EdgeInsets.symmetric(horizontal: 20,vertical: 16),
                          padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10.0),
                              color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                offset: const Offset(1,0),
                                blurRadius: 6.0,
                                color: Colors.grey.withOpacity(0.5)
                              ),
                            ]
                          ),
                        child: Center(
                          child: RichText(
                            text: const TextSpan(
                                text: 'AZURAMART ',
                                style: TextStyle(color: Colors.black87,fontWeight: FontWeight.w800,fontSize: 18),
                                children: <TextSpan>[
                                  TextSpan(
                                    text: '| BELIEVE IN YOU',
                                    style: TextStyle(color: Colors.black87,fontWeight: FontWeight.normal,fontSize: 18),
                                  )
                                ]
                            ),
                          ),
                        ),
                        ),
                    ],
                  ),
                ),
                SliverGrid(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: MediaQuery.of(context).orientation ==
                        Orientation.portrait
                        ? 2
                        : MediaQuery.of(context).size.width > 740 ? 4 : 3,
                    mainAxisSpacing: 12,
                    childAspectRatio:
                    MediaQuery.of(context).orientation ==
                        Orientation.portrait
                        ? screenWidth / 150.0
                        : screenHeight / 140.0,
                    crossAxisSpacing: 0,
                  ),
                  delegate: SliverChildBuilderDelegate(
                    (BuildContext context, int index) {
                      if (index == (featureModel.data!.length - 1) &&
                          canLoading) {
                        Provider.of<CommonNotifier>(context,listen: false).changeLoading(true);
                        // context.read<CommonNotifier>().changeLoading(true);
                        featureBloc.fetchPagingData();
                      }
                      return FeatureGridItem(featureModel, index);
                    },
                    childCount: featureModel.data!.length,
                  ),
                ),
                SliverLayoutBuilder(
                  builder: (BuildContext context, SliverConstraints constraints) {
                    if (Provider.of<CommonNotifier>(context, listen: false).isLoading) {
                      return SliverToBoxAdapter(
                        child: Center(
                          child: Container(
                                margin: const EdgeInsets.symmetric(vertical: 16),
                                height: 20,
                                width: 20,
                                child: const CupertinoActivityIndicator(
                                  animating: true,
                                  radius: 12,
                                ),
                              ),
                        ),
                      );
                    }  else{
                      return const SliverToBoxAdapter(
                        child: Center(
                            child: SizedBox(
                              height: 6,
                            )
                        ),
                      );
                    }
                  },
                ),
              ],
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text(snapshot.error.toString()),
            );
          }
          return LoadingWidget(color: AppsColors.buttonColor,);
        });
  }
}
