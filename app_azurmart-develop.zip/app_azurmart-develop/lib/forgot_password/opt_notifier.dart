import 'package:flutter/foundation.dart';

class OtpNotifier extends ChangeNotifier{
  /// userType 1 = customer; userType 2 = reseller;
  int? userType = 1;
  void changeUserType(int? value){
    userType = value;
    notifyListeners();
  }
}