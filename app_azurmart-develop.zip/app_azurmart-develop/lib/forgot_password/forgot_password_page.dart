import 'dart:convert';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/forgot_password/opt_notifier.dart';
import 'package:azuramartmy/forgot_password/otp_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:provider/provider.dart';

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const ForgotPasswordPage());
  }

  @override
  _ForgotPasswordPageState createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  final GlobalKey<FormState> _forgotFormKey = GlobalKey<FormState>();
  var emailController = TextEditingController();
  String? number;
  String? email;

  bool canLoading = false;

  String? numberValidation(String value) {
    if (value.isEmpty) {
      return 'Empty Mobile/Email!';
    } else if (value.length < 10) {
      return 'Enter valid number!';
    } else if (value.length > 11) {
      return 'Enter valid number!';
    } else {
      return null;
    }
  }

  final _emailRegex = RegExp(
    r'^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$',
  );

  String? validationEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Enter an email address!';
    } else if (!_emailRegex.hasMatch(value)) {
      return 'Enter a valid email!';
    } else {
      return null;
    }
  }

  void getOtp(String? email) async {
    Map<String, dynamic> data = {
      'email': '$email',
      'type': '${Provider.of<OtpNotifier>(context, listen: false).userType}',
    };
    var requestBody = json.encode(data);
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.getOtp);
      print('url');
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      setState(() {
        canLoading = false;
      });
      if (body['status'] == 1) {
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => OtpPage(email: email),
            ));
      } else {
        Common.toastMsg('${body['message']}');
      }
    } on FormatException catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    FirebaseMessaging.instance.getToken().then((value) {
      String? token = value;
      print('token : $token');
    });
    canLoading = false;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: CustomScrollView(
          scrollDirection: Axis.vertical,
          slivers: [
            SliverToBoxAdapter(
              child: Align(
                alignment: Alignment.topLeft,
                child: IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: const Icon(
                    Icons.close,
                    size: 24,
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 50,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Center(
                  child: Image(
                    image: AssetImage('images/azura_logo_large.png'),
                    width: 100,
                    height: 100,
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 80,
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Form(
                  key: _forgotFormKey,
                  child: Column(
                    children: [
                      SizedBox(
                        width: double.infinity,
                        child: TextFormField(
                          style: const TextStyle(
                              color: Colors.black87,
                              fontSize: 18,
                              fontWeight: FontWeight.w600),
                          controller: emailController,
                          validator: validationEmail,
                          cursorColor: Colors.black87,
                          textInputAction: TextInputAction.done,
                          onSaved: (String? val) {
                            email = val;
                          },
                          keyboardType: TextInputType.emailAddress,
                          decoration: InputDecoration(
                            alignLabelWithHint: true,
                            prefixIcon: const Icon(
                              Icons.email_outlined,
                              size: 18,
                              color: Colors.black54,
                            ),
                            filled: true,
                            fillColor: const Color(0xFFD1D2D3).withOpacity(0.4),
                            contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 16),
                            hintText: 'Email',
                            hintStyle:
                            const TextStyle(color: Colors.black54, fontSize: 18),
                            focusedBorder: InputBorder.none,
                            border: InputBorder.none,
                            enabledBorder: InputBorder.none,
                            errorBorder: InputBorder.none,
                            disabledBorder: InputBorder.none,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      SizedBox(
                        height: 50,
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () {
                            if (_forgotFormKey.currentState!.validate()) {
                              _forgotFormKey.currentState!.save();
                              setState(() {
                                canLoading = true;
                              });
                              getOtp(email);
                            }
                          },
                          style: ElevatedButton.styleFrom(
                              primary: AppsColors.buttonColor,
                              shape: const RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(6.0)))),
                          child: !canLoading
                              ? const Text(
                                  'GET OTP',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600),
                                )
                              : const Center(
                                  child: SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Radio(
                                    activeColor: AppsColors.buttonColor,
                                    value: 1,
                                    groupValue:
                                        context.watch<OtpNotifier>().userType,
                                    onChanged: (dynamic value) {
                                      context
                                          .read<OtpNotifier>()
                                          .changeUserType(value);
                                    }),
                                const SizedBox(
                                  width: 0,
                                ),
                                GestureDetector(
                                  onTap: () {
                                    context
                                        .read<OtpNotifier>()
                                        .changeUserType(1);
                                  },
                                  child: Text(
                                    'Customer',
                                    style: TextStyle(
                                        color: context
                                                    .watch<OtpNotifier>()
                                                    .userType ==
                                                1
                                            ? Colors.black
                                            : Colors.black45,
                                        fontSize: 14),
                                  ),
                                )
                              ],
                            ),
                            const SizedBox(
                              width: 16,
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Radio(
                                    activeColor: AppsColors.buttonColor,
                                    value: 2,
                                    groupValue:
                                        context.watch<OtpNotifier>().userType,
                                    onChanged: (dynamic value) {
                                      context
                                          .read<OtpNotifier>()
                                          .changeUserType(value);
                                    }),
                                const SizedBox(
                                  width: 0,
                                ),
                                GestureDetector(
                                  onTap: () {
                                    context
                                        .read<OtpNotifier>()
                                        .changeUserType(2);
                                  },
                                  child: Text(
                                    'Reseller',
                                    style: TextStyle(
                                        color: context
                                                    .watch<OtpNotifier>()
                                                    .userType ==
                                                1
                                            ? Colors.black45
                                            : Colors.black,
                                        fontSize: 14),
                                  ),
                                )
                              ],
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
