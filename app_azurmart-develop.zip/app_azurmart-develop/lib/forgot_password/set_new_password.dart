import 'dart:async';
import 'dart:convert';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/forgot_password/opt_notifier.dart';
import 'package:azuramartmy/login/login_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:provider/provider.dart';

class SetNewPassword extends StatefulWidget {
  const SetNewPassword({Key? key,this.email,this.token}) : super(key: key);
  final String? email;
  final String? token;

  static Route route(){
    return MaterialPageRoute(builder: (_) => const SetNewPassword());
  }

  @override
  _SetNewPasswordState createState() => _SetNewPasswordState();
}

class _SetNewPasswordState extends State<SetNewPassword> {

  final GlobalKey<FormState> _setPassFormKey = GlobalKey<FormState>();
  var passwordController = TextEditingController();
  var confirmPasswordController = TextEditingController();
  String? password;

  String? validationPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Password!';
    } else if (value.length < 5) {
      return 'Enter minimum 5 digit';
    } else {
      return null;
    }
  }

  String? validationConfirmPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Confirm Password!';
    } else if (value.compareTo(passwordController.text.toString()) == 0) {
      return null;
    } else {
      return 'Doesn\'t match with password';
    }
  }

  bool _obscureText = true;
  void _toggle() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  createNewPassword() async {
    Map<String, dynamic> data = {
      'email': '${widget.email}',
      'type': '${Provider.of<OtpNotifier>(context, listen: false).userType}',
      'password': '$password',
      'token': '${widget.token}'
    };
    var requestBody = json.encode(data);
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.resetPassword);
      print('url');
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      if (body['status'] == 1) {
        Common.toastMsg('${body['message']}');
        var _duration = const Duration(seconds: 2);
        return Timer(_duration,loginRoute);
      } else {
        Common.toastMsg('${body['message']}');
      }
    } on FormatException catch (e) {
      print(e);
    }
  }

  void loginRoute(){
    Navigator.pushAndRemoveUntil(context, LoginPage.route(), (route) => false);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: CustomScrollView(
          scrollDirection: Axis.vertical,
          slivers: [
            SliverToBoxAdapter(
              child: Align(
                alignment: Alignment.topLeft,
                child: IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: const Icon(
                    Icons.close,
                    size: 24,
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 50,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Center(
                  child: Image(
                    image: AssetImage('images/azura_logo_large.png'),
                    width: 100,
                    height: 100,
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 80,
              ),
            ),

            SliverToBoxAdapter(
              child: Form(
                key: _setPassFormKey,
                autovalidateMode: AutovalidateMode.always,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      width: double.infinity,
                      child: TextFormField(
                        textAlign: TextAlign.start,
                        style: const TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                        controller: passwordController,
                        validator: validationPassword,
                        textInputAction: TextInputAction.next,
                        keyboardType: TextInputType.visiblePassword,
                        obscureText: _obscureText,
                        maxLines: 1,
                        cursorColor: Colors.black87,
                        onSaved: (String? val) {
                          password = val;
                        },
                        decoration: InputDecoration(
                          // icon: Icon(Icons.vpn_key_outlined),
                          prefixIcon: const Icon(
                            Icons.vpn_key_outlined,
                            color: Colors.black54,
                            size: 20,
                          ),
                          suffixIcon: GestureDetector(
                            onTap: () {
                              _toggle();
                            },
                            child: _obscureText
                                ? const Icon(
                              Icons.visibility_off,
                              color: Colors.black54,
                            )
                                : const Icon(
                              Icons.visibility,
                              color: Colors.black54,
                            ),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 16),
                          fillColor: const Color(0xFFD1D2D3).withOpacity(0.4),
                          filled: true,
                          hintText: 'New Password',
                          focusedBorder: InputBorder.none,
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          errorBorder: InputBorder.none,
                          disabledBorder: InputBorder.none,
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      width: double.infinity,
                      child: TextFormField(
                        textAlign: TextAlign.start,
                        style: const TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                        controller: confirmPasswordController,
                        validator: validationConfirmPassword,
                        textInputAction: TextInputAction.done,
                        keyboardType: TextInputType.visiblePassword,
                        obscureText: _obscureText,
                        maxLines: 1,
                        cursorColor: Colors.black87,
                        onSaved: (String? val) {
                          // confirmPassword = val;
                        },
                        decoration: InputDecoration(
                          // icon: Icon(Icons.vpn_key_outlined),
                          prefixIcon: const Icon(
                            Icons.vpn_key_outlined,
                            color: Colors.black54,
                            size: 20,
                          ),
                          suffixIcon: GestureDetector(
                            onTap: () {
                              _toggle();
                            },
                            child: _obscureText
                                ? const Icon(
                              Icons.visibility_off,
                              color: Colors.black54,
                            )
                                : const Icon(
                              Icons.visibility,
                              color: Colors.black54,
                            ),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 16),
                          fillColor: const Color(0xFFD1D2D3).withOpacity(0.4),
                          filled: true,
                          hintText: 'Confirm New Password',
                          focusedBorder: InputBorder.none,
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          errorBorder: InputBorder.none,
                          disabledBorder: InputBorder.none,
                        ),
                      ),
                    ),

                    Container(
                      height: 50,
                      margin: const EdgeInsets.symmetric(horizontal: 16,vertical: 50),
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          if (_setPassFormKey.currentState!.validate()) {
                            _setPassFormKey.currentState!.save();
                            createNewPassword();
                          }
                        },
                        style: ElevatedButton.styleFrom(
                            primary: AppsColors.buttonColor,
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                BorderRadius.all(Radius.circular(6.0)))),
                        child: const Text(
                          'CREATE NEW PASSWORD',
                          style: TextStyle(
                              color: Colors.white, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
