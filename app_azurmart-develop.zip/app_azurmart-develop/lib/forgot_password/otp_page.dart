import 'dart:convert';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/forgot_password/opt_notifier.dart';
import 'package:azuramartmy/forgot_password/set_new_password.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:provider/provider.dart';

class OtpPage extends StatefulWidget {
  const OtpPage({Key? key,this.email}) : super(key: key);
  final String? email;

  static Route route(){
    return MaterialPageRoute(builder: (_) => const OtpPage());
  }

  @override
  _OtpPageState createState() => _OtpPageState();
}

class _OtpPageState extends State<OtpPage> {

  final GlobalKey<FormState> _optKey = GlobalKey<FormState>();
  var firstController = TextEditingController();
  var secondController = TextEditingController();
  var thirdController = TextEditingController();
  var forthController = TextEditingController();
  var fifthController = TextEditingController();

  String? first,second,third,forth,fifth;
  bool canLoading = false;

  String? firstValidation(String? value){
    if (value == null || value.isEmpty) {
      // Common.toastMsg('Enter OTP');
      return '';
    } else {
      return null;
    }
  }
  String? secondValidation(String? value){
    if (value == null || value.isEmpty) {
      // Common.toastMsg('Enter OTP');
      return '';
    } else {
      return null;
    }
  }
  String? thirdValidation(String? value){
    if (value == null || value.isEmpty) {
      // Common.toastMsg('Enter OTP');
      return '';
    } else {
      return null;
    }
  }
  String? forthValidation(String? value){
    if (value == null || value.isEmpty) {
      // Common.toastMsg('Enter OTP');
      return '';
    } else {
      return null;
    }
  }
  String? fifthValidation(String? value){
    if (value == null || value.isEmpty) {
      // Common.toastMsg('Enter OTP');
      return '';
    } else {
      return null;
    }
  }

  void verifyOtp() async {
    String otp = first! + second! + third! + forth! + fifth!;
    Map<String, dynamic> data = {
      'email': '${widget.email}',
      'token': otp,
      'type': '${Provider.of<OtpNotifier>(context, listen: false).userType}',
    };
    var requestBody = json.encode(data);
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.verifyOty);
      print('$data');
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      setState(() {
        canLoading = false;
      });
      if (body['status'] == 1) {
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SetNewPassword(email: widget.email,token: otp,),
            ));
      } else {
        Common.toastMsg('${body['message']} try again');
      }
    } on FormatException catch (e) {
      print(e);
    }
  }

  void resendOtp() async {
    Map<String, dynamic> data = {
      'email': '${widget.email}',
      'type': '${Provider.of<OtpNotifier>(context, listen: false).userType}',
    };
    var requestBody = json.encode(data);
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.getOtp);
      print('url');
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      if (body['status'] == 1) {
        Common.toastMsg('Check your email');
      } else {
        Common.toastMsg('${body['message']}');
      }
    } on FormatException catch (e) {
      print(e);
    }
  }

  FocusNode? firstNode;
  FocusNode? secondNode;
  FocusNode? thirdNode;
  FocusNode? forthNode;
  FocusNode? fifthNode;

  @override
  void initState() {
    canLoading = false;
    firstNode = FocusNode();
    secondNode = FocusNode();
    thirdNode = FocusNode();
    forthNode = FocusNode();
    fifthNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    firstNode!.dispose();
    secondNode!.dispose();
    thirdNode!.dispose();
    forthNode!.dispose();
    fifthNode!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: CustomScrollView(
          scrollDirection: Axis.vertical,
          slivers: [
            SliverToBoxAdapter(
              child: Align(
                alignment: Alignment.topLeft,
                child: IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: const Icon(
                    Icons.close,
                    size: 24,
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 50,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Center(
                  child: Image(
                    image: AssetImage('images/azura_logo_large.png'),
                    width: 100,
                    height: 100,
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 80,
              ),
            ),

            SliverToBoxAdapter(
              child: Form(
                key: _optKey,
                autovalidateMode: AutovalidateMode.always,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6.0),
                          color: Colors.transparent,
                          border: Border.all(color: const Color(0xFFC7C7C7))
                      ),
                      child: TextFormField(
                        keyboardType: TextInputType.number,
                        maxLength: 1,
                        maxLines: 1,
                        validator: firstValidation,
                        focusNode: firstNode,
                        autofocus: true,
                        onChanged: (value){
                          if (value.isNotEmpty) {
                            FocusScope.of(context).requestFocus(secondNode);
                          }
                        },
                        style: const TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                        onSaved: (value){
                          first = value;
                        },
                        decoration: const InputDecoration(
                          counterText: "",
                          focusedBorder: InputBorder.none,
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          errorBorder: InputBorder.none,
                          disabledBorder: InputBorder.none,
                        ),
                      ),
                    ),
                    Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6.0),
                          color: Colors.transparent,
                          border: Border.all(color: const Color(0xFFC7C7C7))
                      ),
                      child: TextFormField(
                        keyboardType: TextInputType.number,
                        maxLength: 1,
                        maxLines: 1,
                        focusNode: secondNode,
                        validator: secondValidation,
                        onChanged: (value){
                          if (value.isNotEmpty) {
                            FocusScope.of(context).requestFocus(thirdNode);
                          }
                        },
                        style: const TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                        onSaved: (value){
                          second = value;
                        },
                        decoration: const InputDecoration(
                          counterText: "",
                          focusedBorder: InputBorder.none,
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          errorBorder: InputBorder.none,
                          disabledBorder: InputBorder.none,
                        ),
                      ),
                    ),
                    Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6.0),
                          color: Colors.transparent,
                          border: Border.all(color: const Color(0xFFC7C7C7))
                      ),
                      child: TextFormField(
                        keyboardType: TextInputType.number,
                        maxLength: 1,
                        maxLines: 1,
                        focusNode: thirdNode,
                        validator: thirdValidation,
                        onChanged: (value){
                          if (value.isNotEmpty) {
                            FocusScope.of(context).requestFocus(forthNode);
                          }
                        },
                        style: const TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                        onSaved: (value){
                          third = value;
                        },
                        decoration: const InputDecoration(
                          counterText: "",
                          focusedBorder: InputBorder.none,
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          errorBorder: InputBorder.none,
                          disabledBorder: InputBorder.none,
                        ),
                      ),
                    ),
                    Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6.0),
                          color: Colors.transparent,
                          border: Border.all(color: const Color(0xFFC7C7C7))
                      ),
                      child: TextFormField(
                        keyboardType: TextInputType.number,
                        maxLength: 1,
                        maxLines: 1,
                        focusNode: forthNode,
                        validator: forthValidation,
                        onChanged: (value){
                          if (value.isNotEmpty) {
                            FocusScope.of(context).requestFocus(fifthNode);
                          }
                        },
                        style: const TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                        onSaved: (value){
                          forth = value;
                        },
                        decoration: const InputDecoration(
                          counterText: "",
                          focusedBorder: InputBorder.none,
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          errorBorder: InputBorder.none,
                          disabledBorder: InputBorder.none,
                        ),
                      ),
                    ),
                    Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6.0),
                          color: Colors.transparent,
                          border: Border.all(color: const Color(0xFFC7C7C7))
                      ),
                      child: TextFormField(
                        keyboardType: TextInputType.number,
                        textInputAction: TextInputAction.done,
                        maxLength: 1,
                        maxLines: 1,
                        focusNode: fifthNode,
                        validator: fifthValidation,
                        style: const TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                        onSaved: (value){
                          fifth = value;
                        },
                        decoration: const InputDecoration(
                          counterText: "",
                          focusedBorder: InputBorder.none,
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          errorBorder: InputBorder.none,
                          disabledBorder: InputBorder.none,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 10,
              ),
            ),
            SliverToBoxAdapter(
              child: Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: (){
                    resendOtp();
                  },
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('Code Resend',style: TextStyle(color: AppsColors.buttonColor,fontSize: 14,fontWeight: FontWeight.w600),),
                      const SizedBox(
                        width: 10,
                      ),
                      Icon(Icons.replay,color: AppsColors.buttonColor,size: 16,),
                      const SizedBox(
                        width: 10,
                      )
                    ],
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 30,
              ),
            ),

            SliverToBoxAdapter(
              child: Container(
                width: double.infinity,
                height: 50,
                margin: const EdgeInsets.symmetric(horizontal: 20,vertical: 0),
                child: ElevatedButton(
                  onPressed: () {
                    if (_optKey.currentState!.validate()) {
                      _optKey.currentState!.save();
                      setState(() {
                        canLoading = true;
                      });
                      verifyOtp();
                    }else{
                      Common.toastMsg('Enter OTP');
                    }
                  },
                  style: ElevatedButton.styleFrom(
                      primary: AppsColors.buttonColor,
                      shape: const RoundedRectangleBorder(
                          borderRadius:
                          BorderRadius.all(Radius.circular(6.0)))),
                  child: !canLoading? const Text(
                    'VERIFY AND PROCEED',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w600),
                  ) : const Center(
                    child: SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 50,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
