import 'dart:io';

import 'package:azuramartmy/product_details/product_details_body.dart';
import 'package:azuramartmy/provider_models/product_details_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ShowImage extends StatefulWidget {
  const ShowImage({Key? key,this.snapshot}) : super(key: key);
  final AsyncSnapshot<ProductDetailsModel>? snapshot;

  @override
  _ShowImageState createState() => _ShowImageState();
}

class _ShowImageState extends State<ShowImage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: (){
            Navigator.pop(context);
          },
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
      ),
      // backgroundColor: Colors.white.withOpacity(0.3),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(
              flex: 1,
              child: InteractiveViewer(
                constrained: true,
                scaleEnabled: true,
                maxScale: 3,
                minScale: 1,
                boundaryMargin: const EdgeInsets.all(0),
                child: Stack(
                  children: [
                    Container(
                      decoration: const BoxDecoration(color: Colors.transparent),
                      height: double.infinity,
                      width: double.infinity,
                      child: Center(
                        child: PageView.builder(
                            scrollBehavior: const ScrollBehavior(),
                            reverse: false,
                            pageSnapping: true,
                            scrollDirection: Axis.horizontal,
                            // controller: _pageController,
                            onPageChanged: (value) {
                              setState(() {
                                currentPage = value;
                              });
                            },
                            itemCount: widget.snapshot!.data!.data!.img!.length,
                            itemBuilder: (context, index) => DetailsImageView(
                                widget.snapshot!.data!.data!.img![index].relativepath)
                        ),
                      ),
                    ),
                    Align(
                      // bottom: 20,
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 20),
                        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                        decoration: BoxDecoration(
                            color: Colors.grey.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(30.0)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ...List.generate(widget.snapshot!.data!.data!.img!.length,
                                    (index) => buildDot(index))
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  int currentPage = 0;

  AnimatedContainer buildDot(int index) {
    return AnimatedContainer(
      duration: const Duration(microseconds: 500),
      curve: Curves.easeInOut,
      margin: const EdgeInsets.only(right: 5),
      height: 6,
      width: currentPage == index ? 12 : 6,
      decoration: ShapeDecoration(
          color: currentPage == index
              ? AppsColors.buttonColor
              : AppsColors.buttonColor.withOpacity(0.3),
          shape: const StadiumBorder()
      ),
    );
  }

}
