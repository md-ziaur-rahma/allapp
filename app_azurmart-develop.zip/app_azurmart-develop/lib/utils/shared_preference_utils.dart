import 'package:azuramartmy/provider_models/app_setting_model.dart';
import 'package:azuramartmy/provider_models/best_sell_model.dart';
import 'package:azuramartmy/provider_models/category2.dart';
import 'package:azuramartmy/provider_models/coupon_product_model.dart';
import 'package:azuramartmy/provider_models/offer_model.dart';
import 'package:azuramartmy/provider_models/page_list_model.dart';
import 'package:azuramartmy/provider_models/post_code_model.dart';
import 'package:azuramartmy/provider_models/whatsapp_model.dart';

class SharedPreferenceUtils {
  static const String TOKEN = 'token';
  static const String USER_ID = 'user_id';
  static const String USER_NAME = 'user_name';
  static const String LAST_NAME = 'lastName';
  static const String profilePic = 'profilePic';
  static const String EMAIL = 'email';
  static const String MOBILE = 'mobile';
  static const String ROLE_ID = 'role_id';
  static const String LOCATION = 'location';

  static const String SESSION = "session";

  static const String CATEGORY = 'category';
  static const String LATEST_PRODUCT ='latest_product';

  /// ........ for billing & shipping address ..........
  static const String BILLING_ADDRESS = 'billing_address';
  static const String SHIPPING_ADDRESS = 'shipping_address';
  static const String FIRSTNAME = 'firstname';
  static const String LASTNAME = 'lastname';
  static const String ADDRESS = 'address';
  static const String POSTCODE = 'postcode';
  static const String CITY = 'city';
  static const String STATE = 'state';

  static const String STATEPK = 'state_pk';
  static const String CITYPK = 'city_pk';

  static const String APARTMENT = 'apartment';


  static String? usernameF = '';
  static String? lastNameF = '';
  static String? mobileF = '';
  static String? profilePicF = '';
  static String? emailF = '';
  static int? userIdF = 0;
  static String sessionF = '';

  /// ............. for shipping address ..............
  static String? firstNameSP = '';
  static String? lastnameSP = '';
  static String? addressSP = '';
  static String? address2SP = '';
  static int postcodeSP = 0;
  static String? citySP = '';
  static String? stateSP = '';
  static int? statePkSP = 0;
  static int? cityPkSP = 0;
  static String? mobileSP = '';

  /// ............. for Billing address ..............
  static String? firstNameBL = '';
  static String? lastnameBL = '';
  static String? addressBL = '';
  static String? address2BL = '';
  static int postcodeBL = 0;
  static String? cityBL = '';
  static String? stateBL = '';
  static int? statePkBL = 0;
  static int? cityPkBL = 0;
  static String? mobileBL = '';

  static double? postageCostSS = 0;
  static double? postageCostSM = 0;
  static double? totalPrice = 0;
  static double? totalInsPrice = 0;

  static int? isShipping = 1;
  static var billingAddress = {};
  static var shippingAddress = {};
  static String? password = '';

  /// ................... lists ......................
  static Category2 categoryList = Category2();
  static BestSellModel bestSellModel = BestSellModel();
  static CouponProductModel couponProduct = CouponProductModel();

  static WhatsappModel whatsappModel = WhatsappModel();
  static OfferModel offerModel = OfferModel();
  static PageListModel pageListModel = PageListModel();
  static AppSettingModel appSettingModel = AppSettingModel();

  static List<String> searchSuggestionList = ['wok','balti','knife','wok','balti','knife','wok'];

  /// ................... post code ...................
  static PostCodeModel postCodeModel = PostCodeModel();


}