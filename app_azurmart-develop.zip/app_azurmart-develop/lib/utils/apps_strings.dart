class AppsString {
  static const joiJourNewsLetterText = 'Sign up for the AzuraMart Newsletter and be the first to preview our new collections, receive exclusive offers, and discover our products.';
  static String RETURN_POLICY = 'We deliver to over 100 countries around the world. For full details of the delivery options we offer, please view our Delivery information We hope you’ll love every purchase, but if you ever need to return an item you can do so within a month of receipt. For full details of how to make a return, please view our Returns information';
}