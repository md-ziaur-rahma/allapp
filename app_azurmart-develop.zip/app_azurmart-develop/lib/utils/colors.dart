import 'package:flutter/material.dart';

class AppsColors {
  // Black variant..........
  static Color black = const Color(0xFF000000);
  static Color matteBlack = const Color(0xFF28282B);
  static Color onyxBlack = const Color(0xFF353935);
  static Color darkPurple = const Color(0xFF301934);
  static Color charcoalBlack = const Color(0xFF36454F);

  // White variant..........
  static Color white = const Color(0xFFFFFFFF);
  static Color offWhite = const Color(0xFFFAF9F6);
  static Color seashellWhite = const Color(0xFFFFF5EE);
  static Color cream = const Color(0xFFFFFDD0);
  static Color cornSilkWhite = const Color(0xFFFFF8DC);
  static Color bonWhiteX = const Color(0xFFF9F6EE);

  // Pink variant..........
  static Color cariesPink = const Color(0xFFDE3163);
  static Color amaranthPing = const Color(0xFF9F2B68);
  static Color darkPing = const Color(0xFFAA336A);
  static Color originalPing = const Color(0xFFFFC0CB);
  static Color pinkOrange = const Color(0xFFF89880);
  static Color watermelonPink = const Color(0xFFE37383);

  static Color blueGreenX = const Color(0xFF088F8F);
  static Color verdigrisGreenX = const Color(0xFF40B5AD);

  //................. Offer Color ..................
  static Color offerColor = const Color(0xFFd50000);

  static Color primaryColor = const Color(0xfff68721);
  static Color buttonColor = const Color(0xFF353935);

  static Color highlightedColor = const Color(0xfff68721);
}