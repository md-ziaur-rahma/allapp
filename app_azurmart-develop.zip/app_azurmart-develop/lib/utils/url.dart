class Urls {
  // static String baseUrl = 'http://192.168.203.57/api/v1/';
  // static String baseVersion = 'Local 1.0';
  // static String baseShareUrl = 'https://azuramart.com/product/';
  // static String basePictureUrl = 'https://admin.azuramart.com';

// static String baseUrl = 'http://118.179.179.232:8888/azuramart/public/api/v1/';

  // static String baseUrl = 'http://ww2.azuramart.com/api/v1/';
  // static String baseShareUrl = 'http://ww2.azuramart.com/product/';
  // static String baseVersion = 'Public 1.0';
  // static String basePictureUrl = 'https://admin.azuramart.com';
  // // static String basePictureUrl = 'https://dev.ukshop.my';

  static String baseUrl = 'https://azuramart.com/api/v1/';
  static String baseShareUrl = 'https://azuramart.com/product/';
  static String baseVersion = 'Public 1.0';
  static String basePictureUrl = 'https://admin.azuramart.com';
  // static String basePictureUrl = 'https://dev.ukshop.my';


  static String login = 'login';
  static String googleLogin = 'google-signing';
  static String registration = 'registration';
  static String changePersonalInfo = 'change-personal-info';
  static String changeEmail = 'change-email';
  static String accountDeletion = 'customer/deletion_request';

  static String uploadImage = 'upload-user-image';
  static String getOtp = 'get-otp';
  static String verifyOty = 'verify-otp';
  static String resetPassword = 'reset-password';
  static String changePassword = 'change-password';
  static String orderList = 'order-list';
  static String orderDetails = 'order-details';
  static String PAGE = 'page/about-us';
  static String CHECK_UPDATE = 'check-update';
  static String appSetting = 'app-setting';
  static String PAGE_LIST = 'page-list';
  static String home_banner = 'home-banner';
  static String home_category = 'category-list';
  static String CATEGORY_PRODUCTS = 'category-products';
  static String CATEGORY_BRAND_DETAILS = 'category-brand-details';
  static String NEW_ARRIVAL_PRODUCT = 'new-arrival-product';
  static String ADD_TO_CART = 'add-to-cart';
  static String CART = 'cart-list';
  static String CART_COUNT = 'cart-count';
  static String CARTQTYUPDATE = 'cart-qty-update';
  static String CARTLOCATIONUPDATE = 'cart-location-update';
  static String BRAND = 'brand-list';
  static String ALL_BRAND = 'all-brand';
  static String ADDRESS = 'user-address-list';
  static String userBalanceList = 'user-balance-list';
  static String userPaymentList = 'user-payment-list';
  static String paymentDetails = 'payment-details';
  static String BRAND_DETAILS = 'brand-details';
  static String BRAND_PRODUCT = 'brand-product';
  static String UPDATE_CART = 'update-cart';
  static String WISHLIST = 'wish-list';
  static String FEATURE_PRODUCT = 'feature-product';
  static String OFFER_PRODUCTS = 'offer-list';
  static String BEST_SELL = 'best-sell-list';
  static String COUPON_PRODUCT_LIST = 'coupon-product-list';
  static String COUPON_LIST = 'coupon-list';
  static String COUPON_HOME = 'coupon-home';
  static String ADD_TO_WISH = 'add-wish';
  static String SHORT_SEARCH = 'search-short-result';
  static String SEARCH = 'search-result';
  static String MODEL_SEARCH = 'model-search';
  static String MODEL_SEARCH_RESULT = 'model-product-search';
  static String POST_CODE = 'post-code-list';
  static String SAVE_ADDRESS = 'save-address';
  static String CHECK_EMAIL = 'check-user-exists';
  static String WHATSAPP_LIST = 'whatsapp-list';
  static String MAKE_ORDER = 'make-order';
  static String postOrderPayment = 'post-order-payment';
  static String getOrderPayment = 'get-order-payment';
  static String NEWS = 'blog-feature-list';
  static String BLOG_DETAILS = 'blog-feature-details';
  static String instagramFeed = 'get-instagram-feed';
  static String subscription = 'subscriber/save-subscriber';
  static const String applyCoupon = 'apply-coupon';

  static String DEFAULD_IMAGE = 'https://www.google.com/search?q=default+product+&tbm=isch&ved=2ahUKEwiy8MnIh-rxAhXCD3IKHVyeBlIQ2-cCegQIABAA&oq=default+product+&gs_lcp=CgNpbWcQAzIECCMQJzIECAAQQzICCAAyAggAMgIIADIECAAQHjIECAAQGDIECAAQGDIECAAQGDIECAAQGFDCOFjCOGDxOmgAcAB4AIABugGIAboBkgEDMC4xmAEAoAEBqgELZ3dzLXdpei1pbWfAAQE&sclient=img&ei=vsbyYLKZB8KfyAPcvJqQBQ&bih=937&biw=1920#imgrc=lw1DyR1sCJ_ANM';
}