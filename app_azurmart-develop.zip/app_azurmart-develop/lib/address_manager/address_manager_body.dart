import 'dart:convert';

import 'package:azuramartmy/address_manager/address_manager_notifier.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/my_bloc/address_bloc.dart';
import 'package:azuramartmy/provider_models/address_list_model.dart';
import 'package:azuramartmy/provider_models/post_code_model.dart';
import 'package:azuramartmy/provider_models/temp_post_code_model.dart';
import 'package:azuramartmy/provider_models/temp_state_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:http/http.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AddressManagerBody extends StatefulWidget {
  const AddressManagerBody({Key? key}) : super(key: key);

  @override
  _AddressManagerBodyState createState() => _AddressManagerBodyState();
}

class _AddressManagerBodyState extends State<AddressManagerBody> {
  // int groupValue = -1;

  void getPostCode() async {
    Client client = Client();
    Uri url = Uri.parse('${Urls.baseUrl}${Urls.POST_CODE}');
    try {
      final response = await client.post(url);
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        PostCodeModel postCodeModel = PostCodeModel.fromJson(body);
        SharedPreferenceUtils.postCodeModel = postCodeModel;
      }
    } on Exception catch (e) {
      // print(e);
    }
  }

  void getDefaultShippingAddress(AsyncSnapshot<AddressListModel> snapshot){
    for(var i = 0; i < snapshot.data!.data!.shippingAddress!.length; i++) {
      if (snapshot.data!.data!.shippingAddress![i].isdefault == 1) {
        Provider.of<AddressManagerNotifier>(context,listen: false).changeShippingGroupValue(i);
        return;
      }
    }
  }

  void setDefaultAddress(AsyncSnapshot<AddressListModel> snapshot, int index) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Client client = Client();

    /// address type 1 = shipping, 2 = billing.......
    Map<String, dynamic> data = {
      'session': '$session',
      'user_id': '$userId',
      'token': '$token',
      'firstName': '${snapshot.data!.data!.shippingAddress![index].name}',
      'lastName': '${snapshot.data!.data!.shippingAddress![index].lastname}',
      'address_line1': '${snapshot.data!.data!.shippingAddress![index].addressline1}',
      'postCode': '${snapshot.data!.data!.shippingAddress![index].postcode}',
      'mobile': '${snapshot.data!.data!.shippingAddress![index].telno}',
      'address_line2': '${snapshot.data!.data!.shippingAddress![index].addressline2}',
      'city_pk': '${snapshot.data!.data!.shippingAddress![index].fcityno}',
      'state_pk': '${snapshot.data!.data!.shippingAddress![index].fstateno}',
      'state': '${snapshot.data!.data!.shippingAddress![index].state}',
      'city': '${snapshot.data!.data!.shippingAddress![index].city}',
      'country': '${snapshot.data!.data!.shippingAddress![index].country}',
      'is_update': '1',
      'is_default': '1',
      'address_type': '1'
    };
    var requestBody = json.encode(data);

    print(requestBody);
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.SAVE_ADDRESS);
      print('url');
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      print('${body['message']}');
      if (body['status'] == 1) {

      }
    } on FormatException catch (e) {
      print(e);
      Common.toastMsg(e.toString());
    } on Exception catch (e) {
      print(e);
      Common.toastMsg(e.toString());
    }
  }

  @override
  void initState() {
    getPostCode();
    addressBloc.fetchAllAddress();
    super.initState();
  }

  // @override
  // void dispose() {
  //   Provider.of<AddressManagerNotifier>(context,listen: false).changeShippingGroupValue(0);
  //   super.dispose();
  // }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: addressBloc.allAddress,
        builder: (context, AsyncSnapshot<AddressListModel> snapshot) {
          if (snapshot.hasData) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: CustomScrollView(
                scrollDirection: Axis.vertical,
                slivers: [
                  const SliverToBoxAdapter(
                    child: SizedBox(
                      height: 10,
                    ),
                  ),
                  const SliverToBoxAdapter(
                    child: SizedBox(
                      width: double.infinity,
                      child: Text(
                        'The following addresses will be used on the checkout page by default.',
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 16,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                  ),
                  const SliverToBoxAdapter(
                    child: SizedBox(
                      height: 20,
                    ),
                  ),
                  SliverLayoutBuilder(
                    builder:
                        (BuildContext context, SliverConstraints constraints) {
                      if (snapshot.data!.data!.billingAddress != null) {
                        // todo change ...........................................
                        return SliverToBoxAdapter(
                          child: Slidable(
                            actionPane: const SlidableDrawerActionPane(),
                            actionExtentRatio: 0.15,
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(16),
                              margin: const EdgeInsets.symmetric(vertical: 0),
                              decoration: BoxDecoration(
                                  color: const Color(0xFFFFFFFF),
                                  borderRadius: BorderRadius.circular(3)),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const SizedBox(
                                          width: double.infinity,
                                          child: Text(
                                            'Billing Address',
                                            style: TextStyle(
                                                color: Colors.black87,
                                                fontSize: 20,
                                                fontWeight: FontWeight.w600),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 8,
                                        ),
                                        SizedBox(
                                          width: double.infinity,
                                          child: Text(
                                            '${snapshot.data!.data!.billingAddress!.name} ${snapshot.data!.data!.billingAddress!.lastname}',
                                            textAlign: TextAlign.start,
                                            style: const TextStyle(
                                              color: Colors.black87,
                                              fontWeight: FontWeight.w600,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: double.infinity,
                                          child: Text(
                                            '${snapshot.data!.data!.billingAddress!.addressline1}',
                                            textAlign: TextAlign.start,
                                            style: const TextStyle(
                                                color: Colors.black45,
                                                fontSize: 14,
                                                fontStyle: FontStyle.italic),
                                          ),
                                        ),
                                        SizedBox(
                                          width: double.infinity,
                                          child: Text(
                                            '${snapshot.data!.data!.billingAddress!.addressline2}',
                                            textAlign: TextAlign.start,
                                            style: const TextStyle(
                                                color: Colors.black45,
                                                fontSize: 14,
                                                fontStyle: FontStyle.italic),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 6,
                                        ),
                                        SizedBox(
                                          width: double.infinity,
                                          child: Text(
                                            '${snapshot.data!.data!.billingAddress!.postcode} - ${snapshot.data!.data!.billingAddress!.city}, ${snapshot.data!.data!.billingAddress!.state}',
                                            textAlign: TextAlign.start,
                                            style: const TextStyle(
                                              color: Colors.black87,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 6,
                                        ),
                                        SizedBox(
                                          width: double.infinity,
                                          child: Text(
                                            snapshot.data!.data!.billingAddress!.country != null ?
                                            '${snapshot.data!.data!.billingAddress!.country}' : 'Malaysia',
                                            textAlign: TextAlign.start,
                                            style: const TextStyle(
                                              color: Colors.black87,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 4,
                                        ),
                                        SizedBox(
                                          width: double.infinity,
                                          child: Text(
                                            'Tel : ${snapshot.data!.data!.billingAddress!.telno}',
                                            textAlign: TextAlign.start,
                                            style: const TextStyle(
                                              color: Colors.black87,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 4,
                                        ),
                                        // Container(
                                        //   width: double.infinity,
                                        //   height: 40,
                                        //   margin: EdgeInsets.symmetric(horizontal: 30),
                                        //   child: ElevatedButton(
                                        //     style: ElevatedButton.styleFrom(
                                        //         primary: Colors.pinkAccent,
                                        //         shape: RoundedRectangleBorder(
                                        //             borderRadius: BorderRadius.circular(30))),
                                        //     onPressed: () {},
                                        //     child: Text(
                                        //       'Change Address',
                                        //       style: TextStyle(color: Colors.white),
                                        //     ),
                                        //   ),
                                        // )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            secondaryActions: <Widget>[
                              Column(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Flexible(
                                      flex: 1,
                                      child: FloatingActionButton(
                                        onPressed: () {
                                          showModalBottomSheet(
                                              enableDrag: true,
                                              shape: const RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.only(
                                                      topLeft: Radius.circular(16),
                                                      topRight: Radius.circular(16))),
                                              isScrollControlled: true,
                                              isDismissible: true,
                                              context: context,
                                              builder: (context){
                                                return DraggableScrollableSheet(
                                                    expand: false,
                                                    builder: (context, scrollController){
                                                      return AddressEdit(isUpdate: 1,isDefault: 0,addressType: 2,snapshot: snapshot,index: 0,scrollController: scrollController,);
                                                    }
                                                );
                                              }
                                          );
                                        },
                                        mini: true,
                                        foregroundColor: Colors.black87,
                                        backgroundColor: Colors.white,
                                        child: const Icon(
                                          Icons.edit,
                                          size: 16,
                                        ),
                                      )),
                                  // SizedBox(
                                  //   height: 20,
                                  // ),
                                  // Flexible(
                                  //     flex: 1,
                                  //     child: FloatingActionButton(
                                  //       onPressed: () {
                                  //         ScaffoldMessenger.of(context)
                                  //             .showSnackBar(SnackBar(
                                  //                 content: Text('Deleted')));
                                  //       },
                                  //       mini: true,
                                  //       foregroundColor: Colors.white,
                                  //       backgroundColor: Colors.pinkAccent,
                                  //       child: Icon(
                                  //         Icons.delete,
                                  //         size: 16,
                                  //       ),
                                  //     )),
                                ],
                              )
                            ],
                          ),
                        );
                      } else {
                        return const SliverToBoxAdapter(
                          child: SizedBox(
                            height: 2,
                          ),
                        );
                      }
                    },
                  ),
                  const SliverToBoxAdapter(
                    child: SizedBox(
                      height: 16,
                    ),
                  ),
                  SliverLayoutBuilder(builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.shippingAddress!.isNotEmpty) {
                      snapshot.data!.data!.shippingAddress!.sort((a,b) => b.isdefault!.compareTo(a.isdefault!));
                      // Provider.of<AddressManagerNotifier>(context,listen: false).changeShippingGroupValue(0);
                      return SliverList(
                          delegate: SliverChildBuilderDelegate(
                                  (BuildContext context, index) {
                                // getDefaultShippingAddress(snapshot);
                                return Slidable(
                                  actionPane: const SlidableDrawerActionPane(),
                                  actionExtentRatio: 0.15,
                                  child: Container(
                                    width: double.infinity,
                                    padding: const EdgeInsets.all(16),
                                    margin: const EdgeInsets.symmetric(vertical: 8),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFFFFFFF),
                                      borderRadius: BorderRadius.circular(6),
                                      // boxShadow: [
                                      //   BoxShadow(
                                      //     blurRadius: 6.0,
                                      //     color: Colors.grey.withOpacity(0.3),
                                      //     offset: Offset(1,0),
                                      //     // spreadRadius: 10.0
                                      //   )
                                      // ]
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        // Expanded(
                                        //   flex: 1,
                                        //   child: Container(
                                        //     width: 50,
                                        //     child: Center(
                                        //       child: Radio(
                                        //         value: index,
                                        //         activeColor: AppsColors.buttonColor,
                                        //         groupValue: context.watch<AddressManagerNotifier>().shippingGroupValue,
                                        //         onChanged: (newValue) {
                                        //           context.read<AddressManagerNotifier>().changeShippingGroupValue(newValue);
                                        //           for(int xx = 0; xx < snapshot.data.data.shippingAddress.length; xx++)
                                        //             if (xx == index) {
                                        //               snapshot.data.data.shippingAddress[xx].isdefault = 1;
                                        //             } else {
                                        //               snapshot.data.data.shippingAddress[xx].isdefault = 0;
                                        //             }
                                        //           setDefaultAddress(snapshot,index);
                                        //         },
                                        //       ),
                                        //     ),
                                        //   ),
                                        // ),
                                        Expanded(
                                          flex: 5,
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              SizedBox(
                                                width: double.infinity,
                                                child: Text(
                                                  'Shipping Address ${snapshot.data!.data!.shippingAddress![index].isdefault == 1 ? '(Default)' : '(${index + 1})'}',
                                                  style: const TextStyle(
                                                      color: Colors.black87,
                                                      fontSize: 20,
                                                      fontWeight: FontWeight.w600),
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 4,
                                              ),
                                              SizedBox(
                                                width: double.infinity,
                                                child: Text(
                                                  '${snapshot.data!.data!.shippingAddress![index].name} ${snapshot.data!.data!.shippingAddress![index].lastname}',
                                                  textAlign: TextAlign.start,
                                                  style: const TextStyle(
                                                    color: Colors.black87,
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 16,
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: double.infinity,
                                                child: Text(
                                                  '${snapshot.data!.data!.shippingAddress![index].addressline1}',
                                                  textAlign: TextAlign.start,
                                                  style: const TextStyle(
                                                      color: Colors.black45,
                                                      fontSize: 14,
                                                      fontStyle: FontStyle.italic),
                                                ),
                                              ),
                                              SizedBox(
                                                width: double.infinity,
                                                child: Text(
                                                  '${snapshot.data!.data!.shippingAddress![index].addressline2}',
                                                  textAlign: TextAlign.start,
                                                  style: const TextStyle(
                                                      color: Colors.black45,
                                                      fontSize: 14,
                                                      fontStyle: FontStyle.italic),
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 6,
                                              ),
                                              SizedBox(
                                                width: double.infinity,
                                                child: Text(
                                                  '${snapshot.data!.data!.shippingAddress![index].postcode} - ${snapshot.data!.data!.shippingAddress![index].city}, ${snapshot.data!.data!.shippingAddress![index].state}',
                                                  textAlign: TextAlign.start,
                                                  style: const TextStyle(
                                                    color: Colors.black87,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 6,
                                              ),
                                              SizedBox(
                                                width: double.infinity,
                                                child: Text(
                                                  snapshot.data!.data!.shippingAddress![index].country != null ?
                                                  '${snapshot.data!.data!.shippingAddress![index].country}' : 'Malaysia',
                                                  textAlign: TextAlign.start,
                                                  style: const TextStyle(
                                                    color: Colors.black87,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 6,
                                              ),
                                              SizedBox(
                                                width: double.infinity,
                                                child: Text(
                                                  'Tel : ${snapshot.data!.data!.shippingAddress![index].telno}',
                                                  textAlign: TextAlign.start,
                                                  style: const TextStyle(
                                                    color: Colors.black87,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 4,
                                              ),
                                              // Container(
                                              //   width: double.infinity,
                                              //   height: 40,
                                              //   margin: EdgeInsets.symmetric(horizontal: 30),
                                              //   child: ElevatedButton(
                                              //     style: ElevatedButton.styleFrom(
                                              //         primary: Colors.pinkAccent,
                                              //         shape: RoundedRectangleBorder(
                                              //             borderRadius: BorderRadius.circular(30))),
                                              //     onPressed: () {},
                                              //     child: Text(
                                              //       'Change Address',
                                              //       style: TextStyle(color: Colors.white),
                                              //     ),
                                              //   ),
                                              // )
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  secondaryActions: <Widget>[
                                    Column(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Flexible(
                                            flex: 1,
                                            child: FloatingActionButton(
                                              onPressed: () {
                                                showModalBottomSheet(
                                                    enableDrag: true,
                                                    shape: const RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.only(
                                                            topLeft: Radius.circular(16),
                                                            topRight: Radius.circular(16))),
                                                    isScrollControlled: true,
                                                    isDismissible: true,
                                                    context: context,
                                                    builder: (context){
                                                      return DraggableScrollableSheet(
                                                          expand: false,
                                                          builder: (context, scrollController){
                                                            return AddressEdit(isUpdate: 1,isDefault: snapshot.data!.data!.shippingAddress![index].isdefault,addressType: 1,snapshot: snapshot,index: index,scrollController: scrollController,);
                                                          }
                                                      );
                                                    }
                                                );
                                              },
                                              mini: true,
                                              foregroundColor: Colors.black87,
                                              backgroundColor: Colors.white,
                                              child: const Icon(
                                                Icons.edit,
                                                size: 16,
                                              ),
                                            )
                                        ),
                                        // SizedBox(
                                        //   height: 20,
                                        // ),
                                        // Flexible(
                                        //     flex: 1,
                                        //     child: FloatingActionButton(
                                        //       onPressed: () {
                                        //         ScaffoldMessenger.of(context)
                                        //             .showSnackBar(SnackBar(
                                        //                 content: Text('Deleted')));
                                        //       },
                                        //       mini: true,
                                        //       foregroundColor: Colors.white,
                                        //       backgroundColor: AppsColors.charcoalBlack,
                                        //       child: Icon(
                                        //         Icons.delete,
                                        //         size: 16,
                                        //       ),
                                        //     )
                                        // ),
                                      ],
                                    )
                                  ],
                                );
                              },
                              childCount:
                              snapshot.data!.data!.shippingAddress!.length));
                    } else {
                      return const SliverToBoxAdapter(
                        child: Center(
                          child: Text('You have not any shipping address'),
                        ),
                      );
                    }
                  })
                ],
              ),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text(snapshot.error.toString()),
            );
          }
          return LoadingWidget(color: AppsColors.buttonColor,);
        });
  }
}

class AddressView extends StatefulWidget {
  const AddressView({Key? key}) : super(key: key);

  @override
  _AddressViewState createState() => _AddressViewState();
}

class _AddressViewState extends State<AddressView> {
  int? groupValue = 0;
  int value = 1;
  @override
  Widget build(BuildContext context) {
    return Slidable(
      actionPane: const SlidableDrawerActionPane(),
      actionExtentRatio: 0.15,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        margin: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
            color: const Color(0xFFF4F4F4), borderRadius: BorderRadius.circular(3)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Flexible(
              child: SizedBox(
                width: 50,
                child: Center(
                  child: Radio(
                    value: value,
                    groupValue: groupValue,
                    onChanged: (dynamic newValue) {
                      setState(() {
                        groupValue = newValue;
                      });
                    },
                  ),
                ),
              ),
            ),
            Flexible(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  SizedBox(
                    width: double.infinity,
                    child: Text(
                      'John Dao',
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: Text(
                      'Work Address',
                      textAlign: TextAlign.start,
                      style: TextStyle(
                          color: Colors.black45,
                          fontSize: 10,
                          fontStyle: FontStyle.italic),
                    ),
                  ),
                  SizedBox(
                    height: 12,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: Text(
                      'Pow box 90, Saint Helena Island, SC 232345',
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        color: Colors.black87,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 6,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: Text(
                      'Netherlands',
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        color: Colors.black87,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 16,
                  ),
                  // Container(
                  //   width: double.infinity,
                  //   height: 40,
                  //   margin: EdgeInsets.symmetric(horizontal: 30),
                  //   child: ElevatedButton(
                  //     style: ElevatedButton.styleFrom(
                  //         primary: Colors.pinkAccent,
                  //         shape: RoundedRectangleBorder(
                  //             borderRadius: BorderRadius.circular(30))),
                  //     onPressed: () {},
                  //     child: Text(
                  //       'Change Address',
                  //       style: TextStyle(color: Colors.white),
                  //     ),
                  //   ),
                  // )
                ],
              ),
            ),
          ],
        ),
      ),
      secondaryActions: <Widget>[
        Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Flexible(
                flex: 1,
                child: FloatingActionButton(
                  onPressed: () {
                    ScaffoldMessenger.of(context)
                        .showSnackBar(const SnackBar(content: Text('Edit')));
                  },
                  mini: true,
                  foregroundColor: Colors.black87,
                  backgroundColor: Colors.white,
                  child: const Icon(
                    Icons.edit,
                    size: 16,
                  ),
                )),
            const SizedBox(
              height: 20,
            ),
            Flexible(
                flex: 1,
                child: FloatingActionButton(
                  onPressed: () {
                    ScaffoldMessenger.of(context)
                        .showSnackBar(const SnackBar(content: Text('Deleted')));
                  },
                  mini: true,
                  foregroundColor: Colors.white,
                  backgroundColor: Colors.pinkAccent,
                  child: const Icon(
                    Icons.delete,
                    size: 16,
                  ),
                )),
          ],
        )
      ],
    );
  }
}

class AddressManagerButton extends StatelessWidget {
  const AddressManagerButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 40,
      margin: const EdgeInsets.symmetric(vertical: 30, horizontal: 20),
      child: ElevatedButton(
        onPressed: () {},
        style: ElevatedButton.styleFrom(
            primary: Colors.pinkAccent,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30))),
        child: const Text(
          'Add Address',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}

class AddressEdit extends StatefulWidget {
  const AddressEdit({Key? key,this.addressType,this.isUpdate,this.isDefault,this.snapshot,this.index,this.scrollController}) : super(key: key);
  final int? addressType;
  final int? isUpdate;
  final int? isDefault;
  final AsyncSnapshot<AddressListModel>? snapshot;
  final index;
  final ScrollController? scrollController;


  @override
  _AddressEditState createState() => _AddressEditState();
}

class _AddressEditState extends State<AddressEdit> {
  final GlobalKey<FormState> _addressEditKey = GlobalKey<FormState>();

  List<TempPostCodeModel> tempPostCodeModel = [];
  List<TempStateModel> tempStateModel = [];
  TextEditingController cityController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();

  final TextEditingController _typeAheadController = TextEditingController();
  TextEditingController firstNameController = new TextEditingController();
  TextEditingController lastNameController = new TextEditingController();
  TextEditingController addressLine1Controller = new TextEditingController();
  TextEditingController addressLine2Controller = new TextEditingController();
  TextEditingController countryController = new TextEditingController();
  TextEditingController mobileController = new TextEditingController();



  List<String?> states = [];
  List<String> cities = [];
  int? statePk;
  int? cityPk;
  List<String?> tempPostCodes = [];

  String? firstName;
  String? lastName;
  String? addressLine1;
  String? addressLine2;
  String? mobile;
  String? country;
  String? postCode;
  String? city;
  String? state;

  bool? checkBoxValue = false;
  int? isDefault = 0;

  String? validationFirstName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty First Name!';
    } else {
      return null;
    }
  }

  String? validationLastName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Last Name!';
    } else {
      return null;
    }
  }

  String? validationAddress(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Address!';
    } else {
      return null;
    }
  }

  String? validationCity(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty City!';
    } else {
      return null;
    }
  }

  String? validationMobile(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Mobile!';
    }else if (value.length < 9) {
      return 'Enter valid contact no';
    } else {
      return null;
    }
  }

  String? validationCountry(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Country!';
    } else {
      return null;
    }
  }

  String? validationPostCode(String value) {
    if (value == null || value.isEmpty) {
      return 'Empty Post Code!';
    } else {
      return null;
    }
  }

  //......................................................
  void getPostCode() async {
    PostCodeModel postCodeModel = SharedPreferenceUtils.postCodeModel;
    states.add('Select a state');
    for (var i = 0; i < postCodeModel.data!.length; i++) {
      int m = 0;
      if (postCodeModel.data![i].statename != null &&
          postCodeModel.data![i].fstateno != null &&
          postCodeModel.data![i].pocode != null) {
        TempPostCodeModel temp = TempPostCodeModel(
            postCodeModel.data![i].pocode,
            postCodeModel.data![i].fcityno,
            postCodeModel.data![i].cityname,
            postCodeModel.data![i].statename,
            postCodeModel.data![i].fstateno);
        tempPostCodeModel.add(temp);
        tempPostCodes.add(postCodeModel.data![i].pocode);
      }
      for (var x = 0; x < states.length; x++) {
        if (states[x] == postCodeModel.data![i].statename ||
            postCodeModel.data![i].statename == null ||
            postCodeModel.data![i].fstateno == null ||
            postCodeModel.data![i].pocode == null) {
          m = 1;
        }
      }
      if (m == 0) {
        states.add(postCodeModel.data![i].statename);
        TempStateModel temp = TempStateModel(
            postCodeModel.data![i].statename,
            postCodeModel.data![i].fstateno);
        tempStateModel.add(temp);
      }
    }

  }
  //......................................................

  void setData(){
    if (widget.addressType == 1) {
      firstNameController.text = widget.snapshot!.data!.data!.shippingAddress![widget.index].name!;
      lastNameController.text = widget.snapshot!.data!.data!.shippingAddress![widget.index].lastname!;
      addressLine1Controller.text = widget.snapshot!.data!.data!.shippingAddress![widget.index].addressline1!;
      addressLine2Controller.text = widget.snapshot!.data!.data!.shippingAddress![widget.index].addressline2!;
      countryController.text = widget.snapshot!.data!.data!.shippingAddress![widget.index].country!;
      mobileController.text = widget.snapshot!.data!.data!.shippingAddress![widget.index].telno!;
      cityController.text = widget.snapshot!.data!.data!.shippingAddress![widget.index].city!;
      _typeAheadController.text = widget.snapshot!.data!.data!.shippingAddress![widget.index].postcode!;
      state = widget.snapshot!.data!.data!.shippingAddress![widget.index].state;
      statePk = widget.snapshot!.data!.data!.shippingAddress![widget.index].fstateno;
      cityPk = widget.snapshot!.data!.data!.shippingAddress![widget.index].fcityno;
    } else {
      firstNameController.text = widget.snapshot!.data!.data!.billingAddress!.name!;
      lastNameController.text = widget.snapshot!.data!.data!.billingAddress!.lastname!;
      addressLine1Controller.text = widget.snapshot!.data!.data!.billingAddress!.addressline1!;
      addressLine2Controller.text = widget.snapshot!.data!.data!.billingAddress!.addressline2!;
      countryController.text = widget.snapshot!.data!.data!.billingAddress!.country!;
      mobileController.text = widget.snapshot!.data!.data!.billingAddress!.telno!;
      cityController.text = widget.snapshot!.data!.data!.billingAddress!.city!;
      _typeAheadController.text = widget.snapshot!.data!.data!.billingAddress!.postcode!;
      state = widget.snapshot!.data!.data!.billingAddress!.state;
      statePk = widget.snapshot!.data!.data!.billingAddress!.fstateno;
      cityPk = widget.snapshot!.data!.data!.billingAddress!.fcityno;
    }
  }

  void saveAddress() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Client client = Client();

    /// address type 1 = shipping, 2 = billing.......
    Map<String, dynamic> data = {
      'session': '$session',
      'user_id': '$userId',
      'token': '$token',
      'firstName': '$firstName',
      'lastName': '$lastName',
      'address_line1': '$addressLine1',
      'postCode': '$postCode',
      'mobile': '$mobile',
      'address_line2': '$addressLine2',
      'city_pk': '$cityPk',
      'state_pk': '$statePk',
      'state': '$state',
      'city': '$city',
      'country': '$country',
      'is_update': '${widget.isUpdate}',
      'is_default': '$isDefault',
      'address_type': '${widget.addressType}'
    };
    var requestBody = json.encode(data);

    print(requestBody);
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.SAVE_ADDRESS);
      print('url');
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      print('${body['message']}');
      Common.toastMsg('${body['message']}');
      if (body['status'] == 1) {
        //todo change........
        setState(() {
          _addressEditKey.currentState!.reset();
          _typeAheadController.clear();
          states = [];
          cities = [];
          state = '';
          city = '';

          firstName = '';
          lastName = '';
          addressLine1 = '';
          postCode = '';
          mobile = '';
          addressLine2 = '';
        });
        addressBloc.fetchAllAddress();
      }
    } on FormatException catch (e) {
      print(e);
      Common.toastMsg(e.toString());
    } on Exception catch (e) {
      print(e);
      Common.toastMsg(e.toString());
    }
  }

  @override
  void initState() {
    getPostCode();
    setData();
    checkBoxValue = widget.isDefault == 1 ? true : false;
    isDefault = widget.isDefault;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      scrollDirection: Axis.vertical,
      controller: widget.scrollController,
      shrinkWrap: true,
      slivers: [
        SliverToBoxAdapter(
          child: Container(
            width: double.infinity,
            height: 50,
            decoration: BoxDecoration(
                color: AppsColors.onyxBlack),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: const [
                Icon(Icons.edit,size: 24,color: Colors.white,),
                SizedBox(width: 8,),
                Text(
                  'Edit Address',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight
                          .normal),
                )
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Form(
            key: _addressEditKey,
            autovalidateMode: AutovalidateMode.always,
            child: Column(
              children: [
                const SizedBox(
                  height: 16,
                ),
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextFormField(
                    validator: validationFirstName,
                    textInputAction: TextInputAction.next,
                    controller: firstNameController,
                    onSaved: (String? val) {
                      firstName = val;
                    },
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.symmetric(horizontal: 20),
                      hintText: 'First Name',
                      labelText: 'First Name',
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: const Color(0xFFD0D1D2))),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextFormField(
                    validator: validationLastName,
                    controller: lastNameController,
                    textInputAction: TextInputAction.next,
                    onSaved: (String? val) {
                      lastName = val;
                    },
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                      hintText: 'Last Name',
                      labelText: 'Last Name',
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: const Color(0xFFD0D1D2))),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextFormField(
                    validator: validationAddress,
                    controller: addressLine1Controller,
                    textInputAction: TextInputAction.next,
                    onSaved: (String? val) {
                      addressLine1 = val;
                    },
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                      hintText: 'Address',
                      labelText: 'Address',
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextFormField(
                    textInputAction: TextInputAction.next,
                    controller: addressLine2Controller,
                    onSaved: (val) {
                      setState(() {
                        addressLine2 = val;
                      });
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                      hintText: 'Address line 2(Optional)',
                      labelText: 'Address line 2',
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  width: double.infinity,
                  child: TypeAheadField(
                    textFieldConfiguration: TextFieldConfiguration(
                        controller: _typeAheadController,
                        autofocus: false,
                        style: DefaultTextStyle.of(context).style.copyWith(
                            fontStyle: FontStyle.italic
                        ),
                        decoration: const InputDecoration(
                            labelText: 'post code',
                            border: OutlineInputBorder()
                        )
                    ),
                    transitionBuilder: (context, suggestionsBox, controller) {
                      return suggestionsBox;
                    },
                    suggestionsCallback: (pattern) async {
                      return tempPostCodes
                          .where((item) =>
                          item!.toLowerCase().startsWith(pattern.toLowerCase()))
                          .toList();
                    },
                    itemBuilder: (context, dynamic suggestion) {
                      return ListTile(
                        leading: const Icon(Icons.shopping_cart,size: 20,),
                        title: Text('$suggestion'),
                      );
                    },
                    onSuggestionSelected: (dynamic suggestion) {
                      for (var item in tempPostCodeModel) {
                        if (suggestion.toString().toLowerCase() == item.pocode) {
                          setState(() {
                            _typeAheadController.text = item.pocode!;
                            print('${item.pocode}');
                            postCode = item.pocode;
                            cityPk = item.fcityno;
                            statePk = item.fstateno;
                            state = item.statename;
                            city = item.cityname;
                            cityController.text = item.cityname!;
                          });
                        }
                      }
                    },
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextFormField(
                    controller: cityController,
                    validator: validationCity,
                    textInputAction: TextInputAction.next,
                    onSaved: (String? val) {
                      city = val;
                    },
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                      hintText: 'City',
                      labelText: 'City',
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: DropdownButtonFormField<String>(
                    hint: const Text('Select a state'),
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                    ),
                    focusColor: const Color(0xFFF68721),
                    value: state,
                    icon: const Icon(
                      Icons.arrow_drop_down,
                    ),
                    iconSize: 24,
                    elevation: 3,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Select a state';
                      } else if (value == 'Select a state') {
                        return 'Select a state';
                      } else {
                        return null;
                      }
                    },
                    //underline: SizedBox(),
                    onChanged: (newValue) {
                      setState(() {
                        state = newValue;
                        for (var i = 0; i < tempStateModel.length; i++) {
                          if (newValue == tempStateModel[i].state) {
                            statePk = tempStateModel[i].state_pk;
                          }
                        }
                      });
                    },
                    items: states.map<DropdownMenuItem<String>>((String? value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value!),
                      );
                    }).toList(),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextFormField(
                    enabled: false,
                    initialValue: 'Malaysia',
                    validator: validationCountry,
                    onSaved: (val) {
                      setState(() {
                        country = val;
                      });
                    },
                    decoration: InputDecoration(
                      labelText: 'Country',
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextFormField(
                    validator: validationMobile,
                    controller: mobileController,
                    textInputAction: TextInputAction.done,
                    onSaved: (String? val) {
                      mobile = val;
                    },
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                      hintText: 'Mobile No',
                      labelText: 'Mobile No',
                      prefix: const Text('+60 '),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),

                LayoutBuilder(
                    builder: (BuildContext context, BoxConstraints constraints){
                      if (widget.addressType == 1) {
                        return SizedBox(
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Checkbox(
                                  value: checkBoxValue,
                                  activeColor: Colors.green,
                                  checkColor: Colors.white,
                                  splashRadius: 16,
                                  onChanged: (bool? value){
                                    setState(() {
                                      checkBoxValue = value;
                                    });
                                    if (value!) {
                                      isDefault = 1;
                                    }  else {
                                      isDefault = 0;
                                    }
                                  }
                              ),
                              GestureDetector(
                                onTap: (){
                                  setState(() {
                                    checkBoxValue = !checkBoxValue!;
                                    if (checkBoxValue!) {
                                      isDefault = 1;
                                    } else {
                                      isDefault = 0;
                                    }
                                  });
                                },
                                child: Text('Use as my default delivery address',style: TextStyle(color: checkBoxValue! ? Colors.black87 : Colors.black54,fontSize: 14),),
                              )
                            ],
                          ),
                        );
                      }  else {
                        return const SizedBox(
                          height: 2,
                        );
                      }
                    }
                ),

                Container(
                  width: double.infinity,
                  height: 50,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: ElevatedButton(
                      onPressed: () {
                        if (_addressEditKey.currentState!.validate()) {
                          saveAddress();
                        }
                      },
                      style: ElevatedButton.styleFrom(primary: AppsColors.buttonColor),
                      child: const Text(
                        'Save Address',
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      )),
                )
              ],
            ),
          ),
        )
      ],
    );
  }
}
