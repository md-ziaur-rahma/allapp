import 'dart:io';

import 'package:azuramartmy/address_manager/address_manager_body.dart';
import 'package:azuramartmy/create_address/create_address_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AddressManagerPage extends StatelessWidget {
  const AddressManagerPage({Key? key}) : super(key: key);

  static Route route(){
    return MaterialPageRoute(builder: (_) => const AddressManagerPage());
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Address Book',style: TextStyle(color: Colors.black87),),
        iconTheme: const IconThemeData(color: Colors.black87),
        elevation: 0,
        backgroundColor: Colors.white,
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(statusBarColor: Colors.white,statusBarBrightness: Brightness.dark,statusBarIconBrightness: Brightness.dark),
        actions: [
          IconButton(
            onPressed: (){
              Navigator.push(context, CreateAddressPage.route());
            },
            tooltip: 'Create New Delivery Address',
            icon: const Icon(Icons.add,color: Colors.green,size: 24,),
          )
        ],
      ),
      body: const SafeArea(
        child: AddressManagerBody(),
      ),
    );
  }
}

