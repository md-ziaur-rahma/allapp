import 'package:flutter/foundation.dart';

class AddressManagerNotifier extends ChangeNotifier {
  int shippingGroupValue = 0;
  void changeShippingGroupValue(int value){
    shippingGroupValue = value;
    notifyListeners();
  }
}