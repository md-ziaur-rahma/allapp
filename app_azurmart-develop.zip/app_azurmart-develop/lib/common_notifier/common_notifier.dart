import 'package:flutter/foundation.dart';

class CommonNotifier extends ChangeNotifier{
  bool isLoading = false;
  bool isStock = false;
  void changeLoading(bool value){
    isLoading = value;
    // notifyListeners();
  }

  void changeStock(bool value){
    isStock = value;
    notifyListeners();
  }
}