import 'dart:io';

import 'package:azuramartmy/order_list/order_list_body.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class OrderListPage extends StatelessWidget {
  const OrderListPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const OrderListPage());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Orders',
          style: TextStyle(color: Colors.black87),
        ),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        backgroundColor: Colors.white,
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
      ),
      backgroundColor: const Color(0xFFF4F4F4),
      body: const SafeArea(
        child: OrderListBody(),
      ),
    );
  }
}

