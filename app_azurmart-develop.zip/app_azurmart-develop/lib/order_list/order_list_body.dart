import 'dart:convert';

import 'package:azuramartmy/billplz/redirect_url.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/common_widgets/no_items.dart';
import 'package:azuramartmy/my_bloc/orderlist_bloc.dart';
import 'package:azuramartmy/order_details/order_details_page.dart';
import 'package:azuramartmy/order_list/order_list_notifier.dart';
import 'package:azuramartmy/provider_models/get_payment_order_model.dart';
import 'package:azuramartmy/provider_models/orderlist_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:http/http.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OrderListBody extends StatelessWidget {
  const OrderListBody({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    context.read<OrderListNotifier>().changeIsOrderInGroup(0);
    orderListBloc.fetchAllOrderList(0);
    return StreamBuilder(
        stream: orderListBloc.allOrderList,
        builder: (context, AsyncSnapshot<OrderListModel> snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data!.data!.isNotEmpty) {
              return CustomScrollView(
                scrollDirection: Axis.vertical,
                slivers: [
                  SliverLayoutBuilder(
                    builder:
                        (BuildContext context, SliverConstraints constraints) {
                      if (context.watch<OrderListNotifier>().isOrderInGroup ==
                          1) {
                        return SliverToBoxAdapter(
                          child: GestureDetector(
                            onTap: () {
                              Common.toastMsg('loading...');
                              Provider.of<OrderListNotifier>(context,
                                      listen: false)
                                  .changeIsOrderInGroup(0);
                              orderListBloc.fetchAllOrderList(0);
                            },
                            child: Container(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16),
                              width: double.infinity,
                              height: 45,
                              color: AppsColors.buttonColor,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: const [
                                  Text(
                                    'See all orders',
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 16),
                                  ),
                                  Icon(
                                    Icons.refresh,
                                    color: Colors.white,
                                    size: 20,
                                  )
                                ],
                              ),
                            ),
                          ),
                        );
                      } else {
                        return const SliverToBoxAdapter(
                          child: SizedBox(
                            height: 0,
                          ),
                        );
                      }
                    },
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 16),
                      child: Text(
                        'My Orders (${snapshot.data!.data!.length} items)',
                        style: const TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                  SliverList(
                    delegate: SliverChildBuilderDelegate(
                        (BuildContext context, index) {
                      return OrderListItem(
                        snapshot: snapshot,
                        index: index,
                      );
                    }, childCount: snapshot.data!.data!.length),
                  )
                ],
              );
            } else {
              return const NoItemsCard();
            }
          } else if (snapshot.hasError) {
            return Center(
              child: Text(snapshot.error.toString()),
            );
          }
          return LoadingWidget(
            color: AppsColors.buttonColor,
          );
        });
  }
}

class OrderListItem extends StatelessWidget {
  OrderListItem({Key? key, this.snapshot, this.index}) : super(key: key);
  final AsyncSnapshot<OrderListModel>? snapshot;
  final int? index;

  final f = DateFormat('MMM-dd-yyyy  hh:mm aa');

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      margin: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(6.0),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: const Color(0xFFF4F4F4),
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Order #',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  '${snapshot!.data!.data![index!].orderid}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Source',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  '${snapshot!.data!.data![index!].bookingsalesagentname}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Date',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  f.format(DateTime.parse(snapshot!.data!.data![index!].orderdate!)),
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Created By',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  '${snapshot!.data!.data![index!].createdby}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Expanded(
                  flex: 1,
                  child: Text(
                    'Order To',
                    style: TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                        fontSize: 16),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Text(
                    '${snapshot!.data!.data![index!].orderto}',
                    textAlign: TextAlign.end,
                    style: const TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.normal,
                        fontSize: 16),
                  ),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Order Total',
                  style: TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                Text(
                  'RM${snapshot!.data!.data![index!].totalprice}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.normal,
                      fontSize: 16),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Expanded(
                  flex: 1,
                  child: Text(
                    'Status',
                    style: TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                        fontSize: 16),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Text(
                    '${snapshot!.data!.data![index!].status}',
                    textAlign: TextAlign.end,
                    style: const TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.normal,
                        fontSize: 16),
                  ),
                ),
              ],
            ),
          ),
          const Divider(
            height: 3,
            thickness: 1.0,
            color: Color(0xFFF4F4F4),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(6.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                TextButton(
                  onPressed: () {
                    if (snapshot!.data!.data![index!].isorderingroup == 1) {
                      Common.toastMsg('loading...');
                      orderListBloc.fetchAllOrderList(
                          snapshot!.data!.data![index!].ordergroupid);
                      Provider.of<OrderListNotifier>(context, listen: false)
                          .changeIsOrderInGroup(1);
                    } else {
                      Navigator.of(context).push(
                          CustomRoutePageBuilder.createPageRouteLeft(
                              context,
                              OrderDetailsPage(
                                  orderId:
                                      snapshot!.data!.data![index!].fbookingno)));
                      // Navigator.push(context, OrderDetailsPage.route());
                    }
                  },
                  child: Text(
                    'Order Details',
                    style: TextStyle(color: AppsColors.blueGreenX),
                  ),
                ),
                TextButton.icon(
                  onPressed: () async {
                    int enableIndex = 0;
                    int downPrice = 0;
                    
                    SharedPreferences localStorage =
                        await SharedPreferences.getInstance();
                    String? session =
                        localStorage.getString(SharedPreferenceUtils.SESSION);
                    int? userId =
                        localStorage.getInt(SharedPreferenceUtils.USER_ID);
                    String? token =
                        localStorage.getString(SharedPreferenceUtils.TOKEN);
                    Client client = Client();
                    Uri url = Uri.parse(Urls.baseUrl+Urls.getOrderPayment);
                    print('${snapshot!.data!.data![index!].ordergroupid}');
                    try {
                      var response = await client.post(url, body: {
                        'session': '$session',
                        'user_id': '$userId',
                        'token': '$token',
                        'order_group_id': '${snapshot!.data!.data![index!].ordergroupid}',
                      });
                      print(response.body);
                      if (response.statusCode == 200) {
                        final Map<String, dynamic> body = await json.decode(response.body);
                        GetOrderPaymentModel paymentModel = GetOrderPaymentModel.fromJson(body);
                        if (paymentModel.status == 1) {
                          if (paymentModel.data!.paymentType == 'billplz') {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => RedirectUrl(redirectUrl: paymentModel.data!.url,)));
                          }  else {
                            for (var x = paymentModel.data!.instPayments!.length - 1; x >= 0; x--) {
                              if (paymentModel.data!.instPayments![x].isPaid == 0) {
                                enableIndex = x;
                              }
                            }
                            downPrice = paymentModel.data!.instPayments![enableIndex].calculatedInstallmentAmount!.toInt();
                            List<TextEditingController> _controller = [
                              for (int i = 0; i < paymentModel.data!.instPayments!.length; i++)
                                TextEditingController()
                            ];
                            for(var i = 0; i < paymentModel.data!.instPayments!.length; i++) {
                              _controller[i].text = paymentModel.data!.instPayments![i].calculatedInstallmentAmount!.toStringAsFixed(0).toString();
                            }
                            showModalBottomSheet(
                                shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(16),
                                        topRight: Radius.circular(16))),
                                isScrollControlled: true,
                                context: context,
                                builder: (context) {
                                  return Container(
                                    width: double.infinity,
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 16, vertical: 8),
                                    child: Wrap(
                                      alignment: WrapAlignment.center,
                                      direction: Axis.horizontal,
                                      runSpacing: 10,
                                      spacing: 10,
                                      children: [
                                        for (var i = 0;
                                        i <
                                            paymentModel
                                                .data!.instPayments!.length;
                                        i++)
                                          SizedBox(
                                            width: MediaQuery.of(context)
                                                .orientation ==
                                                Orientation.portrait
                                                ? MediaQuery.of(context)
                                                .size
                                                .width *
                                                0.42
                                                : MediaQuery.of(context)
                                                .size
                                                .height *
                                                0.42,
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                SizedBox(
                                                  // width: double.infinity,
                                                  child: Text(
                                                    i == 0
                                                        ? 'Down Payment'
                                                        : i == 1
                                                        ? '1st Installment'
                                                        : i == 2
                                                        ? '2nd Installment'
                                                        : i == 3
                                                        ? '3rd Installment'
                                                        : i == 4
                                                        ? '4th Installment'
                                                        : i == 5
                                                        ? '5th Installment'
                                                        : i == 6
                                                        ? '6th Installment'
                                                        : '',
                                                    style: const TextStyle(
                                                        color: Colors.black87,
                                                        fontSize: 16),
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                SizedBox(
                                                  width: double.infinity,
                                                  child: TextFormField(
                                                    style: const TextStyle(
                                                        color: Colors.black87,
                                                        fontSize: 18,
                                                        fontWeight:
                                                        FontWeight.w600),
                                                    controller: _controller[i],
                                                    // validator: validationUserName,
                                                    cursorColor: Colors.black87,
                                                    enabled: enableIndex == i
                                                        ? true
                                                        : false,
                                                    // initialValue: paymentModel.data.instPayments[i].calculatedInstallmentAmount.toStringAsFixed(0),
                                                    textInputAction:
                                                    TextInputAction.done,
                                                    onSaved: (String? val) {
                                                      if (val!.isNotEmpty || val != '') {
                                                        downPrice = int.parse(val);
                                                      }
                                                    },
                                                    onChanged: (String val){
                                                      if (val.isNotEmpty && val != '') {
                                                        downPrice = int.parse(val);
                                                      }
                                                    },
                                                    onEditingComplete: () {
                                                      if (_controller[enableIndex].text.isNotEmpty && _controller[enableIndex].text != '' ) {
                                                        int value = int.parse(_controller[enableIndex].text);
                                                        if (value >= paymentModel.data!.due!.toInt()) {
                                                          downPrice = paymentModel.data!.due!.toInt();
                                                          _controller[enableIndex].text = downPrice.toString();
                                                          for(var replace = 0; replace < paymentModel.data!.instPayments!.length; replace++) {
                                                            if (replace > enableIndex) {
                                                              _controller[replace].text = '0';
                                                            }
                                                          }
                                                        }  else if (value <= paymentModel.data!.instPayments![i].calculatedInstallmentAmount!) {
                                                          downPrice = paymentModel.data!.instPayments![enableIndex].calculatedInstallmentAmount!.toInt();
                                                          _controller[enableIndex].text = paymentModel.data!.instPayments![enableIndex].calculatedInstallmentAmount!.toStringAsFixed(0).toString();
                                                          for(var replace = 0; replace < paymentModel.data!.instPayments!.length; replace++) {
                                                            _controller[replace].text = paymentModel.data!.instPayments![replace].calculatedInstallmentAmount!.toStringAsFixed(0).toString();
                                                          }
                                                        } else {
                                                          int difference = value - paymentModel.data!.instPayments![enableIndex].calculatedInstallmentAmount!.toInt();
                                                          downPrice = value;
                                                          for(var xx = 0; xx < paymentModel.data!.instPayments!.length; xx++) {
                                                            if (xx > enableIndex) {
                                                              if (difference >= paymentModel.data!.instPayments![xx].calculatedInstallmentAmount!.toInt()) {
                                                                _controller[xx].text = '0';
                                                                difference -= paymentModel.data!.instPayments![xx].calculatedInstallmentAmount!.toInt();
                                                              } else if (difference > 0) {
                                                                _controller[xx].text = (paymentModel.data!.instPayments![xx].calculatedInstallmentAmount!.toInt() - difference).toString();
                                                                difference -= difference;
                                                              }
                                                            }
                                                          }
                                                        }
                                                      } else {
                                                        downPrice = paymentModel.data!.instPayments![enableIndex].calculatedInstallmentAmount!.toInt();
                                                        _controller[enableIndex].text = paymentModel.data!.instPayments![enableIndex].calculatedInstallmentAmount!.toStringAsFixed(0).toString();
                                                      }
                                                    },
                                                    keyboardType: TextInputType.number,
                                                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                                                    decoration: InputDecoration(
                                                      alignLabelWithHint: true,
                                                      filled: true,
                                                      fillColor: enableIndex == i
                                                          ? Colors.white
                                                          : const Color(0xFFD1D2D3)
                                                          .withOpacity(0.4),
                                                      contentPadding:
                                                      const EdgeInsets.symmetric(
                                                          horizontal: 16,
                                                          vertical: 16),
                                                      hintText: paymentModel
                                                          .data!
                                                          .instPayments![i]
                                                          .calculatedInstallmentAmount!
                                                          .toStringAsFixed(0),
                                                      hintStyle: const TextStyle(
                                                          color: Colors.black54,
                                                          fontSize: 18),
                                                      focusedBorder: enableIndex == i
                                                          ? OutlineInputBorder(borderRadius: BorderRadius.circular(0),
                                                          borderSide: const BorderSide(color: Colors.black))
                                                          : InputBorder.none,
                                                      border: enableIndex == i
                                                          ? OutlineInputBorder(borderRadius: BorderRadius.circular(0),
                                                          borderSide: const BorderSide(color: Color(0xFF000000),width: 1))
                                                          : InputBorder.none,
                                                      // enabledBorder:
                                                      //     InputBorder.none,
                                                      errorBorder:
                                                      InputBorder.none,
                                                      disabledBorder:
                                                      InputBorder.none,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        const SizedBox(
                                          height: 50,
                                        ),
                                        Row(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                                          children: [
                                            Text('Total - ${paymentModel.data!.orderValue!.toStringAsFixed(2)}',style: const TextStyle(color: Colors.black87,fontSize: 18),),
                                            Text('PAID - ${paymentModel.data!.totalPaid!.toStringAsFixed(2)}',style: const TextStyle(color: Colors.black87,fontSize: 18),),
                                          ],
                                        ),
                                        Row(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                                          children: [
                                            Text('Pay - ${downPrice.toStringAsFixed(2)}',style: const TextStyle(color: Colors.black87,fontSize: 18),),
                                            Text('DUE - ${(paymentModel.data!.due! - downPrice).toStringAsFixed(2)}',style: const TextStyle(color: Colors.red,fontSize: 18),),
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                        SizedBox(
                                          height: 45,
                                          width: double.infinity,
                                          child: ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                primary: AppsColors.buttonColor),
                                            onPressed: () async {
                                              if (downPrice >= paymentModel.data!.instPayments![enableIndex].calculatedInstallmentAmount!.toInt()) {
                                                Uri url = Uri.parse(Urls.baseUrl+Urls.postOrderPayment);
                                                try {
                                                  var response = await client.post(url, body: {
                                                    'session': '$session',
                                                    'user_id': '$userId',
                                                    'token': '$token',
                                                    'order_group_id': '${snapshot!.data!.data![index!].ordergroupid}',
                                                    'amount': '$downPrice',
                                                  });
                                                  print(response.body);
                                                  if (response.statusCode == 200) {
                                                    final Map<String, dynamic> body = await json.decode(response.body);
                                                    if (body["status"] == 1) {
                                                      Navigator.push(context, MaterialPageRoute(builder: (_) => RedirectUrl(redirectUrl: body["data"]["url"],)));
                                                    }  else{

                                                    }
                                                  }
                                                } on Exception catch (e) {
                                                  print(e);
                                                }
                                              }
                                            },
                                            child: const Text('Pay Installment'),
                                          ),
                                        )
                                      ],
                                    ),
                                  );
                                });
                          }

                        }
                      } else {
                        throw Exception('Failed to load post');
                      }
                    } on Exception catch (e) {
                      print(e);
                    }
                  },
                  icon: Icon(
                    Icons.attach_money,
                    color: AppsColors.blueGreenX,
                  ),
                  label: Text(
                    'Pay',
                    style: TextStyle(color: AppsColors.blueGreenX),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
