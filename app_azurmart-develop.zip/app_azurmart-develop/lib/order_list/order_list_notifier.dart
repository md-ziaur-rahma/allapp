import 'package:flutter/foundation.dart';

class OrderListNotifier extends ChangeNotifier {
  int isOrderInGroup = 0;
  void changeIsOrderInGroup(int value){
    isOrderInGroup = value;
    // notifyListeners();
  }
}