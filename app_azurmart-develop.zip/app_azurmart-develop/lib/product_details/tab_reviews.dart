import 'package:flutter/material.dart';
// import 'package:percent_indicator/linear_percent_indicator.dart';

class DetailsReview extends StatelessWidget {
  List<String> colors = ['BLACK', 'BLUE', 'RED', 'GREEN'];

  DetailsReview({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Row(
            children: [
              const Text(
                'Ratings',
                style: TextStyle(color: Colors.black87),
              ),
              const Spacer(),
              OutlinedButton(
                  style: OutlinedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      side: const BorderSide(width: 2, color: Colors.red),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(24))),
                  onPressed: () {},
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Text(
                      'Rate Now',
                      style: TextStyle(color: Colors.red, fontSize: 10),
                    ),
                  ))
            ],
          ),
        ),
        SizedBox(
          width: double.infinity,
          height: MediaQuery.of(context).size.width * 0.25,
          child: Row(
            children: [
              Expanded(
                  flex: 1,
                  child: Center(
                    child: Container(
                      height: MediaQuery.of(context).size.width * 0.25,
                      width: MediaQuery.of(context).size.width * 0.25,
                      decoration: const ShapeDecoration(
                          shape: CircleBorder(), color: Color(0xFFECECEC)),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              Text(
                                '3.5',
                                style: TextStyle(
                                    color: Colors.black, fontSize: 14),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 5),
                                child: Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                  size: 20,
                                ),
                              )
                            ],
                          ),
                          const Center(
                            child: Text(
                              '122 Ratings',
                              style: TextStyle(
                                  color: Colors.black54, fontSize: 10),
                            ),
                          )
                        ],
                      ),
                    ),
                  )),
              Expanded(
                  flex: 2,
                  child: Row(
                    children: [
                      const SizedBox(width: 8,),
                      Column(
                        mainAxisSize: MainAxisSize.max,
                        children: const [
                          Expanded(
                            flex: 1,
                            child: Center(
                              child: Text(
                                "5",
                                style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Center(
                              child: Text(
                                "4",
                                style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Center(
                              child: Text(
                                "3",
                                style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Center(
                              child: Text(
                                "2",
                                style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Center(
                              child: Text(
                                "1",
                                style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(width: 8,),
                      Column(
                        mainAxisSize: MainAxisSize.max,
                        children: const [
                          Expanded(child: Icon(Icons.star,color: Colors.amber,size: 14,)),
                          Expanded(child: Icon(Icons.star,color: Colors.amber,size: 14,)),
                          Expanded(child: Icon(Icons.star,color: Colors.amber,size: 14,)),
                          Expanded(child: Icon(Icons.star,color: Colors.amber,size: 14,)),
                          Expanded(child: Icon(Icons.star,color: Colors.amber,size: 14,)),
                        ],
                      ),
                      const SizedBox(width: 8,),
                      Column(
                        mainAxisSize: MainAxisSize.max,
                        children: const [
                          // Expanded(
                          //   flex: 1,
                          //   child: Center(
                          //     child: LinearPercentIndicator(
                          //       width: MediaQuery.of(context).size.width * 0.3,
                          //       lineHeight: 5.0,
                          //       percent: 0.8,
                          //       progressColor: Colors.green,
                          //     ),
                          //   ),
                          // ),
                          // Expanded(
                          //   flex: 1,
                          //   child: Center(
                          //     child: LinearPercentIndicator(
                          //       width: MediaQuery.of(context).size.width * 0.3,
                          //       lineHeight: 5.0,
                          //       percent: 0.7,
                          //       progressColor: Colors.green,
                          //     ),
                          //   ),
                          // ),
                          // Expanded(
                          //   flex: 1,
                          //   child: Center(
                          //     child: LinearPercentIndicator(
                          //       width: MediaQuery.of(context).size.width * 0.3,
                          //       lineHeight: 5.0,
                          //       percent: 0.5,
                          //       progressColor: Colors.amber,
                          //     ),
                          //   ),
                          // ),
                          // Expanded(
                          //   flex: 1,
                          //   child: Center(
                          //     child: LinearPercentIndicator(
                          //       width: MediaQuery.of(context).size.width * 0.3,
                          //       lineHeight: 5.0,
                          //       percent: 0.35,
                          //       progressColor: Colors.red,
                          //     ),
                          //   ),
                          // ),
                          // Expanded(
                          //   flex: 1,
                          //   child: Center(
                          //     child: LinearPercentIndicator(
                          //       width: MediaQuery.of(context).size.width * 0.3,
                          //       lineHeight: 5.0,
                          //       percent: 0.2,
                          //       progressColor: Colors.red,
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),
                      const SizedBox(width: 8,),
                      Column(
                        children: const [
                          Expanded(child: Center(
                            child: Text('80',style: TextStyle(fontSize: 9,color: Colors.black54),),
                          )),
                          Expanded(child: Center(
                            child: Text('70',style: TextStyle(fontSize: 9,color: Colors.black54),),
                          )),
                          Expanded(child: Center(
                            child: Text('55',style: TextStyle(fontSize: 9,color: Colors.black54),),
                          )),
                          Expanded(child: Center(
                            child: Text('35',style: TextStyle(fontSize: 9,color: Colors.black54),),
                          )),
                          Expanded(child: Center(
                            child: Text('20',style: TextStyle(fontSize: 9,color: Colors.black54),),
                          )),
                        ],
                      )
                    ],
                  ))
            ],
          ),
        )
      ],
    );
  }
}
