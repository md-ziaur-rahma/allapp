import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/cart/cart_page.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/floating_action_button.dart';
import 'package:azuramartmy/my_bloc/cart_count_bloc.dart';
import 'package:azuramartmy/product_details/product_details_body.dart';
import 'package:azuramartmy/provider_models/best_sell_model.dart';
import 'package:azuramartmy/provider_models/cart_count_model.dart';
import 'package:azuramartmy/provider_models/offer_model.dart';
import 'package:azuramartmy/provider_models/product_details_model.dart';
import 'package:azuramartmy/search/search_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:azuramartmy/wishlist/add_to_wish.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:http/http.dart';
import 'package:optimized_cached_image/optimized_cached_image.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class ProductDetailsPage extends StatefulWidget {
  const ProductDetailsPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const ProductDetailsPage());
  }

  static String? productUrl;

  static int? stockInfo;
  static int? productPk;
  static int? frdMasterSetupNo;
  static int qty = 0;
  static int? F_PRD_VARIANT_NO;
  static int? F_INV_WAREHOUSE_NO;
  static int? F_SHIPPMENT_NO;
  static double? REGULAR_PRICE;
  static double? INSTALLMENT_PRICE;

  static bool isStock = false;
  static int? isWish = 0;
  static int? variantPk;

  /// ........................................
  static int? stockInfoRG = -1;
  static int itemQty = 1;
  static ProductDetailsModel productDetailsModel = ProductDetailsModel();

  static int isAddedToCart = 1;

  @override
  _ProductDetailsPageState createState() => _ProductDetailsPageState();
}

class _ProductDetailsPageState extends State<ProductDetailsPage> {
  void clearData() {
    ProductDetailsPage.stockInfo = -1;
    ProductDetailsPage.productPk = 0;
    ProductDetailsPage.frdMasterSetupNo = 0;
    ProductDetailsPage.qty = 1;
    ProductDetailsPage.stockInfoRG = -1;
    ProductDetailsPage.itemQty = 1;
    ProductDetailsPage.F_PRD_VARIANT_NO = 0;
    ProductDetailsPage.F_INV_WAREHOUSE_NO = 0;
    ProductDetailsPage.F_SHIPPMENT_NO = 0;
    ProductDetailsPage.REGULAR_PRICE = 0;
    ProductDetailsPage.INSTALLMENT_PRICE = 0;
  }

  bool checkCartInfo() {
    if (ProductDetailsPage.stockInfo == -1) {
      Common.toastMsg('Choose a warehouse');
      return false;
    }
    return true;
  }

  @override
  void initState() {
    _isVisible = true;
    ProductDetailsPage.isAddedToCart = 1;
    clearData();
    super.initState();
  }

  getSession() async {
    SharedPreferences storage = await SharedPreferences.getInstance();
    String? session = storage.getString(SharedPreferenceUtils.SESSION);
    Common.toastMsg(session);
    print(session);
  }

  bool _isVisible = true;

  openWhatsApp(String phone, String message) async {
    String profile = url(phone, message);
    if (canLaunch(profile) != null) {
      await launch(profile, forceSafariVC: false, forceWebView: false);
    } else {
      throw 'Could not launch $profile';
    }
  }

  String url(String phone, String message) {
    if (Platform.isAndroid) {
      return "https://wa.me/$phone/?text=${Uri.parse(message)}"; // new line
    } else {
      return "https://api.whatsapp.com/send?phone=$phone=${Uri.parse(message)}"; // new line
    }
  }

  /// ............. Best Selling products ................
  BestSellModel bestSellModel = SharedPreferenceUtils.bestSellModel;
  OfferModel offerModel = SharedPreferenceUtils.offerModel;

  @override
  Widget build(BuildContext context) {
    cartCountBloc.fetchAllCartCount();
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Azura Mart',
          style: TextStyle(color: Colors.black87),
        ),
        backgroundColor: Colors.white,
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarBrightness: Brightness.dark,
            statusBarIconBrightness: Brightness.dark),
        elevation: 0,
        actions: [
          Ink(
            decoration: const ShapeDecoration(
              color: Color(0xFFFFFFFF),
              shape: CircleBorder(),
            ),
            child: IconButton(
              onPressed: () {
                setState(() {
                  Navigator.push(context, SearchPage.route());
                });
              },
              icon: const Icon(
                Icons.search,
                size: 24,
                color: Colors.black87,
              ),
            ),
          ),
          // Stack(
          //   children: [
          //     SizedBox(
          //       height: double.infinity,
          //       child: Ink(
          //         decoration: ShapeDecoration(
          //           color: Color(0xFFFFFFFF),
          //           shape: CircleBorder(),
          //         ),
          //         child: IconButton(
          //             onPressed: () async {
          //               try {
          //                 final result =
          //                     await InternetAddress.lookup('example.com');
          //                 if (result.isNotEmpty &&
          //                     result[0].rawAddress.isNotEmpty) {
          //                   Navigator.push(context, CartPage.route());
          //                 }
          //               } on SocketException catch (_) {
          //                 Common.toastMsg('No Internet Connection');
          //               }
          //             },
          //             icon: Icon(
          //               Icons.shopping_cart_outlined,
          //               size: 20,
          //               color: Colors.black,
          //             )),
          //       ),
          //     ),
          //     Positioned(
          //       right: 12,
          //       bottom: 12,
          //       child: StreamBuilder(
          //         stream: cartBloc.allCarts,
          //         builder: (context, AsyncSnapshot<CartModel> snapshot) {
          //           if (snapshot.hasData) {
          //             return Container(
          //               padding: const EdgeInsets.all(4.0),
          //               decoration: ShapeDecoration(
          //                   shape: CircleBorder(), color: Color(0xFFF68721)),
          //               child: Text(
          //                 '${snapshot.data.data.length}',
          //                 textAlign: TextAlign.center,
          //                 style: TextStyle(fontSize: 8, color: Colors.white),
          //               ),
          //             );
          //           }
          //           return Text('');
          //         },
          //       ),
          //     )
          //   ],
          // ),
        ],
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: ProductDetailsBody(
        productUrl: ProductDetailsPage.productUrl,
        bestSellModel: bestSellModel,
        offerModel: offerModel,
      ),
      bottomNavigationBar: Container(
        height: 80,
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
                topRight: Radius.circular(16.0),
                topLeft: Radius.circular(16.0))),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: SizedBox(
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: AppsColors.buttonColor,
                      elevation: 0,
                      onPrimary: Colors.red.withOpacity(0.4)),
                  onPressed: () async {
                    try {
                      final result =
                          await InternetAddress.lookup('example.com');
                      if (result.isNotEmpty &&
                          result[0].rawAddress.isNotEmpty) {
                        if (ProductDetailsPage.isStock) {
                          showModalBottomSheet(
                              enableDrag: true,
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(16),
                                      topRight: Radius.circular(16))),
                              isScrollControlled: true,
                              isDismissible: true,
                              context: context,
                              builder: (context){
                                return DraggableScrollableSheet(
                                    expand: false,
                                    builder: (context, scrollController){
                                      return BuildWarehouseDialog(scrollController: scrollController,);
                                    }
                                );
                              }
                          );


                          // showDialog(
                          //     // barrierColor: Color(0xFFF68721).withOpacity(0.2),
                          //     useSafeArea: true,
                          //     context: context,
                          //     builder: (context) {
                          //       return AlertDialog(
                          //         // scrollable: true,
                          //         contentPadding:
                          //             const EdgeInsets.symmetric(horizontal: 8),
                          //         content: BuildWarehouseDialog(),
                          //       );
                          //     });
                        } else {
                          Common.toastMsg('Out Of Stock');
                        }
                      }
                    } on SocketException catch (_) {
                      Common.toastMsg('No Internet Connection');
                    }
                  },
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: const [
                      Icon(
                        Icons.add_shopping_cart,
                        color: Colors.white,
                        size: 20,
                      ),
                      SizedBox(
                        width: 8,
                      ),
                      Text(
                        'ADD TO CART',
                        style: TextStyle(color: Colors.white, fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            Expanded(
              child: SizedBox(
                height: 50,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                      primary: Colors.white,
                      elevation: 0,
                      backgroundColor: Colors.white,
                      side: BorderSide(
                          width: 1.0,
                          color: AppsColors.buttonColor,
                          style: BorderStyle.solid),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(3.0))),
                  onPressed: () async {
                    try {
                      final result =
                          await InternetAddress.lookup('example.com');
                      if (result.isNotEmpty &&
                          result[0].rawAddress.isNotEmpty) {
                        setState(() {
                          if (ProductDetailsPage.isAddedToCart == 1) {
                            Navigator.push(context, CartPage.route());
                          } else {
                            ProductDetailsPage.isWish =
                                ProductDetailsPage.isWish == 0 ? 1 : 0;
                            AddToWish addWish = AddToWish();
                            addWish.addToWish(ProductDetailsPage.variantPk);
                          }
                        });
                      }
                    } on SocketException catch (_) {
                      Common.toastMsg('No Internet Connection');
                    }
                  },
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      ProductDetailsPage.isAddedToCart == 1
                          ? Icon(
                              Icons.shopping_cart_outlined,
                              size: 20,
                              color: AppsColors.buttonColor,
                            )
                          : ProductDetailsPage.isWish == 0
                              ? Icon(
                                  Icons.favorite_outline,
                                  size: 20,
                                  color: AppsColors.buttonColor,
                                )
                              : Icon(
                                  Icons.favorite,
                                  size: 20,
                                  color: AppsColors.buttonColor,
                                ),
                      const SizedBox(
                        width: 8,
                      ),
                      StreamBuilder(
                        stream: cartCountBloc.allCartCount,
                        builder: (context, AsyncSnapshot<CartCountModel> snapshot) {
                          if (snapshot.hasData) {
                            return Text(
                              ProductDetailsPage.isAddedToCart == 1
                                  ? 'My Cart (${snapshot.data!.data!.cartqtycount})'
                                  : ProductDetailsPage.isWish == 0
                                      ? 'ADD TO WISH'
                                      : 'ADDED TO WISH',
                              style: TextStyle(
                                  color: AppsColors.buttonColor, fontSize: 14),
                            );
                          }
                          return const Text('');
                        },
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
      floatingActionButton: MyFloatingActionButton(
        snapshot: SharedPreferenceUtils.whatsappModel,
      ),
    );
  }
}

class BuildWarehouseDialog extends StatefulWidget {
  const BuildWarehouseDialog({Key? key,this.scrollController}) : super(key: key);
  final ScrollController? scrollController;

  @override
  _BuildWarehouseDialogState createState() => _BuildWarehouseDialogState();
}

class _BuildWarehouseDialogState extends State<BuildWarehouseDialog> {
  String getDays(String date) {
    DateTime dob = DateTime.parse(date);
    Duration dur = dob.difference(DateTime.now());
    int differenceDays = dur.inDays;
    return differenceDays <= 0 ? '7' : differenceDays.toString();
  }

  bool checkCartInfo() {
    if (ProductDetailsPage.stockInfo == -1) {
      Common.toastMsg('Choose a warehouse');
      return false;
    }
    return true;
  }

  void clearData() {
    ProductDetailsPage.stockInfo = -1;
    ProductDetailsPage.productPk = 0;
    ProductDetailsPage.frdMasterSetupNo = 0;
    ProductDetailsPage.qty = 1;
    ProductDetailsPage.stockInfoRG = -1;
    ProductDetailsPage.itemQty = 1;
    ProductDetailsPage.F_PRD_VARIANT_NO = 0;
    ProductDetailsPage.F_INV_WAREHOUSE_NO = 0;
    ProductDetailsPage.F_SHIPPMENT_NO = 0;
    ProductDetailsPage.REGULAR_PRICE = 0;
    ProductDetailsPage.INSTALLMENT_PRICE = 0;
  }

  Future<void> addToCart(BuildContext context) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Map<String, dynamic> data = {
      'PK_NO': ProductDetailsPage.productPk,
      'qty': ProductDetailsPage.qty,
      'user_id': '$userId',
      'token': '$token',
      'F_PRD_MASTER_SETUP_NO': ProductDetailsPage.frdMasterSetupNo,
      'session': session,
      'F_PRD_VARIANT_NO': ProductDetailsPage.F_PRD_VARIANT_NO,
      'F_INV_WAREHOUSE_NO': ProductDetailsPage.F_INV_WAREHOUSE_NO,
      'F_SHIPPMENT_NO': ProductDetailsPage.F_SHIPPMENT_NO,
      'REGULAR_PRICE': ProductDetailsPage.REGULAR_PRICE,
      'INSTALLMENT_PRICE': ProductDetailsPage.INSTALLMENT_PRICE,
    };
    var requestBody = json.encode(data);
    Client client = Client();
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.ADD_TO_CART);
      print('url');
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      print('${body['message']}');
      // Common.toastMsg('${body['message']}');
      if (body['status'] == 1) {
        clearData();
        setState(() {
          ProductDetailsPage.isAddedToCart = 1;
        });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text(
            'Added To Cart',
            style: TextStyle(color: Color(0xFFFFFFFF)),
          ),
          backgroundColor: AppsColors.onyxBlack,
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.symmetric(horizontal: 16),
          duration: const Duration(seconds: 3),
        ));
        Navigator.pop(context);
        cartCountBloc.fetchAllCartCount();
      } else {
        clearData();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
            '${body['message']}',
            style: const TextStyle(color: Color(0xFFFFFFFF)),
          ),
          backgroundColor: AppsColors.onyxBlack,
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.symmetric(horizontal: 16),
          duration: const Duration(seconds: 4),
        ));
        Navigator.pop(context);
        cartCountBloc.fetchAllCartCount();
      }
    } on FormatException catch (e) {
      print(e);
      Common.toastMsg(e.toString());
    } on Exception catch (e) {
      print(e);
      Common.toastMsg(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).orientation == Orientation.portrait ? MediaQuery.of(context).size.height * 0.6 : MediaQuery.of(context).size.width * 0.9,
      width: MediaQuery.of(context).orientation == Orientation.portrait ? double.infinity : MediaQuery.of(context).size.width * 0.5,
      child: CustomScrollView(
        scrollDirection: Axis.vertical,
        controller: widget.scrollController,
        shrinkWrap: true,
        slivers: [
          SliverToBoxAdapter(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Expanded(
                        flex: 1,
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(
                            maxHeight: 140,
                            minHeight: 60,
                          ),
                          child: OptimizedCacheImage(
                            imageUrl: Urls.basePictureUrl +
                                ProductDetailsPage.productDetailsModel.data!
                                    .img![0].relativepath!,
                            imageBuilder: (context, imageProvider) => Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: imageProvider,
                                  // fit: BoxFit.cover,
                                  // colorFilter: ColorFilter.mode(Colors.transparent, BlendMode.clear)
                                ),
                              ),
                            ),
                            placeholder: (context, url) => const Center(
                              child: SizedBox(
                                height: 16,
                                width: 16,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.0,
                                  valueColor:
                                  AlwaysStoppedAnimation(Color(0xFFF68721)),
                                ),
                              ),
                            ),
                            errorWidget: (context, url, error) =>
                            const Icon(Icons.error),
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 8,
                      ),
                      Expanded(
                        flex: 2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(
                              child: Text(
                                '${ProductDetailsPage.productDetailsModel.data!.product!.variantname}',
                                maxLines: 3,
                                style: const TextStyle(
                                    color: Colors.black87, fontSize: 16),
                              ),
                            ),
                            const SizedBox(
                              height: 4,
                            ),
                            SizedBox(
                              child: Text(
                                'RM${ProductDetailsPage.productDetailsModel.data!.product!.regularprice!.toStringAsFixed(2)}',
                                maxLines: 1,
                                style: const TextStyle(
                                    color: Color(0xFFF68721),
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600),
                              ),
                            ),
                            const SizedBox(
                              height: 4,
                            ),
                            SizedBox(
                              child: Text(
                                '${ProductDetailsPage.productDetailsModel.data!.product!.sizename} - ${ProductDetailsPage.productDetailsModel.data!.product!.color}',
                                maxLines: 2,
                                style: const TextStyle(
                                    color: Colors.black87, fontSize: 14),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      for (var i = 0;
                      i <
                          ProductDetailsPage
                              .productDetailsModel.data!.stockInfo!.length;
                      i++)
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              /// this is for instant change...
                              ProductDetailsPage.stockInfoRG = i;
                              print('${ProductDetailsPage.stockInfoRG}');

                              /// change in main page...
                              ProductDetailsPage.stockInfo = i;
                              ProductDetailsPage.productPk = ProductDetailsPage
                                  .productDetailsModel.data!.product!.pkno;
                              ProductDetailsPage.frdMasterSetupNo =
                                  ProductDetailsPage.productDetailsModel.data!
                                      .stockInfo![i].fprdmasterno;
                              ProductDetailsPage.F_INV_WAREHOUSE_NO =
                                  ProductDetailsPage.productDetailsModel.data!
                                      .stockInfo![i].finvwarehouseno;
                              ProductDetailsPage.F_SHIPPMENT_NO =
                                  ProductDetailsPage.productDetailsModel.data!
                                      .stockInfo![i].fshippmentno;
                              ProductDetailsPage.F_PRD_VARIANT_NO =
                                  ProductDetailsPage.productDetailsModel.data!
                                      .stockInfo![i].fprdvariantno;
                              ProductDetailsPage.REGULAR_PRICE =
                                  ProductDetailsPage.productDetailsModel.data!
                                      .product!.regularprice;
                              ProductDetailsPage.INSTALLMENT_PRICE =
                                  ProductDetailsPage.productDetailsModel.data!
                                      .product!.installmentprice;
                            });
                          },
                          child: ListTile(
                            title: Text(
                              ProductDetailsPage.productDetailsModel.data!
                                  .stockInfo![i].shipmenttype ==
                                  null
                                  ? ProductDetailsPage.productDetailsModel.data!
                                  .stockInfo![i].finvwarehouseno ==
                                  1
                                  ? 'UK ETA 90+ days (${ProductDetailsPage.productDetailsModel.data!.stockInfo![i].total! > 10 ? 'More than 10 available' : 'Only ${ProductDetailsPage.productDetailsModel.data!.stockInfo![i].total} available'})'
                                  : 'Ready Stock (${ProductDetailsPage.productDetailsModel.data!.stockInfo![i].total! > 10 ? 'More than 10 available' : 'Only ${ProductDetailsPage.productDetailsModel.data!.stockInfo![i].total} available'})'
                                  : ProductDetailsPage.productDetailsModel.data!
                                  .stockInfo![i].finvwarehouseno ==
                                  2
                                  ? 'Ready Stock (${ProductDetailsPage.productDetailsModel.data!.stockInfo![i].total! > 10 ? 'More than 10 available' : 'Only ${ProductDetailsPage.productDetailsModel.data!.stockInfo![i].total} available'})'
                                  : ProductDetailsPage
                                  .productDetailsModel
                                  .data!
                                  .stockInfo![i]
                                  .shipmentstatus ==
                                  10
                                  ? 'UK ETA 90+ days (${ProductDetailsPage.productDetailsModel.data!.stockInfo![i].total! > 10 ? 'More than 10 available' : 'Only ${ProductDetailsPage.productDetailsModel.data!.stockInfo![i].total} available'})'
                                  : 'In Transit ETA  ${getDays(ProductDetailsPage.productDetailsModel.data!.stockInfo![i].scharrivaldate!)} days (${ProductDetailsPage.productDetailsModel.data!.stockInfo![i].total! > 10 ? 'More than 10 available' : 'Only ${ProductDetailsPage.productDetailsModel.data!.stockInfo![i].total} available'})',
                              style: TextStyle(
                                  color: ProductDetailsPage.stockInfoRG == i
                                      ? const Color(0xFFF68721)
                                      : Colors.black87),
                            ),
                            trailing: ProductDetailsPage.productDetailsModel.data!
                                .stockInfo![i].shipmenttype ==
                                null
                                ? ProductDetailsPage.productDetailsModel.data!
                                .stockInfo![i].finvwarehouseno ==
                                1
                                ? const Image(
                              image: AssetImage(
                                'images/british_icon.gif',
                              ),
                              width: 24,
                              height: 16,
                            )
                                : const Image(
                              image: AssetImage(
                                'images/malaysia_icon.gif',
                              ),
                              width: 24,
                              height: 16,
                            )
                                : ProductDetailsPage.productDetailsModel.data!
                                .stockInfo![i].finvwarehouseno ==
                                2
                                ? const Image(
                              image: AssetImage(
                                'images/malaysia_icon.gif',
                              ),
                              width: 24,
                              height: 16,
                            )
                                : ProductDetailsPage.productDetailsModel.data!
                                .stockInfo![i].shipmentstatus ==
                                10
                                ? Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment:
                              MainAxisAlignment.center,
                              children: const [
                                Image(
                                  image: AssetImage(
                                    'images/british_icon.gif',
                                  ),
                                  width: 24,
                                  height: 16,
                                ),
                                Image(
                                  image: AssetImage(
                                    'images/box.png',
                                  ),
                                  width: 24,
                                  height: 16,
                                )
                              ],
                            )
                                : ProductDetailsPage
                                .productDetailsModel
                                .data!
                                .stockInfo![i]
                                .shipmenttype ==
                                "AIR"
                                ? const Icon(
                              (Icons.airplanemode_active),
                              size: 20,
                              color: Colors.black87,
                            )
                                : const Image(
                              image: AssetImage(
                                'images/ship_icon.png',
                                // 'images/cargo_iconn.gif',
                              ),
                              width: 24,
                              height: 16,
                            ),
                            minLeadingWidth: 24,
                            horizontalTitleGap: 0,
                            hoverColor: const Color(0xFFF68721).withOpacity(0.5),
                            focusColor: const Color(0xFFF68721).withOpacity(0.5),
                            leading: Radio(
                              value: i,
                              groupValue: ProductDetailsPage.stockInfoRG,
                              activeColor: const Color(0xFFF68721),
                              onChanged: i == ProductDetailsPage.stockInfoRG
                                  ? null
                                  : (int? value) {
                                setState(() {
                                  /// this is for instant change...
                                  ProductDetailsPage.stockInfoRG = value;

                                  /// change in main page...
                                  ProductDetailsPage.stockInfo = value;
                                  ProductDetailsPage.productPk =
                                      ProductDetailsPage.productDetailsModel
                                          .data!.product!.pkno;
                                  ProductDetailsPage.frdMasterSetupNo =
                                      ProductDetailsPage.productDetailsModel
                                          .data!.stockInfo![i].fprdmasterno;
                                  ProductDetailsPage.F_INV_WAREHOUSE_NO =
                                      ProductDetailsPage
                                          .productDetailsModel
                                          .data!
                                          .stockInfo![i]
                                          .finvwarehouseno;
                                  ProductDetailsPage.F_SHIPPMENT_NO =
                                      ProductDetailsPage.productDetailsModel
                                          .data!.stockInfo![i].fshippmentno;
                                  ProductDetailsPage.F_PRD_VARIANT_NO =
                                      ProductDetailsPage.productDetailsModel
                                          .data!.stockInfo![i].fprdvariantno;
                                  ProductDetailsPage.REGULAR_PRICE =
                                      ProductDetailsPage.productDetailsModel
                                          .data!.product!.regularprice;
                                  ProductDetailsPage.INSTALLMENT_PRICE =
                                      ProductDetailsPage.productDetailsModel
                                          .data!.product!.installmentprice;
                                  // ProductDetailsPage.paymentMethod = -1;

                                  /// clear payment method;
                                  // paymentMethodRG = -1;
                                });
                              },
                            ),
                          ),
                        ),
                    ],
                  ),
                  LayoutBuilder(builder:
                      (BuildContext context, BoxConstraints constraints) {
                    if (ProductDetailsPage.stockInfoRG == -1) {
                      return const Text('');
                    } else {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 3),
                        margin: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(3),
                            border:
                            Border.all(color: const Color(0xFFF4F4F4), width: 2),
                            color: Colors.transparent),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            IconButton(
                                onPressed: ProductDetailsPage.itemQty > 1
                                    ? () {
                                  setState(() {
                                    ProductDetailsPage.itemQty -= 1;
                                    ProductDetailsPage.qty -= 1;
                                        // (ProductDetailsPage.qty! -= 1);
                                  });
                                }
                                    : null,
                                icon: const Icon(
                                  Icons.remove,
                                  color: Colors.black54,
                                  size: 24,
                                )),
                            const SizedBox(
                              width: 16,
                            ),
                            Text(
                              '${ProductDetailsPage.itemQty}',
                              style: const TextStyle(
                                  color: Colors.black87,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(
                              width: 16,
                            ),
                            IconButton(
                                onPressed: ProductDetailsPage.itemQty <
                                    ProductDetailsPage
                                        .productDetailsModel
                                        .data!
                                        .stockInfo![
                                    ProductDetailsPage.stockInfoRG!]
                                        .total!
                                    ? () {
                                  setState(() {
                                    ProductDetailsPage.itemQty += 1;
                                    ProductDetailsPage.qty +=1;
                                    // = (ProductDetailsPage.qty! += 1);
                                  });
                                }
                                    : null,
                                icon: const Icon(
                                  Icons.add,
                                  color: Colors.black54,
                                  size: 24,
                                )),
                          ],
                        ),
                      );
                    }
                  }),
                  const SizedBox(
                    height: 16,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 12,
                      ),
                      Expanded(
                          flex: 1,
                          child: SizedBox(
                            height: 45,
                            child: OutlinedButton(
                              style: OutlinedButton.styleFrom(
                                  primary: Colors.white,
                                  elevation: 0,
                                  backgroundColor: Colors.white,
                                  side: const BorderSide(
                                      width: 1.0,
                                      color: Color(0xFFF68721),
                                      style: BorderStyle.solid),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(3.0))),
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: const Text(
                                'Cancel',
                                style: TextStyle(
                                    color: Color(0xFFF68721), fontSize: 14),
                              ),
                            ),
                          )),
                      const SizedBox(
                        width: 12,
                      ),
                      Expanded(
                          flex: 1,
                          child: SizedBox(
                            height: 45,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  primary: const Color(0xFFF68721),
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(0))),
                              onPressed: () {
                                if (ProductDetailsPage.isStock) {
                                  if (checkCartInfo()) {
                                    addToCart(context);
                                    print(
                                        '.............reach to the context...........');
                                  }
                                } else {
                                  Common.toastMsg('Out Of Stock');
                                }
                              },
                              child: const Text(
                                'Add to cart',
                                style:
                                TextStyle(color: Colors.white, fontSize: 14),
                              ),
                            ),
                          )),
                      const SizedBox(
                        width: 12,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 16,
            ),
          )
        ],
      ),
    );
  }
}
