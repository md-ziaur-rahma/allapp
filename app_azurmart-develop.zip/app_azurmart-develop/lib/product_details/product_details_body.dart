import 'dart:io';

import 'package:azuramartmy/brand_details/brand_details_chngenotifier.dart';
import 'package:azuramartmy/brand_details/brand_details_page.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/home/home_body.dart';
import 'package:azuramartmy/my_bloc/brand_product_bloc.dart';
import 'package:azuramartmy/my_bloc/product_details_bloc.dart';
import 'package:azuramartmy/offer_details/offer_details_page.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/best_sell_model.dart';
import 'package:azuramartmy/provider_models/offer_model.dart';
import 'package:azuramartmy/show_image/show_image.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:azuramartmy/wishlist/add_to_wish.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:azuramartmy/provider_models/product_details_model.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_html/shims/dart_ui_real.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

class ProductDetailsBody extends StatelessWidget {
  const ProductDetailsBody(
      {Key? key, this.productUrl, this.bestSellModel, this.offerModel})
      : super(key: key);
  final String? productUrl;
  final BestSellModel? bestSellModel;
  final OfferModel? offerModel;

  @override
  Widget build(BuildContext context) {
    productDetailsBloc.fetchAllProductDetails('$productUrl');
    return StreamBuilder(
        stream: productDetailsBloc.allProductDetails,
        builder: (context, AsyncSnapshot<ProductDetailsModel> snapshot) {
          if (snapshot.hasData) {
            return CustomScrollView(
              scrollDirection: Axis.vertical,
              slivers: [
                SliverToBoxAdapter(
                  child: ProductDetailsSlider(snapshot),
                ),
                SliverToBoxAdapter(
                  child: ProductDescription(snapshot),
                ),
                SliverToBoxAdapter(
                  child: Container(
                    margin: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 16),
                    child: const Text(
                      'You might also like',
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 18,
                          fontWeight: FontWeight.normal),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                        child: ConstrainedBox(
                          constraints:
                          const BoxConstraints(maxHeight: 250, minHeight: 16),
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              const SizedBox(
                                width: 10,
                              ),
                              ...List.generate(
                                  snapshot.data!.data!.realatedProduct!.length,
                                      (index) => RelatedCard(snapshot, index))
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                SliverToBoxAdapter(
                  child: BestSellProductBar(
                    snapshot: bestSellModel,
                  ),
                ),
                SliverToBoxAdapter(
                  child: HomeOfferProductBar(
                    snapshot: offerModel,
                  ),
                )
              ],
            );
          } else if (snapshot.hasError) {
            return Text(snapshot.error.toString());
          }
          return LoadingWidget(
            color: AppsColors.buttonColor,
          );
        });
  }
}

class ProductDetailsSlider extends StatefulWidget {
  final AsyncSnapshot<ProductDetailsModel> snapshot;
  const ProductDetailsSlider(this.snapshot);

  @override
  _ProductDetailsSliderState createState() => _ProductDetailsSliderState();
}

class _ProductDetailsSliderState extends State<ProductDetailsSlider> {
  int currentPage = 0;
  // PageController _pageController = PageController(
  //   initialPage: 0,
  // );
  @override
  void initState() {
    // Timer.periodic(Duration(seconds: 5), (Timer timer) {
    //   if (currentPage < (widget.snapshot.data.data.img.length - 1)) {
    //     currentPage++;
    //   } else {
    //     currentPage = 0;
    //   }
    //
    //   _pageController.animateToPage(
    //     currentPage,
    //     duration: Duration(milliseconds: 600),
    //     curve: Curves.easeIn,
    //   );
    // });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final RenderBox? box = context.findRenderObject() as RenderBox?;
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          height: MediaQuery.of(context).orientation == Orientation.portrait
              ? MediaQuery.of(context).size.height * 0.4
              : MediaQuery.of(context).size.width * 0.35,
          width: double.infinity,
          decoration: const BoxDecoration(color: Colors.transparent),
          child: PageView.builder(
              scrollBehavior: const ScrollBehavior(),
              reverse: false,
              pageSnapping: true,
              scrollDirection: Axis.horizontal,
              // controller: _pageController,
              onPageChanged: (value) {
                setState(() {
                  currentPage = value;
                });
              },
              itemCount: widget.snapshot.data!.data!.img!.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        CustomRoutePageBuilder.createPageRouteTop(context,ShowImage(
                      snapshot: widget.snapshot,
                    )));
                  },
                  child: DetailsImageView(
                      widget.snapshot.data!.data!.img![index].relativepath),
                );
              }),
        ),
        Positioned(
          bottom: 16,
          //alignment: Alignment.bottomCenter,
          child: Container(
            margin: const EdgeInsets.only(top: 4),
            padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
            decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.5),
                borderRadius: BorderRadius.circular(30.0)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                ...List.generate(widget.snapshot.data!.data!.img!.length,
                    (index) => buildDot(index))
              ],
            ),
          ),
        ),
        Positioned(
          bottom: 8,
          right: 8,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                onPressed: () {
                  Share.share(
                      '${Urls.baseShareUrl}${widget.snapshot.data!.data!.product!.urlslug}',
                      // sharePositionOrigin: box.localToGlobal(Offset.zero) & box.size,
                      subject:
                          'Click bellow the link to see azura mart product');
                },
                icon: const Icon(Icons.share),
              ),
              Text(
                'Share',
                style: TextStyle(color: AppsColors.highlightedColor),
              ),
            ],
          ),
        )
      ],
    );
  }

  AnimatedContainer buildDot(int index) {
    return AnimatedContainer(
      duration: const Duration(microseconds: 500),
      curve: Curves.easeInCubic,
      margin: const EdgeInsets.only(right: 5),
      height: 6,
      width: currentPage == index ? 12 : 6,
      decoration: ShapeDecoration(
          color: currentPage == index
              ? AppsColors.buttonColor
              : const Color(0xffffffff).withOpacity(0.8),
          shape: const StadiumBorder()),
    );
  }
}

class DetailsImageView extends StatelessWidget {
  final String? image;
  const DetailsImageView(this.image);
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Align(
          alignment: Alignment.center,
          child: Container(

              /// Urls.basePictureUrl + image
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: image == null
                  ? const NoImageWidget(
                      text: 'No Image',
                    )
                  : CacheImageProvide(
                      url: image,
                    )),
        )

        // Align(
        //   alignment: Alignment.center,
        //   child: InteractiveViewer(
        //     panEnabled: false, // Set it to false
        //     boundaryMargin: EdgeInsets.all(100),
        //     minScale: 1,
        //     maxScale: 1,
        //     alignPanAxis: false,
        //     // constrained: false,
        //     child: Container(
        //       /// Urls.basePictureUrl + image
        //         width: double.infinity,
        //         padding: const EdgeInsets.symmetric(vertical: 10),
        //         child: image == null
        //             ? NoImageWidget(text: 'No Image',)
        //             : CacheImageProvide(url: image,)
        //     ),
        //   ),
        // )
      ],
    );
  }
}

/// ........................Description.............................
class ProductDescription extends StatefulWidget {
  final AsyncSnapshot<ProductDetailsModel> snapshot;
  const ProductDescription(this.snapshot);

  static int stockInfoRG = -1;
  static int itemQty = 1;

  @override
  _ProductDescriptionState createState() => _ProductDescriptionState();
}

class _ProductDescriptionState extends State<ProductDescription>
    with TickerProviderStateMixin {
  TabController? tabController;
  ExpandableController? warehouseController;

  int? isCommon = 0;
  int isActive = 0;
  String s_color = '';
  String s_size = '';

  @override
  void initState() {
    tabController = TabController(length: 3, vsync: this);
    warehouseController = ExpandableController(initialExpanded: true);
    super.initState();
  }

  String getDays(String date) {
    DateTime dob = DateTime.parse(date);
    Duration dur = dob.difference(DateTime.now());
    int differenceDays = dur.inDays;
    return differenceDays <= 0 ? '7' : differenceDays.toString();
  }

  String? getColorName() {
    for (var i = 0; i < widget.snapshot.data!.data!.productColor!.length; i++) {
      if (widget.snapshot.data!.data!.productColor![i].isActive == 1) {
        return widget.snapshot.data!.data!.productColor![i].colorname;
      }
    }
  }

  String? getSizeName() {
    for (var i = 0; i < widget.snapshot.data!.data!.productSize!.length; i++) {
      if (widget.snapshot.data!.data!.productSize![i].isActive == 1) {
        return widget.snapshot.data!.data!.productSize![i].sizename;
      }
    }
  }

  int? getCommonCode() {
    for (var i = 0; i < widget.snapshot.data!.data!.productSize!.length; i++) {
      if (widget.snapshot.data!.data!.productSize![i].isActive == 1) {
        return widget.snapshot.data!.data!.productSize![i].isCommon;
      }
    }
  }

  int? getActiveProduct() {
    for (var i = 0; i < widget.snapshot.data!.data!.productColor!.length; i++) {
      if (widget.snapshot.data!.data!.productColor![i].isActive == 1) {
        return i;
      }
    }
  }

  /// this is for jump to color in list......
  ScrollController scrollController = ScrollController();
  final double _width = 140.0;

  _animatedToActiveColor(int i) {
    scrollController.animateTo(_width * i,
        duration: const Duration(seconds: 1), curve: Curves.fastOutSlowIn);
  }

  String removeAllHtmlTags(String htmlText) {
    RegExp exp = RegExp(r"<[^>]*>", multiLine: true, caseSensitive: true);

    return htmlText.replaceAll(exp, '');
  }

  void clearData() {
    ProductDetailsPage.stockInfo = -1;
    ProductDetailsPage.productPk = 0;
    ProductDetailsPage.frdMasterSetupNo = 0;
    ProductDetailsPage.qty = 1;
    ProductDetailsPage.F_PRD_VARIANT_NO = 0;
    ProductDetailsPage.F_INV_WAREHOUSE_NO = 0;
    ProductDetailsPage.F_SHIPPMENT_NO = 0;
    ProductDetailsPage.REGULAR_PRICE = 0;
    ProductDetailsPage.INSTALLMENT_PRICE = 0;
  }

  _showModalBottomSheet() {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        // enableDrag: true,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (BuildContext context, setState) {
            return Container(
                padding: const EdgeInsets.only(top: 16, bottom: 16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: double.infinity,
                      margin: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: Text(
                        'Size : ${widget.snapshot.data!.data!.product!.sizename}',
                        style: const TextStyle(color: Colors.black87, fontSize: 16),
                      ),
                    ),

                    /// ............... Size List in dialog..................
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Expanded(
                          child: ConstrainedBox(
                            constraints:
                            const BoxConstraints(maxHeight: 45, minHeight: 8),
                            child: Container(
                              margin:
                                  const EdgeInsets.symmetric(horizontal: 16),
                              child: ListView(
                                scrollDirection: Axis.horizontal,
                                children: [
                                  ...List.generate(
                                      widget.snapshot.data!.data!.productSize!
                                          .length,
                                      (index) => GestureDetector(
                                            onTap: () async {
                                              try {
                                                final result =
                                                    await InternetAddress
                                                        .lookup('example.com');
                                                if (result.isNotEmpty &&
                                                    result[0]
                                                        .rawAddress
                                                        .isNotEmpty) {
                                                  setState(() {
                                                    var newActive;
                                                    widget.snapshot.data!.data!
                                                            .product!.sizename =
                                                        widget
                                                            .snapshot
                                                            .data!
                                                            .data!
                                                            .productSize![index]
                                                            .sizename;
                                                    for (var i = (widget
                                                                .snapshot
                                                                .data!
                                                                .data!
                                                                .productColor!
                                                                .length -
                                                            1);
                                                        i >= 0;
                                                        i--) {
                                                      if (widget
                                                              .snapshot
                                                              .data!
                                                              .data!
                                                              .productColor![i]
                                                              .isCommon ==
                                                          widget
                                                              .snapshot
                                                              .data!
                                                              .data!
                                                              .productSize![
                                                                  index]
                                                              .isCommon) {
                                                        widget
                                                                .snapshot
                                                                .data!
                                                                .data!
                                                                .product!
                                                                .color =
                                                            widget
                                                                .snapshot
                                                                .data!
                                                                .data!
                                                                .productColor![i]
                                                                .colorname;
                                                        print(widget
                                                            .snapshot
                                                            .data!
                                                            .data!
                                                            .productColor![i]
                                                            .colorname);
                                                        newActive = i;
                                                      }
                                                    }
                                                    for (var i = (widget
                                                                .snapshot
                                                                .data!
                                                                .data!
                                                                .productColor!
                                                                .length -
                                                            1);
                                                        i >= 0;
                                                        i--) {
                                                      if (i == newActive) {
                                                        widget
                                                            .snapshot
                                                            .data!
                                                            .data!
                                                            .productColor![
                                                                newActive]
                                                            .isActive = 1;
                                                      } else {
                                                        widget
                                                            .snapshot
                                                            .data!
                                                            .data!
                                                            .productColor![i]
                                                            .isActive = 0;
                                                      }
                                                    }
                                                    widget
                                                        .snapshot
                                                        .data!
                                                        .data!
                                                        .productColor![newActive]
                                                        .isActive = 1;
                                                    productDetailsBloc
                                                        .fetchAllProductDetails(
                                                            '${widget.snapshot.data!.data!.productSize![index].url}');
                                                    clearData();
                                                    isCommon = widget
                                                        .snapshot
                                                        .data!
                                                        .data!
                                                        .productSize![index]
                                                        .isCommon;
                                                  });
                                                }
                                              } on SocketException catch (_) {
                                                Common.toastMsg(
                                                    'No Internet Connection');
                                              }
                                            },
                                            child: Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 16,
                                                      vertical: 0),
                                              margin: const EdgeInsets.only(
                                                  right: 10),
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(6.0),
                                                color: Colors.transparent,
                                                border: Border.all(
                                                    color: widget
                                                                .snapshot
                                                                .data!
                                                                .data!
                                                                .productSize![
                                                                    index]
                                                                .isCommon ==
                                                            isCommon
                                                        ? AppsColors
                                                            .highlightedColor
                                                        : const Color(0xFFD0D1D2)),
                                              ),
                                              child: Center(
                                                child: Text(
                                                  '${widget.snapshot.data!.data!.productSize![index].sizename}',
                                                  style: const TextStyle(
                                                      color: Colors.black87,
                                                      fontSize: 16),
                                                ),
                                              ),
                                            ),
                                          ))
                                ],
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                    Container(
                      width: double.infinity,
                      margin: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: Text(
                        'Color : ${widget.snapshot.data!.data!.product!.color}',
                        style: const TextStyle(color: Colors.black87, fontSize: 16),
                      ),
                    ),

                    /// ............... Color List in dialog..................
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Expanded(
                          child: ConstrainedBox(
                            constraints:
                            const BoxConstraints(maxHeight: 200, minHeight: 16),
                            child: Container(
                              margin:
                                  const EdgeInsets.symmetric(horizontal: 16),
                              child: ListView.builder(
                                  scrollDirection: Axis.horizontal,
                                  // controller: scrollController,
                                  shrinkWrap: true,
                                  itemCount: widget
                                      .snapshot.data!.data!.productColor!.length,
                                  itemBuilder: (context, index) {
                                    // for (int i = 0; i < widget.snapshot.data.data.productColor.length; i++) {
                                    //   if (widget.snapshot.data.data.productColor.elementAt(i).isActive == 1) {
                                    //     scrollController.animateTo(i * 128.0, duration: new Duration(seconds: 1), curve: Curves.easeInOut);
                                    //     //scrollController.jumpTo(index);
                                    //     break;
                                    //   }
                                    // }
                                    return GestureDetector(
                                      onTap: () async {
                                        try {
                                          final result =
                                              await InternetAddress.lookup(
                                                  'example.com');
                                          if (result.isNotEmpty &&
                                              result[0].rawAddress.isNotEmpty) {
                                            setState(() {
                                              widget.snapshot.data!.data!.product!
                                                      .color =
                                                  widget
                                                      .snapshot
                                                      .data!
                                                      .data!
                                                      .productColor![index]
                                                      .colorname;

                                              for (var i = 0;
                                                  i <
                                                      widget.snapshot.data!.data!
                                                          .productSize!.length;
                                                  i++) {
                                                if (widget
                                                        .snapshot
                                                        .data!
                                                        .data!
                                                        .productColor![index]
                                                        .isCommon ==
                                                    widget
                                                        .snapshot
                                                        .data!
                                                        .data!
                                                        .productSize![i]
                                                        .isCommon) {
                                                  widget.snapshot.data!.data!
                                                          .product!.sizename =
                                                      widget
                                                          .snapshot
                                                          .data!
                                                          .data!
                                                          .productSize![i]
                                                          .sizename;
                                                }
                                              }

                                              for (var i = 0;
                                                  i <
                                                      widget.snapshot.data!.data!
                                                          .productColor!.length;
                                                  i++) {
                                                if (i == index) {
                                                  widget
                                                      .snapshot
                                                      .data!
                                                      .data!
                                                      .productColor![i]
                                                      .isActive = 1;
                                                } else {
                                                  widget
                                                      .snapshot
                                                      .data!
                                                      .data!
                                                      .productColor![i]
                                                      .isActive = 0;
                                                }
                                              }

                                              productDetailsBloc
                                                  .fetchAllProductDetails(
                                                      '${widget.snapshot.data!.data!.productColor![index].url}');
                                              clearData();
                                              isCommon = widget
                                                  .snapshot
                                                  .data!
                                                  .data!
                                                  .productColor![index]
                                                  .isCommon;
                                            });
                                          }
                                        } on SocketException catch (_) {
                                          Common.toastMsg(
                                              'No Internet Connection');
                                        }
                                      },
                                      child: Opacity(
                                        opacity: isCommon ==
                                                widget
                                                    .snapshot
                                                    .data!
                                                    .data!
                                                    .productColor![index]
                                                    .isCommon
                                            ? 1.0
                                            : 0.4,
                                        child: Container(
                                          padding:
                                              const EdgeInsets.only(top: 4),
                                          margin: const EdgeInsets.only(
                                              right: 16.0),
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(6.0),
                                              border: Border.all(
                                                  color: widget
                                                              .snapshot
                                                              .data!
                                                              .data!
                                                              .productColor![
                                                                  index]
                                                              .isActive ==
                                                          1
                                                      ? AppsColors
                                                          .highlightedColor
                                                      : const Color(0xFFD0D1D2)),
                                              color: const Color(0xFFFFFFFF)),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Container(
                                                height: 120,
                                                width: 120,
                                                decoration: BoxDecoration(
                                                    color: Colors.white,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            6.0)),
                                                child: Center(
                                                    // widget.snapshot.data.data.productColor[index].primary_img_relative_path,
                                                    child: widget
                                                                .snapshot
                                                                .data!
                                                                .data!
                                                                .productColor![
                                                                    index]
                                                                .primary_img_relative_path ==
                                                            null
                                                        ? const NoImageWidget(
                                                            text: 'No Image',
                                                          )
                                                        : CacheImageProvide(
                                                            url: widget
                                                                .snapshot
                                                                .data!
                                                                .data!
                                                                .productColor![
                                                                    index]
                                                                .primary_img_relative_path,
                                                          )),
                                              ),
                                              Container(
                                                padding:
                                                    const EdgeInsets.all(12),
                                                decoration: BoxDecoration(
                                                    color: Colors.white,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            6.0)),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    SizedBox(
                                                      child: Text(
                                                        '${widget.snapshot.data!.data!.productColor![index].colorname}',
                                                        maxLines: 1,
                                                        style: const TextStyle(
                                                            fontSize: 16,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            color:
                                                                Colors.black87),
                                                      ),
                                                    ),
                                                    const SizedBox(
                                                      height: 8,
                                                    ),
                                                    SizedBox(
                                                      child: Text(
                                                        'RM${widget.snapshot.data!.data!.productColor![index].regularprice!.toStringAsFixed(2)}',
                                                        style: const TextStyle(
                                                            fontSize: 16,
                                                            fontWeight:
                                                                FontWeight
                                                                    .normal,
                                                            color:
                                                                Colors.black87),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  }),
                            ),
                          ),
                        )
                      ],
                    ),
                  ],
                ));
          });
        });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: Column(
        children: [
          const SizedBox(
            height: 8,
          ),

          ///................... Price .......................
          SizedBox(
            width: double.infinity,
            child: Text(
              'RM${widget.snapshot.data!.data!.product!.regularprice!.toStringAsFixed(2)}',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppsColors.highlightedColor,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),

          const SizedBox(
            height: 8,
          ),

          ///............. In Stock .............................
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 0),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: widget.snapshot.data!.data!.availablity! > 0
                    ? Colors.green
                    : Colors.amber),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(
                widget.snapshot.data!.data!.availablity! > 0
                    ? 'In Stock'
                    : 'Out Of Stock',
                style: const TextStyle(color: Colors.white, fontSize: 14),
              ),
            ),
          ),

          const SizedBox(
            height: 8,
          ),

          ///................... Variant Name .......................
          Container(
            width: double.infinity,
            margin: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              '${widget.snapshot.data!.data!.product!.variantname}',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
          // Container(
          //   // width: double.infinity,
          //   margin: EdgeInsets.symmetric(horizontal: 16),
          //   child: RichText(
          //     text: TextSpan(
          //       text: '${widget.snapshot.data.data.product.variantname}',
          //       style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.normal),
          //       children: <TextSpan>[
          //         TextSpan(
          //           text: '  SKU 0xfhs6787656',
          //           style: TextStyle(color: Colors.red, fontSize: 14, fontWeight: FontWeight.normal),
          //         )
          //       ]
          //       ),
          //     ),
          //   ),
          const SizedBox(
            height: 8,
          ),

          /// .................. Free Postage .......................
          const SizedBox(
            height: 8,
          ),
          SizedBox(
            width: double.infinity,
            child: Text(
              'Free postage to Peninsular (SM), for Sabah & Sarawak ( SS ) RM${widget.snapshot.data!.data!.product!.interdistrictpostage!.toStringAsFixed(2)}',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.black54,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),

          /// .................. Offers .................
          // SizedBox(
          //   height: 16,
          // ),
          //
          // LayoutBuilder(
          //   builder: (BuildContext context, BoxConstraints constraints) {
          //     if (widget.snapshot.data.data.offer.length != 0) {
          //       return Container(
          //         decoration: BoxDecoration(
          //           color: Colors.red,
          //           borderRadius: BorderRadius.only(bottomLeft: Radius.circular(6.0),topLeft: Radius.circular(6.0))
          //         ),
          //         child: Row(
          //           mainAxisSize: MainAxisSize.max,
          //           children: [
          //             Expanded(
          //               // flex: 1,
          //               child: Container(
          //                 padding: const EdgeInsets.symmetric(horizontal: 8),
          //                 // height: double.nan,
          //                 decoration: BoxDecoration(
          //                   // color: AppsColors.buttonColor,
          //                     gradient: LinearGradient(
          //                         colors: [
          //                           Colors.red,
          //                           Colors.redAccent,
          //                         ],
          //                         begin: Alignment.topCenter,
          //                         end: Alignment.bottomCenter),
          //                     borderRadius: BorderRadius.only(
          //                         bottomRight: Radius.circular(16))),
          //                 child: Row(
          //                   mainAxisAlignment: MainAxisAlignment.center,
          //                   mainAxisSize: MainAxisSize.min,
          //                   children: [
          //                     Icon(
          //                       Icons.local_offer,
          //                       color: Colors.white,
          //                       size: 20,
          //                     ),
          //                     SizedBox(
          //                       width: 8,
          //                     ),
          //                     Text(
          //                       'Offer',
          //                       style: TextStyle(
          //                           color: Colors.white,
          //                           fontSize: 18,
          //                           fontWeight: FontWeight.w600),
          //                     ),
          //                   ],
          //                 ),
          //               ),
          //             ),
          //             Expanded(
          //               flex: 3,
          //               child: Container(
          //                 width: double.infinity,
          //                 color: Colors.white,
          //                 padding: const EdgeInsets.symmetric(horizontal: 6),
          //                 margin: const EdgeInsets.only(top: 1,bottom: 1,right: 1,),
          //                 child: Column(
          //                   mainAxisSize: MainAxisSize.min,
          //                   mainAxisAlignment: MainAxisAlignment.start,
          //                   children: [
          //                     for (var i = 0; i < widget.snapshot.data.data.offer.length; i++)
          //                       GestureDetector(
          //                         onTap: () async {
          //                           try {
          //                             final result =
          //                             await InternetAddress.lookup('example.com');
          //                             if (result.isNotEmpty &&
          //                                 result[0].rawAddress.isNotEmpty) {
          //                               OfferDetailsPage.offerName = 'offer/' +
          //                                   widget.snapshot.data.data.offer[i].url;
          //                               Navigator.push(context, OfferDetailsPage.route());
          //                             }
          //                           } on SocketException catch (_) {
          //                             Common.toastMsg('No Internet Connection');
          //                           }
          //                         },
          //                         child: Container(
          //                           width: double.infinity,
          //                           margin: const EdgeInsets.symmetric(vertical: 4),
          //                           child: Row(
          //                             mainAxisSize: MainAxisSize.max,
          //                             mainAxisAlignment: MainAxisAlignment.spaceAround,
          //                             crossAxisAlignment: CrossAxisAlignment.start,
          //                             children: [
          //                               Icon(
          //                                 Icons.wallet_giftcard,
          //                                 color: Color(0xFFF68721),
          //                                 size: 20,
          //                               ),
          //                               SizedBox(
          //                                 width: 8,
          //                               ),
          //                               Expanded(
          //                                   child: Text(
          //                                     '${widget.snapshot.data.data.offer[i].bundleNamePublic}',
          //                                     style: TextStyle(
          //                                         color: Color(0xFFF68721),
          //                                         fontSize: 16,
          //                                         fontWeight: FontWeight.bold),
          //                                   )
          //                               )
          //                             ],
          //                           ),
          //                         ),
          //                       ),
          //                   ],
          //                 ),
          //               ),
          //             )
          //           ],
          //         ),
          //       );
          //
          //       //.......................................................
          //       // return Column(
          //       //   mainAxisSize: MainAxisSize.min,
          //       //   children: [
          //       //     Container(
          //       //       width: double.infinity,
          //       //       height: 45,
          //       //       decoration: BoxDecoration(
          //       //         // color: Color(0xFFFF7522)
          //       //         // color: Color(0xFFFA9847),
          //       //         gradient: LinearGradient(
          //       //             colors: [
          //       //               Color(0xFFF78949),
          //       //               Color(0xFFFEA844),
          //       //             ],
          //       //             begin: Alignment.topCenter,
          //       //             end: Alignment.bottomCenter),
          //       //       ),
          //       //       child: Stack(
          //       //         children: [
          //       //           Align(
          //       //             alignment: Alignment.center,
          //       //             child: Text(
          //       //               'Offer Details',
          //       //               style: TextStyle(
          //       //                 color: Colors.white,
          //       //                 fontSize: 16,
          //       //                 fontWeight: FontWeight.w600,
          //       //               ),
          //       //             ),
          //       //           ),
          //       //           Align(
          //       //             alignment: Alignment.centerLeft,
          //       //             child: Container(
          //       //               padding:
          //       //                   const EdgeInsets.symmetric(horizontal: 16),
          //       //               height: double.infinity,
          //       //               decoration: BoxDecoration(
          //       //                   // color: Colors.pink,
          //       //                   gradient: LinearGradient(
          //       //                       colors: [
          //       //                         Colors.pink,
          //       //                         Colors.pinkAccent,
          //       //                       ],
          //       //                       begin: Alignment.topCenter,
          //       //                       end: Alignment.bottomCenter),
          //       //                   borderRadius: BorderRadius.only(
          //       //                       bottomRight: Radius.circular(16))),
          //       //               child: Row(
          //       //                 mainAxisAlignment: MainAxisAlignment.start,
          //       //                 mainAxisSize: MainAxisSize.min,
          //       //                 children: [
          //       //                   Icon(
          //       //                     Icons.local_offer,
          //       //                     color: Colors.white,
          //       //                     size: 20,
          //       //                   ),
          //       //                   SizedBox(
          //       //                     width: 8,
          //       //                   ),
          //       //                   Text(
          //       //                     'Offer',
          //       //                     style: TextStyle(
          //       //                         color: Colors.white,
          //       //                         fontSize: 18,
          //       //                         fontWeight: FontWeight.w600),
          //       //                   ),
          //       //                 ],
          //       //               ),
          //       //             ),
          //       //           ),
          //       //         ],
          //       //       ),
          //       //     ),
          //       //     for (var i = 0;
          //       //         i < widget.snapshot.data.data.offer.length;
          //       //         i++)
          //       //       GestureDetector(
          //       //         onTap: () async {
          //       //           try {
          //       //             final result =
          //       //                 await InternetAddress.lookup('example.com');
          //       //             if (result.isNotEmpty &&
          //       //                 result[0].rawAddress.isNotEmpty) {
          //       //               OfferDetailsPage.offerName = 'offer/' +
          //       //                   widget.snapshot.data.data.offer[i].url;
          //       //               Navigator.push(context, OfferDetailsPage.route());
          //       //             }
          //       //           } on SocketException catch (_) {
          //       //             Common.toastMsg('No Internet Connection');
          //       //           }
          //       //         },
          //       //         child: Container(
          //       //           margin: const EdgeInsets.symmetric(vertical: 8),
          //       //           child: Row(
          //       //             mainAxisSize: MainAxisSize.max,
          //       //             mainAxisAlignment: MainAxisAlignment.spaceAround,
          //       //             crossAxisAlignment: CrossAxisAlignment.start,
          //       //             children: [
          //       //               Icon(
          //       //                 Icons.wallet_giftcard,
          //       //                 color: Color(0xFFF68721),
          //       //                 size: 20,
          //       //               ),
          //       //               SizedBox(
          //       //                 width: 8,
          //       //               ),
          //       //               Expanded(
          //       //                   child: Text(
          //       //                 '${widget.snapshot.data.data.offer[i].bundleNamePublic}',
          //       //                 style: TextStyle(
          //       //                     color: Color(0xFFF68721),
          //       //                     fontSize: 16,
          //       //                     fontWeight: FontWeight.bold),
          //       //               ))
          //       //             ],
          //       //           ),
          //       //         ),
          //       //       ),
          //       //   ],
          //       // );
          //       //.......................................................
          //     } else {
          //       return SizedBox(
          //         height: 2,
          //       );
          //     }
          //   },
          // ),

          const SizedBox(
            height: 16,
          ),

          LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
              if (widget.snapshot.data!.data!.offer!.isNotEmpty) {
                return Column(
                  children: [
                    for (var i = 0;
                        i < widget.snapshot.data!.data!.offer!.length;
                        i++)
                      GestureDetector(
                        onTap: () async {
                          try {
                            final result =
                                await InternetAddress.lookup('example.com');
                            if (result.isNotEmpty &&
                                result[0].rawAddress.isNotEmpty) {
                              OfferDetailsPage.offerName = 'offer/' +
                                  widget.snapshot.data!.data!.offer![i].url!;
                              Navigator.push(context, OfferDetailsPage.route());
                            }
                          } on SocketException catch (_) {
                            Common.toastMsg('No Internet Connection');
                          }
                        },
                        child: Container(
                          width: double.infinity,
                          height: 45,
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: const BorderRadius.only(
                                bottomLeft: Radius.circular(6.0),
                                topLeft: Radius.circular(6.0)),
                            border: Border.all(color: AppsColors.offerColor, width: 1),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Material(
                                  color: AppsColors.offerColor,
                                  shape: const BeveledRectangleBorder(
                                      borderRadius: BorderRadius.only(
                                          bottomRight: Radius.circular(6.0),
                                          topRight: Radius.circular(6.0))),
                                  type: MaterialType.canvas,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 4),
                                    height: double.infinity,
                                    decoration: const BoxDecoration(
                                        // color: Colors.pink,
                                        // gradient: LinearGradient(
                                        //     colors: [
                                        //       Colors.red,
                                        //       Colors.redAccent,
                                        //     ],
                                        //     begin: Alignment.topCenter,
                                        //     end: Alignment.bottomCenter),
                                        // shape: BeveledRectangleBorder(borderRadius: BorderRadius.only(bottomRight: Radius.circular(50.0)))
                                        // borderRadius: BorderRadius.only(
                                        //     bottomRight: Radius.circular(16))
                                        ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      mainAxisSize: MainAxisSize.min,
                                      children: const [
                                        Icon(
                                          Icons.local_offer,
                                          color: Colors.white,
                                          size: 16,
                                        ),
                                        SizedBox(
                                          width: 8,
                                        ),
                                        Text(
                                          'Offer',
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 16,
                                              fontWeight: FontWeight.w600),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 3,
                                child: Container(
                                  width: double.infinity,
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 4),
                                  child: Text(
                                    '${widget.snapshot.data!.data!.offer![i].bundleNamePublic}',
                                    style: TextStyle(
                                        color: AppsColors.offerColor,
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      )
                  ],
                );
              } else {
                return const SizedBox(
                  height: 2,
                );
              }
            },
          ),

          /// ............................... Special Note .........................
          LayoutBuilder(
              builder: (BuildContext context, BoxConstraints constraints) {
            if (widget.snapshot.data!.data!.product!.promotionalmsg == null ||
                widget.snapshot.data!.data!.product!.promotionalmsg == '' ||
                widget.snapshot.data!.data!.product!.promotionalmsg!.isEmpty) {
              return const SizedBox(
                height: 2,
              );
            } else {
              return Container(
                width: double.infinity,
                margin: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: AppsColors.highlightedColor)),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Html(
                        data:
                            """${widget.snapshot.data!.data!.product!.promotionalmsg}""",
                      ),
                    ),
                    const Flexible(
                      child: Image(
                        image: AssetImage('images/free.png'),
                      ),
                    ),
                  ],
                ),
              );
            }
          }),
          const SizedBox(
            height: 16,
          ),

          /// ................ SKU .................
          // Container(
          //   height: 50,
          //   padding: const EdgeInsets.only(left: 16,right: 8),
          //   color: Colors.white,
          //   child: Row(
          //     mainAxisSize: MainAxisSize.max,
          //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //     children: [
          //       Text('SKU',style: TextStyle(color: Colors.black87,fontSize: 16,fontWeight: FontWeight.w700),),
          //       Text('0xfhs679867',style: TextStyle(color: Colors.red,fontSize: 18,fontWeight: FontWeight.w500),),
          //       ElevatedButton(
          //         style: ElevatedButton.styleFrom(primary: Color(0xFFF4F4F4),elevation: 0),
          //           onPressed: (){
          //             Clipboard.setData(ClipboardData(text: "This is Copied text"));
          //             Common.toastMsg('Product SKU Copied');
          //           },
          //           child: Text('copy',style: TextStyle(color: Colors.black87,fontWeight: FontWeight.w700,fontSize: 16),)
          //       )
          //     ],
          //   ),
          // ),

          // SizedBox(
          //   height: 16,
          // ),
          /// ................ add to wish button .................
          SizedBox(
            height: 50,
            child: OutlinedButton(
              style: OutlinedButton.styleFrom(
                  primary: Colors.white,
                  elevation: 0,
                  backgroundColor: Colors.white,
                  side: BorderSide(
                      width: 1.0,
                      color: AppsColors.buttonColor,
                      style: BorderStyle.solid),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(3.0))),
              onPressed: () async {
                try {
                  final result = await InternetAddress.lookup('example.com');
                  if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                    setState(() {
                      widget.snapshot.data!.data!.product!.isWish =
                          widget.snapshot.data!.data!.product!.isWish == 1 ? 0 : 1;
                      AddToWish addWish = AddToWish();
                      addWish.addToWish(widget.snapshot.data!.data!.product!.pkno);
                    });
                  }
                } on SocketException catch (_) {
                  Common.toastMsg('No Internet Connection');
                }
              },
              child: AnimatedCrossFade(
                crossFadeState: widget.snapshot.data!.data!.product!.isWish == 0
                    ? CrossFadeState.showFirst
                    : CrossFadeState.showSecond,
                duration: const Duration(milliseconds: 500),
                firstCurve: Curves.easeOut,
                secondCurve: Curves.easeIn,
                firstChild: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.favorite_outline,
                      size: 20,
                      color: AppsColors.buttonColor,
                    ),
                    const SizedBox(
                      width: 8,
                    ),
                    Text(
                      'ADD TO WISHLIST',
                      style: TextStyle(
                          color: AppsColors.buttonColor, fontSize: 14),
                    )
                  ],
                ),
                secondChild: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.favorite,
                      size: 20,
                      color: AppsColors.buttonColor,
                    ),
                    const SizedBox(
                      width: 8,
                    ),
                    Text(
                      'ADDED TO WISHLIST',
                      style: TextStyle(
                          color: AppsColors.buttonColor, fontSize: 14),
                    )
                  ],
                ),
              ),
              // child: Row(
              //   mainAxisSize: MainAxisSize.max,
              //   mainAxisAlignment: MainAxisAlignment.center,
              //   crossAxisAlignment: CrossAxisAlignment.center,
              //   children: [
              //     widget.snapshot.data.data.product.isWish == 0
              //         ? Icon(
              //             Icons.favorite_outline,
              //             size: 20,
              //             color: Color(0xFFF68721),
              //           )
              //         : Icon(
              //             Icons.favorite,
              //             size: 20,
              //             color: Color(0xFFF68721),
              //           ),
              //     SizedBox(
              //       width: 8,
              //     ),
              //     Text(
              //       widget.snapshot.data.data.product.isWish == 0
              //           ? 'ADD TO WISHLIST'
              //           : 'ADDED TO WISHLIST',
              //       style: TextStyle(color: Color(0xFFF68721), fontSize: 14),
              //     )
              //   ],
              // ),
            ),
          ),
          const SizedBox(
            height: 0,
          ),

          ///................. Bottom dialog Btn..................0xFFD0D1D2
          Container(
            width: double.infinity,
            padding: const EdgeInsets.only(top: 16.0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(primary: const Color(0xFFE7E7E7)),
              onPressed: () {
                setState(() {
                  //_animatedToActiveColor(getActiveProduct());
                  isCommon = getCommonCode();
                  print('initial common value : $isCommon');
                  _showModalBottomSheet();
                });
              },
              child: ListTile(
                title: const Text(
                  'Size : ',
                  style: TextStyle(color: Colors.black54, fontSize: 16),
                ),
                subtitle: Text(
                  '${widget.snapshot.data!.data!.product!.sizename}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.w600,
                      fontSize: 16),
                ),
                trailing: const Icon(Icons.arrow_forward_ios),
              ),
            ),
          ),

          const SizedBox(
            height: 20,
          ),

          SizedBox(
            width: double.infinity,
            // padding: const EdgeInsets.symmetric(vertical: 16.0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(primary: const Color(0xFFE7E7E7)),
              onPressed: () {
                setState(() {
                  //_animatedToActiveColor(getActiveProduct());
                  isCommon = getCommonCode();
                  _showModalBottomSheet();
                });
              },
              child: ListTile(
                title: Text(
                  widget.snapshot.data!.data!.productColor!.length > 1
                      ? '${widget.snapshot.data!.data!.productColor!.length} Colors : '
                      : '${widget.snapshot.data!.data!.productColor!.length} Color : ',
                  style: const TextStyle(color: Colors.black54, fontSize: 16),
                ),
                subtitle: Text(
                  '${widget.snapshot.data!.data!.product!.color}',
                  style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.w600,
                      fontSize: 16),
                ),
                trailing: const Icon(Icons.arrow_forward_ios),
              ),
            ),
          ),

          const Divider(
            height: 40,
            thickness: 5,
          ),

          /// Product Details................
          SizedBox(
            width: double.infinity,
            child: Row(
              children: [
                Expanded(
                  flex: 1,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(left: 20),
                        width: double.infinity,
                        child: const Text(
                          'Details',
                          style: TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.w600,
                              fontSize: 16),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        margin: const EdgeInsets.only(left: 20),
                        width: double.infinity,
                        child: const Text(
                          'Model Name',
                          style: TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.normal,
                              fontSize: 16),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        margin: const EdgeInsets.only(left: 20),
                        width: double.infinity,
                        child: const Text(
                          'Brand',
                          style: TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.normal,
                              fontSize: 16),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        margin: const EdgeInsets.only(left: 20),
                        width: double.infinity,
                        child: const Text(
                          'Size',
                          style: TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.normal,
                              fontSize: 16),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        margin: const EdgeInsets.only(left: 20),
                        width: double.infinity,
                        child: const Text(
                          'Color',
                          style: TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.normal,
                              fontSize: 16),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const SizedBox(
                        width: double.infinity,
                        child: Text(
                          '',
                          style: TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.w600,
                              fontSize: 16),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          '${widget.snapshot.data!.data!.product!.model}',
                          style: const TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.normal,
                              fontSize: 15),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          '${widget.snapshot.data!.data!.product!.brand}',
                          style: const TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.normal,
                              fontSize: 15),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          '${widget.snapshot.data!.data!.product!.sizename}',
                          style: const TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.normal,
                              fontSize: 15),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          '${widget.snapshot.data!.data!.product!.color}',
                          style: const TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.normal,
                              fontSize: 15),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const Divider(
            height: 40,
            thickness: 5,
          ),

          /// ............................Price Plan .............................
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(6.0),
                border: Border.all(color: const Color(0xFFD1D2D3))),
            child: ExpandablePanel(
              collapsed: const SizedBox(height: 0,),
              header: const ListTile(
                title: Image(
                  image:
                      AssetImage('images/app_images/pay_in_instalment_2.png'),
                  height: 50,
                  width: double.infinity,
                ),
                // title: Text(
                //   'Pay in instalment plan, please click here for more info',
                //   style: TextStyle(color: Colors.black87, fontSize: 16),
                // ),
              ),
              expanded: Column(
                children: [
                  /// Azura mart payment plan .........
                  const SizedBox(
                    height: 16,
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    margin:
                        const EdgeInsets.symmetric(vertical: 6, horizontal: 6),
                    decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(6.0),
                        border: Border.all(color: Colors.blue)),
                    child: Column(
                      children: [
                        Container(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 6),
                          padding: const EdgeInsets.all(8),
                          width: double.infinity,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(6.0),
                              border: Border.all(color: const Color(0xFFD1D2D3))),
                          child: Wrap(
                            spacing: 4,
                            runSpacing: 4,
                            direction: Axis.horizontal,
                            alignment: WrapAlignment.start,
                            children: [
                              RichText(
                                text: TextSpan(
                                    text: 'Pay initial deposit minimum ',
                                    style: const TextStyle(
                                        color: Colors.black87,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600),
                                    children: <TextSpan>[
                                      TextSpan(
                                        text:
                                            'RM${(widget.snapshot.data!.data!.product!.regularprice! * 0.2).ceil().toStringAsFixed(2)}',
                                        style: const TextStyle(
                                            color: Colors.black87,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600),
                                      ),
                                      const TextSpan(
                                        text:
                                            ' or MORE remaining balance pay within 90 days (3 months). *',
                                        style: TextStyle(
                                            color: Colors.black87,
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ]),
                              ),
                              const SizedBox(
                                width: 4,
                              ),
                              Container(
                                height: 20,
                                padding: const EdgeInsets.all(0),
                                margin: const EdgeInsets.all(0),
                                child: const Image(
                                  image: AssetImage('images/azura_logo_small.png'),
                                ),
                              ),
                              const SizedBox(
                                width: 4,
                              ),
                              GestureDetector(
                                onTap: () {},
                                child: const Text(
                                  'Learn more',
                                  style: TextStyle(
                                    color: Colors.black87,
                                    fontSize: 16,
                                    decoration: TextDecoration.underline,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 6),
                          padding: const EdgeInsets.all(8),
                          width: double.infinity,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(6.0),
                              border: Border.all(color: const Color(0xFFD1D2D3))),
                          child: Wrap(
                            spacing: 4,
                            runSpacing: 4,
                            direction: Axis.horizontal,
                            alignment: WrapAlignment.start,
                            children: [
                              RichText(
                                text: TextSpan(
                                    text: 'Pay initial deposit minimum ',
                                    style: const TextStyle(
                                        color: Colors.black87,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600),
                                    children: <TextSpan>[
                                      TextSpan(
                                        text:
                                            'RM${(widget.snapshot.data!.data!.product!.installmentprice! * 0.2).ceil().toStringAsFixed(2)}',
                                        style: const TextStyle(
                                            color: Colors.black87,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600),
                                      ),
                                      const TextSpan(
                                        text:
                                            ' or MORE remaining balance pay within 180 days (6 months). *',
                                        style: TextStyle(
                                            color: Colors.black87,
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ]),
                              ),
                              const SizedBox(
                                width: 4,
                              ),
                              Container(
                                height: 20,
                                padding: const EdgeInsets.all(0),
                                margin: const EdgeInsets.all(0),
                                child: const Image(
                                  image: AssetImage('images/azura_logo_small.png'),
                                ),
                              ),
                              const SizedBox(
                                width: 4,
                              ),
                              GestureDetector(
                                onTap: () {},
                                child: const Text(
                                  'Learn more',
                                  style: TextStyle(
                                    color: Colors.black87,
                                    fontSize: 14,
                                    decoration: TextDecoration.underline,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 6),
                          padding: const EdgeInsets.all(8),
                          width: double.infinity,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(6.0),
                              border: Border.all(color: const Color(0xFFD1D2D3))),
                          child: const SizedBox(
                            width: double.infinity,
                            child: Text(
                              '*We will dispatch your order, once balance settle in FULL',
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  /// hoolah .........
                  // const SizedBox(
                  //   height: 12,
                  // ),
                  // Container(
                  //   margin: const EdgeInsets.symmetric(horizontal: 6),
                  //   padding: const EdgeInsets.all(8),
                  //   decoration: BoxDecoration(
                  //       borderRadius: BorderRadius.circular(6.0),
                  //       border: Border.all(color: Colors.blue)),
                  //   width: double.infinity,
                  //   child: Wrap(
                  //     spacing: 4,
                  //     runSpacing: 4,
                  //     direction: Axis.horizontal,
                  //     alignment: WrapAlignment.start,
                  //     children: [
                  //       Text(
                  //         'OR RM${widget.snapshot.data!.data!.product!.regularprice!.toStringAsFixed(2)} X 3 MONTHLY INSTALMENTS.NO INTEREST OR FEES WITH',
                  //         style: const TextStyle(
                  //           color: Colors.black87,
                  //           fontSize: 14,
                  //           fontWeight: FontWeight.w600,
                  //         ),
                  //       ),
                  //       const SizedBox(
                  //         width: 4,
                  //       ),
                  //       Container(
                  //         height: 20,
                  //         padding: const EdgeInsets.all(0),
                  //         margin: const EdgeInsets.all(0),
                  //         child: const Image(
                  //           image: AssetImage('images/hoolahh.png'),
                  //         ),
                  //       ),
                  //       const SizedBox(
                  //         width: 4,
                  //       ),
                  //       GestureDetector(
                  //         onTap: () {
                  //           setState(() {
                  //             Navigator.of(context).push(PageRouteBuilder(
                  //                 opaque: false,
                  //                 pageBuilder: (BuildContext context, _, __) =>
                  //                 const HoolahDialog()));
                  //           });
                  //         },
                  //         child: const Text(
                  //           'Learn more',
                  //           style: TextStyle(
                  //             color: Colors.black87,
                  //             fontSize: 14,
                  //             decoration: TextDecoration.underline,
                  //           ),
                  //         ),
                  //       )
                  //     ],
                  //   ),
                  // ),
                  //
                  // const SizedBox(
                  //   height: 8,
                  // ),

                  /// Grab ..................
                  // LayoutBuilder(builder:
                  //     (BuildContext context, BoxConstraints constraints) {
                  //   if (widget.snapshot.data!.data!.product!.regularprice! < 1000) {
                  //     return Container(
                  //       margin: const EdgeInsets.symmetric(horizontal: 6),
                  //       padding: const EdgeInsets.all(8),
                  //       width: double.infinity,
                  //       decoration: BoxDecoration(
                  //           borderRadius: BorderRadius.circular(6.0),
                  //           border: Border.all(color: Colors.blue)),
                  //       child: Wrap(
                  //         direction: Axis.horizontal,
                  //         spacing: 4,
                  //         runSpacing: 4,
                  //         alignment: WrapAlignment.start,
                  //         children: [
                  //           Text(
                  //             'OR 4 PAYMENTS OF RM${widget.snapshot.data!.data!.product!.regularprice!.toStringAsFixed(2)} WITH',
                  //             style: const TextStyle(
                  //               color: Colors.black87,
                  //               fontSize: 14,
                  //               fontWeight: FontWeight.w600,
                  //             ),
                  //           ),
                  //           const SizedBox(
                  //             width: 4,
                  //           ),
                  //           Container(
                  //             height: 20,
                  //             padding: const EdgeInsets.all(0),
                  //             margin: const EdgeInsets.all(0),
                  //             child: const Image(
                  //               image: AssetImage('images/grab-1.png'),
                  //             ),
                  //           ),
                  //           const SizedBox(
                  //             width: 4,
                  //           ),
                  //           GestureDetector(
                  //             onTap: () {
                  //               Navigator.of(context).push(PageRouteBuilder(
                  //                   opaque: false,
                  //                   pageBuilder:
                  //                       (BuildContext context, _, __) =>
                  //                       const GrabDialog()));
                  //             },
                  //             child: const Text(
                  //               'Learn more',
                  //               style: TextStyle(
                  //                 color: Colors.black87,
                  //                 fontSize: 14,
                  //                 letterSpacing: 1,
                  //                 fontWeight: FontWeight.w600,
                  //                 decoration: TextDecoration.underline,
                  //               ),
                  //             ),
                  //           )
                  //         ],
                  //       ),
                  //     );
                  //   } else {
                  //     return const SizedBox(
                  //       height: 2,
                  //     );
                  //   }
                  // }),
                ],
              ),
            ),
          ),

          const SizedBox(
            height: 16,
          ),
          const SizedBox(
            width: double.infinity,
            child: Text(
              'Pay Securely at Checkout With',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black87, fontSize: 16),
            ),
          ),

          const SizedBox(
            height: 16,
          ),

          SizedBox(
            width: double.infinity,
            child: Wrap(
              direction: Axis.horizontal,
              alignment: WrapAlignment.start,
              spacing: 8,
              runSpacing: 8,
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF4F4F4),
                    borderRadius: BorderRadius.circular(4.0),
                    border: Border.all(color: const Color(0xFFF9F9F9)),
                  ),
                  child: const Image(
                    image: AssetImage('images/malayanbanking.png'),
                    width: 50,
                    height: 24,
                  ),
                ),
                Container(
                  // margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF4F4F4),
                    borderRadius: BorderRadius.circular(4.0),
                    border: Border.all(color: const Color(0xFFF9F9F9)),
                  ),
                  child: const Image(
                    image: AssetImage('images/cimbbank.png'),
                    width: 50,
                    height: 24,
                  ),
                ),
                Container(
                  // margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF4F4F4),
                    borderRadius: BorderRadius.circular(4.0),
                    border: Border.all(color: const Color(0xFFF9F9F9)),
                  ),
                  child: const Image(
                    image: AssetImage('images/pfx.png'),
                    width: 50,
                    height: 24,
                  ),
                ),
                Container(
                  // margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF4F4F4),
                    borderRadius: BorderRadius.circular(4.0),
                    border: Border.all(color: const Color(0xFFF9F9F9)),
                  ),
                  child: const Image(
                    image: AssetImage('images/visaa.png'),
                    width: 50,
                    height: 24,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16,),

          // Container(
          //   width: double.infinity,
          //   margin: EdgeInsets.symmetric(vertical: 20, horizontal: 0),
          //   padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          //   decoration: BoxDecoration(
          //     borderRadius: BorderRadius.circular(6.0),
          //     border: Border.all(color: Color(0xFFD0D1D2).withOpacity(0.5)),
          //   ),
          //   child: Column(
          //     mainAxisSize: MainAxisSize.min,
          //     children: [
          //       Row(
          //         mainAxisSize: MainAxisSize.max,
          //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //         children: [
          //           Expanded(
          //               flex: 1,
          //               child: Column(
          //                 mainAxisAlignment: MainAxisAlignment.center,
          //                 children: [
          //                   Image(
          //                     image: AssetImage('images/fast-safety.png'),
          //                     width: 80,
          //                     height: 80,
          //                   ),
          //                   SizedBox(
          //                     height: 8,
          //                   ),
          //                   SizedBox(
          //                     width: double.infinity,
          //                     child: Text(
          //                       'Fast & Safe Fulfilment',
          //                       textAlign: TextAlign.center,
          //                       style: TextStyle(color: Colors.black87),
          //                     ),
          //                   )
          //                 ],
          //               )),
          //           Expanded(
          //               flex: 1,
          //               child: Column(
          //                 mainAxisAlignment: MainAxisAlignment.center,
          //                 children: [
          //                   Image(
          //                     image: AssetImage('images/grab-black.png'),
          //                     width: 80,
          //                     height: 80,
          //                   ),
          //                   SizedBox(
          //                     height: 8,
          //                   ),
          //                   SizedBox(
          //                     width: double.infinity,
          //                     child: Text(
          //                       'Same Day Grab Delivery',
          //                       textAlign: TextAlign.center,
          //                       style: TextStyle(color: Colors.black87),
          //                     ),
          //                   )
          //                 ],
          //               )),
          //         ],
          //       ),
          //       SizedBox(
          //         height: 16,
          //       ),
          //       Row(
          //         mainAxisSize: MainAxisSize.max,
          //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //         children: [
          //           Expanded(
          //               flex: 1,
          //               child: Column(
          //                 mainAxisAlignment: MainAxisAlignment.center,
          //                 children: [
          //                   Image(
          //                     image: AssetImage('images/secure-payment.png'),
          //                     width: 80,
          //                     height: 80,
          //                   ),
          //                   SizedBox(
          //                     height: 8,
          //                   ),
          //                   SizedBox(
          //                     width: double.infinity,
          //                     child: Text(
          //                       'Secure Payment',
          //                       textAlign: TextAlign.center,
          //                       style: TextStyle(color: Colors.black87),
          //                     ),
          //                   )
          //                 ],
          //               )),
          //           Expanded(
          //               flex: 1,
          //               child: Column(
          //                 mainAxisAlignment: MainAxisAlignment.center,
          //                 children: [
          //                   Image(
          //                     image: AssetImage('images/warrenty.png'),
          //                     width: 80,
          //                     height: 80,
          //                   ),
          //                   SizedBox(
          //                     height: 8,
          //                   ),
          //                   SizedBox(
          //                     width: double.infinity,
          //                     child: Text(
          //                       'Warrenty',
          //                       textAlign: TextAlign.center,
          //                       style: TextStyle(color: Colors.black87),
          //                     ),
          //                   )
          //                 ],
          //               )),
          //         ],
          //       ),
          //     ],
          //   ),
          // ),

          /// ................Product Details Tab...................
          const SizedBox(
            width: double.infinity,
            child: Divider(
              thickness: 1,
            ),
          ),
          SizedBox(
            width: double.infinity,
            child: ExpandablePanel(
              collapsed: const SizedBox(height: 0,),
              header: const ListTile(
                title: Text(
                  'Description',
                  style: TextStyle(color: Colors.black87, fontSize: 16),
                ),
              ),
              expanded: SizedBox(
                width: double.infinity,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Html(
                    data: """${widget.snapshot.data!.data!.product!.narration}""",
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(
            width: double.infinity,
            child: Divider(
              thickness: 1,
            ),
          ),
          SizedBox(
            width: double.infinity,
            child: ExpandablePanel(
              collapsed: const SizedBox(height: 0,),
              header: const ListTile(
                title: Text(
                  'Shipping & Return Policy',
                  style: TextStyle(color: Colors.black87, fontSize: 16),
                ),
              ),
              expanded: SizedBox(
                width: double.infinity,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Html(
                    data:
                        """${SharedPreferenceUtils.appSettingModel.data!.shippingreturn}""",
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(
            width: double.infinity,
            child: Divider(
              thickness: 1,
            ),
          ),

          ///.......................... Revies ................
          // SizedBox(
          //   width: double.infinity,
          //   child: ExpandablePanel(
          //     header: ListTile(
          //       title: Text(
          //         'Reviews',
          //         style: TextStyle(color: Colors.black87, fontSize: 16),
          //       ),
          //     ),
          //     expanded: SizedBox(
          //       width: double.infinity,
          //       child: Container(
          //         margin: const EdgeInsets.symmetric(horizontal: 16),
          //         child: Column(
          //           crossAxisAlignment: CrossAxisAlignment.start,
          //           children: [
          //             Padding(
          //               padding: const EdgeInsets.symmetric(vertical: 16),
          //               child: Row(
          //                 children: [
          //                   Text(
          //                     'Ratings',
          //                     style: TextStyle(color: Colors.black87),
          //                   ),
          //                   Spacer(),
          //                   OutlinedButton(
          //                       style: OutlinedButton.styleFrom(
          //                           backgroundColor: Colors.transparent,
          //                           side:
          //                               BorderSide(width: 2, color: Colors.red),
          //                           shape: RoundedRectangleBorder(
          //                               borderRadius:
          //                                   BorderRadius.circular(24))),
          //                       onPressed: () {},
          //                       child: Padding(
          //                         padding: const EdgeInsets.symmetric(
          //                             horizontal: 10),
          //                         child: Text(
          //                           'Rate Now',
          //                           style: TextStyle(
          //                               color: Colors.red, fontSize: 10),
          //                         ),
          //                       ))
          //                 ],
          //               ),
          //             ),
          //             Container(
          //               width: double.infinity,
          //               height: MediaQuery.of(context).size.width * 0.25,
          //               child: Row(
          //                 children: [
          //                   Expanded(
          //                       flex: 1,
          //                       child: Center(
          //                         child: Container(
          //                           height: MediaQuery.of(context).size.width *
          //                               0.25,
          //                           width: MediaQuery.of(context).size.width *
          //                               0.25,
          //                           decoration: ShapeDecoration(
          //                               shape: CircleBorder(),
          //                               color: Color(0xFFECECEC)),
          //                           child: Column(
          //                             mainAxisSize: MainAxisSize.min,
          //                             mainAxisAlignment:
          //                                 MainAxisAlignment.center,
          //                             children: [
          //                               Row(
          //                                 mainAxisAlignment:
          //                                     MainAxisAlignment.center,
          //                                 children: [
          //                                   Text(
          //                                     '3.5',
          //                                     style: TextStyle(
          //                                         color: Colors.black,
          //                                         fontSize: 14),
          //                                   ),
          //                                   Padding(
          //                                     padding: EdgeInsets.symmetric(
          //                                         horizontal: 5),
          //                                     child: Icon(
          //                                       Icons.star,
          //                                       color: Colors.amber,
          //                                       size: 20,
          //                                     ),
          //                                   )
          //                                 ],
          //                               ),
          //                               Center(
          //                                 child: Text(
          //                                   '122 Ratings',
          //                                   style: TextStyle(
          //                                       color: Colors.black54,
          //                                       fontSize: 10),
          //                                 ),
          //                               )
          //                             ],
          //                           ),
          //                         ),
          //                       )),
          //                   Expanded(
          //                       flex: 2,
          //                       child: Row(
          //                         children: [
          //                           SizedBox(
          //                             width: 8,
          //                           ),
          //                           Column(
          //                             mainAxisSize: MainAxisSize.max,
          //                             children: [
          //                               Expanded(
          //                                 flex: 1,
          //                                 child: Center(
          //                                   child: Text(
          //                                     "5",
          //                                     style: TextStyle(
          //                                         fontSize: 10,
          //                                         fontWeight: FontWeight.bold,
          //                                         color: Colors.black),
          //                                   ),
          //                                 ),
          //                               ),
          //                               Expanded(
          //                                 flex: 1,
          //                                 child: Center(
          //                                   child: Text(
          //                                     "4",
          //                                     style: TextStyle(
          //                                         fontSize: 10,
          //                                         fontWeight: FontWeight.bold,
          //                                         color: Colors.black),
          //                                   ),
          //                                 ),
          //                               ),
          //                               Expanded(
          //                                 flex: 1,
          //                                 child: Center(
          //                                   child: Text(
          //                                     "3",
          //                                     style: TextStyle(
          //                                         fontSize: 10,
          //                                         fontWeight: FontWeight.bold,
          //                                         color: Colors.black),
          //                                   ),
          //                                 ),
          //                               ),
          //                               Expanded(
          //                                 flex: 1,
          //                                 child: Center(
          //                                   child: Text(
          //                                     "2",
          //                                     style: TextStyle(
          //                                         fontSize: 10,
          //                                         fontWeight: FontWeight.bold,
          //                                         color: Colors.black),
          //                                   ),
          //                                 ),
          //                               ),
          //                               Expanded(
          //                                 flex: 1,
          //                                 child: Center(
          //                                   child: Text(
          //                                     "1",
          //                                     style: TextStyle(
          //                                         fontSize: 10,
          //                                         fontWeight: FontWeight.bold,
          //                                         color: Colors.black),
          //                                   ),
          //                                 ),
          //                               ),
          //                             ],
          //                           ),
          //                           SizedBox(
          //                             width: 8,
          //                           ),
          //                           Column(
          //                             mainAxisSize: MainAxisSize.max,
          //                             children: [
          //                               Expanded(
          //                                   child: Icon(
          //                                 Icons.star,
          //                                 color: Colors.amber,
          //                                 size: 14,
          //                               )),
          //                               Expanded(
          //                                   child: Icon(
          //                                 Icons.star,
          //                                 color: Colors.amber,
          //                                 size: 14,
          //                               )),
          //                               Expanded(
          //                                   child: Icon(
          //                                 Icons.star,
          //                                 color: Colors.amber,
          //                                 size: 14,
          //                               )),
          //                               Expanded(
          //                                   child: Icon(
          //                                 Icons.star,
          //                                 color: Colors.amber,
          //                                 size: 14,
          //                               )),
          //                               Expanded(
          //                                   child: Icon(
          //                                 Icons.star,
          //                                 color: Colors.amber,
          //                                 size: 14,
          //                               )),
          //                             ],
          //                           ),
          //                           SizedBox(
          //                             width: 8,
          //                           ),
          //                           Column(
          //                             mainAxisSize: MainAxisSize.max,
          //                             children: [
          //                               Expanded(
          //                                 flex: 1,
          //                                 child: Center(
          //                                   child: LinearPercentIndicator(
          //                                     width: MediaQuery.of(context)
          //                                             .size
          //                                             .width *
          //                                         0.3,
          //                                     lineHeight: 5.0,
          //                                     percent: 0.8,
          //                                     progressColor: Colors.green,
          //                                   ),
          //                                 ),
          //                               ),
          //                               Expanded(
          //                                 flex: 1,
          //                                 child: Center(
          //                                   child: LinearPercentIndicator(
          //                                     width: MediaQuery.of(context)
          //                                             .size
          //                                             .width *
          //                                         0.3,
          //                                     lineHeight: 5.0,
          //                                     percent: 0.7,
          //                                     progressColor: Colors.green,
          //                                   ),
          //                                 ),
          //                               ),
          //                               Expanded(
          //                                 flex: 1,
          //                                 child: Center(
          //                                   child: LinearPercentIndicator(
          //                                     width: MediaQuery.of(context)
          //                                             .size
          //                                             .width *
          //                                         0.3,
          //                                     lineHeight: 5.0,
          //                                     percent: 0.5,
          //                                     progressColor: Colors.amber,
          //                                   ),
          //                                 ),
          //                               ),
          //                               Expanded(
          //                                 flex: 1,
          //                                 child: Center(
          //                                   child: LinearPercentIndicator(
          //                                     width: MediaQuery.of(context)
          //                                             .size
          //                                             .width *
          //                                         0.3,
          //                                     lineHeight: 5.0,
          //                                     percent: 0.35,
          //                                     progressColor: Colors.red,
          //                                   ),
          //                                 ),
          //                               ),
          //                               Expanded(
          //                                 flex: 1,
          //                                 child: Center(
          //                                   child: LinearPercentIndicator(
          //                                     width: MediaQuery.of(context)
          //                                             .size
          //                                             .width *
          //                                         0.3,
          //                                     lineHeight: 5.0,
          //                                     percent: 0.2,
          //                                     progressColor: Colors.red,
          //                                   ),
          //                                 ),
          //                               ),
          //                             ],
          //                           ),
          //                           SizedBox(
          //                             width: 8,
          //                           ),
          //                           Column(
          //                             children: [
          //                               Expanded(
          //                                   child: Center(
          //                                 child: Text(
          //                                   '80',
          //                                   style: TextStyle(
          //                                       fontSize: 9,
          //                                       color: Colors.black54),
          //                                 ),
          //                               )),
          //                               Expanded(
          //                                   child: Center(
          //                                 child: Text(
          //                                   '70',
          //                                   style: TextStyle(
          //                                       fontSize: 9,
          //                                       color: Colors.black54),
          //                                 ),
          //                               )),
          //                               Expanded(
          //                                   child: Center(
          //                                 child: Text(
          //                                   '55',
          //                                   style: TextStyle(
          //                                       fontSize: 9,
          //                                       color: Colors.black54),
          //                                 ),
          //                               )),
          //                               Expanded(
          //                                   child: Center(
          //                                 child: Text(
          //                                   '35',
          //                                   style: TextStyle(
          //                                       fontSize: 9,
          //                                       color: Colors.black54),
          //                                 ),
          //                               )),
          //                               Expanded(
          //                                   child: Center(
          //                                 child: Text(
          //                                   '20',
          //                                   style: TextStyle(
          //                                       fontSize: 9,
          //                                       color: Colors.black54),
          //                                 ),
          //                               )),
          //                             ],
          //                           )
          //                         ],
          //                       ))
          //                 ],
          //               ),
          //             )
          //           ],
          //         ),
          //       ),
          //     ),
          //   ),
          // ),
          // SizedBox(
          //   width: double.infinity,
          //   child: Divider(
          //     thickness: 1,
          //   ),
          // ),

          const SizedBox(
            height: 24,
          ),

          const SizedBox(
            width: double.infinity,
            child: Text(
              'Shop other product by same brand',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 18,
                  fontWeight: FontWeight.normal),
            ),
          ),

          GestureDetector(
            onLongPress: () {
              Common.toastMsg(
                  'Click here to show ${widget.snapshot.data!.data!.brand!.name} product');
            },
            onTap: () async {
              try {
                final result = await InternetAddress.lookup('example.com');
                if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
                  context.read<BrandDetailsNotifier>().changeCategoryName('All Product');
                  brandProductBloc.page = 1;
                  context.read<BrandDetailsNotifier>().changeBtnClear(1);
                  BrandDetailsPage.brandPk =
                      widget.snapshot.data!.data!.brand!.pkno;
                  Navigator.push(context, BrandDetailsPage.route());
                }
              } on SocketException catch (_) {
                Common.toastMsg('No Internet Connection');
              }
            },
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.only(left: 2, right: 2, top: 16),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.0),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      offset: const Offset(1, 0), //(x,y)
                      blurRadius: 6.0,
                    ),
                  ]),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    flex: 1,
                    child: Container(
                        padding:
                        const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
                        child: ConstrainedBox(
                            constraints: const BoxConstraints(
                                minHeight: 24, maxHeight: 50),
                            child: widget.snapshot.data!.data!.brand!.brand_logo ==
                                    null
                                ? const NoImageWidget(
                                    text: 'No Image',
                                  )
                                : CacheImageProvide(
                                    url: widget
                                        .snapshot.data!.data!.brand!.brand_logo,
                                  ))),
                  ),
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Text(
                            '${widget.snapshot.data!.data!.brand!.name}',
                            style: const TextStyle(
                                color: Colors.black87,
                                fontWeight: FontWeight.w600,
                                fontSize: 18,
                                fontStyle: FontStyle.normal),
                          ),
                          const SizedBox(
                            height: 8,
                          ),
                          // Text(
                          //   'Click here',
                          //   style: TextStyle(
                          //       color: Colors.black87,
                          //       fontWeight: FontWeight.w600,
                          //       fontSize: 14,
                          //       fontStyle: FontStyle.italic),
                          // ),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// ......................... Hoalah Dialog..........................
  Widget hoolahDetails() {
    return CustomScrollView(
      scrollDirection: Axis.vertical,
      slivers: [
        SliverToBoxAdapter(
          child: Align(
            alignment: Alignment.topRight,
            child: IconButton(
              onPressed: () {},
              icon: const Icon(
                Icons.close,
                color: Colors.black54,
              ),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: Image(
            image: AssetImage('images/hoolahh.png'),
            width: 150,
            height: 48,
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 16,
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            width: double.infinity,
            child: Text(
              '3 monthly interest free installments',
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            height: 16,
          ),
        ),
        const SliverToBoxAdapter(
          child: SizedBox(
            width: double.infinity,
            child: Text(
              'Get what you need now, and pay later with hoolah. For more information, visit hoolah.co',
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 16,
                  fontWeight: FontWeight.normal),
            ),
          ),
        ),
      ],
    );
  }
}

/// Related Card....................
class RelatedCard extends StatefulWidget {
  final AsyncSnapshot<ProductDetailsModel> snapshot;
  final int index;
  const RelatedCard(this.snapshot, this.index);
  @override
  _RelatedCardState createState() => _RelatedCardState();
}

class _RelatedCardState extends State<RelatedCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            ProductDetailsPage.productUrl =
                widget.snapshot.data!.data!.realatedProduct![widget.index].url;
            ProductDetailsPage.variantPk = widget
                .snapshot.data!.data!.realatedProduct![widget.index].fprdvariantno;
            ProductDetailsPage.isWish =
                widget.snapshot.data!.data!.realatedProduct![widget.index].isWish;
            Navigator.pop(context);
            Navigator.of(context).push(
                CustomRoutePageBuilder.createPageRouteLeft(
                    context, const ProductDetailsPage()));
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: Container(
        decoration: BoxDecoration(
            border:
                Border.all(color: const Color(0xFFD0D1D2).withOpacity(0.3), width: 1),
            color: Colors.transparent),
        margin: const EdgeInsets.symmetric(horizontal: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(
              height: 140,
              width: 140,
              child: Center(
                  child: widget.snapshot.data!.data!.realatedProduct![widget.index]
                              .primaryimgrelativepath ==
                          null
                      ? const NoImageWidget(
                          text: 'No Image',
                        )
                      : CacheImageProvide(
                          url: widget
                              .snapshot
                              .data!
                              .data!
                              .realatedProduct![widget.index]
                              .primaryimgrelativepath,
                        )),
            ),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: const BoxDecoration(color: Colors.transparent),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 120,
                    child: Text(
                      '${widget.snapshot.data!.data!.realatedProduct![widget.index].variantname}',
                      textAlign: TextAlign.center,
                      maxLines: 3,
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.normal,
                          color: Colors.black87),
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  SizedBox(
                    //width: double.infinity,
                    child: Text(
                      'RM${widget.snapshot.data!.data!.realatedProduct![widget.index].price!.toStringAsFixed(2)}',
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.normal,
                          color: Color(0xFFF68721)),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

/// hoolah ..................
class HoolahDialog extends StatelessWidget {
  const HoolahDialog({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: CustomScrollView(
          scrollDirection: Axis.vertical,
          slivers: [
            SliverToBoxAdapter(
              child: Align(
                alignment: Alignment.topRight,
                child: IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: const Icon(
                    Icons.close,
                    color: Colors.black54,
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: Image(
                image: AssetImage('images/hoolahh.png'),
                width: 150,
                height: 48,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 16,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  '3 monthly interest free installments',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 16,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'Get what you need now, and pay later with hoolah. For more information, visit hoolah.co',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black54,
                      fontSize: 16,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: Image(
                image: AssetImage('images/egg.png'),
                width: 80,
                height: 80,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  '0% Interest',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black87,
                      fontSize: 18,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'No Processing Fees',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black87,
                      fontSize: 18,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'You only pay what you see.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black54,
                      fontSize: 16,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'There are no gimmicks',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black54,
                      fontSize: 16,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 16,
              ),
            ),
            const SliverToBoxAdapter(
                child: Icon(
              Icons.credit_card_sharp,
              color: Color(0xFFda0000),
              size: 80,
            )),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'Acceptance Of Both',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black87,
                      fontSize: 18,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'Debit And Credit Cart',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black87,
                      fontSize: 18,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'Pay with any card type',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black54,
                      fontSize: 16,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'issued by any banks.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black54,
                      fontSize: 16,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 16,
              ),
            ),
            const SliverToBoxAdapter(
              child: Image(
                image: AssetImage('images/hare_icon.png'),
                width: 80,
                height: 80,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'Seamless Checkout',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black87,
                      fontSize: 18,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'No credit checks. Just select \nhoolah as your payment option.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black54,
                      fontSize: 16,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 30,
              ),
            ),
            SliverToBoxAdapter(
              child: Container(
                width: double.infinity,
                height: 50,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30.0),
                    color: Colors.black87),
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                      primary: Colors.black87,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0))),
                  child: const Text(
                    'HOW IT WORKS?',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 30,
              ),
            ),
          ],
        ),
      ),
    ));
  }
}

/// Grab.........................
class GrabDialog extends StatelessWidget {
  const GrabDialog({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: CustomScrollView(
          scrollDirection: Axis.vertical,
          slivers: [
            SliverToBoxAdapter(
              child: Align(
                alignment: Alignment.topRight,
                child: IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.close,
                      color: Colors.black54,
                    )),
              ),
            ),
            SliverToBoxAdapter(
              child: Image.network(
                  'https://assets.grab.com/wp-content/uploads/sites/4/2020/11/19140313/2_PayLater_logo.png'),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 16,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'With PayLater, get what you need now and pay later',
                  style: TextStyle(color: Colors.black54, fontSize: 18),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 24,
              ),
            ),
            const SliverToBoxAdapter(
                child: Align(
              alignment: Alignment.center,
              child: Image(
                image: AssetImage('images/payment_grab.png'),
              ),
            )),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 8,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'Spread your bill without interest',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black87,
                      fontSize: 18,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 8,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'With 4 monthly interest-free instalments, we give you more time to pay in smaller amounts.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black54,
                      fontSize: 18,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 24,
              ),
            ),
            const SliverToBoxAdapter(
                child: Align(
              alignment: Alignment.center,
              child: Image(
                image: AssetImage('images/like_grab.png'),
              ),
            )),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 8,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'No hidden charges, free to use',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black87,
                      fontSize: 18,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 8,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'Automatic repayments ensures you won\'t miss any payments.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black54,
                      fontSize: 18,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 24,
              ),
            ),
            const SliverToBoxAdapter(
                child: Align(
              alignment: Alignment.center,
              child: Image(
                image: AssetImage('images/checkout_grab.png'),
              ),
            )),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 8,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'Fast and secure Checkout in 2 taps.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black87,
                      fontSize: 18,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 8,
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  'Set up in 2 minutes without having to save card details on multiple shopping sites anymore.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black54,
                      fontSize: 18,
                      fontWeight: FontWeight.normal),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 30,
              ),
            ),
            SliverToBoxAdapter(
              child: Container(
                width: double.infinity,
                height: 50,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30.0),
                    color: Colors.green),
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                      primary: Colors.green,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0))),
                  child: const Text(
                    'LEARN MORE',
                    style: TextStyle(color: Colors.white, letterSpacing: 2),
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 30,
              ),
            ),
          ],
        ),
      ),
    ));
  }
}
