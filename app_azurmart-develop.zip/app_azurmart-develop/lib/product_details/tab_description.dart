import 'package:azuramartmy/provider_models/product_details_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DetailsDescription extends StatelessWidget {
  final AsyncSnapshot<ProductDetailsModel> snapshot;
  const DetailsDescription(this.snapshot);

  String removeAllHtmlTags(String htmlText) {
    RegExp exp = RegExp(r"<[^>]*>", multiLine: true, caseSensitive: true);

    return htmlText.replaceAll(exp, '');
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: SizedBox(
            width: double.infinity,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(
                removeAllHtmlTags(snapshot.data!.data!.product!.narration!),
                style: const TextStyle(color: Colors.black54, fontSize: 14),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
