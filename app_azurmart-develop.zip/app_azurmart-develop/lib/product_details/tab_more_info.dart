import 'package:azuramartmy/provider_models/product_details_model.dart';
import 'package:flutter/material.dart';
class ProductMoreInfo extends StatelessWidget {
  const ProductMoreInfo({Key? key}) : super(key: key);

  // final AsyncSnapshot<ProductDetailsModel> snapshot;
  // const ProductMoreInfo(this.snapshot);
  @override
  Widget build(BuildContext context) {
    return const SizedBox(
      width: double.infinity,
      child: Text('We deliver to over 100 countries around the world. For full details of the delivery options we offer, please view our Delivery information We hope you’ll love every purchase, but if you ever need to return an item you can do so within a month of receipt. For full details of how to make a return,',style: TextStyle(color: Colors.black54,fontSize: 12.0)),
    );
  }
}
