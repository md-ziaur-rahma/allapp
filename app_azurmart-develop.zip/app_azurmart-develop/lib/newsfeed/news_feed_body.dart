import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:optimized_cached_image/optimized_cached_image.dart';

class NewsFeedBody extends StatefulWidget {
  const NewsFeedBody({Key? key}) : super(key: key);

  @override
  _NewsFeedBodyState createState() => _NewsFeedBodyState();
}

class _NewsFeedBodyState extends State<NewsFeedBody> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          SliverList(
              delegate: SliverChildBuilderDelegate((BuildContext context, index) {
                return const PublicPostCard();
              }, childCount: 40))
        ],
      ),
    );
  }
}

class PublicPostCard extends StatefulWidget {
  const PublicPostCard({Key? key}) : super(key: key);

  @override
  _PublicPostCardState createState() => _PublicPostCardState();
}

class _PublicPostCardState extends State<PublicPostCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(10.0)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          ListTile(
            title: const Text('Mithun Sarkar'),
            subtitle: const Text('27 minutes ago'),
            leading: const CircleAvatar(
              radius: 20,
              backgroundImage: AssetImage('images/user_icon.png'),
            ),
            trailing: GestureDetector(
              // child: Icon(FontAwesomeIcons.bars),
              child: const Icon(Icons.share_outlined),
            ),
          ),
          Container(
            width: double.infinity,
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: const Text(
              'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electroni',
              style: TextStyle(color: Colors.black87, fontSize: 16),
            ),
          ),
          Container(
            height: MediaQuery.of(context).orientation == Orientation.portrait
                ? MediaQuery.of(context).size.width * 0.9
                : MediaQuery.of(context).size.height * 0.9,
            width: double.infinity,
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            child: Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(0),
                child: OptimizedCacheImage(
                  imageUrl:
                      'http://dev.ukshop.my/media/images/banner/prod_05052021_609274c54b84a.jpg',
                  imageBuilder: (context, imageProvider) => Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: imageProvider,
                        fit: BoxFit.cover,
                        // colorFilter: ColorFilter.mode(Colors.transparent, BlendMode.clear)
                      ),
                    ),
                  ),
                  placeholder: (context, url) => const Center(
                    child: SizedBox(
                      height: 16,
                      width: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.0,
                        valueColor: AlwaysStoppedAnimation(Color(0xFFF68721)),
                      ),
                    ),
                  ),
                  errorWidget: (context, url, error) => const Icon(Icons.error),
                ),
              ),
            ),
          ),
          // Container(
          //   margin: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.spaceAround,
          //     crossAxisAlignment: CrossAxisAlignment.center,
          //     children: [
          //       Row(
          //         mainAxisSize: MainAxisSize.min,
          //         children: [
          //           GestureDetector(
          //             child: Icon(
          //               Icons.favorite_outline,
          //               color: Color(0xFFD1D2D3),
          //             ),
          //           ),
          //           SizedBox(
          //             width: 8,
          //           ),
          //           Text('45',style: TextStyle(color: Colors.black54),)
          //         ],
          //       ),
          //       Row(
          //         mainAxisSize: MainAxisSize.min,
          //         children: [
          //           GestureDetector(
          //             child: Icon(
          //               Icons.favorite_outline,
          //               color: Color(0xFFD1D2D3),
          //             ),
          //           ),
          //           SizedBox(
          //             width: 8,
          //           ),
          //           Text('23',style: TextStyle(color: Colors.black54),)
          //         ],
          //       ),
          //       Spacer(),
          //       Row(
          //         mainAxisSize: MainAxisSize.min,
          //         children: [
          //           GestureDetector(
          //             child: Icon(
          //               Icons.share,
          //               color: Colors.black87,
          //             ),
          //           ),
          //           SizedBox(
          //             width: 8,
          //           ),
          //           Text('share',style: TextStyle(color: Colors.black54),)
          //         ],
          //       ),
          //     ],
          //   ),
          // )
        ],
      ),
    );
  }
}
