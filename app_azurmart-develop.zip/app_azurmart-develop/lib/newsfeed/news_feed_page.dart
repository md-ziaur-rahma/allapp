import 'package:azuramartmy/newsfeed/news_feed_body.dart';
import 'package:flutter/material.dart';

class NewsFeedPage extends StatefulWidget {
  const NewsFeedPage({Key? key}) : super(key: key);
  static Route route() {
    return MaterialPageRoute(builder: (_) => const NewsFeedPage());
  }

  @override
  _NewsFeedPageState createState() => _NewsFeedPageState();
}

class _NewsFeedPageState extends State<NewsFeedPage>
    with SingleTickerProviderStateMixin {
  late TabController _controller;
  int _selectedIndex = 0;
  @override
  void initState() {
    super.initState();
    _controller = TabController(length: 3, vsync: this);
    _controller.addListener(() {
      _selectedIndex = _controller.index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
          body: SafeArea(
        child: NestedScrollView(
          headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
            return <Widget>[
              const SliverAppBar(
                title: Text('Tabs Demo'),
                backgroundColor: Colors.white,
                pinned: true,
                floating: true,
                bottom: TabBar(
                  isScrollable: true,
                  tabs: [
                    Tab(
                        child: Text(
                      'PUBLIC',
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                    )),
                    Tab(
                        child: Text(
                      'ANNOUNCEMENT',
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                    )),
                    Tab(
                        child: Text(
                      'DAILY NEWS',
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                    )),
                  ],
                ),
              ),
            ];
          },
          body: const TabBarView(
            children: <Widget>[
              NewsFeedBody(),
              NewsFeedBody(),
              NewsFeedBody(),
            ],
          ),
        ),
      )),
    );
  }
}
