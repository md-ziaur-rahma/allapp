import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/my_bloc/blog_details_bloc.dart';
import 'package:azuramartmy/provider_models/blog_details_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';

class BlogDetailsPage extends StatelessWidget {
  const BlogDetailsPage({Key? key,this.slug}) : super(key: key);
  final String? slug;

  @override
  Widget build(BuildContext context) {
    blogDetailsBloc.fetchBlogDetails(slug!);
    return Scaffold(
      body: SafeArea(
        child: StreamBuilder(
          stream: blogDetailsBloc.allBlogDetails,
          builder: (BuildContext context, AsyncSnapshot<BlogDetailsModel> snapshot) {
            if (snapshot.hasData) {
              return CustomScrollView(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                slivers: [
                  SliverAppBar(
                    iconTheme: const IconThemeData(color: Colors.black87),
                    backgroundColor: Colors.white,
                    titleSpacing: 0,
                    pinned: true,
                    // snap: true,
                    // floating: true,
                    expandedHeight: MediaQuery.of(context).orientation == Orientation.portrait ? 200.0 : 300,
                    onStretchTrigger: () async {
                      print('load more data ...........');
                    },
                    flexibleSpace: FlexibleSpaceBar(
                      stretchModes: const [
                        StretchMode.zoomBackground,
                        StretchMode.blurBackground,
                        StretchMode.fadeTitle
                      ],
                      title: SizedBox(
                        width: double.infinity,
                        child: Text('${snapshot.data!.data!.title}',softWrap: true,style: const TextStyle(color: Colors.black),overflow: TextOverflow.ellipsis,),
                      ),
                      collapseMode: CollapseMode.pin,
                      background: DecoratedBox(
                        position: DecorationPosition.foreground,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              const Color(0xffffffff).withOpacity(1),
                              Colors.transparent
                            ],
                            begin: Alignment.bottomCenter,
                            end: Alignment.center,
                          )
                        ),
                        child: Image.network(Urls.basePictureUrl+snapshot.data!.data!.featureimage!,fit: BoxFit.cover,),
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      width: double.infinity,
                      child: Text('${snapshot.data!.data!.publishdate}',style: const TextStyle(color: Colors.black54,fontSize: 14),),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 3),
                      width: double.infinity,
                      child: Text('${snapshot.data!.data!.title}',style: const TextStyle(color: Colors.black87,fontSize: 18),),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      width: double.infinity,
                      child: Text('in ${snapshot.data!.data!.categoryname}',style: const TextStyle(color: Colors.black54,fontSize: 14),),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: SizedBox(
                      width: double.infinity,
                      child: Html(
                        data: """${snapshot.data!.data!.body}""",
                          onLinkTap: (String? url, RenderContext context, Map<String, String> attributes, element) {
                            Common.launchUrl(url);
                          },
                        // onImageTap: (String url, RenderContext insContext, Map<String, String> attributes, element){
                        //   Navigator.of(context).push(PageRouteBuilder(
                        //       opaque: true,
                        //       pageBuilder: (BuildContext context, _, __) {
                        //         return Center(
                        //           child: Image.network(
                        //             '$url',
                        //             loadingBuilder: (context, child, progress) {
                        //               return progress == null
                        //                   ? child
                        //                   : Center(
                        //                 child: SizedBox(
                        //                   height: 24,
                        //                   width: 24,
                        //                   child: CircularProgressIndicator(
                        //                     strokeWidth: 2,
                        //                   ),
                        //                 ),
                        //               );
                        //             },
                        //             errorBuilder: (BuildContext context,
                        //                 Object exception, StackTrace stackTrace) {
                        //               return Center(
                        //                 child: Container(
                        //                   decoration: BoxDecoration(
                        //                       borderRadius:
                        //                       BorderRadius.circular(6.0),
                        //                       border: Border.all(
                        //                           color: Color(0xFFB3BCCC),
                        //                           width: 1)),
                        //                   padding: const EdgeInsets.symmetric(
                        //                       vertical: 12, horizontal: 16),
                        //                   child: Text(
                        //                     'Failed To Load Image',
                        //                     style: TextStyle(
                        //                         color: Colors.black,
                        //                         fontSize: 18,
                        //                         fontWeight: FontWeight.bold),
                        //                   ),
                        //                 ),
                        //               );
                        //             },
                        //           ),
                        //         );
                        //       }
                        //   ));
                        // },
                      ),
                    ),
                  )
                ],
              );
            }  else if (snapshot.hasError) {
              return Center(
                child: Text(snapshot.error.toString()),
              );
            }
            return LoadingWidget(color: AppsColors.buttonColor,);
          },
        ),
      ),
    );
  }
}
