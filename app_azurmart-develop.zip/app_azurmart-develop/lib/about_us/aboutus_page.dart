import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/my_bloc/about_us_bloc.dart';
import 'package:azuramartmy/provider_models/aboutus_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_html/flutter_html.dart';

class AboutUs extends StatefulWidget {
  const AboutUs({Key? key,this.url}) : super(key: key);
  final String? url;

  static Route route() {
    return MaterialPageRoute(builder: (_) => const AboutUs());
  }

  @override
  _AboutUsState createState() => _AboutUsState();
}

class _AboutUsState extends State<AboutUs> {

  @override
  void initState() {
    aboutUsBloc.fetchAboutUs();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        // backgroundColor: Colors.white,
        body: StreamBuilder(
          stream: aboutUsBloc.allAboutUs,
          builder:
              (BuildContext context, AsyncSnapshot<AboutUsModel> snapshot) {
            if (snapshot.hasData) {
              return CustomScrollView(
                scrollDirection: Axis.vertical,
                slivers: [
                  SliverAppBar(
                    pinned: true,
                    backgroundColor: Colors.white,
                    iconTheme: const IconThemeData(color: Colors.black87),
                    systemOverlayStyle: SystemUiOverlayStyle.dark,
                    titleSpacing: 0,
                    title: Text(
                      '${snapshot.data!.data!.title}',
                      style: Theme.of(context).textTheme.headline5,
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      width: double.infinity,
                      child: Html(
                        data: """${snapshot.data!.data!.body}""",
                      ),
                    ),
                  )
                ],
              );
            } else if (snapshot.hasError) {
              return Center(
                child: Text(snapshot.error.toString()),
              );
            }
            return LoadingWidget(color: AppsColors.buttonColor,);
          },
        ),
      ),
    );
  }
}
