import 'dart:io';

import 'package:azuramartmy/all_category/all_category_notifier.dart';
import 'package:azuramartmy/category_evaly/category_evaly_page.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/provider_models/category2.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AllCategoryBody extends StatefulWidget {
  const AllCategoryBody({Key? key, this.snapshot}) : super(key: key);
  final Category2? snapshot;

  @override
  _AllCategoryBodyState createState() => _AllCategoryBodyState();
}

class _AllCategoryBodyState extends State<AllCategoryBody> {
  @override
  void initState() {
    setState(() {

    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.max,
        children: [
          SizedBox(
            width: MediaQuery.of(context).orientation == Orientation.portrait
                ? MediaQuery.of(context).size.width * 0.28
                : MediaQuery.of(context).size.height * 0.28,
            child: CustomScrollView(
              scrollDirection: Axis.vertical,
              slivers: [
                SliverList(
                    delegate: SliverChildBuilderDelegate(
                            (BuildContext context, index) {
                              if(widget.snapshot!.data![index].subcategories!.isNotEmpty){
                                return GestureDetector(
                                  onTap: () {
                                    context.read<AllCategoryNotifier>().changeSelectedIndex(index);
                                    setState(() {

                                    });
                                  },
                                  child: Container(
                                    height: MediaQuery.of(context).orientation ==
                                        Orientation.portrait
                                        ? MediaQuery.of(context).size.width * 0.3
                                        : MediaQuery.of(context).size.height * 0.3,
                                    width: MediaQuery.of(context).orientation ==
                                        Orientation.portrait
                                        ? MediaQuery.of(context).size.width * 0.3
                                        : MediaQuery.of(context).size.height * 0.3,
                                    margin: const EdgeInsets.symmetric(vertical: 3),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(2.0)),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          flex: 2,
                                          child: Center(
                                            child: ClipRRect(
                                              borderRadius: const BorderRadius.only(
                                                  topLeft: Radius.circular(10),
                                                  topRight: Radius.circular(10)),
                                              child: Container(
                                                  padding: const EdgeInsets.symmetric(
                                                      vertical: 2, horizontal: 2),
                                                  child: ConstrainedBox(
                                                      constraints: BoxConstraints(
                                                          minHeight: MediaQuery.of(context)
                                                              .size
                                                              .width *
                                                              0.15,
                                                          maxHeight: MediaQuery.of(context)
                                                              .size
                                                              .width *
                                                              0.19),
                                                      child: widget.snapshot!.data![index].thumbnail_path == null
                                                          ? const NoImageWidget(text: 'No \nImage',)
                                                          : CacheImageProvide(url: widget.snapshot!.data![index].thumbnail_path,)
                                                  )
                                              ),
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 1,
                                          child: Center(
                                            child: Container(
                                              margin:
                                              const EdgeInsets.symmetric(horizontal: 8),
                                              child: Text(
                                                '${widget.snapshot!.data![index].categoryName}',
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: context.watch<AllCategoryNotifier>().selectedIndex == index
                                                        ? AppsColors.blueGreenX
                                                        : Colors.black87,
                                                    fontSize: 12),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              }else {
                                return const SizedBox(height: 0,);
                              }
                        }, childCount: widget.snapshot!.data!.length)),
              ],
            ),
          ),
          const VerticalDivider(
            thickness: 1,
            width: 1,
            color: Colors.transparent,
          ),
          Expanded(
            child: CustomScrollView(
              scrollDirection: Axis.vertical,
              slivers: [
                SliverToBoxAdapter(
                  child: Container(
                    margin: const EdgeInsets.only(top: 12, left: 8),
                    child: Wrap(
                      direction: Axis.horizontal,
                      crossAxisAlignment: WrapCrossAlignment.start,
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        for (var i = 0;
                        i <
                            widget
                                .snapshot!
                                .data![Provider.of<AllCategoryNotifier>(context,listen: false).selectedIndex]
                                .subcategories!
                                .length;
                        i++)
                          GestureDetector(
                            onTap: () async {
                              try {
                                final result =
                                await InternetAddress.lookup('example.com');
                                if (result.isNotEmpty &&
                                    result[0].rawAddress.isNotEmpty) {
                                  CategoryEPage.catPk = widget
                                      .snapshot!
                                      .data![Provider.of<AllCategoryNotifier>(context,listen: false).selectedIndex]
                                      .categoryId
                                      .toString();
                                  CategoryEPage.subCatPk = widget
                                      .snapshot!
                                      .data![Provider.of<AllCategoryNotifier>(context,listen: false).selectedIndex]
                                      .subcategories![i]
                                      .pkno
                                      .toString();
                                  Navigator.push(
                                      context, CategoryEPage.route());
                                }
                              } on SocketException catch (_) {
                                Common.toastMsg('No Internet Connection');
                              }
                            },
                            child: Container(
                              height: MediaQuery.of(context).orientation ==
                                  Orientation.portrait
                                  ? MediaQuery.of(context).size.width * 0.3
                                  : MediaQuery.of(context).size.height * 0.3,
                              width: MediaQuery.of(context).orientation ==
                                  Orientation.portrait
                                  ? MediaQuery.of(context).size.width * 0.3
                                  : MediaQuery.of(context).size.height * 0.3,
                              // margin: const EdgeInsets.only(left: 12),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10.0)),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: Center(
                                      child: ClipRRect(
                                        borderRadius: const BorderRadius.only(
                                            topLeft: Radius.circular(10),
                                            topRight: Radius.circular(10)),
                                        child: Container(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 2, horizontal: 2),
                                            child: ConstrainedBox(
                                                constraints: BoxConstraints(
                                                    minHeight:
                                                    MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                        0.15,
                                                    maxHeight:
                                                    MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                        0.19),
                                                child: widget.snapshot!.data![context.watch<AllCategoryNotifier>().selectedIndex].subcategories![i].icon == null
                                                    ? const NoImageWidget(text: 'No \nImage',)
                                                    : CacheImageProvide(url: widget.snapshot!.data![context.watch<AllCategoryNotifier>().selectedIndex].subcategories![i].icon,)
                                            )),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Center(
                                      child: SizedBox(
                                        child: Text(
                                          '${widget.snapshot!.data![context.watch<AllCategoryNotifier>().selectedIndex].subcategories![i].name}',
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                              color: Colors.black87,
                                              fontSize: 12),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}