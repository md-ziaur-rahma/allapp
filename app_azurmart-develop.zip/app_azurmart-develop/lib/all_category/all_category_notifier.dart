import 'package:flutter/foundation.dart';

class AllCategoryNotifier extends ChangeNotifier {
  int selectedIndex = 0;
  void changeSelectedIndex(int value){
    selectedIndex = value;
    notifyListeners();
  }
}