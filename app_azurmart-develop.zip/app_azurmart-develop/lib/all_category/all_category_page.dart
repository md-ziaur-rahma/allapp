import 'dart:io';

import 'package:azuramartmy/all_category/all_category_body.dart';
import 'package:azuramartmy/my_bloc/category_bloc.dart';
import 'package:azuramartmy/provider_models/category2.dart';
import 'package:azuramartmy/search/search_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AllCategoryPage extends StatefulWidget {
  const AllCategoryPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const AllCategoryPage());
  }

  @override
  _AllCategoryPageState createState() => _AllCategoryPageState();
}

class _AllCategoryPageState extends State<AllCategoryPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: AppsColors.white,
        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : SystemUiOverlayStyle(
            statusBarColor: AppsColors.white,
            statusBarIconBrightness: Brightness.dark),
        title: const Text(
          'Categories',
          style: TextStyle(
            color: Colors.black87,
          ),
        ),
        actions: [
          IconButton(
              onPressed: () {
                Navigator.push(context, SearchPage.route());
              },
              icon: const Icon(
                Icons.search,
                size: 20,
                color: Colors.black,
              )),
        ],
      ),
      body: SafeArea(
        child: AllCategoryBody(
          snapshot: SharedPreferenceUtils.categoryList,
        ),
      ),
    );
  }
}
