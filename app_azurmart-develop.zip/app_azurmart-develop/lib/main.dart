import 'dart:io';

import 'package:azuramartmy/address_manager/address_manager_notifier.dart';
import 'package:azuramartmy/all_category/all_category_notifier.dart';
import 'package:azuramartmy/brand_details/brand_details_chngenotifier.dart';
import 'package:azuramartmy/common_notifier/common_notifier.dart';
import 'package:azuramartmy/forgot_password/opt_notifier.dart';
import 'package:azuramartmy/home/home_page.dart';
import 'package:azuramartmy/no_internet_connection/no_internet_con_page.dart';
import 'package:azuramartmy/order_list/order_list_notifier.dart';
import 'package:azuramartmy/order_summery_info/order_details_info_notifier.dart';
import 'package:azuramartmy/splash/splash_view.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/wishlist/wishlist_notifier.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:oktoast/oktoast.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

///............... notification handler ..............
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // If you're going to use other Firebase services in the background, such as Firestore,
  // make sure you call `initializeApp` before using other Firebase services.
  await Firebase.initializeApp();
  print('Handling a background message ${message.messageId}');
}
const AndroidNotificationChannel channel = AndroidNotificationChannel(
  'high_importance_channel', // id
  'High Importance Notifications', // title
  // 'This channel is used for important notifications.', // description
  importance: Importance.high,
  playSound: true,
  enableVibration: true,
);

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
FlutterLocalNotificationsPlugin();

requestForIos() async {
  FirebaseMessaging messaging = FirebaseMessaging.instance;
  NotificationSettings settings = await messaging.requestPermission(
    alert: true,
    announcement: false,
    badge: true,
    carPlay: false,
    criticalAlert: false,
    provisional: false,
    sound: true,
  );

  if (settings.authorizationStatus == AuthorizationStatus.authorized) {
  } else if (settings.authorizationStatus ==
      AuthorizationStatus.provisional) {
  } else {}
}

void main() async {
  /// ................ push notification .................
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  if (Platform.isIOS) {
    requestForIos();
  }

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
      AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(channel);

  await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
    alert: true,
    badge: true,
    sound: true,
  );

  FirebaseMessaging.instance.getInitialMessage();
  FirebaseMessaging.instance.subscribeToTopic("all");

  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    RemoteNotification? notification = message.notification;
    AndroidNotification? android = message.notification?.android;

    if (notification != null && android != null) {
      flutterLocalNotificationsPlugin.show(
          notification.hashCode,
          notification.title,
          notification.body,
          NotificationDetails(
            android: AndroidNotificationDetails(
              channel.id,
              channel.name,
              // channel.description,
              styleInformation: const BigTextStyleInformation(''),
              icon: '@mipmap/ic_launcher',
            ),
          ));
    }
  });

  FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
    print('A new onMessageOpenedApp event was published!');

  });

  /// ................ push notification .................
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => BrandDetailsNotifier(),),
        ChangeNotifierProvider(create: (_) => AllCategoryNotifier(),),
        ChangeNotifierProvider(create: (_) => WishListNotifier(),),
        ChangeNotifierProvider(create: (_) => OrderDetailsInfoNotifier(),),
        ChangeNotifierProvider(create: (_) => OtpNotifier(),),
        ChangeNotifierProvider(create: (_) => CommonNotifier(),),
        ChangeNotifierProvider(create: (_) => OrderListNotifier(),),
        ChangeNotifierProvider(create: (_) => AddressManagerNotifier(),),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final _navigatorKey = GlobalKey<NavigatorState>();
  // NavigatorState? get _navigator => _navigatorKey.currentState;
  int? userId;
  String? token;

  Future<void> getUser()async{
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    SharedPreferenceUtils.userIdF = localStorage.getInt(SharedPreferenceUtils.USER_ID) ?? 0;
    SharedPreferenceUtils.usernameF = localStorage.getString(SharedPreferenceUtils.USER_NAME);
    SharedPreferenceUtils.mobileF = localStorage.getString(SharedPreferenceUtils.MOBILE);
    SharedPreferenceUtils.emailF = localStorage.getString(SharedPreferenceUtils.EMAIL);
    SharedPreferenceUtils.lastNameF = localStorage.getString(SharedPreferenceUtils.LAST_NAME);
    SharedPreferenceUtils.profilePicF = localStorage.getString(SharedPreferenceUtils.profilePic);
  }

  createSession() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    localStorage.setString(SharedPreferenceUtils.SESSION, const Uuid().v4());
  }

  getSession() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    if (session == null) {
      createSession();
    }
  }

  @override
  void initState() {
    getUser();
    getSession();
    super.initState();

    // todo sha1 key generator code : keytool -list -v -keystore "C:\Users\yourusernamehere\.android\debug.keystore" -alias androiddebugkey -storepass android -keypass android
    /// ..... sha1 . E4:B1:D4:68:B4:A3:ED:B1:96:2A:1E:02:9B:8D:4A:AE:BD:5B:61:66
    // latest
    // MD5:  B0:DC:3D:82:9F:8B:B8:CB:A5:5E:1F:02:2C:7A:EB:C5
    // SHA1: 1C:F9:E4:82:D3:C3:0A:7F:B0:52:A1:70:B4:0C:E6:F4:C6:FF:9B:28
    // SHA256: 5C:0D:72:AD:99:27:6E:6C:32:94:11:76:6C:F1:35:4E:C4:30:A8:7E:62:5E:8A:FC:BD:BE:ED:4A:A6:C1:17:8D
    // Signature algorithm name: SHA1withRSA
    // Subject Public Key Algorithm: 2048-bit RSA key
    // Version: 1

  }



  @override
  Widget build(BuildContext context) {
    WidgetsFlutterBinding.ensureInitialized();
    return OKToast(
      child: MaterialApp(
        navigatorKey: _navigatorKey,
        debugShowCheckedModeBanner: false,
        home: const SplashScreen(),
        // scrollBehavior: ,
        theme: ThemeData(
          primaryColor: const Color(0xFF000000),
          fontFamily: 'Lato',
          brightness: Brightness.light,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        routes: <String, WidgetBuilder>{
          '/HomeScreen': (BuildContext context) => const HomePage(),
          '/NoInternetPage': (BuildContext context) => const NoInternetConPage(),
        },
      ),
    );
  }
}
