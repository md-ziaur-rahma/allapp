import 'dart:async';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/home/home_page.dart';
import 'package:azuramartmy/order_list/order_list_page.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'package:webview_flutter/webview_flutter.dart';

class RedirectUrl extends StatefulWidget {
  const RedirectUrl({Key? key,this.redirectUrl}) : super(key: key);
  final String? redirectUrl;

  static Route route(){
    return MaterialPageRoute(builder: (_) => RedirectUrl());
  }

  @override
  _RedirectUrlState createState() => _RedirectUrlState();
}

class _RedirectUrlState extends State<RedirectUrl> {
  late WebViewController _controller;

  final Completer<WebViewController> _controllerCompleter =
  Completer<WebViewController>();
  @override
  void initState() {
    if (Platform.isAndroid) {
      WebView.platform = SurfaceAndroidWebView();
    }
    super.initState();
  }

  JavascriptChannel _toasterJavascriptChannel(BuildContext context) {
    return JavascriptChannel(
        name: 'Toaster',
        onMessageReceived: (JavascriptMessage message) {
          // ignore: deprecated_member_use
          print(message.message);
        });
  }

  double progressValue = 0;

  Future<bool> _onWillPop() async {
    if (await _controller.canGoBack()) {
      _controller.goBack();
      return Future.value(false);
    } else {
      return Future.value(true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        child: Scaffold(
          body: SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                SizedBox(
                  width: double.infinity,
                  height: 3,
                  child: LinearProgressIndicator(
                    value: progressValue/100,
                    backgroundColor: Colors.grey,
                    color: Colors.grey,
                    valueColor: const AlwaysStoppedAnimation<Color>(Colors.deepOrange),
                  ),
                ),
                Expanded(
                  child: WebView(
                    javascriptMode: JavascriptMode.unrestricted,
                    initialUrl: '${widget.redirectUrl}',
                    onWebViewCreated: (WebViewController webViewController) {
                      _controllerCompleter.future.then((value) => _controller = value);
                      _controllerCompleter.complete(webViewController);
                    },
                    onProgress: (int progress) {
                      print("WebView is loading (progress : $progress%)");
                      setState(() {
                        progressValue = progress.toDouble();
                      });
                    },

                    javascriptChannels: <JavascriptChannel>{
                      _toasterJavascriptChannel(context),
                    },

                    navigationDelegate: (NavigationRequest request) {
                      // ................
                      var uri = Uri.dataFromString(request.url);
                      Map<String, String> params = uri.queryParameters;
                      var transaction = params['billplz%5Btransaction_status%5D'];
                      var paid = params["billplz%5Bpaid%5D"];
                      print('transaction : $transaction');
                      print('paid : $paid');
                      if (transaction == 'completed' || paid == 'true') {
                        Navigator.push(context, OrderListPage.route());
                        // Navigator.pop(context);
                        return NavigationDecision.navigate;
                      } else if (transaction == 'failed' || paid == 'false') {
                        Common.toastMsg('Payment unsuccessful!');
                        Navigator.push(context, HomePage.route());
                        // Navigator.pop(context);
                        return NavigationDecision.navigate;
                      }
                      // ................
                      print('allowing navigation to $request');
                      return NavigationDecision.navigate;
                    },
                    onPageStarted: (String url) {
                      print('Page started loading: $url');
                    },
                    onPageFinished: (String url) {
                      print('Page finished loading: $url');
                    },
                    gestureNavigationEnabled: true,
                  ),
                )
              ],
            ),
          ),
        ),
        onWillPop: _onWillPop);
  }
}