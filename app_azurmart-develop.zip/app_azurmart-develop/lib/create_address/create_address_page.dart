import 'dart:io';

import 'package:azuramartmy/create_address/create_address_body.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CreateAddressPage extends StatefulWidget {
  const CreateAddressPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => const CreateAddressPage());
  }

  @override
  _CreateAddressPageState createState() => _CreateAddressPageState();
}

class _CreateAddressPageState extends State<CreateAddressPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Create A New Address',
          style: TextStyle(color: Colors.black87),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
      ),
      body: const SafeArea(
        child: CreateAddressBody(),
      ),
    );
  }
}
