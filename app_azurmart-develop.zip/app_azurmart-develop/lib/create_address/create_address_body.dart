import 'dart:convert';

import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/my_bloc/address_bloc.dart';
import 'package:azuramartmy/provider_models/post_code_model.dart';
import 'package:azuramartmy/provider_models/temp_post_code_model.dart';
import 'package:azuramartmy/provider_models/temp_state_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';

class CreateAddressBody extends StatefulWidget {
  const CreateAddressBody({Key? key}) : super(key: key);

  @override
  _CreateAddressBodyState createState() => _CreateAddressBodyState();
}

class _CreateAddressBodyState extends State<CreateAddressBody> {
  List<TempPostCodeModel> tempPostCodeModel = [];
  final TextEditingController _typeAheadController = TextEditingController();
  List<TempStateModel> tempStateModel = [];
  TextEditingController cityController = TextEditingController();

  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController addressLine1Controller = TextEditingController();
  TextEditingController addressLine2Controller = TextEditingController();
  TextEditingController postCodeController = TextEditingController();
  TextEditingController mobileController =  TextEditingController();

  List<String?> states = [];
  List<String> cities = [];
  int? statePk;
  int? cityPk;
  List<String?> tempPostCodes = [];

  final GlobalKey<FormState> _addressKey = GlobalKey<FormState>();
  String? email;
  String? firstName;
  String? lastName;
  String? address;
  String? postCode;
  String? mobile;
  String? apartment;
  String? city;
  String? state = 'Select a state';
  String? country;
  
  int isDefault = 0;
  bool? checkBoxValue = false;

  String? validationFirstName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty First Name!';
    } else {
      return null;
    }
  }

  String? validationLastName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Last Name!';
    } else {
      return null;
    }
  }

  String? validationAddress(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Address!';
    } else {
      return null;
    }
  }

  String? validationCity(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty City!';
    } else {
      return null;
    }
  }

  String? validationMobile(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Mobile!';
    } else if (value.length < 9) {
      return 'Enter valid contact no';
    } else {
      return null;
    }
  }

  String? validationCountry(String? value) {
    if (value == null || value.isEmpty) {
      return 'Empty Country!';
    } else {
      return null;
    }
  }

  String? validationPostCode(String value) {
    if (value == null || value.isEmpty) {
      return 'Empty Post Code!';
    } else {
      return null;
    }
  }

  //......................................................
  void getPostCode() async {
    Client client = Client();
    Uri url = Uri.parse('${Urls.baseUrl}${Urls.POST_CODE}');
    try {
      final response = await client.post(url);
      print('................... ${response.body}.............');
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        PostCodeModel postCodeModel = PostCodeModel.fromJson(body);
        states.add('Select a state');
        for (var i = 0; i < postCodeModel.data!.length; i++) {
          int m = 0;
          if (postCodeModel.data![i].statename != null &&
              postCodeModel.data![i].fstateno != null &&
              postCodeModel.data![i].pocode != null) {
            TempPostCodeModel temp = TempPostCodeModel(
                postCodeModel.data![i].pocode,
                postCodeModel.data![i].fcityno,
                postCodeModel.data![i].cityname,
                postCodeModel.data![i].statename,
                postCodeModel.data![i].fstateno);
            tempPostCodeModel.add(temp);
            tempPostCodes.add(postCodeModel.data![i].pocode);
          }
          for (var x = 0; x < states.length; x++) {
            if (states[x] == postCodeModel.data![i].statename ||
                postCodeModel.data![i].statename == null ||
                postCodeModel.data![i].fstateno == null ||
                postCodeModel.data![i].pocode == null) {
              m = 1;
            }
          }
          if (m == 0) {
            states.add(postCodeModel.data![i].statename);
            TempStateModel temp = TempStateModel(
                postCodeModel.data![i].statename,
                postCodeModel.data![i].fstateno);
            tempStateModel.add(temp);
          }
        }
      }
    } on Exception catch (e) {
      print(e);
    }
  }
  //......................................................

  void saveAddress() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Client client = Client();

    /// address type 1 = shipping, 2 = billing.......
    Map<String, dynamic> data = {
      'session': '$session',
      'user_id': '$userId',
      'token': '$token',
      'firstName': '$firstName',
      'lastName': '$lastName',
      'address_line1': '$address',
      'postCode': '$postCode',
      'mobile': '$mobile',
      'address_line2': '$apartment',
      'city_pk': '$cityPk',
      'state_pk': '$statePk',
      'state': '$state',
      'city': '$city',
      'country': '$country',
      'is_update': '0',
      'is_default': '$isDefault',
      'address_type': '1'
    };
    var requestBody = json.encode(data);

    print(requestBody);
    try {
      final url = Uri.parse(Urls.baseUrl + Urls.SAVE_ADDRESS);
      print('url');
      var response = await client.post(url, body: requestBody, headers: {
        'Content-type': 'application/json',
        'Charset': 'utf-8',
        'Accept': 'application/json',
      });
      print(response.body);
      final Map<String, dynamic> body = await json.decode(response.body);
      print('${body['message']}');
      Common.toastMsg('${body['message']}');
      if (body['status'] == 1) {
        //todo change........
        setState(() {
          _addressKey.currentState!.reset();
          _typeAheadController.clear();
          states = [];
          cities = [];
          state = '';
          city = '';

          firstName = '';
          lastName = '';
          address = '';
          postCode = '';
          mobile = '';
          apartment = '';
        });
        addressBloc.fetchAllAddress();
      }
    } on FormatException catch (e) {
      print(e);
      Common.toastMsg(e.toString());
    } on Exception catch (e) {
      print(e);
      Common.toastMsg(e.toString());
    }
  }

  @override
  void initState() {
    getPostCode();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      scrollDirection: Axis.vertical,
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Form(
              key: _addressKey,
              autovalidateMode: AutovalidateMode.always,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(
                    height: 16,
                  ),
                  const SizedBox(
                      width: double.infinity,
                      child: Text(
                        'Shipping Address',
                        style: TextStyle(color: Colors.black87, fontSize: 18),
                      )),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      validator: validationFirstName,
                      controller: firstNameController,
                      textInputAction: TextInputAction.next,
                      onSaved: (String? val) {
                        firstName = val;
                      },
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                        hintText: 'First Name',
                        labelText: 'First Name',
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Colors.black)),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      validator: validationLastName,
                      controller: lastNameController,
                      textInputAction: TextInputAction.next,
                      onSaved: (String? val) {
                        lastName = val;
                      },
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                        hintText: 'Last Name',
                        labelText: 'Last Name',
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Colors.black)),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      validator: validationAddress,
                      controller: addressLine1Controller,
                      textInputAction: TextInputAction.next,
                      onSaved: (String? val) {
                        address = val;
                      },
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                        hintText: 'Address line 1',
                        labelText: 'Address line 1',
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Colors.black)),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      textInputAction: TextInputAction.next,
                      controller: addressLine2Controller,
                      onSaved: (val) {
                        setState(() {
                          apartment = val;
                        });
                      },
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                        hintText: 'Address line 2',
                        labelText: 'Address line 2',
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Colors.black)),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    child: TypeAheadField(
                      textFieldConfiguration: TextFieldConfiguration(
                        keyboardType: TextInputType.number,
                          textInputAction: TextInputAction.next,
                          controller: _typeAheadController,
                          autofocus: false,
                          style: DefaultTextStyle.of(context).style.copyWith(
                              fontStyle: FontStyle.italic
                          ),
                          decoration: const InputDecoration(
                              labelText: 'post code',
                              border: OutlineInputBorder()
                          )
                      ),
                      transitionBuilder: (context, suggestionsBox, controller) {
                        return suggestionsBox;
                      },
                      suggestionsCallback: (pattern) async {
                        return tempPostCodes
                            .where((item) =>
                            item!.toLowerCase().startsWith(pattern.toLowerCase()))
                            .toList();
                      },
                      itemBuilder: (context, dynamic suggestion) {
                        return ListTile(
                          leading: const Icon(Icons.shopping_cart,size: 20,),
                          title: Text('$suggestion'),
                        );
                      },
                      onSuggestionSelected: (dynamic suggestion) {
                        for (var item in tempPostCodeModel) {
                          if (suggestion.toString().toLowerCase() == item.pocode) {
                            setState(() {
                              _typeAheadController.text = item.pocode!;
                              print('${item.pocode}');
                              postCode = item.pocode;
                              cityPk = item.fcityno;
                              statePk = item.fstateno;
                              state = item.statename;
                              city = item.cityname;
                              cityController.text = item.cityname!;
                            });
                          }
                        }
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      controller: cityController,
                      validator: validationCity,
                      textInputAction: TextInputAction.next,
                      onSaved: (String? val) {
                        city = val;
                      },
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                        hintText: 'City',
                        labelText: 'City',
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Colors.black)),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: DropdownButtonFormField<String>(
                      hint: const Text('Select a state'),
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Colors.black)),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                      ),
                      focusColor: const Color(0xFFF68721),
                      value: state,
                      icon: const Icon(
                        Icons.arrow_drop_down,
                      ),
                      iconSize: 24,
                      elevation: 3,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Select a state';
                        } else if (value == 'Select a state') {
                          return 'Select a state';
                        } else {
                          return null;
                        }
                      },
                      //underline: SizedBox(),
                      onChanged: (newValue) {
                        setState(() {
                          state = newValue;
                          for (var i = 0; i < tempStateModel.length; i++) {
                            if (newValue == tempStateModel[i].state) {
                              statePk = tempStateModel[i].state_pk;
                            }
                          }
                        });
                      },
                      items:
                          states.map<DropdownMenuItem<String>>((String? value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value!),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      enabled: false,
                      initialValue: 'Malaysia',
                      validator: validationCountry,
                      onSaved: (val) {
                        setState(() {
                          country = val;
                        });
                      },
                      decoration: InputDecoration(
                        labelText: 'Country',
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Colors.black)),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 24,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: TextFormField(
                      validator: validationMobile,
                      textInputAction: TextInputAction.next,
                      maxLength: 10,
                      controller: mobileController,
                      onSaved: (String? val) {
                        mobile = val;
                      },
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                        hintText: 'Mobile No',
                        labelText: 'Mobile No',
                        prefix: const Text('+60 '),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(2),
                            borderSide: const BorderSide(color: Colors.black)),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(2),
                            borderSide: const BorderSide(color: Color(0xFFD0D1D2))),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Checkbox(
                            value: checkBoxValue,
                            activeColor: Colors.green,
                            checkColor: Colors.white,
                            splashRadius: 16,
                            onChanged: (bool? value){
                              setState(() {
                                checkBoxValue = value;
                              });
                              if (value!) {
                                isDefault = 1;
                              }  else {
                                isDefault = 0;
                              }
                            }
                        ),
                        GestureDetector(
                          onTap: (){
                            setState(() {
                              checkBoxValue = !checkBoxValue!;
                              if (checkBoxValue!) {
                                isDefault = 1;
                              }  else {
                                isDefault = 0;
                              }
                            });
                          },
                          child: Text('Use as my default delivery address',style: TextStyle(color: checkBoxValue! ? Colors.black87 : Colors.black54,fontSize: 14),),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: AppsColors.buttonColor,
                            shape: const StadiumBorder()),
                        onPressed: () {
                          //Navigator.push(context, ShippingPage.route());
                          if (_addressKey.currentState!.validate()) {
                            _addressKey.currentState!.save();
                            saveAddress();
                          }
                        },
                        child: const Text('Save Address'),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                ],
              ),
            ),
          ),
        ),
        // SliverToBoxAdapter(
        //   child: Padding(
        //     padding: const EdgeInsets.symmetric(horizontal: 16),
        //     child: Form(
        //       key: _addressKey,
        //       autovalidateMode: AutovalidateMode.onUserInteraction,
        //       child: Column(
        //         mainAxisAlignment: MainAxisAlignment.start,
        //         mainAxisSize: MainAxisSize.min,
        //         children: [
        //           SizedBox(
        //             height: 20,
        //           ),
        //           SizedBox(
        //             width: double.infinity,
        //             child: TextFormField(
        //               validator: validationFirstName,
        //               onSaved: (String val) {
        //                 firstName = val;
        //               },
        //               keyboardType: TextInputType.text,
        //               decoration: InputDecoration(
        //                 contentPadding: EdgeInsets.symmetric(horizontal: 20),
        //                 hintText: 'First Name',
        //                 focusedBorder: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Colors.black)),
        //                 border: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Color(0xFFD0D1D2))),
        //               ),
        //             ),
        //           ),
        //           SizedBox(
        //             height: 16,
        //           ),
        //           SizedBox(
        //             width: double.infinity,
        //             child: TextFormField(
        //               validator: validationLastName,
        //               onSaved: (String val) {
        //                 lastName = val;
        //               },
        //               keyboardType: TextInputType.text,
        //               decoration: InputDecoration(
        //                 contentPadding: EdgeInsets.symmetric(horizontal: 20),
        //                 hintText: 'Last Name',
        //                 focusedBorder: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Colors.black)),
        //                 border: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Color(0xFFD0D1D2))),
        //               ),
        //             ),
        //           ),
        //           SizedBox(
        //             height: 16,
        //           ),
        //           SizedBox(
        //             width: double.infinity,
        //             child: TextFormField(
        //               validator: validationAddress,
        //               onSaved: (String val) {
        //                 address = val;
        //               },
        //               keyboardType: TextInputType.text,
        //               decoration: InputDecoration(
        //                 contentPadding: EdgeInsets.symmetric(horizontal: 20),
        //                 hintText: 'Address',
        //                 focusedBorder: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Colors.black)),
        //                 border: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Color(0xFFD0D1D2))),
        //               ),
        //             ),
        //           ),
        //           SizedBox(
        //             height: 16,
        //           ),
        //           SizedBox(
        //             width: double.infinity,
        //             child: TextFormField(
        //               onSaved: (val){
        //                 setState(() {
        //                   apartment = val;
        //                 });
        //               },
        //               decoration: InputDecoration(
        //                 contentPadding: EdgeInsets.symmetric(horizontal: 20),
        //                 hintText: 'Apartment, suit etc. (Optional)',
        //                 focusedBorder: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Colors.black)),
        //                 border: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Color(0xFFD0D1D2))),
        //               ),
        //             ),
        //           ),
        //           SizedBox(
        //             height: 16,
        //           ),
        //           SizedBox(
        //             width: double.infinity,
        //             child: AutoCompleteTextField<TempPostCodeModel>(
        //               key: _autoCompleteKey,
        //               controller: autoCompleteController,
        //               itemBuilder: (context, item){
        //                 return Padding(
        //                   padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 8),
        //                   child: Text('${item.pocode}',style: TextStyle(color: Colors.black87,fontSize: 16),),
        //                 );
        //               },
        //               itemFilter: (item, query){
        //                 return item.pocode.toLowerCase().startsWith(query.toLowerCase());
        //               },
        //               itemSorter: (a, b) {
        //                 return a.pocode.compareTo(b.pocode);
        //               },
        //               itemSubmitted: (item){
        //                 setState(() {
        //                   autoCompleteController.text = item.pocode;
        //                   print('${item.pocode}');
        //                   postCode = item.pocode;
        //                   print('$postCode');
        //                   stateValue = 'Select a state';
        //                   cityValue = 'Select a city';
        //                   cityPk = item.fcityno;
        //                   statePk = item.fstateno;
        //                   cities = [];
        //                   states = [];
        //                   cities.add('Select a city');
        //                   states.add('Select a state');
        //                   cities.add('${item.cityname}');
        //                   states.add('${item.statename}');
        //                   // if (state.isNotEmpty) {
        //                   //   state = '';
        //                   // }
        //                   // if (city.isNotEmpty) {
        //                   //   city = '';
        //                   // }
        //                 });
        //               },
        //               suggestions: tempPostCodeModel,
        //               clearOnSubmit: false,
        //               keyboardType: TextInputType.number,
        //               suggestionsAmount: 10,
        //               style: new TextStyle(color: Colors.black, fontSize: 16.0),
        //               decoration: InputDecoration(
        //                 contentPadding: EdgeInsets.symmetric(horizontal: 20),
        //                 hintText: 'Post Code',
        //                 focusedBorder: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Colors.black)),
        //                 border: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Color(0xFFD0D1D2))),
        //                 filled: true,
        //                 hintStyle: TextStyle(color: Colors.black)
        //               ),
        //             ),
        //           ),
        //           SizedBox(
        //             height: 16,
        //           ),
        //           SizedBox(
        //             width: double.infinity,
        //             child: DropdownButtonFormField<String>(
        //               hint: Text('Select a city'),
        //               decoration: InputDecoration(
        //                 contentPadding: EdgeInsets.symmetric(horizontal: 20),
        //                 // hintText: 'Post Code',
        //                 focusedBorder: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Colors.black)),
        //                 border: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Color(0xFFD0D1D2))),
        //               ),
        //               focusColor: Color(0xFFF68721),
        //               value: cityValue,
        //               icon: const Icon(
        //                 Icons.arrow_drop_down,
        //               ),
        //               iconSize: 24,
        //               elevation: 3,
        //               validator: (value) {
        //                 if (value == null || value.isEmpty) {
        //                   return 'Select a city';
        //                 } else if (value == 'Select a city') {
        //                   return 'Select a city';
        //                 } else  {
        //                   return null;
        //                 }
        //               },
        //               // underline: SizedBox(),
        //               onChanged: (newValue) {
        //                 setState(() {
        //                   city = newValue;
        //                 });
        //               },
        //               items:
        //                   cities.map<DropdownMenuItem<String>>((String value) {
        //                 return DropdownMenuItem<String>(
        //                   value: value,
        //                   child: Text(value),
        //                 );
        //               }).toList(),
        //             ),
        //           ),
        //           SizedBox(
        //             height: 16,
        //           ),
        //           SizedBox(
        //             width: double.infinity,
        //             child: DropdownButtonFormField<String>(
        //               hint: Text('Select a state'),
        //               decoration: InputDecoration(
        //                 contentPadding: EdgeInsets.symmetric(horizontal: 20),
        //                 focusedBorder: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Colors.black)),
        //                 border: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Color(0xFFD0D1D2))),
        //               ),
        //               focusColor: Color(0xFFF68721),
        //               value: stateValue,
        //               icon: const Icon(
        //                 Icons.arrow_drop_down,
        //               ),
        //               iconSize: 24,
        //               elevation: 3,
        //               validator: (value) {
        //                 if (value == null || value.isEmpty) {
        //                   return 'Select a state';
        //                 } else if (value == 'Select a state') {
        //                   return 'Select a state';
        //                 } else {
        //                   return null;
        //                 }
        //               },
        //               //underline: SizedBox(),
        //               onChanged: (newValue) {
        //                 setState(() {
        //                   state = newValue;
        //                 });
        //               },
        //               items:
        //                   states.map<DropdownMenuItem<String>>((String value) {
        //                 return DropdownMenuItem<String>(
        //                   value: value,
        //                   child: Text(value),
        //                 );
        //               }).toList(),
        //             ),
        //           ),
        //           SizedBox(
        //             height: 16,
        //           ),
        //           SizedBox(
        //             width: double.infinity,
        //             child: TextFormField(
        //               enabled: false,
        //               initialValue: 'Malaysia',
        //               validator: validationCountry,
        //               onSaved: (val){
        //                 setState(() {
        //                   country = val;
        //                 });
        //               },
        //               decoration: InputDecoration(
        //                 contentPadding: EdgeInsets.symmetric(horizontal: 20),
        //                 focusedBorder: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Colors.black)),
        //                 border: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Color(0xFFD0D1D2))),
        //               ),
        //             ),
        //           ),
        //           SizedBox(
        //             height: 16,
        //           ),
        //           SizedBox(
        //             width: double.infinity,
        //             child: TextFormField(
        //               validator: validationMobile,
        //               onSaved: (String val) {
        //                 mobile = val;
        //               },
        //               keyboardType: TextInputType.number,
        //               decoration: InputDecoration(
        //                 contentPadding: EdgeInsets.symmetric(horizontal: 20),
        //                 hintText: 'Phone',
        //                 focusedBorder: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Colors.black)),
        //                 border: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(10),
        //                     borderSide: BorderSide(color: Color(0xFFD0D1D2))),
        //               ),
        //             ),
        //           ),
        //           SizedBox(
        //             height: 16,
        //           ),
        //           // Padding(
        //           //   padding: const EdgeInsets.symmetric(vertical: 0),
        //           //   child: Row(
        //           //     children: [
        //           //       Checkbox(
        //           //           value: isKeepEmail,
        //           //           activeColor: Color(0xFFF68721),
        //           //           checkColor: Colors.white,
        //           //           onChanged: (bool value) {
        //           //             setState(() {
        //           //               isKeepEmail = value;
        //           //             });
        //           //           }),
        //           //       SizedBox(
        //           //         width: 0,
        //           //       ),
        //           //       Expanded(
        //           //           child: Text(
        //           //         'Keep me up to date on news and exclusive offers',
        //           //         style: TextStyle(fontSize: 14, color: Colors.black87),
        //           //       ))
        //           //     ],
        //           //   ),
        //           // ),
        //           SizedBox(
        //             width: double.infinity,
        //             child: Container(
        //               width: double.infinity,
        //               height: 50,
        //               child: ElevatedButton(
        //                 style: ElevatedButton.styleFrom(
        //                     primary: Color(0xFFF68721),shape: StadiumBorder()),
        //                 onPressed: () {
        //                   //Navigator.push(context, ShippingPage.route());
        //                   if (_addressKey.currentState.validate()) {
        //                     _addressKey.currentState.save();
        //                     saveAddress();
        //                   }
        //                 },
        //                 child: Text('Save Address'),
        //               ),
        //             ),
        //           ),
        //           SizedBox(
        //             height: 30,
        //           ),
        //         ],
        //       ),
        //     ),
        //   ),
        // )
      ],
    );
  }
}
