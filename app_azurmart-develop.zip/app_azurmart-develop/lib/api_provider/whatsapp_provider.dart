import 'dart:convert';
import 'package:azuramartmy/provider_models/whatsapp_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class WhatsappProvider {
  Client client = Client();
  Future<WhatsappModel?> fetchAllWhatsapp() async {
    Uri url = Uri.parse(Urls.baseUrl+Urls.WHATSAPP_LIST);
    try{
      var response = await client.post(url);
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        WhatsappModel whatsappModel = WhatsappModel.fromJson(body);
        if (response.body.isNotEmpty) {
          SharedPreferenceUtils.whatsappModel = whatsappModel;
          return whatsappModel;
        }
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }

  }
}