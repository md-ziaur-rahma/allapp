import 'dart:convert';

import 'package:azuramartmy/provider_models/address_list_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AddressProvider {
  Client client = Client();
  Future<AddressListModel?> fetchAllAddress() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Uri url = Uri.parse(Urls.baseUrl+Urls.ADDRESS);
    try{
      var response = await client.post(url,body: {'user_id':'$userId','token': '$token'});
      if (response.statusCode == 200) {
        var body = await json.decode(response.body);
        AddressListModel address = AddressListModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return address;
        }
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      // print(e);
    }

  }
}