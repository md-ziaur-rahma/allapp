import 'dart:convert';

import 'package:azuramartmy/provider_models/category_brand_details_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class CategoryBrandDetailsProvider {
  Client client = Client();
  Future<CategoryBrandDetailsModel?> fetchCategoriesBrands(String catId, String subCatID) async {
    Uri url = Uri.parse(Urls.baseUrl+Urls.CATEGORY_BRAND_DETAILS);
    try{
      var response = await client.post(url,body: {'cat_id': catId,'subcat_id': subCatID});
      if (response.statusCode == 200) {
        final Map<String, dynamic>? body = await json.decode(response.body);
        // CategoryBrandDetailsModel categoryBrands = CategoryBrandDetailsModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return CategoryBrandDetailsModel.fromJson(body);
        }
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }

  }
}