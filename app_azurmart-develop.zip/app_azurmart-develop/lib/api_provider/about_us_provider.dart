import 'dart:convert';
import 'package:azuramartmy/provider_models/aboutus_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class AboutUsProvider {
  Client client = Client();
  Future<AboutUsModel?> fetchAboutUs() async {
    Uri url = Uri.parse(Urls.baseUrl+Urls.PAGE);
    try{
      var response = await client.post(url);
      // print(response.body);
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        AboutUsModel aboutUsModel = AboutUsModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return aboutUsModel;
        }
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      // print(e);
    }

  }
}