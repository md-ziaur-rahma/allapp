import 'dart:convert';

import 'package:azuramartmy/provider_models/model_search_result_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ModelSearchResultProvider {
  Client client = Client();
  Future<ModelSearchResultModel?> fetchModelSearchResult(int? modelNo,int page) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    Uri url = Uri.parse(Urls.baseUrl + Urls.MODEL_SEARCH_RESULT);
    try {
      var response = await client.post(url, body: {
        'model_id': '$modelNo',
        'session': '$session',
        'user_id': '$userId',
        'page': '$page',
      });
      if (response.statusCode == 200) {
        final Map<String, dynamic>? body = await json.decode(response.body);
        // ModelSearchResultModel result = ModelSearchResultModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return ModelSearchResultModel.fromJson(body);
        }
      } else {
        throw Exception('Failed to load post');
      }
    } on Exception catch (e) {
      print(e);
    }
  }
}
