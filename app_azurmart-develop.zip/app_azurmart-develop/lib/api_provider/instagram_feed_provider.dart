import 'dart:convert';
import 'package:azuramartmy/provider_models/instagram_feed_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class InstagramFeedProvider {
  Client client = Client();
  Future<InstagramFeedModel?> fetchInstagramFeed() async {
    Uri url = Uri.parse(Urls.baseUrl+Urls.instagramFeed);
    try{
      var response = await client.get(url);
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        // InstagramFeedModel instagramFeedModel = InstagramFeedModel.fromJson(body);
        return InstagramFeedModel.fromJson(body);
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }

  }
}