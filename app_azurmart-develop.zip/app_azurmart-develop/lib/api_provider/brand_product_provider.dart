import 'dart:convert';

import 'package:azuramartmy/provider_models/brand_product_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BrandProductsProvider {
  Client client = Client();
  Future<BrandProductModel?> fetchBrandProduct(int? brandPk, String categoryPk, int page) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userID = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    Uri url = Uri.parse(Urls.baseUrl+Urls.BRAND_PRODUCT);
    // print('brand product\'s ($url) session :  $session user id : $userID  brand : $brandPk. subcat id : $categoryPk page : $page');
    try {
      var response = await client
          .post(url, body: {'session': '$session', 'user_id': '$userID','brand_id':'$brandPk','page':'$page','subcat_id':'$categoryPk'});
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        BrandProductModel brandProduct = BrandProductModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return brandProduct;
        }
      } else {
        throw Exception('Failed to load post');
      }
    } on Exception catch (e) {
      print(e);
    }
  }
}
