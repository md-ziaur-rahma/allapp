import 'dart:convert';

import 'package:azuramartmy/provider_models/new_arrival_item_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart' show Client;

class NewArrivalProductProvider{
  Client client = Client();

  Future<NewArrivalItemModel?> fetchProduct(int page) async {
    var url = Uri.parse(Urls.baseUrl+Urls.NEW_ARRIVAL_PRODUCT);
    try{
      var response = await client.post(url,body: {'page': '$page'});
      if (response.statusCode == 200) {
        return NewArrivalItemModel.fromJson(json.decode(response.body));
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }

  }
}