import 'dart:convert';

import 'package:azuramartmy/provider_models/search_models.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SearchProvider {
  Client client = Client();
  Future<SearchModels?> fetchSearch(String? keyword, int page) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    Uri url = Uri.parse(Urls.baseUrl + Urls.SEARCH);
    try {
      var response = await client.post(url, body: {
        'keyword': '$keyword',
        'session': '$session',
        'user_id': '$userId',
        'page': '$page'
      });
      print(response.body);
      if (response.statusCode == 200) {
        final Map<String, dynamic>? body = await json.decode(response.body);
        // SearchModels result = SearchModels.fromJson(body);
        if (response.body.isNotEmpty) {
          return SearchModels.fromJson(body);
        }
      } else {
        throw Exception('Failed to load post');
      }
    } on Exception catch (e) {
      print(e);
    }
  }
}
