import 'dart:convert';

import 'package:azuramartmy/provider_models/short_search_models.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class ShortSearchProvider {
  Client client = Client();
  Future<ShortSearchModels?> fetchShortSearch(String keyword) async {
    Uri url = Uri.parse(Urls.baseUrl+Urls.SHORT_SEARCH);
    try{
      var response = await client.post(url,body: {'keyword': '$keyword'});
      if (response.statusCode == 200) {
        final Map<String, dynamic>? body = await json.decode(response.body);
        // ShortSearchModels result = ShortSearchModels.fromJson(body);
        if (response.body.isNotEmpty) {
          return ShortSearchModels.fromJson(body);
        }
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }

  }
}