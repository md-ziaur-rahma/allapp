import 'dart:convert';

import 'package:azuramartmy/provider_models/cart_count_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CartCountProvider {
  Client client = Client();
  Future<CartCountModel?> fetchCartCount() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Uri url = Uri.parse(Urls.baseUrl + Urls.CART_COUNT);
    try {
      var response = await client.post(url, body: {'session': '$session','user_id': '$userId','token': '$token'});
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        CartCountModel cartCount = CartCountModel.fromJson(body);
        return cartCount;
      } else {
        throw Exception('Failed to load post');
      }
    } on Exception catch (e) {
      print(e);
    }
  }
}
