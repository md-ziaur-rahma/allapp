import 'dart:convert';

import 'package:azuramartmy/provider_models/order_details_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart' show Client;
import 'package:shared_preferences/shared_preferences.dart';

class OrderDetailsProvider {
  Client client = Client();
  Future<OrderDetailsModel?> fetchOrderDetails(int? orderId) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    var url = Uri.parse(Urls.baseUrl+Urls.orderDetails);
    print("order details : $url/$orderId");
    try{
      var response = await client.post(url,body: {'session': "$session",
        'user_id': "$userId",
        'token': "$token",
        'order_id': "$orderId"});
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        if (body["status"] == 1) {
          // OrderDetailsModel orderDetailsModel = OrderDetailsModel.fromJson(body);
          return OrderDetailsModel.fromJson(body);
        } else {
          OrderDetailsModel orderDetailsModel = OrderDetailsModel();
          orderDetailsModel.status = 0;
          return orderDetailsModel;
        }
      }else {
        throw Exception('Failed to load post');
      }
    } on Exception catch(e){
      print(e);
    }
  }
}