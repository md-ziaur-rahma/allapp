import 'dart:convert';

import 'package:azuramartmy/provider_models/brand_details_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class BrandDetailsProvider {
  Client client = Client();
  Future<BrandDetailsModel?> fetchBrandDetails(int? pkNo) async {
    Uri url = Uri.parse(Urls.baseUrl+Urls.BRAND_DETAILS);
    try{
      var response = await client.post(url,body: {'brand_id': '$pkNo'});
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        BrandDetailsModel brandDetails = BrandDetailsModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return brandDetails;
        }
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }

  }
}