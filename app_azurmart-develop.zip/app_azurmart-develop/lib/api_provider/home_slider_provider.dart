import 'dart:convert';

import 'package:azuramartmy/provider_models/home_slider_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class HomeSliderProvider{
  Client client = Client();
  Future<HomeSliderModel?> fetchSliderList() async {
    var url = Uri.parse(Urls.baseUrl+Urls.home_banner);
    try{
      var response = await client.post(url);
      if (response.statusCode == 200) {
        final Map<String, dynamic> body =await json.decode(response.body);
        // HomeSliderModel homeSliderModel = HomeSliderModel.fromJson(body);
        return HomeSliderModel.fromJson(body);
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }


  }
}

