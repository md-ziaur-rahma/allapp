import 'dart:convert';

import 'package:azuramartmy/cart/cart_page.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/provider_models/cart_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CartProvider {
  Client client = Client();
  Future<CartModel?> fetchCart() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userId = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    print('cart (session : $session / user id : $userId / token : $token)');
    Uri url = Uri.parse(Urls.baseUrl + Urls.CART);
    try {
      var response = await client.post(url, body: {'session': '$session','user_id': '$userId','token': '$token'});
      print(response.body);
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        CartPage.isCartData = body["status"];
        CartModel cart = CartModel.fromJson(body);
        CartPage.cartModel = cart;
        SharedPreferenceUtils.postageCostSM = cart.data!.totalSMCost;
        SharedPreferenceUtils.postageCostSS = cart.data!.totalSSCost;
        SharedPreferenceUtils.totalPrice = cart.data!.totalPrice;
        SharedPreferenceUtils.totalInsPrice = cart.data!.totalInsPrice;
        return cart;
      } else {
        throw Exception('Failed to load post');
      }
    } on Exception catch (e) {
      print(e);
    }
  }
}
