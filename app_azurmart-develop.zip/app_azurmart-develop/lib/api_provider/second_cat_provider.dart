import 'dart:convert';

import 'package:azuramartmy/provider_models/category_product.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SecondCategoryProductProvider {
  Client client = Client();
  Future<CategoryProduct> fetchSecondCategoryProductList(String cat, String subCat, String product,int page) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userID = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    late Uri url;
    if (cat != null && subCat == null && product == null) {
      url = Uri.parse(Urls.baseUrl+cat);
    }  else if (cat != null && subCat != null && product == null) {
      url = Uri.parse(Urls.baseUrl+cat+subCat);
    }else if (cat != null && subCat != null && product != null) {
      url = Uri.parse(Urls.baseUrl+cat+subCat+product);
    }

    var response = await client.post(url,body: {'session': '$session','user_id': '$userID','page': '$page'});
    if (response.statusCode == 200) {
      final Map<String, dynamic> body =await json.decode(response.body);
      // CategoryProduct categoryProduct = CategoryProduct.fromJson(body);
      return CategoryProduct.fromJson(body);
    }else {
      throw Exception('Failed to load post');
    }
  }
}
