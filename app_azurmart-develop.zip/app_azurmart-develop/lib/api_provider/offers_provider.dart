import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/provider_models/offer_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class OffersProvider {
  Client client = Client();
  Future<OfferModel?> fetchOfferProduct(int page,int? random) async {
    Uri url = Uri.parse(Urls.baseUrl + Urls.OFFER_PRODUCTS);
    try {
      var response =
      await client.post(url, body: {'page': '$page', 'limit': '$random'});
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        OfferModel offerModel = OfferModel.fromJson(body);
        if (response.body.isNotEmpty) {
          SharedPreferenceUtils.offerModel = offerModel;
          return offerModel;
        }
      } else {
        throw Exception('Failed to load post');
      }
    }on SocketException catch (_) {
      print('no internet connection!');
    } on Exception catch (e) {
      print(e);
    }
  }
}