import 'dart:convert';

import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';
import 'package:azuramartmy/provider_models/category2.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CategoryProvider{
  Client client = Client();
  Future<Category2> fetchCategoryList() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    final url = Uri.parse(Urls.baseUrl+Urls.home_category);
    var response = await client.post(url);
    if (response.statusCode == 200) {
      final Map<String, dynamic> body =await json.decode(response.body);
      String catBody = jsonEncode(Category2.fromJson(body));
      localStorage.setString(SharedPreferenceUtils.CATEGORY, catBody);
      Category2 categoryList = Category2.fromJson(json.decode(response.body));
      SharedPreferenceUtils.categoryList = categoryList;
      return categoryList;
    }else {
      throw Exception('Failed to load post');
    }
  }
}