import 'dart:convert';

import 'package:azuramartmy/provider_models/wish_list_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class WishListProvider {
  Client client = Client();
  Future<WishListModel?> fetchWishList() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userID = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    String? token = localStorage.getString(SharedPreferenceUtils.TOKEN);
    Map<String, dynamic> data = {
      'session': "$session",
      'user_id': '$userID',
      'token': '$token'
    };
    // var requestBody = json.encode(data);
    Uri url = Uri.parse(Urls.baseUrl + Urls.WISHLIST);
    try {
      var response = await client.post(url, body: data);
      if (response.statusCode == 200) {
        final Map<String, dynamic>? body = await json.decode(response.body);
        // WishListModel wishList = WishListModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return WishListModel.fromJson(body);
        }
      } else {
        throw Exception('Failed to load post');
      }
    } on Exception catch (e) {
      print(e);
    }
  }
}
