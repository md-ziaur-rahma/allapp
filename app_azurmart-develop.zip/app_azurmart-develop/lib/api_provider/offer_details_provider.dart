import 'dart:convert';
import 'package:azuramartmy/provider_models/offer_details_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class OfferDetailsProvider {
  Client client = Client();
  Future<OfferDetailsModel?> fetchOfferDetails(String offerName) async {
    Uri url = Uri.parse(Urls.baseUrl+offerName);
    try{
      var response = await client.post(url);
      if (response.statusCode == 200) {
        final Map<String, dynamic>? body = await json.decode(response.body);
        // OfferDetailsModel offerDetails = OfferDetailsModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return OfferDetailsModel.fromJson(body);
        }
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }

  }
}