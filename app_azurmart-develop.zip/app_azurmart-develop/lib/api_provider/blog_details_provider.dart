import 'dart:convert';

import 'package:azuramartmy/provider_models/blog_details_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class BlogDetailsProvider {
  Client client = Client();
  Future<BlogDetailsModel?> fetchBlogDetails(String slug) async {
    Uri url = Uri.parse(Urls.baseUrl+slug);
    try{
      var response = await client.get(url);
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        BlogDetailsModel blogDetailsModel = BlogDetailsModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return blogDetailsModel;
        }
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }

  }
}