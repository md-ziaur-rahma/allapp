import 'dart:convert';
import 'dart:io';

import 'package:azuramartmy/provider_models/feature_model.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FeatureProvider {
  Client client = Client();
  Future<FeatureModel?> fetchFeatureProduct(int page) async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    String? session = localStorage.getString(SharedPreferenceUtils.SESSION);
    int? userID = localStorage.getInt(SharedPreferenceUtils.USER_ID);
    Uri url = Uri.parse(Urls.baseUrl + Urls.FEATURE_PRODUCT);
    try {
      var response =
          await client.post(url, body: {'session': '$session', 'user_id': '$userID',"page": '$page'});
      if (response.statusCode == 200) {
        final Map<String, dynamic>? body = await json.decode(response.body);
        // FeatureModel featureModel = FeatureModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return FeatureModel.fromJson(body);
        }
      } else {
        throw Exception('Failed to load post');
      }
    }on SocketException catch (_) {
      print('no internet connection!');
    } on Exception catch (e) {
      print(e);
    }
  }
}
