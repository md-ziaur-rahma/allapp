import 'dart:convert';

import 'package:azuramartmy/provider_models/brand_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class BrandProvider {
  Client client = Client();
  Future<BrandModel?> fetchBrand() async {
    Uri url = Uri.parse(Urls.baseUrl+Urls.BRAND);
    try{
      var response = await client.post(url);
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        BrandModel brand = BrandModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return brand;
        }
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }

  }
}