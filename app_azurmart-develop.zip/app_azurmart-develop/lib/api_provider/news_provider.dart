import 'dart:convert';
import 'package:azuramartmy/provider_models/news_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class NewsProvider {
  Client client = Client();
  Future<NewsModel?> fetchNews(int page) async {
    Uri url = Uri.parse(Urls.baseUrl+Urls.NEWS);
    try{
      var response = await client.post(url,body: {'page': '$page'});
      if (response.statusCode == 200) {
        final Map<String, dynamic>? body = await json.decode(response.body);
        // NewsModel news = NewsModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return NewsModel.fromJson(body);
        }
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }

  }
}