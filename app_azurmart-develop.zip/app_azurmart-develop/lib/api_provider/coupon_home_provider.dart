import 'dart:convert';
import 'package:azuramartmy/provider_models/coupon_home_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart';

class CouponHomeProvider {
  Client client = Client();
  Future<CouponHomeModel?> fetchCouponHome() async {
    Uri url = Uri.parse(Urls.baseUrl+Urls.COUPON_HOME);
    try{
      var response = await client.post(url);
      if (response.statusCode == 200) {
        final Map<String, dynamic> body = await json.decode(response.body);
        CouponHomeModel couponHome = CouponHomeModel.fromJson(body);
        if (response.body.isNotEmpty) {
          return couponHome;
        }
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }

  }
}