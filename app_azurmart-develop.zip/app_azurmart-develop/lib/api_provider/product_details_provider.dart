import 'dart:convert';

import 'package:azuramartmy/product_details/product_details_body.dart';
import 'package:azuramartmy/product_details/product_details_page.dart';
import 'package:azuramartmy/provider_models/product_details_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:http/http.dart' show Client;

class ProductDetailsProvider {
  Client client = Client();
  Future<ProductDetailsModel?> fetchProductDetails(String slug) async {
    var url = Uri.parse(Urls.baseUrl+slug);
    print('product-details ($url)');
    var response = await client.post(url);
    if (response.statusCode == 200) {
      final Map<String, dynamic> body = await json.decode(response.body);
      ProductDetailsModel detailsModel = ProductDetailsModel.fromJson(body);
      if (response.body.isNotEmpty) {
        ProductDetailsPage.isStock = detailsModel.data!.product!.totalFreeStock! > 0;
        ProductDetailsPage.isWish = detailsModel.data!.product!.isWish;
        ProductDetailsPage.variantPk = detailsModel.data!.product!.pkno;
        ProductDescription.itemQty = 1;
        ProductDescription.stockInfoRG = -1;

        /// ................
        ProductDetailsPage.itemQty = 1;
        ProductDetailsPage.stockInfoRG = -1;
        ProductDetailsPage.productDetailsModel = detailsModel;
        return detailsModel;
      }
    }else {
      throw Exception('Failed to load post');
    }
  }
}