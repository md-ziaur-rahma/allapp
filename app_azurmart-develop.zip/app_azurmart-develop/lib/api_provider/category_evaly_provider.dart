import 'dart:convert';

import 'package:azuramartmy/provider_models/category_evaly_product_model.dart';
import 'package:azuramartmy/utils/url.dart';
import 'package:dio/dio.dart';
import 'package:http/http.dart';

class CategoryEProductsProvider {
  // Client client = Client();
  Dio dio = Dio();
  Future<CategoryEProductModel?> fetchCategoryProducts(String? catId, String? subCatID, int page) async {
    Uri url = Uri.parse(Urls.baseUrl+Urls.CATEGORY_PRODUCTS);
    try{
      var response = await dio.postUri(url,data: {'cat_id': '$catId','subcat_id': '$subCatID','page': '$page'});
      if (response.statusCode == 200) {
        // CategoryEProductModel productModel = CategoryEProductModel.fromJson(response.data);
        if (response.data.isNotEmpty) {
          return CategoryEProductModel.fromJson(response.data);
        }
      }else {
        throw Exception('Failed to load post');
      }
    }on Exception catch(e){
      print(e);
    }

  }
}