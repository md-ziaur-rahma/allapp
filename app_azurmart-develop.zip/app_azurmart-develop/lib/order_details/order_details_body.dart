import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/my_bloc/order_details_bloc.dart';
import 'package:azuramartmy/payment_details/payment_details_page.dart';
import 'package:azuramartmy/provider_models/order_details_model.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/custom_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';

class OrderDetailsBody extends StatelessWidget {
  OrderDetailsBody({
    Key? key,
    this.orderId,
  }) : super(key: key);
  final int? orderId;
  final f = DateFormat('dd-MMM-yyyy');
  @override
  Widget build(BuildContext context) {
    orderDetailsBloc.fetchOrderDetails(orderId);
    return StreamBuilder(
      stream: orderDetailsBloc.allOrderDetails,
      builder: (context, AsyncSnapshot<OrderDetailsModel> snapshot) {
        if (snapshot.hasData) {
          if (snapshot.data!.status != 0) {
            return CustomScrollView(
              scrollDirection: Axis.vertical,
              slivers: <Widget>[
                SliverToBoxAdapter(
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 16),
                    width: double.infinity,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        RichText(
                          text: TextSpan(
                              text: 'Order ',
                              style: const TextStyle(
                                  color: Colors.black87,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600),
                              children: <TextSpan>[
                                TextSpan(
                                  text:
                                      '#ORD-${snapshot.data!.data!.booking!.bookingNo}',
                                  style: const TextStyle(
                                      color: Color(0xFFF68721),
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600),
                                ),
                              ]),
                        ),
                        Text(
                            f.format(DateTime.parse(snapshot.data!.data!.booking!.reconfirmTime!)),
                            style: const TextStyle(
                                color: Colors.black54,
                                fontSize: 16,
                                fontWeight: FontWeight.w500))
                      ],
                    ),
                  ),
                ),

                /// .................... Non Bundle Items...................
                for (var i = 0; i < snapshot.data!.data!.bundle!.length; i++)
                  SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) {
                        return Container(
                          width: double.infinity,
                          margin:
                          const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(
                                  width: 1, color: AppsColors.buttonColor),
                              color: const Color(0xFFFFFFFF)),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8, horizontal: 8),
                                decoration: BoxDecoration(
                                  color: AppsColors.buttonColor,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      width: double.infinity,
                                      child: Text(
                                        '${snapshot.data!.data!.bundle![i][index].bundleNamePublic} for ${snapshot.data!.data!.bundle![i][index].totalRegularBundlePrice}',
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.infinity,
                                      child: Text(
                                        'You Saved RM${snapshot.data!.data!.bundle![i][index].totalRegularPrice! - snapshot.data!.data!.bundle![i][index].totalRegularBundlePrice!}',
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              ...List.generate(
                                  snapshot.data!.data!.bundle![i][index]
                                      .bundleBreakdown!.length,
                                  (productIndex) => OrderDetailsBundleItemView(
                                        snapshot: snapshot,
                                        i: i,
                                        index: index,
                                        productIndex: productIndex,
                                      )),
                            ],
                          ),
                        );
                      },
                      childCount: snapshot.data!.data!.bundle![i].length,
                    ),
                  ),
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.bundle!.isNotEmpty) {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 12,
                        ),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),

                /// .................... Non Bundle Items...................
                for (var i = 0; i < snapshot.data!.data!.nonBundle!.length; i++)
                  SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) {
                        return snapshot.data!.data!.nonBundle![i][index].totalQty! >
                                0
                            ? Container(
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(0)),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 8),
                                margin:
                                    const EdgeInsets.symmetric(horizontal: 0),
                                child: OrderDetailsNonBundleItemView(
                                  snapshot: snapshot,
                                  i: i,
                                  index: index,
                                ),
                              )
                            : const SizedBox(
                                height: 0,
                              );
                      },
                      childCount: snapshot.data!.data!.nonBundle![i].length,
                    ),
                  ),
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.nonBundle!.isNotEmpty) {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 12,
                        ),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),

                /// .................... Book Child.........................
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.bookChild!.isNotEmpty) {
                      return SliverToBoxAdapter(
                        child: Container(
                          padding: const EdgeInsets.only(
                              left: 16, top: 16, right: 16),
                          margin: const EdgeInsets.symmetric(horizontal: 0),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(0)),
                          child: const SizedBox(
                            width: double.infinity,
                            child: Text(
                              'Products',
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.bookChild!.isNotEmpty) {
                      return SliverList(
                        delegate: SliverChildBuilderDelegate(
                            (BuildContext context, int index) {
                          return Container(
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(0)),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            margin: const EdgeInsets.symmetric(horizontal: 0),
                            child: OrderDetailsBookChildItemView(
                              snapshot: snapshot,
                              index: index,
                            ),
                          );
                        }, childCount: snapshot.data!.data!.bookChild!.length),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.bookChild!.isNotEmpty) {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 12,
                        ),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),

                /// .................... Returned Items......................
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.returnedItems!.isNotEmpty) {
                      return SliverToBoxAdapter(
                        child: Container(
                          padding: const EdgeInsets.only(
                              left: 16, top: 16, right: 16),
                          margin: const EdgeInsets.symmetric(horizontal: 0),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(0)),
                          child: const SizedBox(
                            width: double.infinity,
                            child: Text(
                              'Returned Items',
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.returnedItems!.isNotEmpty) {
                      return SliverList(
                        delegate: SliverChildBuilderDelegate(
                            (BuildContext context, int index) {
                          return Container(
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(0)),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            margin: const EdgeInsets.symmetric(horizontal: 0),
                            child: OrderReTurnedList(
                              snapshot: snapshot,
                              index: index,
                            ),
                          );
                        }, childCount: snapshot.data!.data!.returnedItems!.length),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),

                /// .................... Deleted Items........................
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.deletedItems!.isNotEmpty) {
                      return SliverToBoxAdapter(
                        child: Container(
                          padding: const EdgeInsets.only(
                              left: 16, top: 16, right: 16),
                          margin: const EdgeInsets.symmetric(horizontal: 0),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(0)),
                          child: const SizedBox(
                            width: double.infinity,
                            child: Text(
                              'Deleted Items',
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.deletedItems!.isNotEmpty) {
                      return SliverList(
                        delegate: SliverChildBuilderDelegate(
                            (BuildContext context, int index) {
                          return Container(
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(0)),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            margin: const EdgeInsets.symmetric(horizontal: 0),
                            child: OrderDetailsDeletedItemView(
                              snapshot: snapshot,
                              index: index,
                            ),
                          );
                        }, childCount: snapshot.data!.data!.deletedItems!.length),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),

                /// ................. Order Summery ..................
                SliverToBoxAdapter(
                  child: OrderDetailsView(
                    snapshot: snapshot,
                  ),
                ),

                /// ................. Payment Status ..................
                // SliverToBoxAdapter(
                //   child: PaymentStatusView(),
                // ),
                // SliverToBoxAdapter(
                //   child: SizedBox(
                //     height: 8,
                //   ),
                // ),

                /// ...................... Refunds Item ........................
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.refunded!.isNotEmpty) {
                      return SliverToBoxAdapter(
                        child: Container(
                          padding: const EdgeInsets.only(
                              left: 16, top: 16, right: 16),
                          margin: const EdgeInsets.symmetric(horizontal: 0),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(0)),
                          child: const SizedBox(
                            width: double.infinity,
                            child: Text(
                              'Refunds',
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.refunded!.isNotEmpty) {
                      return SliverList(
                        delegate: SliverChildBuilderDelegate(
                            (BuildContext context, int index) {
                          return Container(
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(0)),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            margin: const EdgeInsets.symmetric(horizontal: 0),
                            child: OrderRefundList(
                              snapshot: snapshot,
                              index: index,
                            ),
                          );
                        }, childCount: snapshot.data!.data!.refunded!.length),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),

                const SliverToBoxAdapter(
                  child: SizedBox(
                    height: 8,
                  ),
                ),

                /// ...................... Delivered Products ........................
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.dispatched!.isNotEmpty) {
                      return SliverToBoxAdapter(
                        child: Container(
                          padding: const EdgeInsets.only(
                              left: 16, top: 16, right: 16),
                          margin: const EdgeInsets.symmetric(horizontal: 0),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(0)),
                          child: const SizedBox(
                            width: double.infinity,
                            child: Text(
                              'Delivered',
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),
                SliverLayoutBuilder(
                  builder:
                      (BuildContext context, SliverConstraints constraints) {
                    if (snapshot.data!.data!.dispatched!.isNotEmpty) {
                      return SliverList(
                        delegate: SliverChildBuilderDelegate(
                            (BuildContext context, int index) {
                          return Container(
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(0)),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            margin: const EdgeInsets.symmetric(horizontal: 0),
                            child: OrderDeliveredList(
                              snapshot: snapshot,
                              index: index,
                            ),
                          );
                        }, childCount: snapshot.data!.data!.dispatched!.length),
                      );
                    } else {
                      return const SliverToBoxAdapter(
                        child: SizedBox(
                          height: 0,
                        ),
                      );
                    }
                  },
                ),

                SliverToBoxAdapter(
                  child: Container(
                    width: double.infinity,
                    color: Colors.white,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: const Text(
                      'Order Information',
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 20,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: OrderInformationView(
                    snapshot: snapshot,
                  ),
                ),
                SliverToBoxAdapter(
                  child: Container(
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            colors: [
                              const Color(0xFFCFD8DC),
                              const Color(0xFFCFD8DC).withOpacity(0.5),
                        ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter)),
                    margin: const EdgeInsets.only(top: 16),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    width: double.infinity,
                    child: RichText(
                      text: const TextSpan(
                          text: 'Note : ',
                          style: TextStyle(
                            color: Colors.red,
                            fontSize: 18,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text:
                                  'COD - Cash on delivery, RTC - Ready to collect, SD - Special Delivery',
                              style: TextStyle(
                                color: Colors.redAccent,
                                fontSize: 16,
                              ),
                            )
                          ]),
                    ),
                  ),
                )
              ],
            );
          } else {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    width: double.infinity,
                    child: const Text(
                      'Something went wrong! \nPlease Go Back and Retry',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black87,
                          fontWeight: FontWeight.normal,
                          fontSize: 16),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    style: ElevatedButton.styleFrom(
                        primary: AppsColors.buttonColor),
                    child: const Text(
                      'Go Back',
                      style: TextStyle(color: Colors.white),
                    ),
                  )
                ],
              ),
            );
            // return Center(
            //   child: NoItemsCard(),
            // );
          }
        } else if (snapshot.hasError) {
          return Center(
            child: Text(snapshot.error.toString()),
          );
        }
        return const Center(
          child: SizedBox(
            height: 20,
            width: 20,
            child: CupertinoActivityIndicator(
              animating: true,
              radius: 16,
            ),
          ),
        );
      },
    );
  }
}

/// ......................... Bundle products ......................
class OrderDetailsBundleItemView extends StatelessWidget {
  const OrderDetailsBundleItemView(
      {Key? key, this.snapshot, this.i, this.index, required this.productIndex})
      : super(key: key);
  final AsyncSnapshot<OrderDetailsModel>? snapshot;
  final int? index;
  final int? i;
  final int productIndex;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: const Color(0xFFF4F4F4), width: 1)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 1,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(
                    maxHeight: 80,
                    minHeight: 60,
                  ),
                  child: Center(
                      child: snapshot!
                                  .data!
                                  .data!
                                  .bundle![i!][index!]
                                  .bundleBreakdown![productIndex]
                                  .prdVariantImagePath ==
                              null
                          ? const NoImageWidget(
                              text: 'No \nImage',
                            )
                          : CacheImageProvide(
                              url: snapshot!
                                  .data!
                                  .data!
                                  .bundle![i!][index!]
                                  .bundleBreakdown![productIndex]
                                  .prdVariantImagePath)),
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: Text(
                        '${snapshot!.data!.data!.bundle![i!][index!].bundleBreakdown![productIndex].prdVarinatName}',
                        maxLines: 3,
                        textAlign: TextAlign.start,
                        style: const TextStyle(
                            color: Colors.black54,
                            fontSize: 16,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                    const Divider(
                      height: 30,
                      thickness: 1,
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'RM${snapshot!.data!.data!.bundle![i!][index!].bundleBreakdown![productIndex].unitDefaultPrice!.toStringAsFixed(2)}',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                        Text(
                          'Ordered : ${snapshot!.data!.data!.bundle![i!][index!].bundleBreakdown![productIndex].totalQty}',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          snapshot!
                                      .data!
                                      .data!
                                      .bundle![i!][index!]
                                      .bundleBreakdown![productIndex]
                                      .shippedQty! >
                                  0
                              ? 'Shipped : ${snapshot!.data!.data!.bundle![i!][index!].bundleBreakdown![productIndex].shippedQty}'
                              : '',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                        Text(
                          snapshot!.data!.data!.bundle![i!][index!]
                                      .bundleBreakdown![productIndex].refundQty! >
                                  0
                              ? 'Refunded : ${snapshot!.data!.data!.bundle![i!][index!].bundleBreakdown![productIndex].refundQty}'
                              : '',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

/// ......................... Non Bundle products ......................
class OrderDetailsNonBundleItemView extends StatelessWidget {
  const OrderDetailsNonBundleItemView({Key? key, this.snapshot, this.i, this.index})
      : super(key: key);
  final AsyncSnapshot<OrderDetailsModel>? snapshot;
  final int? index;
  final int? i;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: const Color(0xFFF4F4F4), width: 1)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 1,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(
                    maxHeight: 80,
                    minHeight: 60,
                  ),
                  child: Center(
                      child: snapshot!.data!.data!.nonBundle![i!][index!]
                                  .prdVariantImagePath ==
                              null
                          ? const NoImageWidget(
                              text: 'No \nImage',
                            )
                          : CacheImageProvide(
                              url: snapshot!.data!.data!.nonBundle![i!][index!]
                                  .prdVariantImagePath)),
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: Text(
                        '${snapshot!.data!.data!.nonBundle![i!][index!].prdVarinatName}',
                        maxLines: 3,
                        textAlign: TextAlign.start,
                        style: const TextStyle(
                            color: Colors.black54,
                            fontSize: 16,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                    const Divider(
                      height: 30,
                      thickness: 1,
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'RM${snapshot!.data!.data!.nonBundle![i!][index!].unitPrice!.toStringAsFixed(2)} x ${snapshot!.data!.data!.nonBundle![i!][index!].totalQty}',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                        Text(
                          'RM${snapshot!.data!.data!.nonBundle![i!][index!].lineTotal!.toStringAsFixed(2)}',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          snapshot!.data!.data!.nonBundle![i!][index!].shippedQty! > 0
                              ? 'Shipped : ${snapshot!.data!.data!.nonBundle![i!][index!].shippedQty}'
                              : '',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                        Text(
                          snapshot!.data!.data!.nonBundle![i!][index!].refundQty! >
                                      0 &&
                                  snapshot!.data!.data!.nonBundle![i!][index!]
                                          .deleteQty! >
                                      0
                              ? 'Refunded : ${snapshot!.data!.data!.nonBundle![i!][index!].refundQty}\nDeleted : ${snapshot!.data!.data!.nonBundle![i!][index!].deleteQty}'
                              : snapshot!.data!.data!.nonBundle![i!][index!]
                                          .refundQty! >
                                      0
                                  ? 'Refunded : ${snapshot!.data!.data!.nonBundle![i!][index!].refundQty}'
                                  : snapshot!.data!.data!.nonBundle![i!][index!]
                                              .deleteQty! >
                                          0
                                      ? 'Deleted : ${snapshot!.data!.data!.nonBundle![i!][index!].deleteQty}'
                                      : '',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

/// ......................... Book Child products ......................
class OrderDetailsBookChildItemView extends StatelessWidget {
  const OrderDetailsBookChildItemView({Key? key, this.snapshot, this.index})
      : super(key: key);
  final AsyncSnapshot<OrderDetailsModel>? snapshot;
  final int? index;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: const Color(0xFFF4F4F4), width: 1)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 1,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(
                    maxHeight: 80,
                    minHeight: 60,
                  ),
                  child: Center(
                      child: snapshot!.data!.data!.bookChild![index!]
                                  .prdVariantImagePath ==
                              null
                          ? const NoImageWidget(
                              text: 'No \nImage',
                            )
                          : CacheImageProvide(
                              url: snapshot!.data!.data!.bookChild![index!]
                                  .prdVariantImagePath)),
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: Text(
                        '${snapshot!.data!.data!.bookChild![index!].prdVariantName}',
                        maxLines: 3,
                        textAlign: TextAlign.start,
                        style: const TextStyle(
                            color: Colors.black54,
                            fontSize: 16,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                    const Divider(
                      height: 30,
                      thickness: 1,
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'RM${snapshot!.data!.data!.bookChild![index!].unitPrice!.toStringAsFixed(2)} x ${snapshot!.data!.data!.bookChild![index!].totalQty}',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                        Text(
                          'RM${snapshot!.data!.data!.bookChild![index!].lineTotal!.toStringAsFixed(2)}',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          snapshot!.data!.data!.bookChild![index!].shippedQty! > 0
                              ? '${snapshot!.data!.data!.bookChild![index!].shippedQty}'
                              : '',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                        Text(
                          snapshot!.data!.data!.bookChild![index!].refundQty! > 0 &&
                                  snapshot!.data!.data!.bookChild![index!]
                                          .deleteQty! >
                                      0
                              ? 'Refunded : ${snapshot!.data!.data!.bookChild![index!].refundQty}\nDeleted : ${snapshot!.data!.data!.bookChild![index!].deleteQty}'
                              : snapshot!.data!.data!.bookChild![index!].refundQty! >
                                      0
                                  ? 'Refunded : ${snapshot!.data!.data!.bookChild![index!].refundQty}'
                                  : snapshot!.data!.data!.bookChild![index!]
                                              .deleteQty! >
                                          0
                                      ? 'Deleted : ${snapshot!.data!.data!.bookChild![index!].deleteQty}'
                                      : '',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

/// ......................... Deleted products ......................
class OrderDetailsDeletedItemView extends StatelessWidget {
  const OrderDetailsDeletedItemView({Key? key, this.snapshot, this.index})
      : super(key: key);
  final AsyncSnapshot<OrderDetailsModel>? snapshot;
  final int? index;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: const Color(0xFFF4F4F4), width: 1)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 1,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(
                    maxHeight: 80,
                    minHeight: 60,
                  ),
                  child: Center(
                      child: snapshot!.data!.data!.deletedItems![index!]
                                  .prdVariantImagePath ==
                              null
                          ? const NoImageWidget(
                              text: 'No \nImage',
                            )
                          : CacheImageProvide(
                              url: snapshot!.data!.data!.deletedItems![index!]
                                  .prdVariantImagePath)),
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: Text(
                        '${snapshot!.data!.data!.deletedItems![index!].prdVariantName}',
                        maxLines: 3,
                        textAlign: TextAlign.start,
                        style: const TextStyle(
                            color: Colors.black54,
                            fontSize: 16,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                    const Divider(
                      height: 30,
                      thickness: 1,
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'RM${snapshot!.data!.data!.deletedItems![index!].unitPrice!.toStringAsFixed(2)} x ${snapshot!.data!.data!.deletedItems![index!].deleteQty}',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                        Text(
                          'RM${snapshot!.data!.data!.deletedItems![index!].lineTotal!.toStringAsFixed(2)}',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          '',
                          style: TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                        Text(
                          'Deleted : ${snapshot!.data!.data!.deletedItems![index!].deleteQty}',
                          style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 16,
                              fontWeight: FontWeight.normal),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

/// ......................... Refund products ......................
class OrderRefundList extends StatelessWidget {
  const OrderRefundList({Key? key, this.snapshot, this.index}) : super(key: key);
  final AsyncSnapshot<OrderDetailsModel>? snapshot;
  final int? index;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: const Color(0xFFF4F4F4), width: 1)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 1,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(
                        maxHeight: 80,
                        minHeight: 60,
                      ),
                      child: Center(
                          child: snapshot!.data!.data!.refunded![index!]
                                      .prdVariantImagePath ==
                                  null
                              ? const NoImageWidget(
                                  text: 'No \nImage',
                                )
                              : CacheImageProvide(
                                  url: snapshot!.data!.data!.refunded![index!]
                                      .prdVariantImagePath)),
                    ),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: Text(
                            '${snapshot!.data!.data!.refunded![index!].prdVariantName}',
                            maxLines: 3,
                            textAlign: TextAlign.start,
                            style: const TextStyle(
                                color: Colors.black54,
                                fontSize: 16,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                        const Divider(
                          height: 30,
                          thickness: 1,
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'RM${snapshot!.data!.data!.refunded![index!].currentRegularPrice!.toStringAsFixed(2)} x 1',
                              style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal),
                            ),
                            Text(
                              'Postage : RM${snapshot!.data!.data!.refunded![index!].customerPostage!.toStringAsFixed(2)}',
                              style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              '',
                              style: TextStyle(
                                  color: Colors.black54,
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal),
                            ),
                            Text(
                              'RM${snapshot!.data!.data!.refunded![index!].linePrice!.toStringAsFixed(2)}',
                              style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              decoration: BoxDecoration(
                  color: const Color(0xFFF4F4F4),
                  borderRadius: BorderRadius.circular(6.0)),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Refund : ${snapshot!.data!.data!.refunded![index!].refundAmount!.toStringAsFixed(2)}',
                    style: const TextStyle(
                        color: Colors.black87,
                        fontSize: 16,
                        fontWeight: FontWeight.w600),
                  ),
                  Text(
                    'Total : ${snapshot!.data!.data!.refunded![index!].refundAmount!.toStringAsFixed(2)}',
                    style: const TextStyle(
                        color: Colors.black87,
                        fontSize: 16,
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ......................... Returned products ......................
class OrderReTurnedList extends StatelessWidget {
  const OrderReTurnedList({Key? key, this.snapshot, this.index})
      : super(key: key);
  final AsyncSnapshot<OrderDetailsModel>? snapshot;
  final int? index;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: const Color(0xFFF4F4F4), width: 1)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 1,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(
                        maxHeight: 80,
                        minHeight: 60,
                      ),
                      child: Center(
                          child: snapshot!.data!.data!.returnedItems![index!]
                                      .prdVariantImagePath ==
                                  null
                              ? const NoImageWidget(
                                  text: 'No \nImage',
                                )
                              : CacheImageProvide(
                                  url: snapshot!.data!.data!.returnedItems![index!]
                                      .prdVariantImagePath)),
                    ),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: Text(
                            '${snapshot!.data!.data!.returnedItems![index!].prdVariantName}',
                            maxLines: 3,
                            textAlign: TextAlign.start,
                            style: const TextStyle(
                                color: Colors.black54,
                                fontSize: 16,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                        const Divider(
                          height: 30,
                          thickness: 1,
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'RM${snapshot!.data!.data!.returnedItems![index!].unitPrice!.toStringAsFixed(2)} x ${snapshot!.data!.data!.returnedItems![index!].returnQty}',
                              style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal),
                            ),
                            Text(
                              'RM${snapshot!.data!.data!.returnedItems![index!].linePrice!.toStringAsFixed(2)}',
                              style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              '',
                              style: TextStyle(
                                  color: Colors.black54,
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal),
                            ),
                            Text(
                              'Returned : ${snapshot!.data!.data!.returnedItems![index!].returnQty}',
                              style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// ......................... Delivered products ......................
class OrderDeliveredList extends StatelessWidget {
  const OrderDeliveredList({Key? key, this.snapshot, this.index})
      : super(key: key);
  final AsyncSnapshot<OrderDetailsModel>? snapshot;
  final int? index;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: const Color(0xFFF4F4F4), width: 1)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 1,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(
                        maxHeight: 80,
                        minHeight: 60,
                      ),
                      child: Center(
                          child: snapshot!.data!.data!.dispatched![index!]
                                      .prdVariantImagePath ==
                                  null
                              ? const NoImageWidget(
                                  text: 'No \nImage',
                                )
                              : CacheImageProvide(
                                  url: snapshot!.data!.data!.dispatched![index!]
                                      .prdVariantImagePath)),
                    ),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: Text(
                            '${snapshot!.data!.data!.dispatched![index!].prdVarinatName}',
                            maxLines: 3,
                            textAlign: TextAlign.start,
                            style: const TextStyle(
                                color: Colors.black54,
                                fontSize: 16,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                        const Divider(
                          height: 30,
                          thickness: 1,
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'RM${snapshot!.data!.data!.dispatched![index!].currentRegularPrice!.toStringAsFixed(2)}',
                              style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal),
                            ),
                            Text(
                              'Shipped : ${snapshot!.data!.data!.dispatched![index!].qty}',
                              style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 4,
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: const [
                            Text(
                              'Consignment',
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600),
                            ),
                            Text(
                              '',
                              style: TextStyle(
                                  color: Colors.black54,
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              flex: 1,
                              child: SizedBox(
                                width: double.infinity,
                                child: Text(
                                  '${snapshot!.data!.data!.dispatched![index!].courierTrackingNo}',
                                  style: const TextStyle(
                                      color: Colors.black54,
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal),
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 12,
                            ),
                            Expanded(
                              flex: 1,
                              child: SizedBox(
                                width: double.infinity,
                                child: Text(
                                  '${snapshot!.data!.data!.dispatched![index!].courierName}',
                                  style: const TextStyle(
                                      color: Colors.black54,
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class OrderDetailsStatus extends StatelessWidget {
  const OrderDetailsStatus({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.symmetric(
          horizontal: MediaQuery.of(context).size.width * 0.02,
          vertical: MediaQuery.of(context).size.width * 0.02),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          color: Colors.transparent,
          border: Border.all(color: Colors.transparent, width: 2)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.max,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                height: 6,
                width: 6,
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              ),
              Container(
                height: 2,
                width: 2,
                margin: const EdgeInsets.symmetric(vertical: 1, horizontal: 1.5),
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              ),
              Container(
                height: 2,
                width: 2,
                margin: const EdgeInsets.symmetric(vertical: 1, horizontal: 1.5),
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              ),
              Container(
                height: 2,
                width: 2,
                margin: const EdgeInsets.symmetric(vertical: 1, horizontal: 1.5),
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              ),
              Container(
                height: 2,
                width: 2,
                margin: const EdgeInsets.symmetric(vertical: 1, horizontal: 1.5),
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              ),
              Container(
                height: 2,
                width: 2,
                margin: const EdgeInsets.symmetric(vertical: 1, horizontal: 1.5),
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              ),
              Container(
                height: 2,
                width: 2,
                margin: const EdgeInsets.symmetric(vertical: 1, horizontal: 1.5),
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              ),
              Container(
                height: 2,
                width: 2,
                margin: const EdgeInsets.symmetric(vertical: 1, horizontal: 1.5),
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              ),
              Container(
                height: 2,
                width: 2,
                margin: const EdgeInsets.symmetric(vertical: 1, horizontal: 1.5),
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              ),
              Container(
                height: 2,
                width: 2,
                margin: const EdgeInsets.symmetric(vertical: 1, horizontal: 1.5),
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              ),
              Container(
                height: 2,
                width: 2,
                margin: const EdgeInsets.symmetric(vertical: 1, horizontal: 1.5),
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              ),
              Container(
                height: 2,
                width: 2,
                margin: const EdgeInsets.symmetric(vertical: 1, horizontal: 1.5),
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              ),
              Container(
                height: 6,
                width: 6,
                decoration:
                const ShapeDecoration(shape: CircleBorder(), color: Colors.red),
              )
            ],
          ),
          const SizedBox(
            width: 20,
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: const [
              SizedBox(
                width: double.infinity,
                child: Text(
                  'Order Approved',
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w600),
                ),
              ),
              SizedBox(
                height: 50,
              ),
              ExpansionTile(
                title: Text(
                  'Item Delivered',
                  style: TextStyle(color: Colors.black, fontSize: 16),
                ),
                children: [
                  Text('Text1'),
                  Text('Text1'),
                ],
              ),
              SizedBox(
                width: double.infinity,
                child: Text(
                  'Thu, 28 Mar 2021',
                  style: TextStyle(
                      color: Colors.black54,
                      fontSize: 12,
                      fontWeight: FontWeight.w600),
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: Text(
                  'Your ordered item has been delivered',
                  style: TextStyle(
                      color: Colors.black54,
                      fontSize: 12,
                      fontWeight: FontWeight.w600),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}

/// ................. Order Delivery Address
class OrderInformationView extends StatelessWidget {
  OrderInformationView({Key? key, this.snapshot}) : super(key: key);
  final AsyncSnapshot<OrderDetailsModel>? snapshot;
  final f = DateFormat('dd-MMM-yyyy');
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      color: Colors.white,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          const SizedBox(
            width: double.infinity,
            child: Text(
              'Delivery Address',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 18,
                  fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              '${snapshot!.data!.data!.order!.deliveryName}',
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              '${snapshot!.data!.data!.order!.prevDeliveryAddressLine1}',
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              snapshot!.data!.data!.order!.prevDeliveryAddressLine2 != null ? '${snapshot!.data!.data!.order!.prevDeliveryAddressLine2}' : '--|--',
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              '${snapshot!.data!.data!.order!.deliveryCity},${snapshot!.data!.data!.order!.deliveryState}-${snapshot!.data!.data!.order!.deliveryPostcode}',
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              snapshot!.data!.data!.order!.deliveryCountry != null
                  ? '${snapshot!.data!.data!.order!.deliveryCountry}'
                  : '',
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              'Tel : ${snapshot!.data!.data!.order!.deliveryMobile}',
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),

          const Divider(
            height: 30,
            color: Color(0xFFF4F4F4),
            thickness: 5,
          ),

          /// .............billing address...............
          const SizedBox(
            width: double.infinity,
            child: Text(
              'Billing Address',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 18,
                  fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              snapshot!.data!.data!.billingAddress!.lastName != null
                  ? '${snapshot!.data!.data!.billingAddress!.name} ${snapshot!.data!.data!.billingAddress!.lastName}'
                  : '${snapshot!.data!.data!.billingAddress!.name}',
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              '${snapshot!.data!.data!.billingAddress!.addressLine1}',
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              snapshot!.data!.data!.billingAddress!.addressLine2 != null
                  ? '${snapshot!.data!.data!.billingAddress!.addressLine2}'
                  : '',
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              '${snapshot!.data!.data!.billingAddress!.city},${snapshot!.data!.data!.billingAddress!.state}-${snapshot!.data!.data!.billingAddress!.postCode}',
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              snapshot!.data!.data!.billingAddress!.country != null ? '${snapshot!.data!.data!.billingAddress!.country}' : '',
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              'Tel : ${snapshot!.data!.data!.billingAddress!.telNo}',
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),

          const Divider(
            height: 30,
            color: Color(0xFFF4F4F4),
            thickness: 5,
          ),

          /// .............Delivery Method...............
          const SizedBox(
            width: double.infinity,
            child: Text(
              'Delivery Method',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 18,
                  fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: const Text(
              'Standard Delivery - within 5 working days from',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 6,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: Text(
              f.format(DateTime.parse(snapshot!.data!.data!.booking!.reconfirmTime!)),
              textAlign: TextAlign.start,
              style: const TextStyle(
                  color: Colors.green,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),

          const Divider(
            height: 30,
            color: Color(0xFFF4F4F4),
            thickness: 5,
          ),

          /// .............Payment Method...............
          const SizedBox(
            width: double.infinity,
            child: Text(
              'Payment Method',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 18,
                  fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: const Text(
              'BANK payment',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            width: double.infinity,
            child: const Text(
              'CASH Payment',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }
}

/// ................ Order Summery .................
class OrderDetailsView extends StatelessWidget {
  OrderDetailsView({Key? key, this.snapshot}) : super(key: key);
  final AsyncSnapshot<OrderDetailsModel>? snapshot;
  final f = DateFormat('dd-MMM-yyyy');
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 16),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: const BoxDecoration(
        color: Colors.white,
      ),
      child: Column(
        children: [
          const SizedBox(
            width: double.infinity,
            child: Text(
              'Order Summery',
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 18,
                  fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              const Text(
                'Subtotal',
                style: TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                ),
              ),
              Text(
                'RM${snapshot!.data!.data!.subtotal!.toStringAsFixed(2)}',
                style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 16,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(
            height: 8,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              const Text(
                'Postage',
                style: TextStyle(
                  color: Colors.black54,
                  fontSize: 16,
                ),
              ),
              Text(
                'RM${snapshot!.data!.data!.totalPostage!.toStringAsFixed(2)}',
                style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 16,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(
            height: 8,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              const Text(
                'Total',
                style: TextStyle(
                    color: Colors.black87,
                    fontSize: 16,
                    fontWeight: FontWeight.w600),
              ),
              Text(
                'RM${snapshot!.data!.data!.total!.toStringAsFixed(2)}',
                style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 16,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(
            height: 8,
          ),

          // ................... payment list...................
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ...List.generate(snapshot!.data!.data!.payments!.length, (index) {
                return Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  decoration: BoxDecoration(
                      color: const Color(0xFFF4F4F4),
                      borderRadius: BorderRadius.circular(6.0)),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        f.format(DateTime.parse(snapshot!.data!.data!.payments![index].txnDate!)),
                        style: const TextStyle(color: Colors.black87, fontSize: 16),
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.of(context)
                              .push(CustomRoutePageBuilder.createPageRouteLeft(
                              context,
                              PaymentDetailsPage(
                                txnId: snapshot!.data!.data!.payments![index].pkNo,
                              )));
                        },
                        child: Text(
                          'Pay - ${snapshot!.data!.data!.payments![index].code}',
                          style: const TextStyle(
                              color: Color(0xFFF68721),
                              fontSize: 16,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                      Text(
                        'RM${snapshot!.data!.data!.payments![index].paymentAmount!.toStringAsFixed(2)}',
                        style: const TextStyle(
                            color: Colors.black87,
                            fontSize: 14,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                );
              })
            ],
          ),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              const Text(
                'Paid Amount',
                style: TextStyle(color: Colors.black54, fontSize: 16),
              ),
              Text(
                'RM${snapshot!.data!.data!.paymentAmount!.toStringAsFixed(2)}',
                style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 16,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(
            height: 8,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              const Text(
                'Due Amount',
                style: TextStyle(color: Colors.redAccent, fontSize: 16),
              ),
              Text(
                'RM${snapshot!.data!.data!.due!.toStringAsFixed(2)}',
                style: const TextStyle(
                    color: Colors.red,
                    fontSize: 16,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class PaymentStatusView extends StatelessWidget {
  const PaymentStatusView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(16.0),
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              const Text(
                'Payment Status',
                style: TextStyle(color: Colors.black87, fontSize: 18),
              ),
              Container(
                decoration: BoxDecoration(
                    color: Colors.green,
                    borderRadius: BorderRadius.circular(6.0)),
                padding: const EdgeInsets.all(8),
                child: const Text(
                  'Partial',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.normal),
                ),
              )
            ],
          ),
          const SizedBox(
            height: 8,
          ),
          const SizedBox(
            width: double.infinity,
            child: Text(
              'Nagad',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.redAccent,
                  fontSize: 18,
                  fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(
            height: 8,
          ),
          SizedBox(
            width: double.infinity,
            child: RichText(
                text: const TextSpan(
                    text: 'Account  ',
                    style: TextStyle(
                        color: Colors.black54,
                        fontSize: 16,
                        fontWeight: FontWeight.w600),
                    children: <TextSpan>[
                  TextSpan(
                    text: 'RM1235.00',
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w600),
                  )
                ])),
          )
        ],
      ),
    );
  }
}

class OrderDetailsRatingView extends StatefulWidget {
  const OrderDetailsRatingView({Key? key}) : super(key: key);

  @override
  _OrderDetailsRatingViewState createState() => _OrderDetailsRatingViewState();
}

class _OrderDetailsRatingViewState extends State<OrderDetailsRatingView> {
  double rating = 3;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.symmetric(
          horizontal: MediaQuery.of(context).size.width * 0.02,
          vertical: MediaQuery.of(context).size.width * 0.02),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          color: Colors.transparent,
          border: Border.all(color: const Color(0xFFF4F4F4), width: 2)),
      child: Column(
        children: const [
          SizedBox(
            width: double.infinity,
            child: Text(
              'Give Rating',
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 14,
                  fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}
