import 'dart:io';

import 'package:azuramartmy/order_details/order_details_body.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class OrderDetailsPage extends StatelessWidget {
  const OrderDetailsPage({Key? key,this.orderId}) : super(key: key);
  final int? orderId;
  static Route route() {
    return MaterialPageRoute(builder: (_) =>const  OrderDetailsPage());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Order Details',
          style: TextStyle(color: Colors.black87),
        ),
        elevation: 0,
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black87),
        systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
      ),
      body: SafeArea(
        child: OrderDetailsBody(orderId: orderId,),
      ),
    );
  }
}
