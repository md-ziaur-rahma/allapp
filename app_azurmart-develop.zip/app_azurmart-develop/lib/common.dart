import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:oktoast/oktoast.dart';
import 'package:url_launcher/url_launcher.dart';

class Common {
  static int isGrid = 0;

  static void toastMsg(String? msg){
    showToast(
      '$msg',
      duration: const Duration(milliseconds: 3500),
      position: ToastPosition.bottom,
      backgroundColor: Colors.black.withOpacity(0.7),
      radius: 6.0,
      dismissOtherToast: true,
      textPadding: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
      textStyle: const TextStyle(fontSize: 16.0),
    );
  }

  // todo change, need to add only parameter for phone call
  static void makePhoneCall(String? contactNo) async {
    String url = 'tel:$contactNo';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  // todo change, need to add three parameter(email, subject, body)
  static void makeEmail(String? email,String subject,String body) async {
    String mailUrl = 'mailto:$email?subject=$subject&body=$body';
    if (canLaunch(mailUrl) != null) {
      await launch(mailUrl);
    } else {
      throw 'Could not launch $mailUrl';
    }
  }

  static void openFacebookApp(String url) async {
    if (canLaunch(url) != null) {
      await launch(url, forceSafariVC: false, forceWebView: false);
    } else {
      throw 'Could not launch $url';
    }
  }

  static void openInstagramApp(String url) async {
    String profile = 'https://www.instagram.com/azuramart/';
    if (canLaunch(url) != null) {
      await launch(url, forceSafariVC: false, forceWebView: false);
    } else {
      throw 'Could not launch $url';
    }
  }

  static void openPlayStore(String url) async {
    if (canLaunch(url) != null) {
      await launch(url, forceSafariVC: false, forceWebView: false);
    } else {
      throw 'Could not launch $url';
    }
  }

  // todo change, need to add latitude longitude for google map.......
  static void openMap() async {
    const String homeLat = "5.393481";
    const String homeLng = "100.404347";
    // 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3972.
    // 1540877577804!2d100.40216241525037!3d5.3934768367614065!2m3!1f0!2
    // f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x304ac5d0ccc9077d%3A0x34adc39d9e
    // 90575c!2s8%2C%20Pintas%20Tuna%203%2C%20Seberang%20Jaya%2C%2013700%20Perai%2C%20Pula
    // u%20Pinang%2C%20Malaysia!5e0!3m2!1sen!2sbd!4v1628167938374!5m2!1sen!2sbd'
    final String googleMapsLocationUrl =
        "https://www.google.com/maps/search/?api=1&query=${SharedPreferenceUtils.appSettingModel.data!.latitude},${SharedPreferenceUtils.appSettingModel.data!.longitude}";
    final String encodedURl = Uri.encodeFull(googleMapsLocationUrl);
    if (await canLaunch(encodedURl) != null) {
      await launch(encodedURl,forceWebView: false,forceSafariVC: false);
    } else {
      print('Could not launch $encodedURl');
      throw 'Could not launch $encodedURl';
    }
  }

  static void  launchUrl(String? url) async {
    String mailUrl = '$url';
    if (canLaunch(mailUrl) != null) {
      await launch(mailUrl);
    } else {
      throw 'Could not launch $mailUrl';
    }
  }

  static double getCouponAppliedPrice(double? regularPrice,double? couponAmount,int? type){
    double price = 0;
    if(type == 1){
      price = regularPrice! - (regularPrice * (couponAmount! / 100));
    }else {
      price = (regularPrice! - couponAmount!);
    }
    return price;
  }

}