import 'package:azuramartmy/home/home_page.dart';
import 'package:azuramartmy/login/login_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:flutter/material.dart';

class SliderPage extends StatefulWidget {
  const SliderPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute<void>(builder: (_) => const SliderPage());
  }

  @override
  _SliderPageState createState() => _SliderPageState();
}

class _SliderPageState extends State<SliderPage> {

  final GlobalKey<ScaffoldState> _scaffoldState = GlobalKey<ScaffoldState>();

  int currentPage = 0;
  List<Map<String, String>> splashData = [
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldState,
      body: CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          const SliverToBoxAdapter(
              child: SizedBox(
            height: 30,
          )),
          const SliverToBoxAdapter(
            child: SizedBox(
              width: double.infinity,
              child: Text(
                'Hi, We,re Woobox',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.w600),
              ),
            ),
          ),
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 8,
            ),
          ),
          const SliverToBoxAdapter(
            child: SizedBox(
              width: double.infinity,
              child: Text(
                'We make around your city,affordable\n easy and efficient',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.black54,
                    fontSize: 12,
                    fontStyle: FontStyle.italic,
                    fontWeight: FontWeight.normal),
              ),
            ),
          ),
          const SliverToBoxAdapter(
              child: SizedBox(
            height: 30,
          )),
          SliverToBoxAdapter(
            child: SizedBox(
              height: MediaQuery.of(context).size.width * 0.7,
              child: PageView.builder(
                  onPageChanged: (value) {
                    setState(() {
                      currentPage = value;
                    });
                  },
                  itemCount: splashData.length,
                  itemBuilder: (context, index) =>
                      SliderImage(splashData[index]["image"])),
            ),
          ),
          const SliverToBoxAdapter(
              child: SizedBox(
            height: 30,
          )),
          SliverToBoxAdapter(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ...List.generate(splashData.length, (index) => BuildDot(index))
              ],
            ),
          ),
          const SliverToBoxAdapter(
              child: SizedBox(
            height: 30,
          )),
          SliverToBoxAdapter(
            child: Flexible(
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.22,),
                height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50),
                  color: AppsColors.buttonColor,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 5,
                      blurRadius: 7,
                      offset: const Offset(0, 10), // changes position of shadow
                    ),
                  ],
                ),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: Colors.pinkAccent,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30))),
                  onPressed: () {
                    Navigator.pushAndRemoveUntil(
                        context, HomePage.route(), (route) => false);
                  },
                  child: const Text('Start to shopping'),
                ),
              ),
            ),
          ),
          const SliverToBoxAdapter(
              child: SizedBox(
            height: 30,
          )),
          SliverToBoxAdapter(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Already have you an account?',
                  style: TextStyle(color: Colors.black54),
                ),
                const SizedBox(
                  width: 4,
                ),
                GestureDetector(
                    onTap: () {
                      Navigator.pushAndRemoveUntil(
                          context, LoginPage.route(), (route) => false);
                    },
                    child: const Text(
                      'Sign in',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        decoration: TextDecoration.underline,
                      ),
                    )),
              ],
            ),
          ),
          const SliverToBoxAdapter(
              child: SizedBox(
            height: 30,
          )),
        ],
      ),
    );
  }

  AnimatedContainer BuildDot(int index) {
    return AnimatedContainer(
      duration: const Duration(microseconds: 1000),
      child: Container(
        margin: const EdgeInsets.only(right: 5),
        height: 8,
        width: currentPage == index ? 20 : 8,
        decoration: BoxDecoration(
            color: currentPage == index
                ? Colors.pink
                : Colors.pink.withOpacity(0.3),
            borderRadius: BorderRadius.circular(4)),
      ),
    );
  }
}

class SliderImage extends StatelessWidget {
  final String? image;
  const SliderImage(this.image);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.25, vertical: 16),
      height: MediaQuery.of(context).size.width * 0.8,
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 5,
            blurRadius: 7,
            offset: const Offset(0, 3), // changes position of shadow
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Image.asset(
          '$image',
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
