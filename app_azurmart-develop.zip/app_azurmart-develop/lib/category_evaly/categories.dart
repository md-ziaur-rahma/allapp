import 'dart:io';

import 'package:azuramartmy/category_evaly/category_evaly_page.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/common_widgets/no_items.dart';
import 'package:azuramartmy/provider_models/category_brand_details_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/shims/dart_ui_real.dart';

class CategoryView extends StatefulWidget {
  const CategoryView({Key? key, this.snapshot}) : super(key: key);
  final AsyncSnapshot<CategoryBrandDetailsModel>? snapshot;

  @override
  _CategoryViewState createState() => _CategoryViewState();
}

class _CategoryViewState extends State<CategoryView> {
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: widget.snapshot!.data!.data!.subCat!.isEmpty
          ? const Center(
              child: NoItemsCard(),
            )
          : CustomScrollView(
              scrollDirection: Axis.vertical,
              slivers: [
                const SliverToBoxAdapter(
                  child: SizedBox(
                    height: 16,
                  ),
                ),
                SliverGrid(
                  delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) {
                    return Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 0),
                      child: CategoryCard(
                        snapshot: widget.snapshot,
                        index: index,
                      ),
                    );
                  }, childCount: widget.snapshot!.data!.data!.subCat!.length),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: MediaQuery.of(context).orientation ==
                            Orientation.portrait
                        ? 3
                        : 5,
                    mainAxisSpacing: 12,
                    childAspectRatio: MediaQuery.of(context).orientation ==
                            Orientation.portrait
                        ? screenWidth / 120.0
                        : screenHeight / 100.0,
                    crossAxisSpacing: 12,
                  ),
                ),
                const SliverToBoxAdapter(
                  child: SizedBox(
                    height: 16,
                  ),
                ),
              ],
            ),
    );
  }
}

class CategoryCard extends StatefulWidget {
  const CategoryCard({Key? key, this.snapshot, this.index}) : super(key: key);
  final AsyncSnapshot<CategoryBrandDetailsModel>? snapshot;
  final int? index;

  @override
  _CategoryCardState createState() => _CategoryCardState();
}

class _CategoryCardState extends State<CategoryCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            CategoryEPage.catPk = widget
                .snapshot!.data!.data!.subCat![widget.index!].fprdcategoryno
                .toString();
            CategoryEPage.subCatPk =
                widget.snapshot!.data!.data!.subCat![widget.index!].pkno.toString();
            Navigator.push(context, CategoryEPage.route());
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }
      },
      child: ClipRRect(
        borderRadius: BorderRadius.circular(6.0),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10,sigmaY: 10),
          child: Material(
            color: Colors.transparent,
            child: Ink(
              child: Container(
                height: MediaQuery.of(context).size.width * 0.3,
                width: MediaQuery.of(context).size.width * 0.3,
                decoration: BoxDecoration(
                    color: Colors.white, borderRadius: BorderRadius.circular(10.0)),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Expanded(
                      flex: 2,
                      child: Center(
                        child: ClipRRect(
                          borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10)),
                          child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 2),
                              child: ConstrainedBox(
                                  constraints: BoxConstraints(
                                      minHeight: MediaQuery.of(context).size.width * 0.15,
                                      maxHeight:
                                      MediaQuery.of(context).size.width * 0.19),
                                  child: widget.snapshot!.data!.data!.subCat![widget.index!].icon == null
                                      ? const NoImageWidget(text: 'No \nImage',)
                                      : CacheImageProvide(url: widget.snapshot!.data!.data!.subCat![widget.index!].icon,)
                              )
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Center(
                        child: SizedBox(
                          child: Text(
                            '${widget.snapshot!.data!.data!.subCat![widget.index!].name}',
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.black87, fontSize: 12),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
