import 'dart:io';
import 'dart:ui';

import 'package:azuramartmy/brand_details/brand_details_chngenotifier.dart';
import 'package:azuramartmy/brand_details/brand_details_page.dart';
import 'package:azuramartmy/common.dart';
import 'package:azuramartmy/common_widgets/cache_image.dart';
import 'package:azuramartmy/common_widgets/no_image.dart';
import 'package:azuramartmy/common_widgets/no_items.dart';
import 'package:azuramartmy/my_bloc/brand_product_bloc.dart';
import 'package:azuramartmy/provider_models/category_brand_details_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CategoryBrandView extends StatefulWidget {
  const CategoryBrandView({Key? key,this.snapshot}) : super(key: key);
  final AsyncSnapshot<CategoryBrandDetailsModel>? snapshot;

  @override
  _CategoryBrandViewState createState() => _CategoryBrandViewState();
}

class _CategoryBrandViewState extends State<CategoryBrandView> {
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width / 3;
    final screenHeight = MediaQuery.of(context).size.height / 3;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: widget.snapshot!.data!.data!.brands!.isEmpty
          ? const Center(
        child: NoItemsCard(),
      )
          :  CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          const SliverToBoxAdapter(
            child: SizedBox(
              height: 16,
            ),
          ),
          SliverGrid(
            delegate:
                SliverChildBuilderDelegate((BuildContext context, int index) {
              return Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 0),
                child: CategoryBrandCard(snapshot: widget.snapshot,index: index,),
              );
            }, childCount: widget.snapshot!.data!.data!.brands!.length),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount:
                  MediaQuery.of(context).orientation == Orientation.portrait
                      ? 3
                      : 5,
              mainAxisSpacing: 12,
              childAspectRatio:
                  MediaQuery.of(context).orientation == Orientation.portrait
                      ? screenWidth / 120.0
                      : screenHeight / 100.0,
              crossAxisSpacing: 12,
            ),
          )
        ],
      ),
    );
  }
}

class CategoryBrandCard extends StatefulWidget {
  const CategoryBrandCard({Key? key,this.snapshot,this.index}) : super(key: key);
  final AsyncSnapshot<CategoryBrandDetailsModel>? snapshot;
  final int? index;

  @override
  _CategoryBrandCardState createState() => _CategoryBrandCardState();
}

class _CategoryBrandCardState extends State<CategoryBrandCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: ()async {
        try {
          final result = await InternetAddress.lookup('example.com');
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            context.read<BrandDetailsNotifier>().changeCategoryName('All Product');
            brandProductBloc.page = 1;
            context.read<BrandDetailsNotifier>().changeBtnClear(1);
            BrandDetailsPage.brandPk = widget.snapshot!.data!.data!.brands![widget.index!].pkno;
            Navigator.push(context, BrandDetailsPage.route());
          }
        } on SocketException catch (_) {
          Common.toastMsg('No Internet Connection');
        }

      },
      child: ClipRRect(
        borderRadius: BorderRadius.circular(6.0),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10,sigmaY: 10),
          child: Container(
            height: MediaQuery.of(context).size.width * 0.3,
            width: MediaQuery.of(context).size.width * 0.3,
            // margin: const EdgeInsets.only(left: 12),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(10.0)),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  flex: 2,
                  child: Center(
                    child: ClipRRect(
                      borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10)),
                      child: Container(
                          padding: const EdgeInsets.symmetric(
                              vertical: 2, horizontal: 2),
                          child: ConstrainedBox(
                              constraints: BoxConstraints(
                                  minHeight: MediaQuery.of(context).size.width * 0.15, maxHeight: MediaQuery.of(context).size.width * 0.19),
                              //widget.snapshot.data.data.brands[widget.index].brandlogo
                              child: widget.snapshot!.data!.data!.brands![widget.index!].brandlogo ==
                                  null
                                  ? const NoImageWidget(text: 'No \nImage',)
                                  : CacheImageProvide(url: widget.snapshot!.data!.data!.brands![widget.index!].brandlogo,)
                          )),
                    ),
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: Center(
                    child: SizedBox(
                      child: Text(
                        '${widget.snapshot!.data!.data!.brands![widget.index!].name}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.black87, fontSize: 12),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
