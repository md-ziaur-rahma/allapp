import 'dart:io';

import 'package:azuramartmy/category_evaly/categories.dart';
import 'package:azuramartmy/category_evaly/category_brand.dart';
import 'package:azuramartmy/category_evaly/category_products.dart';
import 'package:azuramartmy/common_widgets/floating_action_button.dart';
import 'package:azuramartmy/common_widgets/loading.dart';
import 'package:azuramartmy/home/home_page.dart';
import 'package:azuramartmy/my_bloc/category_brand_details_bloc.dart';
import 'package:azuramartmy/provider_models/category_brand_details_model.dart';
import 'package:azuramartmy/search/search_page.dart';
import 'package:azuramartmy/utils/colors.dart';
import 'package:azuramartmy/utils/shared_preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CategoryEPage extends StatefulWidget {
  const CategoryEPage({Key? key}) : super(key: key);

  static Route route() {
    return MaterialPageRoute(builder: (_) => CategoryEPage());
  }

  static String? catPk;
  static String? subCatPk;

  @override
  _CategoryEPageState createState() => _CategoryEPageState();
}

class _CategoryEPageState extends State<CategoryEPage>
    with SingleTickerProviderStateMixin {
  late TabController _controller;
  int _selectedIndex = 0;
  @override
  void initState() {
    super.initState();
    categoryBrandDetailsBloc.fetchAllCategoryBrandDetails(
        '${CategoryEPage.catPk}', '${CategoryEPage.subCatPk}');
    _controller = TabController(length: 3, vsync: this);
    _controller.addListener(() {
      _selectedIndex = _controller.index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        body: SafeArea(
          child: StreamBuilder(
              stream: categoryBrandDetailsBloc.allCategoryBrandDetails,
              builder:
                  (context, AsyncSnapshot<CategoryBrandDetailsModel> snapshot) {
                if (snapshot.hasData) {
                  if (snapshot.data!.data != null) {
                    return NestedScrollView(
                      headerSliverBuilder:
                          (BuildContext context, bool innerBoxIsScrolled) {
                        return <Widget>[
                          SliverAppBar(
                            title: Container(
                              height: 42,
                              width: double.infinity,
                              margin: const EdgeInsets.only(right: 10),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(6.0),
                                  color: Colors.white),
                              child: ElevatedButton(
                                onPressed: () {
                                  Navigator.push(context, SearchPage.route());
                                },
                                style: ElevatedButton.styleFrom(
                                    primary: const Color(0xFFF2F2F2), elevation: 0),
                                child: const SizedBox(
                                  width: double.infinity,
                                  child: Text(
                                    'Search...',
                                    textAlign: TextAlign.start,
                                    style: TextStyle(
                                        color: Colors.black54, fontSize: 16),
                                  ),
                                ),
                              ),
                            ),
                            elevation: 0,
                            titleSpacing: 0,
                            systemOverlayStyle: Platform.isIOS ? SystemUiOverlayStyle.dark : const SystemUiOverlayStyle(
                                statusBarIconBrightness: Brightness.dark,
                                statusBarColor: Colors.white),
                            backgroundColor: Colors.white,
                            iconTheme: const IconThemeData(color: Colors.black87),
                            pinned: true,
                            floating: true,
                            bottom: const TabBar(
                              isScrollable: true,
                              tabs: [
                                Tab(
                                    child: Text(
                                      'Products',
                                      style: TextStyle(
                                          color: Colors.black87,
                                          fontSize: 18,
                                          fontWeight: FontWeight.w600),
                                    )),
                                Tab(
                                    child: Text(
                                      'Categories',
                                      style: TextStyle(
                                          color: Colors.black87,
                                          fontSize: 18,
                                          fontWeight: FontWeight.w600),
                                    )),
                                Tab(
                                    child: Text(
                                      'Brands',
                                      style: TextStyle(
                                          color: Colors.black87,
                                          fontSize: 18,
                                          fontWeight: FontWeight.w600),
                                    )
                                ),
                              ],
                            ),
                          ),
                        ];
                      },
                      body: TabBarView(
                        children: <Widget>[
                          CategoryProductsView(
                            catPk: CategoryEPage.catPk,
                            subCatPk: CategoryEPage.subCatPk,
                          ),
                          CategoryView(
                            snapshot: snapshot,
                          ),
                          CategoryBrandView(
                            snapshot: snapshot,
                          ),
                        ],
                      ),
                    );
                  } else {
                    return const Center(
                      child: Text('Oops!Data Not Found'),
                    );
                  }
                } else if (snapshot.hasError) {
                  return Center(
                    child: Text(snapshot.error.toString()),
                  );
                }
                return LoadingWidget(color: AppsColors.buttonColor,);
              }),
        ),
        floatingActionButton: MyFloatingActionButton(snapshot: SharedPreferenceUtils.whatsappModel,),
        bottomNavigationBar: HomeBottomNavBar(isHome: 0,),
      ),
    );
  }
}
