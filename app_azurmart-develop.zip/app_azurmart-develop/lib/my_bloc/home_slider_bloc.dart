import 'package:azuramartmy/provider_models/home_slider_model.dart';
import 'package:azuramartmy/repository/home_slider_repository.dart';
import 'package:rxdart/rxdart.dart';

class HomeSliderBloc {
  final _homeSliderRepository = HomeSliderRepository();
  final _homeSliderFetcher = PublishSubject<HomeSliderModel>();

  Stream<HomeSliderModel> get allHomeSliders => _homeSliderFetcher.stream;

  fetchAllHomeSliders() async {
    HomeSliderModel? homeSliderModel =
        await _homeSliderRepository.fetchHomeSliders();
    _homeSliderFetcher.sink.add(homeSliderModel!);
  }

  dispose() {
    _homeSliderFetcher.close();
  }
}

final homeSliderBloc = HomeSliderBloc();
