import 'package:azuramartmy/repository/wish_list_repository.dart';
import 'package:azuramartmy/provider_models/wish_list_model.dart';
import 'package:rxdart/rxdart.dart';

class WishListBloc {
  final _wishListRepository = WishListRepository();
  final _wishListFetcher = PublishSubject<WishListModel>();

  Stream<WishListModel> get allWishLists => _wishListFetcher.stream;

  fetchAllWishLists() async {
    WishListModel? wishListModel =
    await _wishListRepository.fetchWishLists();
    _wishListFetcher.sink.add(wishListModel!);
  }

  dispose() {
    _wishListFetcher.close();
  }
}

final wishListBloc = WishListBloc();