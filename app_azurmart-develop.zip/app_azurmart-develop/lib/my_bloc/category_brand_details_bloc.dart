import 'package:azuramartmy/provider_models/category_brand_details_model.dart';
import 'package:azuramartmy/repository/category_brand_details_repository.dart';
import 'package:rxdart/rxdart.dart';

class CategoryBrandDetailsBloc {
  final _categoryBrandDetailsRepository = CategoryBrandsDetailsRepository();
  final _categoryBrandDetailsFetcher = PublishSubject<CategoryBrandDetailsModel>();

  Stream<CategoryBrandDetailsModel> get allCategoryBrandDetails => _categoryBrandDetailsFetcher.stream;

  fetchAllCategoryBrandDetails(String catId,String subCatID) async {
    CategoryBrandDetailsModel? categoryEProductsModel =
    await _categoryBrandDetailsRepository.fetchCategoryBrandDetails(catId,subCatID);
    _categoryBrandDetailsFetcher.sink.add(categoryEProductsModel!);
  }

  dispose() {
    _categoryBrandDetailsFetcher.close();
  }
}

final categoryBrandDetailsBloc = CategoryBrandDetailsBloc();