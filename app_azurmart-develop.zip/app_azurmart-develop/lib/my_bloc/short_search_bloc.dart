import 'package:azuramartmy/provider_models/short_search_models.dart';
import 'package:azuramartmy/repository/short_search_repository.dart';
import 'package:rxdart/rxdart.dart';

class ShortSearchBloc {
  final _shortSearchRepository = ShortSearchRepository();
  final _shortSearchFetcher = PublishSubject<ShortSearchModels>();

  Stream<ShortSearchModels> get shortSearch => _shortSearchFetcher.stream;

  fetchAllBrands(String keyword) async {
    ShortSearchModels? brandModel =
    await _shortSearchRepository.fetchShortSearch(keyword);
    _shortSearchFetcher.sink.add(brandModel!);
  }

  dispose() {
    _shortSearchFetcher.close();
  }
}

final shortSearchBloc = ShortSearchBloc();