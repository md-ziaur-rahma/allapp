import 'package:azuramartmy/provider_models/aboutus_model.dart';
import 'package:azuramartmy/repository/aboutus_repository.dart';
import 'package:rxdart/rxdart.dart';

class AboutUsBloc {
  final _aboutUsRepository = AboutUsRepository();
  final _aboutUsFetcher = PublishSubject<AboutUsModel>();

  Stream<AboutUsModel> get allAboutUs => _aboutUsFetcher.stream;

  fetchAboutUs() async {
    AboutUsModel? aboutUsModel =
    await _aboutUsRepository.fetchAboutUs();
    _aboutUsFetcher.sink.add(aboutUsModel!);
  }

  dispose() {
    _aboutUsFetcher.close();
  }
}

final aboutUsBloc = AboutUsBloc();