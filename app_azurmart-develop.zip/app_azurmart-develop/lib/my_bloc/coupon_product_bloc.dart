import 'package:azuramartmy/provider_models/coupon_product_model.dart';
import 'package:azuramartmy/repository/coupon_product_repository.dart';
import 'package:rxdart/rxdart.dart';

class CouponProductBloc {
  int page = 1;
  final _couponProductRepository = CouponProductRepository();
  final _couponProductFetcher = PublishSubject<CouponProductModel>();

  Stream<CouponProductModel> get allCouponProduct => _couponProductFetcher.stream;

  fetchAllCouponProducts(String? couponCode) async {
    CouponProductModel? couponProductModel =
    await _couponProductRepository.fetchCouponProduct(couponCode,page);
    _couponProductFetcher.sink.add(couponProductModel!);
  }

  fetchPagingData(String? couponCode) async {
    page++;
    CouponProductModel? bestShellModel = await _couponProductRepository.fetchCouponProduct(couponCode,page);
    _couponProductFetcher.sink.add(bestShellModel!);
  }

  dispose() {
    _couponProductFetcher.close();
  }
}

final couponProductBloc = CouponProductBloc();