import 'package:azuramartmy/provider_models/new_arrival_item_model.dart';
import 'package:azuramartmy/repository/new_arrival_product_repository.dart';
import 'package:rxdart/rxdart.dart';

class NewArrivalProductBloc {
  int page = 1;
  final _repository = NewArrivalProductRepository();
  final _newArrivalProductFetcher = PublishSubject<NewArrivalItemModel>();

  Stream<NewArrivalItemModel> get allNewProduct => _newArrivalProductFetcher.stream;

  fetchAllNewProduct () async {
    NewArrivalItemModel? newArrivalItemModel = await _repository.fetchProduct(page);
    _newArrivalProductFetcher.sink.add(newArrivalItemModel!);
  }

  fetchLatestPagingProduct () async {
    page++;
    NewArrivalItemModel? newArrivalItemModel = await _repository.fetchProduct(page);
    _newArrivalProductFetcher.sink.add(newArrivalItemModel!);
  }

  dispose() {
    _newArrivalProductFetcher.close();
  }

}

final newProductBloc = NewArrivalProductBloc();