
import 'package:azuramartmy/provider_models/model_search_result_model.dart';
import 'package:azuramartmy/repository/model_search_result_repository.dart';
import 'package:rxdart/rxdart.dart';

class ModelSearchResultBloc {
  int page = 1;
  final _modelSearchResultRepository = ModelSearchResultRepository();
  final _modelSearchResultFetcher = PublishSubject<ModelSearchResultModel>();

  Stream<ModelSearchResultModel> get allModelSearchResult => _modelSearchResultFetcher.stream;

  fetchAllModelSearchResult(int? modelNo) async {
    ModelSearchResultModel? modelSearchResult =
    await _modelSearchResultRepository.fetchModelSearchResult(modelNo,page);
    _modelSearchResultFetcher.sink.add(modelSearchResult!);
  }

  fetchPagingAllSearch(int? modelNo) async {
    page++;
    ModelSearchResultModel? modelSearchResult =
    await _modelSearchResultRepository.fetchModelSearchResult(modelNo,page);
    _modelSearchResultFetcher.sink.add(modelSearchResult!);
  }

  dispose() {
    _modelSearchResultFetcher.close();
  }
}

final modelSearchResultBloc = ModelSearchResultBloc();