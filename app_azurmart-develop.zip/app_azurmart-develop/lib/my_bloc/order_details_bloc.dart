import 'package:azuramartmy/provider_models/order_details_model.dart';
import 'package:azuramartmy/repository/order_details_repository.dart';
import 'package:rxdart/rxdart.dart';

class OrderDetailsBloc {
  final _orderDetailsRepository = OrderDetailsRepository();
  final _orderDetailsFetcher = PublishSubject<OrderDetailsModel>();
  Stream<OrderDetailsModel> get allOrderDetails =>
      _orderDetailsFetcher.stream;
  fetchOrderDetails(int? orderId) async {
    OrderDetailsModel? orderDetailsModel = await _orderDetailsRepository.fetchOrderDetailsModel(orderId);
    _orderDetailsFetcher.sink.add(orderDetailsModel!);
  }
  dispose(){
    _orderDetailsFetcher.close();
  }
}
final orderDetailsBloc = OrderDetailsBloc();
