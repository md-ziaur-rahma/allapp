import 'package:azuramartmy/provider_models/blog_details_model.dart';
import 'package:azuramartmy/repository/blog_details_repository.dart';
import 'package:rxdart/rxdart.dart';

class BlogDetailsBloc {
  final _blogDetailsRepository = BlogDetailsRepository();
  final _blogDetailsFetcher = PublishSubject<BlogDetailsModel>();

  Stream<BlogDetailsModel> get allBlogDetails => _blogDetailsFetcher.stream;

  fetchBlogDetails(String slug) async {
    BlogDetailsModel? aboutUsModel =
    await _blogDetailsRepository.fetchBlogDetails(slug);
    _blogDetailsFetcher.sink.add(aboutUsModel!);
  }

  dispose() {
    _blogDetailsFetcher.close();
  }
}

final blogDetailsBloc = BlogDetailsBloc();