import 'package:azuramartmy/provider_models/best_sell_model.dart';
import 'package:azuramartmy/provider_models/orderlist_model.dart';
import 'package:azuramartmy/repository/orderlist_repository.dart';
import 'package:rxdart/rxdart.dart';

class OrderListBloc {
  final _orderListRepository = OrderListRepository();
  final _orderListFetcher = PublishSubject<OrderListModel>();

  Stream<OrderListModel> get allOrderList => _orderListFetcher.stream;

  fetchAllOrderList(int? groupId) async {
    OrderListModel? orderListModel =
    await _orderListRepository.fetchOrderList(groupId);
    _orderListFetcher.sink.add(orderListModel!);
  }

  dispose() {
    _orderListFetcher.close();
  }
}

final orderListBloc = OrderListBloc();