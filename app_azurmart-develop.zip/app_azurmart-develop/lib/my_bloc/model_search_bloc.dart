
import 'package:azuramartmy/provider_models/model_search_model.dart';
import 'package:azuramartmy/repository/model_search_repository.dart';
import 'package:rxdart/rxdart.dart';

class ModelSearchBloc {
  final _modelSearchRepository = ModelSearchRepository();
  final _modelSearchFetcher = PublishSubject<ModelSearchModel>();

  Stream<ModelSearchModel> get allModelSearchResult => _modelSearchFetcher.stream;

  fetchAllModelSearch(String? keyword) async {
    ModelSearchModel? modelSearch =
    await _modelSearchRepository.fetchModelSearch(keyword);
    _modelSearchFetcher.sink.add(modelSearch!);
  }

  dispose() {
    _modelSearchFetcher.close();
  }
}

final modelSearchBloc = ModelSearchBloc();