import 'package:azuramartmy/provider_models/cart_count_model.dart';
import 'package:azuramartmy/repository/cart_count_repository.dart';
import 'package:rxdart/rxdart.dart';

class CartCountBloc {
  final _cartCountRepository = CartCountRepository();
  final _cartCountFetcher = PublishSubject<CartCountModel>();

  Stream<CartCountModel> get allCartCount => _cartCountFetcher.stream;

  fetchAllCartCount() async {
    CartCountModel? cartCountModel =
    await _cartCountRepository.fetchCartCount();
    _cartCountFetcher.sink.add(cartCountModel!);
  }

  dispose() {
    _cartCountFetcher.close();
  }
}

final cartCountBloc = CartCountBloc();