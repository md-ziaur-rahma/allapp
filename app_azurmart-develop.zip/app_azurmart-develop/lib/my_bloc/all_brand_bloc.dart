import 'package:azuramartmy/provider_models/brand_model.dart';
import 'package:azuramartmy/repository/all_brand_repository.dart';
import 'package:rxdart/rxdart.dart';

class AllBrandBloc {
  final _allBrandRepository = AllBrandRepository();
  final _allBrandFetcher = PublishSubject<BrandModel>();

  Stream<BrandModel> get allBrands => _allBrandFetcher.stream;

  fetchAllBrands() async {
    BrandModel? brandModel =
    await _allBrandRepository.fetchAllBrands();
    _allBrandFetcher.sink.add(brandModel!);
  }

  dispose() {
    _allBrandFetcher.close();
  }
}

final allBrandBloc = AllBrandBloc();