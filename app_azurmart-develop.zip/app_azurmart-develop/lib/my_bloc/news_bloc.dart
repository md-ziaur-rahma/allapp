import 'package:azuramartmy/provider_models/best_sell_model.dart';
import 'package:azuramartmy/provider_models/news_model.dart';
import 'package:azuramartmy/repository/best_sell_repository.dart';
import 'package:azuramartmy/repository/news_repository.dart';
import 'package:rxdart/rxdart.dart';

class NewsBloc {
  int page = 1;
  final _newsRepository = NewsRepository();
  final _newsFetcher = PublishSubject<NewsModel>();

  Stream<NewsModel> get allNews => _newsFetcher.stream;

  fetchAllNews() async {
    NewsModel? newsModel =
    await _newsRepository.fetchNews(page);
    _newsFetcher.sink.add(newsModel!);
  }

  fetchPagingData() async {
    page++;
    NewsModel? newsModel = await _newsRepository.fetchNews(page);
    _newsFetcher.sink.add(newsModel!);
  }

  dispose() {
    _newsFetcher.close();
  }
}

final newsBloc = NewsBloc();