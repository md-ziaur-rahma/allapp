
import 'package:azuramartmy/provider_models/search_models.dart';
import 'package:azuramartmy/repository/search_repository.dart';
import 'package:rxdart/rxdart.dart';

class SearchBloc {
  int page = 1;
  final _searchRepository = SearchRepository();
  final _searchFetcher = PublishSubject<SearchModels>();

  Stream<SearchModels> get allSearchResult => _searchFetcher.stream;

  fetchAllSearch(String? keyword) async {
    SearchModels? brandModel =
    await _searchRepository.fetchSearch(keyword,page);
    _searchFetcher.sink.add(brandModel!);
  }

  fetchPagingAllSearch(String? keyword) async {
    page++;
    SearchModels? brandModel =
    await _searchRepository.fetchSearch(keyword,page);
    _searchFetcher.sink.add(brandModel!);
  }

  dispose() {
    _searchFetcher.close();
  }
}

final searchBloc = SearchBloc();