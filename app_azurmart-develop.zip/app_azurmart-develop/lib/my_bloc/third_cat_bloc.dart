import 'package:azuramartmy/provider_models/category_product.dart';
import 'package:azuramartmy/repository/third_cat_repository.dart';
import 'package:rxdart/rxdart.dart';

class ThirdCategoryProductBloc {
  int page = 1;
  final _thirdCategoryProductRepository = ThirdCategoryProductRepository();
  final _thirdCategoryProductFetcher = PublishSubject<CategoryProduct>();

  Stream<CategoryProduct> get allThirdCategoryProduct =>
      _thirdCategoryProductFetcher.stream;
  fetchAllThirdCategoryProduct (String cat, String subCat, String product,) async {
    CategoryProduct? categoryProduct = await _thirdCategoryProductRepository.fetchAllThirdCategoryProducts(cat, subCat, product,page);
    _thirdCategoryProductFetcher.sink.add(categoryProduct!);
  }

  fetchPagingAllThirdCategoryProduct (String cat, String subCat, String product,) async {
    page++;
    CategoryProduct? categoryProduct = await _thirdCategoryProductRepository.fetchAllThirdCategoryProducts(cat, subCat, product,page);
    _thirdCategoryProductFetcher.sink.add(categoryProduct!);
  }

  dispose(){
    _thirdCategoryProductFetcher.close();
  }
}

final thirdCategoryProductBloc = ThirdCategoryProductBloc();
