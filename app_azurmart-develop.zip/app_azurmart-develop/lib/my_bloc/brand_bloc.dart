import 'package:azuramartmy/provider_models/brand_model.dart';
import 'package:azuramartmy/repository/brand_repository.dart';
import 'package:rxdart/rxdart.dart';

class BrandBloc {
  final _brandRepository = BrandRepository();
  final _brandFetcher = PublishSubject<BrandModel>();

  Stream<BrandModel> get allBrands => _brandFetcher.stream;

  fetchAllBrands() async {
    BrandModel? brandModel =
    await _brandRepository.fetchBrands();
    _brandFetcher.sink.add(brandModel!);
  }

  dispose() {
    _brandFetcher.close();
  }
}

final brandBloc = BrandBloc();