import 'package:azuramartmy/provider_models/best_sell_model.dart';
import 'package:azuramartmy/provider_models/instagram_feed_model.dart';
import 'package:azuramartmy/repository/best_sell_repository.dart';
import 'package:azuramartmy/repository/instagram_feed_repository.dart';
import 'package:rxdart/rxdart.dart';

class InstagramFeedBloc {
  final _instagramFeedRepository = InstagramFeedRepository();
  final _instagramFeedFetcher = PublishSubject<InstagramFeedModel>();

  Stream<InstagramFeedModel> get allInstagramFeed => _instagramFeedFetcher.stream;

  fetchAllInstagramFeed() async {
    InstagramFeedModel? instagramFeedModel =
    await _instagramFeedRepository.fetchInstagramFeed();
    _instagramFeedFetcher.sink.add(instagramFeedModel!);
  }

  dispose() {
    _instagramFeedFetcher.close();
  }
}

final instagramFeedBloc = InstagramFeedBloc();