import 'package:azuramartmy/provider_models/offer_details_model.dart';
import 'package:azuramartmy/repository/offer_details_repository.dart';
import 'package:rxdart/rxdart.dart';

class OfferDetailsBloc {
  final _offerDetailsRepository = OfferDetailsRepository();
  final _offerDetailsFetcher = PublishSubject<OfferDetailsModel>();

  Stream<OfferDetailsModel> get allOfferDetails => _offerDetailsFetcher.stream;

  fetchAllOfferDetails(String offerName) async {
    OfferDetailsModel? offerDetailsModel =
    await _offerDetailsRepository.fetchOfferDetails(offerName);
    _offerDetailsFetcher.sink.add(offerDetailsModel!);
  }

  dispose() {
    _offerDetailsFetcher.close();
  }
}

final offerDetailsBloc = OfferDetailsBloc();