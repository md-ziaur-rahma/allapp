import 'package:azuramartmy/provider_models/category_product.dart';
import 'package:azuramartmy/repository/second_cat_repository.dart';
import 'package:rxdart/rxdart.dart';

class SecondCategoryProductBloc {
  int page = 1;
  final _secondCategoryProductRepository = SecondCategoryProductRepository();
  final _secondCategoryProductFetcher = PublishSubject<CategoryProduct>();

  Stream<CategoryProduct> get allSecondCategoryProduct =>
      _secondCategoryProductFetcher.stream;
  fetchAllSecondCategoryProduct (String cat, String subCat, String product,) async {
    CategoryProduct categoryProduct = await _secondCategoryProductRepository.fetchAllSecondCategoryProducts(cat, subCat, product,page);
    _secondCategoryProductFetcher.sink.add(categoryProduct);
  }

  fetchPagingAllSecondCategoryProduct (String cat, String subCat, String product,) async {
    page++;
    CategoryProduct categoryProduct = await _secondCategoryProductRepository.fetchAllSecondCategoryProducts(cat, subCat, product,page);
    _secondCategoryProductFetcher.sink.add(categoryProduct);
  }

  dispose(){
    _secondCategoryProductFetcher.close();
  }
}

final secondCategoryProductBloc = SecondCategoryProductBloc();
