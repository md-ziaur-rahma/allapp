import 'package:azuramartmy/provider_models/category_product.dart';
import 'package:azuramartmy/repository/first_cat_repository.dart';
import 'package:rxdart/rxdart.dart';

class FirstCategoryProductBloc {
  int page = 1;
  final _firstCategoryProductRepository = FirstCategoryProductRepository();
  final _firstCategoryProductFetcher = PublishSubject<CategoryProduct>();

  Stream<CategoryProduct> get allFirstCategoryProduct =>
      _firstCategoryProductFetcher.stream;
  fetchAllFirstCategoryProduct (String cat, String subCat, String product,) async {
    CategoryProduct? categoryProduct = await _firstCategoryProductRepository.fetchAllFirstCategoryProducts(cat, subCat, product,page);
    _firstCategoryProductFetcher.sink.add(categoryProduct!);
  }

  fetchPagingFirstCategoryProduct (String cat, String subCat, String product,) async {
    page++;
    CategoryProduct? categoryProduct = await _firstCategoryProductRepository.fetchAllFirstCategoryProducts(cat, subCat, product,page);
    _firstCategoryProductFetcher.sink.add(categoryProduct!);
  }

  dispose(){
    _firstCategoryProductFetcher.close();
  }
}

final firstCategoryProductBloc = FirstCategoryProductBloc();
