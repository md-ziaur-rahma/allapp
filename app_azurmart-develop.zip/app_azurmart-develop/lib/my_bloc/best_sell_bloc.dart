import 'package:azuramartmy/provider_models/best_sell_model.dart';
import 'package:azuramartmy/repository/best_sell_repository.dart';
import 'package:rxdart/rxdart.dart';

class BestSellBloc {
  int page = 1;
  final _bestSellRepository = BestSellRepository();
  final _bestSellFetcher = PublishSubject<BestSellModel>();

  Stream<BestSellModel> get allBestSellProduct => _bestSellFetcher.stream;

  fetchAllBestSellProducts() async {
    BestSellModel? bestShellModel =
    await _bestSellRepository.fetchBestSellProduct(page);
    _bestSellFetcher.sink.add(bestShellModel!);
  }

  fetchPagingData() async {
    page++;
    BestSellModel? bestShellModel = await _bestSellRepository.fetchBestSellProduct(page);
    _bestSellFetcher.sink.add(bestShellModel!);
  }

  dispose() {
    _bestSellFetcher.close();
  }
}

final bestSellBloc = BestSellBloc();