import 'package:azuramartmy/repository/product_details_repository.dart';
import 'package:rxdart/rxdart.dart';
import 'package:azuramartmy/provider_models/product_details_model.dart';

class ProductDetailsBloc {
  final _productDetailsRepository = ProductDetailsRepository();
  final _productDetailsFetcher = PublishSubject<ProductDetailsModel>();
  Stream<ProductDetailsModel> get allProductDetails =>
      _productDetailsFetcher.stream;
  fetchAllProductDetails(String slug) async {
    ProductDetailsModel? detailsModel = await _productDetailsRepository.fetchAllProductDetailsModel(slug);
    _productDetailsFetcher.sink.add(detailsModel!);
  }
  dispose(){
    _productDetailsFetcher.close();
  }
}
final productDetailsBloc = ProductDetailsBloc();
