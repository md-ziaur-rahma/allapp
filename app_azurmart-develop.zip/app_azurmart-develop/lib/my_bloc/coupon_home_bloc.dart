import 'package:azuramartmy/provider_models/coupon_home_model.dart';
import 'package:azuramartmy/provider_models/coupon_list_model.dart';
import 'package:azuramartmy/repository/coupon_home_repository.dart';
import 'package:rxdart/rxdart.dart';

class CouponHomeBloc {
  final _couponHomeRepository = CouponHomeRepository();
  final _couponHomeFetcher = PublishSubject<CouponHomeModel>();

  Stream<CouponHomeModel> get allCouponHome => _couponHomeFetcher.stream;

  fetchAllCouponHome() async {
    CouponHomeModel? couponHomeModel =
    await _couponHomeRepository.fetchCouponHome();
    _couponHomeFetcher.sink.add(couponHomeModel!);
  }

  dispose() {
    _couponHomeFetcher.close();
  }
}

final couponHomeBloc = CouponHomeBloc();