import 'package:azuramartmy/provider_models/brand_details_model.dart';
import 'package:azuramartmy/repository/brand_details_repository.dart';
import 'package:rxdart/rxdart.dart';

class BrandDetailsBloc {
  final _brandDetailsRepository = BrandDetailsRepository();
  final _brandDetailsFetcher = PublishSubject<BrandDetailsModel>();

  Stream<BrandDetailsModel> get allBrandDetails => _brandDetailsFetcher.stream;

  fetchAllBrandDetails(int? pkNo) async {
    BrandDetailsModel? brandDetailsModel =
    await _brandDetailsRepository.fetchBrandDetails(pkNo);
    _brandDetailsFetcher.sink.add(brandDetailsModel!);
  }

  dispose() {
    _brandDetailsFetcher.close();
  }
}

final brandDetailsBloc = BrandDetailsBloc();