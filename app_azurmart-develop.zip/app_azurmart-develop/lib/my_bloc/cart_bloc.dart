import 'package:azuramartmy/provider_models/cart_model.dart';
import 'package:azuramartmy/repository/cart_repository.dart';
import 'package:rxdart/rxdart.dart';

class CartBloc {
  final _cartRepository = CartRepository();
  final _cartFetcher = PublishSubject<CartModel>();

  Stream<CartModel> get allCarts => _cartFetcher.stream;

  fetchAllCarts() async {
    CartModel? cartModel =
    await _cartRepository.fetchCarts();
    _cartFetcher.sink.add(cartModel!);
  }

  dispose() {
    _cartFetcher.close();
  }
}

final cartBloc = CartBloc();