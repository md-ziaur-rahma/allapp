import 'package:azuramartmy/provider_models/coupon_list_model.dart';
import 'package:azuramartmy/repository/coupon_list_repository.dart';
import 'package:rxdart/rxdart.dart';

class CouponListBloc {
  final _couponListRepository = CouponListRepository();
  final _couponListFetcher = PublishSubject<CouponListModel>();

  Stream<CouponListModel> get allCouponList => _couponListFetcher.stream;

  fetchAllCouponList() async {
    CouponListModel? couponListModel =
    await _couponListRepository.fetchCouponProduct();
    _couponListFetcher.sink.add(couponListModel!);
  }

  dispose() {
    _couponListFetcher.close();
  }
}

final couponListBloc = CouponListBloc();