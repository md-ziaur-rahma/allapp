import 'package:azuramartmy/provider_models/whatsapp_model.dart';
import 'package:azuramartmy/repository/whatsapp_repository.dart';
import 'package:rxdart/rxdart.dart';

class WhatsappBloc {
  final _whatsappRepository = WhatsappRepository();
  final _whatsappFetcher = PublishSubject<WhatsappModel>();

  Stream<WhatsappModel> get allWhatsapp => _whatsappFetcher.stream;

  fetchAllWhatsapp() async {
    WhatsappModel? whatsappModel =
    await _whatsappRepository.fetchWhatsapp();
    _whatsappFetcher.sink.add(whatsappModel!);
  }

  dispose() {
    _whatsappFetcher.close();
  }
}

final whatsappBloc = WhatsappBloc();