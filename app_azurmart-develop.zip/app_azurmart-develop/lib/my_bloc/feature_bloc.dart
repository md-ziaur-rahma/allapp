import 'package:azuramartmy/provider_models/feature_model.dart';
import 'package:azuramartmy/repository/feature_repository.dart';
import 'package:rxdart/rxdart.dart';

class FeatureBloc {
  int page = 1;
  final _featureRepository = FeatureRepository();
  final _featureFetcher = PublishSubject<FeatureModel>();

  Stream<FeatureModel> get allFeatures => _featureFetcher.stream;

  fetchAllFeatures() async {
    FeatureModel? featureModel = await _featureRepository.fetchFeatureProducts(page);
    _featureFetcher.sink.add(featureModel!);
  }

  fetchPagingData() async {
    page++;
    FeatureModel? featureModel = await _featureRepository.fetchFeatureProducts(page);
    _featureFetcher.sink.add(featureModel!);
  }

  dispose() {
    _featureFetcher.close();
  }
}

final featureBloc = FeatureBloc();
