import 'package:azuramartmy/provider_models/brand_product_model.dart';
import 'package:azuramartmy/repository/brand_product_repository.dart';
import 'package:rxdart/rxdart.dart';

class BrandProductBloc {
  int page = 1;
  final _brandProductRepository = BrandProductRepository();
  final _brandProductFetcher = PublishSubject<BrandProductModel>();

  Stream<BrandProductModel> get allBrandProducts => _brandProductFetcher.stream;

  fetchAllBrandProducts(int? brandPk, String categoryPk) async {
    BrandProductModel? brandProductModel =
    await _brandProductRepository.fetchBrandProducts(brandPk,categoryPk,page);
    _brandProductFetcher.sink.add(brandProductModel!);
  }

  fetchPagingProduct (int? brandPk, String categoryPk) async {
    page++;
    BrandProductModel? brandProductModel = await _brandProductRepository.fetchBrandProducts(brandPk,categoryPk,page);
    _brandProductFetcher.sink.add(brandProductModel!);
  }

  dispose() {
    _brandProductFetcher.close();
  }
}

final brandProductBloc = BrandProductBloc();