import 'package:azuramartmy/provider_models/address_list_model.dart';
import 'package:azuramartmy/repository/address_repository.dart';
import 'package:rxdart/rxdart.dart';

class AddressBloc {
  final _addressRepository = AddressRepository();
  final _addressFetcher = PublishSubject<AddressListModel>();

  Stream<AddressListModel> get allAddress => _addressFetcher.stream;

  fetchAllAddress() async {
    AddressListModel? addressListModel =
    await _addressRepository.fetchAllAddress();
    _addressFetcher.sink.add(addressListModel!);
  }

  dispose() {
    _addressFetcher.close();
  }
}

final addressBloc = AddressBloc();