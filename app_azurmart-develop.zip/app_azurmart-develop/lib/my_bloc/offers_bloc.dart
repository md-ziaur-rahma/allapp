import 'package:azuramartmy/provider_models/offer_model.dart';
import 'package:azuramartmy/repository/offers_repository.dart';
import 'package:rxdart/rxdart.dart';

class OfferBloc {
  int page = 1;
  final _offerRepository = OfferRepository();
  final _offerFetcher = PublishSubject<OfferModel>();

  Stream<OfferModel> get allOffer => _offerFetcher.stream;

  fetchAllOffer(int limit) async {
    OfferModel? offerModel = await _offerRepository.fetchOfferProducts(page,limit);
    _offerFetcher.sink.add(offerModel!);
  }

  fetchPagingData() async {
    page++;
    OfferModel? offerModel = await _offerRepository.fetchOfferProducts(page,null);
    _offerFetcher.sink.add(offerModel!);
  }

  dispose() {
    _offerFetcher.close();
  }
}

final offerBloc = OfferBloc();