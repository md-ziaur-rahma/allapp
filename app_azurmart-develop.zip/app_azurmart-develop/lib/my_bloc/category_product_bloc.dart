import 'package:azuramartmy/provider_models/category_product.dart';
import 'package:azuramartmy/repository/category_product_repository.dart';
import 'package:rxdart/rxdart.dart';

class CategoryProductBloc {
  int page = 1;
  final _categoryProductRepository = CategoryProductRepository();
  final _categoryProductFetcher = PublishSubject<CategoryProduct>();

  Stream<CategoryProduct> get allCategoryProduct =>
      _categoryProductFetcher.stream;
  fetchAllCategoryProduct (String cat, String? subCat, String? product,) async {
    CategoryProduct categoryProduct = await _categoryProductRepository.fetchAllCategoryProducts(cat, subCat, product,page);
    _categoryProductFetcher.sink.add(categoryProduct);
  }

  fetchPagingProduct (String cat, String subCat, String product,) async {
    page++;
    CategoryProduct categoryProduct = await _categoryProductRepository.fetchAllCategoryProducts(cat, subCat, product,page);
    _categoryProductFetcher.sink.add(categoryProduct);
  }

  dispose(){
    _categoryProductFetcher.close();
  }
}

final categoryProductBloc = CategoryProductBloc();
