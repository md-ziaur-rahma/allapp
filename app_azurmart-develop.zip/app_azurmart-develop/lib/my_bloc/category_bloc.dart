import 'package:azuramartmy/provider_models/category2.dart';
import 'package:azuramartmy/repository/category_repository.dart';
import 'package:rxdart/rxdart.dart';

class CategoryBloc {
  final _categoryRepository = CategoryRepository();
  final _categoryFetcher = PublishSubject<Category2>();
  
  Stream<Category2> get allCategory => _categoryFetcher.stream;
  
  fetchAllCategory () async {
    Category2 category = await _categoryRepository.fetchCategory();
    _categoryFetcher.sink.add(category);
  }
  dispose() {
    _categoryFetcher.close();
  }
}

final categoryBloc = CategoryBloc();

