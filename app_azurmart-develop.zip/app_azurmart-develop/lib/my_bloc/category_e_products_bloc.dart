import 'package:azuramartmy/provider_models/category_evaly_product_model.dart';
import 'package:azuramartmy/repository/category_e_product_repository.dart';
import 'package:rxdart/rxdart.dart';

class CategoryEProductsBloc {
  int page = 1;
  final _categoryEProductsRepository = CategoryEProductsRepository();
  final _categoryEProductsFetcher = PublishSubject<CategoryEProductModel>();

  Stream<CategoryEProductModel> get allCategoryEProducts => _categoryEProductsFetcher.stream;

  fetchAllCategoryEProducts(String? catId,String? subCatID) async {
    CategoryEProductModel? categoryEProductsModel =
    await _categoryEProductsRepository.fetchCategoryEProducts(catId,subCatID,page);
    _categoryEProductsFetcher.sink.add(categoryEProductsModel!);
  }

  fetchPagingProduct (String? catId,String? subCatID) async {
    page++;
    CategoryEProductModel? categoryEProductsModel = await _categoryEProductsRepository.fetchCategoryEProducts(catId,subCatID,page);
    _categoryEProductsFetcher.sink.add(categoryEProductsModel!);
  }

  dispose() {
    _categoryEProductsFetcher.close();
  }
}

final categoryEProductsBloc = CategoryEProductsBloc();