import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart';
import 'package:driver/modules/authentication/controllers/forgot_password/forgot_password_cubit.dart';
import 'package:driver/utils/my_theme.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'core/data/datasources/local_data_source.dart';
import 'core/data/datasources/remote_data_source.dart';
import 'core/router_name.dart';
import 'modules/animated_splash/controller/app_setting_cubit.dart';
import 'modules/animated_splash/repository/app_setting_repository.dart';
import 'modules/authentication/controllers/login/login_bloc.dart';
import 'modules/authentication/controllers/sign_up/sign_up_bloc.dart';
import 'modules/authentication/repository/auth_repository.dart';
import 'modules/profile/controller/change_password/change_password_cubit.dart';
import 'modules/profile/repository/profile_repository.dart';
import 'modules/setting/controllers/about_us_cubit/about_us_cubit.dart';
import 'modules/setting/controllers/acc_deletion/acc_deletion_bloc.dart';
import 'modules/setting/controllers/contact_us_cubit/contact_us_cubit.dart';
import 'modules/setting/controllers/contact_us_form_bloc/contact_us_form_bloc.dart';
import 'modules/setting/controllers/faq_cubit/faq_cubit.dart';
import 'modules/setting/controllers/privacy_and_term_condition_cubit/privacy_and_term_condition_cubit.dart';
import 'modules/setting/controllers/repository/setting_repository.dart';

late final SharedPreferences _sharedPreferences;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  _sharedPreferences = await SharedPreferences.getInstance();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiRepositoryProvider(
      providers: [
        ///network client
        RepositoryProvider<Client>(
          create: (context) => Client(),
        ),
        RepositoryProvider<SharedPreferences>(
          create: (context) => _sharedPreferences,
        ),

        ///data source repository
        RepositoryProvider<RemoteDataSource>(
          create: (context) => RemoteDataSourceImpl(client: context.read()),
        ),
        RepositoryProvider<LocalDataSource>(
          create: (context) =>
              LocalDataSourceImpl(sharedPreferences: context.read()),
        ),

        ///Repository
        RepositoryProvider<AuthRepository>(
          create: (context) => AuthRepositoryImp(
            remoteDataSource: context.read(),
            localDataSource: context.read(),
          ),
        ),
        RepositoryProvider<ProfileRepository>(
          create: (context) => ProfileRepositoryImp(
            remoteDataSource: context.read(),
            localDataSource: context.read(),
          ),
        ),
        RepositoryProvider<SettingRepository>(
          create: (context) =>
              SettingRepositoryImp(remoteDataSource: context.read()),
        ),

        RepositoryProvider<AppSettingRepository>(
          create: (context) => AppSettingRepositoryImp(
            remoteDataSource: context.read(),
            localDataSource: context.read(),
          ),
        ),
      ],
      child: MultiBlocProvider(
        providers: [
          BlocProvider<LoginBloc>(
            create: (BuildContext context) => LoginBloc(
              profileRepository: context.read(),
              authRepository: context.read(),
            ),
          ),
          BlocProvider<ForgotPasswordCubit>(
            create: (BuildContext context) => ForgotPasswordCubit(
              context.read(),
            ),
          ),
          BlocProvider<AppSettingCubit>(
            create: (BuildContext context) => AppSettingCubit(context.read()),
          ),
          BlocProvider<AccDeletionBloc>(
            create: (BuildContext context) =>
                AccDeletionBloc(
                    settingRepository: context.read(),
                    loginBloc: context.read()
                ),
          ),
          BlocProvider<SignUpBloc>(
            create: (BuildContext context) => SignUpBloc(context.read()),
          ),
          BlocProvider<ChangePasswordCubit>(
            create: (BuildContext context) => ChangePasswordCubit(
              loginBloc: context.read(),
              profileRepository: context.read(),
            ),
          ),


          BlocProvider<AboutUsCubit>(
            create: (BuildContext context) => AboutUsCubit(context.read()),
          ),
          BlocProvider<FaqCubit>(
            create: (BuildContext context) => FaqCubit(context.read()),
          ),
          BlocProvider<PrivacyAndTermConditionCubit>(
            create: (BuildContext context) =>
                PrivacyAndTermConditionCubit(context.read()),
          ),
          BlocProvider<ContactUsCubit>(
            create: (BuildContext context) => ContactUsCubit(context.read()),
          ),
          BlocProvider<ContactUsCubit>(
            create: (BuildContext context) => ContactUsCubit(context.read()),
          ),
          BlocProvider<ContactUsFormBloc>(
            create: (BuildContext context) =>
                ContactUsFormBloc(context.read()),
          ),

        ],
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          // title: Kstrings.appName,
          theme: MyTheme.theme,
          onGenerateRoute: RouteNames.generateRoute,
          initialRoute: RouteNames.animatedSplashScreen,
          onUnknownRoute: (RouteSettings settings) {
            return MaterialPageRoute(
              builder: (_) => Scaffold(
                body: Center(
                  child: Text('No route defined for ${settings.name}'),
                ),
              ),
            );
          },
          builder: (context, child) {
            return MediaQuery(
              data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
              child: child!,
            );
          },
        )
      ),
    );
  }
}