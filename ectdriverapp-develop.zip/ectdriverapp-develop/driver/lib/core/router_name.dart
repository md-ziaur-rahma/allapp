import 'package:driver/modules/add_voucher/add_voucher_screen.dart';
import 'package:driver/modules/booking_details/booking_details_screen.dart';
import 'package:flutter/material.dart';
import 'package:driver/modules/dashboard/dashboard_screen.dart';
import 'package:driver/modules/main/main_screen.dart';
import 'package:driver/modules/profile/change_password_screen.dart';
import 'package:driver/modules/profile/edti_profile_screen.dart';
import 'package:driver/modules/profile/public_profile.dart';
import 'package:driver/modules/setting/account_deletion_screen.dart';

import '../modules/animated_splash/animated_splash_screen.dart';
import '../modules/authentication/authentication_screen.dart';
import '../modules/authentication/forgot_screen.dart';
import '../modules/authentication/product_details/product_details_screen.dart';
import '../modules/home/home_screen.dart';
import '../modules/onboarding/onboarding_screen.dart';
import '../modules/setting/about_us_screen.dart';
import '../modules/setting/add_address_screen.dart';
import '../modules/setting/add_new_payment_card_screen.dart';
import '../modules/setting/contact_us_screen.dart';
import '../modules/setting/faq_screen.dart';
import '../modules/setting/privacy_policy_screen.dart';
import '../modules/setting/terms_condition_screen.dart';

class RouteNames {
  static const String onBoardingScreen = '/onBoardingScreen';
  static const String animatedSplashScreen = '/';
  static const String mainPage = '/mainPage';

  static const String authenticationScreen = '/authenticationScreen';
  static const String accDeletionScreen = '/accDeletionScreen';
  static const String forgotScreen = '/forgotScreen';
  static const String verificationCodeScreen = '/verificationCodeScreen';
  static const String setPasswordScreen = '/setPasswordScreen';

  static const String allCategoryListScreen = '/allCategoryListScreen';
  static const String locationSelection = '/locationSelection';
  static const String categorySelection = '/categorySelection';

  static const String postAd = '/postAd';
  static const String adDetails = '/adDetails';
  static const String bookingDetailsScreen = '/bookingDetailsScreen';
  static const String addVoucherScreen = '/addVoucherScreen';

  static const String notificationScreen = '/notificationScreen';
  static const String messageScreen = '/messageScreen';
  static const String singleCategoryProductScreen = '/singleCategoryProductScreen';

  static const String blog = '/blog';
  static const String termsConditionScreen = '/termsConditionScreen';
  static const String privacyPolicyScreen = '/privacyPolicyScreen';
  static const String faqScreen = '/faqScreen';
  static const String aboutUsScreen = '/aboutUsScreen';
  static const String contactUsScreen = '/contactUsScreen';

  static const String dashboardScreen = '/dashboardScreen';
  static const String pricePlaningScreen = '/pricePlaningScreen';
  static const String publicProfile = '/publicProfile';
  static const String profileEditScreen = '/profileEditScreen';
  static const String chatScreen = '/chatScreen';
  static const String chatDetails = '/chatDetails';
  static const String addAddressScreen = '/addAddressScreen';
  static const String cartScreen = '/cartScreen';
  static const String checkoutScreen = '/checkoutScreen';
  static const String productDetailsScreen = '/productDetailsScreen';
  static const String addressScreen = '/addressScreen';
  static const String productSearchScreen = '/productSearchScreen';
  static const String changePasswordScreen = '/changePasswordScreen';
  static const String profileContactIcon =
      "assets/icons/profile_contact_icon.svg";

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case RouteNames.onBoardingScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const OnBoardingScreen());
      // case RouteNames.changePasswordScreen:
      //   return MaterialPageRoute(
      //       settings: settings, builder: (_) => const ChangePasswordScreen());
      case RouteNames.accDeletionScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const AccountDeletionScreen());

      case RouteNames.mainPage:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const MainScreen());
      case RouteNames.animatedSplashScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const AnimatedSplashScreen());
      case RouteNames.changePasswordScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const ChangePasswordScreen());
      case RouteNames.authenticationScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const AuthenticationScreen());
      case RouteNames.forgotScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const ForgotScreen());

        case RouteNames.bookingDetailsScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const BookingDetailsScreen());

        case RouteNames.addVoucherScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const AddVoucherScreen());


        case RouteNames.termsConditionScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const TermsConditionScreen());
      case RouteNames.privacyPolicyScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const PrivacyPolicyScreen());
      case RouteNames.dashboardScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const DashboardScreen());
      case RouteNames.publicProfile:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const PublicProfile());
      case RouteNames.profileEditScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const EditProfileScreen());
      case RouteNames.faqScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const FaqScreen());
      case RouteNames.aboutUsScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const AboutUsScreen());
      case RouteNames.contactUsScreen:
        return MaterialPageRoute(
            settings: settings, builder: (_) => const ContactUsScreen());
      case RouteNames.addAddressScreen:
        final type = settings.arguments as String;
        return MaterialPageRoute(
            settings: settings, builder: (_) => AddAddressScreen(type: type));
      case RouteNames.productDetailsScreen:
        final slug = settings.arguments as String;
        return MaterialPageRoute(
            settings: settings,
            builder: (_) => ProductDetailsScreen(slug: slug));

      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: Text('No route defined for ${settings.name}'),
            ),
          ),
        );
    }
  }
}
