import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:driver/modules/dashboard/model/dashboard_card_model.dart';
import 'package:driver/modules/home/model/product_model.dart';
import 'package:driver/modules/home/model/slider_model.dart';
import 'package:driver/modules/profile/model/social_name_model.dart';

final sliderList = [
  const SliderModel(
      id: 1,
      title: "",
      description: "",
      image: "uploads/custom-images/slider-2022-11-13-10-50-32-4131.jpg",
      link: "",
      status: 1,
      serial: 1,
      createdAt: "",
      updatedAt: ""
  ),
  const SliderModel(
      id: 2,
      title: "",
      description: "",
      image: "uploads/custom-images/slider-2022-11-13-10-54-28-1362.jpg",
      link: "",
      status: 1,
      serial: 1,
      createdAt: "",
      updatedAt: ""
  ),
  const SliderModel(
      id: 3,
      title: "",
      description: "",
      image: "uploads/custom-images/slider-2022-11-13-10-54-52-4479.jpg",
      link: "",
      status: 1,
      serial: 1,
      createdAt: "",
      updatedAt: ""
  ),
  const SliderModel(
      id: 4,
      title: "",
      description: "",
      image: "uploads/custom-images/slider-2022-11-13-10-55-11-3042.jpg",
      link: "",
      status: 1,
      serial: 1,
      createdAt: "",
      updatedAt: ""
  ),
  const SliderModel(
      id: 5,
      title: "",
      description: "",
      image: "uploads/custom-images/slider-2022-11-13-10-50-32-4131.jpg",
      link: "",
      status: 1,
      serial: 1,
      createdAt: "",
      updatedAt: ""
  ),
];

final imageList = [
  const SliderModel(
      id: 1,
      title: "",
      description: "",
      image: "https://adlisting.templatecookie.com/dummy/product/vehicles/car/Acura.jpg",
      link: "",
      status: 1,
      serial: 1,
      createdAt: "",
      updatedAt: ""
  ),
  const SliderModel(
      id: 2,
      title: "",
      description: "",
      image: "https://adlisting.templatecookie.com/dummy/product/vehicles/car/Equinox.jpg",
      link: "",
      status: 1,
      serial: 1,
      createdAt: "",
      updatedAt: ""
  ),
  const SliderModel(
      id: 3,
      title: "",
      description: "",
      image: "https://adlisting.templatecookie.com/dummy/product/vehicles/car/Dodge.jpg",
      link: "",
      status: 1,
      serial: 1,
      createdAt: "",
      updatedAt: ""
  ),
  const SliderModel(
      id: 4,
      title: "",
      description: "",
      image: "https://adlisting.templatecookie.com/dummy/product/vehicles/car/Roadster.jpg",
      link: "",
      status: 1,
      serial: 1,
      createdAt: "",
      updatedAt: ""
  ),
];

final products = [
  const ProductModel(
      id: 1,
      title: "Samsung Galaxy A04s",
      category: "Mobile",
      image: "https://www.mobiledokan.com/wp-content/uploads/2022/03/Samsung-Galaxy-A03.jpg",
      model: "Samsung",
      authenticity: 'New',
      condition: 'New',
      negotiable: "Yes",
      location: "Uttara,Dhaka",
      price: 22499.0,
  ),
  const ProductModel(
      id: 1,
      title: "Samsung Galaxy A32s",
      category: "Mobile",
      image: "https://www.mobiledokan.com/wp-content/uploads/2022/10/Samsung-Galaxy-A04s.jpg",
      model: "Samsung",
      authenticity: 'New',
      condition: 'New',
      negotiable: "Yes",
      location: "Uttara,Dhaka",
      price: 22499.0,
  ),
  const ProductModel(
    id: 1,
    title: "Samsung Galaxy F13",
    category: "Mobile",
    image: "https://www.mobiledokan.com/wp-content/uploads/2022/08/Samsung-Galaxy-F13.jpg",
    model: "Samsung",
    authenticity: 'New',
    condition: 'New',
    negotiable: "Yes",
    location: "Uttara,Dhaka",
    price: 22499.0,
  ),
  const ProductModel(
    id: 1,
    title: "Samsung Galaxy A23",
    category: "Mobile",
    image: "https://www.mobiledokan.com/wp-content/uploads/2022/04/Samsung-Galaxy-A23.jpg",
    model: "Samsung",
    authenticity: 'New',
    condition: 'New',
    negotiable: "Yes",
    location: "Uttara,Dhaka",
    price: 33499.0,
  ),
  const ProductModel(
    id: 1,
    title: "Samsung Galaxy A72",
    category: "Mobile",
    image: "https://www.mobiledokan.com/wp-content/uploads/2021/03/Samsung-Galaxy-A72-image.jpg",
    model: "Samsung",
    authenticity: 'New',
    condition: 'New',
    negotiable: "Yes",
    location: "Uttara,Dhaka",
    price: 54499.0,
  ),
  const ProductModel(
    id: 1,
    title: "Apple I-Phone 14 Pro Max",
    category: "Mobile",
    image: "https://www.mobiledokan.com/wp-content/uploads/2022/09/Apple-iPhone-14-Pro-Max.jpg",
    model: "Apple",
    authenticity: 'New',
    condition: 'New',
    negotiable: "Yes",
    location: "Banani,Dhaka",
    price: 122499.0,
  ),
  const ProductModel(
    id: 1,
    title: "Apple I-Phone 13 Pro Max",
    category: "Mobile",
    image: "https://www.mobiledokan.com/wp-content/uploads/2021/10/Apple-iPhone-13-Pro-Max-image.jpg",
    model: "Apple",
    authenticity: 'New',
    condition: 'New',
    negotiable: "Yes",
    location: "Banani,Dhaka",
    price: 122499.0,
  ),
  const ProductModel(
    id: 1,
    title: "Apple I-Phone 11 Pro Max",
    category: "Mobile",
    image: "https://www.mobiledokan.com/wp-content/uploads/2019/09/Apple-iPhone-11-Pro-Max.jpg",
    model: "Apple",
    authenticity: 'New',
    condition: 'New',
    negotiable: "Yes",
    location: "Banani,Dhaka",
    price: 122499.0,
  ),
  const ProductModel(
    id: 1,
    title: "Apple I-Phone 14 Pro Max",
    category: "Mobile",
    image: "https://www.mobiledokan.com/wp-content/uploads/2022/09/Apple-iPhone-14-Pro-Max.jpg",
    model: "Apple",
    authenticity: 'New',
    condition: 'New',
    negotiable: "Yes",
    location: "Banani,Dhaka",
    price: 122499.0,
  ),
  const ProductModel(
    id: 1,
    title: "Apple I-Phone 13 Pro Max",
    category: "Mobile",
    image: "https://www.mobiledokan.com/wp-content/uploads/2021/10/Apple-iPhone-13-Pro-Max-image.jpg",
    model: "Apple",
    authenticity: 'New',
    condition: 'New',
    negotiable: "Yes",
    location: "Banani,Dhaka",
    price: 122499.0,
  ),
  const ProductModel(
    id: 1,
    title: "Apple I-Phone 11 Pro Max",
    category: "Mobile",
    image: "https://www.mobiledokan.com/wp-content/uploads/2019/09/Apple-iPhone-11-Pro-Max.jpg",
    model: "Apple",
    authenticity: 'New',
    condition: 'New',
    negotiable: "Yes",
    location: "Banani,Dhaka",
    price: 122499.0,
  ),
];

final dashboardCardList = [
  const DashboardCardModel(id: 1, title: "Pending", value: 15, image: Icons.pending),
  // const DashboardCardModel(id: 2, title: "Favourite Ads", value: 7, image: Icons.favorite),
  const DashboardCardModel(id: 5, title: "Upcoming", value: 5, image: Icons.next_plan),
  const DashboardCardModel(id: 3, title: "Completed", value: 6, image: Icons.done_all),
  const DashboardCardModel(id: 4, title: "Cancelled", value: 10, image: Icons.close),
];

final plansBillingList = [
  const ProductModel(
    id: 1,
    title: "Basic",
    category: "Mobile",
    image: "assets/images/free.png",
    model: "Apple",
    authenticity: 'New',
    condition: 'New',
    negotiable: "Yes",
    location: "Banani,Dhaka",
    price: 0,
  ),
  const ProductModel(
    id: 1,
    title: "Premium",
    category: "Mobile",
    image: "assets/images/premium.png",
    model: "Apple",
    authenticity: 'New',
    condition: 'New',
    negotiable: "Yes",
    location: "Banani,Dhaka",
    price: 100.0,
  ),
  const ProductModel(
    id: 1,
    title: "Business",
    category: "Mobile",
    image: "assets/images/business.png",
    model: "Apple",
    authenticity: 'New',
    condition: 'New',
    negotiable: "Yes",
    location: "Banani,Dhaka",
    price: 500.0,
  ),
];


final socialNameList = [
  const SocialNameModel(
      id: 1,
      title: "Facebook",
      color: Colors.blue,
      image: FontAwesomeIcons.facebook
  ),
  const SocialNameModel(
      id: 2,
      title: "Twitter",
      color: Colors.blue,
      image: FontAwesomeIcons.twitter
  ),
  const SocialNameModel(
      id: 3,
      title: "Instagram",
      color: Color(0xff8a3ab9),
      image:FontAwesomeIcons.instagram,
  ),
  const SocialNameModel(
      id: 4,
      title: "Youtube",
      color: Colors.red,
      image: FontAwesomeIcons.youtube,
  ),
  const SocialNameModel(
      id: 5,
      title: "Linkedin",
      color: Colors.blue,
      image: FontAwesomeIcons.linkedin
  ),
  const SocialNameModel(
      id: 6,
      title: "Quora",
      color: Color(0xff800000),
      image: FontAwesomeIcons.quora
  ),
];