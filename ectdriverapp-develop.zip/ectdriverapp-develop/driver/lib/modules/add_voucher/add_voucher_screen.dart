import 'package:driver/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

class AddVoucherScreen extends StatefulWidget {
  const AddVoucherScreen({Key? key}) : super(key: key);

  @override
  State<AddVoucherScreen> createState() => _AddVoucherScreenState();
}

class _AddVoucherScreenState extends State<AddVoucherScreen> {

  bool isBuono = false;
  bool isCash = false;
  bool isFattura = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: redColor,
        title: const Text("Create Voucher"),
        leading: IconButton(
          onPressed: (){
            Navigator.of(context).pop();
          },
          icon: const Icon(Icons.arrow_back_sharp,color: iconThemeColor,),
        ),
      ),
      body: CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            sliver: SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.blueGrey.withOpacity(0.1),
                          blurRadius: 6,
                          offset: const Offset(1, 1))
                    ]),
                child: Form(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            flex: 3,
                            child: TextFormField(
                              textAlign: TextAlign.start,
                              controller: dateController,
                              validator: (String? value) {
                                if (value == "") {
                                  return 'Select Date';
                                } else {
                                  return null;
                                }
                              },
                              textInputAction: TextInputAction.next,
                              keyboardType: TextInputType.text,
                              readOnly: true,
                              maxLines: 1,
                              cursorColor: Colors.black87,
                              onSaved: (String? val) {
                                date = val;
                              },
                              onTap: (){
                                dateChooser(context);
                              },
                              decoration: const InputDecoration(
                                suffix: Icon(Icons.calendar_month,color: Colors.black45,size: 20,),
                                contentPadding: EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 16),
                                hintText: 'mm/dd/yyyy',
                              ),
                            ),
                          ),
                          const SizedBox(width: 8,),
                          Expanded(
                            flex: 2,
                            child: TextFormField(
                              textAlign: TextAlign.start,
                              controller: dateController,
                              validator: (String? value) {
                                if (value == "") {
                                  return 'Select Time';
                                } else {
                                  return null;
                                }
                              },
                              textInputAction: TextInputAction.next,
                              keyboardType: TextInputType.text,
                              readOnly: true,
                              maxLines: 1,
                              cursorColor: Colors.black87,
                              onSaved: (String? val) {
                                date = val;
                              },
                              onTap: (){
                                dateChooser(context);
                              },
                              decoration: const InputDecoration(
                                suffix: Icon(Icons.watch_later_outlined,color: Colors.black45,size: 20,),
                                contentPadding: EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 16),
                                hintText: 'hh:mm aa',
                              ),
                            ),
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      const Text("Departure From"),
                      TextFormField(
                        keyboardType: TextInputType.text,
                        decoration: const InputDecoration(
                          hintText: "Departure From",
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      const Text("Arrived In"),
                      TextFormField(
                        keyboardType: TextInputType.text,
                        decoration: const InputDecoration(
                          hintText: "Arrived In",
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      const Text("KM(Kilometer)"),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              keyboardType: TextInputType.number,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly,
                              ],
                              decoration: const InputDecoration(
                                hintText: "KM Start",
                              ),
                            ),
                          ),
                          const SizedBox(width: 10,),
                          Expanded(
                            child: TextFormField(
                              keyboardType: TextInputType.number,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly,
                              ],
                              decoration: const InputDecoration(
                                hintText: "KM Finished",
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      const Text("Customer Name"),
                      TextFormField(
                        keyboardType: TextInputType.text,
                        decoration: const InputDecoration(
                          hintText: "Customer Name",
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      const Text("Pax No"),
                      TextFormField(
                        keyboardType: TextInputType.text,
                        decoration: const InputDecoration(
                          hintText: "Pax No",
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                        children: const [
                          Expanded(
                            child: Text("Flight/Cruise")
                          ),
                          SizedBox(width: 10,),
                          Expanded(
                            child: Text("Stop")
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              keyboardType: TextInputType.text,
                              decoration: const InputDecoration(
                                hintText: "Flight/Cruise",
                              ),
                            ),
                          ),
                          const SizedBox(width: 10,),
                          Expanded(
                            child: DropdownButtonFormField<int>(
                              decoration: const InputDecoration(
                                hintText: "Stop",
                              ),
                              onChanged: (value){

                              },
                              items: <int>[1,2,3,4,5,6,7,8,9,10].map<DropdownMenuItem<int>>((e) {
                                return DropdownMenuItem(
                                  value: e,
                                  child: Text("$e"),
                                );
                              }).toList(),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      const Text("€ Amount"),
                      TextFormField(
                        keyboardType: TextInputType.text,
                        decoration: const InputDecoration(
                          hintText: "€ Amount",
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: CheckboxListTile(
                              value: isBuono,
                              activeColor: redColor,
                              contentPadding: EdgeInsets.zero,
                              controlAffinity: ListTileControlAffinity.leading,
                              dense: true,
                              title: Text(
                                'Buono',
                                style: TextStyle(
                                    fontSize: 14,
                                    color: blackColor.withOpacity(0.5),
                                    fontWeight: FontWeight.w400),
                              ),
                              onChanged: (v) {
                                setState(() {
                                  isBuono = v!;
                                });
                              },
                            ),
                          ),
                          Expanded(
                            child: CheckboxListTile(
                              value: isCash,
                              activeColor: redColor,
                              contentPadding: EdgeInsets.zero,
                              controlAffinity: ListTileControlAffinity.leading,
                              dense: true,
                              title: Text(
                                'Cash',
                                style: TextStyle(
                                    fontSize: 14,
                                    color: blackColor.withOpacity(0.5),
                                    fontWeight: FontWeight.w400),
                              ),
                              onChanged: (v) {
                                setState(() {
                                  isCash = v!;
                                });
                              },
                            ),
                          ),
                          Expanded(
                            child: CheckboxListTile(
                              value: isFattura,
                              activeColor: redColor,
                              contentPadding: EdgeInsets.zero,
                              controlAffinity: ListTileControlAffinity.leading,
                              dense: true,
                              title: Text(
                                'Fattura',
                                style: TextStyle(
                                    fontSize: 14,
                                    color: blackColor.withOpacity(0.5),
                                    fontWeight: FontWeight.w400),
                              ),
                              onChanged: (v) {
                                setState(() {
                                  isFattura = v!;
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      const Text("Select Targa No"),
                    ],
                  ),
                ),
              ),
            ),
          )
        ],
      ),
      bottomNavigationBar: Container(
          height: 60,
          decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    blurRadius: 50,
                    offset: const Offset(0,10),
                    color: Colors.grey.withOpacity(0.5)
                )
              ]
          ),
          padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 8),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: redColor,shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6))),
            onPressed: (){},
            child: Text("Create Voucher"),
          )),
    );
  }

  //.......... Date Chooser ............
  var dateController = TextEditingController();
  final formatter = DateFormat('MM-dd-yyyy');
  DateTime dateTime = DateTime.now();
  String? date;
  dateChooser(BuildContext context) async {
    DateTime? newSelectedDate = await showDatePicker(
        context: context,
        initialDate: dateTime,
        firstDate: DateTime(1950),
        lastDate: DateTime(2040),
        currentDate: DateTime.now(),
        initialDatePickerMode: DatePickerMode.year,
        builder: (BuildContext context, Widget? child) {
          return Theme(
            data: ThemeData.dark().copyWith(
              colorScheme: const ColorScheme.light(
                primary: Color(0xFF31A3DD),
                onPrimary: Color(0xFFFFFFFF),
                surface: Color(0xFF31A3DD),
                onSurface: Color(0xFF000000),
              ),
              dialogBackgroundColor: Colors.white,
            ),
            child: child!,
          );
        });

    if (newSelectedDate != null) {
      dateTime = newSelectedDate;
      dateController
        ..text = formatter.format(dateTime)
        ..selection = TextSelection.fromPosition(TextPosition(
            offset: dateController.text.length,
            affinity: TextAffinity.upstream));
      setState((){
        date = dateController.text;
      });
    }
  }

}
