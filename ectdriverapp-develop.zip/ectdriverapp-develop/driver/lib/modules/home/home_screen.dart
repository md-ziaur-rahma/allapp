import 'package:driver/modules/home/component/home_appbar.dart';
import 'package:flutter/material.dart';
import 'package:driver/dummy_data/all_dudmmy_data.dart';

import '../../core/router_name.dart';
import 'component/list_product_container.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({Key? key}) : super(key: key);

  final scrollController = ScrollController();

  final scrollController2 = ScrollController();

  void toTop(){
    scrollController2.animateTo(0,
        duration: const Duration(milliseconds: 500), curve: Curves.easeInOut);
  }

  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
  GlobalKey<RefreshIndicatorState>();

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      controller: scrollController2,
      physics: const AlwaysScrollableScrollPhysics(),
      slivers: [
        HomeAppBar.appBar(context),
        ListProductContainer(
          productList: products,
          title: "Upcoming Booking",
          onPressed: (){},
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 65)),
      ],
    );
  }
}
