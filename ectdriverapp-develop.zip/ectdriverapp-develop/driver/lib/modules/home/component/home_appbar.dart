import 'package:driver/utils/k_images.dart';
import 'package:driver/widgets/custom_image.dart';
import 'package:flutter/material.dart';

import '../../../core/router_name.dart';
import '../../../utils/constants.dart';

class HomeAppBar{
  static appBar(context){
    return SliverAppBar(
      expandedHeight: 120,
      floating: true,
      snap: true,
      pinned: false,
      centerTitle: true,
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: const [
          CustomImage(path: Kimages.logoColor,height: 55,color: Colors.white,)
        ],
      ),
      // flexibleSpace: SizedBox.expand(),
      bottom: PreferredSize(
        preferredSize: const Size(double.infinity, 120),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 8),
          decoration: const BoxDecoration(
              color: redColor,
              borderRadius:
              BorderRadius.vertical(top: Radius.circular(10))),
          child: Row(
            children: [
              Expanded(
                child: Material(
                  color: Colors.white38,
                  borderRadius: BorderRadius.circular(16),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: (){},
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: const [
                          Icon(Icons.pending,size: 24,color: Colors.amber,),
                          Text("3",style: TextStyle(color: Colors.black87,fontSize: 16,fontWeight: FontWeight.w500),),
                          Text("Upcoming",style: TextStyle(color: Colors.black54,fontSize: 13,fontWeight: FontWeight.w400),),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10,),
              Expanded(
                child: Material(
                  color: Colors.white38,
                  borderRadius: BorderRadius.circular(16),
                  child: InkWell(
                    onTap: (){},
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          const Icon(Icons.check_box_outlined,size: 24,color: Colors.green,),
                          Text("16",style: TextStyle(color: Colors.black87,fontSize: 16,fontWeight: FontWeight.w500),),
                          Text("Completed",style: TextStyle(color: Colors.black54,fontSize: 13,fontWeight: FontWeight.w400),),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10,),
              Expanded(
                child: Material(
                  color: Colors.white38,
                  borderRadius: BorderRadius.circular(16),
                  child: InkWell(
                    onTap: (){},
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: const [
                          Icon(Icons.close_outlined,size: 24,color: Colors.red,),
                          Text("12",style: TextStyle(color: Colors.black87,fontSize: 16,fontWeight: FontWeight.w500),),
                          Text("Cancelled",style: TextStyle(color: Colors.black54,fontSize: 13,fontWeight: FontWeight.w400),),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}