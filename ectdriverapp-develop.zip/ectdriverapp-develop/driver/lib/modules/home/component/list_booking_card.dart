import 'package:driver/core/router_name.dart';
import 'package:driver/utils/k_images.dart';
import 'package:driver/widgets/custom_image.dart';
import 'package:flutter/material.dart';

class ListBookingCard extends StatefulWidget {
  const ListBookingCard({Key? key}) : super(key: key);

  @override
  State<ListBookingCard> createState() => _ListBookingCardState();
}

class _ListBookingCardState extends State<ListBookingCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        Navigator.pushNamed(context, RouteNames.bookingDetailsScreen);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.transparent),
            boxShadow: [
              BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  blurRadius: 6,
                  offset: const Offset(0,5)
              )
            ]
        ),
        child: Column(
          children: [
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  clipBehavior: Clip.antiAlias,
                  child: const CustomImage(path: Kimages.defaultUser,height: 50,width: 50,),
                ),
                const SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text("John Dao",style: TextStyle(color: Colors.black87,fontWeight: FontWeight.w500),maxLines: 1,),
                      Text("+8801860141942",style: TextStyle(color: Colors.black54,fontSize: 13,fontWeight: FontWeight.w400),),
                    ],
                  ),
                ),
                const SizedBox(
                  width: 8,
                ),
                const Text("€499.00",style: TextStyle(color: Colors.black87,fontSize: 13,fontWeight: FontWeight.w600),),
              ],
            ),
            const Divider(
              height: 30,
            ),
            SizedBox(
              height: 60,
              child: Row(
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.max,
                    children: const [
                      Expanded(flex: 2,child: Icon(Icons.star,color: Colors.blue,size: 16,)),
                      Expanded(child: Icon(Icons.circle,color: Colors.grey,size: 4,)),
                      Expanded(child: Icon(Icons.circle,color: Colors.grey,size: 4,)),
                      Expanded(child: Icon(Icons.circle,color: Colors.grey,size: 4,)),
                      Expanded(child: Icon(Icons.circle,color: Colors.grey,size: 4,)),
                      Expanded(flex: 2,child: Icon(Icons.star,color: Colors.grey,size: 16,)),
                    ],
                  ),
                  SizedBox(
                    width: 16,
                  ),
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Row(
                          children: const [
                            Expanded(
                              child: SizedBox(child: Text("Rd-17,Banani,Dhaka-1213",maxLines: 1,)),
                            ),
                            Text("9:45 PM",style: TextStyle(color: Colors.black45,fontSize: 12),),
                          ],
                        ),
                        const Spacer(),
                        Row(
                          children: const [
                            Expanded(
                              child: Text("Rd-45,Savar,Dhaka-1213",maxLines: 1,),
                            ),
                            Text("11:30 PM",style: TextStyle(color: Colors.black45,fontSize: 12),),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
