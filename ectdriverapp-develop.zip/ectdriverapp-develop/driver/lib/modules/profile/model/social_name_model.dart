import 'dart:convert';

import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class SocialNameModel extends Equatable {
  final int id;
  final String title;
  final Color color;
  final IconData image;
  const SocialNameModel({
    required this.id,
    required this.title,
    required this.color,
    required this.image,
  });

  SocialNameModel copyWith({
    int? id,
    String? title,
    Color? color,
    IconData? image,
  }) {
    return SocialNameModel(
      id: id ?? this.id,
      title: title ?? this.title,
      color: color ?? this.color,
      image: image ?? this.image,
    );
  }

  Map<String, dynamic> toMap() {
    final result = <String, dynamic>{};

    result.addAll({'id': id});
    result.addAll({'title': title});
    result.addAll({'color': color});
    result.addAll({'image': image});

    return result;
  }

  factory SocialNameModel.fromMap(Map<String, dynamic> map) {
    return SocialNameModel(
      id: map['id']?.toInt() ?? 0,
      title: map['title'] ?? '',
      color: map['color'] ?? '',
      image: map['image'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory SocialNameModel.fromJson(String source) =>
      SocialNameModel.fromMap(json.decode(source));

  @override
  String toString() {
    return 'SocialNameModel(id: $id, title: $title, color: $color, image: $image)';
  }

  @override
  List<Object> get props {
    return [
      id,
      title,
      color,
      image,
    ];
  }
}
