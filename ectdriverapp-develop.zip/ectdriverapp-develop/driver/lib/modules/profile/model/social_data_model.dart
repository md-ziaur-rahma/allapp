import 'dart:convert';

import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:driver/modules/profile/model/social_name_model.dart';

class SocialDataModel extends Equatable {
  final TextEditingController controller;
  final SocialNameModel socialNameModel;
  const SocialDataModel({
    required this.controller,
    required this.socialNameModel,
  });

  SocialDataModel copyWith({
    TextEditingController? controller,
    SocialNameModel? socialNameModel,
  }) {
    return SocialDataModel(
      controller: controller ?? this.controller,
      socialNameModel: socialNameModel ?? this.socialNameModel,
    );
  }

  Map<String, dynamic> toMap() {
    final result = <String, dynamic>{};

    result.addAll({'controller': controller});
    result.addAll({'socialNameModel': socialNameModel});

    return result;
  }

  factory SocialDataModel.fromMap(Map<String, dynamic> map) {
    return SocialDataModel(
      controller: map['controller'],
      socialNameModel: SocialNameModel.fromMap(map['socialNameModel']),
    );
  }

  String toJson() => json.encode(toMap());

  factory SocialDataModel.fromJson(String source) =>
      SocialDataModel.fromMap(json.decode(source));

  @override
  String toString() {
    return 'SocialNameModel(controller: $controller, socialNameModel: $socialNameModel)';
  }

  @override
  List<Object> get props {
    return [
      controller,
      socialNameModel,
    ];
  }
}
