import 'package:flutter/material.dart';
import 'package:driver/modules/profile/component/edit/change_password.dart';
import 'package:driver/modules/profile/component/edit/social_link.dart';

import '../../utils/constants.dart';
import 'component/edit/basic_info_edit.dart';
import 'component/edit/delete_account.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({Key? key}) : super(key: key);

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Account Setting"),
        leading: IconButton(
          onPressed: (){
            Navigator.of(context).pop();
          },
          icon: const Icon(Icons.arrow_back_sharp,color: iconThemeColor,),
        ),
      ),
      body: const CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          SliverPadding(
            padding: EdgeInsets.symmetric(horizontal: 16,vertical: 16),
            sliver: SliverToBoxAdapter(
              child: BasicInfoEdit(),
            ),
          ),
          SliverPadding(
            padding: EdgeInsets.symmetric(horizontal: 16,vertical: 0),
            sliver: SliverToBoxAdapter(
              child: ChangePassEdit(),
            ),
          ),
          SliverPadding(
            padding: EdgeInsets.symmetric(horizontal: 16,vertical: 16),
            sliver: SliverToBoxAdapter(
              child: DeleteAccount(),
            ),
          ),
        ],
      ),
    );
  }
}
