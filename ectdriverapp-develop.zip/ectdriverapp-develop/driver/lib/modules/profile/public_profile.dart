import 'package:flutter/material.dart';
import 'package:driver/modules/home/model/product_model.dart';
import 'package:driver/utils/constants.dart';
import 'package:driver/widgets/custom_image.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../../core/router_name.dart';
import '../../dummy_data/all_dudmmy_data.dart';
import '../../utils/k_images.dart';

class PublicProfile extends StatefulWidget {
  const PublicProfile({Key? key}) : super(key: key);

  @override
  State<PublicProfile> createState() => _PublicProfileState();
}

class _PublicProfileState extends State<PublicProfile> {

  int isAds = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Profile"),
        leading: IconButton(
          onPressed: (){
            Navigator.of(context).pop();
          },
          icon: const Icon(Icons.arrow_back_sharp,color: iconThemeColor,),
        ),
      ),
      body: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            sliver: SliverToBoxAdapter(
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.blueGrey.withOpacity(0.1),
                          blurRadius: 6,
                          offset: const Offset(1, 1))
                    ]),
                child: Column(
                  children: [
                    const CircleAvatar(
                      radius: 80,
                      backgroundColor: ashColor,
                      backgroundImage: AssetImage(Kimages.defaultUser),
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    const Text(
                      "Customer Name",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w500),
                    ),
                    const Divider(
                      height: 50,
                    ),
                    const Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          "Contact Information",
                          style: TextStyle(
                              color: Colors.black54,
                              fontSize: 14,
                              fontWeight: FontWeight.w400),
                        )
                    ),
                    Row(
                      children: const [
                        Icon(Icons.call,color: Colors.green,size: 20,),
                        SizedBox(
                          width: 8,
                        ),
                        Text(
                          "01860141942",
                          style: TextStyle(
                              color: Colors.black87,
                              fontSize: 16,
                              fontWeight: FontWeight.w400),
                        )
                      ],
                    ),
                    Row(
                      children: [
                        const Icon(Icons.mail_outline,color: Colors.green,size: 20,),
                        const SizedBox(
                          width: 8,
                        ),
                        const Text(
                          "ziariyad018@gmail.com",
                          style: TextStyle(
                              color: Colors.black87,
                              fontSize: 16,
                              fontWeight: FontWeight.w400),
                        ),
                        const Spacer(),
                        Material(
                          color: Colors.white.withAlpha(910),
                          elevation: 3,
                          shadowColor: const Color(0xFFFFFFFF),
                          borderOnForeground: true,
                          shape: const CircleBorder(),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(50),
                            onTap: (){
                              Navigator.pushNamed(context, RouteNames.profileEditScreen);
                            },
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              child: const Icon(Icons.edit,color: redColor,size: 20,),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
            sliver: SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.blueGrey.withOpacity(0.1),
                          blurRadius: 6,
                          offset: const Offset(1, 1))
                    ]),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: ashColor)
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text("8",style: TextStyle(color: Colors.black,fontSize: 16,fontWeight: FontWeight.w600),),
                                Text("Completed Trips",style: TextStyle(color: Colors.black54,fontSize: 14,fontWeight: FontWeight.w400),),
                              ],
                            ),
                          ),
                          const SizedBox(
                            width: 16,
                          ),
                          Container(
                            height: 60,
                            width: 60,
                            padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
                            decoration: BoxDecoration(
                              // color: Colors.red.withOpacity(0.1),
                              border: Border.all(color: redColor),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Center(
                              child: FaIcon(FontAwesomeIcons.car,size: 30,color: redColor,)
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
