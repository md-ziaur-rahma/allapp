import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../core/router_name.dart';
import '../../utils/constants.dart';
import '../../utils/k_images.dart';
import '../../widgets/custom_image.dart';
import '../authentication/controllers/login/login_bloc.dart';
import '../main/main_controller.dart';

class ProfileScreen extends StatelessWidget {
  ProfileScreen({Key? key}) : super(key: key);

  final scrollController = ScrollController();

  void toTop(){
    scrollController.animateTo(0,
        duration: const Duration(milliseconds: 500), curve: Curves.easeInOut);
  }

  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
  GlobalKey<RefreshIndicatorState>();
  final mainController = MainController();
  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      controller: scrollController,
      physics: const AlwaysScrollableScrollPhysics(),
      slivers: [
        SliverAppBar(
          title: const Text("My Account"),
          pinned: true,
          leading: IconButton(
            onPressed: (){
              mainController.naveListener.sink.add(0);
            },
            icon: const Icon(Icons.arrow_back_sharp,color: iconThemeColor,),
          ),
        ),
        _buildProfileOptions(context),
        const SliverToBoxAdapter(child: SizedBox(height: 65)),
      ],
    );
  }

  SliverPadding _buildProfileOptions(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
      sliver: SliverList(
        delegate: SliverChildListDelegate(
          [
            ListTile(
              minLeadingWidth: 0,
              onTap: () {
                Navigator.pushNamed(context, RouteNames.dashboardScreen);
              },
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.dashboard,size: 27,color: redColor,),
              title: const Text('Overview', style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              minLeadingWidth: 0,
              onTap: () {
                Navigator.pushNamed(context, RouteNames.publicProfile);
              },
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.person_sharp,size: 27,color: redColor,),
              title: const Text('Profile', style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              minLeadingWidth: 0,
              onTap: () {
                Navigator.pushNamed(context, RouteNames.addVoucherScreen);
              },
              contentPadding: EdgeInsets.zero,
              leading: const CustomImage(path: Kimages.profilePostAd,height: 27,width: 27,color: redColor,),
              title: const Text('Create Voucher', style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.changePasswordScreen);
              },
              minLeadingWidth: 0,
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.password_outlined, color: redColor),
              title:
              const Text('Change password', style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.termsConditionScreen);
              },
              minLeadingWidth: 0,
              contentPadding: EdgeInsets.zero,
              leading:
              const CustomImage(path: Kimages.profileTermsConditionIcon,color: redColor,),
              title: const Text('Terms & Condition',
                  style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.privacyPolicyScreen);
              },
              minLeadingWidth: 0,
              contentPadding: EdgeInsets.zero,
              leading: const CustomImage(path: Kimages.profilePrivacyIcon,color: redColor,),
              title:
              const Text('Privacy Policy', style: TextStyle(fontSize: 16)),
            ),
            // ListTile(
            //   onTap: () {
            //     Navigator.pushNamed(context, RouteNames.faqScreen);
            //   },
            //   minLeadingWidth: 0,
            //   contentPadding: EdgeInsets.zero,
            //   leading: const CustomImage(path: Kimages.profileFaqIcon,color: redColor,),
            //   title: const Text('FAQ', style: TextStyle(fontSize: 16)),
            // ),
            // ListTile(
            //   onTap: () {
            //     Navigator.pushNamed(context, RouteNames.aboutUsScreen);
            //   },
            //   minLeadingWidth: 0,
            //   contentPadding: EdgeInsets.zero,
            //   leading: const CustomImage(path: Kimages.profileAboutUsIcon,color: redColor,),
            //   title: const Text('About Us', style: TextStyle(fontSize: 16)),
            // ),
            // ListTile(
            //   onTap: () {
            //     Navigator.pushNamed(context, RouteNames.contactUsScreen);
            //   },
            //   minLeadingWidth: 0,
            //   contentPadding: EdgeInsets.zero,
            //   leading: const CustomImage(path: Kimages.profileContactIcon),
            //   title: const Text('Contact Us', style: TextStyle(fontSize: 16)),
            // ),
            ListTile(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.accDeletionScreen);
              },
              minLeadingWidth: 0,
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.person_remove_sharp,color: redColor,),
              title: const Text('Account Deletion', style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.profileEditScreen);
              },
              minLeadingWidth: 0,
              contentPadding: EdgeInsets.zero,
              leading: const CustomImage(path: Kimages.profileSettingIcon,color: redColor,),
              title: const Text('Settings', style: TextStyle(fontSize: 16)),
            ),
            BlocBuilder<LoginBloc, LoginModelState>(builder: (context, state) {
              if (state.state is LoginStateLogOutLoading) {
                const CircularProgressIndicator();
              }
              return ListTile(
                minLeadingWidth: 0,
                contentPadding: EdgeInsets.zero,
                leading: const CustomImage(path: Kimages.profileLogOutIcon,color: redColor,),
                title: const Text('Sign Out', style: TextStyle(fontSize: 16)),
                onTap: () {
                  // context.read<LoginBloc>().add(const LoginEventLogout());
                },
              );
            }),
          ],
        ),
      ),
    );
  }

}
