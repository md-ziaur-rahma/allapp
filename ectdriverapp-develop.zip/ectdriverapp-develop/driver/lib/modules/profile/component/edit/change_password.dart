import 'package:flutter/material.dart';
import 'package:driver/utils/constants.dart';
import 'package:driver/utils/k_images.dart';

class ChangePassEdit extends StatefulWidget {
  const ChangePassEdit({Key? key}) : super(key: key);

  @override
  State<ChangePassEdit> createState() => _ChangePassEditState();
}

class _ChangePassEditState extends State<ChangePassEdit> {
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.transparent),
            boxShadow: [
              BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  blurRadius: 6,
                  offset: const Offset(0,5)
              )
            ]
        ),
        child: Column(
          children: [
            const Align(alignment: Alignment.centerLeft,child: Padding(
              padding: EdgeInsets.only(bottom: 16.0),
              child: Text("Change Password",textAlign: TextAlign.left,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500),),
            )),
            const SizedBox(
              width: double.infinity,
              height: 16,
            ),
            const Align(alignment: Alignment.centerLeft,child: Padding(
              padding: EdgeInsets.symmetric(vertical: 8.0),
              child: Text("Current Password",textAlign: TextAlign.left,),
            )),
            TextFormField(
              decoration: const InputDecoration(
                hintText: "Current password",
              ),
            ),
            const Align(alignment: Alignment.centerLeft,child: Padding(
              padding: EdgeInsets.symmetric(vertical: 8.0),
              child: Text("New password *",textAlign: TextAlign.left,),
            )),
            TextFormField(
              decoration: const InputDecoration(
                hintText: "New password",
              ),
            ),
            const Align(alignment: Alignment.centerLeft,child: Padding(
              padding: EdgeInsets.symmetric(vertical: 8.0),
              child: Text("Confirm password *",textAlign: TextAlign.left,),
            )),
            TextFormField(
              decoration: const InputDecoration(
                hintText: "Confirm password",
              ),
            ),
            SizedBox(
              height: 24,
            ),
            SizedBox(
              height: 48,
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(foregroundColor: redColor,shadowColor: ashColor,side: const BorderSide(color: redColor,strokeAlign: StrokeAlign.inside),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
                onPressed: (){},
                child: const Text("Save Changes"),
              ),
            )
          ],
        )
    );
  }
}
