import 'package:flutter/material.dart';
import 'package:driver/utils/constants.dart';
import 'package:driver/utils/k_images.dart';

class BasicInfoEdit extends StatefulWidget {
  const BasicInfoEdit({Key? key}) : super(key: key);

  @override
  State<BasicInfoEdit> createState() => _BasicInfoEditState();
}

class _BasicInfoEditState extends State<BasicInfoEdit> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.transparent),
          boxShadow: [
            BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                blurRadius: 6,
                offset: const Offset(0,5)
            )
          ]
      ),
      child: Column(
        children: [
          const Align(alignment: Alignment.centerLeft,child: Padding(
            padding: EdgeInsets.only(bottom: 16.0),
            child: Text("Account Information",textAlign: TextAlign.left,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500),),
          )),
          const CircleAvatar(
            radius: 70,
            backgroundImage: AssetImage(Kimages.defaultUser,),
          ),
          const SizedBox(
            width: double.infinity,
            height: 16,
          ),
          const Align(alignment: Alignment.centerLeft,child: Padding(
            padding: EdgeInsets.symmetric(vertical: 8.0),
            child: Text("Full Name",textAlign: TextAlign.left,),
          )),
          TextFormField(
            decoration: const InputDecoration(
              hintText: "Enter Name",
            ),
          ),
          const Align(alignment: Alignment.centerLeft,child: Padding(
            padding: EdgeInsets.symmetric(vertical: 8.0),
            child: Text("Phone Number *",textAlign: TextAlign.left,),
          )),
          TextFormField(
            decoration: const InputDecoration(
              hintText: "Phone Number",
            ),
          ),
          const Align(alignment: Alignment.centerLeft,child: Padding(
            padding: EdgeInsets.symmetric(vertical: 8.0),
            child: Text("Email",textAlign: TextAlign.left,),
          )),
          TextFormField(
            decoration: const InputDecoration(
              hintText: "Email",
            ),
          ),
          const SizedBox(
            height: 24,
          ),
          SizedBox(
            height: 48,
            child: OutlinedButton(
              style: OutlinedButton.styleFrom(foregroundColor: redColor,shadowColor: ashColor,side: const BorderSide(width: 0.5,color: redColor,strokeAlign: StrokeAlign.inside),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
              onPressed: (){},
              child: const Text("Save Changes",style: TextStyle(color: redColor,fontWeight: FontWeight.w400),),
            ),
          )
        ],
      )
    );
  }
}