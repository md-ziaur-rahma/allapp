import 'package:flutter/material.dart';
import 'package:driver/dummy_data/all_dudmmy_data.dart';
import 'package:driver/modules/profile/model/social_data_model.dart';
import 'package:driver/modules/profile/model/social_name_model.dart';
import 'package:driver/utils/constants.dart';

import '../../../../core/animation/delayed_animation.dart';

class SocialLinkEdit extends StatefulWidget {
  const SocialLinkEdit({Key? key}) : super(key: key);

  @override
  State<SocialLinkEdit> createState() => _SocialLinkEditState();
}

class _SocialLinkEditState extends State<SocialLinkEdit> {

  List<SocialDataModel> socialDataList = [];

  SocialNameModel demoSocialNameModel = const SocialNameModel(
      id: 0,
      title: "",
      color: Colors.grey,
      image: Icons.error_outline_sharp
  );

  void addSocial(){
    socialDataList.add(SocialDataModel(controller: TextEditingController(), socialNameModel: demoSocialNameModel));
  }

  void removeSocial(index){
    socialDataList.removeAt(index);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    WidgetsBinding.instance
        .addPostFrameCallback((_) {
          setState(() {
            socialDataList.add(SocialDataModel(controller: TextEditingController(), socialNameModel: demoSocialNameModel));
          });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 16),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.transparent),
            boxShadow: [
              BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  blurRadius: 6,
                  offset: const Offset(0,5)
              )
            ]
        ),
        child: Column(
          children: [
            const Align(alignment: Alignment.centerLeft,child: Padding(
              padding: EdgeInsets.only(bottom: 16.0),
              child: Text("Social Media",textAlign: TextAlign.left,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500),),
            )),
            ...List.generate(socialDataList.length, (index) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 16.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DelayedAnimation(
                      delay: 100,
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            flex: 1,
                            child: SizedBox(
                              // height: 60,
                              child: Stack(
                                alignment: Alignment.topCenter,
                                clipBehavior: Clip.none,
                                children: [
                                  Container(
                                      padding: const EdgeInsets.only(left: 10,right: 10,top: 24,bottom: 10),
                                      // height: double.infinity,
                                      width: double.infinity,
                                      decoration: BoxDecoration(
                                          color: Colors.transparent,
                                          border: Border.all(color: ashTextColor,width: 1),
                                          borderRadius: BorderRadius.circular(10)
                                      ),
                                      child: Column(
                                        children: [
                                          DropdownButtonFormField<SocialNameModel>(
                                            decoration: const InputDecoration(
                                              hintText: "Select One"
                                            ),
                                              items: socialNameList.map<DropdownMenuItem<SocialNameModel>>((e) => DropdownMenuItem<SocialNameModel>(
                                                value: e,
                                                child: Text(e.title,style: const TextStyle(color: Colors.black87,fontSize: 14,fontWeight: FontWeight.w400),),
                                              )).toList(),
                                              onChanged: (socialModel){
                                              print("xxxxxxxxxxxxxxxxxxxxx");
                                              setState(() {
                                                // socialDataList[index].copyWith(socialNameModel: socialModel);
                                                socialDataList[index] = SocialDataModel(controller: TextEditingController(), socialNameModel: socialModel!);
                                              });
                                              print(socialDataList[index].socialNameModel.title);
                                              }
                                          ),
                                          TextFormField(
                                            controller: socialDataList[index].controller,
                                            maxLines: 1,
                                            decoration: const InputDecoration(
                                              hintText: "Enter link here..."
                                            ),
                                          )
                                        ],
                                      ),
                                  ),
                                  Positioned(
                                    top: -16,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 6,vertical: 6),
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                          color: const Color(0xFFF4F4F4),
                                          border: Border.all(color: ashTextColor,width: 1),
                                          // borderRadius: BorderRadius.circular(16)
                                      ),
                                      child: Icon(socialDataList[index].socialNameModel.image,color: socialDataList[index].socialNameModel.color,),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(
                            width: 3,
                          ),
                          Material(
                            color: index == socialDataList.length -1 ? redColor : ashTextColor,
                            shape: const CircleBorder(),
                            child: InkWell(
                              onTap: (){
                                if (index == (socialDataList.length-1)) {
                                  setState(() {
                                    addSocial();
                                  });

                                } else {
                                  setState(() {
                                    removeSocial(index);
                                  });
                                }
                              },
                              borderRadius: BorderRadius.circular(50),
                              child: Padding(
                                padding: const EdgeInsets.all(5),
                                child: index == socialDataList.length -1
                                    ? const Icon(Icons.add,size: 20,color: Colors.white,)
                                    : const Icon(Icons.close,size: 20,color: Colors.white,),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    const SizedBox(height: 16,)
                  ],
                ),
              );
            }),
          ]
        )
    );
  }
}
