import '../../../utils/k_images.dart';
import 'onbording_model.dart';

const onBoardingList = [
  OnBoardingModel(
    image: Kimages.onBoarding_1,
    subTitle: 'Welcome to',
    title: "ECT Drivers App",
    paragraph:
        'ECT drivers app designed for controlling bookings fro the drivers.',
  ),
  OnBoardingModel(
    image: Kimages.onBoarding_2,
    subTitle: 'Easy way to',
    title: "Operate Bookings",
    paragraph:
    'Drivers will able to add, edit, view & print their schedules and money receipts.',
  ),
  OnBoardingModel(
    image: Kimages.onBoarding_4,
    subTitle: 'Transaction Tracking',
    title: "History of transactions",
    paragraph: 'Drivers will able to see accepted,rejected bookings list.',
  ),
];
