import 'package:driver/utils/k_images.dart';
import 'package:driver/widgets/custom_image.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class VoucherCard extends StatefulWidget {
  const VoucherCard({Key? key, required this.isEdit}) : super(key: key);
  final bool isEdit;

  @override
  State<VoucherCard> createState() => _VoucherCardState();
}

class _VoucherCardState extends State<VoucherCard> {

  bool isTapDownload = false;
  bool isTapEdit = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.transparent),
          boxShadow: [
            BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                blurRadius: 6,
                offset: const Offset(0,5)
            )
          ]
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text("€499.00",style: TextStyle(color: Colors.black87,fontSize: 13,fontWeight: FontWeight.w600),),
                    Text("12/09/2022 05:45 PM",style: TextStyle(color: Colors.black54,fontWeight: FontWeight.w400),maxLines: 1,),
                  ],
                ),
              ),
              const SizedBox(
                width: 8,
              ),
              Visibility(
                visible: widget.isEdit,
                child: GestureDetector(
                  onTap: (){},
                  onTapDown: (_){
                    setState(() {
                      isTapEdit = true;
                    });
                  },
                  onTapUp: (_){
                    Future.delayed(const Duration(milliseconds: 100)).then((value) {
                      setState(() {
                        isTapEdit = false;
                      });
                    });
                  },
                  child: FaIcon(FontAwesomeIcons.penToSquare,color: isTapEdit ? Colors.black87 : Colors.blue,size: 20,),
                ),
              ),
              const SizedBox(
                width: 8,
              ),
              GestureDetector(
                onTap: (){},
                onTapDown: (_){
                  setState(() {
                    isTapDownload = true;
                  });
                },
                onTapUp: (_){
                  Future.delayed(const Duration(milliseconds: 100)).then((value) {
                    setState(() {
                      isTapDownload = false;
                    });
                  });
                },
                child: Icon(Icons.download,color: isTapDownload ? Colors.black87 : Colors.green,size: 24,),
              ),
            ],
          ),
          const Divider(
            height: 30,
          ),
          SizedBox(
            height: 60,
            child: Row(
              children: [
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: const [
                    Expanded(flex: 2,child: Icon(Icons.star,color: Colors.blue,size: 16,)),
                    Expanded(child: Icon(Icons.circle,color: Colors.grey,size: 4,)),
                    Expanded(child: Icon(Icons.circle,color: Colors.grey,size: 4,)),
                    Expanded(child: Icon(Icons.circle,color: Colors.grey,size: 4,)),
                    Expanded(child: Icon(Icons.circle,color: Colors.grey,size: 4,)),
                    Expanded(flex: 2,child: Icon(Icons.star,color: Colors.grey,size: 16,)),
                  ],
                ),
                SizedBox(
                  width: 16,
                ),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Row(
                        children: const [
                          Expanded(
                            child: SizedBox(child: Text("Rd-17,Banani,Dhaka-1213",maxLines: 1,)),
                          ),
                          Text("9:45 PM",style: TextStyle(color: Colors.black45,fontSize: 12),),
                        ],
                      ),
                      const Spacer(),
                      Row(
                        children: const [
                          Expanded(
                            child: Text("Rd-45,Savar,Dhaka-1213",maxLines: 1,),
                          ),
                          Text("11:30 PM",style: TextStyle(color: Colors.black45,fontSize: 12),),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
