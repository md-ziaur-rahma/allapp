import 'package:driver/dummy_data/all_dudmmy_data.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../utils/constants.dart';
import '../home/component/list_booking_card.dart';
import '../main/main_controller.dart';
import 'component/voucher_card.dart';

class MoneyReceiptScreen extends StatefulWidget {
  const MoneyReceiptScreen({Key? key}) : super(key: key);

  @override
  State<MoneyReceiptScreen> createState() => _MoneyReceiptScreenState();
}

class _MoneyReceiptScreenState extends State<MoneyReceiptScreen> {
  final mainController = MainController();
  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      scrollDirection: Axis.vertical,
      slivers: [
        SliverAppBar(
          pinned: true,
          title: const Text("MoneyReceipt List"),
          leading: IconButton(
            onPressed: (){
              mainController.naveListener.sink.add(0);
            },
            icon: const Icon(Icons.arrow_back_sharp,color: iconThemeColor,),
          ),
        ),
        SliverLayoutBuilder(
          builder: (context,constraints){
            if (products.isNotEmpty) {
              return SliverList(
                delegate: SliverChildBuilderDelegate((context, index) {
                  // return  ListProductCard(productModel: widget.productList[index]);
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8.0),
                    child: VoucherCard(isEdit: false,),
                  );
                },childCount: products.length),
              );
            } else {
              return SliverToBoxAdapter(
                child: SizedBox(
                  height: 150,
                  width: double.infinity,
                  child: Center(
                    child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: Colors.black54)
                        ),
                        child: const Text("Product Not Found",style: TextStyle(color: Colors.black54,fontSize: 16,fontWeight: FontWeight.w500),)),
                  ),
                ),
              );
            }
          },
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 65)),
      ],
    );
  }
}
