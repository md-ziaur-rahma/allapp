import 'package:driver/utils/k_strings.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../../utils/constants.dart';
import '../../utils/k_images.dart';
import '../../widgets/custom_image.dart';

class BookingDetailsScreen extends StatefulWidget {
  const BookingDetailsScreen({Key? key}) : super(key: key);

  @override
  State<BookingDetailsScreen> createState() => _BookingDetailsScreenState();
}

class _BookingDetailsScreenState extends State<BookingDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Vehicle Booking Log Details"),
        leading: IconButton(
          onPressed: (){
            Navigator.of(context).pop();
          },
          icon: const Icon(Icons.arrow_back_sharp,color: iconThemeColor,),
        ),
      ),
      body: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            sliver: SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.blueGrey.withOpacity(0.1),
                          blurRadius: 6,
                          offset: const Offset(1, 1))
                    ]),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Row(
                            children: const [
                              Icon(Icons.person_sharp,),
                              SizedBox(width: 8,),
                              Text("4")
                            ],
                          ),
                        ),
                        Expanded(
                          child: Row(
                            children: const [
                              Icon(Icons.card_travel,),
                              SizedBox(width: 8,),
                              Text("2")
                            ],
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: const [
                              Text("Single Trip",style: TextStyle(color: Colors.black87,fontSize: 16,fontWeight: FontWeight.w500),)
                            ],
                          ),
                        ),

                      ],
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: ashColor)
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Row(
                              children: const [
                                FaIcon(FontAwesomeIcons.car,size: 20,color: Colors.black87,),
                                SizedBox(
                                  width: 8,
                                ),
                                Expanded(child: SizedBox(child: Text("Standard Sedan",style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w500),))),
                              ],
                            ),
                          ),
                          const Text("€499.00",style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w500),)
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: ashColor)
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: 90,
                            child: Row(
                              children: [
                                Column(
                                  mainAxisSize: MainAxisSize.max,
                                  children: const [
                                    Expanded(flex: 2,child: Icon(Icons.star,color: Colors.blue,size: 16,)),
                                    Expanded(child: Icon(Icons.circle,color: Colors.grey,size: 4,)),
                                    Expanded(child: Icon(Icons.circle,color: Colors.grey,size: 4,)),
                                    Expanded(child: Icon(Icons.circle,color: Colors.grey,size: 4,)),
                                    Expanded(child: Icon(Icons.circle,color: Colors.grey,size: 4,)),
                                    Expanded(flex: 2,child: Icon(Icons.star,color: Colors.grey,size: 16,)),
                                  ],
                                ),
                                const SizedBox(
                                  width: 16,
                                ),
                                Expanded(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Row(
                                        children: const [
                                          Expanded(
                                            child: SizedBox(child: Text("Rd-17,Banani,Dhaka-1213",maxLines: 2,)),
                                          ),
                                          Text("9:45 PM",style: TextStyle(color: Colors.black45,fontSize: 14),),
                                        ],
                                      ),
                                      const Spacer(),
                                      Row(
                                        children: const [
                                          Expanded(
                                            child: Text("Rd-45,Savar,Dhaka-1213",maxLines: 1,),
                                          ),
                                          Text("-- : --",style: TextStyle(color: Colors.black45,fontSize: 14),),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: ashColor)
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: const [
                          Text("Return : ",style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w500),),
                          SizedBox(
                            width: 8,
                          ),
                          Expanded(child: SizedBox(child: Text("N/A",style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w500),))),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: ashColor)
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Text("Status : ",style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w500),),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(24),
                              color: Colors.deepPurple.shade50,
                              border: Border.all(color: Colors.deepPurple)
                            ),
                              child: const Text("Upcoming",style: TextStyle(color: Colors.deepPurple,fontSize: 15,fontWeight: FontWeight.w500),)
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: ashColor)
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: const [
                          Text("TRX : ",style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w500),),
                          SizedBox(
                            width: 8,
                          ),
                          Expanded(child: SizedBox(child: Text("X34RT567800",style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w500),))),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: ashColor)
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: const [
                          Text("SERVICES : ",style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w500),),
                          SizedBox(
                            width: 8,
                          ),
                          Expanded(child: SizedBox(child: Text("X34RT567800",style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w500),))),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    const Align(alignment: Alignment.centerLeft,child: Text("NOTE",textAlign: TextAlign.start,style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w600),)),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: ashColor)
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: const [
                          Expanded(child: SizedBox(child: Text(KStrings.loremIpsum,maxLines: 4,style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w500),))),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    const Align(alignment: Alignment.centerLeft,child: Text("FLIGHT DETAILS",textAlign: TextAlign.start,style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w600),)),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: ashColor)
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: const [
                          Expanded(child: SizedBox(child: Text(KStrings.loremIpsum,maxLines: 5,style: TextStyle(color: Colors.black87,fontSize: 15,fontWeight: FontWeight.w500),))),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
            sliver: SliverToBoxAdapter(
              child: Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.blueGrey.withOpacity(0.1),
                          blurRadius: 6,
                          offset: const Offset(1, 1))
                    ]),
                child: Column(
                  children: [
                    const CircleAvatar(
                      radius: 80,
                      backgroundColor: ashColor,
                      backgroundImage: AssetImage(Kimages.defaultUser),
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    const Text(
                      "Customer Name",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w500),
                    ),
                    const Text(
                      "@username",
                      style: TextStyle(
                          color: Colors.blue,
                          fontSize: 16,
                          fontWeight: FontWeight.w400),
                    ),
                    const Divider(
                      height: 50,
                    ),
                    const Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          "Contact Information",
                          style: TextStyle(
                              color: Colors.black54,
                              fontSize: 14,
                              fontWeight: FontWeight.w400),
                        )
                    ),
                    Row(
                      children: const [
                        Icon(Icons.call,color: Colors.green,size: 20,),
                        SizedBox(
                          width: 8,
                        ),
                        Text(
                          "01860141942",
                          style: TextStyle(
                              color: Colors.black87,
                              fontSize: 16,
                              fontWeight: FontWeight.w400),
                        )
                      ],
                    ),
                    Row(
                      children: const [
                        Icon(Icons.mail_outline,color: Colors.green,size: 20,),
                        SizedBox(
                          width: 8,
                        ),
                        Text(
                          "ziariyad018@gmail.com",
                          style: TextStyle(
                              color: Colors.black87,
                              fontSize: 16,
                              fontWeight: FontWeight.w400),
                        )
                      ],
                    ),
                    Row(
                      children: const [
                        Icon(Icons.location_on_outlined,color: Colors.red,size: 20,),
                        SizedBox(
                          width: 8,
                        ),
                        Expanded(
                          child: SizedBox(
                            child: Text(
                              "Nuhash polli, Heiderabad, India",
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400),
                            ),
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
