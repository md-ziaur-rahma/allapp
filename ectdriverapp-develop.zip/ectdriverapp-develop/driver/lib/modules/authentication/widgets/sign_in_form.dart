import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:driver/modules/authentication/widgets/social_buttons.dart';
import '../../../core/router_name.dart';
import '../../../utils/constants.dart';
import '../../../utils/k_images.dart';
import '../../../utils/utils.dart';
import '../../../widgets/custom_image.dart';
import '../../../widgets/primary_button.dart';
import '../controllers/login/login_bloc.dart';

class SignInForm extends StatefulWidget {
  const SignInForm({Key? key}) : super(key: key);

  @override
  State<SignInForm> createState() => SignInFormState();
}

class SignInFormState extends State<SignInForm> {
  bool _checkBoxSelect = false;
  bool _passwordVisible = false;

  @override
  Widget build(BuildContext context) {
    final loginBloc = context.read<LoginBloc>();
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          const SliverPadding(
            padding: EdgeInsets.symmetric(vertical: 30,),
            sliver: SliverToBoxAdapter(
              child: CustomImage(
                // path: RemoteUrls.imageUrl(appSetting.settingModel!.logo),
                path: Kimages.logoColor,
                width: 280,
                height: 110,
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16,),
            sliver: SliverToBoxAdapter(
              child: Form(
                key: loginBloc.formKey,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.1),
                        blurRadius: 6,
                        offset: const Offset(1,1)
                      )
                    ]
                  ),
                  child: Column(
                    children: [
                      AnimatedContainer(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        alignment: Alignment.topLeft,
                        duration: kDuration,
                        child: const Center(
                          child: Text("Signin",
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      BlocBuilder<LoginBloc, LoginModelState>(
                        buildWhen: (previous, current) => previous.email != current.email,
                        builder: (context, state) {
                          return TextFormField(
                            keyboardType: TextInputType.emailAddress,
                            initialValue: state.email,
                            textInputAction: TextInputAction.next,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Enter email';
                              }
                              return null;
                            },
                            onChanged: (value) =>
                                loginBloc.add(LoginEventUserName(value)),
                            decoration: const InputDecoration(
                              hintText: 'Email',
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 16),
                      BlocBuilder<LoginBloc, LoginModelState>(
                        buildWhen: (previous, current) =>
                        previous.password != current.password,
                        builder: (context, state) {
                          return TextFormField(
                            keyboardType: TextInputType.visiblePassword,
                            initialValue: state.password,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Enter Password';
                              }else if (value.length < 6) {
                                return 'Enter Minimum 6 Character';
                              }
                              return null;
                            },
                            onChanged: (value) =>
                                loginBloc.add(LoginEventPassword(value)),
                            obscureText: !_passwordVisible,
                            decoration: InputDecoration(
                              hintText: 'Password',
                              suffixIcon: IconButton(
                                icon: Icon(
                                  _passwordVisible
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                  color: grayColor,
                                ),
                                onPressed: () {
                                  setState(() {
                                    _passwordVisible = !_passwordVisible;
                                  });
                                },
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 8),
                      _buildRememberMe(),
                      const SizedBox(height: 25),
                      BlocBuilder<LoginBloc, LoginModelState>(
                        buildWhen: (previous, current) => previous.state != current.state,
                        builder: (context, state) {
                          if (state.state is LoginStateLoading) {
                            return const Center(child: CircularProgressIndicator());
                          }
                          return PrimaryButton(
                            text: 'Sign In',
                            onPressed: () {
                              Utils.closeKeyBoard(context);
                              loginBloc.add(const LoginEventSubmit());
                            },
                          );
                        },
                      ),
                      const SizedBox(
                        height: 24,
                      ),
                      const Text("Or Signin with Social"),
                      const SizedBox(
                        height: 24,
                      ),
                      const SocialButtons()
                    ],
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildRememberMe() {
    return Row(
      children: [
        Flexible(
          child: CheckboxListTile(
            value: _checkBoxSelect,
            dense: true,
            shape: BeveledRectangleBorder(
              borderRadius: BorderRadius.circular(40),
            ),
            contentPadding: EdgeInsets.zero,
            checkColor: Colors.white,
            activeColor: redColor,
            controlAffinity: ListTileControlAffinity.leading,
            title: Text(
              'Remember me',
              style: TextStyle(color: blackColor.withOpacity(.5)),
            ),
            onChanged: (bool? v) {
              if (v == null) return;
              setState(() {
                _checkBoxSelect = v;
              });
            },
          ),
        ),
        InkWell(
          onTap: () {
            Navigator.pushNamed(context, RouteNames.forgotScreen);
          },
          child: const Text(
            'Forgot password?',
            style: TextStyle(color: redColor),
          ),
        ),
      ],
    );
  }
}
