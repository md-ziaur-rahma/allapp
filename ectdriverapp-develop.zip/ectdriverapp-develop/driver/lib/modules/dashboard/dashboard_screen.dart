import 'package:flutter/material.dart';
import 'package:driver/modules/dashboard/component/chart_component.dart';
import 'package:driver/modules/dashboard/component/top_bar.dart';
import 'package:driver/utils/constants.dart';

import 'component/grid_card_container.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFFF1F3F6),
      // backgroundColor: Colors.red,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              sliver: SliverToBoxAdapter(child: DashboardTopBar()),
            ),
            SliverPadding(
              padding: EdgeInsets.symmetric(horizontal: 16,vertical: 16),
              sliver: DashboardGridCardLayout(),
            ),
            SliverToBoxAdapter(
              child: SizedBox(
                height: 30,
              ),
            ),
          ],
        ),
      ),
    );
  }

}