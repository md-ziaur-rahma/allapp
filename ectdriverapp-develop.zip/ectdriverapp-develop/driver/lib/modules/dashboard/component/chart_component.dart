import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../../utils/constants.dart';

class ColumnChart extends StatefulWidget {
  const ColumnChart({Key? key}) : super(key: key);

  @override
  State<ColumnChart> createState() => _ColumnChartState();
}

class _ColumnChartState extends State<ColumnChart> {
  late List<_ChartData> data;
  late TooltipBehavior _tooltip;

  @override
  void initState() {
    data = [
      _ChartData('SUN', 2),
      _ChartData('MON', 3),
      _ChartData('TUE', 1),
      _ChartData('WED', 6),
      _ChartData('THU', 2),
      _ChartData('FRI', 3),
      _ChartData('SAT', 6),
    ];
    _tooltip = TooltipBehavior(enable: true);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withAlpha(1000),
      // elevation: 3,
      shadowColor: const Color(0xFFFFFFFF),
      borderRadius: BorderRadius.circular(30),
      borderOnForeground: true,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SfCartesianChart(
                title: ChartTitle(
                    text: "Records in chart",
                    alignment: ChartAlignment.near,
                    borderWidth: 10),
                borderColor: ashColor,
                isTransposed: false,
                primaryXAxis: CategoryAxis(borderColor: ashColor),
                primaryYAxis:
                    NumericAxis(minimum: 0, maximum: 10, interval: 50),
                tooltipBehavior: _tooltip,
                series: <ChartSeries<_ChartData, String>>[
                  ColumnSeries<_ChartData, String>(
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                      dataSource: data,
                      xValueMapper: (_ChartData data, _) => data.x,
                      yValueMapper: (_ChartData data, _) => data.y,
                      name: 'Gold',
                      color: redColor,
                      width: 0.3)
                ])
          ],
        ),
      ),
    );
  }
}

class _ChartData {
  _ChartData(this.x, this.y);

  final String x;
  final double y;
}
