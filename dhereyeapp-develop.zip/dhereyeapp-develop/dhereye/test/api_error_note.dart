/// home category icon need icon as image
/// product model missiong rating attribute
/// user registration smtp.mailtrap.io error
/// user login it gives statuscode 200 but need 403 for wrang password
/// can't check forgot, reset, validation, token api due to smtp.mailtrap.io error
/// product details page related see all api not found;
///  123816
/// onboarding feature
/// product rating value
/// notification featuere
/// view offer base on profile
/// payment getaway
/// home category icon need icon as image
/// only required json data should be provide