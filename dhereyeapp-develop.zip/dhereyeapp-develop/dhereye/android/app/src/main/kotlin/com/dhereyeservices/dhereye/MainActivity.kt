package com.dhereyeservices.dhereye

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
