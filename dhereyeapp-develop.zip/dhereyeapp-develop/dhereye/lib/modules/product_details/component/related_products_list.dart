import 'package:flutter/material.dart';
import 'package:dhereye/utils/constants.dart';

import '../../home/component/section_header.dart';
import '../model/product_details_product_model.dart';
import 'related_single_product_card.dart';

class RelatedProductsList extends StatelessWidget {
  const RelatedProductsList(
    this.relatedProducts, {
    Key? key,
  }) : super(key: key);
  final List<ProductDetailsProductModel> relatedProducts;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
              Text(
                "Related Products",
                style: TextStyle(
                    fontSize: 18,
                    color: blackColor,
                    height: 1.5,
                    fontWeight: FontWeight.w600),
              ),
              SizedBox()
            ],
          ),
        ),
        SizedBox(
          height: 235,
          child: ListView.separated(
            separatorBuilder: (context, index) => const SizedBox(width: 16),
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
            itemCount: relatedProducts.length,
            itemBuilder: (context, index) => RelatedSingleProductCard(
                productModel: relatedProducts[index], width: 180),
          ),
        ),
      ],
    );
  }
}
