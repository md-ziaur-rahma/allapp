import 'dart:convert';

import 'package:equatable/equatable.dart';

class SellerModel extends Equatable{
  const SellerModel({
    required this.id,
    required this.userId,
    required this.totalAmount,
    required this.bannerImage,
    required this.phone,
    required this.email,
    required this.shopName,
    required this.slug,
    required this.openAt,
    required this.closedAt,
    required this.address,
    required this.seoTitle,
    required this.seoDescription,
    required this.status,
    required this.isFeatured,
    required this.topRated,
    required this.description,
    required this.greetingMsg,
    required this.countryId,
    required this.stateId,
    required this.cityId,
    required this.latitude,
    required this.longitude,
  });

  final int id;
  final int userId;
  final int totalAmount;
  final String bannerImage;
  final String phone;
  final String email;
  final String shopName;
  final String slug;
  final String openAt;
  final String closedAt;
  final String address;
  final String seoTitle;
  final String seoDescription;
  final int status;
  final int isFeatured;
  final int topRated;
  final String description;
  final String greetingMsg;
  final int countryId;
  final int stateId;
  final int cityId;
  final double latitude;
  final double longitude;

  SellerModel copyWith({
    int? id,
    int? userId,
    int? totalAmount,
    String? bannerImage,
    String? phone,
    String? email,
    String? shopName,
    String? slug,
    String? openAt,
    String? closedAt,
    String? address,
    String? seoTitle,
    String? seoDescription,
    int? status,
    int? isFeatured,
    int? topRated,
    String? description,
    String? greetingMsg,
    int? countryId,
    int? stateId,
    int? cityId,
    double? latitude,
    double? longitude,
  }) =>
      SellerModel(
        id: id ?? this.id,
        userId: userId ?? this.userId,
        totalAmount: totalAmount ?? this.totalAmount,
        bannerImage: bannerImage ?? this.bannerImage,
        phone: phone ?? this.phone,
        email: email ?? this.email,
        shopName: shopName ?? this.shopName,
        slug: slug ?? this.slug,
        openAt: openAt ?? this.openAt,
        closedAt: closedAt ?? this.closedAt,
        address: address ?? this.address,
        seoTitle: seoTitle ?? this.seoTitle,
        seoDescription: seoDescription ?? this.seoDescription,
        status: status ?? this.status,
        isFeatured: isFeatured ?? this.isFeatured,
        topRated: topRated ?? this.topRated,
        description: description ?? this.description,
        greetingMsg: greetingMsg ?? this.greetingMsg,
        countryId: countryId ?? this.countryId,
        stateId: stateId ?? this.stateId,
        cityId: cityId ?? this.cityId,
        latitude: latitude ?? this.latitude,
        longitude: longitude ?? this.longitude,
      );

  factory SellerModel.fromJson(String str) => SellerModel.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory SellerModel.fromMap(Map<String, dynamic> json) => SellerModel(
    id: json["id"] ?? 0,
    userId: json["user_id"] ?? 0,
    totalAmount: json["total_amount"] ?? 0,
    bannerImage: json["banner_image"] ?? '',
    phone: json["phone"] ?? '',
    email: json["email"] ?? '',
    shopName: json["shop_name"]  ?? '',
    slug: json["slug"] ?? '',
    openAt: json["open_at"] ?? '',
    closedAt: json["closed_at"] ?? '',
    address: json["address"] ?? '',
    seoTitle: json["seo_title"] ?? '',
    seoDescription: json["seo_description"] ?? 0,
    status: json["status"] ?? '',
    isFeatured: json["is_featured"] ?? 0,
    topRated: json["top_rated"] ?? 0,
    description: json["description"]  ?? '',
    greetingMsg: json["greeting_msg"]  ?? '',
    countryId: json["country_id"]  ?? 0,
    stateId: json["state_id"] ?? 0,
    cityId: json["city_id"] ?? 0,
    latitude: json["latitude"] ?? 0.0,
    longitude: json["longitude"] ?? 0.0,
  );

  Map<String, dynamic> toMap() => {
    "id": id,
    "user_id": userId,
    "total_amount": totalAmount,
    "banner_image": bannerImage,
    "phone": phone,
    "email": email,
    "shop_name": shopName,
    "slug": slug,
    "open_at": openAt,
    "closed_at": closedAt,
    "address": address,
    "seo_title": seoTitle,
    "seo_description": seoDescription,
    "status": status,
    "is_featured": isFeatured,
    "top_rated": topRated,
    "description": description,
    "greeting_msg": greetingMsg,
    "country_id": countryId,
    "state_id": stateId,
    "city_id": cityId,
    "latitude": latitude,
    "longitude": longitude,
  };

  @override
  String toString() {
    return 'SellerModel(id: $id, userId: $userId, totalAmount: $totalAmount, bannerImage: $bannerImage, phone: $phone, email: $email, shopName: $shopName, slug: $slug, openAt: $openAt, closedAt: $closedAt, address: $address, seoTitle: $seoTitle, seoDescription: $seoDescription, status: $status, isFeatured: $isFeatured, topRated: $topRated, description: $description, greetingMsg: $greetingMsg, countryId: $countryId, stateId: $stateId, cityId: $cityId, latitude: $latitude, longitude: $longitude)';
  }

  @override
  List<Object> get props {
    return [
      id,
      userId,
      totalAmount,
      bannerImage,
      phone,
      email,
      shopName,
      slug,
      openAt,
      closedAt,
      address,
      seoTitle,
      seoDescription,
      status,
      isFeatured,
      topRated,
      description,
      greetingMsg,
      countryId,
      stateId,
      cityId,
      latitude,
      longitude,
    ];
  }
}