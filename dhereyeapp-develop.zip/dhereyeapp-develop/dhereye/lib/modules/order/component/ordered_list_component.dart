import 'package:flutter/material.dart';
import 'package:dhereye/core/router_name.dart';
import '../../../utils/constants.dart';
import '../../../utils/utils.dart';
import '../model/order_model.dart';
import 'single_order_details_component.dart';

class OrderedListComponent extends StatelessWidget {
  const OrderedListComponent({Key? key, required this.orderedItem})
      : super(key: key);

  final OrderModel orderedItem;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      margin: const EdgeInsets.symmetric(vertical: 9),
      decoration: BoxDecoration(
        color: redColor.withOpacity(.06),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          _buildOrderNumber(context),
          const SizedBox(height: 8),
          ...orderedItem.orderProducts.map((e) => SingleOrderDetailsComponent(
              orderItem: e, isOrdered: orderedItem.orderStatus == 3)),
          const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _totalItem(),
              Text(
                Utils.orderStatus(orderedItem.orderStatus.toString()),
                style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color:
                        orderedItem.orderStatus.toString() == '4' ? redColor : greenColor),
              )
            ],
          ),
          const SizedBox(height: 18),
        ],
      ),
    );
  }

  Widget _totalItem() {
    int i = orderedItem.orderProducts.length;
    String s = 'Item: ${i.toString()}';
    if (i > 1) s = 'Items: ${i.toString()}';

    final subTotal = Utils.formatPriceIcon(orderedItem.subTotal, orderedItem.currencyIcon);
    final total = Utils.formatPriceIcon(orderedItem.subTotal+orderedItem.shippingCost, orderedItem.currencyIcon);
    final deliveryFee = Utils.formatPriceIcon(orderedItem.shippingCost, orderedItem.currencyIcon);
    final text = orderedItem.shippingCost > 0 ? "SubTotal" : "Total";

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '$s, $text : $subTotal',
          style: const TextStyle(fontSize: 16),
        ),
        Visibility(
          visible: orderedItem.shippingCost > 0,
          child: Text(
            'Delivery Fee : $deliveryFee',
            style: const TextStyle(fontSize: 16),
          ),
        ),
        Visibility(
          visible: orderedItem.shippingCost > 0,
          child: Text(
            'Total : $total',
            style: const TextStyle(fontSize: 16),
          ),
        ),
      ],
    );
  }

  Widget _buildOrderNumber(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        GestureDetector(
          onTap: (){
            Navigator.pushNamed(context, RouteNames.trackOrderScreen,arguments: orderedItem.orderId.toString());
          },
          child: Text.rich(
            TextSpan(
              text: "Tracking number : ",
              style: const TextStyle(fontSize: 16, height: 1),
              children: [
                TextSpan(
                  text: orderedItem.orderId,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
        ),
        Text(
          Utils.formatDate(orderedItem.createdAt),
          style: const TextStyle(color: Color(0xff85959E)),
        )
      ],
    );
  }
}
