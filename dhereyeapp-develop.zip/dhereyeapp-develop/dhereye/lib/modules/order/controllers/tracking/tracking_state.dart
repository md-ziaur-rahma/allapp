part of 'tracking_cubit.dart';

abstract class TrackingState extends Equatable {
  const TrackingState();

  @override
  List<Object> get props => [];
}

class TrackingStateInitial extends TrackingState {
  const TrackingStateInitial();
}

class TrackingStateLoading extends TrackingState {
  const TrackingStateLoading();
}

class TrackingStateError extends TrackingState {
  const TrackingStateError(this.message, this.statusCode);
  final String message;
  final int statusCode;

  @override
  List<Object> get props => [message, statusCode];
}

class TrackingStateLoaded extends TrackingState {
  final OrderModel trackingData;
  const TrackingStateLoaded(this.trackingData);

  @override
  List<Object> get props => [trackingData];
}