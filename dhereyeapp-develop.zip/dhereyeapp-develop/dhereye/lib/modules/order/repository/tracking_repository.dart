import 'package:dartz/dartz.dart';
import 'package:dhereye/core/data/datasources/remote_data_source.dart';
import 'package:dhereye/core/error/exception.dart';
import 'package:dhereye/core/error/failure.dart';
import 'package:dhereye/modules/order/model/order_model.dart';

abstract class TrackingRepository {
  Future<Either<Failure,OrderModel>> trackingData(String orderId);
}

class TrackingRepositoryImp extends TrackingRepository {
  final RemoteDataSource _remoteDataSource;

  TrackingRepositoryImp(this._remoteDataSource);

  @override
  Future<Either<Failure, OrderModel>> trackingData(String orderId) async {
    try{
      final result = await _remoteDataSource.trackOrder(orderId);

      return Right(result);
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message, e.statusCode));
    }
  }

}