import 'package:custom_pop_up_menu/custom_pop_up_menu.dart';
import 'package:dhereye/widgets/rounded_app_bar.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../utils/constants.dart';
import '../../utils/utils.dart';
import '../category/component/product_card.dart';
import 'controller/banner_product_bloc.dart';

class BannerProductScreen extends StatefulWidget {
  const BannerProductScreen({Key? key, required this.link, required this.title}) : super(key: key);
  final String link;
  final String title;

  @override
  State<BannerProductScreen> createState() => _BannerProductScreenState();
}

class _BannerProductScreenState extends State<BannerProductScreen> {
  @override
  void initState() {
    super.initState();
    _init();
    Future.microtask(() {
      context.read<BannerProductBloc>().add(BannerProductEventSearch(widget.link));
    });

  }

  void _init() {
    _controller.addListener(() {
      final maxExtent = _controller.position.maxScrollExtent - 200;
      if (maxExtent < _controller.position.pixels) {
        bannerProductBloc.add(const BannerProductEventLoadMore());
      }
    });
  }

  final _controller = ScrollController();

  late BannerProductBloc bannerProductBloc;
  @override
  void dispose() {
    super.dispose();
    bannerProductBloc.products.clear();
  }

  final brandMenuController = CustomPopupMenuController();
  final categoryMenuController = CustomPopupMenuController();

  @override
  Widget build(BuildContext context) {
    bannerProductBloc = context.read<BannerProductBloc>();

    return Scaffold(
      appBar: RoundedAppBar(titleText: widget.title,),
      body: BlocConsumer<BannerProductBloc, BannerProductState>(
        listener: (context, state) {
          if (state is BannerProductStateMoreError) {
            Utils.errorSnackBar(context, state.message);
          }
        },
        builder: (context, state) {
          final products = bannerProductBloc.products;
          if (bannerProductBloc.products.isEmpty && state is BannerProductStateLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is BannerProductStateError) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Center(
                  child: Text(
                    state.message,
                    style: const TextStyle(color: redColor),
                  ),
                ),
              ],
            );
          }
          return Column(
            children: [
              if (bannerProductBloc.brandList.isNotEmpty && bannerProductBloc.categoryList.isNotEmpty || state is BannerProductStateLoaded)
                // Container(
                //   padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
                //   decoration: BoxDecoration(
                //       color: Colors.white,
                //       boxShadow: [
                //         BoxShadow(
                //             blurRadius: 6,
                //             color: Colors.grey.withOpacity(0.2),
                //             offset: const Offset(0,1),
                //             blurStyle: BlurStyle.outer
                //         )
                //       ]
                //   ),
                //   child: Row(
                //     mainAxisAlignment: MainAxisAlignment.start,
                //     crossAxisAlignment: CrossAxisAlignment.center,
                //     mainAxisSize: MainAxisSize.max,
                //     children: [
                //       CustomPopupMenu(
                //           pressType: PressType.singleClick,
                //           position: PreferredPosition.bottom,
                //           showArrow: false,
                //           verticalMargin: 4,
                //           horizontalMargin: 0,
                //           controller: brandMenuController,
                //           // barrierColor: Colors.transparent,
                //           child: Material(
                //             // borderRadius: BorderRadius.circular(30),
                //             color: const Color(0xFFF2F2F2),
                //             shape: const StadiumBorder(),
                //             borderOnForeground: true,
                //             child: InkWell(
                //               borderRadius: BorderRadius.circular(30),
                //               onTap: (){
                //                 if (bannerProductBloc.brandList.isNotEmpty) {
                //                   brandMenuController.showMenu();
                //                 }
                //               },
                //               child: Container(
                //                 decoration: BoxDecoration(
                //                   // border: Border.all(color: Colors.black54),
                //                     borderRadius: BorderRadius.circular(30)
                //                 ),
                //                 padding: const EdgeInsets.symmetric(horizontal: 8.0,vertical: 4),
                //                 child: Row(
                //                   children: const [
                //                     Text("Brands",style: TextStyle(color: Colors.black54,fontSize: 13),),
                //                     SizedBox(width: 8,),
                //                     Icon(Icons.arrow_drop_down_rounded,size: 18,color: Colors.black54,)
                //                   ],
                //                 ),
                //               ),
                //             ),
                //           ),
                //           menuOnChange: (val){
                //
                //           },
                //           menuBuilder: () => StatefulBuilder(
                //               builder: (stateContext, setState) {
                //                 return Container(
                //                   // height: 200,
                //                   width: double.infinity,
                //                   decoration: const BoxDecoration(
                //                     color: Colors.white,
                //                   ),
                //                   child: Column(
                //                     children: [
                //                       GridView.builder(
                //                         shrinkWrap: true,
                //                         padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                //                         gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                //                             crossAxisCount: 2,
                //                             mainAxisSpacing: 0,
                //                             crossAxisSpacing: 10,
                //                             mainAxisExtent: 40
                //                         ),
                //                         itemBuilder: (context,index){
                //                           return GestureDetector(
                //                             onTap: (){
                //                               setState((){
                //                                 bannerProductBloc.addFilterBrand(bannerProductBloc.brandList[index]);
                //                               });
                //                               if (kDebugMode) {
                //                                 print("${bannerProductBloc.filterBrandList.length}");
                //                               }
                //                             },
                //                             child: Column(
                //                               mainAxisSize: MainAxisSize.min,
                //                               crossAxisAlignment: CrossAxisAlignment.start,
                //                               children: [
                //                                 Row(
                //                                   mainAxisSize: MainAxisSize.max,
                //                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //                                   children: [
                //                                     Expanded(
                //                                       child: Text(bannerProductBloc.brandList[index].name,style: TextStyle(color: bannerProductBloc.isAdded(bannerProductBloc.brandList[index])
                //                                           ? redColor : Colors.black54,fontSize: 13,fontWeight: FontWeight.w500),),
                //                                     ),
                //                                     Icon(Icons.check,size: 16,color: bannerProductBloc.isAdded(bannerProductBloc.brandList[index]) ? redColor : Colors.transparent,)
                //                                   ],
                //                                 ),
                //                                 Divider(
                //                                   height: 16,
                //                                   color: bannerProductBloc.isAdded(bannerProductBloc.brandList[index]) ? redColor : Colors.grey[300],
                //                                 )
                //                               ],
                //                             ),
                //                           );
                //                         },itemCount: bannerProductBloc.brandList.length,
                //                       ),
                //                       Row(
                //                         children: [
                //                           const SizedBox(
                //                             width: 20,
                //                           ),
                //                           Expanded(
                //                             child: SizedBox(
                //                               height: 35,
                //                               child: OutlinedButton(
                //                                 style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.black54)),
                //                                 onPressed: (){
                //                                   setState((){
                //                                     bannerProductBloc.filterBrandList.clear();
                //                                   });
                //                                   brandMenuController.hideMenu();
                //                                 },
                //                                 child: const Text("Reset",style: TextStyle(color: Colors.black54,fontSize: 13),),
                //                               ),
                //                             ),
                //                           ),
                //                           const SizedBox(
                //                             width: 20,
                //                           ),
                //                           Expanded(
                //                             child: SizedBox(
                //                               height: 35,
                //                               child: ElevatedButton(
                //                                 onPressed: (){},
                //                                 child: const Text("Apply",style: TextStyle(color: Colors.white,fontSize: 13),),
                //                               ),
                //                             ),
                //                           ),
                //                           const SizedBox(
                //                             width: 20,
                //                           ),
                //                         ],
                //                       ),
                //                       const SizedBox(
                //                         height: 10,
                //                       )
                //                     ],
                //                   ),
                //                 );
                //               }
                //           )
                //
                //       ),
                //       const SizedBox(width: 10,),
                //       CustomPopupMenu(
                //           pressType: PressType.singleClick,
                //           position: PreferredPosition.bottom,
                //           showArrow: false,
                //           verticalMargin: 4,
                //           horizontalMargin: 0,
                //           controller: categoryMenuController,
                //           // barrierColor: Colors.transparent,
                //           child: Material(
                //             // borderRadius: BorderRadius.circular(30),
                //             color: const Color(0xFFF2F2F2),
                //             shape: const StadiumBorder(),
                //             borderOnForeground: true,
                //             child: InkWell(
                //               borderRadius: BorderRadius.circular(30),
                //               onTap: (){
                //                 if (bannerProductBloc.categoryList.isNotEmpty) {
                //                   categoryMenuController.showMenu();
                //                 }
                //               },
                //               child: Container(
                //                 decoration: BoxDecoration(
                //                   // border: Border.all(color: Colors.black54),
                //                     borderRadius: BorderRadius.circular(30)
                //                 ),
                //                 padding: const EdgeInsets.symmetric(horizontal: 8.0,vertical: 4),
                //                 child: Row(
                //                   children: const [
                //                     Text("Categories",style: TextStyle(color: Colors.black54,fontSize: 13,fontWeight: FontWeight.w500),),
                //                     SizedBox(width: 8,),
                //                     Icon(Icons.arrow_drop_down_rounded,size: 18,color: Colors.black54,)
                //                   ],
                //                 ),
                //               ),
                //             ),
                //           ),
                //           menuOnChange: (val){
                //
                //           },
                //           menuBuilder: () => Container(
                //             // height: 200,
                //             width: double.infinity,
                //             decoration: const BoxDecoration(
                //               color: Colors.white,
                //             ),
                //             child: Column(
                //               children: [
                //                 GridView.builder(
                //                   shrinkWrap: true,
                //                   padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                //                   gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                //                       crossAxisCount: 2,
                //                       mainAxisSpacing: 0,
                //                       crossAxisSpacing: 10,
                //                       mainAxisExtent: 40
                //                   ),
                //                   itemBuilder: (context,index){
                //                     return GestureDetector(
                //                       onTap: (){
                //                         if (kDebugMode) {
                //                           print("fldskf");
                //                         }
                //                       },
                //                       child: Column(
                //                         mainAxisSize: MainAxisSize.min,
                //                         crossAxisAlignment: CrossAxisAlignment.start,
                //                         children: [
                //                           Text(bannerProductBloc.categoryList[index].name,style: const TextStyle(color: Colors.black54,fontSize: 13),),
                //                           const Divider(
                //                             color: Colors.transparent,
                //                             height: 16,
                //                           )
                //                         ],
                //                       ),
                //                     );
                //                   },itemCount: bannerProductBloc.categoryList.length,
                //                 ),
                //               ],
                //             ),
                //           )
                //       ),
                //     ],
                //   ),
                // ),
              Expanded(
                child: GridView.builder(
                  controller: _controller,
                  padding: const EdgeInsets.all(15),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    mainAxisExtent: 208,
                  ),
                  itemCount: products.length,
                  itemBuilder: (BuildContext context, int index) {
                    return ProductCard(productModel: products[index]);
                  },
                ),
              ),
              if (state is BannerProductStateLoadMore)
                Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: const CircularProgressIndicator()),
            ],
          );
        },
      ),
    );
  }
}
