import 'package:dartz/dartz.dart';
import 'package:dhereye/modules/search/model/search_data_model.dart';
import '../../../core/data/datasources/remote_data_source.dart';
import '../../../core/error/exception.dart';
import '../../../core/error/failure.dart';

abstract class BannerProductRepository {
  Future<Either<Failure, SearchDataModel>> bannerProduct(Uri uri);
}

class BannerProductRepositoryImp extends BannerProductRepository {
  final RemoteDataSource _remoteDataSource;

  BannerProductRepositoryImp({
    required RemoteDataSource remoteDataSource,
  }) : _remoteDataSource = remoteDataSource;

  @override
  Future<Either<Failure, SearchDataModel>> bannerProduct(Uri uri) async {
    try {
      final result = await _remoteDataSource.bannerProduct(uri);
      return Right(result);
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message, e.statusCode));
    }
  }
}
