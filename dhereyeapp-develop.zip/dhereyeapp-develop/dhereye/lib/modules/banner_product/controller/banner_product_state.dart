part of 'banner_product_bloc.dart';


abstract class BannerProductState extends Equatable {
  const BannerProductState();
  @override
  List<Object> get props => [];
}

class BannerProductStateInitial extends BannerProductState {
  const BannerProductStateInitial();
}

class BannerProductStateLoading extends BannerProductState {
  const BannerProductStateLoading();
}

class BannerProductStateLoadMore extends BannerProductState {
  const BannerProductStateLoadMore();
}

class BannerProductStateError extends BannerProductState {
  final String message;
  final int statusCode;

  const BannerProductStateError(this.message, this.statusCode);
  @override
  List<Object> get props => [message, statusCode];
}

class BannerProductStateMoreError extends BannerProductState {
  final String message;
  final int statusCode;

  const BannerProductStateMoreError(this.message, this.statusCode);
  @override
  List<Object> get props => [message, statusCode];
}

class BannerProductStateLoaded extends BannerProductState {
  final List<ProductModel> products;
  const BannerProductStateLoaded(this.products);

  @override
  List<Object> get props => [products];
}

class BannerProductStateMoreLoaded extends BannerProductState {
  final List<ProductModel> products;
  const BannerProductStateMoreLoaded(this.products);

  @override
  List<Object> get props => [products];
}
