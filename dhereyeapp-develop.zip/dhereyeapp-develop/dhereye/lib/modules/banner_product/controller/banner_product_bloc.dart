import 'package:bloc/bloc.dart';
import 'package:dhereye/modules/banner_product/repository/banner_product_repository.dart';
import 'package:dhereye/modules/home/model/product_model.dart';
import 'package:dhereye/modules/search/model/search_data_model.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart';
import 'package:dhereye/modules/category/model/product_categories_model.dart';
import 'package:dhereye/modules/home/model/brand_model.dart';
import '../../../../core/remote_urls.dart';
import '../../../../utils/constants.dart';

import 'package:stream_transform/stream_transform.dart';
part 'banner_product_state.dart';
part 'banner_product_event.dart';

class BannerProductBloc extends Bloc<BannerProductEvent, BannerProductState> {
  final BannerProductRepository _bannerProductRepository;

  // SearchResponseModel? _searchResponseModel;
  SearchDataModel? searchDataModel;
  List<ProductModel> products = [];
  List<BrandModel> brandList = [];
  List<ProductCategoriesModel> categoryList = [];

  List<BrandModel> filterBrandList = [];
  bool isAdded(BrandModel brandModel){
    return filterBrandList.any((element) => element.id == brandModel.id);
  }
  void addFilterBrand(BrandModel brandModel){
    if (isAdded(brandModel)) {
      filterBrandList.remove(brandModel);
    } else {
      filterBrandList.add(brandModel);
    }
  }

  BannerProductBloc({
    required BannerProductRepository bannerProductRepository,
  })  : _bannerProductRepository = bannerProductRepository,
        super(const BannerProductStateInitial()) {
    on<BannerProductEventSearch>(_bannerProduct, transformer: debounce());
    on<BannerProductEventLoadMore>(_loadMore);
  }

  void _bannerProduct(BannerProductEventSearch event, Emitter<BannerProductState> emit) async {
    emit(const BannerProductStateLoading());

    final uri = Uri.parse(RemoteUrls.baseUrl+event.shopName);

    if (kDebugMode) {
      print(uri);
    }

    final result = await _bannerProductRepository.bannerProduct(uri);

    result.fold((failure) {
      emit(BannerProductStateError(failure.message, failure.statusCode));
    }, (successData) {
      searchDataModel = successData;

      products = successData.products.products;
      brandList = successData.brandList;
      categoryList = successData.categoryList;

      emit(BannerProductStateLoaded(successData.products.products));
    });
  }

  void _loadMore(BannerProductEventLoadMore event, Emitter<BannerProductState> emit) async {
    if (state is BannerProductStateLoadMore) return;
    if (searchDataModel == null ||
        searchDataModel?.products.nextPageUrl == null) {
      return;
    }

    emit(const BannerProductStateLoadMore());

    final uri = Uri.parse(searchDataModel!.products.nextPageUrl!);

    if (kDebugMode) {
      print(uri);
    }

    final result = await _bannerProductRepository.bannerProduct(uri);

    result.fold(
          (failure) {
        emit(BannerProductStateMoreError(failure.message, failure.statusCode));
      },
          (successData) {
        searchDataModel = successData;
        products.addAll(successData.products.products);

        emit(BannerProductStateMoreLoaded(products.toSet().toList()));
      },
    );
  }
}

EventTransformer<Event> debounce<Event>() {
  return (events, mapper) => events.debounce(kDuration).switchMap(mapper);
}
