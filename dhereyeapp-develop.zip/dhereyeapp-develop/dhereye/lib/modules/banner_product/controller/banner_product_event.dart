part of 'banner_product_bloc.dart';

abstract class BannerProductEvent extends Equatable {
  const BannerProductEvent();

  @override
  List<Object> get props => [];
}

class BannerProductEventSearch extends BannerProductEvent {
  final String shopName;
  const BannerProductEventSearch(this.shopName);

  @override
  List<Object> get props => [shopName];
}

class BannerProductEventLoadMore extends BannerProductEvent {
  const BannerProductEventLoadMore();
}
