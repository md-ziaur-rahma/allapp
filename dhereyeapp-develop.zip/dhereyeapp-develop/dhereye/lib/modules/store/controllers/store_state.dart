part of 'store_bloc.dart';
abstract class StoreState extends Equatable {
  const StoreState();
  @override
  List<Object> get props => [];
}

class StoreStateInitial extends StoreState {
  const StoreStateInitial();
}

class StoreStateLoading extends StoreState {
  const StoreStateLoading();
}

class StoreStateLoadMore extends StoreState {
  const StoreStateLoadMore();
}

class StoreStateError extends StoreState {
  final String message;
  final int statusCode;

  const StoreStateError(this.message, this.statusCode);
  @override
  List<Object> get props => [message, statusCode];
}

class StoreStateMoreError extends StoreState {
  final String message;
  final int statusCode;

  const StoreStateMoreError(this.message, this.statusCode);
  @override
  List<Object> get props => [message, statusCode];
}

class StoreStateLoaded extends StoreState {
  final List<ProductModel> products;
  const StoreStateLoaded(this.products);

  @override
  List<Object> get props => [products];
}

class StoreStateMoreLoaded extends StoreState {
  final List<ProductModel> products;
  const StoreStateMoreLoaded(this.products);

  @override
  List<Object> get props => [products];
}
