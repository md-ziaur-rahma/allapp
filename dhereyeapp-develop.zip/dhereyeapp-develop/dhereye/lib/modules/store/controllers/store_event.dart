part of 'store_bloc.dart';

abstract class StoreEvent extends Equatable {
  const StoreEvent();

  @override
  List<Object> get props => [];
}

class StoreEventSearch extends StoreEvent {
  final String shopName;
  const StoreEventSearch(this.shopName);

  @override
  List<Object> get props => [shopName];
}

class StoreEventLoadMore extends StoreEvent {
  const StoreEventLoadMore();
}

class StoreEventAddRemoveCatIds extends StoreEvent {
  final int id;
  const StoreEventAddRemoveCatIds(this.id);

  @override
  List<Object> get props => [id];
}

class StoreEventAddRemoveBrandIds extends StoreEvent {
  final int id;
  const StoreEventAddRemoveBrandIds(this.id);

  @override
  List<Object> get props => [id];
}

class StoreEventFilter extends StoreEvent {
  const StoreEventFilter();
}
