import 'package:equatable/equatable.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:bloc/bloc.dart';
import 'package:stream_transform/stream_transform.dart';
import 'package:dhereye/core/remote_urls.dart';
import 'package:dhereye/modules/category/model/product_categories_model.dart';
import 'package:dhereye/modules/home/model/brand_model.dart';
import 'package:dhereye/modules/home/model/product_model.dart';
import 'package:dhereye/modules/search/model/search_response_model.dart';
import 'package:dhereye/modules/store/models/store_model.dart';
import 'package:dhereye/modules/store/repository/store_repository.dart';

import '../../../utils/constants.dart';

part 'store_event.dart';
part 'store_state.dart';

class StoreBloc extends Bloc<StoreEvent, StoreState> {
  final StoreRepository _storeRepository;
  // SearchResponseModel? _storeResponseModel;
  StoreModel? storeModel;
  List<ProductModel> products = [];
  List<BrandModel> brandList = [];
  List<ProductCategoriesModel> categoryList = [];

  StoreBloc({required StoreRepository storeRepository})
      : _storeRepository = storeRepository,
        super(const StoreStateInitial()) {
    on<StoreEventSearch>(_getStoreData, transformer: debounce());
    on<StoreEventLoadMore>(_loadMore);
    on<StoreEventAddRemoveBrandIds>(_addOrRemoveBrandIds);
    on<StoreEventAddRemoveCatIds>(_addOrRemoveCatIds);
    on<StoreEventFilter>(_filterProduct);
  }

  void _getStoreData(StoreEventSearch event, Emitter<StoreState> emit) async {
    emit(const StoreStateLoading());

    final uri = Uri.parse(RemoteUrls.storeProduct).replace(
      queryParameters: {'shop_name': event.shopName},
    );

    if (kDebugMode) {
      print(uri);
    }

    final result = await _storeRepository.storeProduct(uri);

    result.fold((failure) {
      emit(StoreStateError(failure.message, failure.statusCode));
    }, (successData) {
      storeModel = successData;

      products = storeModel!.products.products;
      brandList = storeModel!.brandList;
      categoryList = storeModel!.categoryList;

      emit(StoreStateLoaded(successData.products.products));
    });
  }

  void _loadMore(StoreEventLoadMore event, Emitter<StoreState> emit) async {
    if (state is StoreStateLoadMore) return;
    if (storeModel == null || storeModel?.products.nextPageUrl == null) {
      return;
    }

    emit(const StoreStateLoadMore());

    final uri = Uri.parse(storeModel!.products.nextPageUrl!);
    // final uri = Uri.parse(_storeResponseModel!.nextPageUrl!).replace(
    //   queryParameters: {'shop_name': event.shopName},
    // );

    final result = await _storeRepository.storeProduct(uri);

    result.fold(
      (failure) {
        emit(StoreStateMoreError(failure.message, failure.statusCode));
      },
      (successData) {
        storeModel = successData;
        products.addAll(successData.products.products);

        emit(StoreStateMoreLoaded(products.toSet().toList()));
      },
    );
  }

  void _addOrRemoveCatIds(
      StoreEventAddRemoveCatIds event, Emitter<StoreState> emit) {}
  void _addOrRemoveBrandIds(
      StoreEventAddRemoveBrandIds event, Emitter<StoreState> emit) {
    bool value = brandIds.any((element) => element == event.id);
    value == true ? brandIds.remove(event.id) : brandIds.add(event.id);
  }

  void _addOrRemoveBrandIds1(id) {
    bool value = brandIds.any((element) => element == id);
    value == true ? brandIds.remove(id) : brandIds.add(id);
  }

  void _filterProduct(StoreEventFilter event, Emitter<StoreState> emit) {}

  List<int> brandIds = [];
  bool isBrandAdded(id) {
    return brandIds.any((element) => element == id);
  }

  void openFilterDialog(StoreBloc bloc, context) {
    showModalBottomSheet(
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16))),
        isScrollControlled: true,
        isDismissible: true,
        context: context,
        backgroundColor: Colors.white,
        builder: (context) {
          return StatefulBuilder(builder: (stateContext, setState) {
            return DraggableScrollableSheet(
                expand: false,
                maxChildSize: 0.9,
                initialChildSize: 0.5,
                builder: (context, scrollController) {
                  return CustomScrollView(
                    controller: scrollController,
                    scrollDirection: Axis.vertical,
                    slivers: [
                      SliverPadding(
                        padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                        sliver: SliverToBoxAdapter(
                          child: Align(
                            alignment: Alignment.topRight,
                            child: SizedBox(
                              height: 45,
                              width: 160,
                              child: ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(backgroundColor: redColor,shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
                                onPressed: (){},
                                icon: const Icon(Icons.filter_alt_outlined,color: whiteColor,),
                                label: const Text("Filter",style: TextStyle(color: whiteColor,),),
                              ),
                            ),
                          )
                        ),
                      ),
                      SliverToBoxAdapter(
                        child: Container(
                          margin: const EdgeInsets.symmetric(
                              vertical: 8, horizontal: 10),
                          decoration: BoxDecoration(
                            // color: redColor.withOpacity(0.4),
                            border: Border.all(color: redColor.withOpacity(1)),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: ExpandablePanel(
                            header: Container(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8, horizontal: 10),
                                // margin: const EdgeInsets.symmetric(
                                //     vertical: 8, horizontal: 10),
                                decoration: BoxDecoration(
                                    color: redColor.withOpacity(1)),
                                child: const Text(
                                  "Filter By Category",
                                  style: TextStyle(
                                    color: whiteColor,
                                      fontSize: 18, fontWeight: FontWeight.w600),
                                )),
                            collapsed: const SizedBox(),
                            expanded: ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemBuilder: (context,index){
                                return InkWell(
                                  onTap: () {},
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 24.0, vertical: 8),
                                    child: SizedBox(
                                        width: double.infinity,
                                        child: Text(
                                          categoryList[index].name,
                                          style: const TextStyle(
                                              color: Colors.black,
                                              fontWeight: FontWeight.w600),
                                        )),
                                  ),
                                );
                              },itemCount: categoryList.length,
                            ),
                          ),
                        ),
                      ),
                      SliverToBoxAdapter(
                        child: Container(
                          margin: const EdgeInsets.symmetric(
                              vertical: 8, horizontal: 10),
                          decoration: BoxDecoration(
                            // color: redColor.withOpacity(0.4),
                            border: Border.all(color: redColor.withOpacity(1)),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: ExpandablePanel(
                            header: Container(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8, horizontal: 10),
                                // margin: const EdgeInsets.symmetric(
                                //     vertical: 8, horizontal: 10),
                                decoration: BoxDecoration(
                                    color: redColor.withOpacity(1)),
                                child: const Text(
                                  "Filter By Brand",
                                  style: TextStyle(color: whiteColor,
                                      fontSize: 18, fontWeight: FontWeight.w600),
                                )),
                            collapsed: const SizedBox(),
                            expanded: ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemBuilder: (context,index){
                                return GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      print("xxxxxxxxxxxxxxxxxxx");
                                      // bloc.add(StoreEventAddRemoveBrandIds(brandList[index].id));
                                      _addOrRemoveBrandIds1(brandList[index].id);
                                    });
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16.0, vertical: 0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Checkbox(
                                          activeColor: redColor,
                                          splashRadius: 6,
                                          value: isBrandAdded(brandList[index].id),
                                          onChanged: (value) {
                                            setState(() {
                                              _addOrRemoveBrandIds1(
                                                  brandList[index].id);
                                              // bloc.add(StoreEventAddRemoveBrandIds(brandList[index].id));
                                            });
                                          },
                                        ),
                                        const SizedBox(
                                          width: 10,
                                        ),
                                        Text(
                                          brandList[index].name,
                                          style: const TextStyle(
                                              fontWeight: FontWeight.w500),
                                        )
                                      ],
                                    ),
                                  ),
                                );
                              },itemCount: brandList.length,
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                });
          });
        });
  }
}

EventTransformer<Event> debounce<Event>() {
  return (events, mapper) => events.debounce(kDuration).switchMap(mapper);
}
