import 'dart:convert';

import 'package:equatable/equatable.dart';
import 'package:dhereye/modules/category/model/product_categories_model.dart';
import 'package:dhereye/modules/home/model/brand_model.dart';
import 'package:dhereye/modules/product_details/model/seller_model.dart';
import 'package:dhereye/modules/search/model/search_response_model.dart';

class StoreModel extends Equatable {
  final ShopBanner banner;
  final SellerModel seller;
  final SearchResponseModel products;
  final List<BrandModel> brandList;
  final int totalReview;
  final List<ProductCategoriesModel> categoryList;
  const StoreModel({
    required this.banner,
    required this.seller,
    required this.products,
    required this.brandList,
    required this.totalReview,
    required this.categoryList,
});

  StoreModel copyWith({
    ShopBanner? banner,
    SellerModel? seller,
    SearchResponseModel? products,
    List<BrandModel>? brandList,
    int? totalReview,
    List<ProductCategoriesModel>? categoryList,
}) {
    return StoreModel(
        banner: banner ?? this.banner,
        seller: seller ?? this.seller,
        products: products ?? this.products,
        brandList: brandList ?? this.brandList,
        totalReview: totalReview ?? 0,
        categoryList: categoryList ?? this.categoryList,
    );
  }

  Map<String, dynamic> toMap() {
    final result = <String, dynamic>{};

    result.addAll({'banner': banner.toMap()});
    result.addAll({'seller': seller.toMap()});
    result.addAll({'products': products.toMap()});
    result.addAll({'productCategories': categoryList.map((x) => x.toMap()).toList()});
    result.addAll({'totalReview': totalReview});
    result.addAll({'brands': brandList.map((x) => x.toMap()).toList()});

    return result;
  }

  factory StoreModel.fromMap(Map<String, dynamic> map) {
    return StoreModel(
      banner: ShopBanner.fromMap(map['banner']),
      seller: SellerModel.fromMap(map['seller']),
      products: SearchResponseModel.fromMap(map['products']),
      categoryList: map['productCategories'] != null
          ? List<ProductCategoriesModel>.from(
          map['productCategories']?.map((x) => ProductCategoriesModel.fromMap(x)))
          : [],
      totalReview: map["totalReview"] ?? 0,
      brandList: map['brands'] != null
          ? List<BrandModel>.from(
          map['brands']?.map((x) => BrandModel.fromMap(x)))
          : [],
    );
  }

  String toJson() => json.encode(toMap());

  factory StoreModel.fromJson(String source) =>
      StoreModel.fromMap(json.decode(source));

  @override
  String toString() {
    return 'StoreModel(banner: $banner, seller: $seller, products: $products, productCategories: $categoryList, totalReview: $totalReview brands: $brandList)';
  }

  @override
  List<Object> get props {
    return [
      banner,
      seller,
      products,
      categoryList,
      totalReview,
      brandList,
    ];
  }
}

class ShopBanner extends Equatable {
  final int id;
  final String location;
  final int imageType;
  final String image;

  const ShopBanner({
    required this.id,
    required this.location,
    required this.imageType,
    required this.image,
  });

  ShopBanner copyWith({
    int? id,
    String? location,
    int? imageType,
    String? image,
  }) {
    return ShopBanner(
      id: id ?? this.id,
      location: location ?? this.location,
      imageType: imageType ?? this.imageType,
      image: image ?? this.image,
    );
  }

  Map<String, dynamic> toMap() {
    final result = <String, dynamic>{};

    result.addAll({'id': id});
    result.addAll({'location': location});
    result.addAll({'image_type': imageType});
    result.addAll({'image': image});

    return result;
  }

  factory ShopBanner.fromMap(Map<String, dynamic> map) {
    return ShopBanner(
      id: map['id'] ?? 0,
      location: map['location'] ?? '',
      imageType: map['image_type'] ?? 1,
      image: map['image'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory ShopBanner.fromJson(String source) =>
      ShopBanner.fromMap(json.decode(source));

  @override
  String toString() {
    return 'ShopBanner(id: $id, location: $location, image_type: $imageType, image: $image)';
  }

  @override
  List<Object> get props {
    return [
      id,
      location,
      imageType,
      image,
    ];
  }
}