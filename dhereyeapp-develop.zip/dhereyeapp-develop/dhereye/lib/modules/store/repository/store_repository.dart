import 'package:dartz/dartz.dart';
import 'package:dhereye/modules/store/models/store_model.dart';
import '../../../core/data/datasources/remote_data_source.dart';
import '../../../core/error/exception.dart';
import '../../../core/error/failure.dart';

abstract class StoreRepository {
  Future<Either<Failure, StoreModel>> storeProduct(Uri uri);
}

class StoreRepositoryImp extends StoreRepository {
  final RemoteDataSource _remoteDataSource;

  StoreRepositoryImp({
    required RemoteDataSource remoteDataSource,
  }) : _remoteDataSource = remoteDataSource;

  @override
  Future<Either<Failure, StoreModel>> storeProduct(Uri uri) async {
    try {
      final result = await _remoteDataSource.storeProduct(uri);
      return Right(result);
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message, e.statusCode));
    }
  }
}
