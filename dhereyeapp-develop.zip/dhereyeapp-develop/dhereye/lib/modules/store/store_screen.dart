import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:dhereye/core/remote_urls.dart';
import 'package:dhereye/modules/category/component/product_card.dart';
import 'package:dhereye/modules/product_details/model/seller_model.dart';
import 'package:dhereye/modules/store/controllers/store_bloc.dart';
import 'package:dhereye/utils/constants.dart';
import 'package:dhereye/utils/k_images.dart';
import 'package:dhereye/utils/utils.dart';
import 'package:dhereye/widgets/custom_image.dart';
import 'package:dhereye/widgets/rounded_app_bar.dart';

import '../../widgets/page_refresh.dart';
import '../home/component/hot_deal_banner.dart';

class StoreProductScreen extends StatefulWidget {
  const StoreProductScreen({Key? key, required this.shopName}) : super(key: key);
  final String shopName;
  // final SellerModel sellerModel;

  @override
  State<StoreProductScreen> createState() => _StoreProductScreenState();
}

class _StoreProductScreenState extends State<StoreProductScreen> {
  @override
  void initState() {
    super.initState();
    _init();
    Future.microtask(() {
      context.read<StoreBloc>().add(StoreEventSearch(widget.shopName));
    });

  }

  void _init() {
    _controller.addListener(() {
      final maxExtent = _controller.position.maxScrollExtent - 200;
      if (maxExtent < _controller.position.pixels) {
        storeBloc.add(const StoreEventLoadMore());
      }
    });
  }

  final _controller = ScrollController();

  late StoreBloc storeBloc;

  @override
  void dispose() {
    super.dispose();

    storeBloc.products.clear();
  }

  @override
  Widget build(BuildContext context) {
    storeBloc = context.read<StoreBloc>();
    return Scaffold(
      appBar: RoundedAppBar(titleText: "Shop",
      //   action: [
      //   IconButton(
      //     onPressed: (){
      //       storeBloc.openFilterDialog(storeBloc,context);
      //     },
      //     icon: const CustomImage(path: Kimages.menuIcon,color: Colors.white,),
      //   )
      // ],
      ),
      body: BlocConsumer<StoreBloc, StoreState>(
        listener: (context, state) {
          if (state is StoreStateError) {
            Utils.errorSnackBar(context, state.message);
          }
        },
        builder: (context, state) {
          final products = storeBloc.products;
          if (storeBloc.products.isEmpty && state is StoreStateLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is StoreStateError) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Center(
                  child: Text(
                    state.message,
                    style: const TextStyle(color: redColor),
                  ),
                ),
              ],
            );
          }
          return PageRefresh(
            onTap: () => storeBloc.add(StoreEventSearch(widget.shopName)),
            child: Column(
              children: [
                Expanded(
                  child: CustomScrollView(
                    controller: _controller,
                    slivers: [
                      SliverLayoutBuilder(
                        builder: (context,constraints){
                          if (storeBloc.storeModel != null) {
                            return SliverToBoxAdapter(
                              child: Container(
                                height: 160,
                                margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 8),
                                width: MediaQuery.of(context).size.width,
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    image: NetworkImage(RemoteUrls.imageUrl("${storeBloc.storeModel?.seller.bannerImage}")),
                                    fit: BoxFit.cover,
                                  ),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                                  decoration: BoxDecoration(
                                    // color: Colors.black.withOpacity(.1),
                                    gradient: LinearGradient(
                                      begin: Alignment.centerLeft,
                                      end: Alignment.centerRight,
                                      colors: [
                                        Colors.black.withOpacity(.8),
                                        Colors.transparent,
                                      ]
                                    )
                                  ),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            FittedBox(
                                              child: Text(
                                                "${storeBloc.storeModel?.seller.shopName}",
                                                maxLines: 1,
                                                style: const TextStyle(
                                                    fontSize: 20.0, height: 2, color: Colors.white),
                                              ),
                                            ),

                                            Row(
                                              children: [
                                                ...List.generate(5, (index) => Icon(Icons.star_border,color: Colors.amber,size: 20,)),
                                                const SizedBox(
                                                  width: 8,
                                                ),
                                                Text("(${storeBloc.storeModel?.totalReview} Review)",style: const TextStyle(
                                                    fontSize: 14, height: 1.5, color: Colors.white),)
                                              ],
                                            ),

                                            Row(
                                              children: [
                                                const Icon(Icons.phone,color: Colors.white,size: 16,),
                                                const SizedBox(
                                                  width: 8,
                                                ),
                                                Text(
                                                  "${storeBloc.storeModel?.seller.phone}",
                                                  maxLines: 1,
                                                  style: const TextStyle(
                                                      fontSize: 14, height: 1.5, color: Colors.white),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                const Icon(Icons.email_outlined,color: Colors.white,size: 16,),
                                                const SizedBox(
                                                  width: 8,
                                                ),
                                                Text(
                                                  "${storeBloc.storeModel?.seller.email}",
                                                  maxLines: 1,
                                                  style: const TextStyle(
                                                      fontSize: 14, height: 1.5, color: Colors.white),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                const Icon(Icons.location_on_outlined,color: Colors.white,size: 16,),
                                                const SizedBox(
                                                  width: 8,
                                                ),
                                                Expanded(
                                                  child: Text(
                                                    "${storeBloc.storeModel?.seller.address}",
                                                    maxLines: 1,
                                                    style: const TextStyle(
                                                        fontSize: 14, height: 1.5, color: Colors.white),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                      // Expanded(
                                      //   child: Column(
                                      //     mainAxisAlignment: MainAxisAlignment.center,
                                      //     crossAxisAlignment: CrossAxisAlignment.end,
                                      //     children: [
                                      //       FittedBox(
                                      //         child: Text(
                                      //           "${storeBloc.storeModel?.seller.shopName}",
                                      //           maxLines: 1,
                                      //           style: const TextStyle(
                                      //               fontSize: 20.0, height: 2, color: Colors.white),
                                      //         ),
                                      //       ),
                                      //
                                      //       Text(
                                      //         "${storeBloc.storeModel?.seller.phone}",
                                      //         maxLines: 1,
                                      //         style: const TextStyle(
                                      //             fontSize: 14, height: 1.5, color: Colors.white),
                                      //       ),
                                      //       Text(
                                      //         "${storeBloc.storeModel?.seller.address}",
                                      //         maxLines: 1,
                                      //         style: const TextStyle(
                                      //             fontSize: 14, height: 1.5, color: Colors.white),
                                      //       ),
                                      //     ],
                                      //   ),
                                      // ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          } else {
                            return const SliverToBoxAdapter(
                              child: SizedBox(),
                            );
                          }
                        },
                      ),
                      // SliverToBoxAdapter(
                      //   child: Container(
                      //     height: 150,
                      //     margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 8),
                      //     width: MediaQuery.of(context).size.width,
                      //     decoration: BoxDecoration(
                      //       image: DecorationImage(
                      //         image: NetworkImage(RemoteUrls.imageUrl("${storeBloc.storeModel?.banner.image}")),
                      //         fit: BoxFit.cover,
                      //       ),
                      //       borderRadius: BorderRadius.circular(4),
                      //     ),
                      //   ),
                      // ),
                      SliverPadding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        sliver: SliverGrid(
                          delegate: SliverChildBuilderDelegate(
                                  (BuildContext context, int index) {
                                    return ProductCard(productModel: products[index]);
                              },
                              childCount: products.length),
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisSpacing: 16,
                            crossAxisSpacing: 16,
                            mainAxisExtent: 208,
                            // childAspectRatio: 0.7,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (state is StoreStateLoadMore)
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: const CircularProgressIndicator()),
              ],
            ),
          );
        },
      ),
    );
  }
}
