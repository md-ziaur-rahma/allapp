import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/remote_urls.dart';
import '../../core/router_name.dart';
import '../../utils/constants.dart';
import '../../utils/k_images.dart';
import '../../widgets/custom_image.dart';
import '../../widgets/please_signin_widget.dart';
import '../animated_splash_screen/controller/app_setting_cubit/app_setting_cubit.dart';
import '../authentication/controller/login/login_bloc.dart';
import 'component/profile_app_bar.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // final _className = 'ProfileScreen';

  final scrollController = ScrollController();
  final scrollController2 = ScrollController();

  @override
  Widget build(BuildContext context) {
    final userData = context.read<LoginBloc>().userInfo;
    final settingModel = context.read<AppSettingCubit>().settingModel;
    const double appBarHeight = 180;
    final routeName = ModalRoute.of(context)?.settings.name ?? '';

    if (userData == null) {
      return const PleaseSigninWidget();
    }

    return NestedScrollView(
      physics: const NeverScrollableScrollPhysics(),
      controller: scrollController,
      headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
        return <Widget>[
          SliverAppBar(
            // iconTheme: const IconThemeData(color: primaryColor),
            automaticallyImplyLeading: routeName != RouteNames.mainPage,
            expandedHeight: appBarHeight,
            backgroundColor: Colors.transparent,
            floating: false,
            pinned: true,
            systemOverlayStyle: const SystemUiOverlayStyle(
                statusBarColor: Color(0xffE8EEF2),
                statusBarIconBrightness: Brightness.dark
            ),
            flexibleSpace: ProfileAppBar(
                height: 180,
                logo: Kimages.logoBG,
                // logo: RemoteUrls.imageUrl(settingModel?.logo ?? ''),
                userData: userData),
          ),
        ];
      },
      body: CustomScrollView(
        controller: scrollController2,
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          const SliverToBoxAdapter(child: SizedBox(height: 12)),
          _buildProfileOptions(context),
          const SliverToBoxAdapter(child: SizedBox(height: 65)),
        ],
      ),
    );
  }

  SliverPadding _buildProfileOptions(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
      sliver: SliverList(
        delegate: SliverChildListDelegate(
          [
            ListTile(
              minLeadingWidth: 0,
              onTap: () {
                Navigator.pushNamed(context, RouteNames.addressScreen);
              },
              contentPadding: EdgeInsets.zero,
              leading: const CustomImage(path: Kimages.profileLocationIcon),
              title: const Text('Your Address', style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              minLeadingWidth: 0,
              onTap: () {
                Navigator.pushNamed(context, RouteNames.trackOrderScreen,arguments: '');
              },
              contentPadding: EdgeInsets.zero,
              leading: const CustomImage(path: Kimages.profileLocationIcon),
              title: const Text('Track Order', style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              minLeadingWidth: 0,
              onTap: () {
                Navigator.pushNamed(context, RouteNames.allCategoryListScreen);
              },
              contentPadding: EdgeInsets.zero,
              leading: const CustomImage(path: Kimages.profileCategoryIcon),
              title: const Text('All Category', style: TextStyle(fontSize: 16)),
            ),
            // ListTile(
            //   minLeadingWidth: 0,
            //   onTap: () {
            //     Navigator.pushNamed(context, RouteNames.notificationScreen);
            //   },
            //   contentPadding: EdgeInsets.zero,
            //   leading: const CustomImage(path: Kimages.profileNotificationIcon),
            //   title: const Text('Notification', style: TextStyle(fontSize: 16)),
            // ),
            // ListTile(
            //   onTap: () {
            //     Navigator.pushNamed(context, RouteNames.chatListScreen);
            //   },
            //   minLeadingWidth: 0,
            //   contentPadding: EdgeInsets.zero,
            //   leading: const CustomImage(path: Kimages.profileChatIcon),
            //   title: const Text('Chats', style: TextStyle(fontSize: 16)),
            // ),
            // ListTile(
            //   onTap: () {
            //     Navigator.pushNamed(context, RouteNames.paymentsScreen);
            //   },
            //   minLeadingWidth: 0,
            //   contentPadding: EdgeInsets.zero,
            //   leading: const CustomImage(path: Kimages.paymentIcon),
            //   title:
            //       const Text('Payment Methods', style: TextStyle(fontSize: 16)),
            // ),
            ListTile(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.changePasswordScreen);
              },
              minLeadingWidth: 0,
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.password_outlined, color: redColor),
              title:
                  const Text('Change password', style: TextStyle(fontSize: 16)),
            ),
            // ListTile(
            //   onTap: () {
            //     Navigator.pushNamed(context, RouteNames.settingScreen);
            //   },
            //   minLeadingWidth: 0,
            //   contentPadding: EdgeInsets.zero,
            //   leading: const CustomImage(path: Kimages.profileSettingIcon),
            //   title: const Text('Settings', style: TextStyle(fontSize: 16)),
            // ),
            ListTile(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.termsConditionScreen);
              },
              minLeadingWidth: 0,
              contentPadding: EdgeInsets.zero,
              leading:
                  const CustomImage(path: Kimages.profileTermsConditionIcon),
              title: const Text('Terms & Condition',
                  style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.privacyPolicyScreen);
              },
              minLeadingWidth: 0,
              contentPadding: EdgeInsets.zero,
              leading: const CustomImage(path: Kimages.profilePrivacyIcon),
              title:
                  const Text('Privacy Policy', style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.faqScreen);
              },
              minLeadingWidth: 0,
              contentPadding: EdgeInsets.zero,
              leading: const CustomImage(path: Kimages.profileFaqIcon),
              title: const Text('FAQ', style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.aboutUsScreen);
              },
              minLeadingWidth: 0,
              contentPadding: EdgeInsets.zero,
              leading: const CustomImage(path: Kimages.profileAboutUsIcon),
              title: const Text('About Us', style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.contactUsScreen);
              },
              minLeadingWidth: 0,
              contentPadding: EdgeInsets.zero,
              leading: const CustomImage(path: Kimages.profileContactIcon),
              title: const Text('Contact Us', style: TextStyle(fontSize: 16)),
            ),
            ListTile(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.accDeletionScreen);
              },
              minLeadingWidth: 0,
              contentPadding: EdgeInsets.zero,
              leading: const CustomImage(path: Kimages.profileContactIcon),
              title: const Text('Account Deletion', style: TextStyle(fontSize: 16)),
            ),
            // const ListTile(
            //   minLeadingWidth: 0,
            //   contentPadding: EdgeInsets.zero,
            //   leading: CustomImage(path: Kimages.profileAppInfoIcon),
            //   title: Text('App Info', style: TextStyle(fontSize: 16)),
            // ),
            BlocBuilder<LoginBloc, LoginModelState>(builder: (context, state) {
              if (state.state is LoginStateLogOutLoading) {
                const CircularProgressIndicator();
              }
              return ListTile(
                minLeadingWidth: 0,
                contentPadding: EdgeInsets.zero,
                leading: const CustomImage(path: Kimages.profileLogOutIcon),
                title: const Text('Sign Out', style: TextStyle(fontSize: 16)),
                onTap: () {
                  context.read<LoginBloc>().add(const LoginEventLogout());
                },
              );
            }),
          ],
        ),
      ),
    );
  }
}
