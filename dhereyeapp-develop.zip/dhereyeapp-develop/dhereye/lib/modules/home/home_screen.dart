import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:dhereye/modules/cart/controllers/cart/cart_cubit.dart';
import 'package:dhereye/utils/k_images.dart';
import '../../../core/router_name.dart';
import '../../../utils/constants.dart';
import '../../core/remote_urls.dart';
import '../../utils/utils.dart';
import '../cart/controllers/cart/add_to_cart/add_to_cart_cubit.dart';
import 'component/category_grid_view.dart';
import 'component/count_down_offer_and_product.dart';
import 'component/category_and_list_component.dart';
import 'component/flash_deal_component.dart';
import 'component/home_app_bar.dart';
import 'component/hot_deal_banner_slider.dart';
import 'component/new_arrival_component.dart';
import 'component/offer_banner_slider.dart';
import 'component/sponsor_component.dart';
import 'controller/cubit/home_controller_cubit.dart';
import 'model/home_model.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);
  final _className = 'HomeScreen';

  // final cartBloc = CartCubit(loginBloc: loginBloc, cartRepository: cartRepository)

  @override
  Widget build(BuildContext context) {
    return BlocListener<AddToCartCubit, AddToCartState>(
      listenWhen: (previous, current) => true,
      listener: (context, state) {
        if (state is AddToCartStateLoading) {
          Utils.loadingDialog(context);
        } else {
          Utils.closeDialog(context);
          if (state is AddToCartStateAdded) {
            Utils.showSnackBar(context, state.message);
            context.read<CartCubit>().getCartProducts();
          } else if (state is AddToCartStateError) {
            if (state.statusCode == 401) {
              Utils.showSnackBarWithAction(context, state.message,(){
                Navigator.pushNamed(context, RouteNames.authenticationScreen);
              },primaryColor,"Login");
            }else {
              Utils.errorSnackBar(context, state.message);
            }
          }
        }
      },
      child: Scaffold(
        body: BlocBuilder<HomeControllerCubit, HomeControllerState>(
          builder: (context, state) {
            log(state.toString(), name: _className);
            if (state is HomeControllerLoading) {
              return const Center(child: CircularProgressIndicator());
            }
            if (state is HomeControllerError) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      state.errorMessage,
                      style: const TextStyle(color: redColor),
                    ),
                    const SizedBox(height: 10),
                    IconButton(
                      onPressed: () {
                        context.read<HomeControllerCubit>().getHomeData();
                      },
                      icon: const Icon(Icons.refresh_outlined),
                    ),
                  ],
                ),
              );
            }

            if (state is HomeControllerLoaded) {
              return LoadedHomePage(homeModel: state.homeModel);
            }
            return const SizedBox();
          },
        ),
      ),
    );
  }
}

class LoadedHomePage extends StatelessWidget {
  LoadedHomePage({
    Key? key,
    required this.homeModel,
  }) : super(key: key);

  final HomeModel homeModel;

  final scrollController = ScrollController();
  final scrollController2 = ScrollController();

  void toTop(){
    scrollController2.animateTo(0,
        duration: const Duration(milliseconds: 500), curve: Curves.easeInOut);
  }

  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
  GlobalKey<RefreshIndicatorState>();

  @override
  Widget build(BuildContext context) {
    final routeName = ModalRoute.of(context)?.settings.name ?? '';
    const double appBarHeight = 140;
    return NestedScrollView(
      physics: const NeverScrollableScrollPhysics(),
      controller: scrollController,
      headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
        return <Widget>[
          SliverAppBar(
            expandedHeight: 140,
            automaticallyImplyLeading: routeName != RouteNames.mainPage,
            backgroundColor: Colors.transparent,
            floating: false,
            // snap: false,
            pinned: true,
            systemOverlayStyle:
            const SystemUiOverlayStyle(statusBarColor: Color(0xffE8EEF2),statusBarIconBrightness: Brightness.dark),
            flexibleSpace: HomeAppBar(
              height: appBarHeight,
              logo: Kimages.logoBG,
              onTap: (){
                toTop();
              },
              // logo: RemoteUrls.imageUrl(homeModel.setting.logo),
            ),
          ),
        ];
      },
      body: RefreshIndicator(
        key: _refreshIndicatorKey,
        color: Colors.white,
        backgroundColor: redColor,
        strokeWidth: 2.0,
        onRefresh: () => context.read<HomeControllerCubit>().getHomeDataOnRefresh(),
        child: CustomScrollView(
          controller: scrollController2,
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: OfferBannerSlider(sliders: homeModel.sliders),
            ),

            ///todo change... Brands
            // SliverToBoxAdapter(
            //   child: SponsorComponent(brands: homeModel.brands),
            // ),

            ///...... Countdown.........
            // const CountDownOfferAndProduct(),

            CategoryAndListComponent(
              productList: homeModel.topProducts,
              category: "Popular",
              onTap: () {
                Navigator.pushNamed(context, RouteNames.allPopulerProductScreen);
              },
            ),

            //// dumy data list categoryList
            CategoryGridView(
              categoryList: homeModel.productCategories.take(12).toList(),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 20,
              ),
            ),
            SliverToBoxAdapter(
              child: HotDealBannerSlider(
                banners: homeModel.banners.take(5).toList(),
              ),
            ),

            FlashDealComponent(
              productList: homeModel.flashDealProducts,
              category: "Xaarash",
              bgColor: const Color(0xff18587A),
              onTap: () {
                Navigator.pushNamed(context, RouteNames.allFlashDealProductScreen,
                    arguments: homeModel.flashDealProducts);
              },
            ),

            CategoryAndListComponent(
              productList: homeModel.firstCategory.products,
              category: homeModel.firstCategory.name,
              onTap: () {
                Navigator.pushNamed(context, RouteNames.singleCategoryProductScreen,
                    arguments: homeModel.firstCategory);
              },
            ),
            CategoryAndListComponent(
              productList: homeModel.secondCategory.products,
              category: homeModel.secondCategory.name,
              bgColor: const Color(0xffF1F5F7),
              onTap: () {
                Navigator.pushNamed(context, RouteNames.singleCategoryProductScreen,
                    arguments: homeModel.secondCategory);
              },
            ),
            CategoryAndListComponent(
              productList: homeModel.thirdCategory.products,
              category: homeModel.thirdCategory.name,
              onTap: () {
                Navigator.pushNamed(context, RouteNames.singleCategoryProductScreen,
                    arguments: homeModel.thirdCategory);
              },
            ),
            CategoryAndListComponent(
              productList: homeModel.fourthCategory.products,
              category: homeModel.fourthCategory.name,
              onTap: () {
                Navigator.pushNamed(context, RouteNames.singleCategoryProductScreen,
                    arguments: homeModel.fourthCategory);
              },
            ),

            NewArrivalComponent(productList: homeModel.newProducts,homeModel: homeModel,),

            const SliverToBoxAdapter(child: SizedBox(height: 65)),
          ],
        ),
      ),
    );
  }
}
//ATBBUc2drrxWVwwxzsEpzFxEpkt8E103ADEA
