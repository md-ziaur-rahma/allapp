import 'package:custom_pop_up_menu/custom_pop_up_menu.dart';
import 'package:flutter/material.dart';
import 'package:sliver_tools/sliver_tools.dart';
import 'package:dhereye/modules/home/model/home_model.dart';
import '../../../utils/k_images.dart';
import '../../../widgets/custom_image.dart';
import '../../category/component/product_card.dart';
import '../model/product_model.dart';

class NewArrivalComponent extends StatefulWidget {
  const NewArrivalComponent({
    Key? key,
    required this.productList, required this.homeModel,
  }) : super(key: key);
  final List<ProductModel> productList;
  final HomeModel homeModel;

  @override
  State<NewArrivalComponent> createState() => _NewArrivalComponentState();
}

class _NewArrivalComponentState extends State<NewArrivalComponent> {
  final _controller = CustomPopupMenuController();

  final List<String> list = <String>[
    'New Arrival',
    'Best Sellings',
    'Top Products',
    'Featured Products',
    'Flash Deal Products',
  ];

  var value = "";
  int index = 0;

  int getLength(index){
    if (index == 0) {
      return widget.homeModel.newProducts.length;
    }
    if (index == 1) {

      // todo change to best sell
      return widget.homeModel.bestSellProducts.length;
    }
    if (index == 2) {
      return widget.homeModel.topProducts.length;
    }
    if (index == 3) {
      // todo change to featured
      return widget.homeModel.featuredProducts.length;
    }
    if (index == 4) {
      return widget.homeModel.flashDealProducts.length;
    }
    return 0;
  }

  ProductModel getProduct(type,index){
    if (type == 0) {
      return widget.homeModel.newProducts[index];
    }
    if (type == 1) {

      // todo change to best sell
      return widget.homeModel.bestSellProducts[index];
    }
    if (type == 2) {
      return widget.homeModel.topProducts[index];
    }
    if (type == 3) {
      // todo change to featured
      return widget.homeModel.featuredProducts[index];
    }
    if (type == 4) {
      return widget.homeModel.flashDealProducts[index];
    }
    return widget.homeModel.newProducts[index];
  }

  @override
  void initState() {
    value = list[0];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      sliver: MultiSliver(
        children: [
          SliverToBoxAdapter(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    value,
                    style:
                    const TextStyle(fontSize: 18, height: 1.5, fontWeight: FontWeight.w600),
                  ),
                  CustomPopupMenu(
                    pressType: PressType.singleClick,
                    position: PreferredPosition.bottom,
                    showArrow: false,
                    verticalMargin: 4,
                    controller: _controller,
                    child: const SizedBox(
                      height: 24,
                      width: 24,
                      child: Center(child: CustomImage(path: Kimages.menuIcon)),
                    ),
                    menuOnChange: (val){

                    },
                    menuBuilder: () =>
                        ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: Container(
                            color: Colors.white,
                            width: 175,
                            height: 280,
                            alignment: Alignment.topLeft,
                            padding: const EdgeInsets.only(left: 12),
                            child: ListView(
                              shrinkWrap: true,
                              padding: EdgeInsets.zero,
                              children: list
                                  .map(
                                    (e) => InkWell(
                                  onTap: () {
                                    _controller.hideMenu();
                                    setState(() {
                                      value = e;
                                      index = list.indexOf(e);
                                    });
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8),
                                    child: Text(
                                      e,
                                      style: const TextStyle(fontSize: 16),
                                    ),
                                  ),
                                ),
                              )
                                  .toList(),
                            ),
                          ),
                        ),
                  ),
                ],
              ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 15)),
          SliverLayoutBuilder(
            builder: (context,constraints){
              if (getLength(index) > 0) {
                return SliverGrid(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    mainAxisExtent: 208,
                  ),
                  delegate: SliverChildBuilderDelegate(
                        (BuildContext context, int pIndex) =>
                        ProductCard(productModel:getProduct(index,pIndex)),
                    childCount: getLength(index),
                  ),
                );
              } else {
                return SliverToBoxAdapter(
                  child: SizedBox(
                    height: 150,
                    width: double.infinity,
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Colors.black54)
                        ),
                          child: const Text("Product Not Found",style: TextStyle(color: Colors.black54,fontSize: 16,fontWeight: FontWeight.w500),)),
                    ),
                  ),
                );
              }
            },
          )

        ],
      ),
    );
  }
}

class _NewArrivalHeader extends StatefulWidget {
  const _NewArrivalHeader({
    Key? key,
  }) : super(key: key);

  @override
  State<_NewArrivalHeader> createState() => _NewArrivalHeaderState();
}

class _NewArrivalHeaderState extends State<_NewArrivalHeader> {
  final _controller = CustomPopupMenuController();

  final List<String> list = <String>[
    'New Arrival',
    'Best Sellings',
    'Top Products',
    'Featured Products',
    'Flash Deal Products',
  ];

  var value = "";
  @override
  void initState() {
    value = list[0];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          value,
          style:
              const TextStyle(fontSize: 18, height: 1.5, fontWeight: FontWeight.w600),
        ),
        CustomPopupMenu(
          pressType: PressType.singleClick,
          position: PreferredPosition.bottom,
          showArrow: false,
          verticalMargin: 4,
          controller: _controller,
          child: const SizedBox(
            height: 24,
            width: 24,
            child: Center(child: CustomImage(path: Kimages.menuIcon)),
          ),
          menuOnChange: (val){

          },
          menuBuilder: () =>
              ClipRRect(
                borderRadius: BorderRadius.circular(5),
                child: Container(
                  color: Colors.white,
                  width: 175,
                  height: 280,
                  alignment: Alignment.topLeft,
                  padding: const EdgeInsets.only(left: 12),
                  child: ListView(
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    children: list
                        .map(
                          (e) => InkWell(
                        onTap: () {
                          _controller.hideMenu();
                          setState(() {
                            value = e;
                          });
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Text(
                            e,
                            style: const TextStyle(fontSize: 16),
                          ),
                        ),
                      ),
                    )
                        .toList(),
                  ),
                ),
              ),
        ),
      ],
    );
  }
}

