import 'package:custom_pop_up_menu/custom_pop_up_menu.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../utils/constants.dart';
import '../../utils/utils.dart';
import '../category/component/product_card.dart';
import 'components/rounded_app_bar.dart';
import 'controllers/search/search_bloc.dart';

class ProductSearchScreen extends StatefulWidget {
  const ProductSearchScreen({Key? key}) : super(key: key);

  @override
  State<ProductSearchScreen> createState() => ProductSearchScreenState();
}

class ProductSearchScreenState extends State<ProductSearchScreen> {
  @override
  void initState() {
    super.initState();
    _init();
  }

  void _init() {
    _controller.addListener(() {
      final maxExtent = _controller.position.maxScrollExtent - 200;
      if (maxExtent < _controller.position.pixels) {
        searchBloc.add(const SearchEventLoadMore());
      }
    });
  }

  final searchCtr = TextEditingController();
  final _controller = ScrollController();

  late SearchBloc searchBloc;

  @override
  void dispose() {
    super.dispose();
    searchBloc.products.clear();
  }

  final brandMenuController = CustomPopupMenuController();
  final categoryMenuController = CustomPopupMenuController();
  final sortingMenuController = CustomPopupMenuController();

  @override
  Widget build(BuildContext context) {
    searchBloc = context.read<SearchBloc>();

    return Scaffold(
      appBar: SearchAppBar(
        titleWidget: Container(
          margin: const EdgeInsets.only(right: 20),
          height: 40,
          child: TextFormField(
            controller: searchCtr,
            textInputAction: TextInputAction.search,
            autofocus: true,
            onChanged: (v) {
              if (v.isEmpty) return;
              context.read<SearchBloc>().add(SearchEventSearch(v.trim()));
            },
            onFieldSubmitted: (v) {
              if (v.isEmpty) return;
              context.read<SearchBloc>().add(SearchEventSearch(v.trim()));
            },
            decoration: const InputDecoration(
                contentPadding: EdgeInsets.all(8),
                hintText: "Search here",
                suffixIcon: Icon(Icons.search)),
          ),
        ),
      ),
      body: BlocConsumer<SearchBloc, SearchState>(
        listener: (context, state) {
          if (state is SearchStateMoreError) {
            Utils.errorSnackBar(context, state.message);
          }
        },
        builder: (context, state) {
          final products = searchBloc.products;
          if (searchBloc.products.isEmpty && state is SearchStateLoading) {
          // if (state is SearchStateLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is SearchStateError) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Center(
                  child: Text(
                    state.message,
                    style: const TextStyle(color: redColor),
                  ),
                ),
              ],
            );
          } else if (searchBloc.products.isEmpty &&
              state is SearchStateLoaded) {
            return const Center(
              child: Text(
                "Product Not Found!",
                style: TextStyle(
                    color: redColor, fontSize: 16, fontWeight: FontWeight.w500),
              ),
            );
          }
          return Column(
            children: [
              if (searchBloc.brandList.isNotEmpty &&
                      searchBloc.categoryList.isNotEmpty ||
                  state is SearchStateLoaded)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(color: Colors.white, boxShadow: [
                    BoxShadow(
                        blurRadius: 6,
                        color: Colors.grey.withOpacity(0.2),
                        offset: const Offset(0, 1),
                        blurStyle: BlurStyle.outer)
                  ]),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      CustomPopupMenu(
                          pressType: PressType.singleClick,
                          position: PreferredPosition.bottom,
                          showArrow: false,
                          verticalMargin: 4,
                          horizontalMargin: 0,
                          controller: brandMenuController,
                          // barrierColor: Colors.transparent,
                          child: Material(
                            // borderRadius: BorderRadius.circular(30),
                            color: const Color(0xFFF2F2F2),
                            shape: const StadiumBorder(),
                            borderOnForeground: true,
                            child: InkWell(
                              borderRadius: BorderRadius.circular(30),
                              onTap: () {
                                if (searchBloc.brandList.isNotEmpty) {
                                  brandMenuController.showMenu();
                                }
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                    // border: Border.all(color: Colors.black54),
                                    borderRadius: BorderRadius.circular(30)),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8.0, vertical: 4),
                                child: Row(
                                  children: const [
                                    Text(
                                      "Brands",
                                      style: TextStyle(
                                          color: Colors.black54, fontSize: 13),
                                    ),
                                    SizedBox(
                                      width: 8,
                                    ),
                                    Icon(
                                      Icons.arrow_drop_down_rounded,
                                      size: 18,
                                      color: Colors.black54,
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                          menuOnChange: (val) {},
                          menuBuilder: () => StatefulBuilder(
                                  builder: (stateContext, setState) {
                                return Container(
                                  // height: 200,
                                  width: double.infinity,
                                  decoration: const BoxDecoration(
                                    color: Colors.white,
                                  ),
                                  child: Column(
                                    children: [
                                      GridView.builder(
                                        shrinkWrap: true,
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 10),
                                        gridDelegate:
                                            const SliverGridDelegateWithFixedCrossAxisCount(
                                                crossAxisCount: 2,
                                                mainAxisSpacing: 0,
                                                crossAxisSpacing: 10,
                                                mainAxisExtent: 40),
                                        itemBuilder: (context, index) {
                                          return GestureDetector(
                                            onTap: () {
                                              setState(() {
                                                searchBloc.addFilterBrand(
                                                    searchBloc
                                                        .brandList[index]);
                                              });
                                              if (kDebugMode) {
                                                print(
                                                    "${searchBloc.filterBrandList.length}");
                                              }
                                            },
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Row(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Expanded(
                                                      child: Text(
                                                        searchBloc
                                                            .brandList[index]
                                                            .name,
                                                        style: TextStyle(
                                                            color: searchBloc.isAdded(
                                                                    searchBloc
                                                                            .brandList[
                                                                        index])
                                                                ? redColor
                                                                : Colors
                                                                    .black54,
                                                            fontSize: 13,
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500),
                                                      ),
                                                    ),
                                                    Icon(
                                                      Icons.check,
                                                      size: 16,
                                                      color: searchBloc.isAdded(
                                                              searchBloc
                                                                      .brandList[
                                                                  index])
                                                          ? redColor
                                                          : Colors.transparent,
                                                    )
                                                  ],
                                                ),
                                                Divider(
                                                  height: 16,
                                                  color: searchBloc.isAdded(
                                                          searchBloc
                                                              .brandList[index])
                                                      ? redColor
                                                      : Colors.grey[300],
                                                )
                                              ],
                                            ),
                                          );
                                        },
                                        itemCount: searchBloc.brandList.length,
                                      ),
                                      Row(
                                        children: [
                                          const SizedBox(
                                            width: 20,
                                          ),
                                          Expanded(
                                            child: SizedBox(
                                              height: 35,
                                              child: OutlinedButton(
                                                style: OutlinedButton.styleFrom(
                                                    side: BorderSide(
                                                        color: Colors.black54)),
                                                onPressed: () {
                                                  setState(() {
                                                    searchBloc.filterBrandList
                                                        .clear();
                                                    context
                                                        .read<SearchBloc>()
                                                        .add(SearchEventSearch(
                                                            searchCtr.text
                                                                .trim()));
                                                  });
                                                  brandMenuController
                                                      .hideMenu();
                                                },
                                                child: const Text(
                                                  "Reset",
                                                  style: TextStyle(
                                                      color: Colors.black54,
                                                      fontSize: 13),
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(
                                            width: 20,
                                          ),
                                          Expanded(
                                            child: SizedBox(
                                              height: 35,
                                              child: ElevatedButton(
                                                onPressed: () {
                                                  List<String> brands =
                                                      searchBloc.filterBrandList
                                                          .map((e) => e.slug)
                                                          .toSet()
                                                          .toList();
                                                  context
                                                      .read<SearchBloc>()
                                                      .add(SearchEventWithBrand(
                                                          brands,
                                                          searchCtr.text
                                                              .trim()));
                                                  brandMenuController
                                                      .hideMenu();
                                                },
                                                child: const Text(
                                                  "Apply",
                                                  style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 13),
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(
                                            width: 20,
                                          ),
                                        ],
                                      ),
                                      const SizedBox(
                                        height: 10,
                                      )
                                    ],
                                  ),
                                );
                              })),
                      const SizedBox(
                        width: 10,
                      ),
                      CustomPopupMenu(
                          pressType: PressType.singleClick,
                          position: PreferredPosition.bottom,
                          showArrow: false,
                          verticalMargin: 4,
                          horizontalMargin: 0,
                          controller: categoryMenuController,
                          // barrierColor: Colors.transparent,
                          child: Material(
                            // borderRadius: BorderRadius.circular(30),
                            color: const Color(0xFFF2F2F2),
                            shape: const StadiumBorder(),
                            borderOnForeground: true,
                            child: InkWell(
                              borderRadius: BorderRadius.circular(30),
                              onTap: () {
                                if (searchBloc.categoryList.isNotEmpty) {
                                  categoryMenuController.showMenu();
                                }
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                    // border: Border.all(color: Colors.black54),
                                    borderRadius: BorderRadius.circular(30)),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8.0, vertical: 4),
                                child: Row(
                                  children: const [
                                    Text(
                                      "Categories",
                                      style: TextStyle(
                                          color: Colors.black54,
                                          fontSize: 13,
                                          fontWeight: FontWeight.w500),
                                    ),
                                    SizedBox(
                                      width: 8,
                                    ),
                                    Icon(
                                      Icons.arrow_drop_down_rounded,
                                      size: 18,
                                      color: Colors.black54,
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                          menuOnChange: (val) {},
                          menuBuilder: () => Container(
                                // height: 200,
                                width: double.infinity,
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                ),
                                child: Column(
                                  children: [
                                    GridView.builder(
                                      shrinkWrap: true,
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10, vertical: 10),
                                      gridDelegate:
                                          const SliverGridDelegateWithFixedCrossAxisCount(
                                              crossAxisCount: 2,
                                              mainAxisSpacing: 0,
                                              crossAxisSpacing: 10,
                                              mainAxisExtent: 40),
                                      itemBuilder: (context, index) {
                                        return GestureDetector(
                                          onTap: () {
                                            context.read<SearchBloc>().add(SearchEventWithCategory(searchBloc.categoryList[index].slug, searchCtr.text.trim()));
                                            categoryMenuController.hideMenu();
                                          },
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                searchBloc
                                                    .categoryList[index].name,
                                                style: const TextStyle(
                                                    color: Colors.black54,
                                                    fontSize: 13),
                                              ),
                                              const Divider(
                                                color: Colors.transparent,
                                                height: 16,
                                              )
                                            ],
                                          ),
                                        );
                                      },
                                      itemCount: searchBloc.categoryList.length,
                                    ),
                                  ],
                                ),
                              )),
                      const SizedBox(
                        width: 10,
                      ),
                      CustomPopupMenu(
                          pressType: PressType.singleClick,
                          position: PreferredPosition.bottom,
                          showArrow: false,
                          verticalMargin: 4,
                          horizontalMargin: 0,
                          controller: sortingMenuController,
                          // barrierColor: Colors.transparent,
                          child: Material(
                            // borderRadius: BorderRadius.circular(30),
                            color: const Color(0xFFF2F2F2),
                            shape: const StadiumBorder(),
                            borderOnForeground: true,
                            child: InkWell(
                              borderRadius: BorderRadius.circular(30),
                              onTap: () {
                                if (searchBloc.categoryList.isNotEmpty) {
                                  sortingMenuController.showMenu();
                                }
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                    // border: Border.all(color: Colors.black54),
                                    borderRadius: BorderRadius.circular(30)),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8.0, vertical: 4),
                                child: Row(
                                  children: const [
                                    Text(
                                      "Sorting",
                                      style: TextStyle(
                                          color: Colors.black54,
                                          fontSize: 13,
                                          fontWeight: FontWeight.w500),
                                    ),
                                    SizedBox(
                                      width: 8,
                                    ),
                                    Icon(
                                      Icons.arrow_drop_down_rounded,
                                      size: 18,
                                      color: Colors.black54,
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                          menuOnChange: (val) {},
                          menuBuilder: () => StatefulBuilder(
                            builder: (context,setState) {
                              return ConstrainedBox(
                                constraints: BoxConstraints(
                                  minHeight: MediaQuery.of(context).size.width,
                                ),
                                child: Container(
                                      width: double.infinity,
                                      decoration: const BoxDecoration(
                                        color: Colors.white,
                                      ),
                                      padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          const Text("Price Sorting",style: TextStyle(color: redColor,fontSize: 18,fontWeight: FontWeight.w600),),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Wrap(
                                            spacing: 16,
                                            runSpacing: 16,
                                            children: [
                                              ...List.generate(searchBloc.sortingList.length, (index) {
                                                return Material(
                                                  borderRadius: BorderRadius.circular(30),
                                                  color: index == searchBloc.sortingId-1 ? redColor : Colors.transparent,
                                                  child: InkWell(
                                                    borderRadius: BorderRadius.circular(30),
                                                    onTap: (){
                                                      searchBloc.sortingText = searchBloc.sortingList[index];
                                                      searchBloc.changeSortingValue(searchBloc.sortingList[index]);
                                                      context.read<SearchBloc>().add(SearchEventSearch(searchCtr.text.trim()));
                                                      // sortingMenuController.hideMenu();
                                                    },
                                                    child: Container(
                                                      padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
                                                      decoration: BoxDecoration(
                                                        border: Border.all(color: redColor),
                                                        borderRadius: BorderRadius.circular(30),
                                                      ),
                                                      child: Text(searchBloc.sortingList[index],style: TextStyle(color: index == searchBloc.sortingId-1 ? Colors.white : redColor),),
                                                    ),
                                                  ),
                                                );
                                              })
                                            ],
                                          ),
                                          const SizedBox(
                                            height: 24,
                                          ),
                                          const Text("Price Range",style: TextStyle(color: redColor,fontSize: 18,fontWeight: FontWeight.w600),),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Row(
                                            children: [
                                              Text("${searchBloc.rangeValues.start.round().toString()} \$",style: TextStyle(color: redColor,fontSize: 14,fontWeight: FontWeight.w400),),
                                              const SizedBox(
                                                width: 0,
                                              ),
                                              Expanded(
                                                child: RangeSlider(
                                                  max: 20000,
                                                    min: 0,
                                                    divisions: 1000,
                                                    inactiveColor: const Color(0xFFF4F4F4),
                                                    activeColor: redColor,
                                                    values: searchBloc.rangeValues,
                                                    onChanged: (val){
                                                    setState((){
                                                      searchBloc.rangeValues = val;
                                                    });
                                                    },
                                                  labels: RangeLabels(
                                                      "${searchBloc.rangeValues.start.round().toString()} \$",
                                                      "${searchBloc.rangeValues.end.round().toString()} \$"
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(
                                                width: 0,
                                              ),
                                              Text("${searchBloc.rangeValues.end.round().toString()} \$",style: const TextStyle(color: redColor,fontSize: 14,fontWeight: FontWeight.w500),),
                                            ],
                                          ),
                                          const SizedBox(
                                            height: 16,
                                          ),
                                          Align(
                                            alignment: Alignment.bottomRight,
                                            child: ConstrainedBox(
                                              constraints: const BoxConstraints(
                                                maxHeight: 40,
                                                maxWidth: 150
                                              ),
                                              child: ElevatedButton(
                                                onPressed: (){
                                                  context.read<SearchBloc>().add(SearchEventSearch(searchCtr.text.trim()));
                                                  sortingMenuController.hideMenu();
                                                },
                                                child: const Text("Apply",style: TextStyle(color: Colors.white),),
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                              );
                            }
                          )),
                    ],
                  ),
                ),
              Expanded(
                child: GridView.builder(
                  controller: _controller,
                  padding: const EdgeInsets.all(15),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    mainAxisExtent: 208,
                  ),
                  itemCount: products.length,
                  itemBuilder: (BuildContext context, int index) {
                    return ProductCard(productModel: products[index]);
                  },
                ),
              ),
              if (state is SearchStateLoadMore)
                Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: const CircularProgressIndicator()),
            ],
          );
        },
      ),
    );
  }
}
