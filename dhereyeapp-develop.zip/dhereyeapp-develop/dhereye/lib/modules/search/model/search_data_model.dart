import 'dart:convert';

import 'package:equatable/equatable.dart';
import 'package:dhereye/modules/category/model/product_categories_model.dart';
import 'package:dhereye/modules/home/model/brand_model.dart';
import 'package:dhereye/modules/product_details/model/seller_model.dart';
import 'package:dhereye/modules/search/model/search_response_model.dart';

class SearchDataModel extends Equatable {
  final SearchResponseModel products;
  final List<BrandModel> brandList;
  final int totalReview;
  final List<ProductCategoriesModel> categoryList;
  const SearchDataModel({
    required this.products,
    required this.brandList,
    required this.totalReview,
    required this.categoryList,
  });

  SearchDataModel copyWith({
    SellerModel? seller,
    SearchResponseModel? products,
    List<BrandModel>? brandList,
    int? totalReview,
    List<ProductCategoriesModel>? categoryList,
  }) {
    return SearchDataModel(
      products: products ?? this.products,
      brandList: brandList ?? this.brandList,
      totalReview: totalReview ?? 0,
      categoryList: categoryList ?? this.categoryList,
    );
  }

  Map<String, dynamic> toMap() {
    final result = <String, dynamic>{};

    result.addAll({'products': products.toMap()});
    result.addAll({'productCategories': categoryList.map((x) => x.toMap()).toList()});
    result.addAll({'totalReview': totalReview});
    result.addAll({'brands': brandList.map((x) => x.toMap()).toList()});

    return result;
  }

  factory SearchDataModel.fromMap(Map<String, dynamic> map) {
    return SearchDataModel(
      products: SearchResponseModel.fromMap(map['products']),
      categoryList: map['productCategories'] != null
          ? List<ProductCategoriesModel>.from(
          map['productCategories']?.map((x) => ProductCategoriesModel.fromMap(x)))
          : [],
      totalReview: map["totalReview"] ?? 0,
      brandList: map['brands'] != null
          ? List<BrandModel>.from(
          map['brands']?.map((x) => BrandModel.fromMap(x)))
          : [],
    );
  }

  String toJson() => json.encode(toMap());

  factory SearchDataModel.fromJson(String source) =>
      SearchDataModel.fromMap(json.decode(source));

  @override
  String toString() {
    return 'StoreModel(products: $products, productCategories: $categoryList, totalReview: $totalReview brands: $brandList)';
  }

  @override
  List<Object> get props {
    return [
      products,
      categoryList,
      totalReview,
      brandList,
    ];
  }
}