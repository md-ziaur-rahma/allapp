part of 'search_bloc.dart';

abstract class SearchEvent extends Equatable {
  const SearchEvent();

  @override
  List<Object> get props => [];
}

class SearchEventSearch extends SearchEvent {
  final String search;
  const SearchEventSearch(this.search);

  @override
  List<Object> get props => [search];
}

class SearchEventWithBrand extends SearchEvent {
  final List<String> brands;
  final String search;
  const SearchEventWithBrand(this.brands,this.search);

  @override
  List<Object> get props => [brands];
}

class SearchEventWithCategory extends SearchEvent {
  final String category;
  final String search;
  const SearchEventWithCategory(this.category,this.search);

  @override
  List<Object> get props => [category];
}

class SearchEventLoadMore extends SearchEvent {
  const SearchEventLoadMore();
}
