import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart';
import 'package:dhereye/modules/category/model/product_categories_model.dart';
import 'package:dhereye/modules/home/model/brand_model.dart';
import 'package:flutter/material.dart';
import '../../../../core/remote_urls.dart';
import '../../../../utils/constants.dart';
import '../../../home/model/product_model.dart';
import '../../model/search_data_model.dart';
import '../../model/search_response_model.dart';
import '../search_repository.dart';

import 'package:stream_transform/stream_transform.dart';
part 'search_event.dart';
part 'search_state.dart';

class SearchBloc extends Bloc<SearchEvent, SearchState> {
  final SearchRepository _searchRepository;

  // SearchResponseModel? _searchResponseModel;
  SearchDataModel? searchDataModel;
  List<ProductModel> products = [];
  List<BrandModel> brandList = [];
  List<ProductCategoriesModel> categoryList = [];

  List<BrandModel> filterBrandList = [];
  RangeValues rangeValues = const RangeValues(0,20000);
  List<String> sortingList = ['Default Sorting','Low To High Price','High To Low Price'];
  String sortingText = 'Default Sorting';
  int sortingId = 1;
  void changeSortingValue(String value){
    sortingId = sortingList.indexOf(value)+1;
    print("vvvvvvvvvvvvvvv $sortingId");
  }
  bool isAdded(BrandModel brandModel){
    return filterBrandList.any((element) => element.id == brandModel.id);
  }
  void addFilterBrand(BrandModel brandModel){
    if (isAdded(brandModel)) {
      filterBrandList.remove(brandModel);
    } else {
      filterBrandList.add(brandModel);
    }
  }

  SearchBloc({
    required SearchRepository searchRepository,
  })  : _searchRepository = searchRepository,
        super(const SearchStateInitial()) {
    on<SearchEventSearch>(_search, transformer: debounce());
    on<SearchEventWithBrand>(_searchWithBrands, transformer: debounce());
    on<SearchEventWithCategory>(_searchWithCategory, transformer: debounce());
    on<SearchEventLoadMore>(_loadMore);
  }

  void _search(SearchEventSearch event, Emitter<SearchState> emit) async {
    emit(const SearchStateLoading());

    final uri = Uri.parse(RemoteUrls.searchProduct).replace(
      queryParameters: {'search': event.search,'price_range': "${rangeValues.start.round().toString()};${rangeValues.end.round().toString()}",'shorting_id': sortingId.toString()},
    );

    if (kDebugMode) {
      print(uri);
    }

    final result = await _searchRepository.search(uri);

    result.fold((failure) {
      emit(SearchStateError(failure.message, failure.statusCode));
    }, (successData) {
      searchDataModel = successData;

      products = successData.products.products;
      brandList = successData.brandList;
      categoryList = successData.categoryList;

      emit(SearchStateLoaded(successData.products.products));
    });
  }

  void _searchWithBrands(SearchEventWithBrand event, Emitter<SearchState> emit) async {
    emit(const SearchStateLoading());

    final uri = Uri.parse(RemoteUrls.searchProduct).replace(
      queryParameters: {'search': event.search,'brand': event.brands,
        'price_range': "${rangeValues.start.round().toString()};${rangeValues.end.round().toString()}",'shorting_id': sortingId.toString()},
    );

    if (kDebugMode) {
      print(uri);
    }

    final result = await _searchRepository.search(uri);

    result.fold((failure) {
      emit(SearchStateError(failure.message, failure.statusCode));
    }, (successData) {
      searchDataModel = successData;

      products = successData.products.products;
      brandList = successData.brandList;
      categoryList = successData.categoryList;

      emit(SearchStateLoaded(successData.products.products));
    });
  }

  void _searchWithCategory(SearchEventWithCategory event, Emitter<SearchState> emit) async {
    emit(const SearchStateLoading());

    final uri = Uri.parse(RemoteUrls.searchProduct).replace(
      queryParameters: {'search': event.search,'category': event.category,
        'price_range': "${rangeValues.start.round().toString()};${rangeValues.end.round().toString()}",'shorting_id': sortingId.toString()},
    );

    if (kDebugMode) {
      print(uri);
    }

    final result = await _searchRepository.search(uri);

    result.fold((failure) {
      emit(SearchStateError(failure.message, failure.statusCode));
    }, (successData) {
      searchDataModel = successData;

      products = successData.products.products;
      brandList = successData.brandList;
      categoryList = successData.categoryList;

      emit(SearchStateLoaded(successData.products.products));
    });
  }

  void _loadMore(SearchEventLoadMore event, Emitter<SearchState> emit) async {
    if (state is SearchStateLoadMore) return;
    if (searchDataModel == null ||
        searchDataModel?.products.nextPageUrl == null) {
      return;
    }

    emit(const SearchStateLoadMore());

    final uri = Uri.parse(searchDataModel!.products.nextPageUrl!);

    final result = await _searchRepository.search(uri);

    result.fold(
      (failure) {
        emit(SearchStateMoreError(failure.message, failure.statusCode));
      },
      (successData) {
        searchDataModel = successData;
        products.addAll(successData.products.products);

        emit(SearchStateMoreLoaded(products.toSet().toList()));
      },
    );
  }
}

EventTransformer<Event> debounce<Event>() {
  return (events, mapper) => events.debounce(kDuration).switchMap(mapper);
}
