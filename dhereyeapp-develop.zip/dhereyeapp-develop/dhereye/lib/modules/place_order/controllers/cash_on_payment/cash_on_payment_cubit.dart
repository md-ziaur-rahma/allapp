import 'package:bloc/bloc.dart';
import 'package:dhereye/modules/cart/controllers/cart/cart_cubit.dart';
import 'package:equatable/equatable.dart';
import '../../../../core/remote_urls.dart';
import '../../../authentication/controller/login/login_bloc.dart';
import '../payment_repository.dart';
part 'cash_on_payment_state.dart';

class CashOnPaymentCubit extends Cubit<CashPaymentState> {
  final LoginBloc _loginBloc;
  final PaymentRepository _paymentRepository;
  final CartCubit _cartBloc;
  CashOnPaymentCubit({
    required LoginBloc loginBloc,
    required PaymentRepository paymentRepository,
    required CartCubit cartBloc,
  })  : _loginBloc = loginBloc,
        _paymentRepository = paymentRepository,
        _cartBloc = cartBloc,
        super(const CashPaymentStateInitial());

  Future<void> cashOnDelivery(shippingMethod) async {
    if (_loginBloc.userInfo == null) {
      emit(const CashPaymentStateError('Please login', 401));
      return;
    }

    emit(const CashPaymentStateLoading());

    final uri = Uri.parse(RemoteUrls.cashOnDelivery).replace(
      queryParameters: {
        'token': _loginBloc.userInfo!.accessToken,
        'shipping_method': shippingMethod,
        'agree_terms_condition': '1',
      },
    );

    print(uri);

    final result = await _paymentRepository.cashOnDelivery(uri);

    result.fold(
      (failure) {
        emit(CashPaymentStateError(failure.message, failure.statusCode));
      },
      (successData) {
        _cartBloc.getCartProducts();
        emit(CashPaymentStateLoaded(successData));
      },
    );
  }
}
