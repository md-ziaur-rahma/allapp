import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../authentication/controller/login/login_bloc.dart';
import '../../../cart/controllers/cart/cart_cubit.dart';
import '../payment_repository.dart';

part 'stripe_state.dart';

class StripeCubit extends Cubit<StripeState> {
  final PaymentRepository _paymentRepository;

  final LoginBloc _loginBloc;
  final CartCubit _cartCubit;

  StripeCubit({
    required LoginBloc loginBloc,
    required PaymentRepository paymentRepository,
    required CartCubit cartCubit,
  })  : _paymentRepository = paymentRepository,
        _loginBloc = loginBloc,
        _cartCubit = cartCubit,
        super(const StripeInitial());

  Future<void> callStripe(Map<String, String> body) async {
    emit(const StripeLoading());
    final result = await _paymentRepository.stripePay(
        _loginBloc.userInfo!.accessToken, body);

    result.fold((failure) {
      emit(StripeError(failure.message, failure.statusCode));
    }, (data) {
      _cartCubit.getCartProducts();
      emit(StripeLoaded(data));
    });
  }
}
