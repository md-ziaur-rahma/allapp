import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:dhereye/core/router_name.dart';
import 'package:dhereye/modules/authentication/controller/login/login_bloc.dart';
import 'package:dhereye/modules/authentication/widgets/sign_in_form.dart';
import 'package:dhereye/utils/constants.dart';
import 'package:dhereye/utils/k_images.dart';
import 'package:dhereye/utils/utils.dart';
import 'package:dhereye/widgets/custom_image.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key}) : super(key: key);

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final tabUnSelectedTextColor = const Color(0xff797979);
  @override
  Widget build(BuildContext context) {
    return BlocListener<LoginBloc, LoginModelState>(
      listenWhen: (previous, current) => previous.state != current.state,
      listener: (context, state) {
        if (state.state is LoginStateError) {
          final status = state.state as LoginStateError;

          if (status.statusCode == 402) {
            Utils.showSnackBarWithAction(
              context,
              status.errorMsg,
                  () {
                context
                    .read<LoginBloc>()
                    .add(const SentAccountActivateCodeSubmit());
                Navigator.pushNamed(
                    context, RouteNames.verificationCodeScreen);
              },
            );
          } else {
            Utils.errorSnackBar(context, status.errorMsg);
          }
        } else if (state.state is LoginStateLoaded) {
          Navigator.pushReplacementNamed(context, RouteNames.mainPage);
        } else if (state.state is SendAccountCodeSuccess) {
          final messageState = state.state as SendAccountCodeSuccess;
          Utils.showSnackBar(context, messageState.msg);
        } else if (state.state is AccountActivateSuccess) {
          final messageState = state.state as AccountActivateSuccess;
          Utils.showSnackBar(context, messageState.msg);
          Navigator.pop(context);
        }
      },
      child: Scaffold(
        body: SafeArea(
          child: Container(
            height: MediaQuery.of(context).size.height,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomRight,
                colors: [Colors.white, Color(0xffFFEFE7)],
              ),
            ),
            child: CustomScrollView(
              scrollDirection: Axis.vertical,
              slivers: [
                SliverToBoxAdapter(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CustomImage(
                        // path: RemoteUrls.imageUrl(appSetting.settingModel!.logo),
                        path: Kimages.logoColor,
                        width: 280,
                        height: 110,
                      ),
                      AnimatedContainer(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        alignment: Alignment.topLeft,
                        duration: kDuration,
                        child: const Center(
                          child: Text("Welcome back!",
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
                          ),
                        ),
                      ),
                      const SizedBox(height: 15),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            InkWell(
                              onTap: () {
                                // _pageController.animateToPage(0,
                                //     duration: kDuration, curve: Curves.bounceInOut);
                              },
                              child: const Text(
                                'Sign In',
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                    color: blackColor),
                              ),
                            ),
                            Container(
                              color: borderColor,
                              width: 1,
                              height: 20,
                              margin: const EdgeInsets.symmetric(horizontal: 16),
                            ),
                            InkWell(
                              onTap: () {
                                // _pageController.animateToPage(1,
                                //     duration: kDuration, curve: Curves.bounceInOut);
                              },
                              child: Text(
                                'Sign Up',
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                    color: tabUnSelectedTextColor),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SigninForm(),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
