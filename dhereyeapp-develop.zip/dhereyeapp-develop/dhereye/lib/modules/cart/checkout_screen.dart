import 'dart:async';

import 'package:dhereye/modules/authentication/controller/login/login_bloc.dart';
import 'package:dhereye/modules/map/map_cubit.dart';
import 'package:dhereye/modules/place_order/place_order_screen.dart';
import 'package:dhereye/modules/profile/controllers/country_state_by_id/country_state_by_id_cubit.dart';
import 'package:dhereye/modules/profile/model/address_model.dart';
import 'package:dhereye/modules/profile/model/city_model.dart';
import 'package:dhereye/modules/profile/model/country_model.dart';
import 'package:dhereye/modules/profile/model/country_state_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../core/router_name.dart';
import '../../utils/constants.dart';
import '../../utils/utils.dart';
import '../../widgets/page_refresh.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/rounded_app_bar.dart';
import '../map/map_view.dart';
import 'component/address_card_component.dart';
import 'component/checkout_single_item.dart';
import 'component/shiping_method_list.dart';
import 'controllers/checkout/checkout_cubit.dart';
import 'model/checkout_response_model.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({Key? key}) : super(key: key);

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      context.read<CheckoutCubit>().getCheckOutData(true);
    });
    // Future.microtask(() => context.read<CheckoutCubit>().setMarkerIcon(kLatLng.latitude,kLatLng.longitude));
    // Future.microtask(() => context.read<CheckoutCubit>().getCheckOutData(true));
    // Future.microtask(() => context.read<MapCubit>().getCurrentLocation());
    // Future.microtask(() => context.read<CheckoutCubit>().getCurrentLocation());
    // todo use current lat lng ........... and use one micro task
  }

  @override
  void dispose() {

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: RoundedAppBar(titleText: 'Checkout'),
      body: BlocBuilder<CheckoutCubit, CheckoutState>(
        builder: (context, state) {
          if (state is CheckoutStateLoading || state is CheckoutStateInitial) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is CheckoutStateError) {
            return Center(
              child: Text(
                state.message,
                style: const TextStyle(color: redColor),
              ),
            );
          } else if (state is CheckoutStateLoaded) {
            return _LoadedWidget(
                checkoutResponseModel: state.checkoutResponseModel);
          }
          return const SizedBox();
        },
      ),
    );
  }
}

class _LoadedWidget extends StatefulWidget {
  const _LoadedWidget({
    Key? key,
    required this.checkoutResponseModel,
  }) : super(key: key);

  final CheckoutResponseModel checkoutResponseModel;

  @override
  State<_LoadedWidget> createState() => _LoadedWidgetState();
}

class _LoadedWidgetState extends State<_LoadedWidget> {
  final double height = 140;

  final headerStyle =
      const TextStyle(fontSize: 16, fontWeight: FontWeight.w600);

  // late CheckoutResponseModel checkoutResponseModel;

  int shippingMethod = 0;
  int agreeTermsCondition = 1;

  int isManual = 0;

  //.................. Shipping Address ....................
  CountryModel? _countryModel;
  CountryStateModel? _countryStateModel;
  CityModel? _cityModel;
  AddressModel? addressModel;

  final nameCtr = TextEditingController();
  final emailCtr = TextEditingController();
  final phoneCtr = TextEditingController();
  final addressCtr = TextEditingController();
  final zipCtr = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  List<CountryModel> countries = [];

  @override
  void initState() {
    super.initState();
    Future.microtask(() => context.read<MapCubit>().getCurrentLocation());
    makeFormData();
  }

  final scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return PageRefresh(
      onTap: () => context.read<CheckoutCubit>().getCheckOutData(false),
      child: Column(
        children: [
          Expanded(
            child: CustomScrollView(
              controller: scrollController,
              physics: const ClampingScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(child: _buildProductNumber()),
                _buildProductList(),
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                  sliver: SliverToBoxAdapter(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("Select Your Shipping Address Entry Method",style: TextStyle(color: blackColor,fontSize: 16,fontWeight: FontWeight.w500),),
                        const SizedBox(
                          height: 10,
                        ),
                        Material(
                          borderRadius: BorderRadius.circular(3),
                          color: whiteColor,
                          child: InkWell(
                            borderRadius: BorderRadius.circular(3),
                            onTap: (){
                              setState(() {
                                isManual = 0;
                              });
                            },
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                              decoration: BoxDecoration(
                                border: Border.all(color: isManual == 0 ? redColor : blackColor,),
                                borderRadius: BorderRadius.circular(3)
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  CircleAvatar(
                                    radius: 12,
                                    backgroundColor: isManual == 0 ? redColor : blackColor,
                                    child: CircleAvatar(
                                        backgroundColor: Colors.white,
                                        radius: 11,child: Center(child: Icon(Icons.circle,size: 18,
                                      color: isManual == 0 ? redColor : whiteColor,))),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  const Text("From Google Map",style: TextStyle(),),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 16,
                        ),
                        Material(
                          borderRadius: BorderRadius.circular(3),
                          color: whiteColor,
                          child: InkWell(
                            borderRadius: BorderRadius.circular(3),
                            onTap: (){
                              setState(() {
                                isManual = 1;
                              });
                            },
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                              decoration: BoxDecoration(
                                  border: Border.all(color: isManual == 1 ? redColor : blackColor,),
                                  borderRadius: BorderRadius.circular(3)
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  CircleAvatar(
                                    radius: 12,
                                    backgroundColor: isManual == 1 ? redColor : blackColor,
                                    child: CircleAvatar(
                                        backgroundColor: Colors.white,
                                        radius: 11,child: Center(child: Icon(Icons.circle,size: 18,
                                      color: isManual == 1 ? redColor : whiteColor,))),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  const Text("Manual Entry",style: TextStyle(),),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SliverLayoutBuilder(
                  builder: (context,constraints){
                    if(isManual == 1){
                      // ...... todo add animation .......
                      // return SliverToBoxAdapter(child: _buildAddress());
                      return SliverToBoxAdapter(child: _buildShippingForm());
                    } else if(isManual == 0){
                      return SliverToBoxAdapter(
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          margin: const EdgeInsets.all(8),
                          width: double.infinity,
                          height: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color: whiteColor,
                            borderRadius: BorderRadius.circular(6),
                            boxShadow: [
                              BoxShadow(
                                blurRadius: 70,
                                color: Colors.grey.withOpacity(0.2),
                                offset: const Offset(1,1),
                              )
                            ]
                          ),
                          child: const AppMapView(),
                          // child: GoogleMap(
                          //   mapType: MapType.normal,
                          //   scrollGesturesEnabled: true,
                          //   indoorViewEnabled: false,
                          //   buildingsEnabled: true,
                          //   myLocationButtonEnabled: true,
                          //   myLocationEnabled: true,
                          //   // tiltGesturesEnabled: false,
                          //   compassEnabled: true,
                          //   markers: markers,
                          //   gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{
                          //     Factory<OneSequenceGestureRecognizer>(() => EagerGestureRecognizer(),),
                          //   },
                          //   initialCameraPosition: googlePlex,
                          //   onMapCreated: (GoogleMapController mapController) async {
                          //     if (!this.mapController.isCompleted) {
                          //       this.mapController.complete(mapController);
                          //     }
                          //     // context.read<CheckoutCubit>().generateMarkers();
                          //   },
                          //   onTap: (latLan){
                          //     setState(() {
                          //       generateMarkers(latLan);
                          //       // setMarkerIcon(latLan.latitude,latLan.longitude);
                          //     });
                          //     // context.read<CheckoutCubit>().updateLocation(latLan);
                          //   },
                          // ),
                        )
                      );
                    }
                    return const SliverToBoxAdapter(child: SizedBox());
                  },
                ),

                SliverToBoxAdapter(
                  child: ShippingMethodList(
                    shippingMethods: widget.checkoutResponseModel.shippingMethods,
                    onChange: (int id) {
                      shippingMethod = id;
                    },
                  ),
                ),
                // SliverToBoxAdapter(child: _buildPaymentList(context)),
                SliverToBoxAdapter(
                  child: CheckboxListTile(
                    controlAffinity: ListTileControlAffinity.leading,
                    title: const Text("Agree with Terms and Conditions"),
                    value: agreeTermsCondition == 1 ? true : false,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                    activeColor: redColor,
                    onChanged: (v) {
                      if (v != null) {
                        agreeTermsCondition = agreeTermsCondition == 1 ? 0 : 1;
                        if (mounted) setState(() {});
                      }
                    },
                  ),
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 10)),
              ],
            ),
          ),
          _bottomBtn(),
        ],
      ),
    );
  }

  Widget _bottomBtn() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Total: ${Utils.formatPrice(widget.checkoutResponseModel.totalAmount)} ",
                style: const TextStyle(color: redColor),
              ),
              const Text(
                " +shipping cost",
                style: TextStyle(fontSize: 10),
              ),
            ],
          ),
          const SizedBox(width: 20),
          Flexible(
            child: PrimaryButton(
              text: 'BUY NOW',
              onPressed: () {
                Map<String, String> dataMap = {};
                if (agreeTermsCondition != 1) {
                  Utils.errorSnackBar(context, 'Please agree terms condition');
                  return;
                }
                // if (widget.checkoutResponseModel.billing == null && isManual == 1) {
                //   Utils.errorSnackBar(
                //       context, 'Please add your billing address');
                //   return;
                // }
                // if (widget.checkoutResponseModel.shipping == null && isManual == 1) {
                //   Utils.errorSnackBar(
                //       context, 'Please add your shipping address');
                //   return;
                // }

                if (isManual == 1) {
                  if (!_formKey.currentState!.validate()) return;
                  Marker marker = context.read<MapCubit>().markers.firstWhere((element) => true, orElse: context.read<MapCubit>().defaultMarker);
                  print("${marker.position.latitude}, ${marker.position.longitude}");
                  dataMap = {
                    'name': nameCtr.text.trim(),
                    'email': emailCtr.text.trim(),
                    'phone': phoneCtr.text.trim(),
                    'country': _countryModel!.id.toString(),
                    'state': _countryStateModel!.id.toString(),
                    'city': _cityModel!.id.toString(),
                    'zip_code': zipCtr.text.trim(),
                    'address': addressCtr.text.trim(),
                    'shipping_method': shippingMethod.toString(),
                    'latitude': marker.position.latitude.toString(),
                    'longitude': marker.position.longitude.toString(),
                    'is_manual': isManual.toString(),
                  };
                } else {
                  Marker marker = context.read<MapCubit>().markers.firstWhere((element) => true, orElse: context.read<MapCubit>().defaultMarker);
                  print("${marker.position.latitude}, ${marker.position.longitude}");
                  if (marker.position.latitude == 0.0) {
                    Utils.showSnackBar(context, "To continue, turn on device location or proceed with Manual Entry.");
                    Future.delayed(const Duration(seconds: 2)).then((value) => openAppSettings());
                    return;
                  }
                  dataMap = {
                    'shipping_method': shippingMethod.toString(),
                    // 'latitude': context.read<MapCubit>().markers.first.position.latitude.toString(),
                    'latitude': marker.position.latitude.toString(),
                    'longitude': marker.position.longitude.toString(),
                    'is_manual': isManual.toString(),
                  };
                }

                Navigator.pushNamed(context, RouteNames.placeOrderScreen,
                    arguments: PlaceOrderScreen(queryParams: dataMap,));
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddress() {
    return Column(
      children: [
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Address", style: headerStyle),
              InkWell(
                onTap: () {
                  Navigator.pushNamed(context, RouteNames.addressScreen).then((value) {
                    context.read<CheckoutCubit>().getCheckOutData(false);
                  });
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  height: 22,
                  decoration: BoxDecoration(
                    color: redColor,
                    borderRadius: BorderRadius.circular(3),
                  ),
                  child: const Center(
                    child: Text(
                      "Update Address",
                      style: TextStyle(fontSize: 13, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 9),
        if (widget.checkoutResponseModel.shipping != null) ...[
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: AddressCardComponent(
              addressModel: widget.checkoutResponseModel.shipping!,
              type: 'shipping',
              pwidth: MediaQuery.of(context).size.width,
            ),
          ),
        ],
        const SizedBox(height: 8),
        if (widget.checkoutResponseModel.billing != null) ...[
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: AddressCardComponent(
              addressModel: widget.checkoutResponseModel.billing!,
              type: 'billing',
              pwidth: MediaQuery.of(context).size.width,
            ),
          ),
        ]
      ],
    );
  }

  Widget _buildShippingForm() {
    return BlocListener<CountryStateByIdCubit,CountryStateByIdState>(
        listener: (context, state) {
          if (state is CountryStateByIdCityLoading) {
            _cityModel = null;
          } else if (state is CountryStateByIdCityLoaded) {
            _cityModel = null;
          } else if (state is CountryStateByIdCityLoading) {
            _cityModel = null;
          }
        },
      child: BlocBuilder<CountryStateByIdCubit, CountryStateByIdState>(
          builder: (context, state) {
            if (state is CountryStateByIdStateLoadied) {
              _cityModel = null;
              // _countryStateModel = context
              //     .read<CountryStateByIdCubit>()
              //     .filterState(addressModel?.stateId ?? 0);
              // if (_countryStateModel != null) {
              //   context
              //       .read<CountryStateByIdCubit>()
              //       .cityStateChangeCityFilter(_countryStateModel!);
              //
              //   _cityModel = context
              //       .read<CountryStateByIdCubit>()
              //       .filterCity(addressModel?.cityId ?? 0);
              // }
            } else if (state is CountryStateByIdCityLoaded) {
              _cityModel = null;
            } else if (state is CountryStateByIdCityLoading) {
              _cityModel = null;
            }
            return Form(
              key: _formKey,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0,vertical: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Shipping Address',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          height: 1.5),
                    ),
                    const SizedBox(height: 9),
                    TextFormField(
                      controller: nameCtr,
                      validator: (s) {
                        if (s == null || s.isEmpty) return 'Enter name';
                        return null;
                      },
                      keyboardType: TextInputType.name,
                      decoration: InputDecoration(
                        hintText: 'full name',
                        fillColor: borderColor.withOpacity(.10),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: emailCtr,
                      validator: (s) {
                        if (s == null || s.isEmpty) return 'Enter email';
                        if (!Utils.isEmail(s)) return "Enter valid email";
                        return null;
                      },
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        hintText: 'email address',
                        fillColor: borderColor.withOpacity(.10),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: phoneCtr,
                      validator: (s) {
                        if (s == null || s.isEmpty) return 'Enter phone';
                        return null;
                      },
                      keyboardType: TextInputType.phone,
                      decoration: InputDecoration(
                        hintText: 'phone number',
                        fillColor: borderColor.withOpacity(.10),
                      ),
                    ),
                    const SizedBox(height: 16),
                    _countryField(countries),
                    const SizedBox(height: 16),
                    _stateField(),
                    const SizedBox(height: 16),
                    _cityField(),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: addressCtr,
                      validator: (s) {
                        if (s == null || s.isEmpty) return 'Enter address';
                        return null;
                      },
                      keyboardType: TextInputType.streetAddress,
                      decoration: InputDecoration(
                        fillColor: borderColor.withOpacity(.10),
                        hintText: 'Address',
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: zipCtr,
                      validator: (s) {
                        if (s == null || s.isEmpty) return 'Enter zip-code';
                        return null;
                      },
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        fillColor: borderColor.withOpacity(.10),
                        hintText: 'ZipCode',
                      ),
                    ),
                    // const SizedBox(height: 30),
                    // PrimaryButton(
                    //   text: 'Set Address',
                    //   onPressed: () {
                    //
                    //   },
                    // )
                  ],
                ),
              ),
            );
          },
        ),
    );
  }

  Widget _cityField() {
    final addressBl = context.read<CountryStateByIdCubit>();
    return DropdownButtonFormField<CityModel>(
      value: _cityModel,
      hint: const Text('City'),
      decoration: const InputDecoration(
        isDense: true,
        border: OutlineInputBorder(
          // borderSide: BorderSide(width: 1, color: CustomColors.lineColor),
          borderRadius: BorderRadius.all(Radius.circular(5)),
        ),
      ),
      // onTap: () async {
      //   Utils.closeKeyBoard(context);
      // },
      onChanged: (value) {
        _cityModel = value;
        if (value == null) return;
      },
      validator: (value) => value == null ? 'field required' : null,
      isDense: true,
      isExpanded: true,
      items: addressBl.cities
          .map<DropdownMenuItem<CityModel>>((CityModel value) {
        return DropdownMenuItem<CityModel>(
            value: value, child: Text(value.name));
      }).toList(),
    );
  }

  Widget _stateField() {
    final addressBl = context.read<CountryStateByIdCubit>();
    return DropdownButtonFormField<CountryStateModel>(
      value: _countryStateModel,
      hint: const Text('State'),
      decoration: const InputDecoration(
        isDense: true,
        border: OutlineInputBorder(
          // borderSide: BorderSide(width: 1, color: CustomColors.lineColor),
          borderRadius: BorderRadius.all(Radius.circular(5)),
        ),
      ),
      // onTap: () async {
      //   Utils.closeKeyBoard(context);
      // },
      onChanged: (value) async {
        if (value == null) return;
        _cityModel = null;
        _countryStateModel = value;
        print("city data : $_cityModel");
        print("state data : $_countryStateModel");
        // await addressBl.cityStateChangeCityFilter(value);
        context.read<CountryStateByIdCubit>().cityLoadIdStateId(value.id.toString());
      },
      validator: (value) => value == null ? 'field required' : null,
      isDense: true,
      isExpanded: true,
      items: context.read<CountryStateByIdCubit>().stateList
          .map<DropdownMenuItem<CountryStateModel>>((CountryStateModel value) {
        return DropdownMenuItem<CountryStateModel>(
            value: value, child: Text(value.name));
      }).toList(),
    );
  }

  Widget _countryField(List<CountryModel> countries) {
    return DropdownButtonFormField<CountryModel>(
      value: _countryModel,
      hint: const Text('Country'),
      decoration: const InputDecoration(
        isDense: true,
        border: OutlineInputBorder(
          // borderSide: BorderSide(width: 1, color: CustomColors.lineColor),
          borderRadius: BorderRadius.all(Radius.circular(5)),
        ),
      ),
      // onTap: () async {
      //   Utils.closeKeyBoard(context);
      // },
      onChanged: (value) {
        if (value == null) return;
        _loadState(value);
      },
      validator: (value) => value == null ? 'field required' : null,
      isDense: true,
      isExpanded: true,
      items:
      countries.map<DropdownMenuItem<CountryModel>>((CountryModel value) {
        return DropdownMenuItem<CountryModel>(
            value: value, child: Text(value.name));
      }).toList(),
    );
  }

  SliverPadding _buildProductList() {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      sliver: SliverList(
        delegate: SliverChildBuilderDelegate(
          (context, index) {
            return CheckoutSingleItem(
                product: widget.checkoutResponseModel.cartProducts[index]);
          },
          childCount: widget.checkoutResponseModel.cartProducts.length,
          addAutomaticKeepAlives: true,
        ),
      ),
    );
  }

  Widget _buildProductNumber() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 14),
      child: Row(
        children: [
          const Icon(Icons.shopping_cart_rounded, color: redColor),
          const SizedBox(width: 10),
          Text(
            "${widget.checkoutResponseModel.cartProducts.length} Products",
            style: headerStyle,
          ),
        ],
      ),
    );
  }

  void makeFormData(){
    countries = context.read<LoginBloc>().countries.toSet().toList();
    addressModel = widget.checkoutResponseModel.shipping;
    if (addressModel != null) {
      _countryModel = context.read<CountryStateByIdCubit>().filterCountryWithCountries(countries, addressModel!.countryId);

      // context.read<CountryStateByIdCubit>().stateList = widget.checkoutResponseModel.states;
      // context.read<CountryStateByIdCubit>().cities = widget.checkoutResponseModel.cities;

      _countryStateModel = context.read<CountryStateByIdCubit>().filterStateWithStates(widget.checkoutResponseModel.states, addressModel!.stateId);
      _cityModel = context.read<CountryStateByIdCubit>().filterCityWithCities(widget.checkoutResponseModel.cities, addressModel!.cityId);

    } else {
      _countryModel = null;
      _countryStateModel = null;
      _cityModel = null;
    }


    // if (_countryModel != null) {
    //   final stateLoadIdCountryId =
    //       context.read<CountryStateByIdCubit>().stateLoadIdCountryId;
    //   stateLoadIdCountryId(_countryModel!.id.toString());
    // }
    _setValueIntoController();
  }
  void _loadState(CountryModel countryModel) {
    _countryModel = countryModel;
    _countryStateModel = null;
    _cityModel = null;
    // cities = [];
    // stateList = [];

    final stateLoadIdCountryId =
        context.read<CountryStateByIdCubit>().stateLoadIdCountryId;

    stateLoadIdCountryId(countryModel.id.toString());
  }
  void _setValueIntoController() {
    nameCtr.text = addressModel?.name ?? "${context.read<LoginBloc>().userInfo?.user.name}";
    emailCtr.text = addressModel?.email ?? "${context.read<LoginBloc>().userInfo?.user.email}";
    phoneCtr.text = addressModel?.phone ?? "${context.read<LoginBloc>().userInfo?.user.phone}";
    zipCtr.text = addressModel?.zipCode ?? '';
    addressCtr.text = addressModel?.address ?? "${context.read<LoginBloc>().userInfo?.user.address}";
  }
}
