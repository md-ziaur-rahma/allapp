class KStrings {
  static const String appName = "Dhereye";

  static const String cachedUserResponseKey = "cacheUserResponse";
  static const String cacheOnBoardingKey = "cacheOnBoardingKey";
  static const String cachedWebSettingKey = "cachedWebSettingKey";
}
