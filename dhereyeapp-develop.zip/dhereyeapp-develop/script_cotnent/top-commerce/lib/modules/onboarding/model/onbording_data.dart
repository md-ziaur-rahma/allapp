import '../../../utils/k_images.dart';
import 'onbording_model.dart';

const onBordingList = [
  OnBordingModel(
    image: Kimages.onboarding_1,
    subTitle: 'Welcome to',
    title: "Choose Product",
    paragraph:
        'Dhereye E-Commerce is a online store. Its has  50k+ Products. you can buy every into a products in easy way.',
  ),
  OnBordingModel(
    image: Kimages.onboarding_2,
    subTitle: 'Easy way to',
    title: "Make Your Payment",
    paragraph:
        'Dhereye E-Commerce is a online store. Its has  50k+ Products. you can buy every into a products in easy way.',
  ),
  OnBordingModel(
    image: Kimages.onboarding_3,
    subTitle: 'Online Shoping',
    title: "Fastest Delivery",
    paragraph:
        'Dhereye E-Commerce is a online store. Its has  50k+ Products. you can buy every into a products in easy way.',
  ),
];
