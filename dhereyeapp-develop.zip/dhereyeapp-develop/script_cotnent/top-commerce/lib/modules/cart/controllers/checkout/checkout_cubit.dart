import 'dart:async';
import 'dart:math';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../authentication/controller/login/login_bloc.dart';
import '../../model/checkout_response_model.dart';
import '../cart_repository.dart';

part 'checkout_state.dart';

class CheckoutCubit extends Cubit<CheckoutState> {
  final CartRepository _cartRepository;

  final LoginBloc _loginBloc;

  CheckoutCubit({
    required LoginBloc loginBloc,
    required CartRepository cartRepository,
  })  : _cartRepository = cartRepository,
        _loginBloc = loginBloc,
        super(const CheckoutStateInitial());

  CheckoutResponseModel? checkoutResponseModel;

  Future<void> getCheckOutData() async {
    if (_loginBloc.userInfo == null) {
      emit(const CheckoutStateInitial());
      emit(const CheckoutStateError("Please login first", 401));
      return;
    }
    emit(const CheckoutStateLoading());
    final result =
        await _cartRepository.getCheckoutData(_loginBloc.userInfo!.accessToken);

    result.fold(
      (failure) {
        emit(CheckoutStateError(failure.message, failure.statusCode));
      },
      (successData) {
        checkoutResponseModel = successData;
        emit(CheckoutStateLoaded(successData));
      },
    );
  }

  //............... Google Map .................
  Completer<GoogleMapController> mapController = Completer();
  CameraPosition googlePlex = const CameraPosition(
    target: LatLng(23.817206, 90.413953),
    zoom: 16,
  );

  CameraPosition getCameraPosition(lat,lon) {
    return CameraPosition(
      target: LatLng(lat, lon),
      zoom: 16,
    );
  }

  void updateLocation(LatLng latLan)async{
    final GoogleMapController controller = await mapController.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(getCameraPosition(latLan.latitude,latLan.longitude)));
    generateMarkers(latLan);
    emit(state);
  }

  //............................ Marker .........................
  late Set<Marker> markers;
  BitmapDescriptor? myMarker;
  void setMarkerIcon(lat,lon) async {
    myMarker = await BitmapDescriptor.fromAssetImage(
        const ImageConfiguration(size: Size(50, 50)),'assets/images/marker_red.png');
    generateMarkers(LatLng(lat, lon));
  }

  void generateMarkers(LatLng latLng) {
    var localMarkers = <Marker>{};
    localMarkers.add(
        Marker(
            markerId: MarkerId(Random().nextInt(1000).toString()),
            draggable: true,
            onDragEnd: (latLng){
              print("ccccccccccccccccccccc");
            },
            position: LatLng(latLng.latitude, latLng.longitude),
            icon: myMarker!
        )
    );
    markers = localMarkers;
    emit(state);
    // emit(const CheckoutLocationLoaded());
  }

  late Position currentPosition;
  void getCurrentLocation() async {
    if (await Permission.location.isGranted) {
      Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.best,
          forceAndroidLocationManager: false)
          .then((Position position) async {
        currentPosition = position;
        print("${currentPosition.latitude}, ${currentPosition.longitude}");
        final GoogleMapController controller = await mapController.future;
        controller.animateCamera(CameraUpdate.newCameraPosition(getCameraPosition(position.latitude,position.longitude)));
        setMarkerIcon(position.latitude,position.longitude);
        // emit(state);
        // String url = "http://maps.google.com/maps?saddr=${currentPosition.latitude},${currentPosition.longitude}&daddr=$lat,$long&mode=driving";
        // Helper.openMap(url);
        if (kDebugMode) {
          print('${currentPosition.latitude} ${currentPosition.longitude}');
        }
      }).catchError((e) {
        if (kDebugMode) {
          print(e);
        }
        // Helper().toastMsg('Please Turn On Your Mobile Location');
      });
    } else {
      Map<Permission, PermissionStatus> statuses = await [
        Permission.location,
      ].request();
      getCurrentLocation();
      // Get.snackbar("Message", "Try Again");
    }
  }
}
