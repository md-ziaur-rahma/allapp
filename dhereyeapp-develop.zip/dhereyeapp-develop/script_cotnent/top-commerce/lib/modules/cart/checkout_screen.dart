import 'package:expandable/expandable.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:grouped_list/grouped_list.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../core/router_name.dart';
import '../../utils/constants.dart';
import '../../utils/utils.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/rounded_app_bar.dart';
import 'component/address_card_component.dart';
import 'component/checkout_single_item.dart';
import 'component/shiping_method_list.dart';
import 'controllers/checkout/checkout_cubit.dart';
import 'model/checkout_response_model.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({Key? key}) : super(key: key);

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => context.read<CheckoutCubit>().getCheckOutData());
    Future.microtask(() => context.read<CheckoutCubit>().getCurrentLocation());
    Future.microtask(() => context.read<CheckoutCubit>().setMarkerIcon(kLatLng.latitude,kLatLng.longitude));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: RoundedAppBar(titleText: 'Checkout'),
      body: BlocBuilder<CheckoutCubit, CheckoutState>(
        builder: (context, state) {
          if (state is CheckoutStateLoading || state is CheckoutStateInitial) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is CheckoutStateError) {
            return Center(
              child: Text(
                state.message,
                style: const TextStyle(color: redColor),
              ),
            );
          } else if (state is CheckoutStateLoaded) {
            return _LoadedWidget(
                checkoutResponseModel: state.checkoutResponseModel);
          }
          return const SizedBox();
        },
      ),
    );
  }
}

class _LoadedWidget extends StatefulWidget {
  const _LoadedWidget({
    Key? key,
    required this.checkoutResponseModel,
  }) : super(key: key);

  final CheckoutResponseModel checkoutResponseModel;

  @override
  State<_LoadedWidget> createState() => _LoadedWidgetState();
}

class _LoadedWidgetState extends State<_LoadedWidget> {
  final double height = 140;

  final headerStyle =
      const TextStyle(fontSize: 16, fontWeight: FontWeight.w600);

  late CheckoutResponseModel checkoutResponseModel;

  int shippingMethod = 0;
  int agreeTermsCondition = 1;

  int isManual = 0;

  @override
  void initState() {
    super.initState();
    checkoutResponseModel = widget.checkoutResponseModel;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(child: _buildProductNumber()),
              _buildProductList(),

              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                sliver: SliverToBoxAdapter(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Select Your Shipping Address Entry Method",style: TextStyle(color: blackColor,fontSize: 16,fontWeight: FontWeight.w500),),
                      const SizedBox(
                        height: 10,
                      ),
                      Material(
                        borderRadius: BorderRadius.circular(3),
                        color: whiteColor,
                        child: InkWell(
                          borderRadius: BorderRadius.circular(3),
                          onTap: (){
                            setState(() {
                              isManual = 0;
                            });
                          },
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                            decoration: BoxDecoration(
                              border: Border.all(color: isManual == 0 ? redColor : blackColor,),
                              borderRadius: BorderRadius.circular(3)
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                CircleAvatar(
                                  radius: 12,
                                  backgroundColor: isManual == 0 ? redColor : blackColor,
                                  child: CircleAvatar(
                                      backgroundColor: Colors.white,
                                      radius: 11,child: Center(child: Icon(Icons.circle,size: 18,
                                    color: isManual == 0 ? redColor : whiteColor,))),
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                const Text("From Google Map",style: TextStyle(),),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Material(
                        borderRadius: BorderRadius.circular(3),
                        color: whiteColor,
                        child: InkWell(
                          borderRadius: BorderRadius.circular(3),
                          onTap: (){
                            setState(() {
                              isManual = 1;
                            });
                          },
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                            decoration: BoxDecoration(
                                border: Border.all(color: isManual == 1 ? redColor : blackColor,),
                                borderRadius: BorderRadius.circular(3)
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                CircleAvatar(
                                  radius: 12,
                                  backgroundColor: isManual == 1 ? redColor : blackColor,
                                  child: CircleAvatar(
                                      backgroundColor: Colors.white,
                                      radius: 11,child: Center(child: Icon(Icons.circle,size: 18,
                                    color: isManual == 1 ? redColor : whiteColor,))),
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                const Text("Manual Entry",style: TextStyle(),),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              SliverLayoutBuilder(
                builder: (context,constraints){
                  if(isManual == 1){
                    // ...... todo add animation .......
                    return SliverToBoxAdapter(child: _buildAddress());
                  } else if(isManual == 0){
                    return SliverToBoxAdapter(
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        margin: const EdgeInsets.all(8),
                        width: double.infinity,
                        height: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          color: whiteColor,
                          borderRadius: BorderRadius.circular(6),
                          boxShadow: [
                            BoxShadow(
                              blurRadius: 70,
                              color: Colors.grey.withOpacity(0.2),
                              offset: const Offset(1,1),
                            )
                          ]
                        ),
                        child: BlocBuilder<CheckoutCubit, CheckoutState>(
                          builder: (context,state) {
                            return GoogleMap(
                              mapType: MapType.normal,
                              scrollGesturesEnabled: true,
                              indoorViewEnabled: false,
                              buildingsEnabled: true,
                              myLocationButtonEnabled: true,
                              myLocationEnabled: true,
                              // tiltGesturesEnabled: false,
                              compassEnabled: true,
                              markers: context.read<CheckoutCubit>().markers,
                              gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{
                                Factory<OneSequenceGestureRecognizer>(() => EagerGestureRecognizer(),),
                              },
                              initialCameraPosition: context.read<CheckoutCubit>().googlePlex,
                              onMapCreated: (GoogleMapController mapController) {
                                context.read<CheckoutCubit>().mapController.complete(mapController);
                                // context.read<CheckoutCubit>().generateMarkers();
                              },
                              onTap: (latLan){
                                setState(() {
                                  context.read<CheckoutCubit>().setMarkerIcon(latLan.latitude,latLan.longitude);
                                });
                                // context.read<CheckoutCubit>().updateLocation(latLan);
                              },
                            );
                          }
                        ),
                      )
                    );
                  }
                  return const SliverToBoxAdapter(child: SizedBox());
                },
              ),
              
              SliverToBoxAdapter(
                child: ShippingMethodList(
                  shippingMethods: checkoutResponseModel.shippingMethods,
                  onChange: (int id) {
                    shippingMethod = id;
                  },
                ),
              ),
              // SliverToBoxAdapter(child: _buildPaymentList(context)),
              SliverToBoxAdapter(
                child: CheckboxListTile(
                  controlAffinity: ListTileControlAffinity.leading,
                  title: const Text("Agree widh terms condition"),
                  value: agreeTermsCondition == 1 ? true : false,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  activeColor: redColor,
                  onChanged: (v) {
                    if (v != null) {
                      agreeTermsCondition = agreeTermsCondition == 1 ? 0 : 1;
                      setState(() {});
                    }
                  },
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 10)),
            ],
          ),
        ),
        _bottomBtn(),
      ],
    );
  }

  Widget _bottomBtn() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Total: ${Utils.formatPrice(checkoutResponseModel.totalAmount)} ",
                style: const TextStyle(color: redColor),
              ),
              const Text(
                " +shipping cost",
                style: TextStyle(fontSize: 8),
              ),
            ],
          ),
          const SizedBox(width: 20),
          Flexible(
            child: PrimaryButton(
              text: 'Place to Order',
              onPressed: () {
                if (agreeTermsCondition != 1) {
                  Utils.errorSnackBar(context, 'Please agree terms condition');
                  return;
                }
                if (checkoutResponseModel.billing == null) {
                  Utils.errorSnackBar(
                      context, 'Please add your billing address');
                  return;
                }
                if (checkoutResponseModel.shipping == null) {
                  Utils.errorSnackBar(
                      context, 'Please add your shipping address');
                  return;
                }
                Navigator.pushNamed(context, RouteNames.placeOrderScreen,
                    arguments: shippingMethod);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddress() {
    return Column(
      children: [
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Address", style: headerStyle),
              InkWell(
                onTap: () {
                  Navigator.pushNamed(context, RouteNames.addressScreen);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  height: 22,
                  decoration: BoxDecoration(
                    color: redColor,
                    borderRadius: BorderRadius.circular(3),
                  ),
                  child: const Center(
                    child: Text(
                      "Update Addresse",
                      style: TextStyle(fontSize: 13, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 9),
        if (checkoutResponseModel.shipping != null) ...[
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: AddressCardComponent(
              addressModel: checkoutResponseModel.shipping!,
              type: 'shipping',
              pwidth: MediaQuery.of(context).size.width,
            ),
          ),
        ],
        const SizedBox(height: 8),
        if (checkoutResponseModel.billing != null) ...[
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: AddressCardComponent(
              addressModel: checkoutResponseModel.billing!,
              type: 'billing',
              pwidth: MediaQuery.of(context).size.width,
            ),
          ),
        ]
      ],
    );
  }

  SliverPadding _buildProductList() {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      sliver: SliverList(
        delegate: SliverChildBuilderDelegate(
          (context, index) {
            return CheckoutSingleItem(
                product: checkoutResponseModel.cartProducts[index]);
          },
          childCount: checkoutResponseModel.cartProducts.length,
          addAutomaticKeepAlives: true,
        ),
      ),
    );
  }

  Widget _buildProductNumber() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 14),
      child: Row(
        children: [
          const Icon(Icons.shopping_cart_rounded, color: redColor),
          const SizedBox(width: 10),
          Text(
            "${checkoutResponseModel.cartProducts.length} Products",
            style: headerStyle,
          ),
        ],
      ),
    );
  }
}
