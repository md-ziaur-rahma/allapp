import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:top_commerce_app/modules/order/model/order_model.dart';

import '../../repository/tracking_repository.dart';
part 'tracking_state.dart';


class TrackingCubit extends Cubit<TrackingState> {
  final TrackingRepository _trackingRepository;

  TrackingCubit({required TrackingRepository trackingRepository})
      : _trackingRepository = trackingRepository,
        super(const TrackingStateInitial());

  late OrderModel trackData;

  void trackOrder(String orderId) async {
    emit(const TrackingStateLoading());
    final result = _trackingRepository.trackingData(orderId);
    result.then((value) {
      value.fold((l) {
        emit(TrackingStateError(l.message, l.statusCode));
      }, (r) {
        trackData = r;
        final loadedState = TrackingStateLoaded(r);
        emit(loadedState);
      });
    });
    // result.fold(
    //   (failure) {
    //     emit(TrackingStateError(failure.message, failure.statusCode));
    //   },
    //   (data) {
    //     trackData = data;
    //     final loadedState = TrackingStateLoaded(data);
    //     emit(loadedState);
    //   },
    // );
  }
}
