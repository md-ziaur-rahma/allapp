import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:timeline_tile/timeline_tile.dart';
import 'package:top_commerce_app/modules/order/controllers/tracking/tracking_cubit.dart';
import 'package:top_commerce_app/utils/constants.dart';
import 'package:top_commerce_app/utils/k_images.dart';
import 'package:top_commerce_app/widgets/custom_image.dart';
import 'package:top_commerce_app/widgets/please_signin_widget.dart';
import 'package:top_commerce_app/widgets/rounded_app_bar.dart';

class OrderTrackingScreen extends StatefulWidget {
  const OrderTrackingScreen({Key? key, this.trackingNumber}) : super(key: key);
  final String? trackingNumber;

  @override
  State<OrderTrackingScreen> createState() => _OrderTrackingScreenState();
}

class _OrderTrackingScreenState extends State<OrderTrackingScreen> {
  var trackingController = TextEditingController();
  @override
  void initState() {
    trackingController.text = widget.trackingNumber?? '';
    super.initState();
    Future.microtask(() {
      if (widget.trackingNumber == null || widget.trackingNumber == '') {
        context.read<TrackingCubit>().emit(const TrackingStateInitial());
      }else {
        context.read<TrackingCubit>().trackOrder(widget.trackingNumber!);
      }
    });
  }

  List<IconData> icons = [Icons.arrow_forward_rounded,Icons.repeat,Icons.fire_truck_sharp,Icons.check];
  List<String> status = ["Pending","Order Processing","On The Way","Completed"];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: RoundedAppBar(
        titleText: "Track You Order(${widget.trackingNumber})",
      ),
      body: CustomScrollView(
        scrollDirection: Axis.vertical,
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            sliver: SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
                decoration: BoxDecoration(
                    color: borderColor,
                    borderRadius: BorderRadius.circular(6),
                    boxShadow: [
                      BoxShadow(
                          blurRadius: 70,
                          offset: Offset(10,10),
                          color: Colors.grey.withOpacity(0.1)
                      )
                    ]
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Text("Order Tracking",style: TextStyle(color: Colors.black,fontSize: 22,fontWeight: FontWeight.w700),),
                    const Text("Tracking Your Order Status",style: TextStyle(color: Colors.black54,fontSize: 16,fontWeight: FontWeight.w400),),
                    const SizedBox(
                      height: 30,
                    ),
                    const Align(alignment: Alignment.bottomLeft,child: Text("Order id",style: TextStyle(color: Colors.black54,fontSize: 16,fontWeight: FontWeight.w400),)),
                    const SizedBox(
                      height: 8,
                    ),
                    SizedBox(
                      child: TextFormField(
                        controller: trackingController,
                        textInputAction: TextInputAction.done,
                        keyboardType: TextInputType.text,
                        decoration: const InputDecoration(
                          hintText: "1234**1178",
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    SizedBox(
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: redColor,shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6))),
                        onPressed: (){
                          if (trackingController.text.isNotEmpty) {
                            context.read<TrackingCubit>().trackOrder(trackingController.text);
                          } else {

                          }
                        },
                        child: const Text("TRACK",style: TextStyle(color: whiteColor),),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
            sliver: SliverToBoxAdapter(
              child: BlocBuilder<TrackingCubit,TrackingState>(
                builder: (context,state){
                  if (state is TrackingStateLoading) {
                    return const Center(child: CircularProgressIndicator());
                  } else if (state is TrackingStateError) {
                    if (state.statusCode == 401) {
                      return const PleaseSigninWidget();
                    } else if (state.statusCode == 210) {
                      return Center(
                        child: Column(
                          children: [
                            const CustomImage(path: Kimages.emptyOrder,height: 160),
                            const SizedBox(
                              height: 16,
                            ),
                            Text(
                              state.message,
                              style: const TextStyle(color: redColor,fontSize: 20),
                            ),
                          ],
                        ),
                      );
                    }
                    return Center(
                      child: Text(
                        state.message,
                        style: const TextStyle(color: redColor),
                      ),
                    );
                  } else if (state is TrackingStateInitial) {
                    return const SizedBox();
                  } else if (state is TrackingStateLoaded) {
                    return Column(
                      children: [
                        ...List.generate(4, (index) {
                          return TimelineTile(
                            alignment: TimelineAlign.manual,
                            lineXY: 0.05,
                            isFirst: index == 0 ? true : false,
                            afterLineStyle: LineStyle(
                                color: index > context.read<TrackingCubit>().trackData.orderStatus ? Colors.grey.withOpacity(0.4) : redColor,
                                thickness: 5
                            ),
                            beforeLineStyle: LineStyle(
                                color: index > context.read<TrackingCubit>().trackData.orderStatus ? Colors.grey.withOpacity(0.4) : redColor,
                                thickness: 5
                            ),
                            indicatorStyle: IndicatorStyle(color: redColor,
                                indicator: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: index > context.read<TrackingCubit>().trackData.orderStatus ? Colors.white : redColor,
                                    shape: BoxShape.circle,
                                    border: Border.all(color: index > context.read<TrackingCubit>().trackData.orderStatus ? Colors.grey.withOpacity(0.4) : redColor,width: 2),
                                  ),
                                  child: Center(child: Icon(icons[index],size: 16,color: index > context.read<TrackingCubit>().trackData.orderStatus ? Colors.grey.withOpacity(0.4) : whiteColor,),),
                                ),
                                // indicatorXY: 0.5,
                                width: 35,
                                height: 35
                            ),
                            endChild: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 24.0),
                              child: Text(status[index],style: const TextStyle(fontSize: 16,fontWeight: FontWeight.w500),),
                            ),
                            startChild: const SizedBox(),
                          );
                        }),
                      ],
                    );
                  } else {
                    return const SizedBox();
                  }
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
