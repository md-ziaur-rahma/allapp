package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class RtsDispatchPost {
    @SerializedName("user_id")
    public int user_id;

    @SerializedName("consignment_label")
    public String consignment_label;

    @SerializedName("data")
    public List<DispatchItemSubModel> data;
}
