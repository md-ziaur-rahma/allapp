package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ukshop.Adapters.BoxListAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.BoxListPost;
import com.example.ukshop.NetworkModel.BoxListResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class BoxlistPage extends AppCompatActivity implements ZXingScannerView.ResultHandler,
        AdapterView.OnItemSelectedListener {

    private RecyclerView recyclerView;
    private List<BoxListResponse.Data> mainList = new ArrayList<>();
    private List<BoxListResponse.Data> scrollList = new ArrayList<>();
    private List<BoxListResponse.Data> tempList = new ArrayList<>();
    private BoxListAdapter adapter;

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private NestedScrollView nestedScrollView;
    private EditText searchbox;
    TextView maxAir;
    private ExtendedFloatingActionButton scanProductFabBtn;

    private Spinner spinner;
    private List<String> dropDownList = new ArrayList<>();
    private List<Integer> integerTempList = new ArrayList<>();
    private ArrayAdapter<String> spinnerAdapter;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    public static int shipment_no;

    private static final int CAMERA_REQUEST_CODE = 501;

    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static boolean isFlash = false;

    private boolean isInvalid = false;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();
    private int isTone = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boxlist_page);

        rightTone = MediaPlayer.create(this, R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this, R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();
        spinner.setOnItemSelectedListener(this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new BoxListAdapter(mainList, BoxlistPage.this, rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        loadBoxList();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        toolbar.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();

            if (id == R.id.menuShipment_refreshId) {
                if (Utils.broadcastIntent(BoxlistPage.this, rootLayout)) {
                    loadBoxList();
                } else {
                    Utils.snackbarToast(rootLayout, "No Internet Connection!");
                }
                return true;
            }
            return false;
        });

        scanProductFabBtn.setOnClickListener(v -> {
            if (Utils.isCameraPermission(BoxlistPage.this)) {
                isTone = 1;
                openScanner();
            } else {
                ActivityCompat.requestPermissions(BoxlistPage.this, new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST_CODE);
            }
        });

        scanProductFabBtn.setOnLongClickListener(v -> {
            isTone = 0;
            final Dialog dialog = new Dialog(BoxlistPage.this, R.style.fadeDialog);
            dialog.setContentView(R.layout.barcod_picker_layout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width, height);
            dialog.setCancelable(true);
            dialog.show();

            final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
            final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
            Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
            barcodeText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});

            search.setText(R.string.search);

            cancel.setOnClickListener(v1 -> dialog.dismiss());

            search.setOnClickListener(v12 -> {
                if (!TextUtils.isEmpty(barcodeText.getText().toString())) {
                    if (barcodeText.getText().toString().length() == 8) {
                        boxSearch(barcodeText.getText().toString());
                    } else {
                        Toast.makeText(BoxlistPage.this, "This is not Box Label!", Toast.LENGTH_SHORT).show();
                    }
                    dialog.dismiss();
                } else {
                    barcodeText.requestFocus();
                    Toast.makeText(BoxlistPage.this, "Enter Barcode !", Toast.LENGTH_LONG).show();
                }
            });

            return false;
        });

        nestedScrollView.setOnScrollChangeListener((NestedScrollView.OnScrollChangeListener) (v, scrollX, scrollY, oldScrollX, oldScrollY) -> {

            if (v.getChildAt(v.getChildCount() - 1) != null) {
                if ((scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight())) &&
                        scrollY > oldScrollY) {

                    //https://medium.com/@mujjtahidah/load-more-recyclerview-inside-nested-scroll-view-and-coordinator-layout-4f179dc01fd

                    if (!recyclerView.canScrollVertically(1)) {
                        onScrollToBottom();
                    }

                }
            }

        });

        searchbox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (mainList.size() > 0) {
                    if (!TextUtils.isEmpty(s.toString())) {
                        filterBoxByText(s.toString());
                    } else {
                        filterBoxByText("");
                    }
                }

            }
        });

    }


    private void onScrollToBottom() {
        if (tempList.size() < scrollList.size()) {
            int x, y;
            if ((scrollList.size() - tempList.size()) >= 20) {
                x = tempList.size();
                y = x + 20;
            } else {
                x = tempList.size();
                y = x + scrollList.size() - tempList.size();
            }

            for (int i = x; i < y; i++) {
                tempList.add(i, scrollList.get(i));
            }

            adapter.updateList(tempList);
        }
    }
    private void initialFindFields() {
        rootLayout = (CoordinatorLayout) findViewById(R.id.boxListRootLayoutID);
        toolbar = (MaterialToolbar) findViewById(R.id.boxListToolbarID);
        nestedScrollView = (NestedScrollView) findViewById(R.id.boxListNestedScrollID);
        scanProductFabBtn = (ExtendedFloatingActionButton) findViewById(R.id.boxListFabBtnID);

        searchbox = (EditText) findViewById(R.id.boxListSearchID);
        recyclerView = (RecyclerView) findViewById(R.id.boxListRecyclerID);
        maxAir = (TextView) findViewById(R.id.boxListMaxAriID);
        spinner = (Spinner) findViewById(R.id.boxListSpinnerID);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CAMERA_REQUEST_CODE) {
            if (grantResults.length >= 0) {
                openScanner();
            } else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    private void openScanner() {
        scannerDialog = new Dialog(BoxlistPage.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width, height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(BoxlistPage.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash) {
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                } else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }

    private void loadBoxList() {

        if (Utils.broadcastIntent(this, recyclerView)) {

            scrollList = new ArrayList<>();
            tempList = new ArrayList<>();
            mainList = new ArrayList<>();
            adapter.updateList(mainList);

            String token = SharedPreperenceUtils.getToken(this);
            int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

            final Dialog dialog = new Dialog(BoxlistPage.this);
            dialog.setContentView(R.layout.transparent_progress_dialoge);

            int width = WindowManager.LayoutParams.WRAP_CONTENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width, height);
            dialog.setCancelable(false);
            dialog.show();

            final BoxListPost post = new BoxListPost();
            post.user_id = user_id;
            post.shipment_no = shipment_no;

            Log.e("box list post", "msg" + new Gson().toJson(post));

            compositeDisposable.add(mIRetrofitApi.getBoxList(token, post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<BoxListResponse>() {
                @SuppressLint("SetTextI18n")
                @Override
                public void accept(BoxListResponse response) throws Exception {
                    if (response.status == 1) {
                        mainList = response.data;

                        if (mainList != null) {

                            int x = 0;
                            int xa = 0;
                            int xs = 0;

                            dropDownList = new ArrayList<>();
                            integerTempList = new ArrayList<>();
                            dropDownList.add("Unassigned Air");
                            dropDownList.add("Unassigned Sea");

                            for (int i = 0; i < mainList.size(); i++) {
                                final String boxLabel = response.data.get(i).box_label;
                                if (boxLabel.startsWith("1")) {
                                    // total air box count
                                    xa++;
                                } else if (boxLabel.startsWith("2")) {
                                    // total sea box count...
                                    xs++;
                                }

                                if (response.data.get(i).status > 10) {
                                    // total assigned box count...
                                    x++;
                                } else if (response.data.get(i).status <= 10 && boxLabel.startsWith("1")) {
                                    // this is for unAssigned air list....
                                    scrollList.add(mainList.get(i));
                                }


                                // this count for creating unique drop down list...
                                if (mainList.get(i).shipment_label > 0) {

                                    int m = 0;

                                    for (int j = 0; j < integerTempList.size(); j++) {
                                        if (mainList.get(i).shipment_label == integerTempList.get(j)) {
                                            m = 1;
                                        }
                                    }

                                    if (m < 1) {
                                        //dropDownList.add(String.valueOf(mainList.get(i).shipment_label));
                                        integerTempList.add(mainList.get(i).shipment_label);
                                    }
                                }


                            }

                            // shipment label is showing descending order...
                            Collections.sort(integerTempList, Collections.reverseOrder());

                            for (int mm = 0; mm < integerTempList.size(); mm++) {
                                dropDownList.add(String.valueOf(integerTempList.get(mm)));
                            }

                            // this is for adding box count with shipment label in dropdown...
                            dropDownList.set(0, dropDownList.get(0).concat(" (" + scrollList.size() + ")"));
                            dropDownList.set(1, dropDownList.get(1).concat(" (" + ((mainList.size() - x) - scrollList.size()) + ")"));
                            if (dropDownList.size() > 2) {
                                for (int i = 2; i < dropDownList.size(); i++) {
                                    int d_label = Integer.parseInt(dropDownList.get(i));
                                    int count = 0;
                                    for (int j = 0; j < mainList.size(); j++) {
                                        if (d_label == mainList.get(j).shipment_label) {
                                            count++;
                                        }
                                    }
                                    dropDownList.set(i, dropDownList.get(i).concat(" (" + count + ")"));
                                }
                            }

                            spinnerAdapter = new ArrayAdapter<>(BoxlistPage.this, android.R.layout.simple_expandable_list_item_1, dropDownList);
                            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            spinner.setAdapter(spinnerAdapter);

                            toolbar.setTitle("Box List  (" + x + "/" + mainList.size() + ")");

                            maxAir.setText("AIR : " + response.max_air + "/" + xa + "  SEA : " + response.max_sea + "/" + xs);


                            // this is for pagination in recyclerView...
                            if (scrollList.size() > 0) {
                                if (scrollList.size() >= 30) {
                                    for (int i = 0; i < 30; i++) {
                                        tempList.add(scrollList.get(i));
                                    }
                                } else {
                                    tempList.addAll(scrollList);
                                }
                                adapter.updateList(tempList);

                            } else {
                                // when unAssigned air list is zero...
                                for (int z = 0; z < mainList.size(); z++) {
                                    if (mainList.get(z).status <= 10 && mainList.get(z).box_label.startsWith("2")) {
                                        scrollList.add(mainList.get(z));
                                    }
                                }

                                // this is for pagination in recyclerView...
                                if (scrollList.size() > 0) {
                                    if (scrollList.size() >= 30) {
                                        for (int i = 0; i < 30; i++) {
                                            tempList.add(scrollList.get(i));
                                        }

                                    } else {
                                        tempList.addAll(scrollList);
                                    }
                                    adapter.updateList(tempList);
                                    spinner.setSelection(1);
                                } else {
                                    //when unAssigned air and sea both are zero...
                                    for (BoxListResponse.Data item : mainList) {
                                        if (item.shipment_label == Integer.parseInt(dropDownList.get(2).substring(0, 6))) {
                                            scrollList.add(item);
                                        }
                                    }

                                    // sorting descending order by box serial
                                    Collections.sort(scrollList, new Comparator<BoxListResponse.Data>() {
                                        @Override
                                        public int compare(BoxListResponse.Data s1, BoxListResponse.Data s2) {
                                            return s1.box_serial - s2.box_serial;
                                        }
                                    });

                                    Collections.reverse(scrollList);

                                    // this is for pagination in recyclerView...
                                    if (scrollList.size() >= 30) {
                                        for (int i = 0; i < 30; i++) {
                                            tempList.add(scrollList.get(i));
                                        }

                                    } else {
                                        tempList.addAll(scrollList);
                                    }

                                    adapter.updateList(tempList);

                                    spinner.setSelection(2);

                                }
                            }


                            dialog.dismiss();


                        } else {
                            dialog.dismiss();
                            Utils.snackbarToast(rootLayout, "Box has not yet been assigned!");
                        }
                    } else {

                        dialog.dismiss();

                        if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                            Utils.expiredTokenAlert(rootLayout, BoxlistPage.this);
                        } else {
                            Snackbar snackbar = Snackbar.make(rootLayout, "" + response.message, Snackbar.LENGTH_LONG);
                            snackbar.setAction("Retry", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    loadBoxList();
                                }
                            });
                            snackbar.show();
                        }
                    }
                }
            }, new Consumer<Throwable>() {
                @Override
                public void accept(Throwable throwable) throws Exception {
                    dialog.dismiss();

                    if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                        Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                loadBoxList();
                            }
                        });
                        snackbar.show();
                    } else {
                        Snackbar snackbar = Snackbar.make(rootLayout, "" + throwable.getMessage(), Snackbar.LENGTH_LONG);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                loadBoxList();
                            }
                        });
                        snackbar.show();
                    }
                }
            }));

        } else {
            NoInternetSnackBar();
        }


    }


    private void NoInternetSnackBar() {
        Snackbar snackbar = Snackbar.make(rootLayout, "No Internet Connection!", 5000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(BoxlistPage.this, rootLayout)) {
                    loadBoxList();
                } else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null) {
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()) {
            compositeDisposable.dispose();
        }

    }


    @Override
    public void handleResult(Result rawResult) {
        if (!TextUtils.isEmpty(rawResult.getText())) {
            if (rawResult.getText().length() == 8) {
                scannerDialog.dismiss();
                scannerView.stopCamera();
                boxSearch(rawResult.getText());
            } else {
                wrongTone.start();
                scannerDialog.dismiss();
                scannerView.stopCamera();
                Utils.snackbarToast(rootLayout, "This is not Box Label!");
            }
        } else {
            wrongTone.start();
            scannerDialog.dismiss();
            scannerView.stopCamera();
            Utils.snackbarToast(rootLayout, "Box Label is empty!");
        }

    }

    private void boxSearch(String boxLabel) {
        scrollList = new ArrayList<>();

        for (BoxListResponse.Data item : mainList) {
            if (item.box_label.toLowerCase().equals(boxLabel.toLowerCase())) {
                scrollList.add(item);
            }
        }

        if (scrollList.size() > 0) {
            if (isTone == 1) {
                rightTone.start();
                isTone = 0;
            }
            tempList = scrollList;
            adapter.updateList(tempList);
        } else {
            if (isTone == 1) {
                wrongTone.start();
                isTone = 0;
            }
            Utils.snackbarToast(rootLayout, "Box not found!");
        }


    }

    private void filterBoxByText(String boxLabel) {
        scrollList = new ArrayList<>();
        tempList = new ArrayList<>();
        ArrayList<BoxListResponse.Data> filteredList = new ArrayList<>();

        for (BoxListResponse.Data item : mainList) {
            if (item.box_label.toLowerCase().contains(boxLabel.toLowerCase())) {
                scrollList.add(item);
            }
        }

        if (scrollList.size() > 0) {

            if (scrollList.size() >= 30) {
                for (int i = 0; i < 30; i++) {
                    tempList.add(scrollList.get(i));
                }
            } else {
                tempList.addAll(scrollList);
            }
        }
        adapter.updateList(tempList);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        if (position == 0) {

            final Dialog dialog = new Dialog(BoxlistPage.this);
            dialog.setContentView(R.layout.transparent_progress_dialoge);

            int width = WindowManager.LayoutParams.WRAP_CONTENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width, height);
            dialog.setCancelable(false);
            dialog.show();

            scrollList = new ArrayList<>();
            tempList = new ArrayList<>();
            for (BoxListResponse.Data item : mainList) {
                if (item.status <= 10 && item.box_label.startsWith("1")) {
                    scrollList.add(item);
                }
            }

            if (scrollList.size() > 0) {

                if (scrollList.size() >= 30) {
                    for (int i = 0; i < 30; i++) {
                        tempList.add(scrollList.get(i));
                    }

                } else {
                    tempList.addAll(scrollList);
                }
            }
            adapter.updateList(tempList);
            dialog.dismiss();
        } else if (position == 1) {
            final Dialog dialog = new Dialog(BoxlistPage.this);
            dialog.setContentView(R.layout.transparent_progress_dialoge);

            int width = WindowManager.LayoutParams.WRAP_CONTENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width, height);
            dialog.setCancelable(false);
            dialog.show();

            scrollList = new ArrayList<>();
            tempList = new ArrayList<>();
            for (BoxListResponse.Data item : mainList) {
                if (item.status <= 10 && item.box_label.startsWith("2")) {
                    scrollList.add(item);
                }
            }

            if (scrollList.size() > 0) {

                if (scrollList.size() >= 30) {
                    for (int i = 0; i < 30; i++) {
                        tempList.add(scrollList.get(i));
                    }

                } else {
                    tempList.addAll(scrollList);
                }
            }
            adapter.updateList(tempList);
            dialog.dismiss();
        } else {

            final Dialog dialog = new Dialog(BoxlistPage.this);
            dialog.setContentView(R.layout.transparent_progress_dialoge);

            int width = WindowManager.LayoutParams.WRAP_CONTENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width, height);
            dialog.setCancelable(false);
            dialog.show();

            scrollList = new ArrayList<>();
            tempList = new ArrayList<>();
            //ArrayList<BoxListResponse.Data> filteredLIst = new ArrayList<>();
            for (BoxListResponse.Data item : mainList) {

                if (item.shipment_label == Integer.parseInt(dropDownList.get(position).substring(0, 6))) {
                    scrollList.add(item);
                }
            }

            Collections.sort(scrollList, new Comparator<BoxListResponse.Data>() {
                @Override
                public int compare(BoxListResponse.Data s1, BoxListResponse.Data s2) {
                    return s1.box_serial - s2.box_serial;
                }
            });

            Collections.reverse(scrollList);

            if (scrollList.size() > 0) {

                if (scrollList.size() >= 30) {
                    for (int i = 0; i < 30; i++) {
                        tempList.add(scrollList.get(i));
                    }
                } else {
                    tempList.addAll(scrollList);
                }
            }
            adapter.updateList(tempList);
            dialog.dismiss();
        }


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }
}