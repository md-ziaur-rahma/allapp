package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class ReboxingPost {
    @SerializedName("user_id")
    public int user_id;

    @SerializedName("box_label")
    public String box_label;

    @SerializedName("merchant_id")
    public int merchant_id;
}
