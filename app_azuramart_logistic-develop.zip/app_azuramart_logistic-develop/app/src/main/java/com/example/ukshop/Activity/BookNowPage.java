package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.app.Dialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.ukshop.R;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;

public class BookNowPage extends AppCompatActivity {


    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private ImageView mainImage;
    private TextView textSkuID, textColor, textSize, textPrice, textName;

    private TextView textAvlMy,textAvlUK,textAvlAIR,textAvlSEA,
            textBookedMy,textBookedUK,textBookedAIR,textBookedSEA;

    private EditText editextBookMY, editextBookUK,editextBookAIR,editextBookSEA;
    private Button bookBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_now_page);

        initialFindFields();




        bookBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }

        });

        /// Toolbar navigation home button's code...
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
    private void initialFindFields(){
        toolbar = (MaterialToolbar)findViewById(R.id.bookNowToolbarID);
        rootLayout = (CoordinatorLayout)findViewById(R.id.bookNowRootLayoutID);

        bookBtn = (Button)findViewById(R.id.BookNowBookBtnID);

        mainImage = (ImageView)findViewById(R.id.bookNowImageID);
        textSkuID= (TextView)findViewById(R.id.bookNowSkuID);
        textColor= (TextView)findViewById(R.id.bookNowColorID);
        textSize= (TextView)findViewById(R.id.bookNowSizeID);
        textPrice= (TextView)findViewById(R.id.bookNowPriceID);
        textName= (TextView)findViewById(R.id.bookNowProductNameID);

        textAvlMy= (TextView)findViewById(R.id.bookNowAvlQtyMyID);
        textAvlUK= (TextView)findViewById(R.id.bookNowAvlQtyUkID);
        textAvlAIR= (TextView)findViewById(R.id.bookNowAvlQtyAirID);
        textAvlSEA= (TextView)findViewById(R.id.bookNowAvlQtySeaID);
        textBookedMy= (TextView)findViewById(R.id.bookNowAlreadyBookedMyID);
        textBookedUK= (TextView)findViewById(R.id.bookNowAlreadyBookedUKID);
        textBookedAIR= (TextView)findViewById(R.id.bookNowAlreadyBookedAIRID);
        textBookedSEA= (TextView)findViewById(R.id.bookNowAlreadyBookedSeaID);

        editextBookMY= (EditText)findViewById(R.id.bookNowBookingQtyMyID);
        editextBookUK= (EditText) findViewById(R.id.bookNowBookingQtyUkID);
        editextBookAIR= (EditText)findViewById(R.id.bookNowBookingQtyAIRID);
        editextBookSEA= (EditText)findViewById(R.id.bookNowBookingQtySeaID);
    }

}