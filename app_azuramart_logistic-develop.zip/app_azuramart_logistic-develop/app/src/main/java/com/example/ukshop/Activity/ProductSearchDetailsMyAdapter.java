package com.example.ukshop.Activity;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.Models.ProductSearchDetailsMyModel;
import com.example.ukshop.NetworkModel.ProductSearchDetailsMyResponse;
import com.example.ukshop.R;

import java.util.List;

public class ProductSearchDetailsMyAdapter extends RecyclerView.Adapter {

    private List<ProductSearchDetailsMyResponse.Data> list;
    private Activity context;
    private CoordinatorLayout rootLayout;

    public ProductSearchDetailsMyAdapter(List<ProductSearchDetailsMyResponse.Data> list, Activity context, CoordinatorLayout rootLayout) {
        this.list = list;
        this.context = context;
        this.rootLayout = rootLayout;
    }

    @Override
    public int getItemViewType(int position) {
        switch (list.get(position).type){
            case 1:
                return ProductSearchDetailsMyModel.BOX_TYPE;
            case 2:
                return ProductSearchDetailsMyModel.LANDING_TYPE;
            case 3:
                return ProductSearchDetailsMyModel.SHELVE_TYPE;
            default:
                return -1;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.product_box_location_item_layout,parent,false);

        switch (viewType){
            case ProductSearchDetailsMyModel.BOX_TYPE:
                return new BoxQtyViewHolder(view);

            case ProductSearchDetailsMyModel.LANDING_TYPE:
                return new LandingQtyViewHolder(view);

            case ProductSearchDetailsMyModel.SHELVE_TYPE:
                return new ShelvedQtyViewHolder(view);
            default:
                return null;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        String label;
        int qty;
        String warehouse;
        String description;

        switch (list.get(position).type){
            case ProductSearchDetailsMyModel.BOX_TYPE:
                label = list.get(position).label;
                qty = list.get(position).qty;
                warehouse = list.get(position).warehouse;
                ((BoxQtyViewHolder) holder).setBoxData(qty,label,warehouse);
                break;

            case ProductSearchDetailsMyModel.LANDING_TYPE:
                qty = list.get(position).qty;
                warehouse = list.get(position).warehouse;
                description = list.get(position).description;
                ((LandingQtyViewHolder) holder).setLandingData(qty,warehouse,description);
                break;

            case ProductSearchDetailsMyModel.SHELVE_TYPE:
                label = list.get(position).label;
                qty = list.get(position).qty;
                warehouse = list.get(position).warehouse;
                description = list.get(position).description;
                ((ShelvedQtyViewHolder) holder).setShelvedData(qty,label,warehouse,description);
                break;

            default: return;
        }

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void updateList(List<ProductSearchDetailsMyResponse.Data> newList){
        list = newList;
        notifyDataSetChanged();
    }


    public class BoxQtyViewHolder extends RecyclerView.ViewHolder{

        private TextView boxLabel, boxStatus, warehouse, productCount;
        private ImageView greenCheck,bigIcon;

        public BoxQtyViewHolder(@NonNull View itemView) {
            super(itemView);

            greenCheck = itemView.findViewById(R.id.productBoxLocationGreenCheckID);
            boxLabel = itemView.findViewById(R.id.productBoxLocationLabelID);
            warehouse = itemView.findViewById(R.id.productBoxLocationWarehouseID);
            productCount = itemView.findViewById(R.id.productBoxLocationProductCountID);
            boxStatus = itemView.findViewById(R.id.productBoxLocationBoxstatusID);
            bigIcon = itemView.findViewById(R.id.productBoxLocationBigImageID);

        }

        public void setBoxData(int qty, String label, String warehouse){

            boxLabel.setText(label);
            productCount.setText("Qty : "+qty);
            this.warehouse.setText(warehouse);
            bigIcon.setImageResource(R.drawable.ic_box_list);

            boxLabel.setVisibility(View.VISIBLE);
            greenCheck.setVisibility(View.GONE);
            boxStatus.setVisibility(View.GONE);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

        }

    }

    public class ShelvedQtyViewHolder extends RecyclerView.ViewHolder{

        private TextView boxLabel, boxStatus, warehouse, productCount;
        private ImageView greenCheck,bigIcon;

        public ShelvedQtyViewHolder(@NonNull View itemView) {
            super(itemView);

            greenCheck = itemView.findViewById(R.id.productBoxLocationGreenCheckID);
            boxLabel = itemView.findViewById(R.id.productBoxLocationLabelID);
            warehouse = itemView.findViewById(R.id.productBoxLocationWarehouseID);
            productCount = itemView.findViewById(R.id.productBoxLocationProductCountID);
            boxStatus = itemView.findViewById(R.id.productBoxLocationBoxstatusID);
            bigIcon = itemView.findViewById(R.id.productBoxLocationBigImageID);
        }

        public void setShelvedData(int qty, String label, String warehouse, String description){

            boxLabel.setText("Shelve Label : "+label);
            productCount.setText("Qty : "+qty);
            this.warehouse.setText(warehouse);
            boxStatus.setText(description);
            bigIcon.setImageResource(R.drawable.ic_my_shelve);

            boxStatus.setVisibility(View.VISIBLE);
            boxLabel.setVisibility(View.VISIBLE);
            greenCheck.setVisibility(View.GONE);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

        }

    }

    public class LandingQtyViewHolder extends RecyclerView.ViewHolder{

        private TextView boxLabel, boxStatus, warehouse, productCount;
        private ImageView greenCheck, bigIcon;

        public LandingQtyViewHolder(@NonNull View itemView) {
            super(itemView);

            greenCheck = itemView.findViewById(R.id.productBoxLocationGreenCheckID);
            boxLabel = itemView.findViewById(R.id.productBoxLocationLabelID);
            warehouse = itemView.findViewById(R.id.productBoxLocationWarehouseID);
            productCount = itemView.findViewById(R.id.productBoxLocationProductCountID);
            boxStatus = itemView.findViewById(R.id.productBoxLocationBoxstatusID);
            bigIcon = itemView.findViewById(R.id.productBoxLocationBigImageID);
        }

        public void setLandingData(int qty, String warehouse,String description){

            productCount.setText("Qty : "+qty);
            this.warehouse.setText(warehouse);
            //bigIcon.setImageResource(R.drawable.ic_my_landing);
            bigIcon.setImageResource(R.drawable.ic_unboxed_new);
            this.boxStatus.setText(description);

            greenCheck.setVisibility(View.GONE);
            boxStatus.setVisibility(View.VISIBLE);
            boxLabel.setVisibility(View.GONE);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }

    }
}
