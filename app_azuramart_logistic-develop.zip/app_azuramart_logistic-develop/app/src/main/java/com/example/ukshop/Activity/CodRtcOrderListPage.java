package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.example.ukshop.Adapters.OrderListAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ConsignmentListPost;
import com.example.ukshop.NetworkModel.OrderListResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class CodRtcOrderListPage extends AppCompatActivity {

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private LinearLayout searchBtn;
    private EditText searchBox;

    private List<OrderListResponse.Data> list = new ArrayList<>();
    private RecyclerView recyclerView;
    private OrderListAdapter adapter;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cod_rtc_order_list_page);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new OrderListAdapter(list,rootLayout,this);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        if (Utils.broadcastIntent(CodRtcOrderListPage.this,rootLayout)){
            loadOrderData();
        }else {
            Utils.snackbarToast(rootLayout,"No Internet Connection!");
        }

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                int id = item.getItemId();
                if (id == R.id.menuShipment_refreshId){
                    if (Utils.broadcastIntent(CodRtcOrderListPage.this,rootLayout)){
                        loadOrderData();
                    }else {
                        Utils.snackbarToast(rootLayout,"No Internet Connection!");
                    }
                    return true;
                }

                return false;
            }
        });

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (list.size() > 0 ){
                    if (!TextUtils.isEmpty(s.toString())){
                        filterText(s.toString());
                    }else{
                        filterText("");
                    }
                }
            }
        });
    }

    private void filterText(String text){
        List<OrderListResponse.Data> tempOrderList = new ArrayList<>();
        ArrayList<OrderListResponse.Data> filteredList = new ArrayList<>();

        for (OrderListResponse.Data item : list){
            if (isMatches(text,String.valueOf(item.order_id))
                    ||isMatches(text,item.customer_name)
                    ||isMatches(text,item.customer_mobile)
            ){filteredList.add(item);}
        }

        if (filteredList.size() >= 20){
            for (int i = 0; i < 20; i++){
                tempOrderList.add(filteredList.get(i));
            }
        }else {
            tempOrderList.addAll(filteredList);
        }
        adapter.updateList(tempOrderList);
    }

    private boolean isMatches(String input,String name){
        String[] split = input.split(" ");
        for (String s : split){
            if (name.toLowerCase().contains(s.toLowerCase())){
                return true;
            }
        }
        return false;
    }

    private void initialFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.codRtcOrderListRootLayoutID);
        toolbar = (MaterialToolbar) findViewById(R.id.codRtcOrderListToolbarID);
        searchBox = (EditText)findViewById(R.id.codDispatchOrderSearchBarID);
        searchBtn = (LinearLayout)findViewById(R.id.codDispatchOrderSearchBtnID);
        recyclerView = (RecyclerView)findViewById(R.id.codRtcOrderListRecyclerID);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null) {
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()) {
            compositeDisposable.dispose();
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(CodRtcOrderListPage.this,rootLayout)){
            loadOrderData();
        }else {
            Utils.snackbarToast(rootLayout,"No Internet Connection!");
        }
    }

    private void loadOrderData(){

        list = new ArrayList<>();
        adapter.updateList(list);

        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        final ConsignmentListPost post = new ConsignmentListPost();
        post.user_id = user_id;

        Log.e("cod order list post", "msg"+new Gson().toJson(post));

        final Dialog dialog = new Dialog(CodRtcOrderListPage.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        compositeDisposable.add(mIRetrofitApi.getCodRtcOrderList(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<OrderListResponse>() {
            @Override
            public void accept(OrderListResponse response) throws Exception {
                if (response.status == 1){
                    list = response.data;
                    adapter.updateList(list);
                    dialog.dismiss();
                }else {
                    dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout, CodRtcOrderListPage.this);
                    }else {
                        Utils.snackbarToast(rootLayout,response.message);
                    }
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        }));
    }
}