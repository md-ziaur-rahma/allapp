package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ProductSearchDetailsMyResponse extends ApiResponse{

    @SerializedName("data")
    public ArrayList<Data> data;

    public class Data{
        @SerializedName("type")
        public int type;

        @SerializedName("label")
        public String label;

        @SerializedName("qty")
        public int qty;

        @SerializedName("warehouse")
        public String warehouse;

        @SerializedName("description")
        public String description;
    }
}
