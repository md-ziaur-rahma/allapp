package com.example.ukshop.Models;

public class BookingItemModel {
    private int productImage;
    private String productCode;
    private String productName;
    private String productBrand;
    private String productSize;
    private String productPrice;
    private String productQnt;
    private String date;


    public BookingItemModel(int productImage, String productCode, String productName,
                            String productBrand, String productSize, String productPrice,
                            String productQnt, String date) {
        this.productImage = productImage;
        this.productCode = productCode;
        this.productName = productName;
        this.productBrand = productBrand;
        this.productSize = productSize;
        this.productPrice = productPrice;
        this.productQnt = productQnt;
        this.date = date;
    }

    public BookingItemModel() {
    }

    public int getProductImage() {
        return productImage;
    }

    public void setProductImage(int productImage) {
        this.productImage = productImage;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductBrand() {
        return productBrand;
    }

    public void setProductBrand(String productBrand) {
        this.productBrand = productBrand;
    }

    public String getProductSize() {
        return productSize;
    }

    public void setProductSize(String productSize) {
        this.productSize = productSize;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductQnt() {
        return productQnt;
    }

    public void setProductQnt(String productQnt) {
        this.productQnt = productQnt;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
