package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.ukshop.Adapters.ImageShowAdapter;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;

import java.util.ArrayList;
import java.util.List;

public class ImageShowPage extends AppCompatActivity {

    // viewpager required variables...

    public static List<VariantImageResponse.Data> variantImageList = new ArrayList<>();
    LinearLayout sliderDotsPanel;
    private int dotsCount;
    private ImageView[] dots;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_show_page);

        ViewPager viewPager2;
        ImageShowAdapter viewpagerAdapter;
        viewPager2 = (ViewPager) findViewById(R.id.imageShowViewPagerID);
        sliderDotsPanel = (LinearLayout)findViewById(R.id.imageShowViewPagerDotLayoutID);


        viewpagerAdapter = new ImageShowAdapter(variantImageList,variantImageList.size(),ImageShowPage.this);
        viewPager2.setAdapter(viewpagerAdapter);

        dotsCount = viewpagerAdapter.getCount();
        dots = new ImageView[dotsCount];

        for (int i = 0; i<dotsCount; i++){
            dots[i] = new ImageView(this);
            dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.viewpager_non_active_dot));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(8,0,8,0);

            sliderDotsPanel.addView(dots[i],params);
        }

        dots[0].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.viewpager_active_dots));

        viewPager2.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                for (int i = 0; i<dotsCount; i++){
                    dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.viewpager_non_active_dot));
                }
                dots[position].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.viewpager_active_dots));

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }
}