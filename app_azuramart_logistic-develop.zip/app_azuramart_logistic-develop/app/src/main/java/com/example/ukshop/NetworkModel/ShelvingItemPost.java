package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class ShelvingItemPost {
    @SerializedName("user_id")
    public int user_id;

    @SerializedName("sku_id")
    public String sku_id;
}
