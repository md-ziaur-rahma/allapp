package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class OrderListResponse extends ApiResponse{

    @SerializedName("data")
    public ArrayList<Data> data;

    public static class Data{
        @SerializedName("order_id")
        public int order_id;

        @SerializedName("customer_name")
        public String customer_name;

        @SerializedName("customer_mobile")
        public String customer_mobile;

        @SerializedName("product_count")
        public int product_count;
    }
}
