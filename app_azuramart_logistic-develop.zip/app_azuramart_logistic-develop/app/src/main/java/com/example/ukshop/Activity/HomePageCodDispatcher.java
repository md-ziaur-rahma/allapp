package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ukshop.MasterProductPage;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.snackbar.Snackbar;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static maes.tech.intentanim.CustomIntent.customType;

public class HomePageCodDispatcher extends AppCompatActivity {

    private TextView userName, userLocation;
    private LinearLayout aboutBtn;
    private LinearLayout productList,checkEntry, shipmentList,productSearchBtn,
            codRtcDispatchZoneBtn,codRtcDispatchBtn,codStockListBtn, logoutBtn;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    IRetrofitApi mRetrofitApi;

    private CoordinatorLayout rootLayout;

    private boolean isInvalid = false;

    @Override
    public void overridePendingTransition(int enterAnim, int exitAnim) {
        super.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page_cod_dispatcher);

        mRetrofitApi = Common.getApiArobil();


        initialFindByID();


        userName.setText(SharedPreperenceUtils.getUserName(this));
        userLocation.setText(SharedPreperenceUtils.getUserLocation(this));

        productList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent masterIntent = new Intent(HomePageCodDispatcher.this, MasterProductPage.class);
                startActivity(masterIntent);
                customType(HomePageCodDispatcher.this,"left-to-right");
            }
        });

        checkEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePageCodDispatcher.this,CheckEntry.class);
                startActivity(intent);
                customType(HomePageCodDispatcher.this,"left-to-right");
            }
        });



        productSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent dispatchIntent = new Intent(HomePageCodDispatcher.this,ProductSearchMy.class);
                startActivity(dispatchIntent);
                customType(HomePageCodDispatcher.this,"left-to-right");
            }
        });

        shipmentList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent dispatchIntent = new Intent(HomePageCodDispatcher.this,ShipmentInprogress.class);
                startActivity(dispatchIntent);
                customType(HomePageCodDispatcher.this,"left-to-right");
            }
        });

        codRtcDispatchZoneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent boxingIntent = new Intent(HomePageCodDispatcher.this, CodRtcDispatchZone.class);
                startActivity(boxingIntent);
                customType(HomePageCodDispatcher.this,"left-to-right");
            }
        });

        codStockListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent boxingIntent = new Intent(HomePageCodDispatcher.this, CodRtcStockList.class);
                startActivity(boxingIntent);
                //customType(HomePageCodDispatcher.this,"left-to-right");
            }
        });

        codRtcDispatchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePageCodDispatcher.this, CodRtcOrderListPage.class);
                startActivity(intent);
                customType(HomePageCodDispatcher.this,"left-to-right");
                //Toast.makeText(HomePage.this, "Under development", Toast.LENGTH_SHORT).show();
            }
        });

        aboutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent(HomePageCodDispatcher.this, AboutUs.class);
                startActivity(returnIntent);
            }
        });

        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Dialog dialog = new Dialog(HomePageCodDispatcher.this,R.style.fadeDialog);
                dialog.setContentView(R.layout.dialog_logout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                Button OkBtn = dialog.findViewById(R.id.dialogeLogoutOkID);
                Button cancelBtn = dialog.findViewById(R.id.dialogeLogoutCancelID);

                cancelBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                OkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        SharedPreperenceUtils.removeShared(HomePageCodDispatcher.this,SharedPreperenceUtils.USER_ID);
                        SharedPreperenceUtils.clearUserData(HomePageCodDispatcher.this);

                        Intent intent = new Intent(HomePageCodDispatcher.this,LoginPage.class);
                        startActivity(intent);
                        //customType(HomePageCodDispatcher.this,"right-to-left");
                        dialog.dismiss();
                        finish();
                    }
                });

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootLayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootLayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
            snackbar.show();
        }
    }

    @Override
    public void onBackPressed() {

        final Dialog dialog = new Dialog(HomePageCodDispatcher.this,R.style.fadeDialog);
        dialog.setContentView(R.layout.dialog_logout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(true);
        dialog.show();

        final Button okBtn = dialog.findViewById(R.id.dialogeLogoutOkID);
        final Button cancelBtn = dialog.findViewById(R.id.dialogeLogoutCancelID);
        final TextView topMsg = dialog.findViewById(R.id.dialogLogoutTopTextID);
        final TextView msg = dialog.findViewById(R.id.dialogeLogoutTextMsgID);

        okBtn.setText("Exit");
        topMsg.setText("Warning!");
        msg.setText("Are you want to close app.. ?");

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
            }
        });


    }


    /// find all fields method....
    private void initialFindByID(){
        rootLayout = (CoordinatorLayout)findViewById(R.id.homePageDispatcherRootLayoutID);

        userName = (TextView)findViewById(R.id.homeUserNameID);
        userLocation = (TextView)findViewById(R.id.homeUserLocationID);
        aboutBtn = (LinearLayout)findViewById(R.id.homeAboutBtnID);
        productList = (LinearLayout)findViewById(R.id.homeDispatcherProductListId);
        checkEntry = (LinearLayout)findViewById(R.id.homeDispatcherCheckEntryBtnID);
        shipmentList = (LinearLayout)findViewById(R.id.homeDispatcherShipmentListBtnID);
        productSearchBtn = (LinearLayout)findViewById(R.id.homeDispatcherProductSearchBtnID);
        codRtcDispatchBtn = (LinearLayout)findViewById(R.id.homeDispatcherCodRtcDispatchBtnID) ;
        codStockListBtn = (LinearLayout)findViewById(R.id.homeDispatcherCodRtcStockListBtnID) ;
        codRtcDispatchZoneBtn = (LinearLayout)findViewById(R.id.homeDispatcherCodRtcDispatchZoneBtnID) ;
        logoutBtn = (LinearLayout)findViewById(R.id.homeDispatcherLogoutBtnID);
    }

    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ApiResponse>() {
            @Override
            public void accept(ApiResponse response) throws Exception {
                if (response.status == 0) {
                    isInvalid = true;
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));

        return isInvalid;
    }
}