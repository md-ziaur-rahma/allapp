package com.example.ukshop.Adapters;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.ImageShowPage;
import com.example.ukshop.Activity.ProductListPage;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.MasterProductDetailsResponse;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.google.android.material.snackbar.Snackbar;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class MasterProductDetailsAdapter extends RecyclerView.Adapter<MasterProductDetailsAdapter.ViewHolder> {

    private List<MasterProductDetailsResponse.Data> list;
    private Activity context;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;
    List<VariantImageResponse.Data> variantImageList = new ArrayList<>();

    public MasterProductDetailsAdapter(List<MasterProductDetailsResponse.Data> list, Activity context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public MasterProductDetailsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.stock_check_layout_2,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MasterProductDetailsAdapter.ViewHolder holder, int position) {
        String imageUrl = list.get(position).variant_primary_image;
        String primaryImage = list.get(position).primary_image;
        int pk_id = list.get(position).PK_NO;
        String skuId = list.get(position).sku_id;
        String barcode = list.get(position).barcode;
        String mktId = list.get(position).mkt_id;
        String name = list.get(position).product_name;
        String vaiantName = list.get(position).variant_name;
        String color = list.get(position).color;
        int isAir = list.get(position).is_air;
//        int is_air_count = list.get(position).is_air_count;
//        int is_sea_count = list.get(position).is_sea_count;
        String size = list.get(position).size;
        float price = list.get(position).price;
        float ins_price = list.get(position).ins_price;
        float sm_price = list.get(position).sm_price;
        float ss_price = list.get(position).ss_price;
        int qty = list.get(position).available_qty;

        holder.setData(skuId,barcode,mktId,pk_id,name,vaiantName,
                primaryImage,imageUrl,color,isAir,size,price,ins_price,sm_price,ss_price,qty,position);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void filterdItem(ArrayList<MasterProductDetailsResponse.Data> filteredList){
        list = filteredList;
        notifyDataSetChanged();
    }

    public void updateList(List<MasterProductDetailsResponse.Data> updateList){
        list = updateList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private ImageView variant_iamge, seaIcon,airIcon;
        private TextView name,skuId,ig_code,barcode,size,
                color,isAir,price,price2,qty,airText,seaText,
                airQty, seaQty;
        private Button bookBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            variant_iamge = itemView.findViewById(R.id.stock_check_item_imageID);
            name = itemView.findViewById(R.id.stock_check_item_nameID);
            skuId = itemView.findViewById(R.id.stock_check_item_skuID);

            skuId.setVisibility(View.GONE);

            barcode = itemView.findViewById(R.id.stock_check_item_barcodeID);
            ig_code = itemView.findViewById(R.id.stock_check_item_IGCODEID);
            size = itemView.findViewById(R.id.stock_check_item_sizeID);
            color = itemView.findViewById(R.id.stock_check_item_colorID);

            airText = itemView.findViewById(R.id.stock_check_item_airID);
            seaText = itemView.findViewById(R.id.stock_check_item_seaID);
            airIcon = itemView.findViewById(R.id.stock_check_item_airIconID);
            seaIcon = itemView.findViewById(R.id.stock_check_item_seaIconID);
            airQty = itemView.findViewById(R.id.stock_check_item_airQtyID);
            seaQty = itemView.findViewById(R.id.stock_check_item_seaQtyID);

            price = itemView.findViewById(R.id.stock_check_item_priceID);
            price2 = itemView.findViewById(R.id.stock_check_item_price2ID);
            qty = itemView.findViewById(R.id.stock_check_item_qntID);

            bookBtn = itemView.findViewById(R.id.stock_check_item_buttonID);
        }

        public void setData(final String sku,final String barcode, String mktid, final int pk_id, String name, String variant_Name,String primaryImage, String imageUrl,
                            String color,final int isAir, String size, float price,final float ins_price,final float sm_price, final float ss_price, int quantity, final int position){

            if (imageUrl == null || imageUrl.equals("")){
                primaryImage = Common.BASEURL_PICTURE+primaryImage;
                Glide.with(context)
                        .load(primaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_iamge);
            }else {
                imageUrl = Common.BASEURL_PICTURE+imageUrl;
                Glide.with(context)
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_iamge);
            }


            if (variant_Name == null || variant_Name == ""){
                this.name.setText(name);
            }else {
                this.name.setText(variant_Name);
            }

            skuId.setText("SKU : "+sku);
            this.barcode.setText("Barcode : "+barcode);
            this.ig_code.setText("IG CODE : "+mktid);
            this.color.setText("Color : "+color);

            if (isAir == 1){
                this.seaIcon.setVisibility(View.GONE);
                this.seaText.setVisibility(View.GONE);
                this.seaQty.setVisibility(View.GONE);
                airQty.setVisibility(View.GONE);
                airIcon.setVisibility(View.VISIBLE);
                airText.setVisibility(View.VISIBLE);

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                params.setMargins(0,0,0,0);
                airText.setLayoutParams(params);

                this.airIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#4F1B35")));
            }else if (isAir == 0){
                this.airIcon.setVisibility(View.GONE);
                this.airText.setVisibility(View.GONE);
                this.airQty.setVisibility(View.GONE);
                seaQty.setVisibility(View.GONE);
                seaIcon.setVisibility(View.VISIBLE);
                seaText.setVisibility(View.VISIBLE);
                this.seaIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#4F1B35")));
            }

            if (isAir == 1){
                this.airIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#35cce3")));
            }else {
                this.airIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#35cce3")));
            }

            this.size.setText("Size : "+size);

            NumberFormat formatter = new DecimalFormat("#0.00");

            this.price.setText("RM "+formatter.format(price)+"  / "+formatter.format(ins_price));
            this.price2.setText("SM "+formatter.format(sm_price)+"  / SS "+formatter.format(ss_price));

            this.qty.setText("Qty : "+quantity);

            this.qty.setVisibility(View.GONE);
            this.bookBtn.setVisibility(View.GONE);

            variant_iamge.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mIRetrofitApi = Common.getApiArobil();
                    String token = SharedPreperenceUtils.getToken(context);

                    compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<VariantImageResponse>() {
                        @Override
                        public void accept(VariantImageResponse response) throws Exception {
                            if (response.status == 1){
                                variantImageList = response.data;
                                ImageShowPage.variantImageList = variantImageList;
                                Intent intent = new Intent(context, ImageShowPage.class);
                                itemView.getContext().startActivity(intent);

                                /**

                                final Dialog dialog = new Dialog(context);
                                dialog.setContentView(R.layout.dialoge_master_details_show_variant_image);

                                int width = WindowManager.LayoutParams.MATCH_PARENT;
                                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                                dialog.getWindow().setLayout(width,height);
                                dialog.setCancelable(true);
                                dialog.show();

                                LinearLayout imageContainer = dialog.findViewById(R.id.masterDetailsImageDialogeContainerID);
                                int imagecounts = variantImageList.size();
                                ImageView[] image;

                                image = new ImageView[imagecounts];

                                for (int i = 0; i<imagecounts; i++){

                                    String instImageUrl = Common.BASEURL_PICTURE+variantImageList.get(i).mp_image;

                                    image[i] = new ImageView(context);
                                    Glide.with(context)
                                            .load(instImageUrl)
                                            .placeholder(R.drawable.ic_default)
                                            .into(image[i]);

                                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(300, 250);
                                    params.setMargins(8,0,8,0);
                                    image[i].setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#c1c1c1")));
                                    imageContainer.addView(image[i],params);
                                }

                                 */

                            }else {

                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    }));
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

        }
    }
}
