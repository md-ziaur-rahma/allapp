package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class DispatchConsignmentItemPost {
    @SerializedName("user_id")
    public int user_id;

    @SerializedName("consignment_label")
    public String consignment_label;
}
