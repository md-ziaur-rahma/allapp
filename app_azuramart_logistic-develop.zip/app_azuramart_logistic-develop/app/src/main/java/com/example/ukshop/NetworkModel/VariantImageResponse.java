package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class VariantImageResponse extends ApiResponse{

    @SerializedName("data")
    public ArrayList<Data> data;

    public class Data{
        @SerializedName("mp_image")
        public String mp_image;
    }
}
