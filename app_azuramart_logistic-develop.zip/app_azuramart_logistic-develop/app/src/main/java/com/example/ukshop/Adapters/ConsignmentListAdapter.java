package com.example.ukshop.Adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.NetworkModel.ConsignmentListResponse;
import com.example.ukshop.R;

import java.util.List;

public class ConsignmentListAdapter extends RecyclerView.Adapter<ConsignmentListAdapter.ViewHolder> {

    private List<ConsignmentListResponse.Data> list;
    private Activity context;
    private CoordinatorLayout rootLayout;

    public ConsignmentListAdapter(List<ConsignmentListResponse.Data> list, Activity context, CoordinatorLayout rootLayout) {
        this.list = list;
        this.context = context;
        this.rootLayout = rootLayout;
    }

    @NonNull
    @Override
    public ConsignmentListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.consignment_note_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ConsignmentListAdapter.ViewHolder holder, int position) {
        String label = list.get(position).consignment_label;
        int productCount = list.get(position).product_count;
        int pickedCount = list.get(position).picked_count;

        holder.setData(label,productCount,pickedCount,position);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void updateList(List<ConsignmentListResponse.Data> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        final private TextView label,orderCount,productCount;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            label = itemView.findViewById(R.id.consignment_note_labelID);
            orderCount = itemView.findViewById(R.id.consignment_note_orderCountID);
            productCount = itemView.findViewById(R.id.consignment_note_productCountID);
        }

        public void setData(final String label, final int productCount,final int pickedCount,final int position){
            this.label.setText(label);
            this.orderCount.setVisibility(View.GONE);
            this.productCount.setText("Product Count : "+pickedCount+"/"+productCount);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }
    }
}
