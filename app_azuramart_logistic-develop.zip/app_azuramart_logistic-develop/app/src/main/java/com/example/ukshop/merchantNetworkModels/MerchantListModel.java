package com.example.ukshop.merchantNetworkModels;

import com.example.ukshop.NetworkModel.ApiResponse;
import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;

public class MerchantListModel extends ApiResponse {
    @SerializedName("data")
    public ArrayList<Data> data;

    public static class Data{
        @SerializedName("merchant_pk")
        public int merchant_pk;

        @SerializedName("merchant_name")
        public String merchant_name;
    }
}
