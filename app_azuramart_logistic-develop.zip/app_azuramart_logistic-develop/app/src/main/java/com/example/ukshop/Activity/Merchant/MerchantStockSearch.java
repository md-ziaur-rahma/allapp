package com.example.ukshop.Activity.Merchant;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.ukshop.Activity.BoxlistPage;
import com.example.ukshop.Activity.StockCheckPage;
import com.example.ukshop.Adapters.StockCheckAdapter;
import com.example.ukshop.MerchantAdapters.MerchantStockCheckAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.StockCheckPost;
import com.example.ukshop.NetworkModel.StockCheckSearchResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.example.ukshop.merchantNetworkModels.MerchantListModel;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class MerchantStockSearch extends AppCompatActivity implements ZXingScannerView.ResultHandler, AdapterView.OnItemSelectedListener {
    private EditText skuText, mktText, productNameText;
    private Button stockCheckBtn;
    private CoordinatorLayout rootLayout;
    private NestedScrollView nestedScrollView;
    private ExtendedFloatingActionButton scanProductFabBtn;
    private Spinner spinner;
    private List<String> dropDownList = new ArrayList<>();
    private ArrayAdapter<String> spinnerAdapter;

    String sku_idT;
    String mkt_idT;
    String product_nameT;

    /// ............. merchant list .............
    private int merchant_pkT;
    private String merchantName;
    
    private List<MerchantListModel.Data> merchantListModelList = new ArrayList<>();

    private final CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;


    private RecyclerView recyclerView;
    private MerchantStockCheckAdapter merchantStockCheckAdapter;

    private List<StockCheckSearchResponse.Data> stockSearchList = new ArrayList<>();
    public List<StockCheckSearchResponse.Data> stockList = new ArrayList<>();


    private static boolean isShow = false;

    private MaterialToolbar toolbar;
    private static final int CAMERA_REQUEST_CODE = 501;

    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static boolean isFlash = false;

    private boolean isInvalid = false;

    // Media Player Variable...
    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();

    private static int isTone = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchant_stock_search);
        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();
        spinner.setOnItemSelectedListener(this);
        spinner.setVisibility(View.GONE);
//        loadMerchant();

        merchant_pkT = getIntent().getIntExtra("merchant_pk",0);
        merchantName = getIntent().getStringExtra("merchant_name");

        isShow = getIntent().getBooleanExtra("isShow",false);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        stockCheckBtn.setOnClickListener(v -> {
            sku_idT = skuText.getText().toString();
            mkt_idT = mktText.getText().toString();
            product_nameT = productNameText.getText().toString();

//            if (TextUtils.isEmpty(sku_idT) && TextUtils.isEmpty(mkt_idT) && TextUtils.isEmpty(product_nameT)){
//                Toast.makeText(MerchantStockSearch.this, "Search fields are empty!", Toast.LENGTH_LONG).show();
//            }
            if (TextUtils.isEmpty(sku_idT)){
                sku_idT = "";
            }

            if (TextUtils.isEmpty(mkt_idT)){
                mkt_idT = "";
            }

            if (TextUtils.isEmpty(product_nameT)){
                product_nameT = "";
            }

            if (Utils.broadcastIntent(MerchantStockSearch.this,rootLayout)){
                if (merchant_pkT != 0){
                    loadData(sku_idT, mkt_idT, product_nameT,"",merchant_pkT);
                } else {
                    Toast.makeText(this, "Select a merchant", Toast.LENGTH_LONG).show();
                }

            } else {
                NoInternetSnackBar();
            }
        });
        /// Toolbar code....
        toolbar.setNavigationOnClickListener(v -> {
            isShow = false;
            finish();
        });
        toolbar.setTitle("Stock Search ("+merchantName+")");
        scanProductFabBtn.setOnClickListener(v -> {
            if (Utils.isCameraPermission(MerchantStockSearch.this)){
                openScanner();
            }else {
                ActivityCompat.requestPermissions(MerchantStockSearch.this,new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST_CODE);
            }
        });

        scanProductFabBtn.setOnLongClickListener(v -> {
            final Dialog dialog = new Dialog(MerchantStockSearch.this);
            dialog.setContentView(R.layout.barcod_picker_layout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(true);
            dialog.show();

            final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
            final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
            Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
            // barcodeText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(10)});

            search.setText(R.string.search);

            cancel.setOnClickListener(v12 -> dialog.dismiss());

            search.setOnClickListener(v1 -> {
                if (!TextUtils.isEmpty(barcodeText.getText().toString())){
                    loadData("","","",barcodeText.getText().toString(),merchant_pkT);
                    dialog.dismiss();
                }else {
                    barcodeText.requestFocus();
                    Toast.makeText(MerchantStockSearch.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                }
            });

            return false;
        });

        if (Utils.broadcastIntent(this,rootLayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootLayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
            snackbar.show();
        }
        nestedScrollView.setOnScrollChangeListener((NestedScrollView.OnScrollChangeListener) (v, scrollX, scrollY, oldScrollX, oldScrollY) -> {

            if(v.getChildAt(v.getChildCount() - 1) != null) {
                if ((scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight())) &&
                        scrollY > oldScrollY) {

                    //https://medium.com/@mujjtahidah/load-more-recyclerview-inside-nested-scroll-view-and-coordinator-layout-4f179dc01fd

                    if (!recyclerView.canScrollVertically(1)){
                        onScrollToBottom();
                    }
                }
            }

        });
    }

    private void onScrollToBottom(){
        if (stockList.size() < stockSearchList.size()){
            int x,y;
            if ((stockSearchList.size() - stockList.size()) >= 20){
                x = stockList.size();
                y = x + 20;
            }else {
                x = stockList.size();
                y = x + stockSearchList.size() - stockList.size();
            }

            for (int i = x; i < y; i++){
                stockList.add(i,stockSearchList.get(i));
            }

            merchantStockCheckAdapter.filteredItem(stockList);
        }
    }

    private void openScanner(){
        scannerDialog = new Dialog(MerchantStockSearch.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);



        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(MerchantStockSearch.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(v -> {
            scannerView.stopCamera();
            scannerDialog.dismiss();
        });

        scannerFlash.setOnClickListener(v -> {
            if (isFlash){
                scannerFlash.setImageResource(R.drawable.ic_flash_off);
                scannerView.setFlash(false);
                isFlash = false;
            }else {
                scannerFlash.setImageResource(R.drawable.ic_flash_on);
                scannerView.setFlash(true);
                isFlash = true;
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootLayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootLayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
            snackbar.show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CAMERA_REQUEST_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    private void initialFindFields(){
        rootLayout = findViewById(R.id.merchantStockSearchRootLayoutID);
        nestedScrollView = findViewById(R.id.merchantStockSearchNestedScrollID);
        toolbar = findViewById(R.id.merchantStockSearchToolBarId);
        scanProductFabBtn = findViewById(R.id.merchantStockCheckFabBtnID);
        skuText = findViewById(R.id.stockCheckSKUId);
        mktText = findViewById(R.id.stockCheckMKTId);
        productNameText = findViewById(R.id.stockChectProductNameID);
        stockCheckBtn = findViewById(R.id.stockCheckBtnID);
        recyclerView = findViewById(R.id.merchantStockCheckRecyclerID);
        spinner = findViewById(R.id.merchantListStockSearchSpinnerID);
    }

    @SuppressLint("NotifyDataSetChanged")
    private void loadData(String skuL, String mkuL, String productNameL, String barcode,int merchantPk){

        stockSearchList = new ArrayList<>();
        if (isShow){
            merchantStockCheckAdapter = new MerchantStockCheckAdapter(stockSearchList,MerchantStockSearch.this,1,rootLayout);
        }else {
            merchantStockCheckAdapter = new MerchantStockCheckAdapter(stockSearchList,MerchantStockSearch.this,2,rootLayout);
        }
        recyclerView.setAdapter(merchantStockCheckAdapter);
        merchantStockCheckAdapter.notifyDataSetChanged();

        final Dialog dialog = new Dialog(MerchantStockSearch.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        String token = SharedPreperenceUtils.getToken(MerchantStockSearch.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(MerchantStockSearch.this));

        final StockCheckPost checkPost = new StockCheckPost();
        checkPost.user_id = user_id;
        checkPost.barcode = barcode;
        checkPost.sku_id = skuL;
        checkPost.mkt_id = mkuL;
        checkPost.product_name = productNameL;
        checkPost.merchant_pk = merchantPk;
        Log.e("merchant-stock-search", "request : " + new Gson().toJson(checkPost));
        compositeDisposable.add(mIRetrofitApi.getMerchantStockSearchList(token,checkPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
            if (response.status == 1){

                if (isTone == 1){
                    rightTone.start();
                    isTone = 0;
                }

                stockSearchList = new ArrayList<>();
                stockList = new ArrayList<>();

                stockSearchList = response.data;

                if (stockSearchList.size() >= 30){
                    for (int i = 0;i < 30; i++){
                        stockList.add(i, stockSearchList.get(i));
                    }
                }else {
                    stockList.addAll(stockSearchList);
                }

                merchantStockCheckAdapter.addItem(stockList);
                dialog.dismiss();


            }else if (response.status == 0){

                if (isTone == 1){
                    wrongTone.start();
                    isTone = 0;
                }

                dialog.dismiss();

                if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                    Utils.expiredTokenAlert(rootLayout,MerchantStockSearch.this);
                }else {
                    Utils.snackbarToast(rootLayout,response.message);
                }
            }
        }, throwable -> {

            if (isTone == 1){
                wrongTone.start();
                isTone = 0;
            }

            dialog.dismiss();

            if (Objects.requireNonNull(throwable.getMessage()).toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 3000);
                snackbar.show();
            }else {
                Utils.snackbarToast(rootLayout,throwable.getMessage());
            }
        }));
    }
    
    private void loadMerchant() {
        merchantListModelList = new ArrayList<>();
        dropDownList = new ArrayList<>();
        String token = SharedPreperenceUtils.getToken(MerchantStockSearch.this);
        compositeDisposable.add(mIRetrofitApi.getMerchantList(token).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
            if (response.status == 1){
                merchantListModelList = response.data;
                dropDownList.add("Select a merchant");
                for (MerchantListModel.Data model : merchantListModelList) {
                    dropDownList.add(model.merchant_name);
                }
                spinnerAdapter = new ArrayAdapter<>(MerchantStockSearch.this, android.R.layout.simple_expandable_list_item_1, dropDownList);
                spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(spinnerAdapter);
            } else if (response.status == 0){
                dropDownList.add("Select a merchant");
            }
        }, throwable -> {
            dropDownList.add("Select a merchant");
        }));
    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",3000);
        snackbar.setAction("Retry", v -> {
            if (Utils.broadcastIntent(MerchantStockSearch.this,rootLayout)){
                loadData(sku_idT,mkt_idT,product_nameT,"",merchant_pkT);
            }else {
                NoInternetSnackBar();
            }
        });

        snackbar.show();
    }

    @Override
    public void handleResult(final Result rawResult) {

        if (!TextUtils.isEmpty(rawResult.getText())){
            isTone = 1;
            scannerDialog.dismiss();
            loadData("","","",rawResult.getText(),merchant_pkT);
        }else {
            wrongTone.start();
        }
    }


    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mIRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
            if (response.status == 0) {
                isInvalid = true;
            }
        }, throwable -> {

        }));

        return isInvalid;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (position != 0){
            merchant_pkT = merchantListModelList.get(position-1).merchant_pk;
        } else {
            merchant_pkT = 0;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}