package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ShipmentInprogressResponse extends ApiResponse{

    @SerializedName("data")
    public ArrayList<Data> data;

    public class Data{
        @SerializedName("shipment_no")
        public int shipment_no;

        @SerializedName("shipment_label")
        public int shipment_label;

        @SerializedName("departure_time")
        public String departure_time;

        @SerializedName("SHORT_NAME")
        public String short_name;

        @SerializedName("ETA_date")
        public String ETA_date;

        @SerializedName("status")
        public int status;

        @SerializedName("box_count")
        public int box_count;

        @SerializedName("received_qty")
        public int received_qty;

        @SerializedName("is_air")
        public int is_air;

        @SerializedName("merchant_id")
        public int merchant_id;

        @SerializedName("merchant_name")
        public String merchant_name;
    }
}
