package com.example.ukshop.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.Activity.CodRtcDispatchPage;
import com.example.ukshop.NetworkModel.OrderListResponse;
import com.example.ukshop.R;
import static maes.tech.intentanim.CustomIntent.customType;

import java.util.List;

public class OrderListAdapter extends RecyclerView.Adapter<OrderListAdapter.ViewHolder> {

    private List<OrderListResponse.Data> list;
    private CoordinatorLayout rootLayout;
    private Activity context;

    public OrderListAdapter(List<OrderListResponse.Data> list, CoordinatorLayout rootLayout, Activity context) {
        this.list = list;
        this.rootLayout = rootLayout;
        this.context = context;
    }

    @NonNull
    @Override
    public OrderListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.consignment_note_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderListAdapter.ViewHolder holder, int position) {
        int orderId = list.get(position).order_id;
        String customerName = list.get(position).customer_name;
        String mobile = list.get(position).customer_mobile;
        int productCount = list.get(position).product_count;

        String mob_count = "Qty : "+productCount+"\nMobile : "+mobile;

        holder.setData(orderId,customerName,mobile,productCount,mob_count,position);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void updateList(List<OrderListResponse.Data> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView orderId,name,mobile;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            orderId = itemView.findViewById(R.id.consignment_note_labelID);
            name = itemView.findViewById(R.id.consignment_note_orderCountID);
            mobile = itemView.findViewById(R.id.consignment_note_productCountID);

        }

        public void setData(final int orderID,final String name, final String mobile, final int productCount,final String mob_count,final int position){
            this.orderId.setText("Order id : "+orderID);
            this.name.setText(name);
            this.mobile.setText(mob_count);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final CodRtcDispatchPage dispatchPage = new CodRtcDispatchPage();
                    CodRtcDispatchPage.orderNo = orderID;
                    CodRtcDispatchPage.c_mobile = mobile;
                    CodRtcDispatchPage.c_name = name;

                    Intent intent = new Intent(context,CodRtcDispatchPage.class);
                    itemView.getContext().startActivity(intent);
                    //customType(context,"left-to-right");
                }
            });

        }
    }


}
