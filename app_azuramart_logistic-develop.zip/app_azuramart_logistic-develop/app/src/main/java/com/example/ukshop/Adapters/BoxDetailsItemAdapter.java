package com.example.ukshop.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.ImageShowPage;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ReboxingResponse;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class BoxDetailsItemAdapter extends RecyclerView.Adapter<BoxDetailsItemAdapter.ViewHolder> {

    private List<ReboxingResponse.Data> mainList;
    private Activity context;
    private CoordinatorLayout rootLayout;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;
    List<VariantImageResponse.Data> variantImageList = new ArrayList<>();

    public BoxDetailsItemAdapter(List<ReboxingResponse.Data> mainList, Activity context, CoordinatorLayout rootLayout) {
        this.mainList = mainList;
        this.context = context;
        this.rootLayout = rootLayout;
    }

    @NonNull
    @Override
    public BoxDetailsItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.boxing_item_full_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        int pk_id = mainList.get(position).PK_NO;
        String imageUrl = mainList.get(position).variant_primary_image;
        String primaryImage = mainList.get(position).primary_image;
        String skuId = mainList.get(position).sku_id;
        String mktId = mainList.get(position).mkt_id;
        String name = mainList.get(position).product_name;
        String variantName = mainList.get(position).variant_name;
        String color = mainList.get(position).color;
        int is_air = mainList.get(position).is_air;
        String size = mainList.get(position).size;
        int qty = mainList.get(position).available_qty;
        int givenQty = mainList.get(position).given_qty;
        int unboxedQty = mainList.get(position).unboxed_qty;
        int product_status = mainList.get(position).product_status;
        String barcode = mainList.get(position).barcode;


        holder.setData(pk_id,qty,position,primaryImage,imageUrl,skuId,
                mktId,name,variantName,color, is_air,size,givenQty,unboxedQty,product_status,barcode);
    }

    @Override
    public int getItemCount() {
        return mainList.size();
    }

    public void updateData(List<ReboxingResponse.Data> newList){
        mainList = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView qty,avl_qty;
        ImageView delete, edit;

        private ImageView variant_image;
        private TextView name,skuId,size,color, is_air;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            variant_image = itemView.findViewById(R.id.boxingl_item_imageID);
            name = itemView.findViewById(R.id.boxingl_item_nameID);
            skuId = itemView.findViewById(R.id.boxingl_item_skuID);
            size = itemView.findViewById(R.id.boxingl_item_sizeID);
            color = itemView.findViewById(R.id.boxingl_item_colorID);
            is_air = itemView.findViewById(R.id.boxingl_item_is_airID);

            avl_qty = itemView.findViewById(R.id.boxingl_item_avl_qntID);
            qty = itemView.findViewById(R.id.boxingl_item_qntID);
            delete = itemView.findViewById(R.id.boxingl_item_deleteBtnID);
            edit = itemView.findViewById(R.id.boxingl_item_editBtnID);

        }

        public void setData(final int pk_id,final int qty, final int position, final String primaryImage,
                            final String variantImage, final String sku, final String mkt, final String name, final String variantName,
                            final String color,final int is_air, final String size, final int givenQty,final int unboxedQty,final int product_status, final String barcode ) {
            String insPrimaryImage = Common.BASEURL_PICTURE + primaryImage;

            if (variantImage == null || variantImage.equals("")) {
                Glide.with(context)
                        .load(insPrimaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_image);
            } else {
                String insVariantImage = Common.BASEURL_PICTURE + variantImage;


                Glide.with(context)
                        .load(insVariantImage)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_image);
            }


            if (variantName == null || variantName.equals("")) {
                this.name.setText(name);
            } else {
                this.name.setText(variantName);
            }

            //this.skuId.setText("SKU : "+sku);
            this.skuId.setText("Barcode : " +barcode);
            this.color.setText("Color : " + color);

            if (is_air == 1){
                this.is_air.setText("Air");
            }else if (is_air == 0){
                this.is_air.setText("Sea");
            }

            this.is_air.setVisibility(View.GONE);

            this.size.setText("Size : " + size);

            this.qty.setText("Qty : " +unboxedQty+"/"+ givenQty);
            //this.avl_qty.setText("Avl Qty : " + qty);

            this.avl_qty.setVisibility(View.GONE);

            if (givenQty > unboxedQty && product_status >= 50){
                edit.setImageResource(R.drawable.ic_warning);
                edit.setImageTintList(ColorStateList.valueOf(Color.parseColor("#F0D500")));
                edit.setVisibility(View.VISIBLE);
            } else {
                edit.setVisibility(View.GONE);
            }

            delete.setVisibility(View.GONE);


            itemView.setOnClickListener(v -> {

            });

            variant_image.setOnClickListener(v -> {
                mIRetrofitApi = Common.getApiArobil();
                String token = SharedPreperenceUtils.getToken(context);

                compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<VariantImageResponse>() {
                    @Override
                    public void accept(VariantImageResponse response) throws Exception {
                        if (response.status == 1){
                            variantImageList = response.data;
                            ImageShowPage.variantImageList = variantImageList;
                            Intent intent = new Intent(context, ImageShowPage.class);
                            itemView.getContext().startActivity(intent);

                        } else {

                        }
                    }
                }, throwable -> {

                }));
            });

        }
    }
}
