package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class UnshelvingItemPost {
    @SerializedName("user_id")
    public int user_id;

    @SerializedName("shelve_label")
    public String shelve_label;

    @SerializedName("sku_id")
    public String sku_id;
}
