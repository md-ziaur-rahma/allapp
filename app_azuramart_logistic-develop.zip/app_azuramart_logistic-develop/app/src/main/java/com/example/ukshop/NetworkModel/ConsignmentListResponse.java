package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ConsignmentListResponse extends ApiResponse{

    @SerializedName("data")
    public ArrayList<Data> data;

    public static class Data{
        @SerializedName("consignment_label")
        public String consignment_label;

        @SerializedName("product_count")
        public int product_count;

        @SerializedName("picked_count")
        public int picked_count;
    }
}
