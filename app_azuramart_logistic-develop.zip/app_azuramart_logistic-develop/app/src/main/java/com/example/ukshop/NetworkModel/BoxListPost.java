package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class BoxListPost {
    @SerializedName("user_id")
    public int user_id;

    @SerializedName("shipment_no")
    public int shipment_no;

    @SerializedName("merchant_id")
    public int merchant_id;
}
