package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.ukshop.Adapters.ConsignmentListAdapter;
import com.example.ukshop.Adapters.RtsDispatchConsignmentItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ConsignmentListPost;
import com.example.ukshop.NetworkModel.ConsignmentListResponse;
import com.example.ukshop.NetworkModel.DispatchConsignmentItemPost;
import com.example.ukshop.NetworkModel.RtsDispatchConsignmentItemResponse;
import com.example.ukshop.NetworkModel.DispatchItemSubModel;
import com.example.ukshop.NetworkModel.RtsDispatchPost;
import com.example.ukshop.NetworkModel.DispatchResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class RtsDispatchPage extends AppCompatActivity implements ZXingScannerView.ResultHandler {

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private ExtendedFloatingActionButton dispatchFabBtn;
    private Button scanItemBtn;
    private Button scanConsignmentBtn;

    private LinearLayout instructionView;
    private TextView instructionText;
    private CheckBox instructionCheck;
    private ImageView instructionIcon;
    private Animation bounceAnimation,zoom_in_out;
    private int isAnim = 0;

    private RecyclerView recyclerView;
    private RtsDispatchConsignmentItemAdapter adapter;
    private List<RtsDispatchConsignmentItemResponse.Data> list = new ArrayList<>();


    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;


    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static final int CAMERA_PERMISSION_CODE = 501;


    private static boolean isFlash = false;

    private int consignmentORProduct = -1;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();
    private int isTone = 0;

    private String consignmentLabel = "";
    private int countProduct = 0;
    private int totalCountProduct = 0;
    private int instruction = 0;

    //....................... consignment list .....................//
    private ExtendedFloatingActionButton consignmentListFabBtn;
    private List<ConsignmentListResponse.Data> consignmentList = new ArrayList<>();
    private ConsignmentListAdapter consignmentListAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rts_dispatch_page);

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);
        bounceAnimation = AnimationUtils.loadAnimation(this,R.anim.bounce_infinite);
        zoom_in_out = AnimationUtils.loadAnimation(this,R.anim.zoom_in_out);
        //bounceAnimation.setRepeatCount(Animation.INFINITE);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new RtsDispatchConsignmentItemAdapter(list,this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        //consignmentListFabBtn.hide();
        inVisibleBtn();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.menuShipment_refreshId){
                    if (Utils.broadcastIntent(RtsDispatchPage.this,rootLayout)){
                        inVisibleBtn();
                        loadConsignmentList();
                    }else {
                        Utils.snackbarToast(rootLayout,"No internet connection!");
                    }
                }
                return false;
            }
        });

        scanConsignmentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(RtsDispatchPage.this)) {
                    consignmentORProduct = 1;
                    isTone = 1;
                    openScanner();
                } else {
                    ActivityCompat.requestPermissions(RtsDispatchPage.this,
                            new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
                }
            }
        });

        scanConsignmentBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                isTone = 0;
                final Dialog dialog = new Dialog(RtsDispatchPage.this,R.style.PauseDialog);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);

                barcodeText.setInputType(InputType.TYPE_CLASS_TEXT);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){
                            if (Utils.broadcastIntent(RtsDispatchPage.this,rootLayout)){
                                loadData(barcode);
                                dialog.dismiss();
                            }else {
                                dialog.dismiss();
                                Utils.snackbarToast(rootLayout,"No internet connection!");
                            }
                        }else {
                            Toast.makeText(RtsDispatchPage.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });

                return false;
            }
        });

        scanItemBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(RtsDispatchPage.this)) {
                    consignmentORProduct = 2;
                    isTone = 1;
                    openScanner();
                } else {
                    ActivityCompat.requestPermissions(RtsDispatchPage.this,
                            new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
                }
            }
        });

        scanItemBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                isTone = 0;
                final Dialog dialog = new Dialog(RtsDispatchPage.this,R.style.PauseDialog);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);

                barcodeText.setInputType(InputType.TYPE_CLASS_TEXT);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){
                            if (Utils.broadcastIntent(RtsDispatchPage.this,rootLayout)){
                                checkProduct(barcode);
                                dialog.dismiss();
                            }else {
                                dialog.dismiss();
                                Utils.snackbarToast(rootLayout,"No internet connection!");
                            }
                        }else {
                            Toast.makeText(RtsDispatchPage.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });

                return false;
            }
        });

        instructionCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    instruction = 0;
                    instructionIcon.clearAnimation();
                    bounceAnimation.cancel();
                }else {
                    instruction = 1;
//                    bounceAnimation = AnimationUtils.loadAnimation(RtsDispatchPage.this,R.anim.bounce_animation);
//                    instructionIcon.setAnimation(bounceAnimation);
                }
            }
        });

        dispatchFabBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<DispatchItemSubModel> subList = new ArrayList<>();

                for (RtsDispatchConsignmentItemResponse.Data item : list){
                    if (item.isChecked){
                        final DispatchItemSubModel subModel = new DispatchItemSubModel();
                        subModel.PK_NO = item.PK_NO;
                        subModel.barcode = item.barcode;
                        subModel.qty = item.qty;
                        subModel.sku_id = item.sku_id;

                        subList.add(subModel);
                    }
                }

                if (countProduct < totalCountProduct){
                    Toast.makeText(RtsDispatchPage.this, "Scan and confirm all product!", Toast.LENGTH_LONG).show();
                }else if (countProduct == totalCountProduct){
                    if (instruction == 0){
                        String token = SharedPreperenceUtils.getToken(RtsDispatchPage.this);
                        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(RtsDispatchPage.this));

                        final RtsDispatchPost post = new RtsDispatchPost();
                        post.consignment_label = consignmentLabel;
                        post.user_id = user_id;
                        post.data = subList;

                        Log.e("rts dispatch post", "msg"+new Gson().toJson(post));

                        final Dialog dialog = new Dialog(RtsDispatchPage.this);
                        dialog.setContentView(R.layout.transparent_progress_dialoge);

                        int width = WindowManager.LayoutParams.WRAP_CONTENT;
                        int height = WindowManager.LayoutParams.WRAP_CONTENT;

                        dialog.getWindow().setLayout(width,height);
                        dialog.setCancelable(false);
                        dialog.show();

                        compositeDisposable.add(mIRetrofitApi.dispatch(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<DispatchResponse>() {
                            @Override
                            public void accept(DispatchResponse response) throws Exception {
                                if (response.status == 1){
                                    dialog.dismiss();
                                    inVisibleBtn();
                                    //loadConsignmentList();
                                    Utils.snackbarToast(rootLayout,""+response.message);
                                }else {
                                    dialog.dismiss();

                                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                        Utils.expiredTokenAlert(rootLayout, RtsDispatchPage.this);
                                    }else {
                                        Utils.snackbarToast(rootLayout,response.message);
                                    }
                                }
                            }
                        }, new Consumer<Throwable>() {
                            @Override
                            public void accept(Throwable throwable) throws Exception {
                                dialog.dismiss();
                                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                                    snackbar.show();
                                }else {
                                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                                    snackbar.show();
                                }
                            }
                        }));
                    }else {
                        Toast.makeText(RtsDispatchPage.this, "Check instruction then confirm", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });


        // ..................... consignment list ..............................//

        if (Utils.broadcastIntent(this,rootLayout)){
            inVisibleBtn();
            loadConsignmentList();
        }else {
            Utils.snackbarToast(rootLayout,"No internet connection!");
        }

        consignmentListFabBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isAnim == 1){
                    consignmentListFabBtn.clearAnimation();
                    zoom_in_out.cancel();
                    isAnim = 0;
                }

                final Dialog dialog = new Dialog(RtsDispatchPage.this);
                dialog.setContentView(R.layout.consignment_note_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.MATCH_PARENT;

                dialog.getWindow().setLayout(width,height);
                dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimationBottom;
                dialog.setCancelable(true);
                dialog.show();

                final RecyclerView consignmentListRecyclerView = dialog.findViewById(R.id.consignment_note_list_recyclerViewID);
                ImageView closeIcon = dialog.findViewById(R.id.consignmentNoteCloseIconID);

                LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
                layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                consignmentListRecyclerView.setLayoutManager(layoutManager);

                consignmentListAdapter = new ConsignmentListAdapter(consignmentList, RtsDispatchPage.this,rootLayout);
                consignmentListRecyclerView.setAdapter(consignmentListAdapter);
                consignmentListAdapter.notifyDataSetChanged();


                DialogInterface.OnKeyListener keyListener = new DialogInterface.OnKeyListener() {
                    @Override
                    public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                        int keyAction = event.getAction();
                        if (keyCode == KeyEvent.ACTION_DOWN && !consignmentListRecyclerView.canScrollVertically(0)){
                            dialog.dismiss();
                            return true;
                        }
                        return false;
                    }
                };

                dialog.setOnKeyListener(keyListener);




                closeIcon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
            }
        });

    }

    private void loadConsignmentList() {
        consignmentListFabBtn.show();
        scanConsignmentBtn.setVisibility(View.GONE);
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        final Dialog dialog = new Dialog(RtsDispatchPage.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        final ConsignmentListPost post = new ConsignmentListPost();
        post.user_id = user_id;

        compositeDisposable.add(mIRetrofitApi.getConsignmentList(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ConsignmentListResponse>() {
            @Override
            public void accept(ConsignmentListResponse response) throws Exception {
                if (response.status == 1){
                    scanConsignmentBtn.setVisibility(View.VISIBLE);
                    isAnim = 1;
                    zoom_in_out = AnimationUtils.loadAnimation(RtsDispatchPage.this,R.anim.zoom_in_out);
                    consignmentListFabBtn.setAnimation(zoom_in_out);

                    consignmentList = response.data;
                    consignmentListFabBtn.setText("("+consignmentList.size()+")");
                    dialog.dismiss();
                }else {
                    dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout, RtsDispatchPage.this);
                    }else {
                        Utils.snackbarToast(rootLayout,response.message);
                    }
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();
                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        }));
    }

    private void initialFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.dispatchConsignmentRootLayoutId);
        dispatchFabBtn = (ExtendedFloatingActionButton) findViewById(R.id.dispatchConsignmentFabBtn);
        consignmentListFabBtn = (ExtendedFloatingActionButton) findViewById(R.id.dispatchConsignmentListFabBtn);
        scanConsignmentBtn = (Button)findViewById(R.id.dispatchConsignmentScanID);
        scanItemBtn = (Button )findViewById(R.id.scanItemBtnAID);
        toolbar = (MaterialToolbar)findViewById(R.id.dispatchConsignmentToolbarID);
        recyclerView = (RecyclerView)findViewById(R.id.dispatchConsignmentItemRecyclerID);

        instructionView = (LinearLayout)findViewById(R.id.dispatch_consignment_instructionViewID);
        instructionCheck = (CheckBox)findViewById(R.id.dispatchConsignmentInstructionCheckID);
        instructionText = (TextView) findViewById(R.id.dispatchConsignmentInstructionTextID);
        instructionIcon = (ImageView)findViewById(R.id.rtsDispatchConsignmentInsIconID);
    }

    private void openScanner(){
        scannerDialog = new Dialog(RtsDispatchPage.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);

        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(RtsDispatchPage.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        inVisibleBtn();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null) {
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()) {
            compositeDisposable.dispose();
        }

    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    @Override
    public void handleResult(final Result rawResult) {
        if (!TextUtils.isEmpty(rawResult.getText())){
            if (consignmentORProduct == 1){
                loadData(rawResult.getText());
                scannerDialog.dismiss();
                scannerView.stopCamera();
            }else if (consignmentORProduct == 2){
                checkProduct(rawResult.getText());
                scannerDialog.dismiss();
                scannerView.stopCamera();
            }
        }else {
            wrongTone.start();
            scannerDialog.dismiss();
            scannerView.stopCamera();
            Utils.snackbarToast(rootLayout,"Barcode is empty!");
        }
    }

    private void inVisibleBtn(){
        list = new ArrayList<>();
        adapter.updateList(list);
        consignmentLabel = "";
        scanItemBtn.setVisibility(View.GONE);
        dispatchFabBtn.setText("Dispatch (0)");
        dispatchFabBtn.hide();
        consignmentListFabBtn.setText("(0)");
        countProduct = 0;
        totalCountProduct = 0;
        scanConsignmentBtn.setText(R.string.scan_consignment);
        instructionView.setVisibility(View.GONE);
        instructionText.setText("TextView");
        instructionCheck.setChecked(false);
    }

    private void visibleBtn(){
        scanItemBtn.setVisibility(View.VISIBLE);
        dispatchFabBtn.show();
        dispatchFabBtn.setText("Press Here To Dispatch (0/"+totalCountProduct+")");
    }

    private void loadData(final String barcode){

        inVisibleBtn();

        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        final DispatchConsignmentItemPost post = new DispatchConsignmentItemPost();
        post.consignment_label = barcode;
        post.user_id = user_id;

        Log.e("rts dispatch list", "msg"+new Gson().toJson(post));

        final Dialog dialog = new Dialog(RtsDispatchPage.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        compositeDisposable.add(mIRetrofitApi.getConsignmentItem(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<RtsDispatchConsignmentItemResponse>() {
            @Override
            public void accept(RtsDispatchConsignmentItemResponse response) throws Exception {
                if (response.status == 1){
                    if (isTone == 1){
                        rightTone.start();
                        isTone = 0;
                    }
                    consignmentListFabBtn.hide();
                    consignmentLabel = barcode;
                    list = response.data;
                    adapter.updateList(list);
                    scanConsignmentBtn.setText(barcode);

                    if (response.description == null || response.description.equals("")){
                        instruction = 0;
                    }else {
                        instruction = 1;
                        instructionView.setVisibility(View.VISIBLE);
                        instructionText.setText(response.description);
                        instructionCheck.setChecked(false);
                        instructionIcon.setAnimation(bounceAnimation);
                    }

                    for (RtsDispatchConsignmentItemResponse.Data item : list){
                        totalCountProduct += item.qty;
                    }
                    visibleBtn();
                    dialog.dismiss();
                }else {
                    if (isTone == 1){
                        wrongTone.start();
                    }
                    dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout, RtsDispatchPage.this);
                    }else {
                        Utils.snackbarToast(rootLayout,response.message);
                    }
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();
                if (isTone == 1){
                    wrongTone.start();
                }

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        }));

    }

    private void checkProduct(String barcode){
        int m = 0;
        for (int i = 0; i < list.size(); i++){
            if (list.get(i).barcode.equals(barcode) && list.get(i).isPicked == 1){

                m = 1;

                final Dialog qtyDialog = new Dialog(RtsDispatchPage.this);
                qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                qtyDialog.getWindow().setLayout(width,height);
                qtyDialog.setCancelable(false);
                qtyDialog.show();

                final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                TextView msg = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);

                ok.setText("Confirm");

                ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                String insPrimaryImage = Common.BASEURL_PICTURE + list.get(i).primary_image;

                if (list.get(i).variant_primary_image == null || list.get(i).variant_primary_image.equals("")) {
                    Glide.with(RtsDispatchPage.this)
                            .load(insPrimaryImage)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                } else {
                    String insVariantImage = Common.BASEURL_PICTURE + list.get(i).variant_primary_image;


                    Glide.with(RtsDispatchPage.this)
                            .load(insVariantImage)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                }


                if (list.get(i).variant_name == null || list.get(i).variant_name.equals("")) {
                    cardName.setText(list.get(i).product_name);
                } else {
                    cardName.setText(list.get(i).variant_name);
                }

                cardColor.setText("Color : " + list.get(i).color);
                cardSize.setText("Size : " + list.get(i).size);


                msg.setText("Avl Qty : "+list.get(i).qty);
                qty.setText(""+list.get(i).qty);
                qty.setEnabled(false);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        qtyDialog.dismiss();
                    }
                });

                final int finalI = i;
                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (!list.get(finalI).isChecked){
                            countProduct += list.get(finalI).qty;
                        }

                        dispatchFabBtn.setText("Press Here To Dispatch ("+countProduct+"/"+totalCountProduct+")");

                        final RtsDispatchConsignmentItemResponse.Data item = new RtsDispatchConsignmentItemResponse.Data();
                        item.PK_NO = list.get(finalI).PK_NO;
                        item.sku_id = list.get(finalI).sku_id;
                        item.barcode = list.get(finalI).barcode;
                        item.size = list.get(finalI).size;
                        item.color = list.get(finalI).color;
                        item.product_name = list.get(finalI).product_name;
                        item.variant_name = list.get(finalI).variant_name;
                        item.variant_primary_image = list.get(finalI).variant_primary_image;
                        item.primary_image = list.get(finalI).primary_image;
                        item.qty = list.get(finalI).qty;
                        item.picked_qty = list.get(finalI).picked_qty;
                        item.mkt_id = list.get(finalI).mkt_id;
                        item.isChecked = true;
                        item.isPicked = 1;

                        list.set(finalI,item);

                        adapter.updateList(list);

                        qtyDialog.dismiss();

                        return;
                    }
                });
            }
        }

        if(m == 0){
            Utils.snackbarToast(rootLayout,"Doesn't match the product or not picked!");
        }

    }

}