package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class YettoBoxResponse extends ApiResponse{
    @SerializedName("data")
    public ArrayList<Data> data;

    public static class Data{

        @SerializedName("PK_NO")
        public int PK_NO;

        @SerializedName("sku_id")
        public String sku_id;

        @SerializedName("mkt_id")
        public String mkt_id;

        @SerializedName("product_name")
        public String product_name;

        @SerializedName("product_variant_name")
        public String variant_name;

        @SerializedName("size")
        public String size;

        @SerializedName("color")
        public String color;

        @SerializedName("variant_primary_image")
        public String variant_primary_image;

        @SerializedName("primary_image")
        public String primary_image;

        @SerializedName("available_qty")
        public int available_qty;

        @SerializedName("barcode")
        public String barcode;

        @SerializedName("warehouse")
        public String warehouse;
    }
}
