package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Dialog;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.NetworkModel.ShipmentReceivePost;
import com.example.ukshop.NetworkModel.ShipmentReceiveResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.zxing.Result;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class ShipmentReceivePage extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private Button shipmentReceiveBtn;
    private LinearLayout shipmentBoxScaBtn;
    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private TextView boxLabel;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private String strBoxLabel;

    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static final int CAMERA_PERMISSION_CODE = 501;

    private static boolean isFlash = false;
    private static boolean isCamreOpen = false;

    private boolean isInvalid = false;


    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipment_receive_page);

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFeilds();

        boxLabel.setText(R.string.shipmentReceiveBoxLabel);

        shipmentBoxScaBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(ShipmentReceivePage.this)){
                    openScanner();
                }else {
                    ActivityCompat.requestPermissions(ShipmentReceivePage.this,new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
                }
            }
        });

        shipmentBoxScaBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                final Dialog dialog = new Dialog(ShipmentReceivePage.this);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
                barcodeText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(8)});

                search.setText(R.string.ok);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){
                            if (barcode.length() == 8){

                                strBoxLabel = barcode;
                                boxLabel.setText(""+barcode);
                                dialog.dismiss();

                            }else {
                                Toast.makeText(ShipmentReceivePage.this,"This is not box label!",Toast.LENGTH_LONG).show();
                            }
                        }else {
                            Toast.makeText(ShipmentReceivePage.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });

                return false;
            }
        });

        shipmentReceiveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(strBoxLabel)){
                        if (Utils.broadcastIntent(ShipmentReceivePage.this,rootLayout)){
                            shipmentReceive();
                        }else {
                            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",Snackbar.LENGTH_LONG);
                            snackbar.show();
                        }
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout," Please Scan Box Label!",Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        });


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.menuShipment_refreshId){
                    refreshShipment();
                    Snackbar snackbar = Snackbar.make(rootLayout,"Page Refreshed",Snackbar.LENGTH_LONG);
                    snackbar.show();
                    return true;
                }else {
                    return false;
                }
            }
        });

    }

    private void initialFindFeilds(){
        rootLayout = (CoordinatorLayout)findViewById(R.id.shipmentReceiveRootLayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.shipmentReceiveToolbarId);

        shipmentBoxScaBtn = (LinearLayout)findViewById(R.id.shipmentReceiveBoxID);
        shipmentReceiveBtn = (Button)findViewById(R.id.shipmentReceiveBtnID);
        boxLabel = (TextView) findViewById(R.id.shipmentReceiveBoxLebelID);
    }


    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootLayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootLayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",10000);
            snackbar.show();
        }
    }

    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mIRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ApiResponse>() {
            @Override
            public void accept(ApiResponse response) throws Exception {
                if (response.status == 0) {
                    isInvalid = true;
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));

        return isInvalid;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    private void refreshShipment() {
        strBoxLabel =  null;
        boxLabel.setText(R.string.shipmentReceiveBoxLabel);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    private void openScanner(){
        scannerDialog = new Dialog(ShipmentReceivePage.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


        isCamreOpen = true;
        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(ShipmentReceivePage.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                isCamreOpen = false;
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }

    private void shipmentReceive(){
        final Dialog dialog = new Dialog(ShipmentReceivePage.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        String token = SharedPreperenceUtils.getToken(ShipmentReceivePage.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(ShipmentReceivePage.this));

        final ShipmentReceivePost post = new ShipmentReceivePost();
        post.user_id = user_id;
        post.box_label = strBoxLabel;

        compositeDisposable.add(mIRetrofitApi.shipmentReceive(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ShipmentReceiveResponse>() {
            @Override
            public void accept(ShipmentReceiveResponse response) throws Exception {
                if (response.status == 1){
                    dialog.dismiss();
                    Snackbar snackbar = Snackbar.make(rootLayout,""+ response.message,Snackbar.LENGTH_LONG);
                    snackbar.show();
                    refreshShipment();
                }else {
                    dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout,ShipmentReceivePage.this);
                    }else {
                        Utils.snackbarToast(rootLayout,response.message);
                    }

                    //refreshShipment();
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 15000);
                    snackbar.show();
                }else {
                    Utils.snackbarToast(rootLayout,throwable.getMessage());
                }

                //refreshShipment();
            }
        }));

    }

    @Override
    public void handleResult(Result rawResult) {

        if (!TextUtils.isEmpty(rawResult.getText())){
            if (rawResult.getText().length() == 8){

                rightTone.start();

                strBoxLabel = rawResult.getText();
                boxLabel.setText(""+rawResult.getText());
                scannerDialog.dismiss();
                scannerView.stopCamera();
            }else {

                wrongTone.start();
                scannerDialog.dismiss();
                scannerView.stopCamera();
                Utils.snackbarToast(rootLayout,"This in not Box Label!");
            }
        }else {
            wrongTone.start();
            scannerDialog.dismiss();
            scannerView.stopCamera();
            Utils.snackbarToast(rootLayout,"Barcode is empty!");
        }


    }
}