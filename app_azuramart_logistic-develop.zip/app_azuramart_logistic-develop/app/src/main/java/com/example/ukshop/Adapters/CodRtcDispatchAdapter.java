package com.example.ukshop.Adapters;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.ImageShowPage;
import com.example.ukshop.Models.CodRtcDispatchListModel;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.CodRtcPickingListResponse;
import com.example.ukshop.NetworkModel.CodRtcSubModel;
import com.example.ukshop.NetworkModel.UnboxingItemResponse;
import com.example.ukshop.NetworkModel.UnboxingPost;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.snackbar.Snackbar;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class CodRtcDispatchAdapter extends RecyclerView.Adapter {

    private List<CodRtcPickingListResponse.Data> list;
    private List<CodRtcSubModel> subModelList;
    private Activity context;
    private CoordinatorLayout rootLayout;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    List<VariantImageResponse.Data> variantImageList = new ArrayList<>();

    public CodRtcDispatchAdapter(List<CodRtcPickingListResponse.Data> list, List<CodRtcSubModel> subModelList, Activity context, CoordinatorLayout rootLayout) {
        this.list = list;
        this.subModelList = subModelList;
        this.context = context;
        this.rootLayout = rootLayout;
    }

    @Override
    public int getItemViewType(int position) {
        switch (list.get(position).label.length()){
            case 8:
                return CodRtcDispatchListModel.BOX_TYPE;
            case 4:
                return CodRtcDispatchListModel.LANDING_TYPE;
            case 10:
                return CodRtcDispatchListModel.SHELVE_TYPE;
            default:
                return -1;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cod_rtc_item_layout,parent,false);

        switch (viewType){
            case CodRtcDispatchListModel.BOX_TYPE:
                return new CodRtcDispatchAdapter.BoxQtyViewHolder(view);

            case CodRtcDispatchListModel.LANDING_TYPE:
                return new CodRtcDispatchAdapter.ShelvedQtyViewHolder(view);

            case CodRtcDispatchListModel.SHELVE_TYPE:
                return new CodRtcDispatchAdapter.LandingQtyViewHolder(view);
            default:
                return null;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        String imageUrl = list.get(position).variant_primary_image;
        String primaryImage = list.get(position).primary_image;
        int pk_id = list.get(position).PK_NO;
        String skuId = list.get(position).sku_id;
        String barcode = list.get(position).barcode;
        String name = list.get(position).product_name;
        String variantName = list.get(position).variant_name;
        String color = list.get(position).color;
        String size = list.get(position).size;
        String label = list.get(position).label;
        int qty = list.get(position).qty;
        String location = list.get(position).location;

        int TYPE = label.length() == 8 ? 1 : label.length() == 4 ? 2 : 3;

        switch (TYPE){
            case CodRtcDispatchListModel.BOX_TYPE:
                ((BoxQtyViewHolder)holder).setBoxQtyData(skuId,barcode,pk_id,name,variantName,primaryImage,
                        imageUrl,color,size,qty,label,location,position);
                break;
            case CodRtcDispatchListModel.LANDING_TYPE:
                ((LandingQtyViewHolder)holder).setLandingQtyData(skuId,barcode,pk_id,name,variantName,primaryImage,
                        imageUrl,color,size,qty,label,location,position);
                break;
            case CodRtcDispatchListModel.SHELVE_TYPE:
                ((ShelvedQtyViewHolder)holder).setShelvedQtyData(skuId,barcode,pk_id,name,variantName,primaryImage,
                        imageUrl,color,size,qty,label,location,position);
                break;
            default:return;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void updateList(List<CodRtcPickingListResponse.Data> newList, List<CodRtcSubModel> subModels){
        list = newList;
        subModelList = subModels;
        notifyDataSetChanged();
    }

    public class BoxQtyViewHolder extends RecyclerView.ViewHolder implements ZXingScannerView.ResultHandler {

        private Button scanLabelBtn, scanProductBtn;
        private ImageView variant_image;
        private TextView name,skuId,barcode,location,size,color,qty;

        private int scanPosition = -1;
        private String boxLabel = "";
        private String productLabel = "";
        private boolean isBoxScan = false;



        //...........................................................//
        Dialog scannerDialog;
        ZXingScannerView scannerView;
        private static final int CAMERA_PERMISSION_CODE = 501;

        private boolean isFlash = false;
        private int boxOrProduct = 0;
        private boolean isCamreOpen = false;

        private MediaPlayer rightTone = new MediaPlayer();
        private MediaPlayer wrongTone = new MediaPlayer();
        //.........................................................//

        public BoxQtyViewHolder(@NonNull View itemView) {
            super(itemView);

            scanLabelBtn = itemView.findViewById(R.id.cod_rtcScanLabelBtnId);
            scanProductBtn = itemView.findViewById(R.id.cod_rtcScanProductBtnId);
            variant_image = itemView.findViewById(R.id.cod_rtcImageID);
            name = itemView.findViewById(R.id.cod_rtcNameID);
            skuId = itemView.findViewById(R.id.cod_rtcSkuID);

            location = itemView.findViewById(R.id.cod_rtcLocationID);
            barcode = itemView.findViewById(R.id.cod_rtcBarcodeID);
            size = itemView.findViewById(R.id.cod_rtcSizeID);
            color = itemView.findViewById(R.id.cod_rtcColorID);
            qty = itemView.findViewById(R.id.cod_rtcQtyID);

        }

        public void setBoxQtyData(final String sku, final String barcode, final int pk_id, final String name, final String variant_Name, String primaryImage, String imageUrl,
                            final String color, final String size, final int quantity, final String label, final String location, final int position) {

            if (imageUrl == null || imageUrl.equals("")) {
                primaryImage = Common.BASEURL_PICTURE + primaryImage;
                Glide.with(context)
                        .load(primaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_image);
            } else {
                imageUrl = Common.BASEURL_PICTURE + imageUrl;
                Glide.with(context)
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_image);
            }


            if (variant_Name == null || variant_Name.equals("")) {
                this.name.setText(name);
            } else {
                this.name.setText(variant_Name);
            }

            skuId.setText("SKU : " + sku);
            this.barcode.setText("Barcode : " + barcode);
            this.color.setText("Color : " + color);
            this.size.setText("Size : "+size);
            this.qty.setText("Qty : "+quantity);
            this.location.setText(location);


            this.scanLabelBtn.setVisibility(View.VISIBLE);
            this.scanLabelBtn.setText(R.string.scan_box);
            this.scanLabelBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    isBoxScan = false;
                    scanPosition = position;
                    boxLabel = label;
                    boxOrProduct = 1;
                    openScanner();
                }
            });

            rightTone = MediaPlayer.create(context,R.raw.scanner_tone_2);
            wrongTone = MediaPlayer.create(context,R.raw.wrong_tone);
            this.scanProductBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (isBoxScan && boxLabel.equals(list.get(position).label)){
                        scanPosition = position;
                        productLabel = barcode;
                        boxOrProduct = 2;
                        openScanner();
                    }else {
                        Utils.snackbarToast(rootLayout,"Scan box label!");
                    }


                }
            });

            variant_image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mIRetrofitApi = Common.getApiArobil();
                    String token = SharedPreperenceUtils.getToken(context);

                    compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<VariantImageResponse>() {
                        @Override
                        public void accept(VariantImageResponse response) throws Exception {
                            if (response.status == 1){
                                variantImageList = response.data;
                                ImageShowPage.variantImageList = variantImageList;
                                Intent intent = new Intent(context, ImageShowPage.class);
                                itemView.getContext().startActivity(intent);

                            }else {

                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    }));
                }
            });

        }

        private void openScanner(){
            scannerDialog = new Dialog(context);
            scannerDialog.setContentView(R.layout.boxing_scaning_layout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.MATCH_PARENT;

            scannerDialog.getWindow().setLayout(width,height);
            scannerDialog.setCancelable(true);
            scannerDialog.show();

            scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
            ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
            final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


            isCamreOpen = true;
            scannerView.setAutoFocus(true);

            scannerView.setResultHandler(BoxQtyViewHolder.this);
            scannerView.startCamera();

            scannerClose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    scannerView.stopCamera();
                    isCamreOpen = false;
                    scannerDialog.dismiss();
                }
            });

            scannerFlash.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isFlash){
                        scannerFlash.setImageResource(R.drawable.ic_flash_off);
                        scannerView.setFlash(false);
                        isFlash = false;
                    }else {
                        scannerFlash.setImageResource(R.drawable.ic_flash_on);
                        scannerView.setFlash(true);
                        isFlash = true;
                    }
                }
            });

        }


        @Override
        public void handleResult(Result rawResult) {
            if (!TextUtils.isEmpty(rawResult.getText())){
                if (boxOrProduct == 1){
                    if (boxLabel.equals(rawResult.getText())){
                        rightTone.start();
                        isBoxScan = true;
                        scannerDialog.dismiss();
                        scannerView.stopCamera();
                        Utils.snackbarToast(rootLayout,"Now scan product");
                    }else {
                        isBoxScan = false;
                        wrongTone.start();
                        scannerDialog.dismiss();
                        scannerView.stopCamera();
                        Utils.snackbarToast(rootLayout,"Don't match try again!");
                    }
                }else if (boxOrProduct == 2){
                    if (productLabel.equals(rawResult.getText())){
                        rightTone.start();

                        //.............................

                        final Dialog qtyDialog = new Dialog(context);
                        qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                        int width = WindowManager.LayoutParams.MATCH_PARENT;
                        int height = WindowManager.LayoutParams.WRAP_CONTENT;

                        qtyDialog.getWindow().setLayout(width,height);
                        qtyDialog.setCancelable(false);
                        qtyDialog.show();

                        final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                        Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                        Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                        TextView d_avl_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);

                        qty.setText(""+list.get(scanPosition).qty);
                        d_avl_qty.setText("Avl Qty : "+ list.get(scanPosition).qty);
                        // d_avl_qty.setText("Avl Qty : "+ postItemResponse.data.get(0).available_qty);



                        ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                        TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                        TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                        TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                        String insPrimaryImage = Common.BASEURL_PICTURE + list.get(scanPosition).primary_image;

                        if (list.get(scanPosition).variant_primary_image == null || list.get(scanPosition).variant_primary_image.equals("")) {
                            Glide.with(context)
                                    .load(insPrimaryImage)
                                    .placeholder(R.drawable.ic_default)
                                    .into(cardImage);
                        } else {
                            String insVariantImage = Common.BASEURL_PICTURE + list.get(scanPosition).variant_primary_image;


                            Glide.with(context)
                                    .load(insVariantImage)
                                    .placeholder(R.drawable.ic_default)
                                    .into(cardImage);
                        }


                        if (list.get(scanPosition).variant_name == null || list.get(scanPosition).variant_name.equals("")) {
                            cardName.setText(list.get(scanPosition).product_name);
                        } else {
                            cardName.setText(list.get(scanPosition).variant_name);
                        }

                        cardColor.setText("Color : " + list.get(scanPosition).color);
                        cardSize.setText("Size : " + list.get(scanPosition).size);


                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                qtyDialog.dismiss();
                                scannerDialog.dismiss();
                                scannerView.stopCamera();
                            }
                        });


                        ok.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (!TextUtils.isEmpty(qty.getText())){
                                    String string = qty.getText().toString();
                                    int quantity = Integer.parseInt(string);
                                    //String barcode = rawResult.getText();
                                    if (quantity <= list.get(scanPosition).qty){

                                        if (quantity == 0){
                                            quantity = 1;
                                        }


                                        String token = SharedPreperenceUtils.getToken(context);
                                        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(context));

                                        final UnboxingPost post = new UnboxingPost();
                                        post.user_id = user_id;
                                        post.box_label = boxLabel;
                                        post.sku_id = list.get(scanPosition).sku_id;
                                        post.qty = quantity;

                                        mIRetrofitApi = Common.getApiArobil();

                                        final int finalQuantity = quantity;
                                        compositeDisposable.add(mIRetrofitApi.unboxing(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<UnboxingItemResponse>() {
                                            @Override
                                            public void accept(UnboxingItemResponse response) throws Exception {
                                                if (response.status == 1){

                                                    final CodRtcSubModel model = new CodRtcSubModel();
                                                    model.barcode = list.get(scanPosition).barcode;
                                                    model.qty = finalQuantity;
                                                    model.sku_id = list.get(scanPosition).sku_id;
                                                    subModelList.add(model);

                                                    if (finalQuantity < list.get(scanPosition).qty){
                                                        final CodRtcPickingListResponse.Data item = new CodRtcPickingListResponse.Data();
                                                        item.sku_id = list.get(scanPosition).sku_id;
                                                        item.PK_NO = list.get(scanPosition).PK_NO;
                                                        item.primary_image = list.get(scanPosition).primary_image;
                                                        item.variant_primary_image = list.get(scanPosition).variant_primary_image;
                                                        item.product_name = list.get(scanPosition).product_name;
                                                        item.variant_name = list.get(scanPosition).variant_name;
                                                        item.color = list.get(scanPosition).color;
                                                        item.size = list.get(scanPosition).size;
                                                        item.qty = (list.get(scanPosition).qty - finalQuantity);
                                                        item.barcode = list.get(scanPosition).barcode;
                                                        item.label = list.get(scanPosition).label;
                                                        item.location = list.get(scanPosition).location;

                                                        list.set(scanPosition,item);
                                                        notifyDataSetChanged();
                                                    }else {
                                                        list.remove(scanPosition);
                                                        notifyItemRangeChanged(scanPosition,list.size());
                                                        notifyDataSetChanged();
                                                    }


                                                    // todo code for passable list update...

                                                    isBoxScan = false;
                                                    boxLabel = "";
                                                    productLabel = "";
                                                    scanPosition = -1;
                                                    qtyDialog.dismiss();
                                                    scannerDialog.dismiss();
                                                    scannerView.stopCamera();
                                                    Snackbar snackbar = Snackbar.make(rootLayout,""+response.message,Snackbar.LENGTH_LONG);
                                                    snackbar.show();
                                                }else {
                                                    qtyDialog.dismiss();
                                                    scannerDialog.dismiss();
                                                    scannerView.stopCamera();
                                                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                                        Utils.expiredTokenAlert(rootLayout,context);
                                                    }else {
                                                        Utils.snackbarToast(rootLayout,response.message);
                                                    }
                                                }
                                            }
                                        }, new Consumer<Throwable>() {
                                            @Override
                                            public void accept(Throwable throwable) throws Exception {
                                                qtyDialog.dismiss();
                                                scannerDialog.dismiss();
                                                scannerView.stopCamera();
                                                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 15000);
                                                    snackbar.show();
                                                }else {
                                                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                                                    snackbar.show();
                                                }
                                            }
                                        }));

                                    }else {
                                        qtyDialog.dismiss();
                                        scannerDialog.dismiss();
                                        scannerView.stopCamera();
                                        Toast.makeText(context, "Enter less then or equal : "+list.get(scanPosition).qty, Toast.LENGTH_SHORT).show();
                                    }
                                }else {
                                    qtyDialog.dismiss();
                                    scannerDialog.dismiss();
                                    scannerView.stopCamera();
                                    Toast.makeText(context, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                                }


                            }
                        });

                        //.............................

                    }else {
                        wrongTone.start();
                        scannerDialog.dismiss();
                        scannerView.stopCamera();
                        Utils.snackbarToast(rootLayout,"Don't match try again!");
                    }
                }
            }else {
                wrongTone.start();
                scannerDialog.dismiss();
                scannerView.stopCamera();
                Utils.snackbarToast(rootLayout,"Scanned Result is empty!");
            }
        }
    }

    public class ShelvedQtyViewHolder extends RecyclerView.ViewHolder implements ZXingScannerView.ResultHandler{

        private Button scanLabelBtn, scanProductBtn;
        private ImageView variant_image;
        private TextView name,skuId,barcode,location,size,color,qty;

        private int scanPosition = -1;
        private String shelveLabel = "";
        private String productLabel = "";
        private boolean isShelveScan = false;



        //...........................................................//
        Dialog scannerDialog;
        ZXingScannerView scannerView;
        private static final int CAMERA_PERMISSION_CODE = 501;

        private boolean isFlash = false;
        private int shelveOrProduct = 0;
        private boolean isCamreOpen = false;

        private MediaPlayer rightTone = new MediaPlayer();
        private MediaPlayer wrongTone = new MediaPlayer();

        public ShelvedQtyViewHolder(@NonNull View itemView) {
            super(itemView);

            scanLabelBtn = itemView.findViewById(R.id.cod_rtcScanLabelBtnId);
            scanProductBtn = itemView.findViewById(R.id.cod_rtcScanProductBtnId);
            variant_image = itemView.findViewById(R.id.cod_rtcImageID);
            name = itemView.findViewById(R.id.cod_rtcNameID);
            skuId = itemView.findViewById(R.id.cod_rtcSkuID);

            location = itemView.findViewById(R.id.cod_rtcLocationID);
            barcode = itemView.findViewById(R.id.cod_rtcBarcodeID);
            size = itemView.findViewById(R.id.cod_rtcSizeID);
            color = itemView.findViewById(R.id.cod_rtcColorID);
            qty = itemView.findViewById(R.id.cod_rtcQtyID);

        }

        public void setShelvedQtyData(final String sku, final String barcode, final int pk_id, final String name, final String variant_Name, String primaryImage, String imageUrl,
                            final String color, final String size, final int quantity, final String shelveLabel, final String location, final int position) {


            if (imageUrl == null || imageUrl.equals("")) {
                primaryImage = Common.BASEURL_PICTURE + primaryImage;
                Glide.with(context)
                        .load(primaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_image);
            } else {
                imageUrl = Common.BASEURL_PICTURE + imageUrl;
                Glide.with(context)
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_image);
            }


            if (variant_Name == null || variant_Name.equals("")) {
                this.name.setText(name);
            } else {
                this.name.setText(variant_Name);
            }

            skuId.setText("SKU : " + sku);
            this.barcode.setText("Barcode : " + barcode);
            this.color.setText("Color : " + color);
            this.size.setText("Size : "+size);
            this.qty.setText("Qty : "+quantity);
            this.location.setText(location);


            rightTone = MediaPlayer.create(context,R.raw.scanner_tone_2);
            wrongTone = MediaPlayer.create(context,R.raw.wrong_tone);
            this.scanLabelBtn.setVisibility(View.VISIBLE);
            this.scanLabelBtn.setText(R.string.scan_shelve);
            this.scanLabelBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            this.scanProductBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            variant_image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mIRetrofitApi = Common.getApiArobil();
                    String token = SharedPreperenceUtils.getToken(context);

                    compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<VariantImageResponse>() {
                        @Override
                        public void accept(VariantImageResponse response) throws Exception {
                            if (response.status == 1){
                                variantImageList = response.data;
                                ImageShowPage.variantImageList = variantImageList;
                                Intent intent = new Intent(context, ImageShowPage.class);
                                itemView.getContext().startActivity(intent);

                            }else {

                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    }));
                }
            });

        }

        private void openScanner(){
            scannerDialog = new Dialog(context);
            scannerDialog.setContentView(R.layout.boxing_scaning_layout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.MATCH_PARENT;

            scannerDialog.getWindow().setLayout(width,height);
            scannerDialog.setCancelable(true);
            scannerDialog.show();

            scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
            ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
            final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


            isCamreOpen = true;
            scannerView.setAutoFocus(true);

            scannerView.setResultHandler(ShelvedQtyViewHolder.this);
            scannerView.startCamera();

            scannerClose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    scannerView.stopCamera();
                    isCamreOpen = false;
                    scannerDialog.dismiss();
                }
            });

            scannerFlash.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isFlash){
                        scannerFlash.setImageResource(R.drawable.ic_flash_off);
                        scannerView.setFlash(false);
                        isFlash = false;
                    }else {
                        scannerFlash.setImageResource(R.drawable.ic_flash_on);
                        scannerView.setFlash(true);
                        isFlash = true;
                    }
                }
            });

        }


        @Override
        public void handleResult(Result rawResult) {
            if (!TextUtils.isEmpty(rawResult.getText())){
                if (shelveOrProduct == 1){
                    if (shelveLabel.equals(rawResult.getText())){
                        rightTone.start();
                        isShelveScan = true;
                        scannerDialog.dismiss();
                        scannerView.stopCamera();
                        Utils.snackbarToast(rootLayout,"Now scan product");
                    }else {
                        isShelveScan = false;
                        wrongTone.start();
                        scannerDialog.dismiss();
                        scannerView.stopCamera();
                        Utils.snackbarToast(rootLayout,"Don't match try again!");
                    }
                }else if (shelveOrProduct == 2){
                    if (productLabel.equals(rawResult.getText())){

                    }else {
                        wrongTone.start();
                        scannerDialog.dismiss();
                        scannerView.stopCamera();
                        Utils.snackbarToast(rootLayout,"Don't match try again!");
                    }
                }
            }else {
                wrongTone.start();
                scannerDialog.dismiss();
                scannerView.stopCamera();
                Utils.snackbarToast(rootLayout,"Scanned Result is empty!");
            }
        }
    }

    public class LandingQtyViewHolder extends RecyclerView.ViewHolder{

        private Button scanLabelBtn, scanProductBtn;
        private ImageView variant_image;
        private TextView name,skuId,barcode,location,size,color,qty;

        private int scanPosition = -1;
        private String boxLabel = "";
        private String productLabel = "";

        public LandingQtyViewHolder(@NonNull View itemView) {
            super(itemView);

            scanLabelBtn = itemView.findViewById(R.id.cod_rtcScanLabelBtnId);
            scanProductBtn = itemView.findViewById(R.id.cod_rtcScanProductBtnId);
            variant_image = itemView.findViewById(R.id.cod_rtcImageID);
            name = itemView.findViewById(R.id.cod_rtcNameID);
            skuId = itemView.findViewById(R.id.cod_rtcSkuID);

            location = itemView.findViewById(R.id.cod_rtcLocationID);
            barcode = itemView.findViewById(R.id.cod_rtcBarcodeID);
            size = itemView.findViewById(R.id.cod_rtcSizeID);
            color = itemView.findViewById(R.id.cod_rtcColorID);
            qty = itemView.findViewById(R.id.cod_rtcQtyID);

        }

        public void setLandingQtyData(final String sku, final String barcode, final int pk_id, final String name, final String variant_Name, String primaryImage, String imageUrl,
                            final String color, final String size, final int quantity, final String shelveLabel, final String location, final int position) {


            if (imageUrl == null || imageUrl.equals("")) {
                primaryImage = Common.BASEURL_PICTURE + primaryImage;
                Glide.with(context)
                        .load(primaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_image);
            } else {
                imageUrl = Common.BASEURL_PICTURE + imageUrl;
                Glide.with(context)
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_image);
            }


            if (variant_Name == null || variant_Name.equals("")) {
                this.name.setText(name);
            } else {
                this.name.setText(variant_Name);
            }

            skuId.setText("SKU : " + sku);
            this.barcode.setText("Barcode : " + barcode);
            this.color.setText("Color : " + color);
            this.size.setText("Size : "+size);
            this.qty.setText("Qty : "+quantity);
            this.location.setText(location);


            this.scanLabelBtn.setVisibility(View.GONE);

            this.scanProductBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            variant_image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mIRetrofitApi = Common.getApiArobil();
                    String token = SharedPreperenceUtils.getToken(context);

                    compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<VariantImageResponse>() {
                        @Override
                        public void accept(VariantImageResponse response) throws Exception {
                            if (response.status == 1){
                                variantImageList = response.data;
                                ImageShowPage.variantImageList = variantImageList;
                                Intent intent = new Intent(context, ImageShowPage.class);
                                itemView.getContext().startActivity(intent);

                            }else {

                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    }));
                }
            });

        }

    }
}
