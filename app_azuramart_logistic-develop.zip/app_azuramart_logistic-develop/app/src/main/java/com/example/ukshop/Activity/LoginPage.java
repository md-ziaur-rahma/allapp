package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.ukshop.BuildConfig;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.AuthPost;
import com.example.ukshop.NetworkModel.AuthResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;

import java.util.Objects;
import java.util.UUID;

import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static maes.tech.intentanim.CustomIntent.customType;

public class LoginPage extends AppCompatActivity {

    private Button loginBtn;
    private TextInputLayout email, password;
    private CoordinatorLayout rootLayout;
    private ProgressDialog progressDialog;
    private RadioGroup radioGroup;
    private RadioButton radioButton;
    private CheckBox remember;

    private TelephonyManager telephonyManager;
    private String deviceId;

    private WifiManager wifiManager;
    private String ipAdress;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi retrofitApi;


    private static final int DEVICEID_REQUEST_CODE = 101;
    private static final int IPADRESS_REQUEST_CODE = 102;

    @Override
    public void overridePendingTransition(int enterAnim, int exitAnim) {
        super.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);


        telephonyManager = (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);
        wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);

        loginBtn = (Button)findViewById(R.id.loginButtonID);
        email = (TextInputLayout) findViewById(R.id.loginEmailId);
        password = (TextInputLayout) findViewById(R.id.loginPasswordID);
        rootLayout = (CoordinatorLayout)findViewById(R.id.loginRootLayoutId);
//        radioGroup = (RadioGroup)findViewById(R.id.loginRadioGroupID);
        remember = (CheckBox)findViewById(R.id.loginRememberCheckID);



        loginBtn.setOnClickListener(v -> {
            if (!TextUtils.isEmpty(Objects.requireNonNull(email.getEditText()).getText().toString())){
                if (!TextUtils.isEmpty(Objects.requireNonNull(password.getEditText()).getText().toString())){
                    if (Utils.broadcastIntent(LoginPage.this,rootLayout)){
//                            int radioID = radioGroup.getCheckedRadioButtonId();
//                            radioButton = (RadioButton) findViewById(radioID);
//                                int x = 0;
//                                if (radioButton.getText().toString().equals("LIVE")){
//                                    x = 1;
//                                    SharedPreperenceUtils.saveShared(LoginPage.this,SharedPreperenceUtils.SOURCE_FLAG,"1");
//                                    Common.BASE_URL_AROBIL = "https://admin.azuramart.com/api/";
//                                    Common.BASEURL_PICTURE = "https://admin.azuramart.com";
//                                    Common.BASE_POOR_MSG = "https://admin.azuramart.com/api/";
//                                    Toast.makeText(LoginPage.this, ""+Common.BASE_URL_AROBIL, Toast.LENGTH_SHORT).show();
//                                    loginIn();
//                                }else if (radioButton.getText().toString().equals("TEST")){
//                                    x = 2;
//                                    SharedPreperenceUtils.saveShared(LoginPage.this,SharedPreperenceUtils.SOURCE_FLAG,"2");
//                                    Common.BASE_URL_AROBIL = "http://118.179.179.232:8888/ukshop_beta_dev/public/api/";
//                                    Common.BASEURL_PICTURE = "http://118.179.179.232:8888/ukshop_beta_dev/public";
//                                    Common.BASE_POOR_MSG = "118.179.179.232:8888/ukshop_beta/public";
//                                    Toast.makeText(LoginPage.this, ""+Common.BASE_URL_AROBIL, Toast.LENGTH_SHORT).show();
//                                    loginIn();
//                                }else if (radioButton.getText().toString().equals("DEV")){
//                                    x = 3;
//                                    SharedPreperenceUtils.saveShared(LoginPage.this,SharedPreperenceUtils.SOURCE_FLAG,"3");
//                                    Common.BASE_URL_AROBIL = "http://192.168.203.247/api/";
//                                    Common.BASEURL_PICTURE = "http://192.168.203.247";
//                                    Common.BASE_POOR_MSG = "192.168.203.247";
//                                    Toast.makeText(LoginPage.this, ""+Common.BASE_URL_AROBIL, Toast.LENGTH_SHORT).show();
//                                    loginIn();
//                                }

                        loginIn();


//                            if (ContextCompat.checkSelfPermission(LoginPage.this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
//                                if (ContextCompat.checkSelfPermission(LoginPage.this, Manifest.permission.ACCESS_WIFI_STATE) == PackageManager.PERMISSION_GRANTED){
//                                    loginIn();
//                                }else {
//                                    ActivityCompat.requestPermissions(LoginPage.this,new String[]{Manifest.permission.ACCESS_WIFI_STATE},IPADRESS_REQUEST_CODE);
//                                }
//                            }else {
//                                ActivityCompat.requestPermissions(LoginPage.this,new String[]{Manifest.permission.READ_PHONE_STATE},DEVICEID_REQUEST_CODE);
//                            }

                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",Snackbar.LENGTH_LONG);
                        snackbar.show();
                    }

                }else {
                    //password.setError("Enter Password!");
                    //password.setErrorTextColor(ColorStateList.valueOf(Color.parseColor("#da0000")));
                    Toast.makeText(LoginPage.this, "Password field is empty!", Toast.LENGTH_SHORT).show();
                    password.requestFocus();
                }
            }else {
                //email.setError("Enter Email!");
                //email.setErrorTextColor(ColorStateList.valueOf(Color.parseColor("#da0000")));
                Toast.makeText(LoginPage.this, "Email field is empty!", Toast.LENGTH_SHORT).show();
                email.requestFocus();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    private void loginIn(){
        retrofitApi = Common.getApiArobil();
        showProgressDialoge();
//        getDeviceID();
//        getIPAddress();
        String emailL = email.getEditText().getText().toString();
        String passwordL = password.getEditText().getText().toString();
        int versionCode = BuildConfig.VERSION_CODE;
        float versionName = Float.parseFloat(BuildConfig.VERSION_NAME);

        final AuthPost authPost = new AuthPost();
        authPost.email = emailL;
        authPost.password = passwordL;
        authPost.version_code = versionCode;
        authPost.version_name = versionName;
//        authPost.deviceId = deviceId;
//        authPost.IPaddress = ipAdress;

        Log.e("Login Request : ", "request : " + new Gson().toJson(authPost));

        compositeDisposable.add(retrofitApi.login(authPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(authResponse -> {
            Log.e("Login Response", "response : " + new Gson().toJson(authResponse));

            if (authResponse.status == 1){
                SharedPreperenceUtils.saveToken(LoginPage.this,SharedPreperenceUtils.TOKEN,authResponse.data.token);
                SharedPreperenceUtils.saveShared(LoginPage.this,SharedPreperenceUtils.USER_NAME,authResponse.data.user_name);
                SharedPreperenceUtils.saveShared(LoginPage.this,SharedPreperenceUtils.USER_EMAIL,authResponse.data.email);
                SharedPreperenceUtils.saveShared(LoginPage.this,SharedPreperenceUtils.USER_MOBILE,authResponse.data.mobile_no);
                SharedPreperenceUtils.saveShared(LoginPage.this,SharedPreperenceUtils.USER_ID,String.valueOf(authResponse.data.auth_id));
                SharedPreperenceUtils.saveShared(LoginPage.this,SharedPreperenceUtils.ROLE_ID,String.valueOf(authResponse.data.role_id));
                SharedPreperenceUtils.saveShared(LoginPage.this,SharedPreperenceUtils.MERCHANT_ID,String.valueOf(authResponse.data.merchant_id));

                String location = authResponse.data.user_location == 1 ? "UK" : "MY";
                SharedPreperenceUtils.saveShared(LoginPage.this,SharedPreperenceUtils.USER_LOCATION,location);

                new Handler().postDelayed(() -> {
                    progressDialog.dismiss();
                    //Toast.makeText(LoginPage.this, "logged in",Toast.LENGTH_SHORT).show();

                    if (authResponse.data.user_location == 1){
                        Intent intent = new Intent(LoginPage.this,HomePageUk.class);
                        startActivity(intent);
                        //customType(LoginPage.this,"left-to-right");
                        finish();
                    } else if (authResponse.data.user_location == 2 && authResponse.data.role_id == 21){
                        Intent intent = new Intent(LoginPage.this,HomePageCodDispatcher.class);
                        startActivity(intent);
                        //customType(LoginPage.this,"left-to-right");
                        finish();
                    } else if (authResponse.data.user_location == 2 && authResponse.data.role_id == 26){
                        Intent intent = new Intent(LoginPage.this,HomePageCustomer.class);
                        startActivity(intent);
                        //customType(LoginPage.this,"left-to-right");
                        finish();
                    } else if (authResponse.data.user_location == 2){
                        Intent intent = new Intent(LoginPage.this,HomePage.class);
                        startActivity(intent);
                        //customType(LoginPage.this,"left-to-right");
                        finish();
                    }
                },1500);
            }else {

                if (authResponse.message.toLowerCase().contains("username")){
                    //email.setError("Enter Valid Email!");
                    //email.setErrorTextColor(ColorStateList.valueOf(Color.parseColor("#da0000")));
                    email.requestFocus();
                }else if (authResponse.message.toLowerCase().contains("password")){
                    //password.setError("Enter Valid Password!");
                    //password.setErrorTextColor(ColorStateList.valueOf(Color.parseColor("#da0000")));
                    password.requestFocus();
                }

                progressDialog.dismiss();
                Snackbar snackbar = Snackbar.make(rootLayout,""+authResponse.message,Snackbar.LENGTH_LONG);
                snackbar.show();
            }

        }, new Consumer<Throwable>() {
               @Override
               public void accept(Throwable throwable) throws Exception {
                   progressDialog.dismiss();
                   if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())){
                       Snackbar snackbar = Snackbar.make(rootLayout,"Poor Internet Connection!",Snackbar.LENGTH_LONG);
                       snackbar.show();
                   }else {
                       Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                       snackbar.show();
                   }
               }
        }));
    }

    private void showProgressDialoge(){
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("logging in");
        progressDialog.setCancelable(false);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setProgressStyle(0);
        progressDialog.show();
    }

    private void getDeviceID() {
        telephonyManager =
                (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);
        final String deviceID, serialNumber, androidID;

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O){
                deviceId = ""+ telephonyManager.getDeviceId();
            }else {
                deviceId = "" + Secure.getString(LoginPage.this.getContentResolver(),Secure.ANDROID_ID);
            }
    }


    private void getIPAddress(){
        wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        ipAdress = Formatter.formatIpAddress(wifiManager.getConnectionInfo().getIpAddress());
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == DEVICEID_REQUEST_CODE){
            if (grantResults.length>=0){
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O){
                    deviceId = ""+ telephonyManager.getDeviceId();
                }else {
                    deviceId = "" + Secure.getString(LoginPage.this.getContentResolver(),Secure.ANDROID_ID);
                }
            }
        }else if (requestCode == IPADRESS_REQUEST_CODE){
            if (grantResults.length >= 0 ){
                ipAdress = Formatter.formatIpAddress(wifiManager.getConnectionInfo().getIpAddress());
            }
        }
    }
}