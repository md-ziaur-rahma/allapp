package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ShelveItemListResponse extends ApiResponse{

    @SerializedName("data")
    public ArrayList<Data> data;

    public static class Data{
        @SerializedName("PK_NO")
        public int PK_NO;

        @SerializedName("sku_id")
        public String sku_id;

        @SerializedName("barcode")
        public String barcode;

        @SerializedName("mkt_id")
        public String mkt_id;

        @SerializedName("product_name")
        public String product_name;

        @SerializedName("product_variant_name")
        public String variant_name;

        @SerializedName("size")
        public String size;

        @SerializedName("color")
        public String color;

        @SerializedName("price")
        public float price;

        @SerializedName("ins_price")
        public float ins_price;

        @SerializedName("sm_price")
        public float sm_price;

        @SerializedName("ss_price")
        public float ss_price;

        @SerializedName("variant_primary_image")
        public String variant_primary_image;

        @SerializedName("primary_image")
        public String primary_image;

        @SerializedName("available_qty")
        public int available_qty;
    }
}
