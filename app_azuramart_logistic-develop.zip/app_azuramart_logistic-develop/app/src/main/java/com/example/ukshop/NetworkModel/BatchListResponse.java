package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class BatchListResponse extends ApiResponse{

    @SerializedName("data")
    public ArrayList<Data> data;

    public static class Data{
        @SerializedName("batch_no")
        public int batch_no;
        @SerializedName("product_count")
        public int product_count;
        @SerializedName("total_count")
        public int total_count;
    }
}
