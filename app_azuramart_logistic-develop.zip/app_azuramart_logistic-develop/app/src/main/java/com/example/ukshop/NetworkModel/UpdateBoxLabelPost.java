package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class UpdateBoxLabelPost {
    @SerializedName("user_id")
    public int user_id;

    @SerializedName("PK_NO")
    public int PK_NO;

    @SerializedName("box_label")
    public String box_label;
}
