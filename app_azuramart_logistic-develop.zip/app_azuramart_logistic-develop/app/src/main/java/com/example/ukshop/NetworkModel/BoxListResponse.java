package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class BoxListResponse extends ApiResponse{

    @SerializedName("max_air")
    public int max_air;

    @SerializedName("max_sea")
    public int max_sea;

    @SerializedName("data")
    public ArrayList<Data> data;

    public static class Data{

        @SerializedName("PK_NO")
        public int PK_NO;

        @SerializedName("box_no")
        public int box_no;

        @SerializedName("box_label")
        public String box_label;

        @SerializedName("box_serial")
        public int box_serial;

        @SerializedName("user_name")
        public String user_name;

        @SerializedName("product_count")
        public int product_count;

        @SerializedName("unboxed_qty")
        public int unboxed_qty;

        @SerializedName("warehouse")
        public String warehouse;

        @SerializedName("status")
        public int status;

        @SerializedName("shipment_no")
        public int shipment_no;

        @SerializedName("shipment_label")
        public int shipment_label;

        @SerializedName("MERCHANT_NAME")
        public String merchant_name;
    }
}
