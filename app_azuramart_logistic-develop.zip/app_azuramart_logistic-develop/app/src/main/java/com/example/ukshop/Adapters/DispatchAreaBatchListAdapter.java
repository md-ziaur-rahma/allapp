package com.example.ukshop.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.Activity.RtsDispatchAreaItem;
import com.example.ukshop.NetworkModel.BatchListResponse;
import com.example.ukshop.R;

import java.util.List;

import static maes.tech.intentanim.CustomIntent.customType;

public class DispatchAreaBatchListAdapter extends RecyclerView.Adapter<DispatchAreaBatchListAdapter.ViewHolder> {

    private List<BatchListResponse.Data> list;
    private Activity context;
    private CoordinatorLayout rootLayout;

    public DispatchAreaBatchListAdapter(List<BatchListResponse.Data> list, Activity context, CoordinatorLayout rootLayout) {
        this.list = list;
        this.context = context;
        this.rootLayout = rootLayout;
    }

    @NonNull
    @Override
    public DispatchAreaBatchListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.batch_list_layout,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DispatchAreaBatchListAdapter.ViewHolder holder, int position) {
        int batchNo = list.get(position).batch_no;
        int productCount = list.get(position).product_count;
        int totalCount = list.get(position).total_count;

        holder.setData(batchNo,productCount,totalCount,position);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void updateList(List<BatchListResponse.Data> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView batchNo,productCount;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            batchNo = itemView.findViewById(R.id.batchNoID);
            productCount = itemView.findViewById(R.id.batchItemCountID);

        }

        public void setData(final int batchNo, final int productCount,final int totalCount, int position){
            this.batchNo.setText("Batch No : "+batchNo);
            this.productCount.setText("Collected Product : "+productCount+"/"+totalCount);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, RtsDispatchAreaItem.class);
                    itemView.getContext().startActivity(intent);
                    RtsDispatchAreaItem.BatchNo = batchNo;
                    customType(context,"left-to-right");
                }
            });
        }
    }
}
