package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ukshop.Adapters.PriorityUnboxingItemAdapter;
import com.example.ukshop.Adapters.UnboxingItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ReboxingPost;
import com.example.ukshop.NetworkModel.ReboxingResponse;
import com.example.ukshop.NetworkModel.UnboxingItemResponse;
import com.example.ukshop.R;
import com.example.ukshop.UnboxingPage;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class PriorityUnboxItemList extends AppCompatActivity {

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;

    private RecyclerView recyclerView;
    private List<UnboxingItemResponse.Data> mainList = new ArrayList<>();
    private static List<UnboxingItemResponse.Data> listForScanProduct = new ArrayList<>();
    private PriorityUnboxingItemAdapter adapter;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    public static String checkBoxlabel = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_priority_unbox_item_list);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();
        toolbar.setTitle("Priority Items ("+checkBoxlabel+")");

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new PriorityUnboxingItemAdapter(mainList, PriorityUnboxItemList.this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        if (Utils.broadcastIntent(this,rootLayout)){
            loadData();
        }else {
            NoInternetSnackBar();
        }


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private void initialFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.priorityUnboxItemRootLayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.priorityUnboxItemToolbarID);
        recyclerView = (RecyclerView)findViewById(R.id.priorityUnboxItemRecyclerID);
    }

    public static void updateList(List<UnboxingItemResponse.Data> newList){
        listForScanProduct = newList;
    }

    @Override
    public void onBackPressed() {
        mainList = new ArrayList<>();
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }
    }

    private void loadData(){
        mainList = new ArrayList<>();

        adapter.updateRecyclerView(mainList, checkBoxlabel);

        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        final ReboxingPost reboxingPost = new ReboxingPost();
        reboxingPost.box_label = checkBoxlabel;
        reboxingPost.user_id = user_id;

        Log.e("priority box item post", "msg"+new Gson().toJson(reboxingPost));

        final Dialog dialog = new Dialog(PriorityUnboxItemList.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width, height);
        dialog.setCancelable(false);
        dialog.show();

        compositeDisposable.add(mIRetrofitApi.getPriorityunboxingItemList(token, reboxingPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ReboxingResponse>() {
            @Override
            public void accept(ReboxingResponse response) throws Exception {
                if (response.status == 1) {

                    for (ReboxingResponse.Data item : response.data) {
                        final UnboxingItemResponse.Data mainItem = new UnboxingItemResponse.Data();
                        mainItem.PK_NO = item.PK_NO;
                        mainItem.sku_id = item.sku_id;
                        mainItem.mkt_id = item.mkt_id;
                        mainItem.product_name = item.product_name;
                        mainItem.variant_name = item.variant_name;
                        mainItem.size = item.size;
                        mainItem.color = item.color;
                        mainItem.variant_primary_image = item.variant_primary_image;
                        mainItem.primary_image = item.primary_image;
                        mainItem.available_qty = item.available_qty;
                        mainItem.given_qty = item.given_qty;
                        mainItem.barcode = item.barcode;

                        mainList.add(mainItem);
                    }

                    adapter.updateRecyclerView(mainList, checkBoxlabel);

                    if (mainList.size() > 0) {
                        updateList(mainList);
                    }
                    dialog.dismiss();

                } else {

                    dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout, PriorityUnboxItemList.this);
                    } else {
                        Utils.snackbarToast(rootLayout, response.message);
                    }

                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 15000);
                    snackbar.show();
                } else {
                    Utils.snackbarToast(rootLayout, throwable.getMessage());
                }
            }
        }));
    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(PriorityUnboxItemList.this,rootLayout)){
                    loadData();
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }

}