package com.example.ukshop.Utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.core.content.ContextCompat;

import com.example.ukshop.Activity.HomePage;
import com.example.ukshop.Activity.LoginPage;
import com.example.ukshop.Activity.StockCheckPage;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.google.android.material.snackbar.Snackbar;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static maes.tech.intentanim.CustomIntent.customType;

public class Utils {


    public static boolean broadcastIntent(Context context, View view) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeInfo = connectivityManager.getActiveNetworkInfo();
        if (activeInfo != null) {
            if (activeInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                return true;
            } else if (activeInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                return true;
            }
        } else {
            return false;
        }

        return false;
    }

    public static boolean isCameraPermission(Context context){
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED){
            return true;
        }else {
            return false;
        }
    }


    // Check Session validation..
    private static CompositeDisposable compositeDisposable = new CompositeDisposable();
    private static IRetrofitApi mIRetrofitApi;
    private static boolean isSession = false;

    public static boolean isSessionValid(final Context context){
        mIRetrofitApi = Common.getApiArobil();

        String token = SharedPreperenceUtils.getToken(context);
        int userId = Integer.parseInt(SharedPreperenceUtils.getUser(context));
        compositeDisposable.add(mIRetrofitApi.checkSession(token,userId).subscribeOn(AndroidSchedulers.mainThread()).observeOn(Schedulers.io()).subscribe(new Consumer<ApiResponse>() {
            @Override
            public void accept(ApiResponse response) throws Exception {
                if (response.status == 0){
                    isSession = true;
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));

        return isSession;
    }
    // Check Session validation...


    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager =
                (InputMethodManager) activity.getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getWindow().getDecorView().getRootView().getWindowToken(), 0);
//        inputMethodManager.hideSoftInputFromWindow(
//                activity.getCurrentFocus().getWindowToken(), 0);
        //  inputMethodManager.hideSoftInputFromWindow(Objects.requireNonNull(activity.getCurrentFocus()).getWindowToken(), 0);
    }

    // Expired token alert methode...
    public static void expiredTokenAlert(final View view, final Activity context){

        //SharedPreperenceUtils.clearUserData(context);

        Snackbar snackbar = Snackbar.make(view, "Session Expired!", 5000);
        snackbar.setAction("Login again", new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreperenceUtils.clearUserData(context);

                Intent intent = new Intent(context, LoginPage.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                context.startActivity(intent);
                customType(context, "right-to-left");
                context.finish();
            }
        });
        snackbar.show();
    }

    // normal snackbar..
    public static void snackbarToast(final View view,String msg){
        Snackbar snackbar = Snackbar.make(view,msg, Snackbar.LENGTH_LONG);
        snackbar.show();
    }

}
