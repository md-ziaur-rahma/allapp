package com.example.ukshop.Models;

public class CodRtcDispatchListModel {
    public static final int BOX_TYPE = 1;
    public static final int LANDING_TYPE = 2;
    public static final int SHELVE_TYPE = 3;
}
