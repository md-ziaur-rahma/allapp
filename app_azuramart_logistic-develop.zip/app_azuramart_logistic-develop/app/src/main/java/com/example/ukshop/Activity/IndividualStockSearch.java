package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.ukshop.Adapters.IndividualStockSearchAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.IndividualStockSearchResponse;
import com.example.ukshop.NetworkModel.StockCheckPost;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class IndividualStockSearch extends AppCompatActivity implements ZXingScannerView.ResultHandler {
    private CoordinatorLayout rootLayout;
    private NestedScrollView nestedScrollView;
    private ExtendedFloatingActionButton scanProductFabBtn;

    private final CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private List<IndividualStockSearchResponse.Data> dataList = new ArrayList<>();
    private RecyclerView recyclerView;
    private IndividualStockSearchAdapter adapter;

    private MaterialToolbar toolbar;
    private static final int CAMERA_REQUEST_CODE = 501;

    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static boolean isFlash = false;

    private boolean isInvalid = false;


    //........ Media Player Variable........
    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();

    private static int isTone = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_individual_stock_search);
        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        /// Toolbar code....
        toolbar.setNavigationOnClickListener(v -> finish());

        scanProductFabBtn.setOnClickListener(v -> {
            if (Utils.isCameraPermission(IndividualStockSearch.this)){
                openScanner();
            }else {
                ActivityCompat.requestPermissions(IndividualStockSearch.this,new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST_CODE);
            }
        });
        scanProductFabBtn.setOnLongClickListener(v -> {
            final Dialog dialog = new Dialog(IndividualStockSearch.this);
            dialog.setContentView(R.layout.barcod_picker_layout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(true);
            dialog.show();

            final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
            final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
            Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
            // barcodeText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(10)});

            search.setText(R.string.search);

            cancel.setOnClickListener(v12 -> dialog.dismiss());

            search.setOnClickListener(v1 -> {
                if (!TextUtils.isEmpty(barcodeText.getText().toString())){
                    loadData(barcodeText.getText().toString());
                    dialog.dismiss();
                }else {
                    barcodeText.requestFocus();
                    Toast.makeText(IndividualStockSearch.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                }
            });

            return false;
        });
        if (Utils.broadcastIntent(this,rootLayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootLayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
            snackbar.show();
        }
    }

    private void openScanner(){
        scannerDialog = new Dialog(IndividualStockSearch.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);



        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(IndividualStockSearch.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(v -> {
            scannerView.stopCamera();
            scannerDialog.dismiss();
        });

        scannerFlash.setOnClickListener(v -> {
            if (isFlash){
                scannerFlash.setImageResource(R.drawable.ic_flash_off);
                scannerView.setFlash(false);
                isFlash = false;
            }else {
                scannerFlash.setImageResource(R.drawable.ic_flash_on);
                scannerView.setFlash(true);
                isFlash = true;
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootLayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootLayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",10000);
            snackbar.show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CAMERA_REQUEST_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    private void initialFindFields(){
        rootLayout = findViewById(R.id.individualStockCheckRootLayoutID);
        nestedScrollView = findViewById(R.id.individualStockCheckNestedScrollID);
        toolbar = findViewById(R.id.individualStockCheckToolbarID);
        scanProductFabBtn = findViewById(R.id.individualStockCheckFabBtnID);
        recyclerView = findViewById(R.id.individualStockCheckRecyclerID);
    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",3000);
        snackbar.setAction("Retry", v -> {
            if (Utils.broadcastIntent(IndividualStockSearch.this,rootLayout)){

            }else {
                NoInternetSnackBar();
            }
        });
        snackbar.show();
    }

    @Override
    public void handleResult(final Result rawResult) {

        if (!TextUtils.isEmpty(rawResult.getText())){
            isTone = 1;
            scannerDialog.dismiss();
            loadData(rawResult.getText());
        }else {
            wrongTone.start();
        }
    }

    private void loadData(String barcode){

        dataList = new ArrayList<>();
        adapter = new IndividualStockSearchAdapter(dataList,IndividualStockSearch.this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        final Dialog dialog = new Dialog(IndividualStockSearch.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        String token = SharedPreperenceUtils.getToken(IndividualStockSearch.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(IndividualStockSearch.this));

        final StockCheckPost checkPost = new StockCheckPost();
        checkPost.user_id = user_id;
        checkPost.barcode = barcode;

        compositeDisposable.add(mIRetrofitApi.getIndividualStockCheckSearchList(token,checkPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
            if (response.status == 1){

                if (isTone == 1){
                    rightTone.start();
                    isTone = 0;
                }

                dataList = new ArrayList<>();
                dataList = response.data;
                adapter.addItem(dataList);
                dialog.dismiss();
            }else if (response.status == 0){
                if (isTone == 1){
                    wrongTone.start();
                    isTone = 0;
                }
                dialog.dismiss();

                if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                    Utils.expiredTokenAlert(rootLayout,IndividualStockSearch.this);
                }else {
                    Utils.snackbarToast(rootLayout,response.message);
                }
            }
        }, throwable -> {
            if (isTone == 1){
                wrongTone.start();
                isTone = 0;
            }
            dialog.dismiss();

            if (Objects.requireNonNull(throwable.getMessage()).toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 3000);
                snackbar.show();
            }else {
                Utils.snackbarToast(rootLayout,throwable.getMessage());
            }
        }));
    }

    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mIRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
            if (response.status == 0) {
                isInvalid = true;
            }
        }, throwable -> {

        }));

        return isInvalid;
    }
}