package com.example.ukshop.Activity.Merchant;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.ukshop.Adapters.BoxingItemAdapter;
import com.example.ukshop.Adapters.MerchantBoxingItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.BoxWeightResponse;
import com.example.ukshop.NetworkModel.BoxingItemPost;
import com.example.ukshop.NetworkModel.BoxingItemResponse;
import com.example.ukshop.NetworkModel.BoxingItemSubModel;
import com.example.ukshop.NetworkModel.StockCheckPost;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.example.ukshop.merchantNetworkModels.MerchantListModel;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class MerchantBoxing extends AppCompatActivity implements ZXingScannerView.ResultHandler,
        AdapterView.OnItemSelectedListener {

    private MaterialToolbar toolbar;
    private CoordinatorLayout rootLayout;
    private Button closeBoxBtn, scanItemBtn;
    private LinearLayout boxScan;
    private static TextView boxLabel;
    private static View boxBtnLayout;
    private LinearLayout itemScan;

    /// ............. Weight Layout ..............
    private EditText boxHeight,boxWidth,boxLength,boxWeight;
    private Spinner weightSpinner;
    private List<BoxWeightResponse.Data> boxWeightList = new ArrayList<>();
    private List<String> dimensionTextList = new ArrayList<>();
    private ArrayAdapter<String> spinnerAdapter;
    private static View boxWeightLayout;

    /// ............. merchant list .............
    private int merchant_pk;
    private String merchantName;

    private RecyclerView recyclerview;
    private List<BoxingItemResponse.Data> mainList = new ArrayList<>();

    private List<BoxingItemResponse.Data> tempList = new ArrayList<>();
    private static List<BoxingItemSubModel> boxingItemList = new ArrayList<>();
    private MerchantBoxingItemAdapter adapter;

    private final CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;
    private static String boxLabelText;

    private Dialog scannerDialog;
    private ZXingScannerView scannerView;
    private static final int CAMERA_PERMISSION_CODE = 501;
    private static boolean isFlash = false;
    private static boolean isCamreOpen = false;
    private static int boxORitem = 0;

    private int airORsea = -1;

    // Media Player Varable...
    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();
    // Media Player Varable...
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchant_boxing);

        rightTone = MediaPlayer.create(this, R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this, R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        merchant_pk = getIntent().getIntExtra("merchant_pk",0);
        merchantName = getIntent().getStringExtra("merchant_name");

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerview.setLayoutManager(layoutManager);

        adapter = new MerchantBoxingItemAdapter(mainList, boxingItemList, MerchantBoxing.this, rootLayout);
        recyclerview.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        clearValue();

        weightSpinner.setOnItemSelectedListener(this);

        boxScan.setOnClickListener(v -> {
            if (Utils.isCameraPermission(MerchantBoxing.this)) {
                boxORitem = 1;
                openScanner();
            } else {
                ActivityCompat.requestPermissions(MerchantBoxing.this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
            }
        });

        boxScan.setOnLongClickListener(v -> {

            final Dialog dialog = Common.getDialog(getLayoutInflater().inflate(R.layout.barcod_picker_layout,null),true,MerchantBoxing.this);

            final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
            final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
            Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
            barcodeText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});

            search.setText(R.string.ok);

            cancel.setOnClickListener(v15 -> dialog.dismiss());

            search.setOnClickListener(v16 -> {
                final String barcode = barcodeText.getText().toString();
                if (!TextUtils.isEmpty(barcode)) {
                    if (barcode.length() == 8) {

                        int check = -1;
                        if (barcode.startsWith("3")) {
                            check = 1;
                        } else if (barcode.startsWith("4")) {
                            check = 0;
                        }


                        if (airORsea == check) {
                            boxLabelText = barcode;
                            boxLabel.setText("Box Label : " + barcode);
                            dialog.dismiss();
                        } else {
                            final Dialog airSeaAlertDialog = new Dialog(MerchantBoxing.this);
                            airSeaAlertDialog.setContentView(R.layout.dialoge_exit);

                            int width = WindowManager.LayoutParams.MATCH_PARENT;
                            int height = WindowManager.LayoutParams.WRAP_CONTENT;

                            airSeaAlertDialog.getWindow().setLayout(width, height);
                            airSeaAlertDialog.setCancelable(false);
                            airSeaAlertDialog.show();

                            Button cancel1 = airSeaAlertDialog.findViewById(R.id.dialogeExitCancelID);
                            Button ok = airSeaAlertDialog.findViewById(R.id.dialogeExitOkID);
                            TextView msg = airSeaAlertDialog.findViewById(R.id.dialogeExitTextMsgID);

                            if (check == 1) {
                                msg.setText("The box is not Sea's box");
                            } else if (check == 0) {
                                msg.setText("The box is not Air's box");
                            }else {
                                msg.setText("This is not box label!");
                                ok.setEnabled(false);
                            }


                            ok.setText("Confirm");

                            cancel1.setOnClickListener(v13 -> {
                                airSeaAlertDialog.dismiss();
                                dialog.dismiss();
                                //scannerDialog.dismiss();
                            });

                            ok.setOnClickListener(v14 -> {
                                airSeaAlertDialog.dismiss();
                                boxLabelText = barcode;
                                boxLabel.setText("Box Label : " + barcode);
                                dialog.dismiss();
                            });

                        }

                    } else {
                        Toast.makeText(MerchantBoxing.this, "This is not Box Label!", Toast.LENGTH_LONG).show();
                    }

                } else {
                    Toast.makeText(MerchantBoxing.this, "Enter Barcode !", Toast.LENGTH_LONG).show();
                }
            });


            return false;
        });

        toolbar.setNavigationOnClickListener(v -> finish());

        itemScan.setOnClickListener(v -> {
//                if (Utils.isCameraPermission(MerchantBoxing.this)){
//                    boxORitem = 2;
//                    openScanner();
//                }else {
//                    ActivityCompat.requestPermissions(MerchantBoxing.this,new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
//                }
        });

        scanItemBtn.setOnClickListener(v -> {
            if (Utils.isCameraPermission(MerchantBoxing.this)) {boxORitem = 2;
                openScanner();
            } else {
                ActivityCompat.requestPermissions(MerchantBoxing.this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
            }
        });

        scanItemBtn.setOnLongClickListener(v -> {

            final Dialog dialog = Common.getDialog(getLayoutInflater().inflate(R.layout.barcod_picker_layout,null),true,MerchantBoxing.this);

            final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
            final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
            Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);

            cancel.setOnClickListener(v12 -> dialog.dismiss());

            search.setOnClickListener(v1 -> {
                String barcode = barcodeText.getText().toString();
                if (!TextUtils.isEmpty(barcode)) {

                    getProductForBoxing(barcode);
                    dialog.dismiss();

                } else {
                    Toast.makeText(MerchantBoxing.this, "Enter Barcode !", Toast.LENGTH_LONG).show();
                }
            });


            return false;
        });

        closeBoxBtn.setOnClickListener(v -> {

            if (Utils.broadcastIntent(MerchantBoxing.this, rootLayout)) {
                if (boxingItemList.size() != 0) {
                    if (!TextUtils.isEmpty(boxLabelText)) {

                        String token = SharedPreperenceUtils.getToken(MerchantBoxing.this);
                        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(MerchantBoxing.this));
                        String boxHeightIns = boxHeight.getText().toString();
                        String boxWidthIns = boxWidth.getText().toString();
                        String boxLengthIns = boxLength.getText().toString();
                        String boxWeightIns = boxWeight.getText().toString();

                        if (TextUtils.isEmpty(boxHeightIns) || TextUtils.isEmpty(boxWidthIns) || TextUtils.isEmpty(boxLengthIns) || TextUtils.isEmpty(boxWeightIns)) {
                            Snackbar snackbar = Snackbar.make(rootLayout, " Please give the box dimension!", Snackbar.LENGTH_LONG);
                            snackbar.show();
                        } else {
                            final Dialog dialog = new Dialog(MerchantBoxing.this);
                            dialog.setContentView(R.layout.transparent_progress_dialoge);

                            int width = WindowManager.LayoutParams.WRAP_CONTENT;
                            int height = WindowManager.LayoutParams.WRAP_CONTENT;

                            dialog.getWindow().setLayout(width, height);
                            dialog.setCancelable(false);
                            dialog.show();

//                            if (TextUtils.isEmpty(boxHeightIns)){
//                                boxHeightIns = "";
//                            }
//                            if (TextUtils.isEmpty(boxWidthIns)){
//                                boxWidthIns = "";
//                            }
//                            if (TextUtils.isEmpty(boxLengthIns)){
//                                boxLengthIns = "";
//                            }
//                            if (TextUtils.isEmpty(boxWeightIns)){
//                                boxWeightIns = "";
//                            }

                            final BoxingItemPost post = new BoxingItemPost();
                            post.is_update = 0;
                            post.box_label = boxLabelText;
                            post.user_id = user_id;
                            post.height = boxHeightIns;
                            post.width = boxWidthIns;
                            post.length = boxLengthIns;
                            post.weight = boxWeightIns;
                            post.merchant_id = merchant_pk;
                            post.data = boxingItemList;

                            Log.e("boxing post", "msg" + new Gson().toJson(post));

                            compositeDisposable.add(mIRetrofitApi.boxing(token, post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
                                if (response.status == 1) {
                                    Snackbar snackbar = Snackbar.make(rootLayout, "" + response.message, Snackbar.LENGTH_LONG);
                                    snackbar.show();
                                    dialog.dismiss();

                                    clearValue();
                                } else {
                                    dialog.dismiss();

                                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                        Utils.expiredTokenAlert(rootLayout, MerchantBoxing.this);
                                    } else {
//                                                Utils.snackbarToast(rootLayout, response.message);
                                        Snackbar snackbar = Snackbar.make(rootLayout, "" + response.message, 10000);
                                        snackbar.show();
                                    }
                                }
                            }, throwable -> {

                                dialog.dismiss();

                                if (Objects.requireNonNull(throwable.getMessage()).toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                                    snackbar.show();
                                } else {
                                    Snackbar snackbar = Snackbar.make(rootLayout, "" + throwable.getMessage(), Snackbar.LENGTH_LONG);
                                    snackbar.show();
                                }
                            }));
                        }
                    } else {
                        Snackbar snackbar = Snackbar.make(rootLayout, " Please Scan Box Label!", Snackbar.LENGTH_LONG);
                        snackbar.show();
                    }
                } else {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Scan Minimum One Item!", Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            } else {
                Snackbar snackbar = Snackbar.make(rootLayout, "No internet connection!", Snackbar.LENGTH_LONG);
                snackbar.show();
            }
        });

        // ....................... Box Dimension .......................
        if (Utils.broadcastIntent(this,rootLayout)){
            getBoxDimension();
        }
    }

    private void initialFindFields() {
        rootLayout = findViewById(R.id.merchantBoxingRootLayoutID);
        toolbar = findViewById(R.id.merchantBoxingToolbarID);
        boxBtnLayout = findViewById(R.id.merchantBoxingBoxScanLayoutID);
        closeBoxBtn = findViewById(R.id.boxingEndBoxBtnID);
        itemScan = findViewById(R.id.merchantBoxingScanItemIconID);
        recyclerview = findViewById(R.id.merchantBoxingItemRecyclerID);
        boxScan = findViewById(R.id.boxingBoxID);
        boxLabel = findViewById(R.id.boxingBoxLebelID);
        scanItemBtn = findViewById(R.id.scanItemBtnAID);

        boxHeight = findViewById(R.id.boxingHeightID);
        boxWidth = findViewById(R.id.boxingWidthID);
        boxLength = findViewById(R.id.boxingLengthID);
        boxWeight = findViewById(R.id.boxingWeightID);
        weightSpinner = findViewById(R.id.boxWeightSpinnerID);
        boxWeightLayout = findViewById(R.id.merchantBoxingWeightLayoutID);
    }

    private void openScanner() {
        scannerDialog = new Dialog(MerchantBoxing.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width, height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


        isCamreOpen = true;
        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(MerchantBoxing.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(v -> {
            scannerView.stopCamera();
            isCamreOpen = false;
            scannerDialog.dismiss();
        });

        scannerFlash.setOnClickListener(v -> {
            if (isFlash) {
                scannerFlash.setImageResource(R.drawable.ic_flash_off);
                scannerView.setFlash(false);
                isFlash = false;
            } else {
                scannerFlash.setImageResource(R.drawable.ic_flash_on);
                scannerView.setFlash(true);
                isFlash = true;
            }
        });

    }

    public static void MerchantBoxBtnHideShow(int no, List<BoxingItemSubModel> postList) {
        if (no == 1) {
            boxingItemList = postList;
            boxBtnLayout.setVisibility(View.VISIBLE);
            boxWeightLayout.setVisibility(View.VISIBLE);
        } else if (no == 2) {
            boxingItemList = postList;
            boxLabelText = null;
            boxLabel.setText(R.string.boxin_box_label);
            boxBtnLayout.setVisibility(View.GONE);
            boxWeightLayout.setVisibility(View.GONE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.length >= 0) {
                openScanner();
            } else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    public void onBackPressed() {
        clearValue();
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null) {
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        clearValue();
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()) {
            compositeDisposable.dispose();
        }
    }

    private void clearValue(){
        airORsea = -1;
        boxLabelText = "";
        tempList = new ArrayList<>();
        boxingItemList = new ArrayList<>();
        mainList = new ArrayList<>();
        adapter.addItem(mainList, boxingItemList);
        boxLabel.setText(getResources().getString(R.string.boxin_box_label));
        weightSpinner.setSelection(0);
        MerchantBoxBtnHideShow(2, boxingItemList);
    }

    @Override
    public void handleResult(final Result rawResult) {

        if (!TextUtils.isEmpty(rawResult.getText())) {
            if (boxORitem == 1) {
                if (rawResult.getText().length() == 8) {

                    int check = -1;
                    if (rawResult.getText().startsWith("3")) {
                        check = 1;
                    } else if (rawResult.getText().startsWith("4")) {
                        check = 0;
                    }


                    if (airORsea == check) {
                        rightTone.start();
                        boxLabelText = rawResult.getText();
                        boxLabel.setText("Box Label : " + rawResult.getText());
                        isCamreOpen = false;
                        boxORitem = 0;
                        scannerDialog.dismiss();
                        scannerView.stopCamera();
                    } else {

                        wrongTone.start();

                        final Dialog airSeaAlertDialog = new Dialog(MerchantBoxing.this);
                        airSeaAlertDialog.setContentView(R.layout.dialoge_exit);

                        int width = WindowManager.LayoutParams.MATCH_PARENT;
                        int height = WindowManager.LayoutParams.WRAP_CONTENT;

                        airSeaAlertDialog.getWindow().setLayout(width, height);
                        airSeaAlertDialog.setCancelable(false);
                        airSeaAlertDialog.show();

                        Button cancel = airSeaAlertDialog.findViewById(R.id.dialogeExitCancelID);
                        Button ok = airSeaAlertDialog.findViewById(R.id.dialogeExitOkID);
                        TextView msg = airSeaAlertDialog.findViewById(R.id.dialogeExitTextMsgID);

                        if (check == 1) {
                            msg.setText("The box is not Sea's box");
                        } else if (check == 0) {
                            msg.setText("The box is not Air's box");
                        }


                        ok.setText("Confirm");

                        cancel.setOnClickListener(v -> {
                            airSeaAlertDialog.dismiss();
                            isCamreOpen = false;
                            boxORitem = 0;
                            scannerDialog.dismiss();
                            scannerView.stopCamera();
                            //scannerDialog.dismiss();
                        });

                        ok.setOnClickListener(v -> {
                            airSeaAlertDialog.dismiss();
                            boxLabelText = rawResult.getText();
                            boxLabel.setText("Box Label : " + rawResult.getText());
                            scannerDialog.dismiss();
                            scannerView.stopCamera();
                        });

                    }
                }

            } else if (boxORitem == 2) {

                final String token = SharedPreperenceUtils.getToken(this);
                int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(MerchantBoxing.this));

                final String barcode = rawResult.getText();

                final StockCheckPost checkPost = new StockCheckPost();
                checkPost.user_id = user_id;
                checkPost.barcode = barcode;
                checkPost.sku_id = "";
                checkPost.mkt_id = "";
                checkPost.product_name = "";
                checkPost.merchant_pk = merchant_pk;

                compositeDisposable.add(mIRetrofitApi.getMerchantBoxingItem(token, checkPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {

                    if (response.status == 1) {

                        rightTone.start();

                        tempList = response.data;

                        if (airORsea == -1) {
                            airORsea = tempList.get(0).is_air;
                        }

                        int checkQty = 0;
                        if (boxingItemList.size() > 0) {

                            for (int i = 0; i < boxingItemList.size(); i++) {
                                if (response.data.get(0).sku_id.equals(boxingItemList.get(i).sku_id)) {
                                    checkQty += boxingItemList.get(i).qty;
                                }
                            }
                        }

                        if ((response.data.get(0).available_qty - checkQty) > 0) {

                            if (airORsea == tempList.get(0).is_air) {

                                final Dialog qtyDialog = new Dialog(MerchantBoxing.this,R.style.fadeDialog);
                                qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                                int width = WindowManager.LayoutParams.MATCH_PARENT;
                                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                                qtyDialog.getWindow().setLayout(width, height);
                                qtyDialog.setCancelable(false);
                                qtyDialog.show();

                                final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                                Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                                Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                                TextView msg = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);


                                ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                                TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                                TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                                TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                                String insPrimaryImage = Common.BASEURL_PICTURE + tempList.get(0).primary_image;

                                if (tempList.get(0).variant_primary_image == null || tempList.get(0).variant_primary_image.equals("")) {
                                    Glide.with(MerchantBoxing.this)
                                            .load(insPrimaryImage)
                                            .placeholder(R.drawable.ic_default)
                                            .into(cardImage);
                                } else {
                                    String insVariantImage = Common.BASEURL_PICTURE + tempList.get(0).variant_primary_image;


                                    Glide.with(MerchantBoxing.this)
                                            .load(insVariantImage)
                                            .placeholder(R.drawable.ic_default)
                                            .into(cardImage);
                                }


                                if (tempList.get(0).variant_name == null || tempList.get(0).variant_name.equals("")) {
                                    cardName.setText(tempList.get(0).product_name);
                                } else {
                                    cardName.setText(tempList.get(0).variant_name);
                                }

                                cardColor.setText("Color : " + tempList.get(0).color);
                                cardSize.setText("Size : " + tempList.get(0).size);


                                msg.setText("Avl Qty : " + (tempList.get(0).available_qty - checkQty));

                                cancel.setOnClickListener(v -> {
                                    scannerDialog.dismiss();
                                    qtyDialog.dismiss();
                                });


                                final int finalCheckQty = checkQty;
                                ok.setOnClickListener(v -> {
                                    if (!TextUtils.isEmpty(qty.getText())) {
                                        String string = qty.getText().toString();
                                        int quantity = Integer.parseInt(string);
                                        String barcode1 = rawResult.getText();
                                        if (quantity <= (tempList.get(0).available_qty - finalCheckQty)) {

                                            if (quantity == 0) {
                                                quantity = 1;
                                            }

                                            final BoxingItemSubModel subModel = new BoxingItemSubModel();

                                            subModel.barcode = barcode1;
                                            subModel.qty = quantity;
                                            subModel.sku_id = tempList.get(0).sku_id;

                                            boxingItemList.add(subModel);


                                            BoxingItemResponse.Data item = new BoxingItemResponse.Data();
                                            item.PK_NO = tempList.get(0).PK_NO;
                                            item.primary_image = tempList.get(0).primary_image;
                                            item.variant_primary_image = tempList.get(0).variant_primary_image;
                                            item.color = tempList.get(0).color;
                                            item.is_air = tempList.get(0).is_air;
                                            item.mkt_id = tempList.get(0).mkt_id;
                                            item.size = tempList.get(0).size;
                                            item.sku_id = tempList.get(0).sku_id;
                                            item.variant_name = tempList.get(0).variant_name;
                                            item.product_name = tempList.get(0).product_name;
                                            item.available_qty = tempList.get(0).available_qty;

                                            mainList.add(item);
                                            adapter.addItem(mainList, boxingItemList);
                                            qtyDialog.dismiss();
                                            scannerDialog.dismiss();

                                            Toast.makeText(MerchantBoxing.this, "List Size : " + boxingItemList.size(), Toast.LENGTH_SHORT).show();

                                        } else {
                                            qty.requestFocus();
                                            Toast toast = Toast.makeText(MerchantBoxing.this, "Enter less then or equal : " + tempList.get(0).available_qty, Toast.LENGTH_SHORT);
                                            TextView toastMessage = toast.getView().findViewById(android.R.id.message);
                                            toastMessage.setTextColor(Color.WHITE);
                                            toast.show();
                                        }
                                    } else {
                                        Toast.makeText(MerchantBoxing.this, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                                    }

                                });

                            } else {
                                final Dialog airSeaAertDialoge = new Dialog(MerchantBoxing.this);
                                airSeaAertDialoge.setContentView(R.layout.dialoge_exit);

                                int width = WindowManager.LayoutParams.MATCH_PARENT;
                                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                                airSeaAertDialoge.getWindow().setLayout(width, height);
                                airSeaAertDialoge.setCancelable(false);
                                airSeaAertDialoge.show();

                                Button cancel = airSeaAertDialoge.findViewById(R.id.dialogeExitCancelID);
                                Button ok = airSeaAertDialoge.findViewById(R.id.dialogeExitOkID);
                                TextView msg = airSeaAertDialoge.findViewById(R.id.dialogeExitTextMsgID);

                                if (airORsea == 1) {
                                    msg.setText("This product is not Air's product");
                                } else if (airORsea == 0) {
                                    msg.setText("This product is not Sea's product");
                                }


                                ok.setText("Add");

                                cancel.setOnClickListener(v -> {
                                    airSeaAertDialoge.dismiss();
                                    scannerDialog.dismiss();
                                });

                                final int finalCheckQty1 = checkQty;
                                ok.setOnClickListener(v -> {
                                    airSeaAertDialoge.dismiss();
                                    final Dialog qtyDialog = new Dialog(MerchantBoxing.this,R.style.fadeDialog);
                                    qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                                    int width1 = WindowManager.LayoutParams.MATCH_PARENT;
                                    int height1 = WindowManager.LayoutParams.WRAP_CONTENT;

                                    qtyDialog.getWindow().setLayout(width1, height1);
                                    qtyDialog.setCancelable(false);
                                    qtyDialog.show();

                                    final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                                    Button cancel1 = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                                    Button ok1 = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                                    TextView d_avl_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);


                                    ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                                    TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                                    TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                                    TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                                    String insPrimaryImage = Common.BASEURL_PICTURE + tempList.get(0).primary_image;

                                    if (tempList.get(0).variant_primary_image == null || tempList.get(0).variant_primary_image.equals("")) {
                                        Glide.with(MerchantBoxing.this)
                                                .load(insPrimaryImage)
                                                .placeholder(R.drawable.ic_default)
                                                .into(cardImage);
                                    } else {
                                        String insVariantImage = Common.BASEURL_PICTURE + tempList.get(0).variant_primary_image;


                                        Glide.with(MerchantBoxing.this)
                                                .load(insVariantImage)
                                                .placeholder(R.drawable.ic_default)
                                                .into(cardImage);
                                    }


                                    if (tempList.get(0).variant_name == null || tempList.get(0).variant_name.equals("")) {
                                        cardName.setText(tempList.get(0).product_name);
                                    } else {
                                        cardName.setText(tempList.get(0).variant_name);
                                    }

                                    cardColor.setText("Color : " + tempList.get(0).color);
                                    cardSize.setText("Size : " + tempList.get(0).size);


                                    d_avl_qty.setText("Avl Qty : " + (tempList.get(0).available_qty - finalCheckQty1));

                                    cancel1.setOnClickListener(v12 -> {
                                        scannerDialog.dismiss();
                                        qtyDialog.dismiss();
                                    });


                                    ok1.setOnClickListener(v1 -> {
                                        if (!TextUtils.isEmpty(qty.getText())) {
                                            String string = qty.getText().toString();
                                            int quantity = Integer.parseInt(string);
                                            String barcode12 = rawResult.getText();
                                            if (quantity <= (tempList.get(0).available_qty - finalCheckQty1)) {

                                                final BoxingItemSubModel subModel = new BoxingItemSubModel();

                                                subModel.barcode = barcode12;
                                                subModel.qty = quantity;
                                                subModel.sku_id = tempList.get(0).sku_id;

                                                boxingItemList.add(subModel);


                                                BoxingItemResponse.Data item = new BoxingItemResponse.Data();
                                                item.PK_NO = tempList.get(0).PK_NO;
                                                item.primary_image = tempList.get(0).primary_image;
                                                item.variant_primary_image = tempList.get(0).variant_primary_image;
                                                item.color = tempList.get(0).color;
                                                item.is_air = tempList.get(0).is_air;
                                                item.mkt_id = tempList.get(0).mkt_id;
                                                item.size = tempList.get(0).size;
                                                item.sku_id = tempList.get(0).sku_id;
                                                item.variant_name = tempList.get(0).variant_name;
                                                item.product_name = tempList.get(0).product_name;
                                                item.available_qty = tempList.get(0).available_qty;

                                                mainList.add(item);
                                                adapter.addItem(mainList, boxingItemList);
                                                qtyDialog.dismiss();
                                                scannerDialog.dismiss();

                                                Toast.makeText(MerchantBoxing.this, "List Size : " + boxingItemList.size(), Toast.LENGTH_SHORT).show();

                                            } else {
                                                qty.requestFocus();
                                                Toast toast = Toast.makeText(MerchantBoxing.this, "Enter less then or equal : " + tempList.get(0).available_qty, Toast.LENGTH_SHORT);
                                                TextView toastMessage = toast.getView().findViewById(android.R.id.message);
                                                toastMessage.setTextColor(Color.WHITE);
                                                toast.show();
                                            }
                                        } else {
                                            Toast.makeText(MerchantBoxing.this, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                                        }

                                    });
                                });
                            }

                        } else {
                            scannerDialog.dismiss();
                            Utils.snackbarToast(rootLayout, "Product not available for scan!");
                        }

                    } else {
                        wrongTone.start();
                        scannerDialog.dismiss();

                        if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                            Utils.expiredTokenAlert(rootLayout, MerchantBoxing.this);
                        } else {
                            Utils.snackbarToast(rootLayout, response.message);
                        }
                    }

                }, throwable -> {
                    wrongTone.start();
                    scannerDialog.dismiss();

                    if (Objects.requireNonNull(throwable.getMessage()).toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                        Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 15000);
                        snackbar.show();
                    } else {
                        Snackbar snackbar = Snackbar.make(rootLayout, "" + throwable.getMessage(), Snackbar.LENGTH_LONG);
                        snackbar.show();
                    }
                }));

            }
        } else {
            wrongTone.start();
            scannerDialog.dismiss();
            scannerView.stopCamera();
            Utils.snackbarToast(rootLayout, "Empty barcode!");
        }

    }

    private void getProductForBoxing ( final String barcode){
        final String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(MerchantBoxing.this));

        final StockCheckPost checkPost = new StockCheckPost();
        checkPost.user_id = user_id;
        checkPost.barcode = barcode;
        checkPost.sku_id = "";
        checkPost.mkt_id = "";
        checkPost.product_name = "";
        checkPost.merchant_pk = merchant_pk;

        compositeDisposable.add(mIRetrofitApi.getMerchantBoxingItem(token, checkPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {

            if (response.status == 1) {

                // rightTone.start();

                tempList = response.data;

                if (airORsea == -1) {
                    airORsea = tempList.get(0).is_air;
                }

                int checkQty = 0;
                if (boxingItemList.size() > 0) {

                    for (int i = 0; i < boxingItemList.size(); i++) {
                        if (response.data.get(0).sku_id.equals(boxingItemList.get(i).sku_id)) {
                            checkQty += boxingItemList.get(i).qty;
                        }
                    }
                }

                if ((response.data.get(0).available_qty - checkQty) > 0) {

                    if (airORsea == tempList.get(0).is_air) {


                        final Dialog qtyDialog = new Dialog(MerchantBoxing.this);
                        qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                        int width = WindowManager.LayoutParams.MATCH_PARENT;
                        int height = WindowManager.LayoutParams.WRAP_CONTENT;

                        qtyDialog.getWindow().setLayout(width, height);
                        qtyDialog.setCancelable(false);
                        qtyDialog.show();

                        final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                        Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                        Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                        TextView msg = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);

                        ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                        TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                        TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                        TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                        String insPrimaryImage = Common.BASEURL_PICTURE + tempList.get(0).primary_image;

                        if (tempList.get(0).variant_primary_image == null || tempList.get(0).variant_primary_image.equals("")) {
                            Glide.with(MerchantBoxing.this)
                                    .load(insPrimaryImage)
                                    .placeholder(R.drawable.ic_default)
                                    .into(cardImage);
                        } else {
                            String insVariantImage = Common.BASEURL_PICTURE + tempList.get(0).variant_primary_image;


                            Glide.with(MerchantBoxing.this)
                                    .load(insVariantImage)
                                    .placeholder(R.drawable.ic_default)
                                    .into(cardImage);
                        }


                        if (tempList.get(0).variant_name == null || tempList.get(0).variant_name.equals("")) {
                            cardName.setText(tempList.get(0).product_name);
                        } else {
                            cardName.setText(tempList.get(0).variant_name);
                        }

                        cardColor.setText("Color : " + tempList.get(0).color);
                        cardSize.setText("Size : " + tempList.get(0).size);

                        msg.setText("Avl Qty : " + (tempList.get(0).available_qty - checkQty));

                        cancel.setOnClickListener(v -> {
                            //scannerDialog.dismiss();
                            qtyDialog.dismiss();
                        });


                        final int finalCheckQty = checkQty;
                        ok.setOnClickListener(v -> {
                            if (!TextUtils.isEmpty(qty.getText())) {
                                String string = qty.getText().toString();
                                int quantity = Integer.parseInt(string);
                                if (quantity <= (tempList.get(0).available_qty - finalCheckQty)) {

                                    if (quantity == 0) {
                                        quantity = 1;
                                    }

                                    final BoxingItemSubModel subModel = new BoxingItemSubModel();

                                    subModel.barcode = barcode;
                                    subModel.qty = quantity;
                                    subModel.sku_id = tempList.get(0).sku_id;

                                    boxingItemList.add(subModel);


                                    BoxingItemResponse.Data item = new BoxingItemResponse.Data();
                                    item.PK_NO = tempList.get(0).PK_NO;
                                    item.primary_image = tempList.get(0).primary_image;
                                    item.variant_primary_image = tempList.get(0).variant_primary_image;
                                    item.color = tempList.get(0).color;
                                    item.is_air = tempList.get(0).is_air;
                                    item.mkt_id = tempList.get(0).mkt_id;
                                    item.size = tempList.get(0).size;
                                    item.sku_id = tempList.get(0).sku_id;
                                    item.variant_name = tempList.get(0).variant_name;
                                    item.product_name = tempList.get(0).product_name;
                                    item.available_qty = tempList.get(0).available_qty;

                                    mainList.add(item);
                                    adapter.addItem(mainList, boxingItemList);
                                    qtyDialog.dismiss();
                                    //scannerDialog.dismiss();

                                    Toast.makeText(MerchantBoxing.this, "List Size : " + boxingItemList.size(), Toast.LENGTH_SHORT).show();

                                } else {
                                    qty.requestFocus();
                                    Toast toast = Toast.makeText(MerchantBoxing.this, "Enter less then or equal : " + tempList.get(0).available_qty, Toast.LENGTH_SHORT);
                                    TextView toastMessage = toast.getView().findViewById(android.R.id.message);
                                    toastMessage.setTextColor(Color.WHITE);
                                    toast.show();
                                }
                            } else {
                                Toast.makeText(MerchantBoxing.this, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                            }

                        });

                    } else {
                        final Dialog airSeaAertDialoge = new Dialog(MerchantBoxing.this);
                        airSeaAertDialoge.setContentView(R.layout.dialoge_exit);

                        int width = WindowManager.LayoutParams.MATCH_PARENT;
                        int height = WindowManager.LayoutParams.WRAP_CONTENT;

                        airSeaAertDialoge.getWindow().setLayout(width, height);
                        airSeaAertDialoge.setCancelable(false);
                        airSeaAertDialoge.show();

                        Button cancel = airSeaAertDialoge.findViewById(R.id.dialogeExitCancelID);
                        Button ok = airSeaAertDialoge.findViewById(R.id.dialogeExitOkID);
                        TextView msg = airSeaAertDialoge.findViewById(R.id.dialogeExitTextMsgID);

                        if (airORsea == 1) {
                            msg.setText("This product is not Air's product");
                        } else if (airORsea == 0) {
                            msg.setText("This product is not Sea's product");
                        }


                        ok.setText("Add");

                        cancel.setOnClickListener(v -> {
                            airSeaAertDialoge.dismiss();
                            //scannerDialog.dismiss();
                        });

                        final int finalCheckQty1 = checkQty;
                        ok.setOnClickListener(v -> {
                            airSeaAertDialoge.dismiss();
                            final Dialog qtyDialog = new Dialog(MerchantBoxing.this,R.style.fadeDialog);
                            qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                            int width1 = WindowManager.LayoutParams.MATCH_PARENT;
                            int height1 = WindowManager.LayoutParams.WRAP_CONTENT;

                            qtyDialog.getWindow().setLayout(width1, height1);
                            qtyDialog.setCancelable(false);
                            qtyDialog.show();

                            final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                            Button cancel1 = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                            Button ok1 = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                            TextView d_avl_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);


                            ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                            TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                            TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                            TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                            String insPrimaryImage = Common.BASEURL_PICTURE + tempList.get(0).primary_image;

                            if (tempList.get(0).variant_primary_image == null || tempList.get(0).variant_primary_image.equals("")) {
                                Glide.with(MerchantBoxing.this)
                                        .load(insPrimaryImage)
                                        .placeholder(R.drawable.ic_default)
                                        .into(cardImage);
                            } else {
                                String insVariantImage = Common.BASEURL_PICTURE + tempList.get(0).variant_primary_image;


                                Glide.with(MerchantBoxing.this)
                                        .load(insVariantImage)
                                        .placeholder(R.drawable.ic_default)
                                        .into(cardImage);
                            }


                            if (tempList.get(0).variant_name == null || tempList.get(0).variant_name.equals("")) {
                                cardName.setText(tempList.get(0).product_name);
                            } else {
                                cardName.setText(tempList.get(0).variant_name);
                            }

                            cardColor.setText("Color : " + tempList.get(0).color);
                            cardSize.setText("Size : " + tempList.get(0).size);


                            d_avl_qty.setText("Avl Qty : " + (tempList.get(0).available_qty - finalCheckQty1));

                            cancel1.setOnClickListener(v1 -> {
                                //scannerDialog.dismiss();
                                qtyDialog.dismiss();
                            });


                            ok1.setOnClickListener(v12 -> {
                                if (!TextUtils.isEmpty(qty.getText())) {
                                    String string = qty.getText().toString();
                                    int quantity = Integer.parseInt(string);
                                    if (quantity <= (tempList.get(0).available_qty - finalCheckQty1)) {

                                        final BoxingItemSubModel subModel = new BoxingItemSubModel();

                                        subModel.barcode = barcode;
                                        subModel.qty = quantity;
                                        subModel.sku_id = tempList.get(0).sku_id;

                                        boxingItemList.add(subModel);


                                        BoxingItemResponse.Data item = new BoxingItemResponse.Data();
                                        item.PK_NO = tempList.get(0).PK_NO;
                                        item.primary_image = tempList.get(0).primary_image;
                                        item.variant_primary_image = tempList.get(0).variant_primary_image;
                                        item.color = tempList.get(0).color;
                                        item.is_air = tempList.get(0).is_air;
                                        item.mkt_id = tempList.get(0).mkt_id;
                                        item.size = tempList.get(0).size;
                                        item.sku_id = tempList.get(0).sku_id;
                                        item.variant_name = tempList.get(0).variant_name;
                                        item.product_name = tempList.get(0).product_name;
                                        item.available_qty = tempList.get(0).available_qty;

                                        mainList.add(item);
                                        adapter.addItem(mainList, boxingItemList);
                                        qtyDialog.dismiss();
                                        //scannerDialog.dismiss();

                                        Toast.makeText(MerchantBoxing.this, "List Size : " + boxingItemList.size(), Toast.LENGTH_SHORT).show();

                                    } else {
                                        qty.requestFocus();
                                        Toast toast = Toast.makeText(MerchantBoxing.this, "Enter less then or equal : " + tempList.get(0).available_qty, Toast.LENGTH_SHORT);
                                        TextView toastMessage = toast.getView().findViewById(android.R.id.message);
                                        toastMessage.setTextColor(Color.WHITE);
                                        toast.show();
                                    }
                                } else {
                                    Toast.makeText(MerchantBoxing.this, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                                }

                            });
                        });
                    }

                } else {
                    //scannerDialog.dismiss();
                    Utils.snackbarToast(rootLayout, "Product not available for scan!");
                }


            } else {
                if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                    Utils.expiredTokenAlert(rootLayout, MerchantBoxing.this);
                } else {
                    Utils.snackbarToast(rootLayout, response.message);
                }
            }

        }, throwable -> {
            if (Objects.requireNonNull(throwable.getMessage()).toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                snackbar.show();
            } else {
                Snackbar snackbar = Snackbar.make(rootLayout, "" + throwable.getMessage(), Snackbar.LENGTH_LONG);
                snackbar.show();
            }
        }));
    }

    private void getBoxDimension() {
        dimensionTextList = new ArrayList<>();
        final String token = SharedPreperenceUtils.getToken(this);
        compositeDisposable.add(mIRetrofitApi.getBoxDimensionList(token).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
            if (response.status == 1){
                boxWeightList = response.data;
                dimensionTextList.add("Select box dimension");
                for (int i = 0; i < boxWeightList.size(); i++){
                    dimensionTextList.add(boxWeightList.get(i).dimension_text);
                }
                spinnerAdapter = new ArrayAdapter<>(MerchantBoxing.this, android.R.layout.simple_expandable_list_item_1, dimensionTextList);
                spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                weightSpinner.setAdapter(spinnerAdapter);
            }
        }, throwable -> {

        }));
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (position != 0){
            boxHeight.setText(""+boxWeightList.get((position-1)).height);
            boxWidth.setText(""+boxWeightList.get((position-1)).width);
            boxLength.setText(""+boxWeightList.get((position-1)).length);
        } else {
            boxHeight.setText("");
            boxWidth.setText("");
            boxLength.setText("");
            boxWeight.setText("");
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}