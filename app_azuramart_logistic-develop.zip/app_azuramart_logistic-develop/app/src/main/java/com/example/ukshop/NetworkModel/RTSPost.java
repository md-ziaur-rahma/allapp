package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class RTSPost {
    @SerializedName("user_id")
    public int user_id;
    @SerializedName("batch_no")
    public int batch_no;
}
