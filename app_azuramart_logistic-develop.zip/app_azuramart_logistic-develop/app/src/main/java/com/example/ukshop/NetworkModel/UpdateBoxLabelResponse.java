package com.example.ukshop.NetworkModel;

public class UpdateBoxLabelResponse extends ApiResponse{

}
