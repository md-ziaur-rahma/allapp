package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ukshop.Adapters.NewPurchaseItemAdapter;
import com.example.ukshop.Models.NewPurchaseItemModel;
import com.example.ukshop.R;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class NewProductPurchase extends AppCompatActivity {

    private CoordinatorLayout rootLayout;

    private RecyclerView recyclerView;
    private final List<NewPurchaseItemModel> list = new ArrayList<>();
    private NewPurchaseItemAdapter adapter;

    private Uri filePath;
    private Bitmap bitmap;
    private String deviceId;


    private Date d;

    private final int PICK_IMAGE_REQUEST = 71;
    private final int READ_EXTERNAL_STORAGE_REQUEST = 99;

    /// variables...
    private EditText barcode,price,qnt;
    private Button newProductAddBtn;
    private ImageView image;
    private LinearLayout chooseImage;
    private MaterialToolbar toolbar;


    // camera request code
    private static final int CAMERA_REQUEST_CODE = 101;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_product_purchase);
        //getSupportActionBar().hide();

        initialFindFields();

        // LayoutManager for recyclerView...
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        chooseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(NewProductPurchase.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(NewProductPurchase.this,new String[] {Manifest.permission.READ_EXTERNAL_STORAGE},99);
                }else {
                    chooseImage();
                }
            }
        });

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(NewProductPurchase.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(NewProductPurchase.this,new String[] {Manifest.permission.READ_EXTERNAL_STORAGE},99);
                }else {
                    chooseImage();
                }
            }
        });

        newProductAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                d = Calendar.getInstance().getTime();
                SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-2020 HH:mm", Locale.getDefault());
                String formattedDate = formatter.format(d);

                if (checkInputs()){
                    list.add(new NewPurchaseItemModel(bitmap,barcode.getText().toString(),price.getText().toString(),qnt.getText().toString(),formattedDate));

                    if (list.size() == 1){
                        adapter = new NewPurchaseItemAdapter(list,NewProductPurchase.this);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();


                        Snackbar snackbar = Snackbar.make(rootLayout,"Successfully add",Snackbar.LENGTH_SHORT);
                        snackbar.show();

                        //Toast.makeText(NewProductPurchase.this, "Product successfully add...", Toast.LENGTH_SHORT).show();
                    }else {
                        adapter.newList(list);
                    }

                    Log.e("msg","Add a item by "+deviceId);

                    clearAllField();

                }else {

                }
            }
        });



        /// Toolbar code....
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                int id = item.getItemId();



                return false;
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
        && data != null && data.getData() != null){
            filePath = data.getData();

            InputStream inputStream = null;
            try {

                inputStream = getContentResolver().openInputStream(filePath);
                bitmap = BitmapFactory.decodeStream(inputStream);
                //Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),filefath);
                image.setImageBitmap(bitmap);


            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

    }

    private void initialFindFields() {
        rootLayout = findViewById(R.id.newProductPurchaseRootLayoutID);
        toolbar = findViewById(R.id.newPurchaseToolbarID);
        recyclerView = findViewById(R.id.newPurchaseRecyclerID);

        image = findViewById(R.id.newPurchaseImageID);
        chooseImage = findViewById(R.id.newPurchaseChooseImageID);
        barcode = findViewById(R.id.newPurchaseProductBarcodeID);
        price = findViewById(R.id.newPurchaseProductPriceID);
        qnt = findViewById(R.id.newPurchaseProductQuantityID);

        newProductAddBtn = findViewById(R.id.newPurchaseProductAddBtnID);
    }


    private boolean checkInputs(){

        boolean isTrue = false;

        if (!TextUtils.isEmpty(barcode.getText()) && !TextUtils.isEmpty(price.getText())
                && !TextUtils.isEmpty(qnt.getText()) && filePath != null){
            isTrue = true;
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"Fill the all fields",Snackbar.LENGTH_SHORT);
            snackbar.show();

            //Toast.makeText(this, "Fill the all fields", Toast.LENGTH_SHORT).show();
            isTrue = false;
        }

        return isTrue;
    }

    private void chooseImage() {
        filePath = null;

        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"select image"),PICK_IMAGE_REQUEST);
    }

    private void clearAllField(){

        barcode.setText("");
        price.setText("");
        qnt.setText("");
        bitmap = null;
        filePath = null;

        image.setImageResource(R.drawable.ic_choose);
    }

    /// Read the device info..
    public void deviceID() {
        final TelephonyManager tm =
                (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);
        final String deviceID, serialNumber, androidID;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {

            String[] per = {Manifest.permission.READ_PHONE_STATE};
            requestPermissions(per, 1);
            return;
        }

        deviceId = "" + tm.getDeviceId();

    }
}