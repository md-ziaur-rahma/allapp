package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CodRtcShelveTransferPost {
    @SerializedName("is_shelve")
    public int is_shelve;
    @SerializedName("user_id")
    public int user_id;
    @SerializedName("shelve_label")
    public String shelve_label;
    @SerializedName("data")
    public List<CodRtcSubModel> data;
}
