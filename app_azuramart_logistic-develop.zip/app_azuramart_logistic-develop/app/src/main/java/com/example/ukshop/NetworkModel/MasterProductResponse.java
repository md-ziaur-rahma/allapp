package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class MasterProductResponse extends ApiResponse {

    @SerializedName("data")
    public ArrayList<Data> data;

    public class Data{
        @SerializedName("mp_id")
        public int mp_id;

        @SerializedName("mp_name")
        public String mp_name;

        @SerializedName("mp_image")
        public String mp_image;

        @SerializedName("mp_model")
        public String mp_model;

        @SerializedName("mp_brand")
        public String mp_brand;
    }

}
