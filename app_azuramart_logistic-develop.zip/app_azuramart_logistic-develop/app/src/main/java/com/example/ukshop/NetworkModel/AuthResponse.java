package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class AuthResponse extends ApiResponse {

    @SerializedName("data")
    public Data data;

    public class Data{
        @SerializedName("token")
        public String token;

        @SerializedName("user_name")
        public String user_name;

        @SerializedName("email")
        public String email;

        @SerializedName("mobile_no")
        public String mobile_no;

        @SerializedName("auth_id")
        public int auth_id;

        @SerializedName("role_id")
        public int role_id;

        @SerializedName("user_location")
        public int user_location;

        @SerializedName("merchant_id")
        public int merchant_id;
    }
}
