package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class CodRtcDispatchPost {
    @SerializedName("user_id")
    public int user_id;
    @SerializedName("order_id")
    public int order_id;

    @SerializedName("collect_date")
    public String collect_date;

    @SerializedName("collected_by")
    public String collected_by;

    @SerializedName("data")
    public List<CodRtcDispatchSubModel> data;
}
