package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import com.example.ukshop.Adapters.BoxListAdapter;
import com.example.ukshop.Adapters.ShipmentInprogressItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ShipmentInprogressPost;
import com.example.ukshop.NetworkModel.ShipmentInprogressResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class ShipmentInprogress extends AppCompatActivity {

    private List<ShipmentInprogressResponse.Data> mainList = new ArrayList<>();
    private ShipmentInprogressItemAdapter adapter;
    private RecyclerView recyclerView;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipment_inprogress);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new ShipmentInprogressItemAdapter(mainList,ShipmentInprogress.this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        loadBShipmentList();

        toolbar.setNavigationOnClickListener(v -> finish());

    }

    private void initialFindFields(){
        rootLayout = findViewById(R.id.shipmentInprogressRootlayoutID);
        toolbar = findViewById(R.id.shipmentInprogressToolbarID);
        recyclerView = findViewById(R.id.shipmentInprogressRecyclerID);
    }

    private void loadBShipmentList(){

        if (Utils.broadcastIntent(this,rootLayout)){

            mainList = new ArrayList<>();
            adapter.updateList(mainList);

            String token = SharedPreperenceUtils.getToken(this);
            int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

            final Dialog dialog = new Dialog(ShipmentInprogress.this);
            dialog.setContentView(R.layout.transparent_progress_dialoge);

            int width = WindowManager.LayoutParams.WRAP_CONTENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width, height);
            dialog.setCancelable(false);
            dialog.show();

            final ShipmentInprogressPost post = new ShipmentInprogressPost();
            post.user_id = user_id;

            compositeDisposable.add(mIRetrofitApi.getShipmentList(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ShipmentInprogressResponse>() {
                @Override
                public void accept(ShipmentInprogressResponse response) throws Exception {

                    if (response.status == 1){
                        mainList = response.data;

                        adapter.updateList(mainList);
                        dialog.dismiss();
                    }else {
                        dialog.dismiss();

                        if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                            Utils.expiredTokenAlert(rootLayout, ShipmentInprogress.this);
                        } else {
                            Snackbar snackbar = Snackbar.make(rootLayout,""+response.message,Snackbar.LENGTH_LONG);
                            snackbar.setAction("Retry", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    loadBShipmentList();
                                }
                            });
                            snackbar.show();
                        }
                    }
                }
            }, new Consumer<Throwable>() {
                @Override
                public void accept(Throwable throwable) throws Exception {
                    dialog.dismiss();

                    if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                        Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                loadBShipmentList();
                            }
                        });
                        snackbar.show();
                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                loadBShipmentList();
                            }
                        });
                        snackbar.show();
                    }
                }
            }));

        }else {
            NoInternetSnackBar();
        }


    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(ShipmentInprogress.this,rootLayout)){
                    loadBShipmentList();
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }
}