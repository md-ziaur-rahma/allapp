package com.example.ukshop.Adapters;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.ImageShowPage;
import com.example.ukshop.Activity.LoginPage;
import com.example.ukshop.Activity.ReboxingPage;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ReboxingResponse;
import com.example.ukshop.NetworkModel.UnboxingItemResponse;
import com.example.ukshop.NetworkModel.UnboxingPost;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.UnboxingPage;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static maes.tech.intentanim.CustomIntent.customType;

public class UnboxingItemAdapter extends RecyclerView.Adapter<UnboxingItemAdapter.ViewHolder> {

    private List<UnboxingItemResponse.Data> mainList;
    private Activity context;
    private CoordinatorLayout rootlayout;
    private String mainboxLabel;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;
    List<VariantImageResponse.Data> variantImageList = new ArrayList<>();

    public UnboxingItemAdapter(List<UnboxingItemResponse.Data> mainList, Activity context, CoordinatorLayout rootlayout) {
        this.mainList = mainList;
        this.context = context;
        this.rootlayout = rootlayout;
    }

    @NonNull
    @Override
    public UnboxingItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.unboxing_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UnboxingItemAdapter.ViewHolder holder, int position) {

        int pk_id = mainList.get(position).PK_NO;
        String imageUrl = mainList.get(position).variant_primary_image;
        String primaryImage = mainList.get(position).primary_image;
        String skuId = mainList.get(position).sku_id;
        String mktId = mainList.get(position).mkt_id;
        String name = mainList.get(position).product_name;
        String vaiantName = mainList.get(position).variant_name;
        String color = mainList.get(position).color;
        String size = mainList.get(position).size;
        String barcode = mainList.get(position).barcode;
        int avlqty = mainList.get(position).available_qty;
        int gQty = mainList.get(position).given_qty;

        holder.setData(pk_id,avlqty,gQty,barcode,position,primaryImage,imageUrl,skuId,
                mktId,name,vaiantName,color,size);
    }

    @Override
    public int getItemCount() {
        return mainList.size();
    }

    public void updateRecyclerView(List<UnboxingItemResponse.Data> newList, String boxLabel){
        mainList = newList;
        mainboxLabel = boxLabel;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView qty,avl_qty;
        Button unboxBtn;

        private ImageView variant_iamge;
        private TextView name,skuId,size,color;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            variant_iamge = itemView.findViewById(R.id.unboxingl_item_imageID);
            name = itemView.findViewById(R.id.unboxingl_item_nameID);
            skuId = itemView.findViewById(R.id.unboxingl_item_skuID);
            size = itemView.findViewById(R.id.unboxingl_item_sizeID);
            color = itemView.findViewById(R.id.unboxingl_item_colorID);

            avl_qty = itemView.findViewById(R.id.unboxingl_item_avl_qntID);
            qty = itemView.findViewById(R.id.unboxingl_item_qntID);
            unboxBtn = itemView.findViewById(R.id.unboxingl_item_unboxBtnID);

        }

        public void setData(final int pk_id,final int avlqty,final int gqty,final String barcode, final int position, final String primaryImage,
                            final String variantImage, final String sku, final String mkt, final String name, final String variantName,
                            final String color, final String size ){

            String insPrimaryImage = Common.BASEURL_PICTURE + primaryImage;

            if (variantImage == null || variantImage.equals("")){
                Glide.with(context)
                        .load(insPrimaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_iamge);
            }else {
                String insVariantImage = Common.BASEURL_PICTURE + variantImage;


                Glide.with(context)
                        .load(insVariantImage)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_iamge);
            }



            if (variantName == null || variantName.equals("")){
                this.name.setText(name);
            }else {
                this.name.setText(variantName);
            }

            //this.skuId.setText("SKU : "+sku);
            this.skuId.setText("Barcode : "+barcode);
            this.color.setText("Color : "+color);
            this.size.setText("Size : "+size);

            this.qty.setText("Qty : "+gqty);
            this.avl_qty.setText("Avl Qty : "+gqty);

            unboxBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final Dialog qtyDialog = new Dialog(context,R.style.slideUpDownDialog);
                    qtyDialog.setContentView(R.layout.dialoge_unboxing);

                    int width = WindowManager.LayoutParams.MATCH_PARENT;
                    int height = WindowManager.LayoutParams.WRAP_CONTENT;

                    qtyDialog.getWindow().setLayout(width,height);
                    qtyDialog.setCancelable(false);
                    qtyDialog.show();

                    final EditText qtyText = qtyDialog.findViewById(R.id.unboxingItemQtyDialogeQtyID);
                    Button cancel = qtyDialog.findViewById(R.id.unboxingItemQtyDialogeCancelID);
                    Button ok = qtyDialog.findViewById(R.id.unboxingItemAddDialogeBtnID);

                    TextView d_avl_qty = qtyDialog.findViewById(R.id.unboxingItemGivenQtyID);


                    ImageView cardImage = qtyDialog.findViewById(R.id.unboxingItemAddDialogImageID);
                    TextView cardName = qtyDialog.findViewById(R.id.unboxingItemAddDialogeNameID);
                    TextView cardColor = qtyDialog.findViewById(R.id.unboxingItemAddDialogeColorID);
                    TextView cardSize = qtyDialog.findViewById(R.id.unboxingItemAddDialogeSizeID);

                    String insPrimaryImage = Common.BASEURL_PICTURE + primaryImage;

                    if (variantImage == null || variantImage.equals("")) {
                        Glide.with(context)
                                .load(insPrimaryImage)
                                .placeholder(R.drawable.ic_default)
                                .into(cardImage);
                    } else {
                        String insVariantImage = Common.BASEURL_PICTURE + variantImage;


                        Glide.with(context)
                                .load(insVariantImage)
                                .placeholder(R.drawable.ic_default)
                                .into(cardImage);
                    }


                    if (variantName == null || variantName.equals("")) {
                        cardName.setText(name);
                    } else {
                        cardName.setText(variantName);
                    }

                    cardColor.setText("Color : " + color);
                    cardSize.setText("Size : " + size);


                    d_avl_qty.setText("Avl Qty : "+gqty);
                    qtyText.setText(""+gqty);

                    cancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            qtyDialog.dismiss();
                        }
                    });

                    ok.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (!TextUtils.isEmpty(qtyText.getText())){
                            String newQuantity = qtyText.getText().toString();
                            int newQtyInt = Integer.parseInt(newQuantity);


                                if (newQtyInt <= gqty){

                                    if (newQtyInt == 0){
                                        newQtyInt = 1;
                                    }

                                    String token = SharedPreperenceUtils.getToken(context);
                                    int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(context));

                                    final UnboxingPost post = new UnboxingPost();
                                    post.user_id = user_id;
                                    post.box_label = mainboxLabel;
                                    post.sku_id = sku;
                                    post.qty = newQtyInt;

                                    mIRetrofitApi = Common.getApiArobil();

                                    compositeDisposable.add(mIRetrofitApi.unboxing(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<UnboxingItemResponse>() {
                                        @Override
                                        public void accept(UnboxingItemResponse response) throws Exception {
                                            if (response.status == 1){

                                                mainList = response.data;
                                                notifyDataSetChanged();

                                                qtyDialog.dismiss();
                                                Snackbar snackbar = Snackbar.make(rootlayout,""+response.message,Snackbar.LENGTH_LONG);
                                                snackbar.show();
                                            }else {

                                                qtyDialog.dismiss();
                                                if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                                    Utils.expiredTokenAlert(rootlayout,context);
                                                }else {
                                                    Utils.snackbarToast(rootlayout,response.message);
                                                }
                                            }
                                        }
                                    }, new Consumer<Throwable>() {
                                        @Override
                                        public void accept(Throwable throwable) throws Exception {
                                            qtyDialog.dismiss();
                                            if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                                Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 15000);
                                                snackbar.show();
                                            }else {
                                                Snackbar snackbar = Snackbar.make(rootlayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                                                snackbar.show();
                                            }
                                        }
                                    }));

                                }else {
                                    qtyText.requestFocus();
                                    Toast.makeText(context, "Enter less then or equal : "+gqty, Toast.LENGTH_SHORT).show();
                                }
                            }else {
                                Toast.makeText(context, "Enter minimum 1 Qty!", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
                }
            });


            variant_iamge.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mIRetrofitApi = Common.getApiArobil();
                    String token = SharedPreperenceUtils.getToken(context);

                    compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<VariantImageResponse>() {
                        @Override
                        public void accept(VariantImageResponse response) throws Exception {
                            if (response.status == 1){
                                variantImageList = response.data;
                                ImageShowPage.variantImageList = variantImageList;
                                Intent intent = new Intent(context, ImageShowPage.class);
                                itemView.getContext().startActivity(intent);

                            }else {

                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    }));
                }
            });

        }
    }
}
