package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ukshop.Adapters.PriorityBoxAdapter;
import com.example.ukshop.Adapters.UnboxingBoxListAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.NetworkModel.PriorityBoxPost;
import com.example.ukshop.NetworkModel.PriorityBoxResponse;
import com.example.ukshop.R;
import com.example.ukshop.UnboxingPage;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

import static maes.tech.intentanim.CustomIntent.customType;

public class UnboxingBoxListPage extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private CoordinatorLayout rootlayout;
    private MaterialToolbar toolbar;
    private NestedScrollView nestedScrollView;

    private RecyclerView recyclerView;
    private List<PriorityBoxResponse.Data> list = new ArrayList<>();
    private List<PriorityBoxResponse.Data> scrollList = new ArrayList<>();

    private UnboxingBoxListAdapter adapter;

    private Button productScanBtn;
    private LinearLayout boxScan;
    private TextView boxLabel;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;


    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static final int CAMERA_PERMISSION_CODE = 501;


    private static boolean isFlash = false;
    private static boolean isCamreOpen = false;

    //public static String checkBoxlabel = null;

    private boolean isInvalid = false;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unboxing_box_list_page);

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        boxLabel.setText(getResources().getString(R.string.unboxing_box_label));

        productScanBtn.setText("Scan Product");
        productScanBtn.setVisibility(View.GONE);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new UnboxingBoxListAdapter(list, UnboxingBoxListPage.this,rootlayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();


        boxScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(UnboxingBoxListPage.this)){
                    openScanner();
                }else {
                    ActivityCompat.requestPermissions(UnboxingBoxListPage.this,new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
                }
            }
        });

        boxScan.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                final Dialog dialog = new Dialog(UnboxingBoxListPage.this);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
                barcodeText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(8)});

                search.setText(R.string.ok);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){
                            if (barcode.length() == 8){
                                loadSingleBox(barcode);
                                dialog.dismiss();

                            }else {
                                Toast.makeText(UnboxingBoxListPage.this,"This is not Box Label!",Toast.LENGTH_LONG).show();
                            }

                        }else {
                            Toast.makeText(UnboxingBoxListPage.this,"Please Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });

                return false;
            }
        });

        if (Utils.broadcastIntent(this,rootlayout)){
            loadBoxList();
        }else {
            NoInternetSnackBar();
        }


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.menuShipment_refreshId){

                    if (Utils.broadcastIntent(UnboxingBoxListPage.this,rootlayout)){
                        loadBoxList();
                    }else {
                        NoInternetSnackBar();
                    }

                    return true;
                }
                return false;
            }
        });


        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if(v.getChildAt(v.getChildCount() - 1) != null) {
                    if ((scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight())) &&
                            scrollY > oldScrollY) {

                        //https://medium.com/@mujjtahidah/load-more-recyclerview-inside-nested-scroll-view-and-coordinator-layout-4f179dc01fd

                        if (!recyclerView.canScrollVertically(1)){
                            onScrollToBottom();
                        }

                    }
                }
            }
        });

    }



    private void onScrollToBottom(){
        if (scrollList.size() < list.size()){
            int x,y;
            if ((list.size() - scrollList.size()) >= 20){
                x = scrollList.size();
                y = x + 20;
            }else {
                x = scrollList.size();
                y = x + list.size() - scrollList.size();
            }

            for (int i = x; i < y; i++){
                scrollList.add(i,list.get(i));
            }

            adapter.updateList(scrollList);
        }
    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootlayout,"No Internet Connection!",5000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(UnboxingBoxListPage.this,rootlayout)){
                    loadBoxList();
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }


    private void initialFindFields() {
        rootlayout = (CoordinatorLayout)findViewById(R.id.unboxingBoxListRootLayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.unboxingBoxListToolbarID);
        nestedScrollView = (NestedScrollView)findViewById(R.id.unboxingBoxListScrollViewID);
        recyclerView = (RecyclerView)findViewById(R.id.unboxingBoxListRecyclerID);
        boxScan = (LinearLayout)findViewById(R.id.boxingBoxID);
        boxLabel = (TextView)findViewById(R.id.boxingBoxLebelID);
        productScanBtn = (Button)findViewById(R.id.boxingEndBoxBtnID);
    }

    private void openScanner(){
        scannerDialog = new Dialog(UnboxingBoxListPage.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


        isCamreOpen = true;
        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(UnboxingBoxListPage.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                isCamreOpen = false;
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }


    @Override
    protected void onStart() {
        super.onStart();

        if (Utils.broadcastIntent(this,rootlayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootlayout,this);
            }else {
                loadBoxList();
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootlayout,"No Internet Connection!",10000);
            snackbar.show();
        }
    }

    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mIRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ApiResponse>() {
            @Override
            public void accept(ApiResponse response) throws Exception {
                if (response.status == 0) {
                    isInvalid = true;
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));

        return isInvalid;
    }

    @Override
    public void onBackPressed() {
        scrollList = new ArrayList<>();
        list = new ArrayList<>();
        adapter.updateList(list);
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }


    @Override
    public void handleResult(Result rawResult) {
        if (!TextUtils.isEmpty(rawResult.getText())) {
            if (rawResult.getText().length() == 8) {
                scannerDialog.dismiss();
                scannerView.stopCamera();
                loadSingleBox(rawResult.getText());
            }else {
                wrongTone.start();
                scannerDialog.dismiss();
                scannerView.stopCamera();
                Utils.snackbarToast(rootlayout,"This is not barcode!");
            }
        }else {
            wrongTone.start();
            scannerDialog.dismiss();
            scannerView.stopCamera();
            Utils.snackbarToast(rootlayout,"Empty barcode!");
        }
    }

    private void loadBoxList(){
        if (Utils.broadcastIntent(this,rootlayout)){

            list = new ArrayList<>();
            scrollList = new ArrayList<>();
            adapter.updateList(list);

            String token = SharedPreperenceUtils.getToken(this);
            int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

            final Dialog dialog = new Dialog(UnboxingBoxListPage.this);
            dialog.setContentView(R.layout.transparent_progress_dialoge);

            int width = WindowManager.LayoutParams.WRAP_CONTENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width, height);
            dialog.setCancelable(false);
            dialog.show();

            final PriorityBoxPost post = new PriorityBoxPost();
            post.user_id = user_id;

            compositeDisposable.add(mIRetrofitApi.getUnboxingBoxList(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<PriorityBoxResponse>() {
                @Override
                public void accept(PriorityBoxResponse response) throws Exception {

                    if (response.status == 1){
                        scrollList = new ArrayList<>();
                        list = response.data;

                        if (list.size() >= 30){
                            for (int i = 0; i < 30; i++){
                                scrollList.add(list.get(i));
                            }
                        }else {
                            scrollList.addAll(list);
                        }

                        adapter.updateList(scrollList);

                        dialog.dismiss();
                    }else {
                        dialog.dismiss();

                        if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                            Utils.expiredTokenAlert(rootlayout, UnboxingBoxListPage.this);
                        } else {
                            Snackbar snackbar = Snackbar.make(rootlayout,""+response.message,Snackbar.LENGTH_LONG);
                            snackbar.setAction("Retry", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    loadBoxList();
                                }
                            });
                            snackbar.show();
                        }
                    }

                }
            }, new Consumer<Throwable>() {
                @Override
                public void accept(Throwable throwable) throws Exception {
                    dialog.dismiss();

                    if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                        Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 5000);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                loadBoxList();
                            }
                        });
                        snackbar.show();
                    }else {
                        Snackbar snackbar = Snackbar.make(rootlayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                loadBoxList();
                            }
                        });
                        snackbar.show();
                    }

                }
            }));

        }else {
            NoInternetSnackBar();
        }

    }

    private void loadSingleBox(String barcode){

        int isData = 0;

        for (int i = 0; i < list.size(); i++){
            if (list.get(i).box_label.equals(barcode)){
                scrollList = new ArrayList<>();
                isData = 1;
                scrollList.add(list.get(i));
            }
        }

        if (isData > 0){
            rightTone.start();
            adapter.updateList(scrollList);
        }else {
            wrongTone.start();
            Utils.snackbarToast(rootlayout,"Box not found!");
        }


    }


}