package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class ConsignmentListPost {
    @SerializedName("user_id")
    public int user_id;
}
