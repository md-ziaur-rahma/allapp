package com.example.ukshop.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.ImageShowPage;
import com.example.ukshop.Activity.RtsLandAreaCheckout;
import com.example.ukshop.Activity.RtsShelveCheckout;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.Network.RTSSubModel;
import com.example.ukshop.NetworkModel.RTSResponse;
import com.example.ukshop.NetworkModel.ShelveItemListResponse;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static maes.tech.intentanim.CustomIntent.customType;

public class RTSListAdapter extends RecyclerView.Adapter<RTSListAdapter.ViewHolder> {

    private List<RTSResponse.Data> list;
    private Activity context;
    private CoordinatorLayout rootLayout;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    List<VariantImageResponse.Data> variantImageList = new ArrayList<>();

    public RTSListAdapter(List<RTSResponse.Data> list, Activity context, CoordinatorLayout rootLayout) {
        this.list = list;
        this.context = context;
        this.rootLayout = rootLayout;
    }

    @NonNull
    @Override
    public RTSListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.checkout_product_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RTSListAdapter.ViewHolder holder, int position) {
        String imageUrl = list.get(position).variant_primary_image;
        String primaryImage = list.get(position).primary_image;
        int pk_id = list.get(position).PK_NO;
        String skuId = list.get(position).sku_id;
        String barcode = list.get(position).barcode;
        String name = list.get(position).product_name;
        String variantName = list.get(position).variant_name;
        String color = list.get(position).color;
        String size = list.get(position).size;
        String label = list.get(position).label;
        int batch_no = list.get(position).batch_no;
        int orderID = list.get(position).order_id;
        int qty = list.get(position).qty;
        String location = list.get(position).location;

        holder.setData(skuId,barcode,pk_id,name,variantName,primaryImage,
                imageUrl,color,size,qty,label,location,batch_no,orderID,position);
    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    public void updateList(List<RTSResponse.Data> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private Button gotoCheckoutBtn;
        private ImageView variant_image;
        private TextView name,skuId,barcode,location,size,color,qty;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            gotoCheckoutBtn = itemView.findViewById(R.id.cpGotoBtnID);
            variant_image = itemView.findViewById(R.id.cpImageID);
            name = itemView.findViewById(R.id.cpNameID);
            skuId = itemView.findViewById(R.id.cpSkuID);

            location = itemView.findViewById(R.id.cpLocationID);
            barcode = itemView.findViewById(R.id.cpBarcodeID);
            size = itemView.findViewById(R.id.cpSizeID);
            color = itemView.findViewById(R.id.cpColorID);
            qty = itemView.findViewById(R.id.cpQtyID);

        }

        public void setData(final String sku, final String barcode, final int pk_id, final String name, final String variant_Name, String primaryImage, String imageUrl,
                            final String color, final String size, final int quantity, final String shelveLabel, final String location,final int batch_no, final int orderID, final int position) {

            if (imageUrl == null || imageUrl.equals("")) {
                primaryImage = Common.BASEURL_PICTURE + primaryImage;
                Glide.with(context)
                        .load(primaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_image);
            } else {
                imageUrl = Common.BASEURL_PICTURE + imageUrl;
                Glide.with(context)
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_image);
            }


            if (variant_Name == null || variant_Name.equals("")) {
                this.name.setText(name);
            } else {
                this.name.setText(variant_Name);
            }

            skuId.setText("SKU : " + sku);
            this.barcode.setText("Barcode : " + barcode);
            this.color.setText("Color : " + color);
            this.size.setText("Size : "+size);
            this.qty.setText("Qty : "+quantity);
            this.location.setText(location);

            final String finalImageUrl = imageUrl;
            final String finalPrimaryImage = primaryImage;

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            gotoCheckoutBtn.setText("Please Collect");

            if (shelveLabel.length() == 10){
                gotoCheckoutBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        final ShelveItemListResponse.Data item = new ShelveItemListResponse.Data();
                        item.PK_NO = pk_id;
                        item.sku_id = sku;
                        item.barcode = barcode;
                        item.color = color;
                        item.size = size;
                        item.variant_name = variant_Name;
                        item.product_name = name;
                        item.available_qty = quantity;
                        item.variant_primary_image = finalImageUrl;
                        item.primary_image = finalPrimaryImage;

                        final List<RTSSubModel> subList = new ArrayList<>();

                        final RTSSubModel subModel = new RTSSubModel();
                        subModel.qty = quantity;
                        subModel.barcode = barcode;
                        subModel.sku_id = sku;
                        subModel.batch_no = batch_no;
                        subModel.order_id = orderID;

                        subList.add(subModel);

                        RtsShelveCheckout.data = item;
                        RtsShelveCheckout.list = subList;
                        RtsShelveCheckout.strShelveLabel = shelveLabel;
                        RtsShelveCheckout.strShelveLocation = location;

                        Intent intent  = new Intent(context, RtsShelveCheckout.class);
                        itemView.getContext().startActivity(intent);
                        customType(context,"left-to-right");

                    }
                });
            }else {

                gotoCheckoutBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final ShelveItemListResponse.Data item = new ShelveItemListResponse.Data();
                        item.PK_NO = pk_id;
                        item.sku_id = sku;
                        item.barcode = barcode;
                        item.color = color;
                        item.size = size;
                        item.variant_name = variant_Name;
                        item.product_name = name;
                        item.available_qty = quantity;
                        item.variant_primary_image = finalImageUrl;
                        item.primary_image = finalPrimaryImage;

                        final List<RTSSubModel> subList = new ArrayList<>();

                        final RTSSubModel subModel = new RTSSubModel();
                        subModel.qty = quantity;
                        subModel.barcode = barcode;
                        subModel.sku_id = sku;
                        subModel.batch_no = batch_no;
                        subModel.order_id = orderID;

                        subList.add(subModel);

                        RtsLandAreaCheckout.data = item;
                        RtsLandAreaCheckout.list = subList;

                        Intent intent  = new Intent(context, RtsLandAreaCheckout.class);
                        itemView.getContext().startActivity(intent);
                        customType(context,"left-to-right");
                    }
                });



            }


            variant_image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mIRetrofitApi = Common.getApiArobil();
                    String token = SharedPreperenceUtils.getToken(context);

                    compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<VariantImageResponse>() {
                        @Override
                        public void accept(VariantImageResponse response) throws Exception {
                            if (response.status == 1){
                                variantImageList = response.data;
                                ImageShowPage.variantImageList = variantImageList;
                                Intent intent = new Intent(context, ImageShowPage.class);
                                itemView.getContext().startActivity(intent);

                            }else {

                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    }));
                }
            });

        }



    }
}
