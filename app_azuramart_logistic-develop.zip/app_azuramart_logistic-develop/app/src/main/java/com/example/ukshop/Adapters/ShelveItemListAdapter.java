package com.example.ukshop.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.ImageShowPage;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ShelveItemListResponse;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class ShelveItemListAdapter extends RecyclerView.Adapter<ShelveItemListAdapter.ViewHolder> {

    private List<ShelveItemListResponse.Data> list;
    private Activity context;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    List<VariantImageResponse.Data> variantImageList = new ArrayList<>();

    public ShelveItemListAdapter(List<ShelveItemListResponse.Data> list, Activity context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ShelveItemListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.stock_check_layout_2,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ShelveItemListAdapter.ViewHolder holder, int position) {

        String imageUrl = list.get(position).variant_primary_image;
        String primaryImage = list.get(position).primary_image;
        int pk_id = list.get(position).PK_NO;
        String skuId = list.get(position).sku_id;
        String barcode = list.get(position).barcode;
        String mktId = list.get(position).mkt_id;
        String name = list.get(position).product_name;
        String vaiantName = list.get(position).variant_name;
        String color = list.get(position).color;
        String size = list.get(position).size;
        float price = list.get(position).price;
        float ins_price = list.get(position).ins_price;
        float sm_price = list.get(position).sm_price;
        float ss_price = list.get(position).ss_price;
        int qty = list.get(position).available_qty;

        holder.setData(skuId,barcode,mktId,pk_id,name,vaiantName,primaryImage,
                imageUrl,color,size,price,ins_price,sm_price,ss_price,qty,position);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void updateList(List<ShelveItemListResponse.Data> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private ImageView variant_iamge,seaIcon,airIcon;
        private TextView name,skuId,ig_code,barcode,size,color,price,qty,price2,airText,seaText,
                airQty, seaQty;
        private Button bookBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            variant_iamge = itemView.findViewById(R.id.stock_check_item_imageID);
            name = itemView.findViewById(R.id.stock_check_item_nameID);
            skuId = itemView.findViewById(R.id.stock_check_item_skuID);

            skuId.setVisibility(View.GONE);

            barcode = itemView.findViewById(R.id.stock_check_item_barcodeID);
            ig_code = itemView.findViewById(R.id.stock_check_item_IGCODEID);
            size = itemView.findViewById(R.id.stock_check_item_sizeID);
            color = itemView.findViewById(R.id.stock_check_item_colorID);

            airText = itemView.findViewById(R.id.stock_check_item_airID);
            seaText = itemView.findViewById(R.id.stock_check_item_seaID);
            airIcon = itemView.findViewById(R.id.stock_check_item_airIconID);
            seaIcon = itemView.findViewById(R.id.stock_check_item_seaIconID);
            airQty = itemView.findViewById(R.id.stock_check_item_airQtyID);
            seaQty = itemView.findViewById(R.id.stock_check_item_seaQtyID);

            price = itemView.findViewById(R.id.stock_check_item_priceID);
            price2 = itemView.findViewById(R.id.stock_check_item_price2ID);
            qty = itemView.findViewById(R.id.stock_check_item_qntID);

            bookBtn = itemView.findViewById(R.id.stock_check_item_buttonID);

        }

        public void setData(final String sku,final String barcode, String mktid, final int pk_id, String name, String variant_Name,String primaryImage, String imageUrl,
                            String color, String size, float price, final float ins_price,final float sm_price, final float ss_price,int quantity, final int position) {

            if (imageUrl == null || imageUrl == "") {
                primaryImage = Common.BASEURL_PICTURE + primaryImage;
                Glide.with(context)
                        .load(primaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_iamge);
            } else {
                imageUrl = Common.BASEURL_PICTURE + imageUrl;
                Glide.with(context)
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_iamge);
            }


            if (variant_Name == null || variant_Name == "") {
                this.name.setText(name);
            } else {
                this.name.setText(variant_Name);
            }

            skuId.setText("SKU : " + sku);
            this.barcode.setText("Barcode : " + barcode);
            this.ig_code.setText("IG CODE : " + mktid);
            this.color.setText("Color : " + color);
            this.size.setText("Size : " + size);

            this.airIcon.setVisibility(View.GONE);
            this.seaIcon.setVisibility(View.GONE);
            this.airQty.setVisibility(View.GONE);
            this.seaQty.setVisibility(View.GONE);
            this.airText.setVisibility(View.GONE);
            this.seaText.setVisibility(View.GONE);

            NumberFormat formatter = new DecimalFormat("#0.00");

            this.price.setText("RM "+formatter.format(price)+"  / "+formatter.format(ins_price));
            this.price2.setText("SM "+formatter.format(sm_price)+"  / SS "+formatter.format(ss_price));

            this.qty.setText("Qty : " + quantity);

            this.bookBtn.setVisibility(View.GONE);

            // Optional code...
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            variant_iamge.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mIRetrofitApi = Common.getApiArobil();
                    String token = SharedPreperenceUtils.getToken(context);

                    compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<VariantImageResponse>() {
                        @Override
                        public void accept(VariantImageResponse response) throws Exception {
                            if (response.status == 1){
                                variantImageList = response.data;
                                ImageShowPage.variantImageList = variantImageList;
                                Intent intent = new Intent(context, ImageShowPage.class);
                                itemView.getContext().startActivity(intent);

                            }else {

                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    }));
                }
            });

        }
    }
}
