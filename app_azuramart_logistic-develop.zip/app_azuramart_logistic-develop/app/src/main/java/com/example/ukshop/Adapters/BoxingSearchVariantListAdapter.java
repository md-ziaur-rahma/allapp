package com.example.ukshop.Adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.NetworkModel.StockCheckSearchResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

public class BoxingSearchVariantListAdapter extends RecyclerView.Adapter<BoxingSearchVariantListAdapter.ViewHolder> {

    private List<StockCheckSearchResponse.Data> list;
    private Activity contex;
    private int isShow;
    private CoordinatorLayout rootLayout;

    public BoxingSearchVariantListAdapter(List<StockCheckSearchResponse.Data> list, Activity contex, int isShow, CoordinatorLayout rootLayout) {
        this.list = list;
        this.contex = contex;
        this.isShow = isShow;
        this.rootLayout = rootLayout;
    }

    @NonNull
    @Override
    public BoxingSearchVariantListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.stock_check_layout_2,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BoxingSearchVariantListAdapter.ViewHolder holder, int position) {
        String imageUrl = list.get(position).variant_primary_image;
        String primaryImage = list.get(position).primary_image;
        String skuId = list.get(position).sku_id;
        String mktId = list.get(position).mkt_id;
        String name = list.get(position).product_name;
        String vaiantName = list.get(position).variant_name;
        String color = list.get(position).color;
        String size = list.get(position).size;
        float price = list.get(position).price;
        int qty = list.get(position).available_qty;


        holder.setData(skuId,mktId,name,vaiantName,imageUrl,primaryImage,color,size,price,qty,position);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void filterdItem(ArrayList<StockCheckSearchResponse.Data> filteredList){
        list = filteredList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private ImageView variant_iamge;
        private TextView name,skuId,size,color,price,qty;
        private Button bookBtn;

        public ViewHolder(@NonNull View itemView){
            super(itemView);

            variant_iamge = itemView.findViewById(R.id.stock_check_item_imageID);
            name = itemView.findViewById(R.id.stock_check_item_nameID);
            skuId = itemView.findViewById(R.id.stock_check_item_skuID);
            size = itemView.findViewById(R.id.stock_check_item_sizeID);
            color = itemView.findViewById(R.id.stock_check_item_colorID);
            price = itemView.findViewById(R.id.stock_check_item_priceID);
            qty = itemView.findViewById(R.id.stock_check_item_qntID);

            bookBtn = itemView.findViewById(R.id.stock_check_item_buttonID);

        }

        public void setData(final String sku, final String mktid, final String name, final String variant_Name, String imageUrl,
                            String primary_iamge, final String color, final String size, final float price, final int quantity, int position){

            primary_iamge = Common.BASEURL_PICTURE + primary_iamge;

            if (imageUrl == null || imageUrl == ""){
                Glide.with(contex)
                        .load(primary_iamge)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_iamge);
            }else {
                imageUrl = Common.BASEURL_PICTURE + imageUrl;

                Glide.with(contex)
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_iamge);
            }

            skuId.setText("SKU : "+sku);
            this.color.setText("Color : "+color);
            this.size.setText("Size : "+size);

            NumberFormat formatter = new DecimalFormat("##.00");

            this.price.setText("RM "+formatter.format(price));
            this.qty.setText("Qty : "+quantity);
            this.bookBtn.setVisibility(View.GONE);
            this.qty.setVisibility(View.GONE);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

        }
    }
}
