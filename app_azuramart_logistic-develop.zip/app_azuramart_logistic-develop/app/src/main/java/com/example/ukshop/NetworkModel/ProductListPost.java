package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class ProductListPost {
    @SerializedName("Authorization")
    public String Authorization;
}
