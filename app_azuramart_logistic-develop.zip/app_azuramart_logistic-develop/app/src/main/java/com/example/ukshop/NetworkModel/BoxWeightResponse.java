package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class BoxWeightResponse extends ApiResponse{

    @SerializedName("data")
    public ArrayList<Data> data;

    public static class Data {
        @SerializedName("dimension_text")
        public String dimension_text;
        @SerializedName("height")
        public int height;
        @SerializedName("width")
        public int width;
        @SerializedName("length")
        public int length;
    }
}
