
package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class ApiResponse {
    @SerializedName("status")
    public int status;

    @SerializedName("code")
    public int code;

    @SerializedName("message")
    public String message;
}
