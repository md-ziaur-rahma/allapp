package com.example.ukshop.Network;

import com.google.gson.annotations.SerializedName;

public class RTSSubModel {
    @SerializedName("barcode")
    public String barcode;
    @SerializedName("sku_id")
    public String sku_id;
    @SerializedName("qty")
    public int qty;
    @SerializedName("batch_no")
    public int batch_no;
    @SerializedName("order_id")
    public int order_id;
}
