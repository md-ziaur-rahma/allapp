package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class BoxingItemPost {
    @SerializedName("is_update")
    public int is_update;
    @SerializedName("user_id")
    public int user_id;
    @SerializedName("box_label")
    public String box_label;
    @SerializedName("height")
    public String height;
    @SerializedName("width")
    public String width;
    @SerializedName("length")
    public String length;
    @SerializedName("weight")
    public String weight;
    @SerializedName("merchant_id")
    public int merchant_id;
    @SerializedName("data")
    public List<BoxingItemSubModel> data;
}
