package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.ukshop.Adapters.ReboxingItemAdapter;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.NetworkModel.BoxWeightResponse;
import com.example.ukshop.NetworkModel.BoxingItemPost;
import com.example.ukshop.NetworkModel.BoxingResponse;
import com.example.ukshop.NetworkModel.ReboxingPost;
import com.example.ukshop.NetworkModel.ReboxingResponse;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.BoxingItemResponse;
import com.example.ukshop.NetworkModel.BoxingItemSubModel;
import com.example.ukshop.NetworkModel.StockCheckPost;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

import static maes.tech.intentanim.CustomIntent.customType;

public class ReboxingPage extends AppCompatActivity implements ZXingScannerView.ResultHandler,
        AdapterView.OnItemSelectedListener{

    private MaterialToolbar toolbar;
    private CoordinatorLayout rootlayout;
    private LinearLayout boxScan;
    private TextView boxLabel;
    private static Button reBoxBtn;
    private static LinearLayout scanItem;
    private TextView scanItemText;

    private int merchant_id;

    /// ............. Weight Layout ..............
    private EditText boxHeight,boxWidth,boxLength,boxWeight;
    private Spinner weightSpinner;
    private List<BoxWeightResponse.Data> boxWeightList = new ArrayList<>();
    private List<String> dimensionTextList = new ArrayList<>();
    private ArrayAdapter<String> spinnerAdapter;
    private static View boxWeightLayout;

    private RecyclerView recyclerview;
    private static List<ReboxingResponse.Data> mainList = new ArrayList<>();
    private static List<BoxingItemSubModel> list = new ArrayList<>();
    private List<ReboxingResponse.Data> tempList = new ArrayList<>();
    private ReboxingItemAdapter adapter;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;


    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static final int CAMERA_PERMISSION_CODE = 501;


    private static boolean isFlash = false;
    private static boolean isCamreOpen = false;
    private static int boxORitem = 0;

    private String checkBoxLabel = null;

    private boolean isInvalid = false;

    private int airORsea = -1;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reboxing_page);

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        merchant_id = getIntent().getIntExtra("merchant_id",0);

        reBoxBtn.setText(getResources().getString(R.string.unboxing_btn_label));
        boxLabel.setText(getResources().getString(R.string.unboxing_box_label));

        inVisibleBtns();

        weightSpinner.setOnItemSelectedListener(this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerview.setLayoutManager(layoutManager);

        adapter = new ReboxingItemAdapter(mainList,list, ReboxingPage.this,rootlayout);
        recyclerview.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        boxScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(ReboxingPage.this)){
                    boxORitem = 1;
                    openScanner();
                }else {
                    ActivityCompat.requestPermissions(ReboxingPage.this,new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
                }
            }
        });

        boxScan.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                final Dialog dialog = new Dialog(ReboxingPage.this);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
                barcodeText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(8)});

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){
                            if (barcode.length() == 8){

                                getboxItem(barcode);
                                dialog.dismiss();

                            }else {
                                Toast.makeText(ReboxingPage.this,"This is not box label!",Toast.LENGTH_LONG).show();
                            }
                        }else {
                            Toast.makeText(ReboxingPage.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });

                return false;
            }
        });

        scanItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(ReboxingPage.this)){
                    boxORitem = 2;
                    openScanner();
                }else {
                    ActivityCompat.requestPermissions(ReboxingPage.this,new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
                }
            }
        });


        scanItem.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                final Dialog dialog = new Dialog(ReboxingPage.this);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){

                                getItem(barcode);
                                dialog.dismiss();

                        }else {
                            Toast.makeText(ReboxingPage.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });

                return false;
            }
        });

        reBoxBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(ReboxingPage.this,rootlayout)){
                    if (list.size() != 0){
                        if (checkBoxLabel == null || checkBoxLabel.equals("")){
                            Utils.snackbarToast(rootlayout,"Please scan box label!");
                        }else {

                            final Dialog dialog = new Dialog(ReboxingPage.this);
                            dialog.setContentView(R.layout.transparent_progress_dialoge);

                            int width = WindowManager.LayoutParams.WRAP_CONTENT;
                            int height = WindowManager.LayoutParams.WRAP_CONTENT;

                            dialog.getWindow().setLayout(width,height);
                            dialog.setCancelable(false);
                            dialog.show();

                            String token = SharedPreperenceUtils.getToken(ReboxingPage.this);
                            int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(ReboxingPage.this));
                            String boxHeightIns = boxHeight.getText().toString();
                            String boxWidthIns = boxWidth.getText().toString();
                            String boxLengthIns = boxLength.getText().toString();
                            String boxWeightIns = boxWeight.getText().toString();

                            if (TextUtils.isEmpty(boxHeightIns)){
                                boxHeightIns = "";
                            }
                            if (TextUtils.isEmpty(boxWidthIns)){
                                boxWidthIns = "";
                            }
                            if (TextUtils.isEmpty(boxLengthIns)){
                                boxLengthIns = "";
                            }
                            if (TextUtils.isEmpty(boxWeightIns)){
                                boxWeightIns = "";
                            }

                            final BoxingItemPost post = new BoxingItemPost();
                            post.is_update = 2;
                            post.box_label = checkBoxLabel;
                            post.user_id = user_id;
                            post.height = boxHeightIns;
                            post.width = boxWidthIns;
                            post.length = boxLengthIns;
                            post.weight = boxWeightIns;
                            post.merchant_id = merchant_id;
                            post.data = list;

                            Log.e("reBoxing remove post", "msg"+new Gson().toJson(post));

                            compositeDisposable.add(mIRetrofitApi.boxing(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<BoxingResponse>() {
                                @Override
                                public void accept(BoxingResponse response) throws Exception {
                                    if (response.status == 1) {
                                        Snackbar snackbar = Snackbar.make(rootlayout, "" + response.message, Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                        dialog.dismiss();

                                        clearAll();

                                        adapter.addItem(mainList,list);
                                    }else {
                                        dialog.dismiss();

                                        if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                            Utils.expiredTokenAlert(rootlayout,ReboxingPage.this);
                                        }else {
                                            Utils.snackbarToast(rootlayout,response.message);
                                        }
                                    }
                                }
                            }, new Consumer<Throwable>() {
                                @Override
                                public void accept(Throwable throwable) throws Exception {
                                    dialog.dismiss();

                                    if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                        Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 5000);
                                        snackbar.show();
                                    }else {
                                        Snackbar snackbar = Snackbar.make(rootlayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                    }
                                }
                            }));

                        }
                    }else {
                        Snackbar snackbar = Snackbar.make(rootlayout,"No Change!",Snackbar.LENGTH_LONG);
                        snackbar.show();
                    }
                }else {
                    Snackbar snackbar = Snackbar.make(rootlayout,"No internet connection!",Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // ....................... Box Dimension .......................
        if (Utils.broadcastIntent(this,rootlayout)){
            getBoxDimension();
        }

    }


    public static void shareableListUpdate(List<ReboxingResponse.Data> reboxingList,List<BoxingItemSubModel> postList){
        list = postList;
        mainList = reboxingList;
        if (list.size() == 0){
            inVisibleBtns();
        }else {
            visibleBtns();
        }
    }

    public static void visibleBtns(){
        reBoxBtn.setVisibility(View.VISIBLE);
        scanItem.setVisibility(View.VISIBLE);
        boxWeightLayout.setVisibility(View.VISIBLE);
    }

    public static void inVisibleBtns(){
        reBoxBtn.setVisibility(View.GONE);
        scanItem.setVisibility(View.GONE);
        boxWeightLayout.setVisibility(View.GONE);
    }

    private void initialFindFields() {
        rootlayout = (CoordinatorLayout)findViewById(R.id.reboxingRootlayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.reboxingToolbarID);
        scanItem = (LinearLayout) findViewById(R.id.reboxingScanItemIconID);
        //scanItemText = (TextView)findViewById(R.id.unboxingScantItemTextID);
        recyclerview = (RecyclerView)findViewById(R.id.reboxingItemRecyclerID);
        boxScan = (LinearLayout)findViewById(R.id.boxingBoxID);
        boxLabel = (TextView)findViewById(R.id.boxingBoxLebelID);
        reBoxBtn = (Button)findViewById(R.id.boxingEndBoxBtnID);

        boxHeight = (EditText) findViewById(R.id.boxingHeightID);
        boxWidth = (EditText) findViewById(R.id.boxingWidthID);
        boxLength = (EditText) findViewById(R.id.boxingLengthID);
        boxWeight = (EditText) findViewById(R.id.boxingWeightID);
        weightSpinner = (Spinner) findViewById(R.id.boxWeightSpinnerID);
        boxWeightLayout = (View) findViewById(R.id.reboxingRemoveWeightLayoutID);
    }

    private void openScanner(){
        scannerDialog = new Dialog(ReboxingPage.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


        isCamreOpen = true;
        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(ReboxingPage.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                isCamreOpen = false;
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootlayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootlayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootlayout,"No Internet Connection!",5000);
            snackbar.show();
        }
    }

    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mIRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ApiResponse>() {
            @Override
            public void accept(ApiResponse response) throws Exception {
                if (response.status == 0) {
                    isInvalid = true;
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));

        return isInvalid;
    }

    @Override
    public void onBackPressed() {
        reBoxBtn.setVisibility(View.GONE);
        scanItem.setVisibility(View.GONE);
        list = new ArrayList<>();
        mainList = new ArrayList<>();
        tempList = new ArrayList<>();

        finish();
    }

    private void clearAll(){
        airORsea = -1;
        reBoxBtn.setVisibility(View.GONE);
        scanItem.setVisibility(View.GONE);
        list = new ArrayList<>();
        mainList = new ArrayList<>();
        tempList = new ArrayList<>();

        boxWeight.setText("");
        boxHeight.setText("");
        boxLength.setText("");
        boxWidth.setText("");
        //weightSpinner.setVisibility(View.GONE);
        //weightSpinner.setSelection(0);

        reBoxBtn.setText(getResources().getString(R.string.unboxing_btn_label));
        boxLabel.setText(getResources().getString(R.string.unboxing_box_label));
        inVisibleBtns();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }



    private void getboxItem(final String barcode){
        clearAll();
        list = new ArrayList<>();
        mainList = new ArrayList<>();
        tempList = new ArrayList<>();

        adapter.addItem(mainList,list);
        reBoxBtn.setVisibility(View.GONE);
        scanItem.setVisibility(View.GONE);
        checkBoxLabel = null;

        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        final ReboxingPost reboxingPost = new ReboxingPost();
        reboxingPost.box_label = barcode;
        reboxingPost.user_id = user_id;
        reboxingPost.merchant_id = merchant_id;

        final Dialog dialog = new Dialog(ReboxingPage.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        compositeDisposable.add(mIRetrofitApi.reboxing(token, reboxingPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ReboxingResponse>() {
            @Override
            public void accept(ReboxingResponse response) throws Exception {
                if (response.status == 1){

                    rightTone.start();
                    checkBoxLabel = barcode;
                    mainList = response.data;

                    adapter.addItem(mainList,list);
                    //shareableListUpdate(list);

                    boxLabel.setText("Box Label : "+barcode);
                    reBoxBtn.setVisibility(View.VISIBLE);
                    scanItem.setVisibility(View.VISIBLE);
                    boxWeightLayout.setVisibility(View.VISIBLE);

                    boxHeight.setText(""+response.height);
                    boxWeight.setText(""+response.weight);
                    boxWidth.setText(""+response.width);
                    boxLength.setText(""+response.length);

//                    boxHeight.setEnabled(false);
//                    boxWidth.setEnabled(false);
//                    boxLength.setEnabled(false);

                    dialog.dismiss();

                    Utils.snackbarToast(rootlayout,response.message);
                }else {
                    wrongTone.start();
                    dialog.dismiss();
                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootlayout,ReboxingPage.this);
                    }else {
                        Utils.snackbarToast(rootlayout,response.message);
                    }
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                wrongTone.start();
                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 15000);
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootlayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        }));
    }



    @Override
    public void handleResult(final Result rawResult) {

        if (!TextUtils.isEmpty(rawResult.getText())){
            if (boxORitem == 1){
                if (rawResult.getText().length() == 8){
                    if (Utils.broadcastIntent(this,rootlayout)){
                        getboxItem(rawResult.getText());
                        scannerDialog.dismiss();
                        scannerView.stopCamera();
                        isCamreOpen = false;
                        boxORitem = 0;
                    }else {
                        wrongTone.start();

                        isCamreOpen = false;
                        boxORitem = 0;
                        scannerDialog.dismiss();
                        scannerView.stopCamera();
                        Utils.snackbarToast(rootlayout,"No internet connection!");
                    }
                }else {

                    wrongTone.start();

                    isCamreOpen = false;
                    boxORitem = 0;
                    scannerDialog.dismiss();
                    scannerView.stopCamera();
                    Utils.snackbarToast(rootlayout,"This is not Box Label!");
                }
            }else if (boxORitem == 2){
                getItem(rawResult.getText());
                scannerDialog.dismiss();
                scannerView.stopCamera();
                isCamreOpen = false;
                boxORitem = 0;
            }
        }else {

            wrongTone.start();

            Utils.snackbarToast(rootlayout,"Empty barcode!");
            scannerDialog.dismiss();
            scannerView.stopCamera();
        }



    }

    private void getItem(final String barcode){

        int x = 0, i = 0;

        for (final ReboxingResponse.Data item : mainList){
            i++;
            if (barcode.equalsIgnoreCase(item.barcode)){
                x = 1;

                final Dialog qtyDialog = new Dialog(this);
                qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                qtyDialog.getWindow().setLayout(width,height);
                qtyDialog.setCancelable(false);
                qtyDialog.show();

                final EditText qtyText = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);

                TextView d_avl_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);

                ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                String insPrimaryImage = Common.BASEURL_PICTURE + item.primary_image;

                if (item.variant_primary_image == null || item.variant_primary_image.equals("")) {
                    Glide.with(ReboxingPage.this)
                            .load(insPrimaryImage)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                } else {
                    String insVariantImage = Common.BASEURL_PICTURE + item.variant_primary_image;


                    Glide.with(ReboxingPage.this)
                            .load(insVariantImage)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                }


                if (item.variant_name == null || item.variant_name.equals("")) {
                    cardName.setText(item.product_name);
                } else {
                    cardName.setText(item.variant_name);
                }

                cardColor.setText("Color : " + item.color);
                cardSize.setText("Size : " + item.size);


                d_avl_qty.setText("Avl Qty : "+item.given_qty);
                qtyText.setText(""+item.given_qty);
                ok.setText("Remove");

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        qtyDialog.dismiss();
                    }
                });

                final int finalI = i;
                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!TextUtils.isEmpty(qtyText.getText())){
                            String newQuantity = qtyText.getText().toString();
                            int newQtyInt = Integer.parseInt(newQuantity);
                            if (newQtyInt <= item.given_qty && newQtyInt > 0){

                                if ((item.given_qty - newQtyInt) > 0){
                                    final BoxingItemSubModel subModel = new BoxingItemSubModel();
                                    subModel.barcode = item.barcode;
                                    subModel.sku_id = item.sku_id;
                                    subModel.qty = newQtyInt;
                                    list.add(subModel);


                                    ReboxingResponse.Data itemList = new ReboxingResponse.Data();

                                    itemList.PK_NO = item.PK_NO;
                                    itemList.primary_image = item.primary_image;
                                    itemList.variant_primary_image = item.variant_primary_image;
                                    itemList.color = item.color;
                                    itemList.mkt_id = item.mkt_id;
                                    itemList.size = item.size;
                                    itemList.sku_id = item.sku_id;
                                    itemList.variant_name = item.variant_name;
                                    itemList.product_name = item.product_name;
                                    itemList.given_qty = (item.given_qty - newQtyInt);
                                    itemList.barcode = barcode;

                                    mainList.set((finalI-1),itemList);
                                    shareableListUpdate(mainList,list);

                                    adapter.addItem(mainList,list);
                                }else {
                                    final BoxingItemSubModel subModel = new BoxingItemSubModel();
                                    subModel.barcode = item.barcode;
                                    subModel.sku_id = item.sku_id;
                                    subModel.qty = item.given_qty;
                                    list.add(subModel);

                                    mainList.remove((finalI-1));
                                    adapter.notifyItemRangeChanged(finalI,mainList.size());

                                    shareableListUpdate(mainList, list);

                                    adapter.addItem(mainList,list);

                                }

                                qtyDialog.dismiss();



                            }else {
                                qtyText.requestFocus();
                                Toast.makeText(ReboxingPage.this, "Enter less then or equal : "+item.given_qty, Toast.LENGTH_SHORT).show();

                            }
                        }else {
                            Toast.makeText(ReboxingPage.this, "Enter minimum 1 qty", Toast.LENGTH_SHORT).show();
                        }

                    }
                });

            }
        }

        if (x == 0){
            Utils.snackbarToast(rootlayout, "Product Not Found!");
        }

    }

    private void getBoxDimension() {
        dimensionTextList = new ArrayList<>();
        final String token = SharedPreperenceUtils.getToken(this);
        compositeDisposable.add(mIRetrofitApi.getBoxDimensionList(token).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<BoxWeightResponse>() {
            @Override
            public void accept(BoxWeightResponse response) throws Exception {
                if (response.status == 1){
                    boxWeightList = response.data;
                    dimensionTextList.add("Select box dimension");
                    for (int i = 0; i < boxWeightList.size(); i++){
                        dimensionTextList.add(boxWeightList.get(i).dimension_text);
                    }
                    spinnerAdapter = new ArrayAdapter<String>(ReboxingPage.this, android.R.layout.simple_expandable_list_item_1, dimensionTextList);
                    spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    weightSpinner.setAdapter(spinnerAdapter);
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (position != 0){
            boxHeight.setText(""+boxWeightList.get((position-1)).height);
            boxWidth.setText(""+boxWeightList.get((position-1)).width);
            boxLength.setText(""+boxWeightList.get((position-1)).length);
        }
//        else if (position == 0){
//            boxHeight.setText("");
//            boxWidth.setText("");
//            boxLength.setText("");
//            boxWeight.setText("");
//        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

}