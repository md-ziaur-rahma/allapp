package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class BoxDetailsItemPost {
    @SerializedName("user_id")
    public int user_id;

    @SerializedName("PK_NO")
    public int PK_NO;

    @SerializedName("is_merchant")
    public int is_merchant;
}
