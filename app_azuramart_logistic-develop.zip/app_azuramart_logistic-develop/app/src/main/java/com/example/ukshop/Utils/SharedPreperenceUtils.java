package com.example.ukshop.Utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreperenceUtils {

    private static final String mSharedName = "premo_prefs";
    public static final String TOKEN = "token";
    public static final String USER_ID = "user_id";
    public static final String USER_NAME = "user_name";
    public static final String USER_EMAIL = "user_email";
    public static final String USER_MOBILE = "user_mobile";
    public static final String USER_LOCATION = "user_location";
    public static final String ROLE_ID = "role_id";
    public static final String SOURCE_FLAG = "source_flag";
    public static final String MERCHANT_ID = "merchant_id";



    public static void saveShared(Context c, String type, String val) {
        SharedPreferences.Editor ed = c.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).edit();
        ed.putString(type, val);
        ed.commit();
    }

    public static void saveToken(Context c, String type, String val) {
        SharedPreferences.Editor edToken = c.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).edit();
        edToken.putString(type, val);
        edToken.commit();
    }


    public static void removeShared(Context c, String type) {
        SharedPreferences.Editor ed = c.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).edit();
        ed.remove(type);
        ed.commit();
    }

    public static String getToken(Context context){
        String value = context.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).getString(TOKEN,"");

        return value;
    }

    public static int getSourceFlag(Context context){
        String value = context.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).getString(SOURCE_FLAG,"");

        if (value.equals("")){
            value = "1";
        }

        return Integer.parseInt(value);
    }

    public static String getUserLocation(Context context){

        return context.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).getString(USER_LOCATION,"");
    }

    public static String getUserName(Context context){

        return context.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).getString(USER_NAME,"");
    }

    public static String getRoleId(Context context){
        return context.getSharedPreferences(mSharedName,Context.MODE_PRIVATE).getString(ROLE_ID,"");
    }

    public static String getUserEmail(Context context){
        return context.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).getString(USER_EMAIL,"");
    }

    public static String getUserMobile(Context context){
        return context.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).getString(USER_MOBILE,"");
    }

    public static String getUser(Context context){
        return context.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).getString(USER_ID,"");
    }

    public static String getMerchantId(Context context){
        return context.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).getString(MERCHANT_ID,"");
    }

    public static String getShared(Context c, String type) {
        return c.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).getString(type, "");
    }


    public static void clearUserData(Context c) {
        SharedPreferences.Editor ed = c.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).edit();
        //  ed.remove(TYPE_USER_LOGIN);

        ed.commit();

        SharedPreferences.Editor ed1 = c.getSharedPreferences(mSharedName, Context.MODE_PRIVATE).edit();
        ed1.clear();
        ed1.commit();
    }
}
