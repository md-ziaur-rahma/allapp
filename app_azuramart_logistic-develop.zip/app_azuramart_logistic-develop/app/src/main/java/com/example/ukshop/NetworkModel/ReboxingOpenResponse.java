package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class ReboxingOpenResponse extends ApiResponse{

    @SerializedName("data")
    public Data data;

    public static class Data {
        @SerializedName("is_air")
        public int is_air;
        @SerializedName("weight")
        public int weight;
        @SerializedName("height")
        public int height;
        @SerializedName("width")
        public int width;
        @SerializedName("length")
        public int length;
    }
}
