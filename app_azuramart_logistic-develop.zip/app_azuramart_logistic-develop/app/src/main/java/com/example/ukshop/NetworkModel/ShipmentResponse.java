package com.example.ukshop.NetworkModel;

public class ShipmentResponse extends ApiResponse{

}
