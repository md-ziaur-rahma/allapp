package com.example.ukshop.MerchantAdapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.ImageShowPage;
import com.example.ukshop.Adapters.StockCheckAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.StockCheckSearchResponse;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class MerchantStockCheckAdapter extends RecyclerView.Adapter<MerchantStockCheckAdapter.ViewHolder> {
    private List<StockCheckSearchResponse.Data> list;
    private final Activity context;
    private final int isShow;
    private CoordinatorLayout rootLayout;

    private final CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    List<VariantImageResponse.Data> variantImageList = new ArrayList<>();
    public MerchantStockCheckAdapter(List<StockCheckSearchResponse.Data> list, Activity context, int isShow, CoordinatorLayout rootLayout) {
        this.list = list;
        this.context = context;
        this.isShow = isShow;
        this.rootLayout = rootLayout;
    }
    @NonNull
    @Override
    public MerchantStockCheckAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.stock_check_layout_2,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MerchantStockCheckAdapter.ViewHolder holder, int position) {
        int PK_NO = list.get(position).PK_NO;
        String imageUrl = list.get(position).variant_primary_image;
        String primaryImage = list.get(position).primary_image;
        String skuId = list.get(position).sku_id;
        String barcode = list.get(position).barcode;
        String mktId = list.get(position).mkt_id;
        String name = list.get(position).product_name;
        String variantName = list.get(position).variant_name;
        String color = list.get(position).color;
        int isAir = list.get(position).is_air;
        int is_air_count = list.get(position).is_air_count;
        int is_sea_count = list.get(position).is_sea_count;
        String size = list.get(position).size;
        float price = list.get(position).price;
        float ins_price = list.get(position).ins_price;
        float sm_price = list.get(position).sm_price;
        float ss_price = list.get(position).ss_price;
        int qty = list.get(position).available_qty;

        holder.setData(PK_NO,skuId,barcode,mktId,name,variantName,imageUrl,primaryImage,
                color,isAir,is_air_count,is_sea_count, size,price,ins_price,sm_price,ss_price,qty,position);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void filteredItem(List<StockCheckSearchResponse.Data> filteredList){
        list = filteredList;
        notifyDataSetChanged();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void addItem(List<StockCheckSearchResponse.Data> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private final ImageView variant_iamge,seaIcon,airIcon;
        private final TextView name,skuId,barcode,ig_code,
                size,color,price,price2,qty,isAir,
                airQty, seaQty;
        private final Button bookBtn;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            variant_iamge = itemView.findViewById(R.id.stock_check_item_imageID);
            name = itemView.findViewById(R.id.stock_check_item_nameID);
            skuId = itemView.findViewById(R.id.stock_check_item_skuID);

            //skuId.setVisibility(View.GONE);

            barcode = itemView.findViewById(R.id.stock_check_item_barcodeID);
            ig_code = itemView.findViewById(R.id.stock_check_item_IGCODEID);
            size = itemView.findViewById(R.id.stock_check_item_sizeID);
            color = itemView.findViewById(R.id.stock_check_item_colorID);
            isAir = itemView.findViewById(R.id.stock_check_item_seaID);
            price = itemView.findViewById(R.id.stock_check_item_priceID);
            price2 = itemView.findViewById(R.id.stock_check_item_price2ID);
            qty = itemView.findViewById(R.id.stock_check_item_qntID);

            airIcon = itemView.findViewById(R.id.stock_check_item_airIconID);
            seaIcon = itemView.findViewById(R.id.stock_check_item_seaIconID);
            airQty = itemView.findViewById(R.id.stock_check_item_airQtyID);
            seaQty = itemView.findViewById(R.id.stock_check_item_seaQtyID);


            bookBtn = itemView.findViewById(R.id.stock_check_item_buttonID);

        }

        public void setData(final int pk_id,final String sku,final String barcode, final String mktid, final String name, final String variant_Name, String imageUrl,
                            String primary_iamge, final String color,final int isAir, final int is_air_count,final int is_sea_count, final String size, final float price, final float ins_price,final float sm_price, final float ss_price,final int quantity,
                            int position){

            String bookImage = "";

            primary_iamge = Common.BASEURL_PICTURE + primary_iamge;

            if (imageUrl == null || imageUrl.equals("")){
                bookImage = primary_iamge;
                Glide.with(context)
                        .load(primary_iamge)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_iamge);
            }else {
                imageUrl = Common.BASEURL_PICTURE + imageUrl;

                bookImage = imageUrl;

                Glide.with(context)
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_iamge);
            }

            if (variant_Name == null || variant_Name == ""){
                this.name.setText(name);
            }else {
                this.name.setText(variant_Name);
            }

            skuId.setText("SKU : "+sku);
            this.barcode.setText("Barcode : "+barcode);
            ig_code.setText("IG CODE : "+mktid);
            this.color.setText("Color : "+color);

            this.airIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#4F1B35")));
            this.seaIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#4F1B35")));
            airQty.setText("("+is_air_count+")");
            seaQty.setText("("+is_sea_count+")");

            if (isAir == 1){
                this.airIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#35cce3")));
            }else {
                this.seaIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#35cce3")));
            }

            this.size.setText("Size : "+size);

            NumberFormat formatter = new DecimalFormat("#0.00");

            this.price.setText("GBP "+formatter.format(price)+"  / RM  "+formatter.format(ins_price));
            this.price2.setText("SM "+formatter.format(sm_price)+"  / SS "+formatter.format(ss_price));

            this.qty.setText("Qty : "+quantity);

            if (isShow == 2){
                this.bookBtn.setVisibility(View.GONE);
            }else if (isShow == 3){
                this.qty.setVisibility(View.GONE);
                this.bookBtn.setVisibility(View.GONE);
            }

            itemView.setOnClickListener(v -> {

            });

            bookBtn.setOnClickListener(v -> {

            });


            variant_iamge.setOnClickListener(v -> {
                mIRetrofitApi = Common.getApiArobil();
                String token = SharedPreperenceUtils.getToken(context);

                Log.e("tag","image-request : "+pk_id);

                compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
                    if (response.status == 1){
                        variantImageList = response.data;
                        ImageShowPage.variantImageList = variantImageList;
                        Intent intent = new Intent(context, ImageShowPage.class);
                        itemView.getContext().startActivity(intent);

                    }
                }, throwable -> {

                }));
            });

        }

    }
}
