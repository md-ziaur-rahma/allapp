package com.example.ukshop.Adapters;

import android.app.Activity;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.Models.NewPurchaseItemModel;
import com.example.ukshop.R;

import java.util.List;

public class NewPurchaseItemAdapter extends RecyclerView.Adapter<NewPurchaseItemAdapter.ViewHolder> {

    private List<NewPurchaseItemModel> list;
    private Activity context;

    public NewPurchaseItemAdapter(List<NewPurchaseItemModel> list, Activity context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public NewPurchaseItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.booking_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewPurchaseItemAdapter.ViewHolder holder, int position) {

        Bitmap image = list.get(position).getProductImage();
        String code = list.get(position).getBarcode();
        String price = list.get(position).getProductPrice();
        String qnt = list.get(position).getProductQnt();
        String date = list.get(position).getDate();

        holder.setData(image,code,price,qnt,date,position);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void newList(List<NewPurchaseItemModel> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private ImageView image;
        private TextView code, name,brand,size,price,qnt, date;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.bookingItemImageID);
            code = itemView.findViewById(R.id.bookingItemCodeID);
            name = itemView.findViewById(R.id.bookingItemNameID);
            brand = itemView.findViewById(R.id.bookingItemBrandId);
            size = itemView.findViewById(R.id.bookingItemSizeID);
            price = itemView.findViewById(R.id.bookingItemPriceID);
            qnt = itemView.findViewById(R.id.bookingItemQuantityID);
            date = itemView.findViewById(R.id.bookingItemDateID);
        }

        public void setData(Bitmap img, String cd,String pric,String qnty,String date, int position){
            image.setImageBitmap(img);
            code.setText("Barcode : "+cd);

            name.setVisibility(View.GONE);
            brand.setVisibility(View.GONE);
            size.setVisibility(View.GONE);

            price.setText("$"+pric);
            qnt.setText("Qnt : "+qnty);
            this.date.setText(date);
        }
    }
}
