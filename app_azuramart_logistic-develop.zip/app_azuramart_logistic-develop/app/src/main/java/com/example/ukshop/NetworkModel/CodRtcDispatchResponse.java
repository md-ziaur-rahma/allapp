package com.example.ukshop.NetworkModel;

public class CodRtcDispatchResponse extends ApiResponse{
}
