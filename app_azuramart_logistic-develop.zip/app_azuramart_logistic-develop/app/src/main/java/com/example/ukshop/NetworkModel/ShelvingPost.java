package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ShelvingPost {
    @SerializedName("is_update")
    public int is_update;
    @SerializedName("user_id")
    public int user_id;
    @SerializedName("shelve_label")
    public String shelve_label;
    @SerializedName("data")
    public List<ShelvingItemSubModel> data;
}
