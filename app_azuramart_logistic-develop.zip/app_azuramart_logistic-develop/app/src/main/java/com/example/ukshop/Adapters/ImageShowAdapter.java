package com.example.ukshop.Adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
//import com.jsibbold.zoomage.ZoomageView;

import java.util.List;

public class ImageShowAdapter extends PagerAdapter {

    private List<VariantImageResponse.Data> variantImageList;
    private int tabCount;
    private Activity context;

    public ImageShowAdapter(List<VariantImageResponse.Data> variantImageList, int tabCount, Activity context) {
        this.variantImageList = variantImageList;
        this.tabCount = tabCount;
        this.context = context;
    }

    @Override
    public int getCount() {
        return tabCount;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View)object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view = LayoutInflater.from(container.getContext())
                .inflate(R.layout.image_show_image_layout,container,false);

        //ImageView image = view.findViewById(R.id.imageShowImageId);

        ImageView zoomageView = view.findViewById(R.id.imageShowImageId);

        String urlImage = Common.BASEURL_PICTURE+variantImageList.get(position).mp_image;

        Glide.with(context)
                .load(urlImage)
                .placeholder(R.drawable.ic_default)
                .into(zoomageView);

        container.addView(view,0);

        return view;
    }

}
