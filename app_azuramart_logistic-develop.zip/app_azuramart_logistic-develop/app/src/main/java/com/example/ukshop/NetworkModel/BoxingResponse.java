package com.example.ukshop.NetworkModel;

public class BoxingResponse extends ApiResponse {

}
