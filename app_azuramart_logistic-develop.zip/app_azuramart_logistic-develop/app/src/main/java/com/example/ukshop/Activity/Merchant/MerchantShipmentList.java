package com.example.ukshop.Activity.Merchant;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.view.WindowManager;

import com.example.ukshop.Adapters.ShipmentInprogressItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ShipmentInprogressPost;
import com.example.ukshop.NetworkModel.ShipmentInprogressResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

public class MerchantShipmentList extends AppCompatActivity {
    private List<ShipmentInprogressResponse.Data> mainList = new ArrayList<>();
    private ShipmentInprogressItemAdapter adapter;
    private RecyclerView recyclerView;

    private final CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchant_shipment_list);
        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new ShipmentInprogressItemAdapter(mainList, MerchantShipmentList.this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        loadBShipmentList();

        toolbar.setNavigationOnClickListener(v -> finish());
    }
    private void initialFindFields(){
        rootLayout = findViewById(R.id.merchantShipmentInProgressRootLayoutID);
        toolbar = findViewById(R.id.merchantShipmentInprogressToolbarID);
        recyclerView = findViewById(R.id.merchantShipmentInprogressRecyclerID);
    }

    private void loadBShipmentList(){

        if (Utils.broadcastIntent(this,rootLayout)){

            mainList = new ArrayList<>();
            adapter.updateList(mainList);

            String token = SharedPreperenceUtils.getToken(this);
            int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

            final Dialog dialog = new Dialog(MerchantShipmentList.this);
            dialog.setContentView(R.layout.transparent_progress_dialoge);

            int width = WindowManager.LayoutParams.WRAP_CONTENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width, height);
            dialog.setCancelable(false);
            dialog.show();

            final ShipmentInprogressPost post = new ShipmentInprogressPost();
            post.user_id = user_id;

            compositeDisposable.add(mIRetrofitApi.getMerchantShipmentList(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {

                if (response.status == 1){
                    mainList = response.data;
                    adapter.updateList(mainList);
                    dialog.dismiss();
                }else {
                    dialog.dismiss();
                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout, MerchantShipmentList.this);
                    } else {
                        Snackbar snackbar = Snackbar.make(rootLayout,""+response.message,Snackbar.LENGTH_LONG);
                        snackbar.setAction("Retry", v -> loadBShipmentList());
                        snackbar.show();
                    }
                }
            }, throwable -> {
                dialog.dismiss();

                if (Objects.requireNonNull(throwable.getMessage()).toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.setAction("Retry", v -> loadBShipmentList());
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.setAction("Retry", v -> loadBShipmentList());
                    snackbar.show();
                }
            }));

        }else {
            NoInternetSnackBar();
        }


    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
        snackbar.setAction("Retry", v -> {
            if (Utils.broadcastIntent(MerchantShipmentList.this,rootLayout)){
                loadBShipmentList();
            }else {
                NoInternetSnackBar();
            }
        });

        snackbar.show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }
}