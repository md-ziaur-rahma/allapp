package com.example.ukshop.Models;

public class ProductListViewPagerModel {
    private int image;

    public ProductListViewPagerModel(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
