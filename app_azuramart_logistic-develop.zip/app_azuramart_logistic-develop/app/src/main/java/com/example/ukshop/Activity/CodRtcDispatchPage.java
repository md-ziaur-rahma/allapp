package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.ukshop.Adapters.CodRtcDispatchItemAdapter;
import com.example.ukshop.Adapters.OrderListAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.CodRtcDispatchItemPost;
import com.example.ukshop.NetworkModel.CodRtcDispatchItemResponse;
import com.example.ukshop.NetworkModel.CodRtcDispatchPost;
import com.example.ukshop.NetworkModel.CodRtcDispatchResponse;
import com.example.ukshop.NetworkModel.CodRtcDispatchSubModel;
import com.example.ukshop.NetworkModel.ConsignmentListPost;
import com.example.ukshop.NetworkModel.DispatchItemSubModel;
import com.example.ukshop.NetworkModel.DispatchResponse;
import com.example.ukshop.NetworkModel.MasterProductResponse;
import com.example.ukshop.NetworkModel.OrderListResponse;
import com.example.ukshop.NetworkModel.RtsDispatchConsignmentItemResponse;
import com.example.ukshop.NetworkModel.RtsDispatchPost;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class CodRtcDispatchPage extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private ExtendedFloatingActionButton dispatchBtn;

    private TextView totalAmount,paidAmount,dueAmount,dueCurrentText;
    private TextView orderNoText,customerName;
    private Button getMoneyBtn;
    private EditText chooseDateEditText,collectedByEditText;
    private TextView slipNo;
    private LinearLayout paidTextLayout,dueAmountLayout;
    private LinearLayout scanProductBtn,scanProductBtnLayout;

    private RecyclerView recyclerView;
    private List<CodRtcDispatchItemResponse.Data> list = new ArrayList<>();
    private CodRtcDispatchItemAdapter adapter;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    public static int orderNo = 0;
    public static String c_name = "",c_mobile = "";
    private float dueAmountInt = 0, totalAmountInt;
    private String collectDate = "";
    private String collectedBy = "";
    private Date passableDate;
    private Calendar mCalendar;
    private int day,month,year;

    private int countProduct = 0;
    private int totalCountProduct = 0;


    //..............................................................
    private Dialog scannerDialog;
    private ZXingScannerView scannerView;
    private final int CAMERA_PERMISSION_CODE = 501;

    private static boolean isFlash = false;
    private static boolean isCamreOpen = false;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();
    private int isTone = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cod_rts_dispatch_page);

        rightTone = MediaPlayer.create(this, R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this, R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        orderNoText.setText("Order Id : "+orderNo);
        dueCurrentText.setText("Due");
        customerName.setText(c_name);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new CodRtcDispatchItemAdapter(list,rootLayout,this);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        if (Utils.broadcastIntent(this,rootLayout)){
            loadData(orderNo);
        }else {
            Utils.snackbarToast(rootLayout,"No Internet Connection!");
        }

        scanProductBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(CodRtcDispatchPage.this)) {
                    isTone = 1;
                    openScanner();
                } else {
                    ActivityCompat.requestPermissions(CodRtcDispatchPage.this,
                            new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
                }
            }
        });

        scanProductBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                isTone = 0;
                final Dialog dialog = new Dialog(CodRtcDispatchPage.this,R.style.fadeDialog);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);

                barcodeText.setInputType(InputType.TYPE_CLASS_TEXT);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){
                            if (Utils.broadcastIntent(CodRtcDispatchPage.this,rootLayout)){
                                checkProduct(barcode);
                                dialog.dismiss();
                            }else {
                                dialog.dismiss();
                                Utils.snackbarToast(rootLayout,"No internet connection!");
                            }
                        }else {
                            Toast.makeText(CodRtcDispatchPage.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });
                return false;
            }
        });

        getMoneyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog getMoneyDialog = new Dialog(CodRtcDispatchPage.this,R.style.fadeDialog);
                getMoneyDialog.setContentView(R.layout.get_money_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                getMoneyDialog.getWindow().setLayout(width, height);
                getMoneyDialog.setCancelable(true);
                getMoneyDialog.show();

                final EditText money = getMoneyDialog.findViewById(R.id.getMoneyDialogAmountTextID);
                Button cancel = getMoneyDialog.findViewById(R.id.getMoneyDialogCancelID);
                Button ok = getMoneyDialog.findViewById(R.id.getMoneyDialogAddDialogBtnID);
                TextView msg = getMoneyDialog.findViewById(R.id.getMoneyDialogShowMoneyID);

                msg.setText("Due Amount - RM "+dueAmountInt);
                money.setText(""+dueAmountInt);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getMoneyDialog.dismiss();
                    }
                });

                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String moneyText = money.getText().toString();
                        float moneyInt = Float.parseFloat(moneyText);

                        if (!TextUtils.isEmpty(moneyText)){
                            if (moneyInt == dueAmountInt){
                                getMoneyBtn.setVisibility(View.GONE);
                                paidTextLayout.setVisibility(View.VISIBLE);
                                dueAmountInt = 0;
                                dueAmount.setBackgroundColor(Color.parseColor("#008000"));
                                dueAmount.setTextColor(ColorStateList.valueOf(Color.parseColor("#ffffff")));
                                //dueAmount.setText("0");
                                dueCurrentText.setText("Current Paid Amount");
                                //paidAmount.setText("RM "+totalAmountInt);
                                getMoneyDialog.dismiss();
                            }else {
                                Toast.makeText(CodRtcDispatchPage.this, "Pay "+dueAmountInt, Toast.LENGTH_LONG).show();
                            }
                        }else {
                            Toast.makeText(CodRtcDispatchPage.this, "Enter due amount", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });

        dispatchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<CodRtcDispatchSubModel> subList = new ArrayList<>();

                for (CodRtcDispatchItemResponse.Data item : list){
                    if (item.isChecked){
                        final CodRtcDispatchSubModel subModel = new CodRtcDispatchSubModel();
                        subModel.PK_NO = item.PK_NO;
                        subModel.barcode = item.barcode;
                        subModel.qty = item.qty;
                        subModel.sku_id = item.sku_id;

                        subList.add(subModel);
                    }
                }

                if (countProduct < totalCountProduct){
                    Toast.makeText(CodRtcDispatchPage.this, "Scan and confirm all product!", Toast.LENGTH_LONG).show();
                }else if (countProduct == totalCountProduct){
                    if (dueAmountInt == 0){

                        if (!TextUtils.isEmpty(collectedByEditText.getText().toString())){
                            collectedBy = collectedByEditText.getText().toString();
                        }else {
                            collectedBy = "";
                        }

                        String token = SharedPreperenceUtils.getToken(CodRtcDispatchPage.this);
                        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(CodRtcDispatchPage.this));

                        final CodRtcDispatchPost post = new CodRtcDispatchPost();
                        post.order_id = orderNo;
                        post.user_id = user_id;
                        post.collect_date = collectDate;
                        post.collected_by = collectedBy;
                        post.data = subList;

                        Log.e("cod dispatch post", "msg"+new Gson().toJson(post));

                        final Dialog dialog = new Dialog(CodRtcDispatchPage.this);
                        dialog.setContentView(R.layout.transparent_progress_dialoge);

                        int width = WindowManager.LayoutParams.WRAP_CONTENT;
                        int height = WindowManager.LayoutParams.WRAP_CONTENT;

                        dialog.getWindow().setLayout(width,height);
                        dialog.setCancelable(false);
                        dialog.show();

                        compositeDisposable.add(mIRetrofitApi.codRtcDispatch(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<CodRtcDispatchResponse>() {
                            @Override
                            public void accept(CodRtcDispatchResponse response) throws Exception {
                                if (response.status == 1){
                                    dialog.dismiss();
                                    inVisibleBtn();
                                    totalAmount.setText("0");
                                    paidAmount.setText("0");
                                    dueAmount.setText("0");
                                    slipNo.setText("------------");
                                    customerName.setText("------------");
                                    orderNoText.setText("------------");
                                    Utils.snackbarToast(rootLayout,""+response.message);
                                    new Handler().postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            finish();
                                        }
                                    },1500);
                                }else {
                                    dialog.dismiss();

                                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                        Utils.expiredTokenAlert(rootLayout, CodRtcDispatchPage.this);
                                    }else {
                                        Utils.snackbarToast(rootLayout,response.message);
                                    }
                                }
                            }
                        }, new Consumer<Throwable>() {
                            @Override
                            public void accept(Throwable throwable) throws Exception {
                                dialog.dismiss();
                                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                                    snackbar.show();
                                }else {
                                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                                    snackbar.show();
                                }
                            }
                        }));
                    }else {
                        Toast.makeText(CodRtcDispatchPage.this, "Collect Payment!", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });


/// this code for choose date...
        Date d = Calendar.getInstance().getTime();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        final String todaysFormattedDate = sdf.format(d);
        chooseDateEditText.setText(todaysFormattedDate);
        collectDate = todaysFormattedDate;
        passableDate = d;

        mCalendar = Calendar.getInstance();
        day = mCalendar.get(Calendar.DAY_OF_MONTH);
        year = mCalendar.get(Calendar.YEAR);
        month = mCalendar.get(Calendar.MONTH);
        chooseDateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar mCurrentDate = Calendar.getInstance();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
                try {
                    mCurrentDate.setTime(sdf.parse(chooseDateEditText.getText().toString()));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                year = mCurrentDate.get(Calendar.YEAR);
                month = mCurrentDate.get(Calendar.MONTH);
                day = mCurrentDate.get(Calendar.DAY_OF_MONTH);
                DateDialog();
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

//        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
//            @Override
//            public boolean onMenuItemClick(MenuItem item) {
//
//                int id = item.getItemId();
//                if (id == R.id.menuShipment_refreshId){
//                    return true;
//                }
//
//                return false;
//            }
//        });

    }

    private void DateDialog() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(0);
                cal.set(year,month,dayOfMonth);

                Date chooseDate = cal.getTime();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                String selectDate = sdf.format(chooseDate);
                collectDate = selectDate;
                passableDate = chooseDate;
                chooseDateEditText.setText(""+selectDate);
            }
        };

        DatePickerDialog dialog = new DatePickerDialog(this,dateSetListener,year,month,day);
        dialog.show();
    }

    private void inVisibleBtn() {
        dispatchBtn.setText("dispatch(0)");
        dispatchBtn.setVisibility(View.GONE);
        scanProductBtnLayout.setVisibility(View.GONE);
        list = new ArrayList<>();
        adapter.updateList(list);
        countProduct = 0;
        totalCountProduct = 0;
        collectDate = "";
    }

    private void visibleBtns(){
        dispatchBtn.setVisibility(View.VISIBLE);
        scanProductBtnLayout.setVisibility(View.VISIBLE);
    }

    private void initialFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.codRtcDispatchPageRootLayoutID);
        toolbar = (MaterialToolbar) findViewById(R.id.codRtcDispatchPageToolbarID);
        dispatchBtn = (ExtendedFloatingActionButton) findViewById(R.id.codRtcDispatchPageDispatchFabBtn);
        totalAmount = (TextView) findViewById(R.id.codRtcDispatchPageTotalAmountID);
        paidAmount = (TextView)findViewById(R.id.codRtcDispatchPagePaidAmountID);
        dueAmount = (TextView)findViewById(R.id.codRtcDispatchPageDueAmountID);
        orderNoText = (TextView)findViewById(R.id.codRtcDispatchPageOrderNoID);
        customerName = (TextView)findViewById(R.id.codRtcDispatchPageCustomerNameID);
        getMoneyBtn = (Button) findViewById(R.id.codRtcDispatchPageGetMoneyID);
        slipNo = (TextView)findViewById(R.id.codRtcDispatchPageSlipNoID);
        chooseDateEditText = (EditText)findViewById(R.id.codRtcDispatchPageChooseDateID);
        collectedByEditText = (EditText)findViewById(R.id.codRtcDispatchPageCollectedByID);
        paidTextLayout = (LinearLayout) findViewById(R.id.codRtcDispatchPagePaidLayoutID);
        dueCurrentText = (TextView)findViewById(R.id.codRtcDispatchPageDueAmountTexxtID);
        dueAmountLayout = (LinearLayout)findViewById(R.id.codRtcDispatchPageDueAmountLayoutID);
        recyclerView = (RecyclerView) findViewById(R.id.codRtcDispatchPageRecyclerID);
        scanProductBtn = (LinearLayout)findViewById(R.id.scan_productIconBtnID);
        scanProductBtnLayout = (LinearLayout)findViewById(R.id.codRtcDispatchPageScanProductLayoutID);
    }


    public void loadData(final int orderNof){
        inVisibleBtn();
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        final CodRtcDispatchItemPost post = new CodRtcDispatchItemPost();
        post.order_id = orderNof;
        post.user_id = user_id;

        Log.e("cod dispatch item post", "msg"+new Gson().toJson(post));

        final Dialog dialog = new Dialog(CodRtcDispatchPage.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        compositeDisposable.add(mIRetrofitApi.codRtcDispatchItem(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<CodRtcDispatchItemResponse>() {
            @Override
            public void accept(CodRtcDispatchItemResponse response) throws Exception {
                if (response.status == 1){
                    list = response.data;
                    orderNo = orderNof;
                    dueAmountInt = response.due_amount;
                    totalAmountInt = response.total_amount;
                    adapter.updateList(list);

                    visibleBtns();

                    totalAmount.setText("RM "+response.total_amount);
                    paidAmount.setText("RM "+response.paid_amount);
                    dueAmount.setText("RM "+response.due_amount);
                    slipNo.setText("Slip No : "+response.slip_no);

                    if (response.due_amount == 0){
                        dueAmount.setBackgroundColor(Color.parseColor("#ffffff"));
                        dueAmount.setTextColor(ColorStateList.valueOf(Color.parseColor("#000000")));
                        getMoneyBtn.setVisibility(View.GONE);
                        paidTextLayout.setVisibility(View.VISIBLE);
                    }else {
                        dueAmount.setBackgroundColor(Color.parseColor("#da0000"));
                        dueAmount.setTextColor(Color.parseColor("#ffffff"));
                        getMoneyBtn.setVisibility(View.VISIBLE);
                        paidTextLayout.setVisibility(View.GONE);
                    }

                    for (CodRtcDispatchItemResponse.Data item : list){
                        totalCountProduct += item.qty;
                    }

                    dispatchBtn.setText("Dispatch ("+countProduct+"/"+totalCountProduct);

                    dialog.dismiss();
                }else {
                    dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout, CodRtcDispatchPage.this);
                    }else {
                        Utils.snackbarToast(rootLayout,response.message);
                    }
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        }));
    }

    private void openScanner() {
        scannerDialog = new Dialog(CodRtcDispatchPage.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width, height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


        isCamreOpen = true;
        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(CodRtcDispatchPage.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                isCamreOpen = false;
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash) {
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                } else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.length >= 0) {
                openScanner();
            } else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null) {
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()) {
            compositeDisposable.dispose();
        }

    }

    @Override
    public void handleResult(Result rawResult) {
        if (!TextUtils.isEmpty(rawResult.getText())){
            checkProduct(rawResult.getText());
            scannerDialog.dismiss();
            scannerView.stopCamera();
        }else {
            wrongTone.start();
            scannerDialog.dismiss();
            scannerView.stopCamera();
            Utils.snackbarToast(rootLayout, "Empty barcode!");
        }
    }

    private void checkProduct(final String barcode){
        int m = 0;
        for (int i = 0; i < list.size(); i++){
            if (list.get(i).barcode.equals(barcode) && list.get(i).acknowledge == 1){

                if (isTone == 1){
                    rightTone.start();
                    isTone = 0;
                }

                m = 1;

                final Dialog qtyDialog = new Dialog(CodRtcDispatchPage.this,R.style.fadeDialog);
                qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                qtyDialog.getWindow().setLayout(width,height);
                qtyDialog.setCancelable(false);
                qtyDialog.show();

                final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                TextView msg = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);

                ok.setText("Confirm");

                ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                String insPrimaryImage = Common.BASEURL_PICTURE + list.get(i).primary_image;

                if (list.get(i).variant_primary_image == null || list.get(i).variant_primary_image.equals("")) {
                    Glide.with(CodRtcDispatchPage.this)
                            .load(insPrimaryImage)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                } else {
                    String insVariantImage = Common.BASEURL_PICTURE + list.get(i).variant_primary_image;


                    Glide.with(CodRtcDispatchPage.this)
                            .load(insVariantImage)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                }


                if (list.get(i).variant_name == null || list.get(i).variant_name.equals("")) {
                    cardName.setText(list.get(i).product_name);
                } else {
                    cardName.setText(list.get(i).variant_name);
                }

                cardColor.setText("Color : " + list.get(i).color);
                cardSize.setText("Size : " + list.get(i).size);


                msg.setText("Avl Qty : "+list.get(i).qty);
                qty.setText(""+list.get(i).qty);
                qty.setEnabled(false);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        qtyDialog.dismiss();
                    }
                });

                final int finalI = i;
                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (!list.get(finalI).isChecked){
                            countProduct += list.get(finalI).qty;
                        }

                        dispatchBtn.setText("Dispatch ("+countProduct+"/"+totalCountProduct+")");

                        final CodRtcDispatchItemResponse.Data item = new CodRtcDispatchItemResponse.Data();
                        item.PK_NO = list.get(finalI).PK_NO;
                        item.sku_id = list.get(finalI).sku_id;
                        item.barcode = list.get(finalI).barcode;
                        item.size = list.get(finalI).size;
                        item.color = list.get(finalI).color;
                        item.product_name = list.get(finalI).product_name;
                        item.variant_name = list.get(finalI).variant_name;
                        item.variant_primary_image = list.get(finalI).variant_primary_image;
                        item.primary_image = list.get(finalI).primary_image;
                        item.qty = list.get(finalI).qty;
                        item.available_qty = list.get(finalI).available_qty;
                        item.location = list.get(finalI).location;
                        item.label = list.get(finalI).label;
                        item.mkt_id = list.get(finalI).mkt_id;
                        item.is_my = list.get(finalI).is_my;
                        item.isChecked = true;
                        item.acknowledge = 1;

                        list.set(finalI,item);

                        adapter.updateList(list);

                        qtyDialog.dismiss();

                        return;
                    }
                });
            }
        }

        if(m == 0){
            if (isTone == 1){
                wrongTone.start();
                isTone = 0;
            }
            Utils.snackbarToast(rootLayout,"Doesn't match the product or not picked!");
        }
    }
}