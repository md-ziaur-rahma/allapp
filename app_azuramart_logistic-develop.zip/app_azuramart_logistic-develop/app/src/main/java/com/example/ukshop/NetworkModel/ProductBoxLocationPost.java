package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class ProductBoxLocationPost {
    @SerializedName("user_id")
    public int user_id;

    @SerializedName("sku_id")
    public String sku_id;

    @SerializedName("warehouse")
    public String warehouse;

    @SerializedName("merchant_id")
    public int merchant_id;
}
