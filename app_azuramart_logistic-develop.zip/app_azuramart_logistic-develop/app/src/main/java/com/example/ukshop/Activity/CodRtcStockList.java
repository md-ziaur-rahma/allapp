package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Adapters.CodRtcDispatchZoneAdapter;
import com.example.ukshop.Adapters.CodRtcStockListAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.CodRtcDispatchZonePost;
import com.example.ukshop.NetworkModel.CodRtcDispatchZoneResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class CodRtcStockList extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private RecyclerView recyclerView;
    private List<CodRtcDispatchZoneResponse.Data> mainList = new ArrayList<>();
    private CodRtcStockListAdapter adapter;

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private ExtendedFloatingActionButton productScanFavBtn;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private static final int CAMERA_REQUEST_CODE = 501;
    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static boolean isFlash = false;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();
    private int isTone = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cod_rtc_stock_list);

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new CodRtcStockListAdapter(mainList, this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        if (Utils.broadcastIntent(this,rootLayout)){
            loadData();
        }else {
            NoInternetSnackBar();
        }


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.menuShipment_refreshId){
                    if (Utils.isCameraPermission(CodRtcStockList.this)){
                        loadData();
                    }
                }
                return false;
            }
        });

        productScanFavBtn.hide();
        productScanFavBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(CodRtcStockList.this)){
                    isTone = 1;
                    //openScanner();
                }else {
                    ActivityCompat.requestPermissions(CodRtcStockList.this,new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST_CODE);
                }
            }
        });
    }


    private void initialFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.codRtcStockListRootLayoutID);
        toolbar = (MaterialToolbar) findViewById(R.id.codRtcStockListToolbarID);
        productScanFavBtn = (ExtendedFloatingActionButton)findViewById(R.id.codRtcStockListFabBtnID);
        recyclerView = (RecyclerView)findViewById(R.id.codRtcStockListRecyclerID);
    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",10000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(CodRtcStockList.this,rootLayout)){
                    loadData();
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    private void openScanner(){
        scannerDialog = new Dialog(CodRtcStockList.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);

        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(CodRtcStockList.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }

    @Override
    public void handleResult(final Result rawResult) {

        if (!TextUtils.isEmpty(rawResult.getText())){

            isTone = 1;
            checkProduct(rawResult.getText());
            scannerDialog.dismiss();
            scannerView.stopCamera();
        }else {

            wrongTone.start();

            scannerDialog.dismiss();
            scannerView.stopCamera();
        }
    }

    private void loadData() {

        mainList = new ArrayList<>();
        adapter.updateData(mainList);
        productScanFavBtn.hide();

        final Dialog dialog = new Dialog(CodRtcStockList.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        String token = SharedPreperenceUtils.getToken(CodRtcStockList.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(CodRtcStockList.this));

        final CodRtcDispatchZonePost post = new CodRtcDispatchZonePost();
        post.user_id = user_id;

        Log.e("cod dispatch zone post", "msg"+new Gson().toJson(post));

        compositeDisposable.add(mIRetrofitApi.getCodRtcDispatchZoneItem(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<CodRtcDispatchZoneResponse>() {
            @Override
            public void accept(CodRtcDispatchZoneResponse response) throws Exception {
                if (response.status == 1){
                    for (CodRtcDispatchZoneResponse.Data item : response.data){
                        if (item.is_acknowledge == 1){
                            mainList.add(item);
                        }
                    }
                    adapter.updateData(mainList);
                    //productScanFavBtn.show();

                    //todo use for direct Acknowledge...........
//                    if (!directAckBarcode.equals("")){
//                        checkProduct(directAckBarcode);
//                    }

                    dialog.dismiss();

                }else {
                    dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout, CodRtcStockList.this);
                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,response.message,10000);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (Utils.broadcastIntent(CodRtcStockList.this,rootLayout)){
                                    loadData();
                                }else {
                                    NoInternetSnackBar();
                                }
                            }
                        });

                        snackbar.show();
                    }
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        }));


    }

    private void checkProduct(String barcode){
        int m = 0;
        for (int i = 0; i < mainList.size(); i++){
            if (mainList.get(i).barcode.equals(barcode)){
                m = 1;
                if (isTone == 1){
                    rightTone.start();
                    isTone = 0;
                }
                final Dialog qtyDialog = new Dialog(CodRtcStockList.this);
                qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                qtyDialog.getWindow().setLayout(width,height);
                qtyDialog.setCancelable(false);
                qtyDialog.show();

                final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                TextView msg = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);

                ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                String insPrimaryImage = Common.BASEURL_PICTURE + mainList.get(i).primary_image;

                if (mainList.get(i).variant_primary_image == null || mainList.get(i).variant_primary_image.equals("")) {
                    Glide.with(CodRtcStockList.this)
                            .load(insPrimaryImage)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                } else {
                    String insVariantImage = Common.BASEURL_PICTURE + mainList.get(i).variant_primary_image;


                    Glide.with(CodRtcStockList.this)
                            .load(insVariantImage)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                }


                if (mainList.get(i).variant_name == null || mainList.get(i).variant_name.equals("")) {
                    cardName.setText(mainList.get(i).product_name);
                } else {
                    cardName.setText(mainList.get(i).variant_name);
                }

                cardColor.setText("Color : " + mainList.get(i).color);
                cardSize.setText("Size : " + mainList.get(i).size);


                msg.setText("Avl Qty : "+mainList.get(i).qty);
                if (mainList.get(i).is_acknowledge == 1){
                    msg.setText("Already Found Acknowledge");
                    ok.setText("Cancel Ack");
                }else {
                    msg.setText("Confirm Acknowledge");
                    ok.setText("Confirm");
                }
                qty.setText(""+mainList.get(i).qty);
                qty.setEnabled(false);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        qtyDialog.dismiss();
                    }
                });

                final int finalI = i;
                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //acknowledge(finalI);
                        qtyDialog.dismiss();
                        return;
                    }
                });
            }
        }

        if(m == 0){
            if (isTone == 1){
                wrongTone.start();
                isTone = 0;
            }
            Utils.snackbarToast(rootLayout,"Doesn't match the product or not picked!");
        }

    }
}