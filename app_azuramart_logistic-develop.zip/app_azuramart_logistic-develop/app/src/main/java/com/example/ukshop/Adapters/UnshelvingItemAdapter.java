package com.example.ukshop.Adapters;

import android.app.Activity;
import android.app.Dialog;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.SortingShelvingPage;
import com.example.ukshop.Activity.UnshelvePage;
import com.example.ukshop.NetworkModel.ShelveItemListResponse;
import com.example.ukshop.NetworkModel.ShelvingItemSubModel;
import com.example.ukshop.NetworkModel.ShelvingPostItemResponse;
import com.example.ukshop.NetworkModel.UnshelvingItemResponse;
import com.example.ukshop.NetworkModel.UnshelvingItemSubmodel;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;

import java.util.List;

public class UnshelvingItemAdapter extends RecyclerView.Adapter<UnshelvingItemAdapter.ViewHolder> {

    private List<ShelveItemListResponse.Data> mainList;
    private List<ShelvingItemSubModel> list;
    private Activity context;
    private CoordinatorLayout rootlayout;

    public UnshelvingItemAdapter(List<ShelveItemListResponse.Data> mainList, List<ShelvingItemSubModel> list, Activity context, CoordinatorLayout rootlayout) {
        this.mainList = mainList;
        this.list = list;
        this.context = context;
        this.rootlayout = rootlayout;
    }

    @NonNull
    @Override
    public UnshelvingItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.boxing_item_full_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UnshelvingItemAdapter.ViewHolder holder, int position) {

        String imageUrl = mainList.get(position).variant_primary_image;
        String primaryImage = mainList.get(position).primary_image;
        String skuId = mainList.get(position).sku_id;
        String mktId = mainList.get(position).mkt_id;
        String name = mainList.get(position).product_name;
        String vaiantName = mainList.get(position).variant_name;
        String color = mainList.get(position).color;
        String size = mainList.get(position).size;
        int qty = mainList.get(position).available_qty;

        holder.setData(qty,position,primaryImage,imageUrl,skuId,
                mktId,name,vaiantName,color,size);

    }

    @Override
    public int getItemCount() {
        return mainList.size();
    }

    public void addItem(List<ShelveItemListResponse.Data> newList, List<ShelvingItemSubModel> newList2){
        mainList = newList;
        list = newList2;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView qty,avl_qty;
        ImageView delete, edit;

        private ImageView variant_iamge;
        private TextView name,skuId,size,color;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            variant_iamge = itemView.findViewById(R.id.boxingl_item_imageID);
            name = itemView.findViewById(R.id.boxingl_item_nameID);
            skuId = itemView.findViewById(R.id.boxingl_item_skuID);
            size = itemView.findViewById(R.id.boxingl_item_sizeID);
            color = itemView.findViewById(R.id.boxingl_item_colorID);


            avl_qty = itemView.findViewById(R.id.boxingl_item_avl_qntID);
            qty = itemView.findViewById(R.id.boxingl_item_qntID);
            delete = itemView.findViewById(R.id.boxingl_item_deleteBtnID);
            edit = itemView.findViewById(R.id.boxingl_item_editBtnID);

        }

        public void setData(final int qty, final int position, final String primaryImage,
                            final String variantImage, final String sku, final String mkt, final String name, final String variantName,
                            final String color, final String size ) {

            String insPrimaryImage = Common.BASEURL_PICTURE + primaryImage;

            if (variantImage == null || variantImage == "") {
                Glide.with(context)
                        .load(insPrimaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_iamge);
            } else {
                String insVariantImage = Common.BASEURL_PICTURE + variantImage;


                Glide.with(context)
                        .load(insVariantImage)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_iamge);
            }


            if (variantName == null || variantName == "") {
                this.name.setText(name);
            } else {
                this.name.setText(variantName);
            }

            //this.skuId.setText("SKU : "+sku);
            this.skuId.setText("Barcode : " + list.get(position).barcode);
            this.color.setText("Color : " + color);
            this.size.setText("Size : " + size);

            this.qty.setText("Qty : " + list.get(position).qty);
            this.avl_qty.setText("Avl Qty : " + qty);

            UnshelvePage.updateList(1,list);

            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    final Dialog deleteDialoge = new Dialog(context,R.style.PauseDialog);
                    deleteDialoge.setContentView(R.layout.dialoge_exit);

                    int width = WindowManager.LayoutParams.MATCH_PARENT;
                    int height = WindowManager.LayoutParams.WRAP_CONTENT;

                    deleteDialoge.getWindow().setLayout(width,height);
                    deleteDialoge.setCancelable(true);
                    deleteDialoge.show();

                    Button cancel = deleteDialoge.findViewById(R.id.dialogeExitCancelID);
                    Button ok = deleteDialoge.findViewById(R.id.dialogeExitOkID);
                    TextView textMsg = deleteDialoge.findViewById(R.id.dialogeExitTextMsgID);

                    ok.setText("Delete");
                    textMsg.setText("Are you want to delete it?");

                    cancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            deleteDialoge.dismiss();
                        }
                    });

                    ok.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            list.remove(position);
                            mainList.remove(position);
                            notifyItemRangeChanged(position,list.size());
                            notifyItemRangeChanged(position,mainList.size());
                            notifyDataSetChanged();

                            if (list.size()==0){
                                UnshelvePage.updateList(2,list);
                            }else {
                                UnshelvePage.updateList(1,list);
                            }

                            deleteDialoge.dismiss();
                        }
                    });
                }
            });


            edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    int checkQty = 0;
                    if (list.size() > 0){

                        for (int i = 0; i <list.size(); i++){
                            if (sku.equals(list.get(i).sku_id)){
                                checkQty += list.get(i).qty;
                            }
                        }

                        checkQty = checkQty - list.get(position).qty;
                    }



                    final Dialog qtyDialog = new Dialog(context,R.style.PauseDialog);
                    qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                    int width = WindowManager.LayoutParams.MATCH_PARENT;
                    int height = WindowManager.LayoutParams.WRAP_CONTENT;

                    qtyDialog.getWindow().setLayout(width,height);
                    qtyDialog.setCancelable(false);
                    qtyDialog.show();

                    final EditText qtyText = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                    Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                    Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                    TextView d_avl_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);


                    ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                    TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                    TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                    TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                    String insPrimaryImage = Common.BASEURL_PICTURE + primaryImage;

                    if (variantImage == null || variantImage.equals("")) {
                        Glide.with(context)
                                .load(insPrimaryImage)
                                .placeholder(R.drawable.ic_default)
                                .into(cardImage);
                    } else {
                        String insVariantImage = Common.BASEURL_PICTURE + variantImage;


                        Glide.with(context)
                                .load(insVariantImage)
                                .placeholder(R.drawable.ic_default)
                                .into(cardImage);
                    }


                    if (variantName == null || variantName.equals("")) {
                        cardName.setText(name);
                    } else {
                        cardName.setText(variantName);
                    }

                    cardColor.setText("Color : " + color);
                    cardSize.setText("Size : " + size);


                    d_avl_qty.setText("Avl Qty : "+(qty-checkQty));
                    qtyText.setText(""+list.get(position).qty);
                    ok.setText("Update");


                    cancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            qtyDialog.dismiss();
                        }
                    });

                    final int finalCheckQty = checkQty;
                    ok.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            if (!TextUtils.isEmpty(qtyText.getText())){
                                String newQuantity = qtyText.getText().toString();
                                int newQtyInt = Integer.parseInt(newQuantity);



                                if (newQtyInt <= (qty - finalCheckQty)){

                                    if (newQtyInt == 0){
                                        newQtyInt = 1;
                                    }

                                    final ShelvingItemSubModel subModel = new ShelvingItemSubModel();
                                    subModel.barcode = list.get(position).barcode;
                                    subModel.sku_id = list.get(position).sku_id;
                                    subModel.qty = newQtyInt;
                                    list.set(position,subModel);

                                    if (list.size()==0){
                                        UnshelvePage.updateList(2,list);
                                    }else {
                                        UnshelvePage.updateList(1,list);
                                    }


                                    ShelveItemListResponse.Data itemList = new ShelveItemListResponse.Data();

                                    itemList.primary_image = primaryImage;
                                    itemList.variant_primary_image = variantImage;
                                    itemList.color = color;
                                    itemList.mkt_id = mkt;
                                    itemList.size = size;
                                    itemList.sku_id = sku;
                                    itemList.variant_name = variantName;
                                    itemList.product_name = name;
                                    itemList.available_qty = qty;

                                    mainList.set(position,itemList);
                                    notifyDataSetChanged();
                                    qtyDialog.dismiss();

                                }else {
                                    qtyText.requestFocus();
                                    Toast.makeText(context, "Enter less then or equal : "+qty, Toast.LENGTH_SHORT).show();

                                }
                            }else {
                                Toast.makeText(context, "Enter minimum 1 Qty", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

        }

    }
}
