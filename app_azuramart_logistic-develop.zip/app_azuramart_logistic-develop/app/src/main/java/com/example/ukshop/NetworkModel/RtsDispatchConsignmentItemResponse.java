package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class RtsDispatchConsignmentItemResponse extends ApiResponse{

    @SerializedName("description")
    public String description;

    @SerializedName("data")
    public ArrayList<Data> data;

    public static class Data{

        @SerializedName("PK_NO")
        public int PK_NO;

        @SerializedName("sku_id")
        public String sku_id;

        @SerializedName("mkt_id")
        public String mkt_id;

        @SerializedName("barcode")
        public String barcode;

        @SerializedName("product_name")
        public String product_name;

        @SerializedName("product_variant_name")
        public String variant_name;

        @SerializedName("size")
        public String size;

        @SerializedName("color")
        public String color;

        @SerializedName("variant_primary_image")
        public String variant_primary_image;

        @SerializedName("primary_image")
        public String primary_image;

        @SerializedName("qty")
        public int qty;

        @SerializedName("picked_qty")
        public int picked_qty;

        @SerializedName("isPicked")
        public int isPicked;

        @SerializedName("isChecked")
        public boolean isChecked;

        @SerializedName("label")
        public String label;

        @SerializedName("batch_no")
        public int batch_no;

        @SerializedName("order_id")
        public int order_id;

        @SerializedName("location")
        public String location;
    }
}
