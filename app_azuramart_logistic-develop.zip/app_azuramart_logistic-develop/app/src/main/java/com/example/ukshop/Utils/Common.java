package com.example.ukshop.Utils;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.WindowManager;

import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.Network.RetrofitClient;
import com.example.ukshop.R;

public abstract class Common {

    public static String BASE_URL_AROBIL = "https://admin.azuramart.com/api/";
    public static String BASEURL_PICTURE = "https://admin.azuramart.com";
    public static String BASE_POOR_MSG = "admin.azuramart.com";

//    public static String BASE_URL_AROBIL = "http://dev.ukshop.my/api/";
//    public static String BASEURL_PICTURE = "http://dev.ukshop.my";
//    public static String BASE_POOR_MSG = "dev.ukshop.my";

//    public static String BASE_URL_AROBIL = "http://118.179.179.232:8888/ukshop_beta_dev/public/api/";
//    public static String BASEURL_PICTURE = "http://118.179.179.232:8888/ukshop_beta_dev/public";
//    public static String BASE_POOR_MSG = "118.179.179.232:8888/ukshop_beta/public";

//    public static final String BASE_URL_AROBIL = "http://192.168.203.63/api/";
//    public static final String BASEURL_PICTURE = "http://192.168.203.63";
//    public static final String BASE_POOR_MSG = "192.168.203.63";

//    public static String BASE_URL_AROBIL = "";
//    public static String BASEURL_PICTURE = "";
//    public static String BASE_POOR_MSG = "";


//    public static final String public_BASE_URL_AROBIL = "https://admin.azuramart.com/api/";
//    public static final String public_BASEURL_PICTURE = "https://admin.azuramart.com";
//    public static final String public_BASE_POOR_MSG = "admin.azuramart.com";
//
//    //........................
//    public static final String beta_dev_BASE_URL_AROBIL = "http://118.179.179.232:8888/ukshop_beta_dev/public/api/";
//    public static final String beta_dev_BASEURL_PICTURE = "http://118.179.179.232:8888/ukshop_beta_dev/public";
//    public static final String beta_dev_BASE_POOR_MSG = "118.179.179.232:8888/ukshop_beta/public";
//
//
//
//    public static final String office_BASE_URL_AROBIL = "http://192.168.203.247/api/";
//    public static final String office_BASEURL_PICTURE = "http://192.168.203.247";
//    public static final String office_BASE_POOR_MSG = "192.168.203.247";


//    if(sourceFlag=LIVE){
//        BASE_URL_AROBIL = public_BASE_URL_AROBIL;
//        BASEURL_PICTURE = public_BASEURL_PICTURE;
//        BASE_POOR_MSG = public_BASE_POOR_MSG;
//    } else if(sourceFlag=TEST){
//
//        BASE_URL_AROBIL = beta_dev_BASE_URL_AROBIL;
//        BASEURL_PICTURE = beta_dev_BASEURL_PICTURE;
//        BASE_POOR_MSG = beta_dev_BASE_POOR_MSG;
//    }else if(sourceFlag=DEVELOPER){
//        BASE_URL_AROBIL = office_BASE_URL_AROBIL;
//        BASEURL_PICTURE = office_BASEURL_PICTURE;
//        BASE_POOR_MSG = office_BASE_POOR_MSG;
//    }

    public static int master_product_id = 0;
    public static String EXPIRED_TOKEN = "Trying by invalid token !";
    public static String POOR_MSG = "failed to connect to /"+BASE_POOR_MSG+" (port 80) after 7000ms";



    public static IRetrofitApi getApiArobil() {
        return RetrofitClient.getClient(BASE_URL_AROBIL).create(IRetrofitApi.class);
    }

    public static Dialog getDialog(final View view, final boolean cancelable, Context context){
        final Dialog dialog = new Dialog(context, R.style.PauseDialog);
        dialog.setContentView(view);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(cancelable);
        dialog.show();

        return dialog;
    }
}
