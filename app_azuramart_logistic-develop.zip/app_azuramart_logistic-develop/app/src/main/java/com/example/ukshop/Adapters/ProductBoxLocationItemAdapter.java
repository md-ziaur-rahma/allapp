package com.example.ukshop.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.Activity.BoxDetailsItem;
import com.example.ukshop.NetworkModel.ProductBoxLocationResponse;
import com.example.ukshop.R;

import java.util.List;

import static maes.tech.intentanim.CustomIntent.customType;

public class ProductBoxLocationItemAdapter extends RecyclerView.Adapter<ProductBoxLocationItemAdapter.ViewHolder> {

    private List<ProductBoxLocationResponse.Data> list;
    private Activity context;
    private CoordinatorLayout rootLayout;

    public ProductBoxLocationItemAdapter(List<ProductBoxLocationResponse.Data> list, Activity context, CoordinatorLayout rootLayout) {
        this.list = list;
        this.context = context;
        this.rootLayout = rootLayout;
    }

    @NonNull
    @Override
    public ProductBoxLocationItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.product_box_location_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductBoxLocationItemAdapter.ViewHolder holder, int position) {
        int pk_id = list.get(position).PK_NO;
        String boxLabel = list.get(position).box_label;
        String  warehouse = list.get(position).warehouse;
        int productCount = list.get(position).product_count;
        int boxStatus = list.get(position).status;


        holder.setData(pk_id,boxLabel,boxStatus,warehouse,productCount,position);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void updateList(List<ProductBoxLocationResponse.Data> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView boxLabel, boxStatus, warehouse, productCount;
        private ImageView greenCheck;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            greenCheck = itemView.findViewById(R.id.productBoxLocationGreenCheckID);
            boxLabel = itemView.findViewById(R.id.productBoxLocationLabelID);
            warehouse = itemView.findViewById(R.id.productBoxLocationWarehouseID);
            productCount = itemView.findViewById(R.id.productBoxLocationProductCountID);
            boxStatus = itemView.findViewById(R.id.productBoxLocationBoxstatusID);

        }

        public void setData(final int pk_id, String boxLabel,final int boxStatus, String wareHouse, int productcount,int position){

            this.boxLabel.setText("Box Label : "+boxLabel);
            this.productCount.setText("product Count : "+productcount);
            this.warehouse.setText(wareHouse);

//            if (boxStatus == 10){
//                greenCheck.setVisibility(View.GONE);
//                this.boxStatus.setText("Box Packaging In Progress");
//            }else if (boxStatus == 20) {
//                greenCheck.setVisibility(View.VISIBLE);
//                this.boxStatus.setText("Shipment Label Assigned");
//            }

            //........................................

            if (boxStatus == 0) {
                greenCheck.setVisibility(View.GONE);
                this.boxStatus.setText("Not Boxed");
            }else if (boxStatus == 10){
                greenCheck.setVisibility(View.GONE);
                this.boxStatus.setText("In Progress at Source (UK)");
            }else if (boxStatus == 20) {
                greenCheck.setVisibility(View.VISIBLE);
                this.boxStatus.setText("Packaging Complete (UK)");
            }else if (boxStatus == 30) {
                greenCheck.setVisibility(View.VISIBLE);
                this.boxStatus.setText("Assigned to Shipment (UK)");
            }else if (boxStatus == 40) {
                greenCheck.setVisibility(View.VISIBLE);
                this.boxStatus.setText("Arrived At Destination");
            }else if (boxStatus == 50) {
                greenCheck.setVisibility(View.VISIBLE);
                this.boxStatus.setText("Received At Destination (MY)");
            }else if (boxStatus == 60) {
                greenCheck.setVisibility(View.VISIBLE);
                this.boxStatus.setText("Unboxed Completely (MY)");
            }else if (boxStatus == 70) {
                greenCheck.setVisibility(View.VISIBLE);
                this.boxStatus.setText("Unpacked (MY)");
            }else if (boxStatus == 80) {
                greenCheck.setVisibility(View.VISIBLE);
                this.boxStatus.setText("Box Empty");
            }else if (boxStatus == 90) {
                greenCheck.setVisibility(View.VISIBLE);
                this.boxStatus.setText("Disposed");
            }else if (boxStatus == 100) {
                greenCheck.setVisibility(View.VISIBLE);
                this.boxStatus.setText("Life Cycle Complete");
            }


            //......................................

            itemView.setOnClickListener(v -> {
                Intent intent = new Intent(context, BoxDetailsItem.class);
                intent.putExtra("pk_id",pk_id);
                intent.putExtra("is_merchant",0);
                itemView.getContext().startActivity(intent);
                customType(context,"left-to-right");
            });
        }

    }
}
