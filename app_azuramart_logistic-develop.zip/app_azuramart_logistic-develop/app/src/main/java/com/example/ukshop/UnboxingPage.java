package com.example.ukshop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.PriorityUnboxList;
import com.example.ukshop.Activity.UnboxingBoxListPage;
import com.example.ukshop.Adapters.UnboxingItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.NetworkModel.ReboxingPost;
import com.example.ukshop.NetworkModel.ReboxingResponse;
import com.example.ukshop.NetworkModel.UnboxingItemResponse;
import com.example.ukshop.NetworkModel.UnboxingPost;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

import static maes.tech.intentanim.CustomIntent.customType;

public class UnboxingPage extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private CoordinatorLayout rootlayout;
    private MaterialToolbar toolbar;

    private RecyclerView recyclerView;
    private List<UnboxingItemResponse.Data> mainList = new ArrayList<>();
    private static List<UnboxingItemResponse.Data> listForScanProduct = new ArrayList<>();
    private UnboxingItemAdapter adapter;

    private Button productScanBtn;
    private LinearLayout boxScan;
    private TextView boxLabel;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;


    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static final int CAMERA_PERMISSION_CODE = 501;


    private static boolean isFlash = false;
    private static boolean isCamreOpen = false;
    private static int boxORitem = 0;

    public static String checkBoxlabel = null;

    private boolean isInvalid = false;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();
    private int isTone = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unboxing_page);

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        boxLabel.setText(getResources().getString(R.string.unboxing_box_label));

        productScanBtn.setText("Scan Product");
        productScanBtn.setVisibility(View.GONE);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new UnboxingItemAdapter(mainList,UnboxingPage.this,rootlayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        boxScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(UnboxingPage.this)){
                    boxORitem = 1;
                    isTone = 1;
                    openScanner();
                }else {
                    ActivityCompat.requestPermissions(UnboxingPage.this,new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
                }
            }
        });

        boxScan.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                isTone = 0;
                final Dialog dialog = new Dialog(UnboxingPage.this);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
                barcodeText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(8)});

                search.setText(R.string.ok);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){
                            if (barcode.length() == 8){

                                getBoxItem(barcode);

                                dialog.dismiss();

                            }else {
                                Toast.makeText(UnboxingPage.this,"This is not Box Label!",Toast.LENGTH_LONG).show();
                            }

                        }else {
                            Toast.makeText(UnboxingPage.this,"Please Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });

                return false;
            }
        });

        productScanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBoxlabel == null || checkBoxlabel.equals("")){
                    Utils.snackbarToast(rootlayout,"Scan Box Label First!");
                }else {
                    if (Utils.isCameraPermission(UnboxingPage.this)){
                        boxORitem = 2;
                        isTone = 1;
                        openScanner();
                    }else {
                        ActivityCompat.requestPermissions(UnboxingPage.this,new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
                    }
                }
            }
        });


        // ........................ toolbar code  ......................//

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.menuPriorityBoxId){
                    Intent intent = new Intent(UnboxingPage.this, PriorityUnboxList.class);
                    startActivity(intent);
                    customType(UnboxingPage.this,"left-to-right");
                    return true;
                }
                return false;
            }
        });


        // ........................ get box item when load the page  ......................//
         if (Utils.broadcastIntent(this,rootlayout)){
             getBoxItem(checkBoxlabel);
         }else {
             Utils.snackbarToast(rootlayout,"No internet connection!");
         }
        // ........................ get box item when load the page  ......................//


    }

    private void initialFindFields() {
        rootlayout = (CoordinatorLayout)findViewById(R.id.unboxingRootlayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.unboxingToolbarID);
        recyclerView = (RecyclerView)findViewById(R.id.unboxingRecyclerID);
        boxScan = (LinearLayout)findViewById(R.id.boxingBoxID);
        boxLabel = (TextView)findViewById(R.id.boxingBoxLebelID);
        productScanBtn = (Button)findViewById(R.id.boxingEndBoxBtnID);
    }


    public static void updateList(List<UnboxingItemResponse.Data> newList){
        listForScanProduct = newList;
    }

    private void openScanner(){
        scannerDialog = new Dialog(UnboxingPage.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


        isCamreOpen = true;
        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(UnboxingPage.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                isCamreOpen = false;
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }


    @Override
    protected void onStart() {
        super.onStart();
        mainList = new ArrayList<>();

        if (Utils.broadcastIntent(this,rootlayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootlayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootlayout,"No Internet Connection!",10000);
            snackbar.show();
        }
    }

    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mIRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ApiResponse>() {
            @Override
            public void accept(ApiResponse response) throws Exception {
                if (response.status == 0) {
                    isInvalid = true;
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));

        return isInvalid;
    }

    @Override
    public void onBackPressed() {
        mainList = new ArrayList<>();
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    @Override
    public void handleResult(final Result rawResult) {
        if (!TextUtils.isEmpty(rawResult.getText())){
            if (boxORitem == 1) {
                if (rawResult.getText().length() == 8){

                    mainList = new ArrayList<>();

                    adapter.updateRecyclerView(mainList, rawResult.getText());
                    productScanBtn.setVisibility(View.GONE);

                    checkBoxlabel = rawResult.getText();

                    String token = SharedPreperenceUtils.getToken(this);
                    int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

                    final ReboxingPost reboxingPost = new ReboxingPost();
                    reboxingPost.box_label = rawResult.getText();
                    reboxingPost.user_id = user_id;

                    final Dialog dialog = new Dialog(UnboxingPage.this);
                    dialog.setContentView(R.layout.transparent_progress_dialoge);

                    int width = WindowManager.LayoutParams.WRAP_CONTENT;
                    int height = WindowManager.LayoutParams.WRAP_CONTENT;

                    dialog.getWindow().setLayout(width, height);
                    dialog.setCancelable(false);
                    dialog.show();

                    compositeDisposable.add(mIRetrofitApi.unboxingList(token, reboxingPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ReboxingResponse>() {
                        @Override
                        public void accept(ReboxingResponse response) throws Exception {
                            if (response.status == 1) {

                                rightTone.start();

                                for (ReboxingResponse.Data item : response.data) {
                                    final UnboxingItemResponse.Data mainItem = new UnboxingItemResponse.Data();
                                    mainItem.PK_NO = item.PK_NO;
                                    mainItem.sku_id = item.sku_id;
                                    mainItem.mkt_id = item.mkt_id;
                                    mainItem.product_name = item.product_name;
                                    mainItem.variant_name = item.variant_name;
                                    mainItem.size = item.size;
                                    mainItem.color = item.color;
                                    mainItem.variant_primary_image = item.variant_primary_image;
                                    mainItem.primary_image = item.primary_image;
                                    mainItem.available_qty = item.available_qty;
                                    mainItem.given_qty = item.given_qty;
                                    mainItem.barcode = item.barcode;

                                    mainList.add(mainItem);
                                }

                                adapter.updateRecyclerView(mainList, rawResult.getText());
                                boxLabel.setText("Box Label : " + rawResult.getText());

                                if (mainList.size() > 0) {
                                    updateList(mainList);
                                    productScanBtn.setVisibility(View.VISIBLE);
                                }
                                isCamreOpen = false;
                                scannerDialog.dismiss();
                                scannerView.stopCamera();
                                dialog.dismiss();

                            } else {

                                wrongTone.start();

                                isCamreOpen = false;
                                dialog.dismiss();
                                scannerDialog.dismiss();
                                scannerView.stopCamera();

                                if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                    Utils.expiredTokenAlert(rootlayout, UnboxingPage.this);
                                } else {
                                    Utils.snackbarToast(rootlayout, response.message);
                                }

                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                            wrongTone.start();

                            dialog.dismiss();
                            isCamreOpen = false;
                            scannerDialog.dismiss();
                            scannerView.stopCamera();

                            if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 15000);
                                snackbar.show();
                            } else {
                                Utils.snackbarToast(rootlayout, throwable.getMessage());
                            }
                        }
                    }));

                }else {

                    wrongTone.start();

                    isCamreOpen = false;
                    boxORitem = 0;
                    scannerDialog.dismiss();
                    scannerView.stopCamera();
                    Utils.snackbarToast(rootlayout,"This is not Box Label!");
                }

            }else if (boxORitem == 2){

                mainList = listForScanProduct;

                int isData = 0;

                for (int i = 0; i < mainList.size(); i++){
                    final String barcode = mainList.get(i).barcode;

                    if (barcode.equals(rawResult.getText())){

                        isData = 1;

                        rightTone.start();

                        scannerDialog.dismiss();
                        scannerView.stopCamera();

                        final String skuID = mainList.get(i).sku_id;
                        final int insGQty = mainList.get(i).given_qty;

                        final Dialog qtyDialog = new Dialog(this);
                        qtyDialog.setContentView(R.layout.dialoge_unboxing);

                        int width = WindowManager.LayoutParams.MATCH_PARENT;
                        int height = WindowManager.LayoutParams.WRAP_CONTENT;

                        qtyDialog.getWindow().setLayout(width,height);
                        qtyDialog.setCancelable(false);
                        qtyDialog.show();

                        final EditText qtyText = qtyDialog.findViewById(R.id.unboxingItemQtyDialogeQtyID);
                        Button cancel = qtyDialog.findViewById(R.id.unboxingItemQtyDialogeCancelID);
                        Button ok = qtyDialog.findViewById(R.id.unboxingItemAddDialogeBtnID);

                        TextView d_avl_qty = qtyDialog.findViewById(R.id.unboxingItemGivenQtyID);


                        ImageView cardImage = qtyDialog.findViewById(R.id.unboxingItemAddDialogImageID);
                        TextView cardName = qtyDialog.findViewById(R.id.unboxingItemAddDialogeNameID);
                        TextView cardColor = qtyDialog.findViewById(R.id.unboxingItemAddDialogeColorID);
                        TextView cardSize = qtyDialog.findViewById(R.id.unboxingItemAddDialogeSizeID);

                        String insPrimaryImage = Common.BASEURL_PICTURE + mainList.get(i).primary_image;

                        if (mainList.get(i).variant_primary_image == null || mainList.get(i).variant_primary_image.equals("")) {
                            Glide.with(UnboxingPage.this)
                                    .load(insPrimaryImage)
                                    .placeholder(R.drawable.ic_default)
                                    .into(cardImage);
                        } else {
                            String insVariantImage = Common.BASEURL_PICTURE + mainList.get(i).variant_primary_image;


                            Glide.with(UnboxingPage.this)
                                    .load(insVariantImage)
                                    .placeholder(R.drawable.ic_default)
                                    .into(cardImage);
                        }


                        if (mainList.get(i).variant_name == null || mainList.get(i).variant_name.equals("")) {
                            cardName.setText(mainList.get(i).product_name);
                        } else {
                            cardName.setText(mainList.get(i).variant_name);
                        }

                        cardColor.setText("Color : " + mainList.get(i).color);
                        cardSize.setText("Size : " + mainList.get(i).size);


                        d_avl_qty.setText("Avl Qty : "+insGQty);
                        qtyText.setText(""+insGQty);

                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                qtyDialog.dismiss();
                            }
                        });

                        ok.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                if (!TextUtils.isEmpty(qtyText.getText())){
                                    String newQuantity = qtyText.getText().toString();
                                    int newQtyInt = Integer.parseInt(newQuantity);


                                    if (newQtyInt <= insGQty) {

                                        String token = SharedPreperenceUtils.getToken(UnboxingPage.this);
                                        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(UnboxingPage.this));

                                        final UnboxingPost post = new UnboxingPost();
                                        post.user_id = user_id;
                                        post.box_label = checkBoxlabel;
                                        post.sku_id = skuID;
                                        post.qty = newQtyInt;

                                        compositeDisposable.add(mIRetrofitApi.unboxing(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<UnboxingItemResponse>() {
                                            @Override
                                            public void accept(final UnboxingItemResponse response) throws Exception {
                                                if (response.status == 1){

                                                    mainList = response.data;
                                                    adapter.updateRecyclerView(mainList,checkBoxlabel);
                                                    updateList(mainList);

                                                    Snackbar snackbar = Snackbar.make(rootlayout,""+response.message,Snackbar.LENGTH_LONG);
                                                    snackbar.show();
                                                    qtyDialog.dismiss();

                                                }else {

                                                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                                        qtyDialog.dismiss();
                                                        isCamreOpen = false;
                                                        finish();

                                                        Utils.expiredTokenAlert(rootlayout,UnboxingPage.this);

                                                    }else {
                                                        isCamreOpen = false;
                                                        qtyDialog.dismiss();
                                                        Snackbar snackbar = Snackbar.make(rootlayout,response.message,Snackbar.LENGTH_LONG);
                                                        snackbar.show();
                                                    }
                                                }
                                            }
                                        }, new Consumer<Throwable>() {
                                            @Override
                                            public void accept(Throwable throwable) throws Exception {
                                                qtyDialog.dismiss();
                                                isCamreOpen = false;

                                                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                                    Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 15000);
                                                    snackbar.show();
                                                }else {
                                                    Snackbar snackbar = Snackbar.make(rootlayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                                                    snackbar.show();
                                                }

                                            }
                                        }));

                                    }else {
                                        Toast.makeText(UnboxingPage.this, "Enter less than "+insGQty, Toast.LENGTH_SHORT).show();
                                    }
                                }else {
                                    Toast.makeText(UnboxingPage.this, "Enter Minimum 1 Qty!", Toast.LENGTH_SHORT).show();
                                }

                            }
                        });

                        return;
                    }
                }
                if (isData == 0){
                    wrongTone.start();

                    scannerDialog.dismiss();
                    scannerView.stopCamera();

                    Utils.snackbarToast(rootlayout,"Product Not Found!");
                }
            }
        }else {

            wrongTone.start();

            scannerDialog.dismiss();
            scannerView.stopCamera();

            Utils.snackbarToast(rootlayout,"Empty barcode!");
        }
    }


    private void getBoxItem(final String barcode){

        mainList = new ArrayList<>();

        adapter.updateRecyclerView(mainList, barcode);
        productScanBtn.setVisibility(View.GONE);

        checkBoxlabel = barcode;

        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        final ReboxingPost reboxingPost = new ReboxingPost();
        reboxingPost.box_label =barcode;
        reboxingPost.user_id = user_id;

        final Dialog dialog = new Dialog(UnboxingPage.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width, height);
        dialog.setCancelable(false);
        dialog.show();

        compositeDisposable.add(mIRetrofitApi.unboxingList(token, reboxingPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ReboxingResponse>() {
            @Override
            public void accept(ReboxingResponse response) throws Exception {
                if (response.status == 1) {

                    //rightTone.start();

                    for (ReboxingResponse.Data item : response.data) {
                        final UnboxingItemResponse.Data mainItem = new UnboxingItemResponse.Data();
                        mainItem.PK_NO = item.PK_NO;
                        mainItem.sku_id = item.sku_id;
                        mainItem.mkt_id = item.mkt_id;
                        mainItem.product_name = item.product_name;
                        mainItem.variant_name = item.variant_name;
                        mainItem.size = item.size;
                        mainItem.color = item.color;
                        mainItem.variant_primary_image = item.variant_primary_image;
                        mainItem.primary_image = item.primary_image;
                        mainItem.available_qty = item.available_qty;
                        mainItem.given_qty = item.given_qty;
                        mainItem.barcode = item.barcode;

                        mainList.add(mainItem);
                    }

                    adapter.updateRecyclerView(mainList, barcode);
                    boxLabel.setText("Box Label : " + barcode);

                    if (mainList.size() > 0) {
                        updateList(mainList);
                        productScanBtn.setVisibility(View.VISIBLE);
                    }
//                    isCamreOpen = false;
//                    scannerDialog.dismiss();
//                    scannerView.stopCamera();
                    dialog.dismiss();

                } else {
                    dialog.dismiss();

//                    wrongTone.start();
//
//                    isCamreOpen = false;
//
//                    scannerDialog.dismiss();
//                    scannerView.stopCamera();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootlayout, UnboxingPage.this);
                    } else {
                        Utils.snackbarToast(rootlayout, response.message);
                    }

                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

                //wrongTone.start();

                dialog.dismiss();
//                isCamreOpen = false;
//                scannerDialog.dismiss();
//                scannerView.stopCamera();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 15000);
                    snackbar.show();
                } else {
                    Utils.snackbarToast(rootlayout, throwable.getMessage());
                }
            }
        }));

    }


}