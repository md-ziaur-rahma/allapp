package com.example.ukshop.Adapters;

import android.app.Activity;
import android.app.Dialog;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.Models.ProductListModel;
import com.example.ukshop.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Handler;

public class ProductListAdapter extends RecyclerView.Adapter<ProductListAdapter.ViewHolder> {

    private List<ProductListModel> list;
    private Activity context;

    public ProductListAdapter(List<ProductListModel> list, Activity context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ProductListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.product_list_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductListAdapter.ViewHolder holder, int position) {

        int image = list.get(position).getImage();
        String barcode = list.get(position).getBarcode();
        String name = list.get(position).getProductName();
        String brand = list.get(position).getProductBrand();
        String size = list.get(position).getProductSize();
        String price = list.get(position).getProductPrice();

        holder.setData(image,barcode,name,brand,size,price,position);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void filteredItem(ArrayList<ProductListModel> filteredList){
        list = filteredList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private ImageView image;
        private TextView code, name,brand,size,price;
        private Button bookNowBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.bookItemImageID);
            code = itemView.findViewById(R.id.bookItemCodeID);
            name = itemView.findViewById(R.id.bookItemNameID);
            brand = itemView.findViewById(R.id.bookItemBrandId);
            size = itemView.findViewById(R.id.bookItemSizeID);
            price = itemView.findViewById(R.id.bookItemPriceID);

            bookNowBtn = itemView.findViewById(R.id.bookItemBookBtnID);


        }

        public void setData(final int image, String barcode, final String name, String brand, String size, final String price, int position){

            this.image.setImageResource(image);
            code.setText("Barcode : "+barcode);
            this.name.setText(name);
            this.brand.setText("Brand : "+brand);
            this.size.setText("Size : "+size);
            this.price.setText("$"+price);

            bookNowBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final Dialog bookDialoge = new Dialog(context);
                    bookDialoge.setContentView(R.layout.book_now_dialoge_layout);

                    int width = WindowManager.LayoutParams.MATCH_PARENT;
                    int hieght = WindowManager.LayoutParams.WRAP_CONTENT;

                    bookDialoge.getWindow().setLayout(width,hieght);
                    bookDialoge.setCancelable(false);
                    bookDialoge.show();

                    final EditText dialogeQntText = bookDialoge.findViewById(R.id.booknowDialogeQntID);
                    Button cancel = bookDialoge.findViewById(R.id.bookNowDialogeCancelID);
                    Button dialogeBookBtn = bookDialoge.findViewById(R.id.bookNowDialogeBookBtnID);

                    ImageView dialogeImage = bookDialoge.findViewById(R.id.bookNowDialogeImageID);
                    TextView dialogeProductName = bookDialoge.findViewById(R.id.bookNowDialogeNameID);
                    TextView dialogeProductPrice = bookDialoge.findViewById(R.id.bookNowDialogePriceID);

                    dialogeImage.setImageResource(image);
                    dialogeProductName.setText(name);
                    dialogeProductPrice.setText("$"+price);

                    cancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            bookDialoge.dismiss();
                        }
                    });


                    dialogeBookBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            if (!TextUtils.isEmpty(dialogeQntText.getText().toString())){

                                int dialogeQnt = Integer.parseInt(dialogeQntText.getText().toString());
                                int casIntPrice = Integer.parseInt(price);

                                // todo code : check product in stock...

                                int totalBookPrice = casIntPrice * dialogeQnt;

                                final Dialog confirmDialoge = new Dialog(context);
                                confirmDialoge.setContentView(R.layout.book_now_confirm_dialoge_layout);

                                int width = WindowManager.LayoutParams.MATCH_PARENT;
                                int hieght = WindowManager.LayoutParams.WRAP_CONTENT;

                                confirmDialoge.getWindow().setLayout(width,hieght);
                                confirmDialoge.show();
                                confirmDialoge.setCancelable(false);
                                bookDialoge.dismiss();

                                TextView confirmDialogeDate = confirmDialoge.findViewById(R.id.dialogeBookConfirmDateID);
                                TextView confirmDialogePrice = confirmDialoge.findViewById(R.id.dialogeBookConfirmAmountID);
                                Button noBtn = confirmDialoge.findViewById(R.id.bookDialogeConfirmNoID);
                                Button yesBtn = confirmDialoge.findViewById(R.id.bookDialogeConfirmYesID);

                                Date date = Calendar.getInstance().getTime();
                                SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm");
                                String fomatedDate = formatter.format(date);

                                confirmDialogeDate.setText(fomatedDate);
                                confirmDialogePrice.setText("Book Price : $"+totalBookPrice);

                                noBtn.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        confirmDialoge.dismiss();
                                    }
                                });

                                yesBtn.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {

                                        final Dialog sucessDialoge = new Dialog(context);
                                        sucessDialoge.setContentView(R.layout.successful_layout);

                                        int width = WindowManager.LayoutParams.MATCH_PARENT;
                                        int hieght = WindowManager.LayoutParams.WRAP_CONTENT;

                                        sucessDialoge.getWindow().setLayout(width,hieght);
                                        sucessDialoge.setCancelable(true);
                                        sucessDialoge.show();
                                        confirmDialoge.dismiss();
                                    }
                                });

                            }else {
                                Toast.makeText(context, "Enter minimum 1 Quantity!", Toast.LENGTH_SHORT).show();
                            }


                        }
                    });


                }
            });

        }
    }
}
