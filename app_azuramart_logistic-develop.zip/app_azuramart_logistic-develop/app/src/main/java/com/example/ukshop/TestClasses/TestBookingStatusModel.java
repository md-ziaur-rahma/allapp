package com.example.ukshop.TestClasses;

public class TestBookingStatusModel {
    private int image;
    private String productName;
    private String  customerName;
    private String mobile;
    private String status;
    private String time;
    private boolean isShow;

    public TestBookingStatusModel(int image, String productName, String customerName, String mobile, String status, String time, boolean isShow) {
        this.image = image;
        this.productName = productName;
        this.customerName = customerName;
        this.mobile = mobile;
        this.status = status;
        this.time = time;
        this.isShow = isShow;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public boolean isShow() {
        return isShow;
    }

    public void setShow(boolean show) {
        isShow = show;
    }
}
