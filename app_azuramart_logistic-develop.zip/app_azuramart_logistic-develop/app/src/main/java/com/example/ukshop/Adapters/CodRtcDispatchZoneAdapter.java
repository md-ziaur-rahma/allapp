package com.example.ukshop.Adapters;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.CodRtcDispatchZone;
import com.example.ukshop.Activity.HomePage;
import com.example.ukshop.Activity.ImageShowPage;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.CodRtcDispatchZoneResponse;
import com.example.ukshop.NetworkModel.CodRtcZoneItemAcknowledgePost;
import com.example.ukshop.NetworkModel.ShelvingResponse;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class CodRtcDispatchZoneAdapter extends RecyclerView.Adapter<CodRtcDispatchZoneAdapter.ViewHolder> {

    private List<CodRtcDispatchZoneResponse.Data> mainList;
    private Activity context;
    private CoordinatorLayout rootLayout;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;
    List<VariantImageResponse.Data> variantImageList = new ArrayList<>();

    public CodRtcDispatchZoneAdapter(List<CodRtcDispatchZoneResponse.Data> mainList, Activity context, CoordinatorLayout rootLayout) {
        this.mainList = mainList;
        this.context = context;
        this.rootLayout = rootLayout;
    }

    @NonNull
    @Override
    public CodRtcDispatchZoneAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cod_rtc_item_acknowledge_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CodRtcDispatchZoneAdapter.ViewHolder holder, int position) {
        int pk_id = mainList.get(position).PK_NO;
        String imageUrl = mainList.get(position).variant_primary_image;
        String primaryImage = mainList.get(position).primary_image;
        String skuId = mainList.get(position).sku_id;
        String mktId = mainList.get(position).mkt_id;
        String name = mainList.get(position).product_name;
        String variantName = mainList.get(position).variant_name;
        String color = mainList.get(position).color;
        String size = mainList.get(position).size;
        int qty = mainList.get(position).qty;
        String barcode = mainList.get(position).barcode;
        int isAcknowledge = mainList.get(position).is_acknowledge;
        int orderId = mainList.get(position).order_id;


        holder.setData(pk_id,qty,position,primaryImage,imageUrl,skuId,
                mktId,name,variantName,color,size,barcode,isAcknowledge,orderId);
    }

    @Override
    public int getItemCount() {
        return mainList.size();
    }

    public void updateData(List<CodRtcDispatchZoneResponse.Data> newList){
        mainList = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView qty,barcode;
        private CheckBox isAck;
        private ImageView variant_image;
        private TextView name,skuId,size,color;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            variant_image = itemView.findViewById(R.id.cod_ack_item_imageID);
            name = itemView.findViewById(R.id.cod_ack_item_nameID);
            skuId = itemView.findViewById(R.id.cod_ack_item_skuID);
            size = itemView.findViewById(R.id.cod_ack_item_sizeID);
            color = itemView.findViewById(R.id.cod_ack_item_colorID);
            isAck = itemView.findViewById(R.id.cod_ack_itemCheckAckID);
            qty = itemView.findViewById(R.id.cod_ack_item_qntID);
            barcode = itemView.findViewById(R.id.cod_ack_item_barcodeID);
        }

        public void setData(final int pk_id,final int qty, final int position, final String primaryImage,
                            final String variantImage, final String sku, final String mkt, final String name, final String variantName,
                            final String color, final String size, final String barcode ,final int isAcknowledge,final int orderID) {
            String insPrimaryImage = Common.BASEURL_PICTURE + primaryImage;

            if (variantImage == null || variantImage.equals("")) {
                Glide.with(context)
                        .load(insPrimaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_image);
            } else {
                String insVariantImage = Common.BASEURL_PICTURE + variantImage;


                Glide.with(context)
                        .load(insVariantImage)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_image);
            }


            if (variantName == null || variantName.equals("")) {
                this.name.setText(name);
            } else {
                this.name.setText(variantName);
            }

            //this.skuId.setText("SKU : "+sku);
            this.skuId.setText("SKU : " +sku);
            this.barcode.setText("Barcode : "+barcode);
            this.color.setText("Color : " + color);
            this.size.setText("Size : " + size);
            this.qty.setText("Qty : " + qty);

            if (isAcknowledge == 1){
                this.isAck.setChecked(true);
            }else if (isAcknowledge == 0){
                this.isAck.setChecked(false);
            }

            isAck.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    final Dialog dialog = new Dialog(context,R.style.PauseDialog);
                    dialog.setContentView(R.layout.dialoge_exit);

                    int width = WindowManager.LayoutParams.MATCH_PARENT;
                    int height = WindowManager.LayoutParams.WRAP_CONTENT;

                    dialog.getWindow().setLayout(width,height);
                    dialog.setCancelable(true);
                    dialog.show();

                    final Button OkBtn = dialog.findViewById(R.id.dialogeExitOkID);
                    final Button cancelBtn = dialog.findViewById(R.id.dialogeExitCancelID);
                    final TextView msg = dialog.findViewById(R.id.dialogeExitTextMsgID);
                    final TextView toMsg = dialog.findViewById(R.id.dialogExitTopTextID);

                    OkBtn.setText("Confirm");
                    msg.setText("Are you sure?");
                    toMsg.setText("Confirmation");

                    cancelBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            notifyDataSetChanged();
                            dialog.dismiss();
                        }
                    });

                    OkBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mIRetrofitApi = Common.getApiArobil();
                            String token = SharedPreperenceUtils.getToken(context);
                            int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(context));

                            final CodRtcZoneItemAcknowledgePost post = new CodRtcZoneItemAcknowledgePost();
                            post.sku_id = mainList.get(position).sku_id;
                            post.order_id = mainList.get(position).order_id;
                            post.qty = mainList.get(position).qty;
                            post.user_id = user_id;
                            if(isAcknowledge == 0){
                                post.is_acknowledge = 1;
                            }else {
                                post.is_acknowledge = 0;
                            }
                            //post.is_acknowledge = isChecked ? 1 : 0;

                            Log.e("cod dispatch post", "request"+new Gson().toJson(post));

                            compositeDisposable.add(mIRetrofitApi.getCodRtcAcknowledge(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ShelvingResponse>() {
                                @Override
                                public void accept(ShelvingResponse response) throws Exception {
                                    if (response.status == 1){
                                        final CodRtcDispatchZoneResponse.Data item = new CodRtcDispatchZoneResponse.Data();
                                        item.PK_NO = mainList.get(position).PK_NO;
                                        item.sku_id = mainList.get(position).sku_id;
                                        item.mkt_id = mainList.get(position).mkt_id;
                                        item.barcode = mainList.get(position).barcode;
                                        item.product_name = mainList.get(position).product_name;
                                        item.variant_name = mainList.get(position).variant_name;
                                        item.primary_image = mainList.get(position).primary_image;
                                        item.variant_primary_image = mainList.get(position).variant_primary_image;
                                        item.color = mainList.get(position).color;
                                        item.size = mainList.get(position).size;
                                        item.is_acknowledge = isAcknowledge == 0 ? 1 : 0;
                                        item.order_id = mainList.get(position).order_id;
                                        item.qty = mainList.get(position).qty;

                                        mainList.set(position,item);
                                        mainList.remove(position);
                                        notifyItemRangeChanged(position,mainList.size());
                                        notifyDataSetChanged();

                                        Toast.makeText(context, ""+response.message, Toast.LENGTH_SHORT).show();
                                        dialog.dismiss();
                                        //Utils.snackbarToast(rootLayout,response.message);
                                    }else {
                                        notifyDataSetChanged();
                                        dialog.dismiss();
                                        if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                            Utils.expiredTokenAlert(rootLayout, context);
                                        }else {
                                            Utils.snackbarToast(rootLayout,response.message);
                                        }
                                    }
                                }
                            }, new Consumer<Throwable>() {
                                @Override
                                public void accept(Throwable throwable) throws Exception {
                                    notifyDataSetChanged();
                                    dialog.dismiss();
                                    if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                        Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                                        snackbar.show();
                                    }else {
                                        Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                    }
                                }
                            }));
                        }
                    });


                }
            });

//            isAck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                @Override
//                public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked) {
//
//                }
//            });


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            variant_image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    //Toast.makeText(context, ""+pk_id, Toast.LENGTH_SHORT).show();

                    mIRetrofitApi = Common.getApiArobil();
                    String token = SharedPreperenceUtils.getToken(context);

                    compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<VariantImageResponse>() {
                        @Override
                        public void accept(VariantImageResponse response) throws Exception {
                            if (response.status == 1){
                                variantImageList = response.data;
                                ImageShowPage.variantImageList = variantImageList;
                                Intent intent = new Intent(context, ImageShowPage.class);
                                itemView.getContext().startActivity(intent);

                            }else {

                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    }));
                }
            });

        }
    }
}
