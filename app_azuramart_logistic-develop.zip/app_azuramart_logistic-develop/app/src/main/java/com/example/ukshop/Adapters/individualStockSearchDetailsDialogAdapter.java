package com.example.ukshop.Adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.NetworkModel.IndividualStockSearchResponse;
import com.example.ukshop.R;

import java.util.List;

public class individualStockSearchDetailsDialogAdapter extends RecyclerView.Adapter<individualStockSearchDetailsDialogAdapter.ViewHolder> {
    private List<IndividualStockSearchResponse.MerchantQty> list;

    public individualStockSearchDetailsDialogAdapter(List<IndividualStockSearchResponse.MerchantQty> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public individualStockSearchDetailsDialogAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.individual_stock_search_merchant_qty_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull individualStockSearchDetailsDialogAdapter.ViewHolder holder, int position) {
        int airQty = list.get(position).air_qty;
        String name = list.get(position).merchant_name;
        int totalQty = list.get(position).available_qty;
        int seaQty = list.get(position).sea_qty;

        holder.setData(name,seaQty,airQty,totalQty);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
    private TextView name,seaQty,airQty,totalQty;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.individualStock_check_item_qty_NameID);
            seaQty = itemView.findViewById(R.id.individualStock_check_item_qty_seaQtyID);
            airQty = itemView.findViewById(R.id.individualStock_check_item_qty_airQtyID);
            totalQty = itemView.findViewById(R.id.individualStock_check_item_qty_totalQtyID);
        }

        public void setData(String name,int seaQty, int airQty, int totalQty){
            this.airQty.setText(""+airQty);
            this.seaQty.setText(""+seaQty);
            this.name.setText(name);
            this.totalQty.setText(""+totalQty);
        }
    }
}
