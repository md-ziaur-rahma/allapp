package com.example.ukshop.Network;

import com.example.ukshop.NetworkModel.BatchListPost;
import com.example.ukshop.NetworkModel.BatchListResponse;
import com.example.ukshop.NetworkModel.BoxDetailsItemPost;
import com.example.ukshop.NetworkModel.BoxListPost;
import com.example.ukshop.NetworkModel.BoxListResponse;
import com.example.ukshop.NetworkModel.BoxWeightResponse;
import com.example.ukshop.NetworkModel.CheckoutProductPost;
import com.example.ukshop.NetworkModel.CheckoutProductResponse;
import com.example.ukshop.NetworkModel.CodRtcBoxedItemCollectPost;
import com.example.ukshop.NetworkModel.CodRtcDispatchItemPost;
import com.example.ukshop.NetworkModel.CodRtcDispatchItemResponse;
import com.example.ukshop.NetworkModel.CodRtcDispatchPost;
import com.example.ukshop.NetworkModel.CodRtcDispatchResponse;
import com.example.ukshop.NetworkModel.CodRtcPickingListPost;
import com.example.ukshop.NetworkModel.CodRtcPickingListResponse;
import com.example.ukshop.NetworkModel.CodRtcDispatchZonePost;
import com.example.ukshop.NetworkModel.CodRtcDispatchZoneResponse;
import com.example.ukshop.NetworkModel.CodRtcShelveTransferPost;
import com.example.ukshop.NetworkModel.CodRtcZoneItemAcknowledgePost;
import com.example.ukshop.NetworkModel.ConsignmentListPost;
import com.example.ukshop.NetworkModel.ConsignmentListResponse;
import com.example.ukshop.NetworkModel.IndividualStockSearchResponse;
import com.example.ukshop.NetworkModel.OrderListResponse;
import com.example.ukshop.NetworkModel.RtsDispatchConsignmentItemResponse;
import com.example.ukshop.NetworkModel.DispatchConsignmentItemPost;
import com.example.ukshop.NetworkModel.RtsDispatchPost;
import com.example.ukshop.NetworkModel.DispatchResponse;
import com.example.ukshop.NetworkModel.PriorityBoxPost;
import com.example.ukshop.NetworkModel.PriorityBoxResponse;
import com.example.ukshop.NetworkModel.ProductBoxLocationPost;
import com.example.ukshop.NetworkModel.ProductBoxLocationResponse;
import com.example.ukshop.NetworkModel.ProductSearchDetailsMyResponse;
import com.example.ukshop.NetworkModel.ProductSearchMYResponse;
import com.example.ukshop.NetworkModel.ProductSearchPost;
import com.example.ukshop.NetworkModel.ProductSearchResponse;
import com.example.ukshop.NetworkModel.RTSPost;
import com.example.ukshop.NetworkModel.RTSResponse;
import com.example.ukshop.NetworkModel.RTSShelveCheckoutPost;
import com.example.ukshop.NetworkModel.ReboxingOpenPost;
import com.example.ukshop.NetworkModel.ReboxingOpenResponse;
import com.example.ukshop.NetworkModel.ReboxingPost;
import com.example.ukshop.NetworkModel.ReboxingResponse;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.NetworkModel.AuthPost;
import com.example.ukshop.NetworkModel.AuthResponse;
import com.example.ukshop.NetworkModel.BoxingItemPost;
import com.example.ukshop.NetworkModel.BoxingItemResponse;
import com.example.ukshop.NetworkModel.BoxingResponse;
import com.example.ukshop.NetworkModel.MasterProductDetailsResponse;
import com.example.ukshop.NetworkModel.MasterProductResponse;
import com.example.ukshop.NetworkModel.ProductListPost;
import com.example.ukshop.NetworkModel.ProductListResponse;
import com.example.ukshop.NetworkModel.ShelveItemListPost;
import com.example.ukshop.NetworkModel.ShelveItemListResponse;
import com.example.ukshop.NetworkModel.ShelvingItemPost;
import com.example.ukshop.NetworkModel.ShelvingPost;
import com.example.ukshop.NetworkModel.ShelvingPostItemResponse;
import com.example.ukshop.NetworkModel.ShelvingResponse;
import com.example.ukshop.NetworkModel.ShipmentInprogressPost;
import com.example.ukshop.NetworkModel.ShipmentInprogressResponse;
import com.example.ukshop.NetworkModel.ShipmentPost;
import com.example.ukshop.NetworkModel.ShipmentReceivePost;
import com.example.ukshop.NetworkModel.ShipmentReceiveResponse;
import com.example.ukshop.NetworkModel.ShipmentResponse;
import com.example.ukshop.NetworkModel.StockCheckPost;
import com.example.ukshop.NetworkModel.StockCheckSearchResponse;
import com.example.ukshop.NetworkModel.UnboxedItemPost;
import com.example.ukshop.NetworkModel.UnboxedItemResponse;
import com.example.ukshop.NetworkModel.UnboxingItemResponse;
import com.example.ukshop.NetworkModel.UnboxingPost;
import com.example.ukshop.NetworkModel.UpdateBoxLabelPost;
import com.example.ukshop.NetworkModel.UpdateBoxLabelResponse;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.NetworkModel.YettoBoxPost;
import com.example.ukshop.NetworkModel.YettoBoxResponse;
import com.example.ukshop.merchantNetworkModels.MerchantListModel;

import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface IRetrofitApi {
    @POST("v1/login")
    io.reactivex.Observable<AuthResponse> login(@Body AuthPost authPost);

    @POST("v1/get-products")
    io.reactivex.Observable<ProductListResponse> getProdutctList(@Body ProductListPost productListPost);

    @POST("v1/get-master-products")
    io.reactivex.Observable<MasterProductResponse> getMasterProdutctList(@Header("Authorization") String token);

    @POST("v1/get-checkEntry")
    io.reactivex.Observable<MasterProductDetailsResponse> getVariantEntryCheckList(@Header("Authorization") String token,@Body StockCheckPost stockCheckPost);

    @POST("v1/get-variant")
    @FormUrlEncoded
    io.reactivex.Observable<MasterProductDetailsResponse> getProductVariantList(@Header("Authorization") String token, @Field("pk_id") int pk_id);

    @POST("v1/get-variant-img")
    @FormUrlEncoded
    io.reactivex.Observable<VariantImageResponse> getVariantImage(@Header("Authorization")String token,@Field("PK_ID")int PK_ID);

    @POST("v1/get-all-stockSearchList")
    io.reactivex.Observable<IndividualStockSearchResponse> getIndividualStockCheckSearchList(@Header("Authorization") String token, @Body StockCheckPost stockCheckPost);

    @POST("v1/get-stockSearchList")
    io.reactivex.Observable<StockCheckSearchResponse> getStockCheckSearchList(@Header("Authorization") String token, @Body StockCheckPost stockCheckPost);

    @POST("v1/get-merchant-stockSearchList")
    io.reactivex.Observable<StockCheckSearchResponse> getMerchantStockSearchList(@Header("Authorization") String token, @Body StockCheckPost stockCheckPost);

    @POST("v1/merchant-list")
    io.reactivex.Observable<MerchantListModel> getMerchantList(@Header("Authorization") String token);

    @POST("v1/get-merchant-stockSearchList")
    io.reactivex.Observable<BoxingItemResponse> getMerchantBoxingItem(@Header("Authorization") String token, @Body StockCheckPost stockCheckPost);

    @POST("v1/get-stockSearchList")
    io.reactivex.Observable<BoxingItemResponse> getBoxingItem(@Header("Authorization") String token, @Body StockCheckPost stockCheckPost);

    @POST("v1/boxing")
    io.reactivex.Observable<BoxingResponse> boxing(@Header("Authorization") String token, @Body BoxingItemPost boxingItemPost);

    @POST("v1/get-box-dimension")
    io.reactivex.Observable<BoxWeightResponse> getBoxDimensionList(@Header("Authorization") String token);

    @POST("v1/reboxing")
    io.reactivex.Observable<ReboxingResponse> reboxing(@Header("Authorization") String token, @Body ReboxingPost reboxingPost);

    @POST("v1/reboxing-add-box-open")
    io.reactivex.Observable<ReboxingOpenResponse> reboxingAddBoxOpen(@Header("Authorization") String token, @Body ReboxingOpenPost reboxingOpenPost);

    @POST("v1/update-box-label")
    io.reactivex.Observable<UpdateBoxLabelResponse> updateBoxLabel(@Header("Authorization") String token, @Body UpdateBoxLabelPost updateBoxLabelPost);

    @POST("v1/shipment")
    io.reactivex.Observable<ShipmentResponse> shipment(@Header("Authorization")String token, @Body ShipmentPost shipmentPost);

    @POST("v1/shipment-list")
    io.reactivex.Observable<ShipmentInprogressResponse> getShipmentList(@Header("Authorization") String token, @Body ShipmentInprogressPost shipmentInprogressPost);

    @POST("v1/merchant-shipment-list")
    io.reactivex.Observable<ShipmentInprogressResponse> getMerchantShipmentList(@Header("Authorization") String token, @Body ShipmentInprogressPost shipmentInprogressPost);

    @POST("v1/shipment-receive")
    io.reactivex.Observable<ShipmentReceiveResponse> shipmentReceive(@Header("Authorization") String token, @Body ShipmentReceivePost shipmentReceivePost);

    @POST("v1/unboxing-list")
    io.reactivex.Observable<ReboxingResponse> unboxingList(@Header("Authorization") String token, @Body ReboxingPost reboxingPost);

    @POST("v1/priority-unboxing-item-list")
    io.reactivex.Observable<ReboxingResponse> getPriorityunboxingItemList(@Header("Authorization") String token, @Body ReboxingPost reboxingPost);

    @POST("v1/priority-unbox-list")
    io.reactivex.Observable<PriorityBoxResponse> getPriorityBoxList(@Header("Authorization") String token, @Body PriorityBoxPost priorityBoxPost);

    @POST("v1/unboxing-box-list")
    io.reactivex.Observable<PriorityBoxResponse> getUnboxingBoxList(@Header("Authorization") String token, @Body PriorityBoxPost priorityBoxPost);

    @POST("v1/unboxing")
    io.reactivex.Observable<UnboxingItemResponse> unboxing(@Header("Authorization")String token, @Body UnboxingPost unboxingPost);

    @POST("v1/shelving-post-item")
    io.reactivex.Observable<ShelvingPostItemResponse> getShelvingPostItem(@Header("Authorization") String token, @Body ShelvingItemPost shelvingItemPost);

    @POST("v1/shelve-checkout-product")
    io.reactivex.Observable<CheckoutProductResponse> getCheckoutProduct(@Header("Authorization") String token, @Body CheckoutProductPost checkoutProductPost);

    @POST("v1/cod-rtc-order-list")
    io.reactivex.Observable<OrderListResponse> getCodRtcOrderList(@Header("Authorization") String token, @Body ConsignmentListPost consignmentListPost);

    @POST("v1/cod-rtc-dispatch-list")
    io.reactivex.Observable<CodRtcPickingListResponse> getCodRtcDispatchList(@Header("Authorization") String token, @Body CodRtcPickingListPost codRtcPickingListPost);

    @POST("v1/cod-rtc-dispatch-zone-item")
    io.reactivex.Observable<CodRtcDispatchZoneResponse> getCodRtcDispatchZoneItem(@Header("Authorization") String token, @Body CodRtcDispatchZonePost codRtcDispatchZonePost);

    @POST("v1/cod-rtc-acknowledgement")
    io.reactivex.Observable<ShelvingResponse> getCodRtcAcknowledge(@Header("Authorization")String token, @Body CodRtcZoneItemAcknowledgePost acknowledgePost);

    @POST("v1/cod-rtc-shelve-transfer")
    io.reactivex.Observable<ShelvingResponse> codRtcShelveTransfer(@Header("Authorization") String token, @Body CodRtcShelveTransferPost codRtcShelveTransferPost);

    @POST("v1/cod-rtc-boxed-item-transfer")
    io.reactivex.Observable<ShelvingResponse> codRtcBoxedItemTransfer(@Header("Authorization") String token, @Body CodRtcBoxedItemCollectPost codRtcBoxedItemCollectPost);

    @POST("v1/cod-rtc-dispatch-item")
    io.reactivex.Observable<CodRtcDispatchItemResponse> codRtcDispatchItem(@Header("Authorization") String token, @Body CodRtcDispatchItemPost codRtcDispatchItemPost);

    @POST("v1/cod-rtc-dispatch")
    io.reactivex.Observable<CodRtcDispatchResponse> codRtcDispatch(@Header("Authorization") String token, @Body CodRtcDispatchPost codRtcDispatchPost);

    @POST("v1/rts-batch-list")
    io.reactivex.Observable<BatchListResponse> getRtsBatchList(@Header("Authorization") String token, @Body BatchListPost batchListPost);

    @POST("v1/dispatch-area-batch-list")
    io.reactivex.Observable<BatchListResponse> getDispatchAreaBatchList(@Header("Authorization") String token, @Body BatchListPost batchListPost);

    @POST("v1/rts-dispatch-area-item")
    io.reactivex.Observable<ReboxingResponse> getRtsDispatchAreaItem(@Header("Authorization") String token, @Body RTSPost rtsPost);

    @POST("v1/rts-shelve-checkout")
    io.reactivex.Observable<ShelvingResponse> rtsShelveCheckout(@Header("Authorization") String token, @Body RTSShelveCheckoutPost rtsShelveCheckoutPost);

    @POST("v1/rts-dispatch-list")
    io.reactivex.Observable<RTSResponse> getRTSList(@Header("Authorization") String token, @Body RTSPost rtsPost);

    @POST("v1/shelving")
    io.reactivex.Observable<ShelvingResponse> shelving(@Header("Authorization")String token, @Body ShelvingPost shelvingPost);

    @POST("v1/boxlist")
    io.reactivex.Observable<BoxListResponse> getBoxList(@Header("Authorization")String token, @Body BoxListPost boxListPost);

    @POST("v1/merchant-boxlist")
    io.reactivex.Observable<BoxListResponse> getMerchantBoxList(@Header("Authorization")String token, @Body BoxListPost boxListPost);

    @POST("v1/boxed-details-item-list")
    io.reactivex.Observable<ReboxingResponse> getBoxDetailsItem(@Header("Authorization")String token, @Body BoxDetailsItemPost boxDetailsItemPost);

    @POST("v1/yet-to-box")
    io.reactivex.Observable<YettoBoxResponse> getYetToBoxList(@Header("Authorization")String token, @Body YettoBoxPost yettoBoxPost);

    @POST("v1/product-search")
    io.reactivex.Observable<ProductSearchResponse> getProductSearch(@Header("Authorization") String token, @Body ProductSearchPost productSearchPost);

    @POST("v1/merchant-product-search")
    io.reactivex.Observable<ProductSearchResponse> getMerchantProductSearch(@Header("Authorization") String token, @Body ProductSearchPost productSearchPost);

    @POST("v1/product-search-my")
    io.reactivex.Observable<ProductSearchMYResponse> getProductSearchMy(@Header("Authorization") String token, @Body ProductSearchPost productSearchPost);

    @POST("v1/product-search-details-my")
    io.reactivex.Observable<ProductSearchDetailsMyResponse> getProductSearchDetailsMy(@Header("Authorization") String token, @Body ProductBoxLocationPost productBoxLocationPost);

    @POST("v1/product-box-location")
    io.reactivex.Observable<ProductBoxLocationResponse> getProductBoxLocation(@Header("Authorization") String token, @Body ProductBoxLocationPost productBoxLocationPost);

    @POST("v1/land-area-item-list")
    io.reactivex.Observable<UnboxedItemResponse> getUnboxedItemList(@Header("Authorization") String token, @Body UnboxedItemPost unboxedItemPost);

    @POST("v1/shelve-item-list")
    io.reactivex.Observable<ShelveItemListResponse> getShelveItemList(@Header("Authorization") String token, @Body ShelveItemListPost shelveItemListPost);

    @POST("v1/consignment-list")
    io.reactivex.Observable<ConsignmentListResponse> getConsignmentList(@Header("Authorization") String token, @Body ConsignmentListPost consignmentListPost);

    @POST("v1/get-consignment-item")
    io.reactivex.Observable<RtsDispatchConsignmentItemResponse> getConsignmentItem(@Header("Authorization") String token, @Body DispatchConsignmentItemPost dispatchConsignmentItemPost);

    @POST("v1/dispatch")
    io.reactivex.Observable<DispatchResponse> dispatch(@Header("Authorization") String token, @Body RtsDispatchPost dispatchPost);

    @POST("v1/check-session")
    @FormUrlEncoded
    io.reactivex.Observable<ApiResponse> checkSession(@Field("Authorization")String token, @Field("user_id")int user_id);
}
