package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.ukshop.Adapters.BoxingItemAdapter;
import com.example.ukshop.Adapters.ReboxingAddAdapter;
import com.example.ukshop.Adapters.ReboxingItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.NetworkModel.BoxWeightResponse;
import com.example.ukshop.NetworkModel.BoxingItemPost;
import com.example.ukshop.NetworkModel.BoxingItemResponse;
import com.example.ukshop.NetworkModel.BoxingItemSubModel;
import com.example.ukshop.NetworkModel.BoxingResponse;
import com.example.ukshop.NetworkModel.ReboxingOpenPost;
import com.example.ukshop.NetworkModel.ReboxingOpenResponse;
import com.example.ukshop.NetworkModel.StockCheckPost;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class ReboxingAdd extends AppCompatActivity implements ZXingScannerView.ResultHandler,
        AdapterView.OnItemSelectedListener{

    private MaterialToolbar toolbar;
    private CoordinatorLayout rootlayout;
    private LinearLayout boxScan;
    private TextView boxLabel;
    private static Button reBoxBtn;
    private static LinearLayout scanItem;
    private TextView scanItemText;

    private int merchant_id;

    /// ............. Weight Layout ..............
    private EditText boxHeight,boxWidth,boxLength,boxWeight;
    private Spinner weightSpinner;
    private List<BoxWeightResponse.Data> boxWeightList = new ArrayList<>();
    private List<String> dimensionTextList = new ArrayList<>();
    private ArrayAdapter<String> spinnerAdapter;
    private static View boxWeightLayout;

    private RecyclerView recyclerview;
    private List<BoxingItemResponse.Data> mainList = new ArrayList<>();
    private static List<BoxingItemSubModel> list = new ArrayList<>();
    private List<BoxingItemResponse.Data> tempList = new ArrayList<>();
    private ReboxingAddAdapter adapter;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;


    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static final int CAMERA_PERMISSION_CODE = 501;


    private static boolean isFlash = false;
    private static boolean isCameraOpen = false;
    private static int boxORitem = 0;

    private String boxLabelText = null;

    private boolean isInvalid = false;

    private int airORsea = -1;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reboxing_add);

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        merchant_id = getIntent().getIntExtra("merchant_id",0);

        reBoxBtn.setText(getResources().getString(R.string.unboxing_btn_label));
        boxLabel.setText(getResources().getString(R.string.unboxing_box_label));

        inVisibleBtns();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerview.setLayoutManager(layoutManager);

        adapter = new ReboxingAddAdapter(mainList,list,ReboxingAdd.this,rootlayout);
        recyclerview.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        clearAll();

        weightSpinner.setOnItemSelectedListener(this);

        boxScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(ReboxingAdd.this)){
                    boxORitem = 1;
                    openScanner();
                }else {
                    ActivityCompat.requestPermissions(ReboxingAdd.this,new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
                }
            }
        });


        boxScan.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                final Dialog dialog = new Dialog(ReboxingAdd.this);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
                barcodeText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(8)});

                search.setText(R.string.ok);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){
                            if (barcode.length() == 8){

                                if (Utils.broadcastIntent(ReboxingAdd.this,rootlayout)){
                                    isRebox(barcode);
                                    dialog.dismiss();
                                }else {
                                    dialog.dismiss();
                                    Utils.snackbarToast(rootlayout,"No internet connection!");
                                }
                            }else {
                                Toast.makeText(ReboxingAdd.this,"This is not Box Label!",Toast.LENGTH_LONG).show();
                            }

                        }else {
                            Toast.makeText(ReboxingAdd.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });


                return false;
            }
        });



        scanItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(ReboxingAdd.this)){
                    boxORitem = 2;
                    openScanner();
                }else {
                    ActivityCompat.requestPermissions(ReboxingAdd.this,new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
                }
            }
        });

        scanItem.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                final Dialog dialog = new Dialog(ReboxingAdd.this);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);


                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){
                            if (Utils.broadcastIntent(ReboxingAdd.this,rootlayout)){
                                getItem(barcode);
                                dialog.dismiss();
                            }else {
                                dialog.dismiss();
                                Utils.snackbarToast(rootlayout,"No internet connection!");
                            }
                        }else {
                            Toast.makeText(ReboxingAdd.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });

                return false;
            }
        });

        reBoxBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(ReboxingAdd.this,rootlayout)){
                    if (list.size() > 0){
                        if (!TextUtils.isEmpty(boxLabelText)){

                            final Dialog dialog = new Dialog(ReboxingAdd.this);
                            dialog.setContentView(R.layout.transparent_progress_dialoge);

                            int width = WindowManager.LayoutParams.WRAP_CONTENT;
                            int height = WindowManager.LayoutParams.WRAP_CONTENT;

                            dialog.getWindow().setLayout(width,height);
                            dialog.setCancelable(false);
                            dialog.show();

                            String token = SharedPreperenceUtils.getToken(ReboxingAdd.this);
                            int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(ReboxingAdd.this));
                            String boxHeightIns = boxHeight.getText().toString();
                            String boxWidthIns = boxWidth.getText().toString();
                            String boxLengthIns = boxLength.getText().toString();
                            String boxWeightIns = boxWeight.getText().toString();

                            if (TextUtils.isEmpty(boxHeightIns)){
                                boxHeightIns = "";
                            }
                            if (TextUtils.isEmpty(boxWidthIns)){
                                boxWidthIns = "";
                            }
                            if (TextUtils.isEmpty(boxLengthIns)){
                                boxLengthIns = "";
                            }
                            if (TextUtils.isEmpty(boxWeightIns)){
                                boxWeightIns = "";
                            }

                            final BoxingItemPost post = new BoxingItemPost();
                            post.is_update = 1;
                            post.box_label = boxLabelText;
                            post.user_id = user_id;
                            post.height = boxHeightIns;
                            post.width = boxWidthIns;
                            post.length = boxLengthIns;
                            post.weight = boxWeightIns;
                            post.merchant_id = merchant_id;
                            post.data = list;

                            Log.e("reBoxing add post", "msg"+new Gson().toJson(post));

                            compositeDisposable.add(mIRetrofitApi.boxing(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<BoxingResponse>() {
                                @Override
                                public void accept(BoxingResponse response) throws Exception {
                                    if (response.status == 1){
                                        Snackbar snackbar = Snackbar.make(rootlayout,""+response.message,Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                        dialog.dismiss();

                                        clearAll();
                                        adapter.addItem(mainList,list);
                                    }else {
                                        dialog.dismiss();

                                        if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                            Utils.expiredTokenAlert(rootlayout,ReboxingAdd.this);
                                        }else {
//                                            Utils.snackbarToast(rootlayout,response.message);
                                            Snackbar snackbar = Snackbar.make(rootlayout, "" + response.message, 10000);
                                            snackbar.show();
                                        }
                                    }
                                }
                            }, new Consumer<Throwable>() {
                                @Override
                                public void accept(Throwable throwable) throws Exception {

                                    dialog.dismiss();

                                    if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                        Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 15000);
                                        snackbar.show();
                                    }else {
                                        Snackbar snackbar = Snackbar.make(rootlayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                    }
                                }
                            }));


                        }else {
                            Snackbar snackbar = Snackbar.make(rootlayout," Please Scan Box Label!",Snackbar.LENGTH_LONG);
                            snackbar.show();
                        }
                    }else {
                        Snackbar snackbar = Snackbar.make(rootlayout,"Scan Minimum One Item!",Snackbar.LENGTH_LONG);
                        snackbar.show();
                    }
                }else {
                    Snackbar snackbar = Snackbar.make(rootlayout,"No internet connection!",Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // ....................... Box Dimension .......................
        if (Utils.broadcastIntent(this,rootlayout)){
            getBoxDimension();
        }

    }

    public static void shareableListUpdate(List<BoxingItemSubModel> postList){
        list = postList;
    }

    public static void visibleBtns(){
        reBoxBtn.setVisibility(View.VISIBLE);
        scanItem.setVisibility(View.VISIBLE);
        boxWeightLayout.setVisibility(View.VISIBLE);
    }

    public static void inVisibleBtns(){
        reBoxBtn.setVisibility(View.GONE);
        scanItem.setVisibility(View.GONE);
        boxWeightLayout.setVisibility(View.GONE);
    }

    private void initialFindFields() {
        rootlayout = (CoordinatorLayout)findViewById(R.id.reboxingAddRootLayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.reboxingAddToolbarID);
        scanItem = (LinearLayout) findViewById(R.id.reboxingAddScanItemIconID);
        //scanItemText = (TextView)findViewById(R.id.unboxingScantItemTextID);
        recyclerview = (RecyclerView)findViewById(R.id.reboxingAddItemRecyclerID);
        boxScan = (LinearLayout)findViewById(R.id.boxingBoxID);
        boxLabel = (TextView)findViewById(R.id.boxingBoxLebelID);
        reBoxBtn = (Button)findViewById(R.id.boxingEndBoxBtnID);

        boxHeight = (EditText) findViewById(R.id.boxingHeightID);
        boxWidth = (EditText) findViewById(R.id.boxingWidthID);
        boxLength = (EditText) findViewById(R.id.boxingLengthID);
        boxWeight = (EditText) findViewById(R.id.boxingWeightID);
        weightSpinner = (Spinner) findViewById(R.id.boxWeightSpinnerID);
        boxWeightLayout = (View) findViewById(R.id.reboxingWeightLayoutID);
    }

    private void openScanner(){
        scannerDialog = new Dialog(ReboxingAdd.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


        isCameraOpen = true;
        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(ReboxingAdd.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                isCameraOpen = false;
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootlayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootlayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootlayout,"No Internet Connection!",5000);
            snackbar.show();
        }
    }

    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mIRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ApiResponse>() {
            @Override
            public void accept(ApiResponse response) throws Exception {
                if (response.status == 0) {
                    isInvalid = true;
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));

        return isInvalid;
    }

    @Override
    public void onBackPressed() {
       clearAll();

        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        clearAll();
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }


    @Override
    public void handleResult(Result rawResult) {
        if (!TextUtils.isEmpty(rawResult.getText())){
            if (boxORitem == 1){
                if (rawResult.getText().length() == 8){
                    if (Utils.broadcastIntent(this,rootlayout)){
                        isCameraOpen = true;
                        isRebox(rawResult.getText());
                        scannerDialog.dismiss();
                    }else {
                        wrongTone.start();
                        isCameraOpen = false;
                        scannerDialog.dismiss();
                        Utils.snackbarToast(rootlayout,"No internet connection!");
                    }
                }else {
                    wrongTone.start();
                    isCameraOpen = false;
                    scannerDialog.dismiss();
                    Utils.snackbarToast(rootlayout,"This is not box label!");
                }
            }else if (boxORitem == 2){
                if (Utils.broadcastIntent(this,rootlayout)){
                    isCameraOpen = true;
                    getItem(rawResult.getText());
                    scannerDialog.dismiss();
                }else {
                    wrongTone.start();
                    isCameraOpen = false;
                    scannerDialog.dismiss();
                    Utils.snackbarToast(rootlayout,"No internet connection!");
                }
            }
        }else {
            wrongTone.start();
            isCameraOpen = false;
            scannerDialog.dismiss();
            Utils.snackbarToast(rootlayout,"Barcode is empty!");
        }
    }

    private void clearAll(){
        list = new ArrayList<>();
        mainList = new ArrayList<>();
        tempList = new ArrayList<>();

        boxLabelText = "";
        airORsea = -1;

        reBoxBtn.setText(getResources().getString(R.string.unboxing_btn_label));
        boxLabel.setText(getResources().getString(R.string.unboxing_box_label));

        boxWeight.setText("");
        boxHeight.setText("");
        boxLength.setText("");
        boxWidth.setText("");
        //weightSpinner.setSelection(0);
        //weightSpinner.setVisibility(View.GONE);
        inVisibleBtns();
    }

    private void isRebox(final String barcode){

        clearAll();

        final String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(ReboxingAdd.this));

        final ReboxingOpenPost openPost = new ReboxingOpenPost();
        openPost.box_label = barcode;
        openPost.user_id = user_id;
        openPost.merchant_id = merchant_id;

        compositeDisposable.add(mIRetrofitApi.reboxingAddBoxOpen(token,openPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
            if (response.status == 1){
                rightTone.start();
                visibleBtns();
                if (barcode.startsWith("1")){
                    airORsea = 1;
                } else if (barcode.startsWith("2")){
                    airORsea = 0;
                } else if (barcode.startsWith("3")){
                    airORsea = 1;
                } else if (barcode.startsWith("4")){
                    airORsea = 0;
                }
                boxLabelText = barcode;
                boxLabel.setText("Box Label : "+barcode);

                boxHeight.setText(""+response.data.height);
                boxWeight.setText(""+response.data.weight);
                boxWidth.setText(""+response.data.width);
                boxLength.setText(""+response.data.length);

//                    boxHeight.setEnabled(false);
//                    boxWidth.setEnabled(false);
//                    boxLength.setEnabled(false);

                Utils.snackbarToast(rootlayout,""+response.message);
            }else {
                wrongTone.start();

                if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                    Utils.expiredTokenAlert(rootlayout,ReboxingAdd.this);
                }else {
                    Utils.snackbarToast(rootlayout,response.message);
                }
            }
        }, throwable -> {
            wrongTone.start();

            if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 5000);
                snackbar.show();
            }else {
                Snackbar snackbar = Snackbar.make(rootlayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                snackbar.show();
            }
        }));
    }

    private void getItem(final String barcode){
        final String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(ReboxingAdd.this));

        final StockCheckPost checkPost = new StockCheckPost();
        checkPost.user_id = user_id;
        checkPost.barcode = barcode;
        checkPost.sku_id = "";
        checkPost.mkt_id = "";
        checkPost.product_name = "";
        checkPost.merchant_pk = merchant_id;

        if (merchant_id > 0) {
            compositeDisposable.add(mIRetrofitApi.getMerchantBoxingItem(token,checkPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {

                if (response.status == 1){

                    rightTone.start();

                    tempList = response.data;

                    int checkQty = 0;
                    if (list.size() > 0){

                        for (int i = 0; i <list.size(); i++){
                            if (response.data.get(0).sku_id.equals(list.get(i).sku_id)){
                                checkQty += list.get(i).qty;
                            }
                        }
                    }

                    if ((response.data.get(0).available_qty - checkQty) > 0){

                        if (airORsea == tempList.get(0).is_air){



                            final Dialog qtyDialog = new Dialog(ReboxingAdd.this);
                            qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                            int width = WindowManager.LayoutParams.MATCH_PARENT;
                            int height = WindowManager.LayoutParams.WRAP_CONTENT;

                            qtyDialog.getWindow().setLayout(width,height);
                            qtyDialog.setCancelable(false);
                            qtyDialog.show();

                            final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                            Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                            Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                            TextView msg = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);


                            ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                            TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                            TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                            TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                            String insPrimaryImage = Common.BASEURL_PICTURE + tempList.get(0).primary_image;

                            if (tempList.get(0).variant_primary_image == null || tempList.get(0).variant_primary_image.equals("")) {
                                Glide.with(ReboxingAdd.this)
                                        .load(insPrimaryImage)
                                        .placeholder(R.drawable.ic_default)
                                        .into(cardImage);
                            } else {
                                String insVariantImage = Common.BASEURL_PICTURE + tempList.get(0).variant_primary_image;


                                Glide.with(ReboxingAdd.this)
                                        .load(insVariantImage)
                                        .placeholder(R.drawable.ic_default)
                                        .into(cardImage);
                            }


                            if (tempList.get(0).variant_name == null || tempList.get(0).variant_name.equals("")) {
                                cardName.setText(tempList.get(0).product_name);
                            } else {
                                cardName.setText(tempList.get(0).variant_name);
                            }

                            cardColor.setText("Color : " + tempList.get(0).color);
                            cardSize.setText("Size : " + tempList.get(0).size);


                            msg.setText("Avl Qty : "+(tempList.get(0).available_qty - checkQty));

                            cancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //scannerDialog.dismiss();
                                    qtyDialog.dismiss();
                                }
                            });


                            final int finalCheckQty = checkQty;
                            ok.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (!TextUtils.isEmpty(qty.getText())){
                                        String string = qty.getText().toString();
                                        int quantity = Integer.parseInt(string);
                                        if (quantity <= (tempList.get(0).available_qty - finalCheckQty)){

                                            if (quantity == 0){
                                                quantity = 1;
                                            }

                                            final BoxingItemSubModel subModel = new BoxingItemSubModel();

                                            subModel.barcode = barcode;
                                            subModel.qty = quantity;
                                            subModel.sku_id = tempList.get(0).sku_id;

                                            list.add(subModel);


                                            BoxingItemResponse.Data item = new BoxingItemResponse.Data();
                                            item.PK_NO = tempList.get(0).PK_NO;
                                            item.primary_image = tempList.get(0).primary_image;
                                            item.variant_primary_image = tempList.get(0).variant_primary_image;
                                            item.color = tempList.get(0).color;
                                            item.is_air = tempList.get(0).is_air;
                                            item.mkt_id = tempList.get(0).mkt_id;
                                            item.size = tempList.get(0).size;
                                            item.sku_id = tempList.get(0).sku_id;
                                            item.variant_name = tempList.get(0).variant_name;
                                            item.product_name = tempList.get(0).product_name;
                                            item.available_qty = tempList.get(0).available_qty;

                                            mainList.add(item);
                                            adapter.addItem(mainList,list);
                                            qtyDialog.dismiss();
                                            //scannerDialog.dismiss();

                                            Toast.makeText(ReboxingAdd.this, "List Size : "+list.size(), Toast.LENGTH_SHORT).show();

                                        }else {
                                            qty.requestFocus();
                                            Toast toast = Toast.makeText(ReboxingAdd.this, "Enter less then or equal : "+tempList.get(0).available_qty, Toast.LENGTH_SHORT);
                                            TextView toastMessage = (TextView) toast.getView().findViewById(android.R.id.message);
                                            toastMessage.setTextColor(Color.WHITE);
                                            toast.show();
                                        }
                                    }else {
                                        Toast.makeText(ReboxingAdd.this, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                                    }

                                }
                            });

                        }else {
                            final Dialog airSeaAertDialoge = new Dialog(ReboxingAdd.this);
                            airSeaAertDialoge.setContentView(R.layout.dialoge_exit);

                            int width = WindowManager.LayoutParams.MATCH_PARENT;
                            int height = WindowManager.LayoutParams.WRAP_CONTENT;

                            airSeaAertDialoge.getWindow().setLayout(width,height);
                            airSeaAertDialoge.setCancelable(false);
                            airSeaAertDialoge.show();

                            Button cancel = airSeaAertDialoge.findViewById(R.id.dialogeExitCancelID);
                            Button ok = airSeaAertDialoge.findViewById(R.id.dialogeExitOkID);
                            TextView msg = airSeaAertDialoge.findViewById(R.id.dialogeExitTextMsgID);

                            if (airORsea == 1){
                                msg.setText("This product is not Air's product");
                            }else if (airORsea == 0){
                                msg.setText("This product is not Sea's product");
                            }


                            ok.setText("Add");

                            cancel.setOnClickListener(v -> {
                                airSeaAertDialoge.dismiss();
                                //scannerDialog.dismiss();
                            });

                            final int finalCheckQty1 = checkQty;
                            ok.setOnClickListener(v -> {
                                airSeaAertDialoge.dismiss();
                                final Dialog qtyDialog = new Dialog(ReboxingAdd.this);
                                qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                                int width1 = WindowManager.LayoutParams.MATCH_PARENT;
                                int height1 = WindowManager.LayoutParams.WRAP_CONTENT;

                                qtyDialog.getWindow().setLayout(width1, height1);
                                qtyDialog.setCancelable(false);
                                qtyDialog.show();

                                final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                                Button cancel1 = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                                Button ok1 = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                                TextView d_avl_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);


                                ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                                TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                                TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                                TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                                String insPrimaryImage = Common.BASEURL_PICTURE + tempList.get(0).primary_image;

                                if (tempList.get(0).variant_primary_image == null || tempList.get(0).variant_primary_image.equals("")) {
                                    Glide.with(ReboxingAdd.this)
                                            .load(insPrimaryImage)
                                            .placeholder(R.drawable.ic_default)
                                            .into(cardImage);
                                } else {
                                    String insVariantImage = Common.BASEURL_PICTURE + tempList.get(0).variant_primary_image;


                                    Glide.with(ReboxingAdd.this)
                                            .load(insVariantImage)
                                            .placeholder(R.drawable.ic_default)
                                            .into(cardImage);
                                }


                                if (tempList.get(0).variant_name == null || tempList.get(0).variant_name.equals("")) {
                                    cardName.setText(tempList.get(0).product_name);
                                } else {
                                    cardName.setText(tempList.get(0).variant_name);
                                }

                                cardColor.setText("Color : " + tempList.get(0).color);
                                cardSize.setText("Size : " + tempList.get(0).size);


                                d_avl_qty.setText("Avl Qty : "+(tempList.get(0).available_qty - finalCheckQty1));

                                cancel1.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        //scannerDialog.dismiss();
                                        qtyDialog.dismiss();
                                    }
                                });


                                ok1.setOnClickListener(v1 -> {
                                    if (!TextUtils.isEmpty(qty.getText())){
                                        String string = qty.getText().toString();
                                        int quantity = Integer.parseInt(string);
                                        if (quantity <= (tempList.get(0).available_qty - finalCheckQty1)){

                                            final BoxingItemSubModel subModel = new BoxingItemSubModel();

                                            subModel.barcode = barcode;
                                            subModel.qty = quantity;
                                            subModel.sku_id = tempList.get(0).sku_id;

                                            list.add(subModel);


                                            BoxingItemResponse.Data item = new BoxingItemResponse.Data();
                                            item.PK_NO = tempList.get(0).PK_NO;
                                            item.primary_image = tempList.get(0).primary_image;
                                            item.variant_primary_image = tempList.get(0).variant_primary_image;
                                            item.color = tempList.get(0).color;
                                            item.is_air = tempList.get(0).is_air;
                                            item.mkt_id = tempList.get(0).mkt_id;
                                            item.size = tempList.get(0).size;
                                            item.sku_id = tempList.get(0).sku_id;
                                            item.variant_name = tempList.get(0).variant_name;
                                            item.product_name = tempList.get(0).product_name;
                                            item.available_qty = tempList.get(0).available_qty;

                                            mainList.add(item);
                                            adapter.addItem(mainList,list);
                                            qtyDialog.dismiss();
                                            //scannerDialog.dismiss();

                                            Toast.makeText(ReboxingAdd.this, "List Size : "+list.size(), Toast.LENGTH_SHORT).show();

                                        }else {
                                            qty.requestFocus();
                                            Toast toast = Toast.makeText(ReboxingAdd.this, "Enter less then or equal : "+tempList.get(0).available_qty, Toast.LENGTH_SHORT);
                                            TextView toastMessage = (TextView) toast.getView().findViewById(android.R.id.message);
                                            toastMessage.setTextColor(Color.WHITE);
                                            toast.show();
                                        }
                                    }else {
                                        Toast.makeText(ReboxingAdd.this, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                                    }

                                });
                            });
                        }

                    }else {
                        //scannerDialog.dismiss();
                        Utils.snackbarToast(rootlayout,"Product not available for scan!");
                    }



                }else {
                    wrongTone.start();
                    //scannerDialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootlayout,ReboxingAdd.this);
                    }else {
                        Utils.snackbarToast(rootlayout,response.message);
                    }
                }

            }, throwable -> {
                wrongTone.start();
                //scannerDialog.dismiss();

                if (Objects.requireNonNull(throwable.getMessage()).toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootlayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }));
        } else {
            compositeDisposable.add(mIRetrofitApi.getBoxingItem(token,checkPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {

                if (response.status == 1){

                    rightTone.start();

                    tempList = response.data;

                    int checkQty = 0;
                    if (list.size() > 0){

                        for (int i = 0; i <list.size(); i++){
                            if (response.data.get(0).sku_id.equals(list.get(i).sku_id)){
                                checkQty += list.get(i).qty;
                            }
                        }
                    }

                    if ((response.data.get(0).available_qty - checkQty) > 0){

                        if (airORsea == tempList.get(0).is_air){



                            final Dialog qtyDialog = new Dialog(ReboxingAdd.this);
                            qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                            int width = WindowManager.LayoutParams.MATCH_PARENT;
                            int height = WindowManager.LayoutParams.WRAP_CONTENT;

                            qtyDialog.getWindow().setLayout(width,height);
                            qtyDialog.setCancelable(false);
                            qtyDialog.show();

                            final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                            Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                            Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                            TextView msg = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);


                            ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                            TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                            TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                            TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                            String insPrimaryImage = Common.BASEURL_PICTURE + tempList.get(0).primary_image;

                            if (tempList.get(0).variant_primary_image == null || tempList.get(0).variant_primary_image.equals("")) {
                                Glide.with(ReboxingAdd.this)
                                        .load(insPrimaryImage)
                                        .placeholder(R.drawable.ic_default)
                                        .into(cardImage);
                            } else {
                                String insVariantImage = Common.BASEURL_PICTURE + tempList.get(0).variant_primary_image;


                                Glide.with(ReboxingAdd.this)
                                        .load(insVariantImage)
                                        .placeholder(R.drawable.ic_default)
                                        .into(cardImage);
                            }


                            if (tempList.get(0).variant_name == null || tempList.get(0).variant_name.equals("")) {
                                cardName.setText(tempList.get(0).product_name);
                            } else {
                                cardName.setText(tempList.get(0).variant_name);
                            }

                            cardColor.setText("Color : " + tempList.get(0).color);
                            cardSize.setText("Size : " + tempList.get(0).size);


                            msg.setText("Avl Qty : "+(tempList.get(0).available_qty - checkQty));

                            cancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //scannerDialog.dismiss();
                                    qtyDialog.dismiss();
                                }
                            });


                            final int finalCheckQty = checkQty;
                            ok.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (!TextUtils.isEmpty(qty.getText())){
                                        String string = qty.getText().toString();
                                        int quantity = Integer.parseInt(string);
                                        if (quantity <= (tempList.get(0).available_qty - finalCheckQty)){

                                            if (quantity == 0){
                                                quantity = 1;
                                            }

                                            final BoxingItemSubModel subModel = new BoxingItemSubModel();

                                            subModel.barcode = barcode;
                                            subModel.qty = quantity;
                                            subModel.sku_id = tempList.get(0).sku_id;

                                            list.add(subModel);


                                            BoxingItemResponse.Data item = new BoxingItemResponse.Data();
                                            item.PK_NO = tempList.get(0).PK_NO;
                                            item.primary_image = tempList.get(0).primary_image;
                                            item.variant_primary_image = tempList.get(0).variant_primary_image;
                                            item.color = tempList.get(0).color;
                                            item.is_air = tempList.get(0).is_air;
                                            item.mkt_id = tempList.get(0).mkt_id;
                                            item.size = tempList.get(0).size;
                                            item.sku_id = tempList.get(0).sku_id;
                                            item.variant_name = tempList.get(0).variant_name;
                                            item.product_name = tempList.get(0).product_name;
                                            item.available_qty = tempList.get(0).available_qty;

                                            mainList.add(item);
                                            adapter.addItem(mainList,list);
                                            qtyDialog.dismiss();
                                            //scannerDialog.dismiss();

                                            Toast.makeText(ReboxingAdd.this, "List Size : "+list.size(), Toast.LENGTH_SHORT).show();

                                        }else {
                                            qty.requestFocus();
                                            Toast toast = Toast.makeText(ReboxingAdd.this, "Enter less then or equal : "+tempList.get(0).available_qty, Toast.LENGTH_SHORT);
                                            TextView toastMessage = (TextView) toast.getView().findViewById(android.R.id.message);
                                            toastMessage.setTextColor(Color.WHITE);
                                            toast.show();
                                        }
                                    }else {
                                        Toast.makeText(ReboxingAdd.this, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                                    }

                                }
                            });

                        }else {
                            final Dialog airSeaAertDialoge = new Dialog(ReboxingAdd.this);
                            airSeaAertDialoge.setContentView(R.layout.dialoge_exit);

                            int width = WindowManager.LayoutParams.MATCH_PARENT;
                            int height = WindowManager.LayoutParams.WRAP_CONTENT;

                            airSeaAertDialoge.getWindow().setLayout(width,height);
                            airSeaAertDialoge.setCancelable(false);
                            airSeaAertDialoge.show();

                            Button cancel = airSeaAertDialoge.findViewById(R.id.dialogeExitCancelID);
                            Button ok = airSeaAertDialoge.findViewById(R.id.dialogeExitOkID);
                            TextView msg = airSeaAertDialoge.findViewById(R.id.dialogeExitTextMsgID);

                            if (airORsea == 1){
                                msg.setText("This product is not Air's product");
                            }else if (airORsea == 0){
                                msg.setText("This product is not Sea's product");
                            }


                            ok.setText("Add");

                            cancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    airSeaAertDialoge.dismiss();
                                    //scannerDialog.dismiss();
                                }
                            });

                            final int finalCheckQty1 = checkQty;
                            ok.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    airSeaAertDialoge.dismiss();
                                    final Dialog qtyDialog = new Dialog(ReboxingAdd.this);
                                    qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                                    int width = WindowManager.LayoutParams.MATCH_PARENT;
                                    int height = WindowManager.LayoutParams.WRAP_CONTENT;

                                    qtyDialog.getWindow().setLayout(width,height);
                                    qtyDialog.setCancelable(false);
                                    qtyDialog.show();

                                    final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                                    Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                                    Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                                    TextView d_avl_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);


                                    ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                                    TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                                    TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                                    TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                                    String insPrimaryImage = Common.BASEURL_PICTURE + tempList.get(0).primary_image;

                                    if (tempList.get(0).variant_primary_image == null || tempList.get(0).variant_primary_image.equals("")) {
                                        Glide.with(ReboxingAdd.this)
                                                .load(insPrimaryImage)
                                                .placeholder(R.drawable.ic_default)
                                                .into(cardImage);
                                    } else {
                                        String insVariantImage = Common.BASEURL_PICTURE + tempList.get(0).variant_primary_image;


                                        Glide.with(ReboxingAdd.this)
                                                .load(insVariantImage)
                                                .placeholder(R.drawable.ic_default)
                                                .into(cardImage);
                                    }


                                    if (tempList.get(0).variant_name == null || tempList.get(0).variant_name.equals("")) {
                                        cardName.setText(tempList.get(0).product_name);
                                    } else {
                                        cardName.setText(tempList.get(0).variant_name);
                                    }

                                    cardColor.setText("Color : " + tempList.get(0).color);
                                    cardSize.setText("Size : " + tempList.get(0).size);


                                    d_avl_qty.setText("Avl Qty : "+(tempList.get(0).available_qty - finalCheckQty1));

                                    cancel.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            //scannerDialog.dismiss();
                                            qtyDialog.dismiss();
                                        }
                                    });


                                    ok.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            if (!TextUtils.isEmpty(qty.getText())){
                                                String string = qty.getText().toString();
                                                int quantity = Integer.parseInt(string);
                                                if (quantity <= (tempList.get(0).available_qty - finalCheckQty1)){

                                                    final BoxingItemSubModel subModel = new BoxingItemSubModel();

                                                    subModel.barcode = barcode;
                                                    subModel.qty = quantity;
                                                    subModel.sku_id = tempList.get(0).sku_id;

                                                    list.add(subModel);


                                                    BoxingItemResponse.Data item = new BoxingItemResponse.Data();
                                                    item.PK_NO = tempList.get(0).PK_NO;
                                                    item.primary_image = tempList.get(0).primary_image;
                                                    item.variant_primary_image = tempList.get(0).variant_primary_image;
                                                    item.color = tempList.get(0).color;
                                                    item.is_air = tempList.get(0).is_air;
                                                    item.mkt_id = tempList.get(0).mkt_id;
                                                    item.size = tempList.get(0).size;
                                                    item.sku_id = tempList.get(0).sku_id;
                                                    item.variant_name = tempList.get(0).variant_name;
                                                    item.product_name = tempList.get(0).product_name;
                                                    item.available_qty = tempList.get(0).available_qty;

                                                    mainList.add(item);
                                                    adapter.addItem(mainList,list);
                                                    qtyDialog.dismiss();
                                                    //scannerDialog.dismiss();

                                                    Toast.makeText(ReboxingAdd.this, "List Size : "+list.size(), Toast.LENGTH_SHORT).show();

                                                }else {
                                                    qty.requestFocus();
                                                    Toast toast = Toast.makeText(ReboxingAdd.this, "Enter less then or equal : "+tempList.get(0).available_qty, Toast.LENGTH_SHORT);
                                                    TextView toastMessage = (TextView) toast.getView().findViewById(android.R.id.message);
                                                    toastMessage.setTextColor(Color.WHITE);
                                                    toast.show();
                                                }
                                            }else {
                                                Toast.makeText(ReboxingAdd.this, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                                            }

                                        }
                                    });
                                }
                            });
                        }

                    }else {
                        //scannerDialog.dismiss();
                        Utils.snackbarToast(rootlayout,"Product not available for scan!");
                    }



                }else {
                    wrongTone.start();
                    //scannerDialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootlayout,ReboxingAdd.this);
                    }else {
                        Utils.snackbarToast(rootlayout,response.message);
                    }
                }

            }, throwable -> {
                wrongTone.start();
                //scannerDialog.dismiss();

                if (Objects.requireNonNull(throwable.getMessage()).toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootlayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }));
        }
    }

    private void getBoxDimension() {
        dimensionTextList = new ArrayList<>();
        final String token = SharedPreperenceUtils.getToken(this);
        compositeDisposable.add(mIRetrofitApi.getBoxDimensionList(token).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<BoxWeightResponse>() {
            @Override
            public void accept(BoxWeightResponse response) throws Exception {
                if (response.status == 1){
                    boxWeightList = response.data;
                    dimensionTextList.add("Select box dimension");
                    for (int i = 0; i < boxWeightList.size(); i++){
                        dimensionTextList.add(boxWeightList.get(i).dimension_text);
                    }
                    spinnerAdapter = new ArrayAdapter<String>(ReboxingAdd.this, android.R.layout.simple_expandable_list_item_1, dimensionTextList);
                    spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    weightSpinner.setAdapter(spinnerAdapter);
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (position != 0){
            boxHeight.setText(""+boxWeightList.get((position-1)).height);
            boxWidth.setText(""+boxWeightList.get((position-1)).width);
            boxLength.setText(""+boxWeightList.get((position-1)).length);
        }
//        else if (position == 0){
//            boxHeight.setText("");
//            boxWidth.setText("");
//            boxLength.setText("");
//            boxWeight.setText("");
//        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}