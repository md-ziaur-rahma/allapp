package com.example.ukshop.Models;

public class ProductListModel {
    private int image;
    private String barcode;
    private String productName;
    private String productBrand;
    private String productSize;
    private String productPrice;

    public ProductListModel() {
    }

    public ProductListModel(int image, String barcode, String productName,
                            String productBrand, String productSize, String productPrice) {
        this.image = image;
        this.barcode = barcode;
        this.productName = productName;
        this.productBrand = productBrand;
        this.productSize = productSize;
        this.productPrice = productPrice;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductBrand() {
        return productBrand;
    }

    public void setProductBrand(String productBrand) {
        this.productBrand = productBrand;
    }

    public String getProductSize() {
        return productSize;
    }

    public void setProductSize(String productSize) {
        this.productSize = productSize;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }
}
