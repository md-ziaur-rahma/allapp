package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.ukshop.Adapters.BookingItemAdapter;
import com.example.ukshop.Models.BookingItemModel;
import com.example.ukshop.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class BookingPage extends AppCompatActivity {

    private List<BookingItemModel> list = new ArrayList<>();
    private BookingItemAdapter adapter;
    private RecyclerView recyclerView;

    private Date d;

    private String diviceId = null;


    // purchase activitie's variable...
    private EditText code,name,brand,size,price,qnt;
    private Button productAddBtn;
    private ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_page);

        //getSupportActionBar().hide();


        // Current date for add product...
        d = Calendar.getInstance().getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm");
        String date = formatter.format(d);

        //required
        initialFindField();
        // get Device Id..
        deviceID();


        // Layoutmanager for recyclerView...
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);


        // this list for testing purchase product...
        list.add(new BookingItemModel(R.drawable.backpack,"123435","Backpack(123),gorgeus","Italian","Small","1200","100",date));
        list.add(new BookingItemModel(R.drawable.backpack_b,"547875","Backpack(456),normal","Chinease","Medium","4500","200",date));
        list.add(new BookingItemModel(R.drawable.backpack_g,"002234","Backpack(123),medium","Indian","Large","2290","150",date));
        list.add(new BookingItemModel(R.drawable.shirt_e,"123421","Backpack(123),gorgeus","USA","Normal","1800","1200",date));
        list.add(new BookingItemModel(R.drawable.shirt_a,"098778","Backpack(123),normal","Bangladeshi","Large","1900","450",date));


        // set adapter with recyclerView...
        adapter = new BookingItemAdapter(list,this);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();


        productAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkData()){

                    d = Calendar.getInstance().getTime();
                    SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm");
                    String date = formatter.format(d);


                    BookingItemModel model = null;

                    list.add(new BookingItemModel(R.drawable.ankle_boots,code.getText().toString(),
                            name.getText().toString(),brand.getText().toString(),size.getText().toString()
                    ,price.getText().toString(),qnt.getText().toString(),date));

                    Log.e("msg","Add a item by "+diviceId);

                    //adding item...
                    addCurrentPurchasesItem();


                    // clear all field...
                    clearAllField();



                }
            }
        });

    }


    private void clearAllField(){

        code.setText("");
        name.setText("");
        brand.setText("");
        size.setText("");
        price.setText("");
        qnt.setText("");
    }

    /// Find all field...
    private void initialFindField(){
        recyclerView = (RecyclerView)findViewById(R.id.bookingRecyclerID);

        image = (ImageView)findViewById(R.id.bookingImageID);
        code = (EditText)findViewById(R.id.bookingProductCodeID);
        name = (EditText)findViewById(R.id.bookingProductNameID);
        brand = (EditText)findViewById(R.id.bookingProductBrandID);
        size = (EditText)findViewById(R.id.bookingProductSizeID);
        price = (EditText)findViewById(R.id.bookingProductPriceID);
        qnt = (EditText)findViewById(R.id.bookingProductQuantityID);

        productAddBtn = (Button)findViewById(R.id.bookingProductAddBtnID);

    }

    // add new purchase product item into list...
    private void addCurrentPurchasesItem(){
        adapter.newList(list);
    }

    private boolean checkData(){

        boolean isTrue = false;

        if (!TextUtils.isEmpty(name.getText()) && !TextUtils.isEmpty(brand.getText())
                && !TextUtils.isEmpty(size.getText()) && !TextUtils.isEmpty(code.getText())
                && !TextUtils.isEmpty(price.getText()) && !TextUtils.isEmpty(qnt.getText())){
            isTrue = true;
        }else {
            Toast.makeText(this, "Fill the all fields", Toast.LENGTH_SHORT).show();
            isTrue = false;
        }

        return isTrue;
    }

    /// Read the device info..
    public void deviceID() {
        final TelephonyManager tm =
                (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);
        final String deviceID, serialNumber, androidID;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {

            String[] per = {Manifest.permission.READ_PHONE_STATE};
            requestPermissions(per, 1);
            return;
        }

        diviceId = ""+tm.getDeviceId();
        deviceID = "Device ID : " + tm.getDeviceId();
        serialNumber = "\nSim Serial Number : "+tm.getSimSerialNumber();
        androidID = "\nandroid ID : "+ android.provider.Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        String sv = "\nSoftware version : "+tm.getDeviceSoftwareVersion();
        String SimOp ="\nSim Operator : "+ tm.getSimOperatorName();
        //String xxx = "\n"+tm.getImei();
        String subscriberId = "\nsubscriber ID :"+tm.getSubscriberId();

    }
}