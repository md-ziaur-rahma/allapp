package com.example.ukshop.Adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.example.ukshop.Models.ProductListViewPagerModel;
import com.example.ukshop.R;

import java.util.List;

public class ProductListViewpagerAdapter extends PagerAdapter {

    private List<ProductListViewPagerModel> list;
    private int tabCount;

    public ProductListViewpagerAdapter(List<ProductListViewPagerModel> list, int tabCount) {
        this.list = list;
        this.tabCount = tabCount;
    }

    @Override
    public int getCount() {
        return tabCount;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View)object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view = LayoutInflater.from(container.getContext())
                .inflate(R.layout.product_list_viewpager_image_layout,container,false);

        ImageView image = view.findViewById(R.id.productListViewpagerImageID);
        image.setImageResource(list.get(position).getImage());

        container.addView(view,0);
        return view;
    }
}
