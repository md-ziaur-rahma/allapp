package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;

import com.example.ukshop.Adapters.RTSListAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.RTSPost;
import com.example.ukshop.NetworkModel.RTSResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class RtsDispatchList extends AppCompatActivity {

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;

    private RecyclerView recyclerView;
    private RTSListAdapter adapter;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private List<RTSResponse.Data> list = new ArrayList<>();
    public static int BatchNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rts_dispatch_list);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();


        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new RTSListAdapter(list,this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        if (Utils.broadcastIntent(this,rootLayout)){
            loadData();
        }else {
            NoInternetSnackBar();
        }


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                int id = item.getItemId();

                if (id == R.id.menuShipment_refreshId) {
                    if (Utils.broadcastIntent(RtsDispatchList.this,rootLayout)){
                        loadData();
                        //adapter.updateList(list);
                    }else {
                        NoInternetSnackBar();
                    }
                    return true;
                }
                return false;
            }
        });

    }

    private void initialFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.rtsRootLayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.rtsToolbarID);
        recyclerView = (RecyclerView)findViewById(R.id.rtsRecyclerID);
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (Utils.broadcastIntent(this,rootLayout)){
            loadData();
        }else {
            NoInternetSnackBar();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }



    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(RtsDispatchList.this,rootLayout)){
                    loadData();
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }

    private void loadData(){
        list = new ArrayList<>();
        adapter.updateList(list);

        final Dialog dialog = new Dialog(RtsDispatchList.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        String token = SharedPreperenceUtils.getToken(RtsDispatchList.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(RtsDispatchList.this));

        final RTSPost post = new RTSPost();
        post.user_id = user_id;
        post.batch_no = BatchNo;

        Log.e("rts dispatch list", "msg"+new Gson().toJson(post));

        compositeDisposable.add(mIRetrofitApi.getRTSList(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<RTSResponse>() {
            @Override
            public void accept(RTSResponse response) throws Exception {
                if (response.status == 1){
                    list = response.data;

                    adapter.updateList(list);

                    dialog.dismiss();
//                    Snackbar snackbar = Snackbar.make(rootLayout,""+response.message,1000);
//                    snackbar.show();
                }else {
                    dialog.dismiss();
                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout,RtsDispatchList.this);
                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,response.message,5000);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (Utils.broadcastIntent(RtsDispatchList.this,rootLayout)){
                                    loadData();
                                }else {
                                    NoInternetSnackBar();
                                }
                            }
                        });

                        snackbar.show();
                    }
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.setAction("Retry", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Utils.broadcastIntent(RtsDispatchList.this,rootLayout)){
                                loadData();
                            }else {
                                NoInternetSnackBar();
                            }
                        }
                    });
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,throwable.getMessage(),5000);
                    snackbar.setAction("Retry", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Utils.broadcastIntent(RtsDispatchList.this,rootLayout)){
                                loadData();
                            }else {
                                NoInternetSnackBar();
                            }
                        }
                    });

                    snackbar.show();
                }
            }
        }));

    }

}