package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class CodRtcDispatchItemResponse extends ApiResponse{

    @SerializedName("customer_name")
    public String customer_name;

    @SerializedName("order_no")
    public String order_no;

    @SerializedName("total_amount")
    public float total_amount;

    @SerializedName("paid_amount")
    public float paid_amount;

    @SerializedName("due_amount")
    public float due_amount;

    @SerializedName("slip_no")
    public String slip_no;

    @SerializedName("data")
    public ArrayList<Data> data;

    public static class Data{
        @SerializedName("sku_id")
        public String sku_id;

        @SerializedName("PK_NO")
        public int PK_NO;

        @SerializedName("mkt_id")
        public String mkt_id;

        @SerializedName("product_name")
        public String product_name;

        @SerializedName("product_variant_name")
        public String variant_name;

        @SerializedName("size")
        public String size;

        @SerializedName("color")
        public String color;

        @SerializedName("barcode")
        public String barcode;

        @SerializedName("variant_primary_image")
        public String variant_primary_image;

        @SerializedName("primary_image")
        public String primary_image;

        @SerializedName("acknowledge")
        public int acknowledge;

        @SerializedName("is_my")
        public int is_my;

        @SerializedName("isChecked")
        public boolean isChecked;

        @SerializedName("label")
        public String label;

        @SerializedName("qty")
        public int qty;

        @SerializedName("available_qty")
        public int available_qty;

        @SerializedName("location")
        public String location;
    }
}
