package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

import com.example.ukshop.Adapters.UnboxedItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.NetworkModel.UnboxedItemPost;
import com.example.ukshop.NetworkModel.UnboxedItemResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class LandAreaItemPage extends AppCompatActivity {

    private CoordinatorLayout rootlayout;
    private NestedScrollView nestedScrollView;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;


    private RecyclerView recyclerView;
    private UnboxedItemAdapter adapter;
    private List<UnboxedItemResponse.Data> mainList = new ArrayList<>();
    private List<UnboxedItemResponse.Data> scrollList = new ArrayList<>();


    private MaterialToolbar toolbar;

    private boolean isInvalid = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unboxed_item_page);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();


        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new UnboxedItemAdapter(mainList,this);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        if (Utils.broadcastIntent(this,rootlayout)){
            loadData();
        }else {
            NoInternetSnackBar();
        }

        /// Toolbar home button...
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                if(v.getChildAt(v.getChildCount() - 1) != null) {
                    if ((scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight())) &&
                            scrollY > oldScrollY) {

                        //https://medium.com/@mujjtahidah/load-more-recyclerview-inside-nested-scroll-view-and-coordinator-layout-4f179dc01fd

                        if (!recyclerView.canScrollVertically(1)){
                            onScrollToBottom();
                        }

                    }
                }

            }
        });


        if (Utils.broadcastIntent(this,rootlayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootlayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootlayout,"No Internet Connection!",10000);
            snackbar.show();
        }

    }


    private void onScrollToBottom(){
        if (scrollList.size() < mainList.size()){
            int x,y;
            if ((mainList.size() - scrollList.size()) >= 20){
                x = scrollList.size();
                y = x + 20;
            }else {
                x = scrollList.size();
                y = x + mainList.size() - scrollList.size();
            }

            for (int i = x; i < y; i++){
                scrollList.add(i,mainList.get(i));
            }

            adapter.updateList(scrollList);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootlayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootlayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootlayout,"No Internet Connection!",10000);
            snackbar.show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mIRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ApiResponse>() {
            @Override
            public void accept(ApiResponse response) throws Exception {
                if (response.status == 0) {
                    isInvalid = true;
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));

        return isInvalid;
    }

    private void initialFindFields(){
        rootlayout = (CoordinatorLayout)findViewById(R.id.unboxedItemRootlayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.unboxedItemToolbarID);
        nestedScrollView = (NestedScrollView)findViewById(R.id.landAreaItemScrollviewID);

        recyclerView = (RecyclerView)findViewById(R.id.unboxedItemRecyclerID);
    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootlayout,"No Internet Connection!",5000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(LandAreaItemPage.this,rootlayout)){
                    loadData();
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }

    private void loadData(){
        mainList = new ArrayList<>();
        scrollList = new ArrayList<>();
        adapter.updateList(mainList);

        final Dialog dialog = new Dialog(LandAreaItemPage.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        String token = SharedPreperenceUtils.getToken(LandAreaItemPage.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(LandAreaItemPage.this));

        final UnboxedItemPost post = new UnboxedItemPost();
        post.user_id = user_id;

        Log.e("land area item post", "msg"+new Gson().toJson(post));

        compositeDisposable.add(mIRetrofitApi.getUnboxedItemList(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<UnboxedItemResponse>() {
            @Override
            public void accept(UnboxedItemResponse response) throws Exception {

                if (response.status == 1){
                    mainList = response.data;

                    if (mainList.size() >= 20){
                        for (int i = 0; i < 20; i++){
                            scrollList.add(mainList.get(i));
                        }
                    }else {
                        scrollList.addAll(mainList);
                    }

                    adapter.updateList(scrollList);

                    dialog.dismiss();
                }else {
                    dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootlayout, LandAreaItemPage.this);
                    }else {
                        Utils.snackbarToast(rootlayout,response.message);
                    }
                }

            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Utils.snackbarToast(rootlayout,throwable.getMessage());
                }
            }
        }));

    }

}