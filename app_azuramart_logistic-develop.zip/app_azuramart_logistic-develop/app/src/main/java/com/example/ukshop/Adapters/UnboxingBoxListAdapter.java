package com.example.ukshop.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.Activity.PriorityUnboxItemList;
import com.example.ukshop.NetworkModel.PriorityBoxResponse;
import com.example.ukshop.R;
import com.example.ukshop.UnboxingPage;

import java.util.List;

import static maes.tech.intentanim.CustomIntent.customType;

public class UnboxingBoxListAdapter extends RecyclerView.Adapter<UnboxingBoxListAdapter.ViewHolder> {

    private List<PriorityBoxResponse.Data> list;
    private Activity context;
    private CoordinatorLayout rootLayout;

    public UnboxingBoxListAdapter(List<PriorityBoxResponse.Data> list, Activity context, CoordinatorLayout rootLayout) {
        this.list = list;
        this.context = context;
        this.rootLayout = rootLayout;
    }

    @NonNull
    @Override
    public UnboxingBoxListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.priority_box_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UnboxingBoxListAdapter.ViewHolder holder, int position) {
        String box_label = list.get(position).box_label;
        int totalCount = list.get(position).total_item_count;
        int priorityCount = list.get(position).priority_item_count;
        int received_qty = list.get(position).unboxed_qty;

        holder.setData(box_label,totalCount,priorityCount,received_qty);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void updateList(List<PriorityBoxResponse.Data> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView box_label,totalCount, priorityCount;
        private LinearLayout countContainer;
        private Animation bounceAnimation;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            bounceAnimation = AnimationUtils.loadAnimation(context,R.anim.bounce_infinite);

            box_label = itemView.findViewById(R.id.priorityBoxLabelID);
            totalCount = itemView.findViewById(R.id.priorityItemCountID);
            priorityCount = itemView.findViewById(R.id.priorityBoxItemCountIconID);
            countContainer = itemView.findViewById(R.id.priorityBoxItemCountContainerID);

        }

        public void setData(final String box_label, final int totalCount, final int priorityCount,final int received_qty) {
            this.box_label.setText(box_label);
            this.totalCount.setText(""+received_qty+"/"+totalCount);
            this.priorityCount.setText(""+priorityCount);
            this.priorityCount.setAnimation(bounceAnimation);

            if (priorityCount == 0){
                this.countContainer.setVisibility(View.GONE);
            }else {
                this.countContainer.setVisibility(View.VISIBLE);
            }


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, UnboxingPage.class);
                    UnboxingPage.checkBoxlabel = box_label;
                    itemView.getContext().startActivity(intent);
                    customType(context,"left-to-right");
                }
            });

        }

    }
}
