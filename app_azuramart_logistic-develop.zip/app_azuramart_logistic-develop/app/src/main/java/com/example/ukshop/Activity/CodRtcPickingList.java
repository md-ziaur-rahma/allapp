package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.ukshop.Adapters.CodRtcPickingListAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.CodRtcPickingListPost;
import com.example.ukshop.NetworkModel.CodRtcPickingListResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class CodRtcPickingList extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private NestedScrollView nestedScrollView;

    private List<CodRtcPickingListResponse.Data> list = new ArrayList<>();
    private List<CodRtcPickingListResponse.Data> tempList = new ArrayList<>();
    private List<CodRtcPickingListResponse.Data> scrollList = new ArrayList<>();
    private CodRtcPickingListAdapter adapter;
    private RecyclerView recyclerView;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private Spinner spinner;
    private List<String> dropDownList = new ArrayList<>();
    private ArrayAdapter<String> spinnerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cod_rtc_dispatch_list);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        spinner.setOnItemSelectedListener(this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new CodRtcPickingListAdapter(list,this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        if (Utils.broadcastIntent(this,rootLayout)){
            loadData();
        }else {
            NoInternetSnackBar();
        }


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                int id = item.getItemId();

                if (id == R.id.menuShipment_refreshId) {
                    if (Utils.broadcastIntent(CodRtcPickingList.this,rootLayout)){
                        loadData();
                        //adapter.updateList(list);
                    }else {
                        NoInternetSnackBar();
                    }
                    return true;
                }
                return false;
            }
        });


        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                if(v.getChildAt(v.getChildCount() - 1) != null) {
                    if ((scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight())) &&
                            scrollY > oldScrollY) {

                        //https://medium.com/@mujjtahidah/load-more-recyclerview-inside-nested-scroll-view-and-coordinator-layout-4f179dc01fd

                        if (!recyclerView.canScrollVertically(1)){
                            onScrollToBottom();
                        }

                    }
                }

            }
        });

    }

    private void initialFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.codRtcDispatchRootLayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.codRtcDispatchToolbarID);
        spinner = (Spinner)findViewById(R.id.codRtcDispatchSpinnerID);
        nestedScrollView = (NestedScrollView)findViewById(R.id.codRtcDispatchScrollviewID);
        recyclerView = (RecyclerView)findViewById(R.id.codRtcDispatchRecyclerID);
    }

    private void onScrollToBottom(){
        if (tempList.size() < scrollList.size()){
            int x,y;
            if ((scrollList.size() - tempList.size()) >= 20){
                x = tempList.size();
                y = x + 20;
            }else {
                x = tempList.size();
                y = x + scrollList.size() - tempList.size();
            }

            for (int i = x; i < y; i++){
                tempList.add(i,scrollList.get(i));
            }

            adapter.updateList(tempList);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootLayout)){
            loadData();
        }else {
            NoInternetSnackBar();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }



    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(CodRtcPickingList.this,rootLayout)){
                    loadData();
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }

    private void loadData(){
        list = new ArrayList<>();
        tempList = new ArrayList<>();
        scrollList = new ArrayList<>();
        adapter.updateList(tempList);

        final Dialog dialog = new Dialog(CodRtcPickingList.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        String token = SharedPreperenceUtils.getToken(CodRtcPickingList.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(CodRtcPickingList.this));

        final CodRtcPickingListPost post = new CodRtcPickingListPost();
        post.user_id = user_id;

        Log.e("cod picking list post", "msg"+new Gson().toJson(post));

        compositeDisposable.add(mIRetrofitApi.getCodRtcDispatchList(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<CodRtcPickingListResponse>() {
            @Override
            public void accept(CodRtcPickingListResponse response) throws Exception {
                if (response.status == 1){
                    list = response.data;

                    if (list.size() > 0){
                        dropDownList = new ArrayList<>();
                        dropDownList.add(list.get(0).person);

                        for (int i = 0; i < list.size(); i++){

                            int m = 0;

                            for (int j = 0; j < dropDownList.size(); j++){
                                if (list.get(i).person.equals(dropDownList.get(j))){
                                    m = 1;
                                }
                            }

                            if (m < 1){
                                dropDownList.add(String.valueOf(list.get(i).person));
                            }

                            if (list.get(i).person.equals(dropDownList.get(0))){
                                scrollList.add(list.get(i));
                            }
                        }

                        toolbar.setTitle("COD & RTC for "+dropDownList.get(0));


                        spinnerAdapter = new ArrayAdapter<String>(CodRtcPickingList.this, android.R.layout.simple_expandable_list_item_1,dropDownList);
                        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinner.setAdapter(spinnerAdapter);


                        if (scrollList.size() > 0){

                            if (scrollList.size() >= 20){
                                for (int i = 0; i < 20;i++){
                                    tempList.add(scrollList.get(i));
                                }

                            }else {
                                tempList.addAll(scrollList);
                            }
                            adapter.updateList(tempList);
                        }

                        //spinner.setSelection(0);

                    }

                    dialog.dismiss();
//                    Snackbar snackbar = Snackbar.make(rootLayout,""+response.message,1000);
//                    snackbar.show();
                }else {
                    dialog.dismiss();
                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout, CodRtcPickingList.this);
                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,response.message,5000);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (Utils.broadcastIntent(CodRtcPickingList.this,rootLayout)){
                                    loadData();
                                }else {
                                    NoInternetSnackBar();
                                }
                            }
                        });

                        snackbar.show();
                    }
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.setAction("Retry", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Utils.broadcastIntent(CodRtcPickingList.this,rootLayout)){
                                loadData();
                            }else {
                                NoInternetSnackBar();
                            }
                        }
                    });
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,throwable.getMessage(),5000);
                    snackbar.setAction("Retry", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Utils.broadcastIntent(CodRtcPickingList.this,rootLayout)){
                                loadData();
                            }else {
                                NoInternetSnackBar();
                            }
                        }
                    });

                    snackbar.show();
                }
            }
        }));

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        final Dialog dialog = new Dialog(CodRtcPickingList.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width, height);
        dialog.setCancelable(false);
        dialog.show();

        scrollList = new ArrayList<>();
        tempList = new ArrayList<>();
        //ArrayList<BoxListResponse.Data> filteredLIst = new ArrayList<>();
        for (CodRtcPickingListResponse.Data item : list){

            if (item.person.equals(dropDownList.get(position))){
                scrollList.add(item);
            }
        }

        if (scrollList.size() > 0){

            if (scrollList.size() >= 20){
                for (int i = 0; i < 20;i++){
                    tempList.add(scrollList.get(i));
                }
            }else {
                tempList.addAll(scrollList);
            }
        }
        toolbar.setTitle("COD & RTC for "+dropDownList.get(position));
        adapter.updateList(tempList);
        dialog.dismiss();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}