package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.ukshop.Adapters.BoxDetailsItemAdapter;
import com.example.ukshop.Adapters.ReboxingItemAdapter;
import com.example.ukshop.MasterProductPage;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.BoxDetailsItemPost;
import com.example.ukshop.NetworkModel.ReboxingResponse;
import com.example.ukshop.NetworkModel.UpdateBoxLabelPost;
import com.example.ukshop.NetworkModel.UpdateBoxLabelResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class BoxDetailsItem extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private RecyclerView recyclerView;
    private List<ReboxingResponse.Data> mainList = new ArrayList<>();
    private BoxDetailsItemAdapter adapter;

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private int pk_id;
    private int isMerchant;

    private static final int CAMERA_REQUEST_CODE = 501;

    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static boolean isFlash = false;

    private boolean isInvalid = false;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_box_details_item);

        pk_id = getIntent().getIntExtra("pk_id",0);
        isMerchant = getIntent().getIntExtra("is_merchant",0);

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new BoxDetailsItemAdapter(mainList, BoxDetailsItem.this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        if (Utils.broadcastIntent(this,rootLayout)){
            loadData();
        }else {
            NoInternetSnackBar();
        }


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.menuReBoxLabelScanId){
                    if (Utils.isCameraPermission(BoxDetailsItem.this)){
                        openScanner();
                    }else {
                        ActivityCompat.requestPermissions(BoxDetailsItem.this,new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST_CODE);
                    }
                }
                return false;
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CAMERA_REQUEST_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    private void loadData() {

        mainList = new ArrayList<>();

        adapter.updateData(mainList);

        final Dialog dialog = new Dialog(BoxDetailsItem.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        String token = SharedPreperenceUtils.getToken(BoxDetailsItem.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(BoxDetailsItem.this));

        final BoxDetailsItemPost post = new BoxDetailsItemPost();
        post.PK_NO = pk_id;
        post.user_id = user_id;
        post.is_merchant = isMerchant;

        Log.e("box details item post", "msg"+new Gson().toJson(post));

        compositeDisposable.add(mIRetrofitApi.getBoxDetailsItem(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ReboxingResponse>() {
            @Override
            public void accept(ReboxingResponse response) throws Exception {
                if (response.status == 1){
                    mainList = response.data;
                    adapter.updateData(mainList);

                    dialog.dismiss();

                }else {
                    dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout,BoxDetailsItem.this);
                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,response.message,10000);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (Utils.broadcastIntent(BoxDetailsItem.this,rootLayout)){
                                    loadData();
                                }else {
                                    NoInternetSnackBar();
                                }
                            }
                        });

                        snackbar.show();
                    }
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        }));


    }

    private void openScanner(){
        scannerDialog = new Dialog(BoxDetailsItem.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);



        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(BoxDetailsItem.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }

    @Override
    public void handleResult(Result rawResult) {
        if (!TextUtils.isEmpty(rawResult.getText())){
            if (rawResult.getText().length() == 8){
                scannerDialog.dismiss();
                scannerView.stopCamera();
                updateBoxLabel(rawResult.getText());

            }else {

                wrongTone.start();

                scannerDialog.dismiss();
                scannerView.stopCamera();
                Utils.snackbarToast(rootLayout,"This is not Box Label!");
            }
        }else {

            wrongTone.start();

            scannerDialog.dismiss();
            scannerView.stopCamera();
            Utils.snackbarToast(rootLayout,"Box Label is empty!");
        }
    }

    private void initialFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.boxDetailsItemRootlayoutID);
        toolbar = (MaterialToolbar) findViewById(R.id.boxDetailsItemToolbarID);

        recyclerView = (RecyclerView)findViewById(R.id.boxDetailsItemRecyclerID);
    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",10000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(BoxDetailsItem.this,rootLayout)){
                    loadData();
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }

    private void updateBoxLabel(String boxLabel){
        if(Utils.broadcastIntent(this,rootLayout)){
            final Dialog dialog = new Dialog(BoxDetailsItem.this);
            dialog.setContentView(R.layout.transparent_progress_dialoge);

            int width = WindowManager.LayoutParams.WRAP_CONTENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(false);
            dialog.show();

            String token = SharedPreperenceUtils.getToken(BoxDetailsItem.this);
            int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(BoxDetailsItem.this));

            final UpdateBoxLabelPost post = new UpdateBoxLabelPost();
            post.PK_NO = pk_id;
            post.user_id = user_id;
            post.box_label = boxLabel;

            Log.e("update box label post", "msg"+new Gson().toJson(post));

            compositeDisposable.add(mIRetrofitApi.updateBoxLabel(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<UpdateBoxLabelResponse>() {
                @Override
                public void accept(UpdateBoxLabelResponse response) throws Exception {
                    if (response.status == 1){

                        rightTone.start();

                        dialog.dismiss();
                        Snackbar snackbar = Snackbar.make(rootLayout,response.message,3000);
                        snackbar.show();
                    }else {

                        wrongTone.start();

                        dialog.dismiss();
                        if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                            Utils.expiredTokenAlert(rootLayout,BoxDetailsItem.this);
                        }else {
                            Snackbar snackbar = Snackbar.make(rootLayout,response.message,3000);
                            snackbar.show();
                        }
                    }
                }
            }, new Consumer<Throwable>() {
                @Override
                public void accept(Throwable throwable) throws Exception {

                    wrongTone.start();

                    dialog.dismiss();

                    if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                        Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                        snackbar.show();
                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                        snackbar.show();
                    }
                }
            }));

        }else {

            wrongTone.start();

            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",Snackbar.LENGTH_LONG);
            snackbar.show();
        }
    }
}