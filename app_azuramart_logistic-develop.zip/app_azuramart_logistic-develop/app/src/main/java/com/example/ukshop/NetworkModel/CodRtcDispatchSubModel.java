package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class CodRtcDispatchSubModel {
    @SerializedName("PK_NO")
    public int PK_NO;

    @SerializedName("sku_id")
    public String sku_id;

    @SerializedName("barcode")
    public String barcode;

    @SerializedName("qty")
    public int qty;
}
