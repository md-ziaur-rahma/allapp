package com.example.ukshop.Adapters;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.ImageShowPage;
import com.example.ukshop.Activity.IndividualStockSearch;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.IndividualStockSearchResponse;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class IndividualStockSearchAdapter extends RecyclerView.Adapter<IndividualStockSearchAdapter.ViewHolder> {
    private List<IndividualStockSearchResponse.Data> list;
    private Activity context;
    private CoordinatorLayout rootLayout;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    List<VariantImageResponse.Data> variantImageList = new ArrayList<>();

    public IndividualStockSearchAdapter(List<IndividualStockSearchResponse.Data> list, Activity context, CoordinatorLayout rootLayout) {
        this.list = list;
        this.context = context;
        this.rootLayout = rootLayout;
    }

    @NonNull
    @Override
    public IndividualStockSearchAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.individual_stock_search_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull IndividualStockSearchAdapter.ViewHolder holder, int position) {
        int PK_NO = list.get(position).PK_NO;
        String imageUrl = list.get(position).variant_primary_image;
        String primaryImage = list.get(position).primary_image;
        String skuId = list.get(position).sku_id;
        String barcode = list.get(position).barcode;
        String mktId = list.get(position).mkt_id;
        String name = list.get(position).product_name;
        String variantName = list.get(position).variant_name;
        String color = list.get(position).color;
        int isAir = list.get(position).is_air;
        int is_air_count = list.get(position).is_air_count;
        int is_sea_count = list.get(position).is_sea_count;
        String size = list.get(position).size;
        float price = list.get(position).price;
        float ins_price = list.get(position).ins_price;
        float sm_price = list.get(position).sm_price;
        float ss_price = list.get(position).ss_price;
        int qty = list.get(position).available_qty;
        int azuramart_qty = list.get(position).azm_available_qty;
        int merchant_qty = list.get(position).mer_available_qty;
        List<IndividualStockSearchResponse.MerchantQty> merchantQties = list.get(position).merchantQuantities;

        holder.setData(PK_NO,skuId,barcode,mktId,name,variantName,imageUrl,primaryImage,
                color,isAir,is_air_count,is_sea_count, size,price,ins_price,sm_price,ss_price,qty,azuramart_qty,merchant_qty,merchantQties,position);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
    public void addItem(List<IndividualStockSearchResponse.Data> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView variant_image,seaIcon,airIcon;
        private TextView name,skuId,barcode,ig_code,
                size,color,price,price2,qty,isAir,
                airQty, seaQty, azmQty, merQty;
        private Button detailsBtn;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            variant_image = itemView.findViewById(R.id.individualStock_check_item_imageID);
            name = itemView.findViewById(R.id.individualStock_check_item_nameID);
            skuId = itemView.findViewById(R.id.individualStock_check_item_skuID);
            barcode = itemView.findViewById(R.id.individualStock_check_item_barcodeID);
            ig_code = itemView.findViewById(R.id.individualStock_check_item_IGCODEID);
            size = itemView.findViewById(R.id.individualStock_check_item_sizeID);
            color = itemView.findViewById(R.id.individualStock_check_item_colorID);
            isAir = itemView.findViewById(R.id.individualStock_check_item_seaID);
            price = itemView.findViewById(R.id.individualStock_check_item_priceID);
            price2 = itemView.findViewById(R.id.individualStock_check_item_price2ID);
            qty = itemView.findViewById(R.id.individualStock_check_item_qntID);
            azmQty = itemView.findViewById(R.id.individualStockSearchAzuramartQtyID);
            merQty = itemView.findViewById(R.id.individualStockSearchMerchantQtyID);

            airIcon = itemView.findViewById(R.id.individualStock_check_item_airIconID);
            seaIcon = itemView.findViewById(R.id.individualStock_check_item_seaIconID);
            airQty = itemView.findViewById(R.id.individualStock_check_item_airQtyID);
            seaQty = itemView.findViewById(R.id.individualStock_check_item_seaQtyID);

            detailsBtn = itemView.findViewById(R.id.individualStock_check_item_buttonID);
        }

        public void setData (final int pk_id,final String sku,final String barcode, final String mktid, final String name, final String variant_Name, String imageUrl,
                             String primary_image, final String color,final int isAir, final int is_air_count,final int is_sea_count, final String size, final float price, final float ins_price,final float sm_price, final float ss_price,final int quantity,
                             int azuramart_qty, int merchant_qty, List<IndividualStockSearchResponse.MerchantQty> merchantQties,int position){
            String bookImage = "";

            primary_image = Common.BASEURL_PICTURE + primary_image;

            if (imageUrl == null || imageUrl.equals("")){
                bookImage = primary_image;
                Glide.with(context)
                        .load(primary_image)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_image);
            }else {
                imageUrl = Common.BASEURL_PICTURE + imageUrl;

                bookImage = imageUrl;

                Glide.with(context)
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_image);
            }



            if (variant_Name == null || variant_Name == ""){
                this.name.setText(name);
            }else {
                this.name.setText(variant_Name);
            }

            skuId.setText("SKU : "+sku);
            this.barcode.setText("Barcode : "+barcode);
            ig_code.setText("IG CODE : "+mktid);
            this.color.setText("Color : "+color);


            this.airIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#4F1B35")));
            this.seaIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#4F1B35")));
            airQty.setText("("+is_air_count+")");
            seaQty.setText("("+is_sea_count+")");


            if (isAir == 1){
                this.airIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#35cce3")));
            }else {
                this.seaIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#35cce3")));
            }

            this.size.setText("Size : "+size);

            NumberFormat formatter = new DecimalFormat("#0.00");
            this.price.setText("RM "+formatter.format(price)+"  / "+formatter.format(ins_price));
            this.price2.setText("SM "+formatter.format(sm_price)+"  / SS "+formatter.format(ss_price));

            this.qty.setText("Qty : "+quantity);
            this.azmQty.setText("Azura Mart Qty : "+azuramart_qty);
            this.merQty.setText("Merchant Qty : "+merchant_qty);

            detailsBtn.setOnClickListener(v -> {
                final Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.individual_stock_search_merchant_qty_dialog);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                TextView azuramartQty = dialog.findViewById(R.id.individualStock_check_item_dialog_azuramart_qtyId);
                TextView merchantQty = dialog.findViewById(R.id.individualStock_check_item_dialog_merchant_qtyId);
                RecyclerView recyclerView = dialog.findViewById(R.id.individualStockCheckDialogRecyclerID);

                azuramartQty.setText("Azura Mart Qty : "+azuramart_qty);
                merchantQty.setText("Merchant Qty : "+merchant_qty);

                LinearLayoutManager layoutManager = new LinearLayoutManager(context);
                layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                recyclerView.setLayoutManager(layoutManager);

                individualStockSearchDetailsDialogAdapter adapter;
                adapter = new individualStockSearchDetailsDialogAdapter(merchantQties);
                recyclerView.setAdapter(adapter);

            });
            itemView.setOnClickListener(v -> {

            });
            variant_image.setOnClickListener(v -> {
                mIRetrofitApi = Common.getApiArobil();
                String token = SharedPreperenceUtils.getToken(context);
                Log.e("tag","image-request : "+pk_id);
                compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
                    if (response.status == 1){
                        variantImageList = response.data;
                        ImageShowPage.variantImageList = variantImageList;
                        Intent intent = new Intent(context, ImageShowPage.class);
                        itemView.getContext().startActivity(intent);
                    }
                }, throwable -> {

                }));
            });
        }
    }
}
