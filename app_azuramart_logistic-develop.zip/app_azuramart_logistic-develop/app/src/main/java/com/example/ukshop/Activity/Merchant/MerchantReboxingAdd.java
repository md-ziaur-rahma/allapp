package com.example.ukshop.Activity.Merchant;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import com.example.ukshop.R;

public class MerchantReboxingAdd extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchant_reboxing_add);
    }
}