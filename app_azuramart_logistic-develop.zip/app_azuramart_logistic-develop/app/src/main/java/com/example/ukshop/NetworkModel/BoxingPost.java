package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class BoxingPost {
        @SerializedName("barcode")
        public String barcode;
        @SerializedName("qty")
        public int qty;
}
