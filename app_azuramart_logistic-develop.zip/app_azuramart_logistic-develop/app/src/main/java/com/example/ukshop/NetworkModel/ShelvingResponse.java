package com.example.ukshop.NetworkModel;

public class ShelvingResponse extends ApiResponse{

}
