package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.Network.RTSSubModel;
import com.example.ukshop.NetworkModel.CodRtcShelveTransferPost;
import com.example.ukshop.NetworkModel.CodRtcSubModel;
import com.example.ukshop.NetworkModel.ShelveItemListResponse;
import com.example.ukshop.NetworkModel.ShelvingResponse;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class CodRtcLandZoneItemCollect extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private Button collectBtn;

    // ...............item layout variables...........
    private TextView qty,avl_qty;
    private ImageView delete, edit;

    private ImageView variant_image;
    private TextView name,skuId,size,color,air;


    private Button productScanBtn;
    private TextView alertText;
    private boolean isProductScan = false;

    // ...............item layout variables...........

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private List<VariantImageResponse.Data> variantImageList = new ArrayList<>();


    public static ShelveItemListResponse.Data data;
    public static List<CodRtcSubModel> list;

    private Dialog scannerDialog;
    private ZXingScannerView scannerView;
    private static final int CAMERA_PERMISSION_CODE = 501;

    private static boolean isFlash = false;
    private static boolean isCameraOpen = false;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cod_rtc_land_zone_item_collect);
        Window window = this.getWindow();
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.batch_list_color));

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);
        mIRetrofitApi = Common.getApiArobil();

        // ............... find variables ................ //
        initialFindFields();

        toolbar.setTitle("Transfer To "+list.get(0).person);
        collectBtn.setText("Transfer");

        if (isProductScan){
            collectBtn.setVisibility(View.VISIBLE);
            alertText.setVisibility(View.VISIBLE);
        }else {
            productScanBtn.setVisibility(View.VISIBLE);
            collectBtn.setVisibility(View.GONE);
            alertText.setVisibility(View.GONE);
        }

        ///.............................

        //String insPrimaryImage = Common.BASEURL_PICTURE + data.primary_image;

        if (data.variant_primary_image == null || data.variant_primary_image.equals("")) {
            Glide.with(this)
                    .load(data.primary_image)
                    .placeholder(R.drawable.ic_default)
                    .into(variant_image);
        } else {
            //String insVariantImage = Common.BASEURL_PICTURE + data.variant_primary_image;


            Glide.with(this)
                    .load(data.variant_primary_image)
                    .placeholder(R.drawable.ic_default)
                    .into(variant_image);
        }


        if (data.variant_name == null || data.variant_name.equals("")) {
            this.name.setText(data.product_name);
        } else {
            this.name.setText(data.variant_name);
        }

        //this.skuId.setText("SKU : "+sku);
        this.skuId.setText("Barcode : " + data.barcode);
        this.color.setText("Color : " + data.color);
        this.size.setText("Size : " + data.size);

        this.qty.setText("Qty : " + data.available_qty);
        //this.avl_qty.setText("Avl Qty : " + qty);
        avl_qty.setVisibility(View.GONE);
        delete.setVisibility(View.GONE);
        this.air.setVisibility(View.GONE);

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog qtyDialog = new Dialog(CodRtcLandZoneItemCollect.this,R.style.PauseDialog);
                qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                qtyDialog.getWindow().setLayout(width,height);
                qtyDialog.setCancelable(false);
                qtyDialog.show();

                final EditText qtyText = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                TextView d_avl_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);

                ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                //String insPrimaryImage = Common.BASEURL_PICTURE + data.primary_image;

                if (data.variant_primary_image == null || data.variant_primary_image.equals("")) {
                    Glide.with(CodRtcLandZoneItemCollect.this)
                            .load(data.primary_image)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                } else {
                    //String insVariantImage = Common.BASEURL_PICTURE + data.variant_primary_image;


                    Glide.with(CodRtcLandZoneItemCollect.this)
                            .load(data.variant_primary_image)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                }


                if (data.variant_name == null || data.variant_name.equals("")) {
                    cardName.setText(data.product_name);
                } else {
                    cardName.setText(data.variant_name);
                }

                cardColor.setText("Color : " + data.color);
                cardSize.setText("Size : " + data.size);

                d_avl_qty.setText("Qty : "+data.available_qty);
                qtyText.setText(""+list.get(0).qty);
                ok.setText("Update");


                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        qtyDialog.dismiss();
                    }
                });





                //............................................... incomplete ....................................//

                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!TextUtils.isEmpty(qtyText.getText())) {
                            String newQuantity = qtyText.getText().toString();
                            int newQtyInt = Integer.parseInt(newQuantity);

                            if (newQtyInt <= data.available_qty) {

                                if (newQtyInt == 0) {
                                    newQtyInt = 1;
                                }

                                final CodRtcSubModel subModel = new CodRtcSubModel();
                                subModel.barcode = list.get(0).barcode;
                                subModel.sku_id = list.get(0).sku_id;
                                subModel.qty = newQtyInt;
                                subModel.person = list.get(0).person;
                                subModel.person_id = list.get(0).person_id;
                                subModel.order_id = list.get(0).order_id;
                                list.set(0,subModel);

                                qty.setText("Qty : " + newQtyInt);

                                qtyDialog.dismiss();


                            }else {
                                qtyText.requestFocus();
                                Toast.makeText(CodRtcLandZoneItemCollect.this, "Enter less then or equal : "+data.available_qty, Toast.LENGTH_SHORT).show();

                            }

                        }else {
                            Toast.makeText(CodRtcLandZoneItemCollect.this, "Enter minimum 1 Qty", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });



        // ............... toolbar related code ................ //
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        productScanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(CodRtcLandZoneItemCollect.this)){
                    openScanner();
                }else {
                    ActivityCompat.requestPermissions(CodRtcLandZoneItemCollect.this,new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
                }
            }
        });

        productScanBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                final Dialog dialog = new Dialog(CodRtcLandZoneItemCollect.this,R.style.PauseDialog);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
                // barcodeText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(10)});

                search.setText(R.string.ok);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });


                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){

                            if (barcode.equals(data.barcode)){
                                final Dialog qtyDialog = new Dialog(CodRtcLandZoneItemCollect.this);
                                qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                                int width = WindowManager.LayoutParams.MATCH_PARENT;
                                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                                qtyDialog.getWindow().setLayout(width,height);
                                qtyDialog.setCancelable(false);
                                qtyDialog.show();

                                final EditText d_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                                Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                                Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                                TextView d_avl_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);

                                d_avl_qty.setText("Avl Qty : "+ data.available_qty);
                                d_qty.setText(""+data.available_qty);


                                ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                                TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                                TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                                TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                                //String insPrimaryImage = Common.BASEURL_PICTURE + data.primary_image;

                                if (data.variant_primary_image == null || data.variant_primary_image.equals("")) {
                                    Glide.with(CodRtcLandZoneItemCollect.this)
                                            .load(data.primary_image)
                                            .placeholder(R.drawable.ic_default)
                                            .into(cardImage);
                                } else {
                                    //String insVariantImage = Common.BASEURL_PICTURE + data.variant_primary_image;


                                    Glide.with(CodRtcLandZoneItemCollect.this)
                                            .load(data.variant_primary_image)
                                            .placeholder(R.drawable.ic_default)
                                            .into(cardImage);
                                }


                                if (data.variant_name == null || data.variant_name.equals("")) {
                                    cardName.setText(data.product_name);
                                } else {
                                    cardName.setText(data.variant_name);
                                }

                                cardColor.setText("Color : " + data.color);
                                cardSize.setText("Size : " + data.size);


                                cancel.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        qtyDialog.dismiss();
                                        dialog.dismiss();
                                    }
                                });

                                ok.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        if (!TextUtils.isEmpty(d_qty.getText())) {
                                            String string = d_qty.getText().toString();
                                            int quantity = Integer.parseInt(string);

                                            if (quantity == 0) {
                                                quantity = 1;
                                            }

                                            final CodRtcSubModel subModel = new CodRtcSubModel();
                                            subModel.barcode = list.get(0).barcode;
                                            subModel.sku_id = list.get(0).sku_id;
                                            subModel.qty = quantity;
                                            subModel.person = list.get(0).person;
                                            subModel.person_id = list.get(0).person_id;
                                            subModel.order_id = list.get(0).order_id;
                                            list.set(0,subModel);

                                            list.set(0,subModel);

                                            qty.setText("Qty : " + quantity);

                                            isProductScan = true;

                                            alertText.setVisibility(View.VISIBLE);
                                            alertText.setText("Successfully Scanned");
                                            alertText.setTextColor(ColorStateList.valueOf(Color.parseColor("#008000")));
                                            collectBtn.setVisibility(View.VISIBLE);
                                            productScanBtn.setVisibility(View.GONE);

                                            qtyDialog.dismiss();
                                            dialog.dismiss();

                                        }else {
                                            qty.requestFocus();
                                            Toast.makeText(CodRtcLandZoneItemCollect.this, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                                        }

                                    }
                                });


                            }else {
                                collectBtn.setVisibility(View.GONE);
                                Utils.snackbarToast(rootLayout,"Doesn't match the barcode!");
                            }

                        }else {
                            barcodeText.requestFocus();
                            Toast.makeText(CodRtcLandZoneItemCollect.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });


                return false;
            }
        });

        collectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(CodRtcLandZoneItemCollect.this,rootLayout)){

                        if (list.size() != 0){

                            final Dialog dialog = new Dialog(CodRtcLandZoneItemCollect.this);
                            dialog.setContentView(R.layout.transparent_progress_dialoge);

                            int width = WindowManager.LayoutParams.WRAP_CONTENT;
                            int height = WindowManager.LayoutParams.WRAP_CONTENT;

                            dialog.getWindow().setLayout(width,height);
                            dialog.setCancelable(false);
                            dialog.show();

                            String token = SharedPreperenceUtils.getToken(CodRtcLandZoneItemCollect.this);
                            int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(CodRtcLandZoneItemCollect.this));

                            final CodRtcShelveTransferPost post = new CodRtcShelveTransferPost();
                            post.is_shelve = 0;
                            post.shelve_label = "";
                            post.user_id = user_id;
                            post.data = list;

                            Log.e("cod land item post", "msg"+new Gson().toJson(post));

                            compositeDisposable.add(mIRetrofitApi.codRtcShelveTransfer(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ShelvingResponse>() {
                                @Override
                                public void accept(ShelvingResponse response) throws Exception {
                                    if (response.status == 1){
                                        Snackbar snackbar = Snackbar.make(rootLayout,""+response.message,Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                        dialog.dismiss();

                                        if (list.get(0).qty < data.available_qty){
                                            data.available_qty = (data.available_qty-list.get(0).qty);
                                            qty.setText("Qty : " + data.available_qty);
                                        }else {
                                            list = new ArrayList<>();
                                            data = new ShelveItemListResponse.Data();
                                            alertText.setVisibility(View.GONE);
                                            collectBtn.setVisibility(View.GONE);
                                            finish();
                                        }

//                                        final Dialog successDialog = new Dialog(CodRtcLandZoneItemCollect.this);
//                                        successDialog.setContentView(R.layout.cod_dispatch_success_layout);
//
//                                        int width = WindowManager.LayoutParams.WRAP_CONTENT;
//                                        int height = WindowManager.LayoutParams.WRAP_CONTENT;
//
//                                        successDialog.getWindow().setLayout(width,height);
//                                        successDialog.setCancelable(true);
//                                        successDialog.show();
//
//                                        new Handler().postDelayed(new Runnable() {
//                                            @Override
//                                            public void run() {
//                                                successDialog.dismiss();
//                                                finish();
//                                            }
//                                        },2000);

                                    }else {
                                        dialog.dismiss();

                                        if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                            Utils.expiredTokenAlert(rootLayout,CodRtcLandZoneItemCollect.this);
                                        }else {
                                            Utils.snackbarToast(rootLayout,response.message);
                                        }
                                    }
                                }
                            }, new Consumer<Throwable>() {
                                @Override
                                public void accept(Throwable throwable) throws Exception {
                                    dialog.dismiss();

                                    if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                        Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                                        snackbar.show();
                                    }else {
                                        Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                    }
                                }
                            }));

                        }else {
                            Snackbar snackbar = Snackbar.make(rootLayout,"Go to back and reselect item!***",Snackbar.LENGTH_LONG);
                            snackbar.show();
                        }
                    }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,"No internet connection!",Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        });

        /// ......................showing image when click on the image.....................
        variant_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String token = SharedPreperenceUtils.getToken(CodRtcLandZoneItemCollect.this);

                compositeDisposable.add(mIRetrofitApi.getVariantImage(token,data.PK_NO).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<VariantImageResponse>() {
                    @Override
                    public void accept(VariantImageResponse response) throws Exception {
                        if (response.status == 1){
                            variantImageList = response.data;
                            ImageShowPage.variantImageList = variantImageList;
                            Intent intent = new Intent(CodRtcLandZoneItemCollect.this, ImageShowPage.class);
                            startActivity(intent);

                        }else {

                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {

                    }
                }));
            }
        });
        /// ......................showing images when click on the image.....................

    }

    @Override
    protected void onDestroy() {
        list = new ArrayList<>();
        data = new ShelveItemListResponse.Data();
        isProductScan = false;
        collectBtn.setVisibility(View.GONE);
        alertText.setVisibility(View.GONE);
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        list = new ArrayList<>();
        data = new ShelveItemListResponse.Data();
        isProductScan = false;
        collectBtn.setVisibility(View.GONE);
        alertText.setVisibility(View.GONE);
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    private void initialFindFields(){
        rootLayout = (CoordinatorLayout)findViewById(R.id.CodRtcLandZoneItemCollectRootLayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.CodRtcLandZoneItemCollectToolbarID);
        collectBtn = (Button)findViewById(R.id.CodRtcLandZoneItemCollectBtnID);
        alertText = (TextView)findViewById(R.id.CodRtcLandZoneItemCollectAlertTextID);
        productScanBtn = (Button) findViewById(R.id.scanItemBtnAID);

        variant_image = (ImageView)findViewById(R.id.boxingl_item_imageID);
        name = (TextView) findViewById(R.id.boxingl_item_nameID);
        skuId = (TextView) findViewById(R.id.boxingl_item_skuID);
        size = (TextView) findViewById(R.id.boxingl_item_sizeID);
        color = (TextView) findViewById(R.id.boxingl_item_colorID);
        air = (TextView)findViewById(R.id.boxingl_item_is_airID);

        avl_qty = (TextView) findViewById(R.id.boxingl_item_avl_qntID);
        qty = (TextView) findViewById(R.id.boxingl_item_qntID);
        delete = (ImageView)findViewById(R.id.boxingl_item_deleteBtnID);
        edit = (ImageView)findViewById(R.id.boxingl_item_editBtnID);
    }

    // ............... scanner open method ................ //
    private void openScanner(){
        scannerDialog = new Dialog(CodRtcLandZoneItemCollect.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


        isCameraOpen = true;
        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(CodRtcLandZoneItemCollect.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                isCameraOpen = false;
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }


    // ............... permission response method ................ //
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }


    @Override
    public void handleResult(Result rawResult) {

        if (!TextUtils.isEmpty(rawResult.getText())){
            final String p_barcode = rawResult.getText();

            if (p_barcode.equals(data.barcode)){
                rightTone.start();
                final Dialog qtyDialog = new Dialog(CodRtcLandZoneItemCollect.this);
                qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                qtyDialog.getWindow().setLayout(width,height);
                qtyDialog.setCancelable(false);
                qtyDialog.show();

                final EditText d_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                TextView d_avl_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);

                d_avl_qty.setText("Avl Qty : "+ data.available_qty);
                d_qty.setText(""+data.available_qty);


                ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

               // String insPrimaryImage = Common.BASEURL_PICTURE + data.primary_image;

                if (data.variant_primary_image == null || data.variant_primary_image.equals("")) {
                    Glide.with(CodRtcLandZoneItemCollect.this)
                            .load(data.primary_image)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                } else {
                    //String insVariantImage = Common.BASEURL_PICTURE + data.variant_primary_image;


                    Glide.with(CodRtcLandZoneItemCollect.this)
                            .load(data.variant_primary_image)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                }


                if (data.variant_name == null || data.variant_name.equals("")) {
                    cardName.setText(data.product_name);
                } else {
                    cardName.setText(data.variant_name);
                }

                cardColor.setText("Color : " + data.color);
                cardSize.setText("Size : " + data.size);


                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        qtyDialog.dismiss();
                        scannerDialog.dismiss();
                        scannerView.stopCamera();
                    }
                });

                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!TextUtils.isEmpty(d_qty.getText())) {
                            String string = d_qty.getText().toString();
                            int quantity = Integer.parseInt(string);

                            if (quantity <= data.available_qty){

                                if (quantity == 0) {
                                    quantity = 1;
                                }

                                final CodRtcSubModel subModel = new CodRtcSubModel();
                                subModel.barcode = list.get(0).barcode;
                                subModel.sku_id = list.get(0).sku_id;
                                subModel.qty = quantity;
                                subModel.person = list.get(0).person;
                                subModel.person_id = list.get(0).person_id;
                                subModel.order_id = list.get(0).order_id;
                                list.set(0,subModel);

                                qty.setText("Qty : " + quantity);

                                isProductScan = true;
                                collectBtn.setVisibility(View.VISIBLE);
                                alertText.setVisibility(View.VISIBLE);
                                alertText.setText("Successfully Scanned");
                                alertText.setTextColor(ColorStateList.valueOf(Color.parseColor("#008000")));

                                qtyDialog.dismiss();
                                scannerDialog.dismiss();
                                scannerView.stopCamera();

                            }else {
                                qty.requestFocus();
                                Toast.makeText(CodRtcLandZoneItemCollect.this, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                            }
                        }else {
                            qty.requestFocus();
                            Toast.makeText(CodRtcLandZoneItemCollect.this, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                        }

                    }
                });


            }else {
                wrongTone.start();
                scannerDialog.dismiss();
                scannerView.stopCamera();
                collectBtn.setVisibility(View.GONE);
                alertText.setVisibility(View.VISIBLE);
                alertText.setText("Doesn't match the barcode! try again");
                alertText.setTextColor(ColorStateList.valueOf(Color.parseColor("#da0000")));
            }
        }else {
            wrongTone.start();
            scannerDialog.dismiss();
            scannerView.stopCamera();
            Utils.snackbarToast(rootLayout,"Barcode is empty!");
            alertText.setVisibility(View.VISIBLE);
            alertText.setText("Doesn't match the barcode! try again");
            alertText.setTextColor(ColorStateList.valueOf(Color.parseColor("#da0000")));
        }


    }
}