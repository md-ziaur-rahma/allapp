package com.example.ukshop.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.ImageShowPage;
import com.example.ukshop.Activity.ProductBoxLocation;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ProductSearchResponse;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

import static maes.tech.intentanim.CustomIntent.customType;

public class ProductSearchItemAdapter extends RecyclerView.Adapter<ProductSearchItemAdapter.ViewHolder> {

    private List<ProductSearchResponse.Data> mainList;
    private final Activity context;
    private final CoordinatorLayout rootLayout;
    private final int isAdvance;
    private final int merchantId;

    private final CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;
    private List<VariantImageResponse.Data> variantImageList = new ArrayList<>();

    public ProductSearchItemAdapter(List<ProductSearchResponse.Data> mainList, Activity context, CoordinatorLayout rootLayout, int merchantId, int isAdvance) {
        this.mainList = mainList;
        this.context = context;
        this.rootLayout = rootLayout;
        this.merchantId = merchantId;
        this.isAdvance = isAdvance;
    }

    @NonNull
    @Override
    public ProductSearchItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.product_search_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductSearchItemAdapter.ViewHolder holder, int position) {
        String imageUrl = mainList.get(position).variant_primary_image;
        String primaryImage = mainList.get(position).primary_image;
        int pk_id = mainList.get(position).PK_NO;
        String skuId = mainList.get(position).sku_id;
        String barcode = mainList.get(position).barcode;
        String mktId = mainList.get(position).mkt_id;
        String name = mainList.get(position).product_name;
        String variantName = mainList.get(position).variant_name;
        String color = mainList.get(position).color;
        int is_air = mainList.get(position).is_air;
        String size = mainList.get(position).size;
        float price = mainList.get(position).price;
        float ins_price = mainList.get(position).ins_price;
        int qty = mainList.get(position).available_qty;

        String warehouse = mainList.get(position).warehouse;
        int boxedQty = mainList.get(position).boxed_qty;
        int unboxedQty = mainList.get(position).yet_to_boxed_qty;
        int shipmentAssignedQty = mainList.get(position).shipment_assigned_qty;
//        int shelvedQty = mainList.get(position).shelved_qty;
//        int unShelvedQty = mainList.get(position).unshelved_qty;

        holder.setData(skuId,barcode,mktId,pk_id,name,variantName,primaryImage,imageUrl,
                color,is_air,size,price,ins_price,qty,warehouse,boxedQty,unboxedQty,
                shipmentAssignedQty,0,0,position);

    }

    @Override
    public int getItemCount() {
        return mainList.size();
    }

    public void updateData(List<ProductSearchResponse.Data> newList){
        mainList = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private final ImageView variant_iamge;
        private final TextView name,skuId,ig_code,barcode,size,color,is_air,price,qty,
                warehouse, boxedQty, unboxedQty, shipmentAssignedQty, shelvedQty, unshelvedQty;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            variant_iamge = itemView.findViewById(R.id.productSearch_item_imageID);
            name = itemView.findViewById(R.id.productSearch_item_nameID);
            skuId = itemView.findViewById(R.id.productSearch_item_skuID);

            barcode = itemView.findViewById(R.id.productSearch_item_barcodeID);
            ig_code = itemView.findViewById(R.id.productSearch_item_IGCODEID);
            size = itemView.findViewById(R.id.productSearch_item_sizeID);
            color = itemView.findViewById(R.id.productSearch_item_colorID);
            is_air = itemView.findViewById(R.id.productSearch_item_is_airID);
            price = itemView.findViewById(R.id.productSearch_item_priceID);
            qty = itemView.findViewById(R.id.productSearch_item_qntID);

            warehouse = itemView.findViewById(R.id.productSearchWarehouseID);
            boxedQty = itemView.findViewById(R.id.productSearchBoxedQtyID);
            unboxedQty = itemView.findViewById(R.id.productSearchYettoBoxID);
            shipmentAssignedQty = itemView.findViewById(R.id.productSearchShipmentAssQtyID);
            shelvedQty = itemView.findViewById(R.id.productSearchShelvedQtyID);
            unshelvedQty = itemView.findViewById(R.id.productSearchUnshelvedQtyID);
        }

        public void setData(final String sku, final String barcode, String mktId, final int pk_id, String name, String variant_Name, String primaryImage, String imageUrl,
                            String color, final int is_air, String size, float price, final float ins_price, int quantity, final String warehouse, int boxedQty, int unboxedQty,
                            int shipmentAssignedQty, int shelvedQty, int unshelvedQty, final int position){

            if (imageUrl == null || imageUrl.equals("")){
                primaryImage = Common.BASEURL_PICTURE+primaryImage;
                Glide.with(context)
                        .load(primaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_iamge);
            }else {
                imageUrl = Common.BASEURL_PICTURE+imageUrl;
                Glide.with(context)
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_default)
                        .into(this.variant_iamge);
            }


            if (variant_Name == null || variant_Name.equals("")){
                this.name.setText(name);
            }else {
                this.name.setText(variant_Name);
            }

            skuId.setText("SKU : "+sku);
            this.barcode.setText("Barcode : "+barcode);
            this.ig_code.setText("IG CODE : "+mktId);
            this.color.setText("Color : "+color);

            if (is_air == 1){
                this.is_air.setText("Air");
            }else if (is_air == 0){
                this.is_air.setText("Sea");
            }

            this.is_air.setVisibility(View.GONE);

            this.size.setText("Size : "+size);

            NumberFormat formatter = new DecimalFormat("##.00");

            if (isAdvance == 1){
                this.price.setText("GBP "+formatter.format(price)+"  / RM "+formatter.format(ins_price));
            } else {
                this.price.setText("RM "+formatter.format(price)+"  / "+formatter.format(ins_price));
            }
            this.qty.setText("Total Qty : "+quantity);

            this.warehouse.setText(warehouse);
            this.boxedQty.setText("Boxed Qty : "+boxedQty);
            this.unboxedQty.setText("YetToBox Qty : "+unboxedQty);
            this.shipmentAssignedQty.setText("Shipment Assigned Qty : "+shipmentAssignedQty);
//            this.shelvedQty.setText("Shelved Qty : "+shelvedQty);
//            this.unshelvedQty.setText("Unshelved Qty :"+unshelvedQty);
            this.shelvedQty.setVisibility(View.GONE);
            this.unshelvedQty.setVisibility(View.GONE);


            variant_iamge.setOnClickListener(v -> {
                mIRetrofitApi = Common.getApiArobil();
                String token = SharedPreperenceUtils.getToken(context);

                compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
                    if (response.status == 1){
                        variantImageList = response.data;
                        ImageShowPage.variantImageList = variantImageList;
                        Intent intent = new Intent(context, ImageShowPage.class);
                        itemView.getContext().startActivity(intent);

                    }else {

                    }
                }, throwable -> {

                }));
            });

            itemView.setOnClickListener(v -> {
                Intent intent = new Intent(context, ProductBoxLocation.class);
                ProductBoxLocation.skuID = sku;
                ProductBoxLocation.warehouse = warehouse;
                intent.putExtra("merchant_id",merchantId);
                itemView.getContext().startActivity(intent);
                customType(context,"left-to-right");
            });

        }
    }
}
