package com.example.ukshop.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.CodRtcDispatchZone;
import com.example.ukshop.Activity.ImageShowPage;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.CodRtcDispatchItemResponse;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class CodRtcDispatchItemAdapter extends RecyclerView.Adapter<CodRtcDispatchItemAdapter.ViewHolder> {

    private List<CodRtcDispatchItemResponse.Data> list;
    private CoordinatorLayout rootLayout;
    private Activity context;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;
    List<VariantImageResponse.Data> variantImageList = new ArrayList<>();

    public CodRtcDispatchItemAdapter(List<CodRtcDispatchItemResponse.Data> list, CoordinatorLayout rootLayout, Activity context) {
        this.list = list;
        this.rootLayout = rootLayout;
        this.context = context;
    }

    @NonNull
    @Override
    public CodRtcDispatchItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.dispatch_consignment_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CodRtcDispatchItemAdapter.ViewHolder holder, int position) {
        int pk_id = list.get(position).PK_NO;
        String imageUrl = list.get(position).variant_primary_image;
        String primaryImage = list.get(position).primary_image;
        String skuId = list.get(position).sku_id;
        String mktId = list.get(position).mkt_id;
        String name = list.get(position).product_name;
        String variantName = list.get(position).variant_name;
        String color = list.get(position).color;
        String size = list.get(position).size;
        int qty = list.get(position).qty;
        int available_qty = list.get(position).available_qty;
        String barcode = list.get(position).barcode;
        boolean isChecked = list.get(position).isChecked;
        String label = list.get(position).label;
        String location = list.get(position).location;
        int isMy = list.get(position).is_my;
        int acknowledge = list.get(position).acknowledge;

        holder.setData(pk_id,qty,available_qty,position,primaryImage,imageUrl,skuId,
                mktId,name,variantName,color,size,barcode,isChecked,label,location,isMy,acknowledge);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void updateList(List<CodRtcDispatchItemResponse.Data> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private final ImageView variant_image,checkBox;
        private final TextView name,skuId,barcode,size,color,qty,location;
        private final Button goBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            variant_image = itemView.findViewById(R.id.dispatchConsignmentItemImageId);
            name = itemView.findViewById(R.id.dispatchConsignmentItemNameId);
            skuId = itemView.findViewById(R.id.dispatchConsignmentItemSkuId);
            barcode = itemView.findViewById(R.id.dispatchConsignmentItemBarcodeId);
            size = itemView.findViewById(R.id.dispatchConsignmentItemSizeId);
            color = itemView.findViewById(R.id.dispatchConsignmentItemColorId);
            qty = itemView.findViewById(R.id.dispatchConsignmentItemQtyId);
            checkBox = itemView.findViewById(R.id.dispatchConsignmentItemCheckBoxId);
            goBtn = itemView.findViewById(R.id.dispatchConsignmentItemGotoBtnID);
            location = itemView.findViewById(R.id.dispatchConsignmentItemLocationID);
        }

        public void setData(final int pk_id,final int qty, final int available_qty, final int position, final String primaryImage,
                            final String variantImage, final String sku, final String mkt, final String name, final String variantName,
                            final String color, final String size, final String barcode,final boolean isChecked,
                            final String label, final String location ,final int isMy,final int acknowledge) {

            String insPrimaryImage = Common.BASEURL_PICTURE + primaryImage;

            if (variantImage == null || variantImage.equals("")) {
                Glide.with(context)
                        .load(insPrimaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_image);
            } else {
                String insVariantImage = Common.BASEURL_PICTURE + variantImage;


                Glide.with(context)
                        .load(insVariantImage)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_image);
            }


            if (variantName == null || variantName.equals("")) {
                this.name.setText(name);
            } else {
                this.name.setText(variantName);
            }

            //this.skuId.setText("SKU : "+sku);
            this.barcode.setText("Barcode : " + barcode);
            this.skuId.setText("SKU :" + sku);
            this.color.setText("Color : " + color);

            this.size.setText("Size : " + size);
            this.qty.setText("Qty : " + available_qty + "/" + qty);
            this.location.setText(location);

            if (acknowledge == 1){
                this.goBtn.setVisibility(View.GONE);
                this.checkBox.setVisibility(View.GONE);
                this.location.setVisibility(View.VISIBLE);
                this.location.setText("Ready For Scan");
            }else if (acknowledge == 0){
                this.goBtn.setVisibility(View.GONE);
                this.checkBox.setVisibility(View.VISIBLE);
                this.checkBox.setImageResource(R.drawable.ic_questions);
                this.location.setVisibility(View.VISIBLE);
            }
//            else if (acknowledge == 0 && isMy == 0){
//                this.goBtn.setVisibility(View.VISIBLE);
//                this.goBtn.setText("Confirm Acknowledge");
//                this.checkBox.setVisibility(View.VISIBLE);
//                this.checkBox.setImageResource(R.drawable.ic_questions);
//                this.location.setVisibility(View.VISIBLE);
//            }

            if (isChecked){
                this.goBtn.setVisibility(View.GONE);
                this.checkBox.setVisibility(View.VISIBLE);
                this.checkBox.setImageResource(R.drawable.ic_check_dispatch);
                this.location.setVisibility(View.GONE);
            }

            goBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    Intent intent = new Intent(context, CodRtcDispatchZone.class);
//                    CodRtcDispatchZone.directAckBarcode = barcode;
//                    itemView.getContext().startActivity(intent);
                }
            });


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            variant_image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mIRetrofitApi = Common.getApiArobil();
                    String token = SharedPreperenceUtils.getToken(context);

                    compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<VariantImageResponse>() {
                        @Override
                        public void accept(VariantImageResponse response) throws Exception {
                            if (response.status == 1){
                                variantImageList = response.data;
                                ImageShowPage.variantImageList = variantImageList;
                                Intent intent = new Intent(context, ImageShowPage.class);
                                itemView.getContext().startActivity(intent);

                            }else {

                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    }));
                }
            });

        }
     }
}
