package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.ukshop.Adapters.ReturnItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.BarcodeQtyModel;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.disposables.CompositeDisposable;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class ReturnPage extends AppCompatActivity implements ZXingScannerView.ResultHandler {

    private CoordinatorLayout rootLayout;
    private RecyclerView recyclerView;
    private List<BarcodeQtyModel> list = new ArrayList<>();
    private ReturnItemAdapter adapter;
    private LinearLayout productScanner;
    private MaterialToolbar toolbar;
    private static Button returnBtn, scanItemBtn;
    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static final int CAMERA_PERMISSION_CODE = 501;

    private static boolean isFlash = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_return_page);

        initiallyFindFields();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new ReturnItemAdapter(list,this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        productScanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (Utils.isCameraPermission(ReturnPage.this)) {
//                    openScanner();
//                } else {
//                    ActivityCompat.requestPermissions(ReturnPage.this,
//                            new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
//                }
            }
        });

        scanItemBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(ReturnPage.this)) {
                    openScanner();
                } else {
                    ActivityCompat.requestPermissions(ReturnPage.this,
                            new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
                }
            }
        });

    }

    private void initiallyFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.returnRootLayoutID);
        recyclerView = (RecyclerView)findViewById(R.id.returnItemRecyclerID);
        toolbar = (MaterialToolbar)findViewById(R.id.returnToolbarID);
        productScanner = (LinearLayout) findViewById(R.id.returnScanItemIconID);
        returnBtn = (Button)findViewById(R.id.returnhBtnID);
        scanItemBtn = (Button)findViewById(R.id.scanItemBtnAID);
    }

    private void openScanner(){
        scannerDialog = new Dialog(ReturnPage.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);



        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(ReturnPage.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
       list = new ArrayList<>();
       finish();}


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }



    @Override
    public void handleResult(final Result rawResult) {
        final Dialog qtyDialog = new Dialog(ReturnPage.this);
        qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        qtyDialog.getWindow().setLayout(width,height);
        qtyDialog.setCancelable(false);
        qtyDialog.show();

        final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
        Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
        Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qtyDialog.dismiss();
            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String string = qty.getText().toString();
                int quantity = Integer.parseInt(string);
                String barcode = rawResult.getText();

                final BarcodeQtyModel barcodeModel = new BarcodeQtyModel();

                barcodeModel.barcode = barcode;
                barcodeModel.qty = quantity;

                list.add(barcodeModel);
                adapter.addItem(list);
                setBtnVisible(list);
                qtyDialog.dismiss();
                scannerView.setResultHandler(ReturnPage.this);
                scannerView.startCamera();
            }
        });
    }

    public static void setBtnVisible(List<BarcodeQtyModel> list1){
        if (list1.size() > 0){
            returnBtn.setVisibility(View.VISIBLE);
        }else {
            returnBtn.setVisibility(View.GONE);
        }
    }



}