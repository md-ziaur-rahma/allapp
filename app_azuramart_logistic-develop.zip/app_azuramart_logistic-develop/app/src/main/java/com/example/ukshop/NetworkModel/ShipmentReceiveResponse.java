package com.example.ukshop.NetworkModel;

public class ShipmentReceiveResponse extends ApiResponse{
}
