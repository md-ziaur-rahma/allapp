package com.example.ukshop.Adapters;

import android.app.Activity;
import android.app.Dialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.Activity.ReturnPage;
import com.example.ukshop.NetworkModel.BarcodeQtyModel;
import com.example.ukshop.R;

import java.util.List;

public class ReturnItemAdapter extends RecyclerView.Adapter<ReturnItemAdapter.ViewHolder> {

    private List<BarcodeQtyModel> list;
    private Activity context;
    private CoordinatorLayout rootlayout;

    public ReturnItemAdapter(List<BarcodeQtyModel> list, Activity context, CoordinatorLayout rootlayout) {
        this.list = list;
        this.context = context;
        this.rootlayout = rootlayout;
    }

    @NonNull
    @Override
    public ReturnItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.boxing_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReturnItemAdapter.ViewHolder holder, int position) {
        int qty = list.get(position).qty;
        String barcode = list.get(position).barcode;

        holder.setData(barcode,qty,position);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void addItem(List<BarcodeQtyModel> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView barcode, qty;
        ImageView delete, edit;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            barcode = itemView.findViewById(R.id.boxingItemBarcodeID);
            qty = itemView.findViewById(R.id.boxingItemQtyID);
            delete = itemView.findViewById(R.id.boxingItemDeleteID);
            edit = itemView.findViewById(R.id.boxingItemEditID);


        }
        public void setData(final String barcode, final int qty, final int position){
            this.barcode.setText(""+barcode);
            this.qty.setText("Qty : "+qty);


            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    list.remove(position);
                    notifyItemRangeChanged(position,list.size());
                    notifyDataSetChanged();
                    ReturnPage.setBtnVisible(list);
                }
            });

            edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final Dialog qtyDialog = new Dialog(context);
                    qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                    int width = WindowManager.LayoutParams.MATCH_PARENT;
                    int height = WindowManager.LayoutParams.WRAP_CONTENT;

                    qtyDialog.getWindow().setLayout(width,height);
                    qtyDialog.setCancelable(false);
                    qtyDialog.show();

                    final EditText qtyText = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                    Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                    Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);

                    qtyText.setText(""+qty);
                    ok.setText("Update");

                    cancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            qtyDialog.dismiss();
                        }
                    });

                    ok.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String newQuantity = qtyText.getText().toString();
                            int newQtyInt = Integer.parseInt(newQuantity);

                            final BarcodeQtyModel barcodeList = new BarcodeQtyModel();
                            barcodeList.barcode = barcode;
                            barcodeList.qty = newQtyInt;

                            list.set(position,barcodeList);
                            notifyDataSetChanged();
                            ReturnPage.setBtnVisible(list);
                            qtyDialog.dismiss();
                        }
                    });
                }
            });

        }

    }

}
