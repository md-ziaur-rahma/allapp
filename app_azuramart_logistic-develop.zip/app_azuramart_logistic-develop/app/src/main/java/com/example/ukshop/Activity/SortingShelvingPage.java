package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.ukshop.Adapters.BoxingItemAdapter;
import com.example.ukshop.Adapters.ShelvingItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.NetworkModel.BoxingItemPost;
import com.example.ukshop.NetworkModel.BoxingItemResponse;
import com.example.ukshop.NetworkModel.BoxingItemSubModel;
import com.example.ukshop.NetworkModel.MasterProductDetailsResponse;
import com.example.ukshop.NetworkModel.ShelvingItemPost;
import com.example.ukshop.NetworkModel.ShelvingItemSubModel;
import com.example.ukshop.NetworkModel.ShelvingPost;
import com.example.ukshop.NetworkModel.ShelvingPostItemResponse;
import com.example.ukshop.NetworkModel.ShelvingResponse;
import com.example.ukshop.NetworkModel.StockCheckPost;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class SortingShelvingPage extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private static Button shelvetBtn, unshelvingBtn;
    private static TextView shelveLabel;
    private LinearLayout scanProductLabel,scanShelveLabel;

    private RecyclerView recyclerView;
    private List<ShelvingPostItemResponse.Data> mainList = new ArrayList<>();

    private List<MasterProductDetailsResponse.Data> tempList = new ArrayList<>();
    private static List<ShelvingItemSubModel> shelvingItemList = new ArrayList<>();
    private ShelvingItemAdapter adapter;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private static String strShelveLabel;

    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static final int CAMERA_PERMISSION_CODE = 501;

    private static boolean isFlash = false;
    private int productORshelve = 0;
    private static boolean isCamreOpen = false;

    private boolean isInvalid = false;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();
    private int isTone = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shorting_shelving_page);

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();

        // ............... find variables ................ //
        initialFindFields();

        // ............... hide shelve and unshelve button ................ //
        shelvetBtn.setVisibility(View.GONE);
        unshelvingBtn.setVisibility(View.GONE);



        // ............... set layout to recyclerview ................ //
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new ShelvingItemAdapter(mainList,shelvingItemList,SortingShelvingPage.this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();



        // ............... Scan shelve label ................ //
        scanShelveLabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(SortingShelvingPage.this)){
                    productORshelve = 1;
                    isTone = 1;
                    openScanner();
                }else {
                    ActivityCompat.requestPermissions(SortingShelvingPage.this,new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
                }
            }
        });


        scanShelveLabel.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                final Dialog dialog = new Dialog(SortingShelvingPage.this,R.style.PauseDialog);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
                barcodeText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(10)});

                search.setText(R.string.ok);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){
                            if (barcode.length() == 10){
                                isTone = 0;
                                strShelveLabel = barcode;
                                shelveLabel.setText("Shelve Label : "+barcode);
                                dialog.dismiss();
                            }else {
                                Toast.makeText(SortingShelvingPage.this,"This is not shelve label !",Toast.LENGTH_LONG).show();
                            }
                        }else {
                            Toast.makeText(SortingShelvingPage.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });

                return false;
            }
        });

        // ............... Scan product label ................ //
        scanProductLabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(SortingShelvingPage.this)){
                    productORshelve = 2;
                    isTone = 1;
                    openScanner();
                }else {
                    ActivityCompat.requestPermissions(SortingShelvingPage.this,new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
                }
            }
        });
        
        scanProductLabel.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final Dialog dialog = new Dialog(SortingShelvingPage.this,R.style.PauseDialog);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
                //barcodeText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(10)});

                search.setText(R.string.ok);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                
                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String productBarcode = barcodeText.getText().toString();
                        if (!productBarcode.equals("")){
                            isTone = 0;
                            getItem(productBarcode);
                            dialog.dismiss();
                        }else {
                            Toast.makeText(SortingShelvingPage.this, "Empty Product Barcode!", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                
                
                return false;
            }
        });



        // ............... shelving products ................ //
        shelvetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(SortingShelvingPage.this,rootLayout)){
                    if (shelvingItemList.size() != 0){
                        if (!TextUtils.isEmpty(strShelveLabel)){

                            final Dialog dialog = new Dialog(SortingShelvingPage.this);
                            dialog.setContentView(R.layout.transparent_progress_dialoge);

                            int width = WindowManager.LayoutParams.WRAP_CONTENT;
                            int height = WindowManager.LayoutParams.WRAP_CONTENT;

                            dialog.getWindow().setLayout(width,height);
                            dialog.setCancelable(false);
                            dialog.show();

                            String token = SharedPreperenceUtils.getToken(SortingShelvingPage.this);
                            int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(SortingShelvingPage.this));

                            final ShelvingPost post = new ShelvingPost();
                            post.is_update = 0;
                            post.shelve_label = strShelveLabel;
                            post.user_id = user_id;
                            post.data = shelvingItemList;

                            compositeDisposable.add(mIRetrofitApi.shelving(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ShelvingResponse>() {
                                @Override
                                public void accept(ShelvingResponse response) throws Exception {
                                    if (response.status == 1){
                                        Snackbar snackbar = Snackbar.make(rootLayout,""+response.message,Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                        dialog.dismiss();

                                        strShelveLabel = null;
                                        tempList = new ArrayList<>();
                                        shelvingItemList = new ArrayList<>();
                                        mainList = new ArrayList<>();
                                        adapter.addItem(mainList,shelvingItemList);
                                        shelveLabel.setText(getResources().getString(R.string.shelving_shelve_label));
                                        updateList(2,shelvingItemList);
                                    }else {
                                        dialog.dismiss();

                                        if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                            Utils.expiredTokenAlert(rootLayout,SortingShelvingPage.this);
                                        }else {
                                            Utils.snackbarToast(rootLayout,response.message);
                                        }
                                    }
                                }
                            }, new Consumer<Throwable>() {
                                @Override
                                public void accept(Throwable throwable) throws Exception {
                                    dialog.dismiss();

                                    if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                        Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 15000);
                                        snackbar.show();
                                    }else {
                                        Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                    }
                                }
                            }));

                        }else {
                            Snackbar snackbar = Snackbar.make(rootLayout,"Scan Shelve Label!",Snackbar.LENGTH_LONG);
                            snackbar.show();
                        }
                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,"Scan Minimum One Item!",Snackbar.LENGTH_LONG);
                        snackbar.show();
                    }
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,"No internet connection!",Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        });



        // ............... Un shelve product ................ //
        unshelvingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(SortingShelvingPage.this,rootLayout)){
                    if (shelvingItemList.size() != 0){
                        if (!TextUtils.isEmpty(strShelveLabel)){

                            final Dialog dialog = new Dialog(SortingShelvingPage.this);
                            dialog.setContentView(R.layout.transparent_progress_dialoge);

                            int width = WindowManager.LayoutParams.WRAP_CONTENT;
                            int height = WindowManager.LayoutParams.WRAP_CONTENT;

                            dialog.getWindow().setLayout(width,height);
                            dialog.setCancelable(false);
                            dialog.show();

                            String token = SharedPreperenceUtils.getToken(SortingShelvingPage.this);
                            int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(SortingShelvingPage.this));

                            final ShelvingPost post = new ShelvingPost();
                            post.is_update = 0;
                            post.shelve_label = strShelveLabel;
                            post.user_id = user_id;
                            post.data = shelvingItemList;

                            compositeDisposable.add(mIRetrofitApi.shelving(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ShelvingResponse>() {
                                @Override
                                public void accept(ShelvingResponse response) throws Exception {
                                    if (response.status == 1){
                                        Snackbar snackbar = Snackbar.make(rootLayout,""+response.message,Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                        dialog.dismiss();

                                        strShelveLabel = null;
                                        tempList = new ArrayList<>();
                                        shelvingItemList = new ArrayList<>();
                                        mainList = new ArrayList<>();
                                        adapter.addItem(mainList,shelvingItemList);
                                        shelveLabel.setText(getResources().getString(R.string.shelving_shelve_label));
                                        updateList(2,shelvingItemList);
                                    }else {
                                        dialog.dismiss();

                                        if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                            Utils.expiredTokenAlert(rootLayout,SortingShelvingPage.this);
                                        }else {
                                            Utils.snackbarToast(rootLayout,response.message);
                                        }
                                    }
                                }
                            }, new Consumer<Throwable>() {
                                @Override
                                public void accept(Throwable throwable) throws Exception {
                                    dialog.dismiss();

                                    if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                        Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 15000);
                                        snackbar.show();
                                    }else {
                                        Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                    }
                                }
                            }));

                        }else {
                            Snackbar snackbar = Snackbar.make(rootLayout,"Please scan shelve label!",Snackbar.LENGTH_LONG);
                            snackbar.show();
                        }
                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,"Scan Minimum One Item!",Snackbar.LENGTH_LONG);
                        snackbar.show();
                    }
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,"No internet connection!",Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        });



        // ............... toolbar related code ................ //
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.menuShipment_refreshId){
                    shelvingItemList = new ArrayList<>();
                    mainList = new ArrayList<>();
                    adapter.addItem(mainList,shelvingItemList);
                    updateList(2,shelvingItemList);
                    Snackbar snackbar = Snackbar.make(rootLayout,"Cleared All",Snackbar.LENGTH_LONG);
                    snackbar.show();
                    return true;
                }else {
                    return false;
                }
            }
        });


        // ............... check session ................ //
        if (Utils.broadcastIntent(this,rootLayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootLayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
            snackbar.show();
        }

    }


    // ............... check session method ................ //
    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mIRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ApiResponse>() {
            @Override
            public void accept(ApiResponse response) throws Exception {
                if (response.status == 0) {
                    isInvalid = true;
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));

        return isInvalid;
    }


    // ............... finding variable method ................ //
    private void initialFindFields(){
        rootLayout = (CoordinatorLayout)findViewById(R.id.shelvingRoolLayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.shelvingToolbarID);

        shelvetBtn = (Button)findViewById(R.id.shelvingbtnID);
        unshelvingBtn = (Button)findViewById(R.id.unshelvingbtnID);
        scanProductLabel = (LinearLayout)findViewById(R.id.shelvingProductScanBtnID);
        scanShelveLabel = (LinearLayout)findViewById(R.id.shelvingScanBtnID);

        recyclerView = (RecyclerView)findViewById(R.id.shelvingRecyclerID);
        shelveLabel = (TextView)findViewById(R.id.sehlvingShalveLabelxTextID);

    }


    // ............... scanner open method ................ //
    private void openScanner(){
        scannerDialog = new Dialog(SortingShelvingPage.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


        isCamreOpen = true;
        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(SortingShelvingPage.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                isCamreOpen = false;
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }


    // ............... permission response method ................ //
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }


    @Override
    protected void onStart() {
        super.onStart();
        //boxLabelText = null;
        //boxLebel.setText(getResources().getString(R.string.boxin_box_label));
        //boxingItemList = new ArrayList<>();
        //mainList = new ArrayList<>();
        //tempList = new ArrayList<>();
    }

    @Override
    public void onBackPressed() {
        strShelveLabel = null;
        shelveLabel.setText(getResources().getString(R.string.shelving_shelve_label));
        shelvingItemList = new ArrayList<>();
        mainList = new ArrayList<>();
        tempList = new ArrayList<>();

        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }


    // ............... passable method ................ //
    public static void updateList(int no, List<ShelvingItemSubModel> postList){
        if (no == 1){
            shelvingItemList = postList;
            shelvetBtn.setVisibility(View.VISIBLE);
            unshelvingBtn.setVisibility(View.GONE);
        }else if (no == 2){
            shelvingItemList = postList;
            strShelveLabel = null;
            shelveLabel.setText(R.string.shelving_shelve_label);
            shelvetBtn.setVisibility(View.GONE);
            unshelvingBtn.setVisibility(View.GONE);
        }
    }

    // ............... scanner response method ................ //
    @Override
    public void handleResult(final Result rawResult) {

        if (!TextUtils.isEmpty(rawResult.getText())){
            if (productORshelve == 1){

                if (rawResult.getText().length() == 10){
                    rightTone.start();

                    strShelveLabel = rawResult.getText();
                    shelveLabel.setText("Shelve Label : "+rawResult.getText());
                    isCamreOpen = false;
                    productORshelve = 0;
                    scannerDialog.dismiss();
                    scannerView.stopCamera();
                }else {
                    wrongTone.start();
                    isCamreOpen = false;
                    productORshelve = 0;
                    scannerDialog.dismiss();
                    scannerView.stopCamera();
                    Utils.snackbarToast(rootLayout,"This is not shelve label!");
                }
            }else if (productORshelve == 2){
                getItem(rawResult.getText());
            }
        }else {
            wrongTone.start();
            scannerDialog.dismiss();
            Utils.snackbarToast(rootLayout,"Empty barcode!");
        }
    }


    private void getItem(final String barcode){
        final String token = SharedPreperenceUtils.getToken(this);
        final int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(SortingShelvingPage.this));

        //final String barcode = rawResult.getText();

        final StockCheckPost checkPost = new StockCheckPost();
        checkPost.user_id = user_id;
        checkPost.barcode = barcode;
        checkPost.sku_id = "";
        checkPost.mkt_id = "";
        checkPost.product_name = "";

        compositeDisposable.add(mIRetrofitApi.getVariantEntryCheckList(token,checkPost).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<MasterProductDetailsResponse>() {
            @Override
            public void accept(final MasterProductDetailsResponse response) throws Exception {

                if (response.status == 1){

                    tempList = response.data;

                    final ShelvingItemPost post = new ShelvingItemPost();
                    post.sku_id = tempList.get(0).sku_id;
                    post.user_id = user_id;

                    compositeDisposable.add(mIRetrofitApi.getShelvingPostItem(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ShelvingPostItemResponse>() {
                        @Override
                        public void accept(final ShelvingPostItemResponse postItemResponse) throws Exception {

                            if (postItemResponse.status == 1){

                                if (isTone == 1){
                                    rightTone.start();
                                }

                                int checkQty = 0;
                                if (shelvingItemList.size() > 0){

                                    for (int i = 0; i <shelvingItemList.size(); i++){
                                        if (postItemResponse.data.get(0).sku_id.equals(shelvingItemList.get(i).sku_id)){
                                            checkQty += shelvingItemList.get(i).qty;
                                        }
                                    }
                                }

                                if ((postItemResponse.data.get(0).available_qty - checkQty) > 0){


                                    final Dialog qtyDialog = new Dialog(SortingShelvingPage.this);
                                    qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                                    int width = WindowManager.LayoutParams.MATCH_PARENT;
                                    int height = WindowManager.LayoutParams.WRAP_CONTENT;

                                    qtyDialog.getWindow().setLayout(width,height);
                                    qtyDialog.setCancelable(false);
                                    qtyDialog.show();

                                    final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                                    Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                                    Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                                    TextView d_avl_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);

                                    d_avl_qty.setText("Avl Qty : "+ (postItemResponse.data.get(0).available_qty - checkQty));
                                    // d_avl_qty.setText("Avl Qty : "+ postItemResponse.data.get(0).available_qty);



                                    ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                                    TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                                    TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                                    TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                                    String insPrimaryImage = Common.BASEURL_PICTURE + postItemResponse.data.get(0).primary_image;

                                    if (postItemResponse.data.get(0).variant_primary_image == null || postItemResponse.data.get(0).variant_primary_image.equals("")) {
                                        Glide.with(SortingShelvingPage.this)
                                                .load(insPrimaryImage)
                                                .placeholder(R.drawable.ic_default)
                                                .into(cardImage);
                                    } else {
                                        String insVariantImage = Common.BASEURL_PICTURE + postItemResponse.data.get(0).variant_primary_image;


                                        Glide.with(SortingShelvingPage.this)
                                                .load(insVariantImage)
                                                .placeholder(R.drawable.ic_default)
                                                .into(cardImage);
                                    }


                                    if (postItemResponse.data.get(0).variant_name == null || postItemResponse.data.get(0).variant_name.equals("")) {
                                        cardName.setText(postItemResponse.data.get(0).product_name);
                                    } else {
                                        cardName.setText(postItemResponse.data.get(0).variant_name);
                                    }

                                    cardColor.setText("Color : " + postItemResponse.data.get(0).color);
                                    cardSize.setText("Size : " + postItemResponse.data.get(0).size);


                                    cancel.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            if (isTone == 1){
                                                scannerDialog.dismiss();
                                            }
                                            qtyDialog.dismiss();
                                        }
                                    });


                                    final int finalCheckQty = checkQty;
                                    ok.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            if (!TextUtils.isEmpty(qty.getText())){
                                                String string = qty.getText().toString();
                                                int quantity = Integer.parseInt(string);
                                                //String barcode = rawResult.getText();
                                                if (quantity <= (postItemResponse.data.get(0).available_qty - finalCheckQty)){

                                                    if (quantity == 0){
                                                        quantity = 1;
                                                    }

                                                    final ShelvingItemSubModel subModel = new ShelvingItemSubModel();

                                                    subModel.barcode = barcode;
                                                    subModel.qty = quantity;
                                                    subModel.sku_id = postItemResponse.data.get(0).sku_id;

                                                    shelvingItemList.add(subModel);


                                                    ShelvingPostItemResponse.Data item = new ShelvingPostItemResponse.Data();
                                                    item.primary_image = postItemResponse.data.get(0).primary_image;
                                                    item.variant_primary_image = postItemResponse.data.get(0).variant_primary_image;
                                                    item.color = postItemResponse.data.get(0).color;
                                                    item.mkt_id = postItemResponse.data.get(0).mkt_id;
                                                    item.size = postItemResponse.data.get(0).size;
                                                    item.sku_id = postItemResponse.data.get(0).sku_id;
                                                    item.variant_name = postItemResponse.data.get(0).variant_name;
                                                    item.product_name = postItemResponse.data.get(0).product_name;
                                                    //item.available_qty = (postItemResponse.data.get(0).available_qty - finalCheckQty);
                                                    item.available_qty = postItemResponse.data.get(0).available_qty;

                                                    mainList.add(item);
                                                    adapter.addItem(mainList,shelvingItemList);
                                                    qtyDialog.dismiss();
                                                    if (isTone == 1){
                                                        scannerDialog.dismiss();
                                                    }

                                                    Toast.makeText(SortingShelvingPage.this, "List Size : "+shelvingItemList.size(), Toast.LENGTH_SHORT).show();

                                                }else {
                                                    qty.requestFocus();
                                                    Toast.makeText(SortingShelvingPage.this, "Enter less then or equal : "+tempList.get(0).available_qty, Toast.LENGTH_SHORT).show();
                                                }
                                            }else {
                                                qty.requestFocus();
                                                Toast.makeText(SortingShelvingPage.this, "Enter minimum 1 qty!", Toast.LENGTH_SHORT).show();
                                            }


                                        }
                                    });

                                }else {
                                    if (isTone == 1){
                                        scannerDialog.dismiss();
                                    }
                                    Utils.snackbarToast(rootLayout,"Product not available for scan!");
                                }



                            }else {

                                if (isTone == 1){
                                    wrongTone.start();
                                    scannerDialog.dismiss();
                                }
                                if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                    Utils.expiredTokenAlert(rootLayout,SortingShelvingPage.this);
                                }else {
                                    Utils.snackbarToast(rootLayout,postItemResponse.message);
                                }
                            }

                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                            if (isTone == 1){
                                wrongTone.start();
                                scannerDialog.dismiss();
                            }
                            if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                                snackbar.show();
                            }else {
                                Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        }
                    }));

                }else {

                    if (isTone == 1){
                        wrongTone.start();
                        scannerDialog.dismiss();
                    }
                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout,SortingShelvingPage.this);
                    }else {
                        Utils.snackbarToast(rootLayout,response.message);
                    }
                }

            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

                if (isTone == 1){
                    wrongTone.start();
                    scannerDialog.dismiss();
                }
                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        }));
    }

}