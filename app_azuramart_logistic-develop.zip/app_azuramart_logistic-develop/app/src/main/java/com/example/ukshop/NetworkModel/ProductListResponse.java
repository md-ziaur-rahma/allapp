package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ProductListResponse extends ApiResponse {

    @SerializedName("data")
    public ArrayList<Data> data;

    public class Data{
        @SerializedName("sku_id")
        public String sku_id;

        @SerializedName("mkt_id")
        public String mkt_id;

        @SerializedName("product_name")
        public String product_name;

        @SerializedName("product_variant_name")
        public String variant_name;

        @SerializedName("size")
        public String size;

        @SerializedName("color")
        public String color;

        @SerializedName("price")
        public float price;

        @SerializedName("variant_primary_image")
        public String variant_primary_image;

        @SerializedName("primary_image")
        public String primary_image;

        @SerializedName("available_qty")
        public int available_qty;
    }
}
