package com.example.ukshop.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.ProductListPage;
import com.example.ukshop.NetworkModel.MasterProductResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;

import static maes.tech.intentanim.CustomIntent.customType;

import java.util.ArrayList;
import java.util.List;

public class MasterProductAdapter extends RecyclerView.Adapter<MasterProductAdapter.ViewHolder> {

    private List<MasterProductResponse.Data> list;
    private Activity context;

    public MasterProductAdapter(List<MasterProductResponse.Data> list, Activity context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public MasterProductAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.master_product_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MasterProductAdapter.ViewHolder holder, int position) {
        int mp_id = list.get(position).mp_id;
        String imageUrl = list.get(position).mp_image;
        String name = list.get(position).mp_name;
        String brand = list.get(position).mp_brand;
        String model = list.get(position).mp_model;

        holder.setData(mp_id, imageUrl, name, brand, model, position);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void filteredItem(List<MasterProductResponse.Data> filterList){
        list = filterList;
        notifyDataSetChanged();
    }

    public void updateList(List<MasterProductResponse.Data> updateList){
        list = updateList;
        notifyDataSetChanged();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{

        private ImageView image;
        private TextView name,model,brand;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.mpItemImageID);
            name = itemView.findViewById(R.id.mpItemNameID);
            brand = itemView.findViewById(R.id.mpItemBrandID);
            model = itemView.findViewById(R.id.mpItemModelID);

        }

        public void setData(final int mp_id, String imageUrl, String name, String brand, String model, int position){

            if (imageUrl == null || imageUrl == ""){
                image.setImageResource(R.drawable.ic_default);
            }else {
                imageUrl = Common.BASEURL_PICTURE +imageUrl;
                Glide.with(context)
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_default)
                        .into(this.image);
            }

            this.name.setText(name);
            this.model.setText(model);
            this.brand.setText(brand);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, ProductListPage.class);
                    intent.putExtra("mp_id",mp_id);
                    Common.master_product_id = mp_id;
                    itemView.getContext().startActivity(intent);
                    customType(context,"left-to-right");
                }
            });


        }
    }
}
