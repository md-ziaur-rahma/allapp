package com.example.ukshop;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;

import com.example.ukshop.Activity.CheckEntry;
import com.example.ukshop.Activity.HomePage;
import com.example.ukshop.Activity.LoginPage;
import com.example.ukshop.Activity.ProductListPage;
import com.example.ukshop.Activity.SplashScreen;
import com.example.ukshop.Activity.StockCheckPage;
import com.example.ukshop.Adapters.MasterProductAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.MasterProductResponse;
import com.example.ukshop.NetworkModel.ProductListPost;
import com.example.ukshop.NetworkModel.ProductListResponse;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static maes.tech.intentanim.CustomIntent.customType;

public class MasterProductPage extends AppCompatActivity {

    private CoordinatorLayout masterRootLayout;
    private EditText searchText;
    private MaterialToolbar materialToolbar;
    private NestedScrollView nestedScrollView;

    private List<MasterProductResponse.Data> masterProductList = new ArrayList<>();
    private List<MasterProductResponse.Data> mastermainList = new ArrayList<>();
    private RecyclerView recyclerView;
    private MasterProductAdapter masterAdaper;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    IRetrofitApi mIRetrofitApi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_master_product_page);


        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        loadData();

        materialToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        searchText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (masterProductList.size() > 0 ){
                    if (!TextUtils.isEmpty(s.toString())){
                        filterText(s.toString());
                    }else{
                        filterText("");
                    }
                }


            }
        });

        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                if(v.getChildAt(v.getChildCount() - 1) != null) {
                    if ((scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight())) &&
                            scrollY > oldScrollY) {

                        //https://medium.com/@mujjtahidah/load-more-recyclerview-inside-nested-scroll-view-and-coordinator-layout-4f179dc01fd

                        if (!recyclerView.canScrollVertically(1)){
                            onScrollToBottom();
                        }



                    }
                }

            }
        });


    }

    private void onScrollToBottom(){
        if (mastermainList.size() < masterProductList.size()){
            int x,y;
            if ((masterProductList.size() - mastermainList.size()) >= 20){
                x = mastermainList.size();
                y = x + 20;
            }else {
                x = mastermainList.size();
                y = x + masterProductList.size() - mastermainList.size();
            }

            for (int i = x; i < y; i++){
                mastermainList.add(i,masterProductList.get(i));
            }

            masterAdaper.updateList(mastermainList);
        }
    }

    private void filterText(String text){
        mastermainList = new ArrayList<>();
        ArrayList<MasterProductResponse.Data> filteredList = new ArrayList<>();

        for (MasterProductResponse.Data item : masterProductList){
            if (isMatches(text,item.mp_name)
                ||isMatches(text,item.mp_brand)
                ||isMatches(text,item.mp_model)
            ){filteredList.add(item);}
        }

        if (filteredList.size() >= 20){
            for (int i = 0; i < 20; i++){
                mastermainList.add(filteredList.get(i));
            }
        }else {
            mastermainList = filteredList;
        }
        masterAdaper.filteredItem(mastermainList);
    }

    private boolean isMatches(String input,String name){
        String[] split = input.split(" ");
        for (String s : split){
            if (name.toLowerCase().contains(s.toLowerCase())){
                return true;
            }
        }
        return false;
    }


    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    private void loadData() {
        if (Utils.broadcastIntent(this,masterRootLayout)){
            final Dialog dialog = new Dialog(MasterProductPage.this);
            dialog.setContentView(R.layout.transparent_progress_dialoge);

            int width = WindowManager.LayoutParams.WRAP_CONTENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(false);
            dialog.show();


            String token = SharedPreperenceUtils.getToken(MasterProductPage.this);

            compositeDisposable.add(mIRetrofitApi.getMasterProdutctList(token).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<MasterProductResponse>() {
                @Override
                public void accept(MasterProductResponse masterProductResponse) throws Exception {
                    if (masterProductResponse.status == 1){
                        masterProductList = masterProductResponse.data;

                        if (masterProductList.size() >= 30){
                            for (int i = 0;i < 30; i++){
                                mastermainList.add(i, masterProductList.get(i));
                            }
                        }else {
                            for (int i = 0;i < masterProductList.size(); i++){
                                mastermainList.add(i, masterProductList.get(i));
                            }
                        }

                        masterAdaper = new MasterProductAdapter(mastermainList,MasterProductPage.this);
                        recyclerView.setAdapter(masterAdaper);
                        masterAdaper.notifyDataSetChanged();

                        dialog.dismiss();
                    }else {
                        dialog.dismiss();

                        if (masterProductResponse.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                            Utils.expiredTokenAlert(masterRootLayout, MasterProductPage.this);
                        }else {
                            Snackbar snackbar = Snackbar.make(masterRootLayout,""+masterProductResponse.message,Snackbar.LENGTH_LONG);
                            snackbar.setAction("Retry", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    loadData();
                                }
                            });
                            snackbar.show();
                        }
                    }
                }
            }, new Consumer<Throwable>() {
                @Override
                public void accept(Throwable throwable) throws Exception {

                    dialog.dismiss();

                    if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                        Snackbar snackbar = Snackbar.make(masterRootLayout, "Poor Internet Connection!", 5000);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                loadData();
                            }
                        });
                        snackbar.show();
                    }else {
                        Snackbar snackbar = Snackbar.make(masterRootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                loadData();
                            }
                        });
                        snackbar.show();
                    }
                }
            }));

        }else {
            NoInternetSnackBar();
        }
    }

    private void initialFindFields(){
        materialToolbar = (MaterialToolbar)findViewById(R.id.mpToolbarID);
        recyclerView = (RecyclerView)findViewById(R.id.mpRecyclerID);
        nestedScrollView = (NestedScrollView)findViewById(R.id.masterProductNestedScrollID);
        masterRootLayout = (CoordinatorLayout)findViewById(R.id.mpRootLayoutId);
        searchText = (EditText)findViewById(R.id.mpSearchID);
    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(masterRootLayout,"No Internet Connection!",10000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(MasterProductPage.this,masterRootLayout)){
                    loadData();
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }

}