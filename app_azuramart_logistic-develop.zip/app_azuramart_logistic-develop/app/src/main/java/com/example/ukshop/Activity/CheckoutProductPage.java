package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;

import com.example.ukshop.Adapters.CheckEntryAdapter;
import com.example.ukshop.Adapters.CheckoutProductAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.CheckoutProductPost;
import com.example.ukshop.NetworkModel.CheckoutProductResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class CheckoutProductPage extends AppCompatActivity {

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;

    private List<CheckoutProductResponse.Data> list = new ArrayList<>();
    private CheckoutProductAdapter adapter;
    private RecyclerView recyclerView;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout_product_page);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        testMethod();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new CheckoutProductAdapter(list,this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();


//        if (Utils.broadcastIntent(this,rootLayout)){
//            loadData();
//        }else {
//            NoInternetSnackBar();
//        }

        /// Toolbar home button...
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                int id = item.getItemId();

                if (id == R.id.menuShipment_refreshId) {
                    if (Utils.broadcastIntent(CheckoutProductPage.this,rootLayout)){
                        //loadData();
                        testMethod();
                        adapter.updateList(list);
                    }else {
                        NoInternetSnackBar();
                    }
                    return true;
                }
                return false;
            }
        });

    }

    private void testMethod(){

        list = new ArrayList<>();

        for (int i = 0; i<10; i++){
            final CheckoutProductResponse.Data tempList = new CheckoutProductResponse.Data();
            tempList.PK_NO = 1;
            tempList.sku_id = "LC123456678";
            tempList.barcode = "096756453423";
            tempList.color = "Magenta";
            tempList.size = "Lc round 18\"";

            final ArrayList<CheckoutProductResponse.Location> locationList = new ArrayList<>();



            for (int x = 0; x<3; x++){
                final CheckoutProductResponse.Location location = new CheckoutProductResponse.Location();
                if (x == 0){
                    location.locationData = "2nd floor room no 4 shelve no 9 Qty : 7";
                }else if (x == 1){
                    location.locationData = "4th floor room no 2 shelve no 23 Qty : 2";
                }else if (x ==2){
                    location.locationData = "3rd floor room no 12 shelve no 23 Qty : 3";
                }

                locationList.add(location);

            }

            tempList.location = locationList;

                    tempList.PK_NO = 1;
            tempList.primary_image = "";
            if (i == 2){
                tempList.variant_primary_image = "/media/images/products/149/prod_05122020_5fcb94f071055.jpg";
            }else if (i == 3){
                tempList.variant_primary_image = "/media/images/products/151/prod_05122020_5fcb9829914ee.jpg";
            }
            else if (i == 4){
                tempList.variant_primary_image = "/media/images/products/152/prod_05122020_5fcbb0b324617.jpg";
            }
            else if (i == 5){
                tempList.variant_primary_image = "/media/images/products/151/prod_05122020_5fcb9829914ee.jpg";
            }
            else if (i == 6){
                tempList.variant_primary_image = "/media/images/products/149/prod_05122020_5fcb94f071055.jpg";
            }
            else if (i == 7){
                tempList.variant_primary_image = "/media/images/products/152/prod_05122020_5fcbb0b324617.jpg";
            }else if (i == 8){
                tempList.variant_primary_image = "/media/images/products/151/prod_05122020_5fcb9829914ee.jpg";
            }else if (i == 9){
                tempList.variant_primary_image = "/media/images/products/149/prod_05122020_5fcb94f071055.jpg";
            }else if (i == 1){
                tempList.variant_primary_image =  "/media/images/products/151/prod_05122020_5fcb9829914ee.jpg";
            }else {
                tempList.variant_primary_image = "/media/images/products/152/prod_05122020_5fcbb0b324617.jpg";
            }
            tempList.variant_name = "LC Round Caserol 16 cm mug";
            tempList.qty = 12;
            tempList.product_name = "fsldfjsldf";
            tempList.shelve_label = "0234567891";

            list.add(tempList);
        }
    }

    private void loadData() {
        list = new ArrayList<>();
        adapter.updateList(list);

        final Dialog dialog = new Dialog(CheckoutProductPage.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        String token = SharedPreperenceUtils.getToken(CheckoutProductPage.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(CheckoutProductPage.this));

        final CheckoutProductPost post = new CheckoutProductPost();
        post.user_id = user_id;

        compositeDisposable.add(mIRetrofitApi.getCheckoutProduct(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<CheckoutProductResponse>() {
            @Override
            public void accept(CheckoutProductResponse response) throws Exception {
                if (response.status == 1){
                    list = response.data;
                    adapter.updateList(list);

                    dialog.dismiss();

                }else {
                    dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout,CheckoutProductPage.this);
                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,response.message,5000);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (Utils.broadcastIntent(CheckoutProductPage.this,rootLayout)){
                                    loadData();
                                }else {
                                    NoInternetSnackBar();
                                }
                            }
                        });

                        snackbar.show();
                    }
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.setAction("Retry", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Utils.broadcastIntent(CheckoutProductPage.this,rootLayout)){
                                loadData();
                            }else {
                                NoInternetSnackBar();
                            }
                        }
                    });
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,throwable.getMessage(),5000);
                    snackbar.setAction("Retry", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Utils.broadcastIntent(CheckoutProductPage.this,rootLayout)){
                                loadData();
                            }else {
                                NoInternetSnackBar();
                            }
                        }
                    });

                    snackbar.show();
                }
            }
        }));

    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(CheckoutProductPage.this,rootLayout)){
                    loadData();
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }

    private void initialFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.checkoutProductRootLayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.checkoutProductToolbarID);
        recyclerView = (RecyclerView)findViewById(R.id.checkoutProductRecyclerID);
    }
}