package com.example.ukshop.Receiver;

import android.app.ActivityManager;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.example.ukshop.Activity.LoginPage;
import com.example.ukshop.R;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;

import java.util.List;

import static android.content.Context.ACTIVITY_SERVICE;

public class SessionReceiver /**extends BroadcastReceiver */{

    private String packageName;
    private Context mContext;
//
//    @Override
//    public void onReceive(final Context context, final Intent intent) {
//        mContext = context;
//
//        if (foregroundPackage() == "com.example.ukshop"){
//            if (SharedPreperenceUtils.getToken(context) != null || SharedPreperenceUtils.getToken(context) != ""){
//                if (Utils.isSessionValid(context)){
//                    SharedPreperenceUtils.clearUserData(context);
//
//                    final Dialog dialog = new Dialog(context);
//                    dialog.setContentView(R.layout.session_expired_dialoge);
//
//                    int width = WindowManager.LayoutParams.MATCH_PARENT;
//                    int height = WindowManager.LayoutParams.WRAP_CONTENT;
//
//                    dialog.getWindow().setLayout(width,height);
//                    dialog.setCancelable(false);
//                    dialog.show();
//
//                    Button button = dialog.findViewById(R.id.dialogeSessionExpiredBtnID);
//
//                    button.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            Intent intentLogin = new Intent(context, LoginPage.class);
//                            context.startActivity(intentLogin);
//                        }
//                    });
//                }
//            }
//
//        }
//
//    }

    public String foregroundPackage() {
        ActivityManager manager = (ActivityManager)mContext.getSystemService(ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> runningTaskInfo = manager.getRunningTasks(1);
        ComponentName componentInfo = runningTaskInfo.get(0).topActivity;
        packageName = componentInfo.getPackageName();
        return componentInfo.getPackageName();
    }
}
