package com.example.ukshop.NetworkModel;

public class DispatchResponse extends ApiResponse{
}
