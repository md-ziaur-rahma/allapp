package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class UnshelvingItemSubmodel {
    @SerializedName("barcode")
    public String barcode;
    @SerializedName("sku_id")
    public String sku_id;
    @SerializedName("qty")
    public int qty;
}
