package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.snackbar.Snackbar;

public class SplashScreen extends AppCompatActivity {

    private CoordinatorLayout rootLayout;
    private ImageView topImage,smallLogo;
    private TextView bottomText;

    private Animation topAnimation, bottomAnimation, fade_in,spin_rotate,bounce_anim;

    private static final int REQUEST_INTERNET_PERMISSION = 201;
    private static final int REQUEST_NETWORKSTATE_PERMISSION = 202;

    @Override
    public void overridePendingTransition(int enterAnim, int exitAnim) {
        super.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        rootLayout = (CoordinatorLayout)findViewById(R.id.splashScreenRootLayoutID);
        topImage = (ImageView)findViewById(R.id.splashScreenTopImgeID);
        bottomText = (TextView)findViewById(R.id.splashScreenBottomTextID);
        smallLogo = (ImageView)findViewById(R.id.splashScreenSmallImgeID);

        topAnimation = AnimationUtils.loadAnimation(this, R.anim.top_to_bottom);
        bottomAnimation = AnimationUtils.loadAnimation(this,R.anim.bottom_to_top);
        fade_in = AnimationUtils.loadAnimation(this,R.anim.fade_in);
        spin_rotate = AnimationUtils.loadAnimation(this,R.anim.spin_rotate);
        bounce_anim = AnimationUtils.loadAnimation(this,R.anim.bounce_animation);

        topImage.setAnimation(topAnimation);
        //bottomText.setAnimation(bottomAnimation);
        bottomText.setAnimation(fade_in);
        smallLogo.setAnimation(bounce_anim);


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.INTERNET},REQUEST_INTERNET_PERMISSION);
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_NETWORK_STATE},REQUEST_NETWORKSTATE_PERMISSION);
        }

        new Handler().postDelayed(() -> {

            if (Utils.broadcastIntent(SplashScreen.this,rootLayout)){
                gotoPage();
            }else {
                ShowSnackBar();
            }
        },2000);

    }

    private void gotoPage(){
        if (SharedPreperenceUtils.getUser(SplashScreen.this) == null ||
                SharedPreperenceUtils.getUser(SplashScreen.this).equals("")){
                Intent intent = new Intent(SplashScreen.this,LoginPage.class);
                startActivity(intent);
                finish();
        }else {
//            int sourceFlag = SharedPreperenceUtils.getSourceFlag(SplashScreen.this);
//
//            if (sourceFlag == 1){
//                Common.BASE_URL_AROBIL = "https://admin.azuramart.com/api/";
//                Common.BASEURL_PICTURE = "https://admin.azuramart.com";
//                Common.BASE_POOR_MSG = "https://admin.azuramart.com/api/";
//            }else if (sourceFlag == 2){
//                Common.BASE_URL_AROBIL = "http://118.179.179.232:8888/ukshop_beta_dev/public/api/";
//                Common.BASEURL_PICTURE = "http://118.179.179.232:8888/ukshop_beta_dev/public";
//                Common.BASE_POOR_MSG = "118.179.179.232:8888/ukshop_beta/public";
//            }else if (sourceFlag == 3){
//                Common.BASE_URL_AROBIL = "http://192.168.203.247/api/";
//                Common.BASEURL_PICTURE = "http://192.168.203.247";
//                Common.BASE_POOR_MSG = "192.168.203.247";
//            }

            if (SharedPreperenceUtils.getUserLocation(SplashScreen.this).equals("UK")){
                Intent intent = new Intent(SplashScreen.this,HomePageUk.class);
                startActivity(intent);
                finish();
            }else if (SharedPreperenceUtils.getUserLocation(SplashScreen.this).equals("MY") && SharedPreperenceUtils.getRoleId(SplashScreen.this).equals("21")){
                Intent intent = new Intent(SplashScreen.this,HomePageCodDispatcher.class);
                startActivity(intent);
                finish();
            }else if (SharedPreperenceUtils.getUserLocation(SplashScreen.this).equals("MY") && SharedPreperenceUtils.getRoleId(SplashScreen.this).equals("26")){
                Intent intent = new Intent(SplashScreen.this,HomePageCustomer.class);
                startActivity(intent);
                finish();
            }else if (SharedPreperenceUtils.getUserLocation(SplashScreen.this).equals("MY") && !SharedPreperenceUtils.getRoleId(SplashScreen.this).equals("21") && !SharedPreperenceUtils.getRoleId(SplashScreen.this).equals("26")){
                Intent intent = new Intent(SplashScreen.this,HomePage.class);
                startActivity(intent);
                finish();
            }

        }
    }

    private void ShowSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection",15000);
        snackbar.setAction("Retry", v -> {
            if (Utils.broadcastIntent(SplashScreen.this,rootLayout)){
                gotoPage();
            }else {
                ShowSnackBar();
            }
        });

        snackbar.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_INTERNET_PERMISSION){
            if (grantResults.length > 0){

            }else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.INTERNET)){

                }
            }

        }else if (requestCode == REQUEST_NETWORKSTATE_PERMISSION){
            if (grantResults.length > 0 ){

            }else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.ACCESS_NETWORK_STATE)){

                }
            }
        }
    }
}