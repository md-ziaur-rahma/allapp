package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Dialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.CodRtcBoxedItemCollectPost;
import com.example.ukshop.NetworkModel.CodRtcSubModel;
import com.example.ukshop.NetworkModel.ShelvingResponse;
import com.example.ukshop.NetworkModel.UnboxingItemResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class CodRtcBoxedItemCollect extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private ExtendedFloatingActionButton collectProductFabBtn;

    private TextView successScanProductText,successScanBoxText;
    private TextView boxLabelText;
    private LinearLayout scanBox;

    // ..................... Item layout variables....................
    private TextView qty,avl_qty;
    private Button scanProductBtn;

    private ImageView variant_image;
    private TextView name,skuId,size,color;
    // ..................... Item layout variables ....................

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private Dialog scannerDialog;
    private ZXingScannerView scannerView;
    private final int CAMERA_PERMISSION_CODE = 501;

    private static boolean isFlash = false;
    private static boolean isCamreOpen = false;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();
    private int isTone = 0;
    private int boxORItem = 0;

    public static String strBoxLabel = "";
    public static UnboxingItemResponse.Data data;
    public static List<CodRtcSubModel> list;

    private int isProductScan = 0;
    private int isBoxScan = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cod_rtc_boxed_item_collect);

        rightTone = MediaPlayer.create(this, R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this, R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        setData();

        scanBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(CodRtcBoxedItemCollect.this)) {
                    boxORItem = 1;
                    isTone = 1;
                    openScanner();
                } else {
                    ActivityCompat.requestPermissions(CodRtcBoxedItemCollect.this,
                            new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
                }
            }
        });

        scanBox.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                isTone = 0;
                final Dialog dialog = new Dialog(CodRtcBoxedItemCollect.this,R.style.PauseDialog);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
                barcodeText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
                barcodeText.setInputType(InputType.TYPE_CLASS_TEXT);

                search.setText("Ok");
                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!TextUtils.isEmpty(barcodeText.getText().toString())){
                            if (barcodeText.getText().toString().length() == 8){
                                matchingBoxLabel(barcodeText.getText().toString());
                                dialog.dismiss();
                            }else {
                                barcodeText.requestFocus();
                                Toast.makeText(CodRtcBoxedItemCollect.this, "This is not box label!", Toast.LENGTH_SHORT).show();
                            }
                        }else {
                            barcodeText.requestFocus();
                            Toast.makeText(CodRtcBoxedItemCollect.this, "Empty label!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                return false;
            }
        });

        scanProductBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(CodRtcBoxedItemCollect.this)) {
                    boxORItem = 2;
                    isTone = 1;
                    openScanner();
                } else {
                    ActivityCompat.requestPermissions(CodRtcBoxedItemCollect.this,
                            new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
                }
            }
        });

        scanProductBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                isTone = 0;
                final Dialog dialog = new Dialog(CodRtcBoxedItemCollect.this,R.style.PauseDialog);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
                //barcodeText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
                barcodeText.setInputType(InputType.TYPE_CLASS_TEXT);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!TextUtils.isEmpty(barcodeText.getText().toString())){
                            matchingProduct(barcodeText.getText().toString());
                            dialog.dismiss();
                        }else {
                            barcodeText.requestFocus();
                            Toast.makeText(CodRtcBoxedItemCollect.this, "Empty Barcode!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                return false;
            }
        });

        collectProductFabBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isBoxScan == 1 && isProductScan == 1){

                    String token = SharedPreperenceUtils.getToken(CodRtcBoxedItemCollect.this);
                    int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(CodRtcBoxedItemCollect.this));

                    final Dialog dialog = new Dialog(CodRtcBoxedItemCollect.this);
                    dialog.setContentView(R.layout.transparent_progress_dialoge);

                    int width = WindowManager.LayoutParams.WRAP_CONTENT;
                    int height = WindowManager.LayoutParams.WRAP_CONTENT;

                    dialog.getWindow().setLayout(width,height);
                    dialog.setCancelable(false);
                    dialog.show();

                    final CodRtcBoxedItemCollectPost post = new CodRtcBoxedItemCollectPost();
                    post.box_label = strBoxLabel;
                    post.user_id = user_id;
                    post.data = list;

                    Log.e("collect boxed item","request"+new Gson().toJson(post));

                    compositeDisposable.add(mIRetrofitApi.codRtcBoxedItemTransfer(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ShelvingResponse>() {
                        @Override
                        public void accept(ShelvingResponse response) throws Exception {
                            if (response.status == 1){
                                dialog.dismiss();
                                Toast.makeText(CodRtcBoxedItemCollect.this, "Successfully Transferred", Toast.LENGTH_SHORT).show();
                                clearValue();
                                finish();
                            }else {
                                dialog.dismiss();

                                if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                                    Utils.expiredTokenAlert(rootLayout, CodRtcBoxedItemCollect.this);
                                } else {
                                    Utils.snackbarToast(rootLayout, response.message);
                                }
                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {
                            dialog.dismiss();

                            if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                                Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rootLayout, "" + throwable.getMessage(), Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        }
                    }));

                }else {
                    Utils.snackbarToast(rootLayout,"Scan and confirm! ");
                }
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private void setData() {
        collectProductFabBtn.setVisibility(View.GONE);
        successScanBoxText.setVisibility(View.GONE);
        successScanProductText.setVisibility(View.GONE);

        boxLabelText.setText("Box Label : "+strBoxLabel);
        scanProductBtn.setText("Scan Product");

        //String insPrimaryImage = Common.BASEURL_PICTURE + data.primary_image;

        if (data.variant_primary_image == null || data.variant_primary_image.equals("")){
            Glide.with(this)
                    .load(data.primary_image)
                    .placeholder(R.drawable.ic_default)
                    .into(variant_image);
        }else {
            //String insVariantImage = Common.BASEURL_PICTURE + data.variant_primary_image;


            Glide.with(this)
                    .load(data.variant_primary_image)
                    .placeholder(R.drawable.ic_default)
                    .into(variant_image);
        }



        if (data.variant_name == null || data.variant_name.equals("")){
            this.name.setText(data.product_name);
        }else {
            this.name.setText(data.variant_name);
        }

        //this.skuId.setText("SKU : "+sku);
        this.skuId.setText("Barcode : "+data.barcode);
        this.color.setText("Color : "+data.color);
        this.size.setText("Size : "+data.size);

        this.qty.setText("Qty : "+data.available_qty);
        this.avl_qty.setText("Avl Qty : "+data.available_qty);
    }

    private void clearValue(){
        isTone = 0;
        isBoxScan = 0;
        isProductScan = 0;
        strBoxLabel = "";
        data = new UnboxingItemResponse.Data();
        list = new ArrayList<>();
        boxORItem = 0;
        successScanProductText.setVisibility(View.GONE);
        successScanBoxText.setVisibility(View.GONE);
    }

    private void initialFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.codRtcBoxedItemCollectRootLayoutID);
        toolbar = (MaterialToolbar) findViewById(R.id.codRtcBoxedItemCollectToolbarID);
        collectProductFabBtn = (ExtendedFloatingActionButton) findViewById(R.id.codRtcBoxedItemCollectBoxScanFabBtnID);

        successScanProductText = (TextView) findViewById(R.id.codRtcBoxedItemCollectSuccessMsg1ID);
        successScanBoxText = (TextView) findViewById(R.id.codRtcBoxedItemCollectSuccessMsg2ID);
        boxLabelText = (TextView) findViewById(R.id.scan_product_textID);
        scanBox = (LinearLayout) findViewById(R.id.scan_productIconBtnID);

        variant_image = (ImageView)findViewById(R.id.unboxingl_item_imageID);
        name = (TextView)findViewById(R.id.unboxingl_item_nameID);
        skuId = (TextView)findViewById(R.id.unboxingl_item_skuID);
        size = (TextView)findViewById(R.id.unboxingl_item_sizeID);
        color = (TextView)findViewById(R.id.unboxingl_item_colorID);

        avl_qty = (TextView)findViewById(R.id.unboxingl_item_avl_qntID);
        qty = (TextView)findViewById(R.id.unboxingl_item_qntID);
        scanProductBtn = (Button) findViewById(R.id.unboxingl_item_unboxBtnID);

    }

    private void openScanner() {
        scannerDialog = new Dialog(CodRtcBoxedItemCollect.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width, height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);


        isCamreOpen = true;
        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(CodRtcBoxedItemCollect.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                isCamreOpen = false;
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash) {
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                } else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.length >= 0) {
                openScanner();
            } else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null) {
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()) {
            compositeDisposable.dispose();
        }

    }

    @Override
    public void handleResult(Result rawResult) {
        if (!TextUtils.isEmpty(rawResult.getText())){
            if (boxORItem == 1){
                matchingBoxLabel(rawResult.getText());
            }else if (boxORItem == 2){

            }
        }else {
            wrongTone.start();
            scannerDialog.dismiss();
            scannerView.stopCamera();
            Utils.snackbarToast(rootLayout, "Empty barcode!");
        }
    }

    private void matchingBoxLabel(final String boxLabel){
        if (boxLabel.equals(strBoxLabel)){
            if (isTone == 1){
                rightTone.start();
                isTone = 0;
            }
            isBoxScan = 1;
            successScanBoxText.setVisibility(View.VISIBLE);
            successScanBoxText.setText("Successfully Scanned Box Label");
            successScanBoxText.setTextColor(ColorStateList.valueOf(Color.parseColor("#008000")));
            if (isBoxScan == 1 && isProductScan == 1){
                collectProductFabBtn.setVisibility(View.VISIBLE);
            }else {
                collectProductFabBtn.setVisibility(View.GONE);
            }
        }else {
            if (isTone == 1){
                wrongTone.start();
                isTone = 0;
            }
            isBoxScan = 0;
            successScanBoxText.setVisibility(View.VISIBLE);
            successScanBoxText.setText("Doesn't Match With Box Label");
            successScanBoxText.setTextColor(ColorStateList.valueOf(Color.parseColor("#da0000")));
            if (isBoxScan == 1 && isProductScan == 1){
                collectProductFabBtn.setVisibility(View.VISIBLE);
            }else {
                collectProductFabBtn.setVisibility(View.GONE);
            }
        }
    }

    private void matchingProduct(final String productBarcode){
        if (productBarcode.equals(list.get(0).barcode)){
            if (isTone == 1){
                rightTone.start();
                isTone = 0;
            }
            //....................................................

            final Dialog qtyDialog = new Dialog(CodRtcBoxedItemCollect.this);
            qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            qtyDialog.getWindow().setLayout(width,height);
            qtyDialog.setCancelable(false);
            qtyDialog.show();

            final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
            Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
            Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
            TextView msg = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);

            ok.setText("Confirm");

            ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
            TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
            TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
            TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

            //String insPrimaryImage = Common.BASEURL_PICTURE + data.primary_image;

            if (data.variant_primary_image == null || data.variant_primary_image.equals("")) {
                Glide.with(CodRtcBoxedItemCollect.this)
                        .load(data.primary_image)
                        .placeholder(R.drawable.ic_default)
                        .into(cardImage);
            } else {
                //String insVariantImage = Common.BASEURL_PICTURE + data.variant_primary_image;


                Glide.with(CodRtcBoxedItemCollect.this)
                        .load(data.variant_primary_image)
                        .placeholder(R.drawable.ic_default)
                        .into(cardImage);
            }


            if (data.variant_name == null || data.variant_name.equals("")) {
                cardName.setText(data.product_name);
            } else {
                cardName.setText(data.variant_name);
            }

            cardColor.setText("Color : " + data.color);
            cardSize.setText("Size : " + data.size);


            msg.setText("Avl Qty : "+data.available_qty);
            qty.setText(""+data.available_qty);
            qty.setEnabled(false);

            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    qtyDialog.dismiss();
                }
            });

            ok.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    qtyDialog.dismiss();
                    isProductScan = 1;
                    successScanProductText.setVisibility(View.VISIBLE);
                    successScanProductText.setText("Successfully Scanned Product Barcode");
                    successScanProductText.setTextColor(ColorStateList.valueOf(Color.parseColor("#008000")));
                    if (isBoxScan == 1 && isProductScan == 1){
                        collectProductFabBtn.setVisibility(View.VISIBLE);
                    }else {
                        collectProductFabBtn.setVisibility(View.GONE);
                    }
                }
            });
        }else {
            if (isTone == 1){
                wrongTone.start();
                isTone = 0;
            }
            isProductScan = 0;
            successScanProductText.setVisibility(View.VISIBLE);
            successScanProductText.setText("Doesn't Match With The Product!");
            successScanProductText.setTextColor(ColorStateList.valueOf(Color.parseColor("#da0000")));
            if (isBoxScan == 1 && isProductScan == 1){
                collectProductFabBtn.setVisibility(View.VISIBLE);
            }else {
                collectProductFabBtn.setVisibility(View.GONE);
            }
        }
    }
}