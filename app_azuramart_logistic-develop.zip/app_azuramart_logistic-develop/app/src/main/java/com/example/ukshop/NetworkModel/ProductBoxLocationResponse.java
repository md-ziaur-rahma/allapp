package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ProductBoxLocationResponse extends ApiResponse{
    @SerializedName("data")
    public ArrayList<Data> data;

    public class Data{

        @SerializedName("PK_NO")
        public int PK_NO;

        @SerializedName("box_label")
        public String box_label;

        @SerializedName("product_count")
        public int product_count;

        @SerializedName("warehouse")
        public String warehouse;

        @SerializedName("status")
        public int status;
    }
}
