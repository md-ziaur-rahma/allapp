package com.example.ukshop.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.Activity.BoxDetailsItem;
import com.example.ukshop.NetworkModel.BoxListResponse;
import com.example.ukshop.R;

import static maes.tech.intentanim.CustomIntent.customType;

import java.util.List;

public class BoxListAdapter extends RecyclerView.Adapter<BoxListAdapter.ViewHolder> {

    private List<BoxListResponse.Data> mainList;
    private Activity context;
    private CoordinatorLayout rootLayout;

    public BoxListAdapter(List<BoxListResponse.Data> mainList, Activity context, CoordinatorLayout rootLayout) {
        this.mainList = mainList;
        this.context = context;
        this.rootLayout = rootLayout;
    }

    @NonNull
    @Override
    public BoxListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.box_list_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BoxListAdapter.ViewHolder holder, int position) {
        int pk_id = mainList.get(position).PK_NO;
        int boxNo = mainList.get(position).box_no;
        String boxLabel = mainList.get(position).box_label;
        int boxSerial = mainList.get(position).box_serial;
        String userName = mainList.get(position).user_name;
        String  warehouse = mainList.get(position).warehouse;
        int productCount = mainList.get(position).product_count;
        int unboxed_qty = mainList.get(position).unboxed_qty;
        int boxStatus = mainList.get(position).status;
        int shipmentNo = mainList.get(position).shipment_no;
        int shimentLabel = mainList.get(position).shipment_label;
        String merchantName = mainList.get(position).merchant_name;


        holder.setData(pk_id,boxNo,boxLabel,boxSerial,userName, boxStatus,warehouse,productCount,unboxed_qty,shipmentNo, shimentLabel,merchantName,position);
    }

    @Override
    public int getItemCount() {
        return mainList.size();
    }

    public void updateList(List<BoxListResponse.Data> newList){
        mainList = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView boxLabel, userName, boxStatus, warehouse, productCount
                , shipmentLabel;
        private ImageView greenCheck, smallIcon,bigImage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            smallIcon = itemView.findViewById(R.id.boxListSmallIconID);
            greenCheck = itemView.findViewById(R.id.boxListGreenCheckID);
            boxLabel = itemView.findViewById(R.id.boxListLabelID);
            userName = itemView.findViewById(R.id.boxListByNameID);
            warehouse = itemView.findViewById(R.id.boxListWarehouseID);
            productCount = itemView.findViewById(R.id.boxListProductCountID);
            boxStatus = itemView.findViewById(R.id.boxListBoxstatusID);
            shipmentLabel = itemView.findViewById(R.id.boxListShipmentLabelID);
            bigImage = itemView.findViewById(R.id.boxListBigImageID);
        }

        public void setData(final int pk_id, int boxNo, String boxLabel,final int boxSerial, String userName,final int boxStatus, String wareHouse,
                            int productcount,int unboxed_qty,int shipmentNo, int shipmentLabel,String merchantName,int position){

            this.boxLabel.setText("Box Label : "+boxLabel);
            if (merchantName != null){
                this.userName.setText("Boxed by : "+userName+"\nMerchant Name : "+merchantName);
            } else {
                this.userName.setText("Boxed by : "+userName);
            }
            this.productCount.setText("product Count : "+unboxed_qty+"/"+productcount);
            this.warehouse.setText(wareHouse);
            this.shipmentLabel.setText("Shipment Label : "+shipmentLabel+" - "+boxSerial);

            if (boxLabel.startsWith("1")){
                smallIcon.setImageResource(R.drawable.ic_plane);
                smallIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#4F1B35")));
            } else if (boxLabel.startsWith("2")){
                smallIcon.setImageResource(R.drawable.ic_ship_jahaj);
                smallIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#4F1B35")));
            } else if (boxLabel.startsWith("3")){
                smallIcon.setImageResource(R.drawable.ic_plane);
                smallIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#4F1B35")));
            } else if (boxLabel.startsWith("4")){
                smallIcon.setImageResource(R.drawable.ic_ship_jahaj);
                smallIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#4F1B35")));
            }

            if (boxStatus == 0) {
                greenCheck.setVisibility(View.GONE);
                this.bigImage.setImageResource(R.drawable.ic_box_list);
                this.boxStatus.setText("Not Boxed");
                this.shipmentLabel.setVisibility(View.GONE);
            }else if (boxStatus == 10){
                greenCheck.setVisibility(View.GONE);
                this.bigImage.setImageResource(R.drawable.ic_box_list);
                this.boxStatus.setText("In Progress at Source (UK)");
                this.shipmentLabel.setVisibility(View.GONE);
            }else if (boxStatus == 20) {
                greenCheck.setVisibility(View.VISIBLE);
                greenCheck.setImageResource(R.drawable.ic_green_check);
                this.bigImage.setImageResource(R.drawable.ic_box_list);
                this.boxStatus.setText("Packaging Complete (UK)");
                this.shipmentLabel.setVisibility(View.VISIBLE);
            }else if (boxStatus == 30) {
                greenCheck.setVisibility(View.VISIBLE);
                greenCheck.setImageResource(R.drawable.ic_green_check);
                this.bigImage.setImageResource(R.drawable.ic_box_list);
                this.boxStatus.setText("Assigned to Shipment (UK)");
                this.shipmentLabel.setVisibility(View.VISIBLE);
            }else if (boxStatus == 40) {
                greenCheck.setVisibility(View.VISIBLE);
                greenCheck.setImageResource(R.drawable.ic_green_check);
                this.bigImage.setImageResource(R.drawable.ic_box_list);
                this.boxStatus.setText("Arrived At Destination");
                this.shipmentLabel.setVisibility(View.VISIBLE);
            }else if (boxStatus == 50) {
                greenCheck.setVisibility(View.VISIBLE);
                greenCheck.setImageResource(R.drawable.ic_green_check);
                this.bigImage.setImageResource(R.drawable.ic_unboxed_new);
                this.boxStatus.setText("Received At Destination (MY)");
                this.shipmentLabel.setVisibility(View.VISIBLE);
            }else if (boxStatus == 60) {
                greenCheck.setVisibility(View.VISIBLE);
                greenCheck.setImageResource(R.drawable.ic_double_check);
                this.bigImage.setImageResource(R.drawable.ic_open_box);
                this.boxStatus.setText("Unboxed Completely (MY)");
                this.shipmentLabel.setVisibility(View.VISIBLE);
            }else if (boxStatus == 70) {
                greenCheck.setVisibility(View.VISIBLE);
                greenCheck.setImageResource(R.drawable.ic_double_check);
                this.bigImage.setImageResource(R.drawable.ic_open_box);
                this.boxStatus.setText("Unpacked (MY)");
                this.shipmentLabel.setVisibility(View.VISIBLE);
            }else if (boxStatus == 80) {
                greenCheck.setVisibility(View.VISIBLE);
                greenCheck.setImageResource(R.drawable.ic_double_check);
                this.bigImage.setImageResource(R.drawable.ic_open_box);
                this.boxStatus.setText("Box Empty");
                this.shipmentLabel.setVisibility(View.VISIBLE);
            }else if (boxStatus == 90) {
                greenCheck.setVisibility(View.VISIBLE);
                greenCheck.setImageResource(R.drawable.ic_double_check);
                this.bigImage.setImageResource(R.drawable.ic_open_box);
                this.boxStatus.setText("Disposed");
                this.shipmentLabel.setVisibility(View.VISIBLE);
            }else if (boxStatus == 100) {
                greenCheck.setVisibility(View.VISIBLE);
                greenCheck.setImageResource(R.drawable.ic_double_check);
                this.bigImage.setImageResource(R.drawable.ic_open_box);
                this.boxStatus.setText("Life Cycle Complete");
                this.shipmentLabel.setVisibility(View.VISIBLE);
            }

            itemView.setOnClickListener(v -> {
                Intent intent = new Intent(context, BoxDetailsItem.class);
                intent.putExtra("pk_id",pk_id);
                if (merchantName != null){
                    intent.putExtra("is_merchant",1);
                } else {
                    intent.putExtra("is_merchant",0);
                }
                itemView.getContext().startActivity(intent);
                customType(context,"left-to-right");
            });
        }
    }
}
