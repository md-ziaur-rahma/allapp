package com.example.ukshop.Models;

import android.graphics.Bitmap;

public class NewPurchaseItemModel {
    private Bitmap productImage;
    private String barcode;
    private String productPrice;
    private String productQnt;
    private String date;

    public NewPurchaseItemModel(Bitmap productImage, String barcode, String productPrice, String productQnt, String date) {
        this.productImage = productImage;
        this.barcode = barcode;
        this.productPrice = productPrice;
        this.productQnt = productQnt;
        this.date = date;
    }

    public NewPurchaseItemModel() {
    }

    public Bitmap getProductImage() {
        return productImage;
    }

    public void setProductImage(Bitmap productImage) {
        this.productImage = productImage;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductQnt() {
        return productQnt;
    }

    public void setProductQnt(String productQnt) {
        this.productQnt = productQnt;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
