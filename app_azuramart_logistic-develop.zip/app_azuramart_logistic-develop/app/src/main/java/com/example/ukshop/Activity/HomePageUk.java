package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ukshop.Activity.AboutUs;
import com.example.ukshop.MasterProductPage;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.snackbar.Snackbar;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static maes.tech.intentanim.CustomIntent.customType;

public class HomePageUk extends AppCompatActivity {

    private TextView userName, userLocation;
    private LinearLayout checkStock,productList,checkEntry,shipment, shipmentList,
            reBoxing,boxing,productSearchBtn,aboutUs, merchantBtn,yetToBoxAllBtn,
            logoutBtn,boxListBtn;

    final private CompositeDisposable compositeDisposable = new CompositeDisposable();
    IRetrofitApi mRetrofitApi;

    private CoordinatorLayout rootLayout;


    private boolean isInvalid = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page_uk);

        mRetrofitApi = Common.getApiArobil();
        initialFindByID();
        userName.setText(SharedPreperenceUtils.getUserName(this));
        userLocation.setText(SharedPreperenceUtils.getUserLocation(this));


        checkStock.setOnClickListener(v -> {
            Intent stockIntent = new Intent(HomePageUk.this,StockCheckPage.class);
            stockIntent.putExtra("isShow",false);
            //StockCheckPage.productList = productListData;
            startActivity(stockIntent);
            customType(HomePageUk.this,"left-to-right");
        });

        productList.setOnClickListener(v -> {

            Intent masterIntent = new Intent(HomePageUk.this, MasterProductPage.class);
            startActivity(masterIntent);
            customType(HomePageUk.this,"left-to-right");
        });

        checkEntry.setOnClickListener(v -> {
            Intent intent = new Intent(HomePageUk.this,CheckEntry.class);
            startActivity(intent);
            customType(HomePageUk.this,"left-to-right");
        });

        productSearchBtn.setOnClickListener(v -> {
            Intent dispatchIntent = new Intent(HomePageUk.this,ProductSearchPage.class);
            startActivity(dispatchIntent);
            customType(HomePageUk.this,"left-to-right");
        });

        boxing.setOnClickListener(v -> {

            Intent boxingIntent = new Intent(HomePageUk.this,BoxingPage.class);
            startActivity(boxingIntent);
            customType(HomePageUk.this,"left-to-right");
        });

        reBoxing.setOnClickListener(v -> {

            final Dialog dialog = new Dialog(HomePageUk.this,R.style.slideUpDownDialog);
            dialog.setContentView(R.layout.riboxing_add_remove_dialoge);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(true);
            dialog.show();

            Button add = dialog.findViewById(R.id.dialogeReboxingAddID);
            Button remove = dialog.findViewById(R.id.dialogeReboxingRemoveID);

            add.setOnClickListener(v14 -> {
                Intent intent = new Intent(HomePageUk.this, ReboxingAdd.class);
                intent.putExtra("merchant_id",0);
                startActivity(intent);
                customType(HomePageUk.this,"left-to-right");
                dialog.dismiss();
            });

            remove.setOnClickListener(v13 -> {
                Intent intent = new Intent(HomePageUk.this, ReboxingPage.class);
                intent.putExtra("merchant_id",0);
                startActivity(intent);
                customType(HomePageUk.this,"left-to-right");
                dialog.dismiss();
            });

        });

        boxListBtn.setOnClickListener(v -> {
            Intent returnIntent = new Intent(HomePageUk.this, BoxlistPage.class);
            BoxlistPage.shipment_no = 0;
            startActivity(returnIntent);
            customType(HomePageUk.this,"left-to-right");
        });

        shipment.setOnClickListener(v -> {
            Intent intent = new Intent(HomePageUk.this,ShipmentPage.class);
            startActivity(intent);
            customType(HomePageUk.this,"left-to-right");
        });

        shipmentList.setOnClickListener(v -> {
            Intent dispatchIntent = new Intent(HomePageUk.this,ShipmentInprogress.class);
            startActivity(dispatchIntent);
            customType(HomePageUk.this,"left-to-right");
        });

        aboutUs.setOnClickListener(v -> {
            Intent aboutIntent = new Intent(HomePageUk.this, AboutUs.class);
            startActivity(aboutIntent);
        });

        yetToBoxAllBtn.setOnClickListener(v -> {
            Intent dispatchIntent = new Intent(HomePageUk.this,IndividualStockSearch.class);
            startActivity(dispatchIntent);
            customType(HomePageUk.this,"left-to-right");
        });

        merchantBtn.setOnClickListener(v -> {
            Intent dispatchIntent = new Intent(HomePageUk.this,HomeMerchant.class);
            startActivity(dispatchIntent);
            customType(HomePageUk.this,"left-to-right");
        });

        logoutBtn.setOnClickListener(v -> {

            final Dialog dialog = new Dialog(HomePageUk.this,R.style.fadeDialog);
            dialog.setContentView(R.layout.dialog_logout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(true);
            dialog.show();

            Button OkBtn = dialog.findViewById(R.id.dialogeLogoutOkID);
            Button cancelBtn = dialog.findViewById(R.id.dialogeLogoutCancelID);

            cancelBtn.setOnClickListener(v12 -> dialog.dismiss());

            OkBtn.setOnClickListener(v1 -> {
                SharedPreperenceUtils.removeShared(HomePageUk.this,SharedPreperenceUtils.USER_ID);
                SharedPreperenceUtils.clearUserData(HomePageUk.this);

                Intent intent = new Intent(HomePageUk.this,LoginPage.class);
                startActivity(intent);
                //customType(HomePageUk.this,"right-to-left");
                dialog.dismiss();
                finish();
            });

        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootLayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootLayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
            snackbar.show();
        }
    }

    @Override
    public void onBackPressed() {

        final Dialog dialog = new Dialog(HomePageUk.this,R.style.fadeDialog);
        dialog.setContentView(R.layout.dialog_logout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(true);
        dialog.show();

        final Button okBtn = dialog.findViewById(R.id.dialogeLogoutOkID);
        final Button cancelBtn = dialog.findViewById(R.id.dialogeLogoutCancelID);
        final TextView topMsg = dialog.findViewById(R.id.dialogLogoutTopTextID);
        final TextView msg = dialog.findViewById(R.id.dialogeLogoutTextMsgID);

        okBtn.setText("Exit");
        topMsg.setText("Warning!");
        msg.setText("Are you want to close app.. ?");

        cancelBtn.setOnClickListener(v -> dialog.dismiss());

        okBtn.setOnClickListener(v -> {
            dialog.dismiss();
            finish();
        });
    }

    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
            if (response.status == 0) {
                isInvalid = true;
            }
        }, throwable -> {

        }));

        return isInvalid;
    }

    private void initialFindByID(){
        rootLayout = (CoordinatorLayout)findViewById(R.id.homePageUKRootLayoutID);

        userName = (TextView)findViewById(R.id.homeUserNameID);
        aboutUs = (LinearLayout)findViewById(R.id.homeAboutBtnID);
        userLocation = (TextView)findViewById(R.id.homeUserLocationID);
        checkStock = (LinearLayout)findViewById(R.id.homeCheckStockUKBtnID);
        productList = (LinearLayout)findViewById(R.id.homeProductListUKId);
        checkEntry = (LinearLayout)findViewById(R.id.homeCheckEntryUKBtnID);
        productSearchBtn = (LinearLayout)findViewById(R.id.homeProductSearchUKBtnID);
        shipment = (LinearLayout)findViewById(R.id.homeShipmentUKBtnID);
        shipmentList = (LinearLayout)findViewById(R.id.homeShipmentListUKBtnID);
        boxing = (LinearLayout)findViewById(R.id.homeBoxingUKBtnID);
        boxListBtn = (LinearLayout)findViewById(R.id.homeBoxListUKBtnID);
        reBoxing = (LinearLayout)findViewById(R.id.homeReboxingUKBtnID);
        merchantBtn = (LinearLayout)findViewById(R.id.homeMerchantBtnID);
        yetToBoxAllBtn = (LinearLayout)findViewById(R.id.homeYetToBoxAllUKBtnID);
        logoutBtn = (LinearLayout)findViewById(R.id.homeLogoutUKBtnID);
    }
}