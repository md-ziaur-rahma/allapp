package com.example.ukshop.NetworkModel;

import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;

public class ProductSearchPost {
    @SerializedName("user_id")
    public int user_id;

    @Nullable
    @SerializedName("barcode")
    public String barcode;

    @Nullable
    @SerializedName("sku_id")
    public String sku_id;

    @Nullable
    @SerializedName("mkt_id")
    public String mkt_id;

    @Nullable
    @SerializedName("product_name")
    public String product_name;

    @SerializedName("merchant_id")
    public int merchant_id;
}
