package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CodRtcBoxedItemCollectPost {
    @SerializedName("box_label")
    public String box_label;
    @SerializedName("user_id")
    public int user_id;
    @SerializedName("data")
    public List<CodRtcSubModel> data;
}
