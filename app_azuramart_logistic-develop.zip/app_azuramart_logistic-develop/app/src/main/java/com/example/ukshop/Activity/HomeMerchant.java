package com.example.ukshop.Activity;

import static maes.tech.intentanim.CustomIntent.customType;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ukshop.Activity.Merchant.MerchantBoxList;
import com.example.ukshop.Activity.Merchant.MerchantBoxing;
import com.example.ukshop.Activity.Merchant.MerchantShipmentLabeling;
import com.example.ukshop.Activity.Merchant.MerchantShipmentList;
import com.example.ukshop.Activity.Merchant.MerchantStockSearch;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.merchantNetworkModels.MerchantListModel;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

public class HomeMerchant extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private LinearLayout checkStock,shipmentLabeling, shipmentList, advanceSearchBtn,
            reBoxing,boxing,boxListBtn;
    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;

    private List<String> dropDownList = new ArrayList<>();
    private List<String> allDropDownList = new ArrayList<>();
    private int merchantPk = 0;
    private String merchantName = "";
    private List<MerchantListModel.Data> merchantListModelList = new ArrayList<>();

    private final CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_merchant);
        initialFindByID();
        mIRetrofitApi = Common.getApiArobil();
        loadMerchant();

        checkStock.setOnClickListener(v -> {
            final Dialog dialog = new Dialog(HomeMerchant.this,R.style.slideUpDownDialog);
            dialog.setContentView(R.layout.merchant_selection_layout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(true);
            dialog.show();

            Button next = dialog.findViewById(R.id.merchantListDialogNextBtnID);
            Button cancel = dialog.findViewById(R.id.merchantListDialogCancelBtnID);
            Spinner spinner = dialog.findViewById(R.id.merchantListDialogSpinnerID);
            ArrayAdapter<String> adapter_state = new ArrayAdapter<>(HomeMerchant.this,  android.R.layout.simple_spinner_item, dropDownList);
            adapter_state.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter_state);
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position == 0){
                        merchantPk = 0;
                        merchantName = "";
                    } else {
                        merchantPk = merchantListModelList.get(position-1).merchant_pk;
                        merchantName = merchantListModelList.get(position-1).merchant_name;
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            next.setOnClickListener(v14 -> {
                if (spinner.getSelectedItemPosition() == 0){
                    Toast.makeText(HomeMerchant.this, "Select a merchant", Toast.LENGTH_LONG).show();
                }else {
                    Intent intent = new Intent(HomeMerchant.this, MerchantStockSearch.class);
                    intent.putExtra("merchant_pk",merchantPk);
                    intent.putExtra("merchant_name",merchantName);
                    intent.putExtra("isShow",false);
                    startActivity(intent);
                    customType(HomeMerchant.this,"left-to-right");
                    dialog.dismiss();
                }

            });

            cancel.setOnClickListener(v13 -> {
                dialog.dismiss();
            });
        });

        advanceSearchBtn.setOnClickListener(v -> {
            final Dialog dialog = new Dialog(HomeMerchant.this,R.style.slideUpDownDialog);
            dialog.setContentView(R.layout.merchant_selection_layout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(true);
            dialog.show();

            Button next = dialog.findViewById(R.id.merchantListDialogNextBtnID);
            Button cancel = dialog.findViewById(R.id.merchantListDialogCancelBtnID);
            Spinner spinner = dialog.findViewById(R.id.merchantListDialogSpinnerID);
            ArrayAdapter<String> adapter_state = new ArrayAdapter<>(HomeMerchant.this,  android.R.layout.simple_spinner_item, dropDownList);
            adapter_state.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter_state);
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position == 0){
                        merchantPk = 0;
                        merchantName = "";
                    } else {
                        merchantPk = merchantListModelList.get(position-1).merchant_pk;
                        merchantName = merchantListModelList.get(position-1).merchant_name;
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            next.setOnClickListener(v14 -> {
                if (spinner.getSelectedItemPosition() == 0){
                    Toast.makeText(HomeMerchant.this, "Select a merchant", Toast.LENGTH_LONG).show();
                } else {
                    Intent intent = new Intent(HomeMerchant.this, CustomerProductSearch.class);
                    intent.putExtra("merchant_id",merchantPk);
                    intent.putExtra("merchant_name",merchantName);
                    startActivity(intent);
                    customType(HomeMerchant.this,"left-to-right");
                    dialog.dismiss();
                }

            });

            cancel.setOnClickListener(v13 -> {
                dialog.dismiss();
            });
        });

        boxing.setOnClickListener(v -> {
            final Dialog dialog = new Dialog(HomeMerchant.this,R.style.slideUpDownDialog);
            dialog.setContentView(R.layout.merchant_selection_layout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(true);
            dialog.show();

            Button next = dialog.findViewById(R.id.merchantListDialogNextBtnID);
            Button cancel = dialog.findViewById(R.id.merchantListDialogCancelBtnID);
            Spinner spinner = dialog.findViewById(R.id.merchantListDialogSpinnerID);
            ArrayAdapter<String> adapter_state = new ArrayAdapter<>(HomeMerchant.this,  android.R.layout.simple_spinner_item, dropDownList);
            adapter_state.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter_state);
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position == 0){
                        merchantPk = 0;
                        merchantName = "";
                    } else {
                        merchantPk = merchantListModelList.get(position-1).merchant_pk;
                        merchantName = merchantListModelList.get(position-1).merchant_name;
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            next.setOnClickListener(v14 -> {
                if (spinner.getSelectedItemPosition() == 0){
                    Toast.makeText(HomeMerchant.this, "Select a merchant", Toast.LENGTH_LONG).show();
                } else {
                    Intent intent = new Intent(HomeMerchant.this, MerchantBoxing.class);
                    intent.putExtra("merchant_pk",merchantPk);
                    intent.putExtra("merchant_name",merchantName);
                    startActivity(intent);
                    customType(HomeMerchant.this,"left-to-right");
                    dialog.dismiss();
                }

            });

            cancel.setOnClickListener(v13 -> {
                dialog.dismiss();
            });
        });

        reBoxing.setOnClickListener(v -> {
            final Dialog dialog = new Dialog(HomeMerchant.this,R.style.slideUpDownDialog);
            dialog.setContentView(R.layout.merchant_selection_layout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(true);
            dialog.show();

            Button next = dialog.findViewById(R.id.merchantListDialogNextBtnID);
            Button cancel = dialog.findViewById(R.id.merchantListDialogCancelBtnID);
            Spinner spinner = dialog.findViewById(R.id.merchantListDialogSpinnerID);
            ArrayAdapter<String> adapter_state = new ArrayAdapter<>(HomeMerchant.this,  android.R.layout.simple_spinner_item, dropDownList);
            adapter_state.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter_state);
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position == 0){
                        merchantPk = 0;
                        merchantName = "";
                    } else {
                        merchantPk = merchantListModelList.get(position-1).merchant_pk;
                        merchantName = merchantListModelList.get(position-1).merchant_name;
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            next.setOnClickListener(v14 -> {
                if (spinner.getSelectedItemPosition() == 0){
                    Toast.makeText(HomeMerchant.this, "Select a merchant", Toast.LENGTH_LONG).show();
                } else {

                    final Dialog dialogG = new Dialog(HomeMerchant.this,R.style.slideUpDownDialog);
                    dialogG.setContentView(R.layout.riboxing_add_remove_dialoge);

                    int widthH = WindowManager.LayoutParams.MATCH_PARENT;
                    int heightT = WindowManager.LayoutParams.WRAP_CONTENT;

                    dialogG.getWindow().setLayout(widthH,heightT);
                    dialogG.setCancelable(true);
                    dialogG.show();

                    Button add = dialogG.findViewById(R.id.dialogeReboxingAddID);
                    Button remove = dialogG.findViewById(R.id.dialogeReboxingRemoveID);

                    add.setOnClickListener(v1 -> {
                        Intent intent = new Intent(HomeMerchant.this, ReboxingAdd.class);
                        intent.putExtra("merchant_id",merchantPk);
                        startActivity(intent);
                        customType(HomeMerchant.this,"left-to-right");
                        dialogG.dismiss();
                    });

                    remove.setOnClickListener(v13 -> {
                        Intent intent = new Intent(HomeMerchant.this, ReboxingPage.class);
                        intent.putExtra("merchant_id",merchantPk);
                        startActivity(intent);
                        customType(HomeMerchant.this,"left-to-right");
                        dialogG.dismiss();
                    });
                    dialog.dismiss();
                }
            });

            cancel.setOnClickListener(v13 -> {
                dialog.dismiss();
            });
        });

        boxListBtn.setOnClickListener(v -> {
            final Dialog dialog = new Dialog(HomeMerchant.this,R.style.slideUpDownDialog);
            dialog.setContentView(R.layout.merchant_selection_layout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(true);
            dialog.show();

            Button next = dialog.findViewById(R.id.merchantListDialogNextBtnID);
            Button cancel = dialog.findViewById(R.id.merchantListDialogCancelBtnID);
            Spinner spinner = dialog.findViewById(R.id.merchantListDialogSpinnerID);
//            List<String> insDropDownList;
//            Log.e("dropdown list", String.valueOf(dropDownList));
//            insDropDownList = dropDownList;
//            insDropDownList.add(1,"All Merchant");
            ArrayAdapter<String> adapter_state = new ArrayAdapter<>(HomeMerchant.this,  android.R.layout.simple_spinner_item, allDropDownList);
            adapter_state.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter_state);
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position == 0){
                        merchantPk = 0;
                        merchantName = "";
                    } else  if (position == 1){
                        merchantPk = -1;
                        merchantName = "All Merchant";
                    } else {
                        merchantPk = merchantListModelList.get(position-2).merchant_pk;
                        merchantName = merchantListModelList.get(position-2).merchant_name;
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            next.setOnClickListener(v14 -> {
                if (spinner.getSelectedItemPosition() == 0){
                    Toast.makeText(HomeMerchant.this, "Select a merchant", Toast.LENGTH_LONG).show();
                } else {
                    Intent intent = new Intent(HomeMerchant.this, MerchantBoxList.class);
                    intent.putExtra("merchant_pk",merchantPk);
                    intent.putExtra("merchant_name",merchantName);
                    BoxlistPage.shipment_no = 0;
                    startActivity(intent);
                    customType(HomeMerchant.this,"left-to-right");
                    dialog.dismiss();
                }

            });
            cancel.setOnClickListener(v13 -> dialog.dismiss());
        });

        shipmentLabeling.setOnClickListener(v -> {
            Intent intent = new Intent(HomeMerchant.this, ShipmentPage.class);
            startActivity(intent);
            customType(HomeMerchant.this,"left-to-right");
        });

        shipmentList.setOnClickListener(v -> {
            Intent dispatchIntent = new Intent(HomeMerchant.this, MerchantShipmentList.class);
            startActivity(dispatchIntent);
            customType(HomeMerchant.this,"left-to-right");
        });
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void initialFindByID(){
        rootLayout = findViewById(R.id.homePageMerchantRootLayoutID);
        toolbar = findViewById(R.id.merchantHomeToolbarID);
        checkStock = findViewById(R.id.merchantHomeCheckStockUKBtnID);
        shipmentLabeling = findViewById(R.id.merchantHomeShipmentLabelingUKBtnID);
        shipmentList = findViewById(R.id.merchantHomeShipmentListUKBtnID);
        boxing = findViewById(R.id.merchantHomeBoxingUKBtnID);
        boxListBtn = findViewById(R.id.merchantHomeBoxListUKBtnID);
        reBoxing = findViewById(R.id.merchantHomeReBoxingUKBtnID);
        advanceSearchBtn = findViewById(R.id.merchantHomeAdvanceSearchUKBtnID);
    }

    private void loadMerchant() {
        merchantListModelList = new ArrayList<>();
        dropDownList = new ArrayList<>();
        allDropDownList = new ArrayList<>();
        String token = SharedPreperenceUtils.getToken(HomeMerchant.this);
        compositeDisposable.add(mIRetrofitApi.getMerchantList(token).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
            if (response.status == 1){
                merchantListModelList = response.data;
                dropDownList.add("Select a merchant");
                allDropDownList.add("Select a merchant");
                allDropDownList.add("All Merchant");
                for (MerchantListModel.Data model : merchantListModelList) {
                    dropDownList.add(model.merchant_name);
                    allDropDownList.add(model.merchant_name);
                }
            } else if (response.status == 0){
                dropDownList.add("Select a merchant");
                allDropDownList.add("Select a merchant");
            }
        }, throwable -> {
            dropDownList.add("Select a merchant");
            allDropDownList.add("Select a merchant");
        }));
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}