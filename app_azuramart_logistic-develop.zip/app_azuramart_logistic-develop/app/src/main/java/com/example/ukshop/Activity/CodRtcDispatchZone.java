package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.ukshop.Adapters.CodRtcDispatchZoneAdapter;
import com.example.ukshop.Adapters.RtsDispatchAreaItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.CodRtcDispatchZonePost;
import com.example.ukshop.NetworkModel.CodRtcDispatchZoneResponse;
import com.example.ukshop.NetworkModel.CodRtcZoneItemAcknowledgePost;
import com.example.ukshop.NetworkModel.RTSPost;
import com.example.ukshop.NetworkModel.ReboxingResponse;
import com.example.ukshop.NetworkModel.RtsDispatchConsignmentItemResponse;
import com.example.ukshop.NetworkModel.ShelvingResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class CodRtcDispatchZone extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private RecyclerView recyclerView;
    private List<CodRtcDispatchZoneResponse.Data> mainList = new ArrayList<>();
    private CodRtcDispatchZoneAdapter adapter;

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private ExtendedFloatingActionButton productScanFavBtn;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private static final int CAMERA_REQUEST_CODE = 501;
    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static boolean isFlash = false;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();
    private int isTone = 0;

    //todo use for direct Acknowledge...........
    public static String directAckBarcode = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cod_rtc_dispatch_zone);

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new CodRtcDispatchZoneAdapter(mainList, this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        if (Utils.broadcastIntent(this,rootLayout)){
            loadData();
        }else {
            NoInternetSnackBar();
        }


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.menuShipment_refreshId){
                    if (Utils.isCameraPermission(CodRtcDispatchZone.this)){
                        loadData();
                    }
                }
                return false;
            }
        });

        productScanFavBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(CodRtcDispatchZone.this)){
                    isTone = 1;
                    openScanner();
                }else {
                    ActivityCompat.requestPermissions(CodRtcDispatchZone.this,new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST_CODE);
                }
            }
        });

        productScanFavBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                isTone = 0;
                final Dialog dialog = new Dialog(CodRtcDispatchZone.this,R.style.fadeDialog);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);

                barcodeText.setInputType(InputType.TYPE_CLASS_TEXT);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){
                            if (Utils.broadcastIntent(CodRtcDispatchZone.this,rootLayout)){
                                checkProduct(barcode);
                                dialog.dismiss();
                            }else {
                                dialog.dismiss();
                                Utils.snackbarToast(rootLayout,"No internet connection!");
                            }
                        }else {
                            Toast.makeText(CodRtcDispatchZone.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });
                return false;
            }
        });

    }

    private void initialFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.codRtcDispatchZoneRootLayoutID);
        toolbar = (MaterialToolbar) findViewById(R.id.codRtcDispatchZoneToolbarID);
        productScanFavBtn = (ExtendedFloatingActionButton)findViewById(R.id.codRtcDispatchZoneFabBtnID);
        recyclerView = (RecyclerView)findViewById(R.id.codRtcDispatchZoneRecyclerID);
    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",10000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(CodRtcDispatchZone.this,rootLayout)){
                    loadData();
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    private void openScanner(){
        scannerDialog = new Dialog(CodRtcDispatchZone.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);

        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(CodRtcDispatchZone.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }

    @Override
    public void handleResult(final Result rawResult) {

        if (!TextUtils.isEmpty(rawResult.getText())){

            isTone = 1;
            checkProduct(rawResult.getText());
            scannerDialog.dismiss();
            scannerView.stopCamera();
        }else {

            wrongTone.start();

            scannerDialog.dismiss();
            scannerView.stopCamera();
        }
    }

    private void loadData() {

        mainList = new ArrayList<>();
        adapter.updateData(mainList);
        productScanFavBtn.hide();

        final Dialog dialog = new Dialog(CodRtcDispatchZone.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        String token = SharedPreperenceUtils.getToken(CodRtcDispatchZone.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(CodRtcDispatchZone.this));

        final CodRtcDispatchZonePost post = new CodRtcDispatchZonePost();
        post.user_id = user_id;

        Log.e("cod dispatch zone post", "msg"+new Gson().toJson(post));

        compositeDisposable.add(mIRetrofitApi.getCodRtcDispatchZoneItem(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<CodRtcDispatchZoneResponse>() {
            @Override
            public void accept(CodRtcDispatchZoneResponse response) throws Exception {
                if (response.status == 1){
                    for (CodRtcDispatchZoneResponse.Data item : response.data){
                        if (item.is_acknowledge == 0){
                            mainList.add(item);
                        }
                    }
                    //Toast.makeText(CodRtcDispatchZone.this, ""+mainList.size(), Toast.LENGTH_SHORT).show();
                    if (mainList.size() > 0 ){
                        adapter.updateData(mainList);
                        productScanFavBtn.show();
                    }else {
                        Utils.snackbarToast(rootLayout,"Data not found!");
                    }


                    //todo use for direct Acknowledge...........
//                    if (!directAckBarcode.equals("")){
//                        checkProduct(directAckBarcode);
//                    }

                    dialog.dismiss();

                }else {
                    dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout, CodRtcDispatchZone.this);
                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,response.message,10000);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (Utils.broadcastIntent(CodRtcDispatchZone.this,rootLayout)){
                                    loadData();
                                }else {
                                    NoInternetSnackBar();
                                }
                            }
                        });

                        snackbar.show();
                    }
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        }));


    }

    private void checkProduct(String barcode){
        int m = 0;
        for (int i = 0; i < mainList.size(); i++){
            if (mainList.get(i).barcode.equals(barcode)){
                m = 1;
                if (isTone == 1){
                    rightTone.start();
                    isTone = 0;
                }
                final Dialog qtyDialog = new Dialog(CodRtcDispatchZone.this,R.style.fadeDialog);
                qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                qtyDialog.getWindow().setLayout(width,height);
                qtyDialog.setCancelable(false);
                qtyDialog.show();

                final EditText qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                TextView msg = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);

                ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                String insPrimaryImage = Common.BASEURL_PICTURE + mainList.get(i).primary_image;

                if (mainList.get(i).variant_primary_image == null || mainList.get(i).variant_primary_image.equals("")) {
                    Glide.with(CodRtcDispatchZone.this)
                            .load(insPrimaryImage)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                } else {
                    String insVariantImage = Common.BASEURL_PICTURE + mainList.get(i).variant_primary_image;


                    Glide.with(CodRtcDispatchZone.this)
                            .load(insVariantImage)
                            .placeholder(R.drawable.ic_default)
                            .into(cardImage);
                }


                if (mainList.get(i).variant_name == null || mainList.get(i).variant_name.equals("")) {
                    cardName.setText(mainList.get(i).product_name);
                } else {
                    cardName.setText(mainList.get(i).variant_name);
                }

                cardColor.setText("Color : " + mainList.get(i).color);
                cardSize.setText("Size : " + mainList.get(i).size);


                msg.setText("Avl Qty : "+mainList.get(i).qty);
                if (mainList.get(i).is_acknowledge == 1){
                    msg.setText("Already Found Acknowledge");
                    ok.setText("Cancel Ack");
                }else {
                    msg.setText("Confirm Acknowledge");
                    ok.setText("Confirm");
                }
                qty.setText(""+mainList.get(i).qty);
                qty.setEnabled(false);

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        qtyDialog.dismiss();
                    }
                });

                final int finalI = i;
                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                    acknowledge(finalI);
                    qtyDialog.dismiss();
                    return;
                    }
                });
            }
        }

        if(m == 0){
            if (isTone == 1){
                wrongTone.start();
                isTone = 0;
            }
            Utils.snackbarToast(rootLayout,"Doesn't match the product or not picked!");
        }

    }


    public void acknowledge(final int position){
//        final Dialog dialog = new Dialog(CodRtcDispatchZone.this);
//        dialog.setContentView(R.layout.transparent_progress_dialoge);
//
//        int width = WindowManager.LayoutParams.WRAP_CONTENT;
//        int height = WindowManager.LayoutParams.WRAP_CONTENT;
//
//        dialog.getWindow().setLayout(width,height);
//        dialog.setCancelable(false);
//        dialog.show();

        String token = SharedPreperenceUtils.getToken(CodRtcDispatchZone.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(CodRtcDispatchZone.this));

        final CodRtcZoneItemAcknowledgePost post = new CodRtcZoneItemAcknowledgePost();
        post.sku_id = mainList.get(position).sku_id;
        post.order_id = mainList.get(position).order_id;
        post.qty = mainList.get(position).qty;
        post.user_id = user_id;
        if(mainList.get(position).is_acknowledge == 0){
            post.is_acknowledge = 1;
        }else {
            post.is_acknowledge = 0;
        }
        //Toast.makeText(this, ""+mainList.get(position).sku_id+"\n"+mainList.get(position).order_id+"\n"+mainList.get(position).qty+"\n"+mainList.get(position).is_acknowledge+"\n"+mainList.get(position).sku_id+"\n", Toast.LENGTH_SHORT).show();

        compositeDisposable.add(mIRetrofitApi.getCodRtcAcknowledge(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ShelvingResponse>() {
            @Override
            public void accept(ShelvingResponse response) throws Exception {
                if (response.status == 1){
                    final CodRtcDispatchZoneResponse.Data item = new CodRtcDispatchZoneResponse.Data();
                    item.PK_NO = mainList.get(position).PK_NO;
                    item.sku_id = mainList.get(position).sku_id;
                    item.mkt_id = mainList.get(position).mkt_id;
                    item.barcode = mainList.get(position).barcode;
                    item.product_name = mainList.get(position).product_name;
                    item.variant_name = mainList.get(position).variant_name;
                    item.primary_image = mainList.get(position).primary_image;
                    item.variant_primary_image = mainList.get(position).variant_primary_image;
                    item.color = mainList.get(position).color;
                    item.size = mainList.get(position).size;
                    item.is_acknowledge = mainList.get(position).is_acknowledge == 0?1:0;
                    item.order_id = mainList.get(position).order_id;
                    item.qty = mainList.get(position).qty;

                    mainList.remove(position);
                    adapter.notifyItemRangeChanged(position,mainList.size());
                    adapter.notifyDataSetChanged();

                    Toast.makeText(CodRtcDispatchZone.this, ""+response.message, Toast.LENGTH_SHORT).show();
                    //Utils.snackbarToast(rootLayout,response.message);
                    //dialog.dismiss();
                }else {
                    //dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootLayout, CodRtcDispatchZone.this);
                    }else {
                        Utils.snackbarToast(rootLayout,response.message);
                    }
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                //dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        }));


    }
}