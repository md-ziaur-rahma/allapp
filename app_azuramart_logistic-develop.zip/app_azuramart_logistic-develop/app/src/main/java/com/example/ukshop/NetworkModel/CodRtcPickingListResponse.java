package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class CodRtcPickingListResponse extends ApiResponse{

    @SerializedName("data")
    public ArrayList<Data> data;

    public static class Data{
        @SerializedName("sku_id")
        public String sku_id;

        @SerializedName("PK_NO")
        public int PK_NO;

        @SerializedName("product_name")
        public String product_name;

        @SerializedName("product_variant_name")
        public String variant_name;

        @SerializedName("size")
        public String size;

        @SerializedName("color")
        public String color;

        @SerializedName("barcode")
        public String barcode;

        @SerializedName("variant_primary_image")
        public String variant_primary_image;

        @SerializedName("primary_image")
        public String primary_image;

        @SerializedName("qty")
        public int qty;

        @SerializedName("label")
        public String label;

        @SerializedName("person")
        public String person;

        @SerializedName("person_id")
        public int person_id;

        @SerializedName("order_id")
        public int order_id;

        @SerializedName("location")
        public String location;
    }
}
