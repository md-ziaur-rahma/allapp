package com.example.ukshop.Adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.Models.BookingItemModel;
import com.example.ukshop.R;

import java.util.List;

public class BookingItemAdapter extends RecyclerView.Adapter<BookingItemAdapter.ViewHolder> {

    private Activity context;
    private List<BookingItemModel> list;

    public BookingItemAdapter(List<BookingItemModel> list, Activity context ) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public BookingItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.booking_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookingItemAdapter.ViewHolder holder, int position) {

        int image = list.get(position).getProductImage();
        String code = list.get(position).getProductCode();
        String name = list.get(position).getProductName();
        String brand = list.get(position).getProductBrand();
        String size = list.get(position).getProductSize();
        String price = list.get(position).getProductPrice();
        String qnt = list.get(position).getProductQnt();
        String date = list.get(position).getDate();

        holder.setData(image,code,name,brand,size,price,qnt,date,position);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void newList(List<BookingItemModel> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private ImageView image;
        private TextView code, name,brand,size,price,qnt, date;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.bookingItemImageID);
            code = itemView.findViewById(R.id.bookingItemCodeID);
            name = itemView.findViewById(R.id.bookingItemNameID);
            brand = itemView.findViewById(R.id.bookingItemBrandId);
            size = itemView.findViewById(R.id.bookingItemSizeID);
            price = itemView.findViewById(R.id.bookingItemPriceID);
            qnt = itemView.findViewById(R.id.bookingItemQuantityID);
            date = itemView.findViewById(R.id.bookingItemDateID);

        }

        public void setData(int img, String cd, String nme,String brnd,String sze,String pric,String qnty,String date, int position){
            image.setImageResource(img);
            code.setText("Code : "+cd);
            name.setText(nme);
            brand.setText("Brand : "+brnd);
            size.setText("Size : "+sze);
            price.setText("$"+pric);
            qnt.setText("Qnt : "+qnty);
            this.date.setText(date);
        }
    }
}
