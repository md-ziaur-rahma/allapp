package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class PriorityBoxResponse extends ApiResponse {

    @SerializedName("data")
    public ArrayList<Data> data;

    public static class Data{

        @SerializedName("box_label")
        public String box_label;

        @SerializedName("total_item_count")
        public int total_item_count;

        @SerializedName("unboxed_qty")
        public int unboxed_qty;

        @SerializedName("priority_item_count")
        public int priority_item_count;
    }
}
