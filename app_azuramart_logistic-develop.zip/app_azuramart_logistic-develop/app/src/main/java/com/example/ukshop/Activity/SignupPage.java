package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.ukshop.R;

import static maes.tech.intentanim.CustomIntent.customType;

public class SignupPage extends AppCompatActivity {

    private Button goLoginBtn, signupBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_page);

        //getSupportActionBar().hide();

        signupBtn = (Button)findViewById(R.id.signupButtonID);
        goLoginBtn = (Button)findViewById(R.id.signupGoLoginButtonID);


        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignupPage.this,LoginPage.class);
                startActivity(intent);
                customType(SignupPage.this,"left-to-right");
                finish();
            }
        });

        goLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignupPage.this,LoginPage.class);
                startActivity(intent);
                customType(SignupPage.this,"right-to-left");
                finish();
            }
        });

    }
}