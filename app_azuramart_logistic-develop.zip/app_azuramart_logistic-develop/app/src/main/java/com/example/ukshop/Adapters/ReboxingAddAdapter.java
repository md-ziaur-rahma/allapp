package com.example.ukshop.Adapters;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ukshop.Activity.BoxingPage;
import com.example.ukshop.Activity.ImageShowPage;
import com.example.ukshop.Activity.ReboxingAdd;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.BoxingItemResponse;
import com.example.ukshop.NetworkModel.BoxingItemSubModel;
import com.example.ukshop.NetworkModel.VariantImageResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class ReboxingAddAdapter extends RecyclerView.Adapter<ReboxingAddAdapter.ViewHolder> {

    private List<BoxingItemResponse.Data> mainList;
    private List<BoxingItemSubModel> list;
    private Activity context;
    private CoordinatorLayout rootlayout;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;
    List<VariantImageResponse.Data> variantImageList = new ArrayList<>();

    public ReboxingAddAdapter(List<BoxingItemResponse.Data> mainList, List<BoxingItemSubModel> list, Activity context, CoordinatorLayout rootlayout) {
        this.mainList = mainList;
        this.list = list;
        this.context = context;
        this.rootlayout = rootlayout;
    }

    @NonNull
    @Override
    public ReboxingAddAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.boxing_item_full_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReboxingAddAdapter.ViewHolder holder, int position) {
        int pk_id = mainList.get(position).PK_NO;
        String imageUrl = mainList.get(position).variant_primary_image;
        String primaryImage = mainList.get(position).primary_image;
        String skuId = mainList.get(position).sku_id;
        String mktId = mainList.get(position).mkt_id;
        String name = mainList.get(position).product_name;
        String vaiantName = mainList.get(position).variant_name;
        String color = mainList.get(position).color;
        int isAir = mainList.get(position).is_air;
        String size = mainList.get(position).size;
        int qty = mainList.get(position).available_qty;

        holder.setData(pk_id,qty,position,primaryImage,imageUrl,skuId,
                mktId,name,vaiantName,color,isAir,size);
    }

    @Override
    public int getItemCount() {
        return mainList.size();
    }
    public void addItem(List<BoxingItemResponse.Data> newList, List<BoxingItemSubModel> newList2){
        mainList = newList;
        list = newList2;
        notifyDataSetChanged();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView qty,avl_qty;
        ImageView delete, edit;

        private ImageView variant_iamge;
        private TextView name,skuId,size,color,isAir;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            variant_iamge = itemView.findViewById(R.id.boxingl_item_imageID);
            name = itemView.findViewById(R.id.boxingl_item_nameID);
            skuId = itemView.findViewById(R.id.boxingl_item_skuID);
            size = itemView.findViewById(R.id.boxingl_item_sizeID);
            color = itemView.findViewById(R.id.boxingl_item_colorID);
            isAir = itemView.findViewById(R.id.boxingl_item_is_airID);

            avl_qty = itemView.findViewById(R.id.boxingl_item_avl_qntID);
            qty = itemView.findViewById(R.id.boxingl_item_qntID);
            delete = itemView.findViewById(R.id.boxingl_item_deleteBtnID);
            edit = itemView.findViewById(R.id.boxingl_item_editBtnID);

        }

        public void setData(final int pk_id,final int qty, final int position, final String primaryImage,
                            final String variantImage, final String sku, final String mkt, final String name, final String variantName,
                            final String color,final int is_Air, final String size ){

            String insPrimaryImage = Common.BASEURL_PICTURE + primaryImage;

            if (variantImage == null || variantImage == ""){
                Glide.with(context)
                        .load(insPrimaryImage)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_iamge);
            }else {
                String insVariantImage = Common.BASEURL_PICTURE + variantImage;


                Glide.with(context)
                        .load(insVariantImage)
                        .placeholder(R.drawable.ic_default)
                        .into(variant_iamge);
            }



            if (variantName == null || variantName == ""){
                this.name.setText(name);
            }else {
                this.name.setText(variantName);
            }

            //this.skuId.setText("SKU : "+sku);
            this.skuId.setText("Barcode : "+list.get(position).barcode);
            this.color.setText("Color : "+color);

            if (is_Air == 1){
                this.isAir.setText("Air");
            }else if (is_Air == 0){
                this.isAir.setText("Sea");
            }

            this.size.setText("Size : "+size);

            this.qty.setText("Qty : "+list.get(position).qty);
            this.avl_qty.setText("Avl Qty : "+qty);


            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    final Dialog deleteDialoge = new Dialog(context,R.style.PauseDialog);
                    deleteDialoge.setContentView(R.layout.dialoge_exit);

                    int width = WindowManager.LayoutParams.MATCH_PARENT;
                    int height = WindowManager.LayoutParams.WRAP_CONTENT;

                    deleteDialoge.getWindow().setLayout(width,height);
                    deleteDialoge.setCancelable(true);
                    deleteDialoge.show();

                    Button cancel = deleteDialoge.findViewById(R.id.dialogeExitCancelID);
                    Button ok = deleteDialoge.findViewById(R.id.dialogeExitOkID);
                    TextView textMsg = deleteDialoge.findViewById(R.id.dialogeExitTextMsgID);

                    ok.setText("Delete");
                    textMsg.setText("Are you want to delete it?");

                    cancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            deleteDialoge.dismiss();
                        }
                    });

                    ok.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            list.remove(position);
                            mainList.remove(position);
                            notifyItemRangeChanged(position,list.size());
                            notifyItemRangeChanged(position,mainList.size());
                            notifyDataSetChanged();

                            ReboxingAdd.shareableListUpdate(list);

                            deleteDialoge.dismiss();
                        }
                    });
                }
            });


            edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    int checkQty = 0;
                    if (list.size() > 0){

                        for (int i = 0; i <list.size(); i++){
                            if (sku.equals(list.get(i).sku_id)){
                                checkQty += list.get(i).qty;
                            }
                        }

                        checkQty = checkQty - list.get(position).qty;
                    }

                    final Dialog qtyDialog = new Dialog(context,R.style.PauseDialog);
                    qtyDialog.setContentView(R.layout.boxing_item_qty_dialoge);

                    int width = WindowManager.LayoutParams.MATCH_PARENT;
                    int height = WindowManager.LayoutParams.WRAP_CONTENT;

                    qtyDialog.getWindow().setLayout(width,height);
                    qtyDialog.setCancelable(false);
                    qtyDialog.show();

                    final EditText qtyText = qtyDialog.findViewById(R.id.boxingItemQtyDialogeQtyID);
                    Button cancel = qtyDialog.findViewById(R.id.boxingItemQtyDialogeCancelID);
                    Button ok = qtyDialog.findViewById(R.id.boxingItemAddDialogeBtnID);
                    TextView d_avl_qty = qtyDialog.findViewById(R.id.boxingItemQtyDialogeAvlQtyID);


                    ImageView cardImage = qtyDialog.findViewById(R.id.boxingItemQtyDialogeImageID);
                    TextView cardName = qtyDialog.findViewById(R.id.boxingItemQtyDialogeNameID);
                    TextView cardColor = qtyDialog.findViewById(R.id.boxingItemQtyDialogeColorID);
                    TextView cardSize = qtyDialog.findViewById(R.id.boxingItemQtyDialogeSizeID);

                    String insPrimaryImage = Common.BASEURL_PICTURE + primaryImage;

                    if (variantImage == null || variantImage.equals("")) {
                        Glide.with(context)
                                .load(insPrimaryImage)
                                .placeholder(R.drawable.ic_default)
                                .into(cardImage);
                    } else {
                        String insVariantImage = Common.BASEURL_PICTURE + variantImage;


                        Glide.with(context)
                                .load(insVariantImage)
                                .placeholder(R.drawable.ic_default)
                                .into(cardImage);
                    }


                    if (variantName == null || variantName.equals("")) {
                        cardName.setText(name);
                    } else {
                        cardName.setText(variantName);
                    }

                    cardColor.setText("Color : " + color);
                    cardSize.setText("Size : " + size);


                    d_avl_qty.setText("Avl Qty : "+(qty - checkQty));
                    qtyText.setText(""+list.get(position).qty);
                    ok.setText("Update");


                    cancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            qtyDialog.dismiss();
                        }
                    });

                    final int finalCheckQty = checkQty;
                    ok.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (!TextUtils.isEmpty(qtyText.getText())){
                                String newQuantity = qtyText.getText().toString();
                                int newQtyInt = Integer.parseInt(newQuantity);
                                if (newQtyInt <= (qty - finalCheckQty)){

                                    if (newQtyInt == 0){
                                        newQtyInt = 1;
                                    }

                                    final BoxingItemSubModel subModel = new BoxingItemSubModel();
                                    subModel.barcode = list.get(position).barcode;
                                    subModel.sku_id = list.get(position).sku_id;
                                    subModel.qty = newQtyInt;
                                    list.set(position,subModel);

                                    ReboxingAdd.shareableListUpdate(list);


                                    BoxingItemResponse.Data itemList = new BoxingItemResponse.Data();

                                    itemList.PK_NO = pk_id;
                                    itemList.primary_image = primaryImage;
                                    itemList.variant_primary_image = variantImage;
                                    itemList.color = color;
                                    itemList.mkt_id = mkt;
                                    itemList.size = size;
                                    itemList.sku_id = sku;
                                    itemList.variant_name = variantName;
                                    itemList.product_name = name;
                                    itemList.available_qty = qty;

                                    mainList.set(position,itemList);
                                    notifyDataSetChanged();
                                    qtyDialog.dismiss();

                                }else {
                                    qtyText.requestFocus();
                                    Toast.makeText(context, "Enter less then or equal : "+qty, Toast.LENGTH_SHORT).show();

                                }
                            }else {
                                Toast.makeText(context, "Enter minimum 1 Qty", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
                }
            });


            variant_iamge.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mIRetrofitApi = Common.getApiArobil();
                    String token = SharedPreperenceUtils.getToken(context);

                    compositeDisposable.add(mIRetrofitApi.getVariantImage(token,pk_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<VariantImageResponse>() {
                        @Override
                        public void accept(VariantImageResponse response) throws Exception {
                            if (response.status == 1){
                                variantImageList = response.data;
                                ImageShowPage.variantImageList = variantImageList;
                                Intent intent = new Intent(context, ImageShowPage.class);
                                itemView.getContext().startActivity(intent);

                            }else {

                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    }));
                }
            });
        }
    }
}
