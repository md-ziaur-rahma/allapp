package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ukshop.MasterProductPage;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.NetworkModel.ProductListResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static maes.tech.intentanim.CustomIntent.customType;

public class HomePage extends AppCompatActivity {

    private TextView userName, userLocation;
    private LinearLayout checkStock,shipment,aboutBtn,
            reboxing,boxing,productSearchBtn, boxListBtn;

    private LinearLayout checkEntry, shipmentList,logoutBtn,productList;
    private LinearLayout unboxing,landAreaItemBtn, priorityUnbox,dispatchProduct,returnProduct,cod_rtcBtn,rtsBtn,
            shelvedItem,unshelving,sorting_shelving,homeRtsDispatchZoneBtn,shipment_receive,yettoBoxBtn,bookingStatus,booking;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    IRetrofitApi mRetrofitApi;


    private static ArrayList<ProductListResponse.Data> productListData = new ArrayList<>();

    private CoordinatorLayout rootLayout;


    private static final int CAMERA_PERMISSION_CODE = 301;

    private boolean isInvalid = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);


        mRetrofitApi = Common.getApiArobil();


        initialFindByID();


        userName.setText(SharedPreperenceUtils.getUserName(this));
        userLocation.setText(SharedPreperenceUtils.getUserLocation(this));

//        checkStock.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent stockIntent = new Intent(HomePage.this,StockCheckPage.class);
//                stockIntent.putExtra("isShow",false);
//                //StockCheckPage.productList = productListData;
//                startActivity(stockIntent);
//                customType(HomePage.this,"left-to-right");
//            }
//        });

        productList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent masterIntent = new Intent(HomePage.this, MasterProductPage.class);
                startActivity(masterIntent);
                customType(HomePage.this,"left-to-right");
            }
        });

        checkEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this,CheckEntry.class);
                startActivity(intent);
                customType(HomePage.this,"left-to-right");
            }
        });



        productSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent dispatchIntent = new Intent(HomePage.this,ProductSearchMy.class);
                startActivity(dispatchIntent);
                customType(HomePage.this,"left-to-right");
            }
        });


//
//
//
//        boxing.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                Intent boxingIntent = new Intent(HomePage.this,BoxingPage.class);
//                startActivity(boxingIntent);
//                customType(HomePage.this,"left-to-right");
//            }
//        });
//
//
//
//        reboxing.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                final Dialog dialog = new Dialog(HomePage.this);
//                dialog.setContentView(R.layout.riboxing_add_remove_dialoge);
//
//                int width = WindowManager.LayoutParams.MATCH_PARENT;
//                int height = WindowManager.LayoutParams.WRAP_CONTENT;
//
//                dialog.getWindow().setLayout(width,height);
//                dialog.setCancelable(true);
//                dialog.show();
//
//                Button add = dialog.findViewById(R.id.dialogeReboxingAddID);
//                Button remove = dialog.findViewById(R.id.dialogeReboxingRemoveID);
//
//                add.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        Intent intent = new Intent(HomePage.this, ReboxingAdd.class);
//                        startActivity(intent);
//                        customType(HomePage.this,"left-to-right");
//                        dialog.dismiss();
//                    }
//                });
//
//                remove.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        Intent intent = new Intent(HomePage.this, ReboxingPage.class);
//                        startActivity(intent);
//                        customType(HomePage.this,"left-to-right");
//                        dialog.dismiss();
//                    }
//                });
//
//            }
//        });

//        boxListBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent returnIntent = new Intent(HomePage.this, BoxlistPage.class);
//                BoxlistPage.shipment_no = 0;
//                startActivity(returnIntent);
//                customType(HomePage.this,"left-to-right");
//            }
//        });
//

//
//
//        shipment.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(HomePage.this,ShipmentPage.class);
//                startActivity(intent);
//                customType(HomePage.this,"left-to-right");
//            }
//        });


        shipmentList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent dispatchIntent = new Intent(HomePage.this,ShipmentInprogress.class);
                startActivity(dispatchIntent);
                customType(HomePage.this,"left-to-right");
            }
        });



        /**

         // don't delete the code...

        booking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(HomePage.this,StockCheckPage.class);
                intent.putExtra("isShow",true);
                startActivity(intent);
                customType(HomePage.this,"left-to-right");
            }
        });

        bookingStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this,BookingStatusPage.class);
                startActivity(intent);
                customType(HomePage.this,"left-to-right");
            }
        }); */



        shipment_receive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this,ShipmentReceivePage.class);
                startActivity(intent);
                customType(HomePage.this,"left-to-right");
            }
        });

        unboxing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent boxingIntent = new Intent(HomePage.this, UnboxingBoxListPage.class);
                startActivity(boxingIntent);
                customType(HomePage.this,"left-to-right");
            }
        });




        dispatchProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent dispatchIntent = new Intent(HomePage.this, RtsDispatchPage.class);
                startActivity(dispatchIntent);
                customType(HomePage.this,"left-to-right");

                //Toast.makeText(HomePage.this, "Under development", Toast.LENGTH_SHORT).show();
            }
        });

        cod_rtcBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent boxingIntent = new Intent(HomePage.this, CodRtcPickingList.class);
                startActivity(boxingIntent);
                customType(HomePage.this,"left-to-right");
            }
        });
//
//        codRtcDispatchZoneBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent boxingIntent = new Intent(HomePage.this, CodRtcDispatchZone.class);
//                startActivity(boxingIntent);
//                customType(HomePage.this,"left-to-right");
//            }
//        });
//
//        codRtcDispatchBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(HomePage.this, CodRtcOrderListPage.class);
//                startActivity(intent);
//                customType(HomePage.this,"left-to-right");
//                //Toast.makeText(HomePage.this, "Under development", Toast.LENGTH_SHORT).show();
//            }
//        });

        rtsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent boxingIntent = new Intent(HomePage.this, RtsBatchList.class);
                startActivity(boxingIntent);
                customType(HomePage.this,"left-to-right");

            //    Toast.makeText(HomePage.this, "Under development", Toast.LENGTH_SHORT).show();

            }
        });


        returnProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                    Intent returnIntent = new Intent(HomePage.this,ReturnPage.class);
//                    startActivity(returnIntent);
//                    customType(HomePage.this,"left-to-right");

                Toast.makeText(HomePage.this, "Under development", Toast.LENGTH_SHORT).show();
            }
        });



        sorting_shelving.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent(HomePage.this, SortingShelvingPage.class);
                startActivity(returnIntent);
                customType(HomePage.this,"left-to-right");
            }
        });


        shelvedItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent(HomePage.this, ShelveItemListPage.class);
                startActivity(returnIntent);
                customType(HomePage.this,"left-to-right");
            }
        });

        homeRtsDispatchZoneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent returnIntent = new Intent(HomePage.this, CheckoutProductPage.class);
//                startActivity(returnIntent);
//                customType(HomePage.this,"left-to-right");

                Intent returnIntent = new Intent(HomePage.this, DispatchAreaBatchList.class);
                startActivity(returnIntent);
                customType(HomePage.this,"left-to-right");

            //    Toast.makeText(HomePage.this, "Under development", Toast.LENGTH_SHORT).show();

            }
        });

        unshelving.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent(HomePage.this, UnshelvePage.class);
                startActivity(returnIntent);
                customType(HomePage.this,"left-to-right");
            }
        });


        landAreaItemBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent(HomePage.this, LandAreaItemPage.class);
                startActivity(returnIntent);
                customType(HomePage.this,"left-to-right");
            }
        });


        priorityUnbox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent(HomePage.this, PriorityUnboxList.class);
                startActivity(returnIntent);
                customType(HomePage.this,"left-to-right");
            }
        });

        aboutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent(HomePage.this, AboutUs.class);
                startActivity(returnIntent);
            }
        });


//        yettoBoxBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent returnIntent = new Intent(HomePage.this, YettoBoxPage.class);
//                startActivity(returnIntent);
//                customType(HomePage.this,"left-to-right");
//            }
//        });


        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Dialog dialog = new Dialog(HomePage.this,R.style.fadeDialog);
                dialog.setContentView(R.layout.dialog_logout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                Button OkBtn = dialog.findViewById(R.id.dialogeLogoutOkID);
                Button cancelBtn = dialog.findViewById(R.id.dialogeLogoutCancelID);

                cancelBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                OkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        SharedPreperenceUtils.removeShared(HomePage.this,SharedPreperenceUtils.USER_ID);
                        SharedPreperenceUtils.clearUserData(HomePage.this);

                        Intent intent = new Intent(HomePage.this,LoginPage.class);
                        startActivity(intent);
                        //customType(HomePage.this,"right-to-left");
                        dialog.dismiss();
                        finish();
                    }
                });

            }
        });

        /**
         * Matrix matrix = new Matrix();
         * imageView.setScaleType(ImageView.ScaleType.MATRIX);   //required
         * matrix.postRotate((float) angle, pivotX, pivotY);
         * imageView.setImageMatrix(matrix);
         */
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootLayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootLayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
            snackbar.show();
        }
    }

    @Override
    public void onBackPressed() {

        final Dialog dialog = new Dialog(HomePage.this,R.style.fadeDialog);
        dialog.setContentView(R.layout.dialog_logout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(true);
        dialog.show();

        final Button okBtn = dialog.findViewById(R.id.dialogeLogoutOkID);
        final Button cancelBtn = dialog.findViewById(R.id.dialogeLogoutCancelID);
        final TextView topMsg = dialog.findViewById(R.id.dialogLogoutTopTextID);
        final TextView msg = dialog.findViewById(R.id.dialogeLogoutTextMsgID);

        okBtn.setText("Exit");
        topMsg.setText("Warning!");
        msg.setText("Are you want to close app.. ?");

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
            }
        });


    }


    /// find all fields method....
    private void initialFindByID(){
        rootLayout = (CoordinatorLayout)findViewById(R.id.homePageRootLayoutID);

        userName = (TextView)findViewById(R.id.homeUserNameID);
        userLocation = (TextView)findViewById(R.id.homeUserLocationID);
        aboutBtn = (LinearLayout)findViewById(R.id.homeAboutBtnID);
        //checkStock = (LinearLayout)findViewById(R.id.homeCheckStockBtnID);
        productList = (LinearLayout)findViewById(R.id.homeProductListId);
        checkEntry = (LinearLayout)findViewById(R.id.homeCheckEntryBtnID);
        //shipment = (LinearLayout)findViewById(R.id.homeShipmentBtnID);
        shipmentList = (LinearLayout)findViewById(R.id.homeShipmentListBtnID);
        shipment_receive = (LinearLayout)findViewById(R.id.homeShipmentReceiveBtnID);
        //booking = (LinearLayout)findViewById(R.id.homeBookingBtnID);
        //bookingStatus = (LinearLayout)findViewById(R.id.homeBookingStatusBtnID);
        productSearchBtn = (LinearLayout)findViewById(R.id.homeProductSearchBtnID);
        unboxing = (LinearLayout)findViewById(R.id.homeUnboxingBtnID);
        //boxing = (LinearLayout)findViewById(R.id.homeBoxingBtnID);
        //boxListBtn = (LinearLayout)findViewById(R.id.homeBoxListBtnID);
        //yettoBoxBtn = (LinearLayout)findViewById(R.id.homeYettoBoxBtnID);
        landAreaItemBtn = (LinearLayout)findViewById(R.id.homeUnboxedItemBtnID);
        priorityUnbox = (LinearLayout)findViewById(R.id.homePriorityUnboxBtnID);
        //reboxing = (LinearLayout)findViewById(R.id.homeReboxingBtnID);
        dispatchProduct = (LinearLayout)findViewById(R.id.homeDispatchBtnID);
        cod_rtcBtn = (LinearLayout)findViewById(R.id.homeCodRtcBtnID);
//        codRtcDispatchBtn = (LinearLayout)findViewById(R.id.homeCodRtcDispatchBtnID) ;
//        codRtcDispatchZoneBtn = (LinearLayout)findViewById(R.id.homeCodRtcDispatchZoneBtnID) ;
        rtsBtn = (LinearLayout)findViewById(R.id.homeRTSBtnID);
        returnProduct = (LinearLayout)findViewById(R.id.homeReturnBtnID);
        sorting_shelving = (LinearLayout)findViewById(R.id.homeShortingShelvingBtnID);
        shelvedItem = (LinearLayout)findViewById(R.id.homeShelvedItemBtnID);
        unshelving = (LinearLayout)findViewById(R.id.homeUnshelvBtnID);
        homeRtsDispatchZoneBtn = (LinearLayout)findViewById(R.id.homeDispatchZoneBtnID);
        logoutBtn = (LinearLayout)findViewById(R.id.homeLogoutBtnID);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE){
            if (grantResults.length >= 0){

            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }


    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ApiResponse>() {
            @Override
            public void accept(ApiResponse response) throws Exception {
                if (response.status == 0) {
                    isInvalid = true;
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));

        return isInvalid;
    }

}