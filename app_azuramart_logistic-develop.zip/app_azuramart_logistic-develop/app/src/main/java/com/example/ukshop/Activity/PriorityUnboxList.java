package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;

import com.example.ukshop.Adapters.PriorityBoxAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.PriorityBoxPost;
import com.example.ukshop.NetworkModel.PriorityBoxResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class PriorityUnboxList extends AppCompatActivity {

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private NestedScrollView nestedScrollView;

    private List<PriorityBoxResponse.Data> scrollList = new ArrayList<>();
    private List<PriorityBoxResponse.Data> list = new ArrayList<>();
    private RecyclerView recyclerView;
    private PriorityBoxAdapter adapter;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_priority_box_list);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new PriorityBoxAdapter(list, PriorityUnboxList.this,rootLayout);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();


        if (Utils.broadcastIntent(this,rootLayout)){
            loadBoxList();
        }else {
            NoInternetSnackBar();
        }


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.menuShipment_refreshId){
                    if (Utils.broadcastIntent(PriorityUnboxList.this,rootLayout)){
                        loadBoxList();
                    }else {
                        NoInternetSnackBar();
                    }
                }

                return false;
            }
        });

        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if(v.getChildAt(v.getChildCount() - 1) != null) {
                    if ((scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight())) &&
                            scrollY > oldScrollY) {

                        //https://medium.com/@mujjtahidah/load-more-recyclerview-inside-nested-scroll-view-and-coordinator-layout-4f179dc01fd

                        if (!recyclerView.canScrollVertically(1)){
                            onScrollToBottom();
                        }

                    }
                }
            }
        });


    }

    private void onScrollToBottom(){
        if (scrollList.size() < list.size()){
            int x,y;
            if ((list.size() - scrollList.size()) >= 20){
                x = scrollList.size();
                y = x + 20;
            }else {
                x = scrollList.size();
                y = x + list.size() - scrollList.size();
            }

            for (int i = x; i < y; i++){
                scrollList.add(i,list.get(i));
            }

            adapter.updateList(scrollList);
        }
    }

    private void initialFindFields() {
        rootLayout = (CoordinatorLayout)findViewById(R.id.priorityBoxRootLayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.priorityboxToolbarID);
        nestedScrollView = (NestedScrollView)findViewById(R.id.priorityUnboxListScrollviewID);

        recyclerView = (RecyclerView)findViewById(R.id.priorityBoxRecyclerID);

    }


    @Override
    public void onBackPressed() {
        scrollList = new ArrayList<>();
        list = new ArrayList<>();
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }
    }

    private void loadBoxList(){

        if (Utils.broadcastIntent(this,rootLayout)){

            scrollList = new ArrayList<>();
            list = new ArrayList<>();
            adapter.updateList(list);

            String token = SharedPreperenceUtils.getToken(this);
            int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

            final Dialog dialog = new Dialog(PriorityUnboxList.this);
            dialog.setContentView(R.layout.transparent_progress_dialoge);

            int width = WindowManager.LayoutParams.WRAP_CONTENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width, height);
            dialog.setCancelable(false);
            dialog.show();

            final PriorityBoxPost post = new PriorityBoxPost();
            post.user_id = user_id;

            Log.e("priority box post", "msg"+new Gson().toJson(post));

            compositeDisposable.add(mIRetrofitApi.getPriorityBoxList(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<PriorityBoxResponse>() {
                @Override
                public void accept(PriorityBoxResponse response) throws Exception {

                    if (response.status == 1){

                        list = response.data;

                        if (list.size() >= 30){
                            for (int i = 0; i < 30; i++){
                                scrollList.add(list.get(i));
                            }
                        }else {
                            scrollList.addAll(list);
                        }

                        adapter.updateList(scrollList);

                        dialog.dismiss();
                    }else {
                        dialog.dismiss();

                        if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                            Utils.expiredTokenAlert(rootLayout, PriorityUnboxList.this);
                        } else {
                            Snackbar snackbar = Snackbar.make(rootLayout,""+response.message,Snackbar.LENGTH_LONG);
                            snackbar.setAction("Retry", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    loadBoxList();
                                }
                            });
                            snackbar.show();
                        }
                    }

                }
            }, new Consumer<Throwable>() {
                @Override
                public void accept(Throwable throwable) throws Exception {
                    dialog.dismiss();

                    if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                        Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                loadBoxList();
                            }
                        });
                        snackbar.show();
                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                        snackbar.setAction("Retry", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                loadBoxList();
                            }
                        });
                        snackbar.show();
                    }

                }
            }));

        }else {
            NoInternetSnackBar();
        }



    }


    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
        snackbar.setAction("Retry", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.broadcastIntent(PriorityUnboxList.this,rootLayout)){
                    loadBoxList();
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        snackbar.show();
    }
}