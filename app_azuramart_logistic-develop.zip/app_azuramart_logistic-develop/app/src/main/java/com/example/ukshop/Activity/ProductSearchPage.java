package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.ukshop.Adapters.ProductSearchItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.NetworkModel.BoxingItemResponse;
import com.example.ukshop.NetworkModel.ProductListResponse;
import com.example.ukshop.NetworkModel.ProductSearchPost;
import com.example.ukshop.NetworkModel.ProductSearchResponse;
import com.example.ukshop.NetworkModel.StockCheckPost;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class ProductSearchPage extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private EditText skuText, mktText, productNameText;
    private Button stockCheckBtn;
    private ExtendedFloatingActionButton scanProductFabBtn;

    private RecyclerView recyclerView;
    private List<ProductSearchResponse.Data> mainList = new ArrayList<>();
    private List<ProductSearchResponse.Data> totalList = new ArrayList<>();
    private ProductSearchItemAdapter adapter;

    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private NestedScrollView nestedScrollView;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    private static final int CAMERA_REQUEST_CODE = 501;

    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static boolean isFlash = false;

    private boolean isInvalid = false;

    // Media Player Varable...

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();
    private static int isTone = 0;


    //private List<BoxingItemResponse.Data> singleProduct = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_search);

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();

        stockCheckBtn.setText(R.string.search);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new ProductSearchItemAdapter(mainList, ProductSearchPage.this,rootLayout,0,0);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();


        //.................. show all product details ...............//
//        if (Utils.broadcastIntent(this,rootLayout)){
//            loadData("","","","");
//        }else {
//            Utils.snackbarToast(rootLayout,"No Internet  Connection!");
//        }



        stockCheckBtn.setOnClickListener(v -> {
            String sku_idT = skuText.getText().toString();
            String mkt_idT = mktText.getText().toString();
            String product_nameT = productNameText.getText().toString();

            if (TextUtils.isEmpty(sku_idT) && TextUtils.isEmpty(mkt_idT) && TextUtils.isEmpty(product_nameT)){
                Toast.makeText(ProductSearchPage.this, "Search fields are empty!", Toast.LENGTH_LONG).show();
            } else {
                if (TextUtils.isEmpty(sku_idT)){
                    sku_idT = "";
                }

                if (TextUtils.isEmpty(mkt_idT)){
                    mkt_idT = "";
                }

                if (TextUtils.isEmpty(product_nameT)){
                    product_nameT = "";
                }

                if (Utils.broadcastIntent(ProductSearchPage.this,rootLayout)){
                    loadData(sku_idT, mkt_idT, product_nameT,"");
                }else {
                    NoInternetSnackBar();
                }
            }
        });

        toolbar.setNavigationOnClickListener(v -> finish());

        toolbar.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();

            if (id == R.id.menuShipment_refreshId) {
                if (Utils.broadcastIntent(ProductSearchPage.this, rootLayout)) {
//                    loadData("", "", "", "");
                } else {
                    Utils.snackbarToast(rootLayout, "No Internet Connection!");
                }
                return true;
            }
            return false;
        });

        scanProductFabBtn.setOnClickListener(v -> {
            if (Utils.isCameraPermission(ProductSearchPage.this)){
                openScanner();
            }else {
                ActivityCompat.requestPermissions(ProductSearchPage.this,new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST_CODE);
            }
        });

        scanProductFabBtn.setOnLongClickListener(v -> {
            final Dialog dialog = new Dialog(ProductSearchPage.this);
            dialog.setContentView(R.layout.barcod_picker_layout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(true);
            dialog.show();

            final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
            final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
            Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
            // barcodeText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(10)});

            search.setText(R.string.search);

            cancel.setOnClickListener(v1 -> dialog.dismiss());

            search.setOnClickListener(v12 -> {
                if (!TextUtils.isEmpty(barcodeText.getText().toString())){
                    loadData("","","",barcodeText.getText().toString());
                    dialog.dismiss();
                }else {
                    barcodeText.requestFocus();
                    Toast.makeText(ProductSearchPage.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                }
            });

            return false;
        });

        nestedScrollView.setOnScrollChangeListener((NestedScrollView.OnScrollChangeListener) (v, scrollX, scrollY, oldScrollX, oldScrollY) -> {

            if(v.getChildAt(v.getChildCount() - 1) != null) {

                if ((scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight())) &&
                        scrollY > oldScrollY) {

                    //https://medium.com/@mujjtahidah/load-more-recyclerview-inside-nested-scroll-view-and-coordinator-layout-4f179dc01fd

                    if (!recyclerView.canScrollVertically(1)){
                        onScrollToBottom();
                    }

                }
            }

        });

        if (Utils.broadcastIntent(this,rootLayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootLayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",10000);
            snackbar.show();
        }
    }

    private void onScrollToBottom(){
        if (mainList.size() < totalList.size()){
            int x,y;
            if ((totalList.size() - mainList.size()) >= 20){
                x = mainList.size();
                y = x + 20;
            }else {
                x = mainList.size();
                y = x + totalList.size() - mainList.size();
            }

            for (int i = x; i < y; i++){
                mainList.add(i,totalList.get(i));
            }

            adapter.updateData(mainList);
        }
    }

    private void initialFindFields(){
        rootLayout = (CoordinatorLayout)findViewById(R.id.productSearchRootLayoutID);
        toolbar = (MaterialToolbar)findViewById(R.id.productSearchToolbarID);
        nestedScrollView = (NestedScrollView)findViewById(R.id.productSearchNestedScrollID);
        scanProductFabBtn = (ExtendedFloatingActionButton)findViewById(R.id.productSearchFabBtnID);

        skuText = (EditText)findViewById(R.id.stockCheckSKUId);
        mktText = (EditText)findViewById(R.id.stockCheckMKTId);
        productNameText = (EditText)findViewById(R.id.stockChectProductNameID);

        stockCheckBtn = (Button)findViewById(R.id.stockCheckBtnID);
        recyclerView = (RecyclerView)findViewById(R.id.productSearchRecyclerID);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootLayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootLayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",10000);
            snackbar.show();
        }
    }

    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mIRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
            if (response.status == 0) {
                isInvalid = true;
            }
        }, throwable -> {

        }));

        return isInvalid;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CAMERA_REQUEST_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    private void NoInternetSnackBar(){
        Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",Snackbar.LENGTH_LONG);
        snackbar.show();
    }

    private void openScanner(){
        scannerDialog = new Dialog(ProductSearchPage.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);



        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(ProductSearchPage.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(v -> {
            scannerView.stopCamera();
            scannerDialog.dismiss();
        });

        scannerFlash.setOnClickListener(v -> {
            if (isFlash){
                scannerFlash.setImageResource(R.drawable.ic_flash_off);
                scannerView.setFlash(false);
                isFlash = false;
            }else {
                scannerFlash.setImageResource(R.drawable.ic_flash_on);
                scannerView.setFlash(true);
                isFlash = true;
            }
        });

    }

    @Override
    public void handleResult(Result rawResult) {

        if (!TextUtils.isEmpty(rawResult.getText())){

            isTone = 1;

            loadData("","","",rawResult.getText());

            scannerDialog.dismiss();
            scannerView.stopCamera();
        }else {
            wrongTone.start();
        }

    }

    private void loadData(String skuID, String mktID, String productName,String barcode){

        totalList = new ArrayList<>();
        mainList = new ArrayList<>();
        adapter.updateData(mainList);

        final Dialog dialog = new Dialog(ProductSearchPage.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        final String token = SharedPreperenceUtils.getToken(ProductSearchPage.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        final ProductSearchPost post = new ProductSearchPost();
        post.sku_id = skuID;
        post.user_id = user_id;
        post.product_name = productName;
        post.mkt_id = mktID;
        post.barcode = barcode;

        Log.e("product search uk post", "msg"+new Gson().toJson(post));

        compositeDisposable.add(mIRetrofitApi.getProductSearch(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
            if (response.status == 1){

                if (isTone == 1){
                    rightTone.start();
                    isTone = 0;
                }

                totalList = response.data;

                //Toast.makeText(ProductSearchPage.this, ""+totalList.size(), Toast.LENGTH_SHORT).show();

                if (totalList.size() >= 20){

                    for (int i = 0; i < 20; i++){
                        mainList.add(totalList.get(i));
                    }
                }else {
                    mainList.addAll(response.data);
                }

                adapter.updateData(mainList);

                dialog.dismiss();

            }else {

                if (isTone == 1){
                    wrongTone.start();
                    isTone = 0;
                }

                dialog.dismiss();

                if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                    Utils.expiredTokenAlert(rootLayout,ProductSearchPage.this);
                }else {
                    Utils.snackbarToast(rootLayout,response.message);
                }
            }
        }, throwable -> {

            if (isTone == 1){
                wrongTone.start();
                isTone = 0;
            }

            dialog.dismiss();

            if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 5000);
                snackbar.show();
            }else {
                Utils.snackbarToast(rootLayout,throwable.getMessage());
            }
        }));

    }
}