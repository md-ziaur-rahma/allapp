package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class CodRtcDispatchItemPost {
    @SerializedName("user_id")
    public int user_id;

    @SerializedName("order_id")
    public int order_id;
}
