package com.example.ukshop.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ukshop.Activity.BoxlistPage;
import com.example.ukshop.Activity.Merchant.MerchantBoxList;
import com.example.ukshop.NetworkModel.ShipmentInprogressResponse;
import com.example.ukshop.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import static maes.tech.intentanim.CustomIntent.customType;

public class ShipmentInprogressItemAdapter extends RecyclerView.Adapter<ShipmentInprogressItemAdapter.ViewHolder> {

    private List<ShipmentInprogressResponse.Data> list;
    private Activity context;
    private CoordinatorLayout rootLayout;

    public ShipmentInprogressItemAdapter(List<ShipmentInprogressResponse.Data> list, Activity context, CoordinatorLayout rootLayout) {
        this.list = list;
        this.context = context;
        this.rootLayout = rootLayout;
    }

    @NonNull
    @Override
    public ShipmentInprogressItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.shipment_in_progress_layout,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ShipmentInprogressItemAdapter.ViewHolder holder, int position) {
        int shipmentNo = list.get(position).shipment_no;
        int shipmentLabel = list.get(position).shipment_label;
        String shortName = list.get(position).short_name;
        int boxCount = list.get(position).box_count;
        int received_qty = list.get(position).received_qty;
        String  departureTime = list.get(position).departure_time;
        String etaDate = list.get(position).ETA_date;
        int status = list.get(position).status;
        int merchantId = list.get(position).merchant_id;
        String merchantName = list.get(position).merchant_name;

        if (!TextUtils.isEmpty(departureTime)){
            if (departureTime.length() > 0){
                departureTime = departureTime.substring(0,10);
            }
        }else {
            departureTime = "";
        }

        if (!TextUtils.isEmpty(etaDate)){
            if (etaDate.length() > 0){
                etaDate = etaDate.substring(0,10);
            }
        }else {
            etaDate = "";
        }



        int is_air = list.get(position).is_air;

        holder.setData(shipmentNo,shipmentLabel,shortName,boxCount,received_qty,departureTime, etaDate, status, is_air,merchantId,merchantName);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void updateList(List<ShipmentInprogressResponse.Data> newList){
        list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private final TextView shipmentLabel, boxCount, departureTime, status, etaDate;
        private final ImageView icon;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            icon = itemView.findViewById(R.id.shipmentInprogressIconID);
            shipmentLabel = itemView.findViewById(R.id.shipmentInprogressShipmentLabelID);
            boxCount = itemView.findViewById(R.id.shipmentInprogressBoxCountID);
            departureTime = itemView.findViewById(R.id.shipmentInprogressDepartureID);
            etaDate = itemView.findViewById(R.id.shipmentInprogressETAID);
            status = itemView.findViewById(R.id.shipmentInprogressStatusID);


        }

        public void setData(final int shipmentNo, int shipmentLabel,final String shortName, final int boxCount,final int received_qty,
                            final String departureTime, final String etaDate, final int status, int is_air,int merchantId, String merchantName) {
            this.shipmentLabel.setText("("+shortName+")"+shipmentLabel);
            this.boxCount.setText("Box Count : "+received_qty+"/"+boxCount);


            if (departureTime == null || departureTime.equals("")){
                this.departureTime.setVisibility(View.GONE);
            }else {
                this.departureTime.setVisibility(View.VISIBLE);
                this.departureTime.setText("EDD : "+departureTime);
            }

            if (etaDate == null || etaDate.equals("")){
                this.etaDate.setVisibility(View.GONE);
            }else {
                this.etaDate.setVisibility(View.VISIBLE);

                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

                Date date1 = new Date();
                Date date2 = new Date();
                Date currentDate = Calendar.getInstance().getTime();
                String strDate2 = format.format(currentDate);

                try {
                    date1 = format.parse(etaDate);
                    date2 = format.parse(strDate2);
                } catch (ParseException e) {
                    e.printStackTrace();
                }


                assert date1 != null;
                assert date2 != null;
                long difference = date1.getTime() - date2.getTime();

                long days = TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS);

                if (status >= 70){
                    this.etaDate.setText("ETA : "+etaDate);
                }else {
                    if (days > 0){
                        this.etaDate.setText("ETA : "+etaDate+" , "+days+" Days more");
                    }else {
                        this.etaDate.setText("ETA : "+etaDate);
                    }
                }
            }

                this.status.setVisibility(View.VISIBLE);
                if (status == 0){
                    this.status.setText("Not Shipped");
                }else if (status == 10){
                    this.status.setText("In Progress at Source");
                }else if (status == 20){
                    this.status.setText("In Transit (UK)");
                }else if (status == 30){
                    this.status.setText("Cancelled");
                }else if (status == 40){
                    this.status.setText("In Transit (UK)");
                }else if (status == 50){
                    this.status.setText("In Transit (VESSEEL)");
                }else if (status == 60){
                    this.status.setText("In Transit (MY)");
                }else if (status == 70){
                    this.status.setText("Ready to Receive (MY)");
                }else if (status == 80){
                    this.status.setText("All Box Received");
                }else if (status == 90){
                    this.status.setText("Unboxing Finished");
                }else if (status == 100){
                    this.status.setText("Shipment Complete");
                }



            if (is_air == 0){
                //icon.setImageResource(R.drawable.ic_ship);
                Drawable iconBack = context.getDrawable(R.drawable.home_button_back_2);
                icon.setBackground(iconBack);
                //icon.setPadding(10,10,10,10);
                icon.setImageResource(R.drawable.ic_ship);
            }else if (is_air == 1){
                //icon.setImageResource(R.drawable.ic_shipment);
                Drawable iconBack = context.getDrawable(R.drawable.home_button_back_2);
                icon.setBackground(iconBack);
                icon.setPadding(5,5,5,5);
                icon.setImageResource(R.drawable.ic_aroplane);
            }


            if (merchantName != null){
                itemView.setOnClickListener(v -> {

                    if (boxCount != 0){
                        Intent intent = new Intent(context, MerchantBoxList.class);
                        intent.putExtra("merchant_pk",merchantId);
                        intent.putExtra("merchant_name",merchantName);
                        MerchantBoxList.shipment_no = shipmentNo;
                        itemView.getContext().startActivity(intent);
                        customType(context,"left-to-right");
                    }else {
                        Toast.makeText(context, "Box Count 0", Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                itemView.setOnClickListener(v -> {

                    if (boxCount != 0){
                        Intent intent = new Intent(context, BoxlistPage.class);
                        BoxlistPage.shipment_no = shipmentNo;
                        itemView.getContext().startActivity(intent);
                        customType(context,"left-to-right");
                    }else {
                        Toast.makeText(context, "Box Count 0", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
    }
}
