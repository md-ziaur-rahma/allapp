package com.example.ukshop.NetworkModel;

import com.google.gson.annotations.SerializedName;

public class AuthPost {
    @SerializedName("email")
    public String email;

    @SerializedName("password")
    public String password;

    @SerializedName("version_code")
    public int version_code;

    @SerializedName("version_name")
    public float version_name;

    @SerializedName("deviceId")
    public String deviceId;

    @SerializedName("IPaddress")
    public String IPaddress;
}
