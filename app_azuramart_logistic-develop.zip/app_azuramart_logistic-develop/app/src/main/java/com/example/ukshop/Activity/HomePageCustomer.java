package com.example.ukshop.Activity;

import static maes.tech.intentanim.CustomIntent.customType;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ukshop.Activity.Merchant.MerchantBoxList;
import com.example.ukshop.Activity.Merchant.MerchantShipmentList;
import com.example.ukshop.Activity.Merchant.MerchantStockSearch;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.snackbar.Snackbar;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

public class HomePageCustomer extends AppCompatActivity {
    private TextView userName, userLocation;
    private LinearLayout shipmentList,productSearchBtn,aboutUs,yetToBoxAllBtn,
            logoutBtn,boxListBtn;
    final private CompositeDisposable compositeDisposable = new CompositeDisposable();
    IRetrofitApi mRetrofitApi;

    private CoordinatorLayout rootLayout;
    private boolean isInvalid = false;
    private String merchantName;
    private int merchantId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page_customer);
        mRetrofitApi = Common.getApiArobil();
        initialFindByID();

        merchantId = Integer.parseInt(SharedPreperenceUtils.getMerchantId(this));
        merchantName = SharedPreperenceUtils.getUserName(this);
        userName.setText(SharedPreperenceUtils.getUserName(this));
        userLocation.setText("");

        productSearchBtn.setOnClickListener(v -> {
            Intent intent = new Intent(HomePageCustomer.this,CustomerProductSearch.class);
            intent.putExtra("merchant_id",Integer.parseInt(SharedPreperenceUtils.getMerchantId(this)));
            intent.putExtra("merchant_name",SharedPreperenceUtils.getUserName(this));
            startActivity(intent);
            customType(HomePageCustomer.this,"left-to-right");
        });

        boxListBtn.setOnClickListener(v -> {
            Intent intent = new Intent(HomePageCustomer.this, MerchantBoxList.class);
            intent.putExtra("merchant_pk",merchantId);
            intent.putExtra("merchant_name",merchantName);
            BoxlistPage.shipment_no = 0;
            startActivity(intent);
            customType(HomePageCustomer.this,"left-to-right");
        });

        shipmentList.setOnClickListener(v -> {
            Intent intent = new Intent(HomePageCustomer.this, MerchantShipmentList.class);
            intent.putExtra("merchant_pk",merchantId);
            intent.putExtra("merchant_name",merchantName);
            startActivity(intent);
            customType(HomePageCustomer.this,"left-to-right");
        });

        aboutUs.setOnClickListener(v -> {
            Intent aboutIntent = new Intent(HomePageCustomer.this, AboutUs.class);
            startActivity(aboutIntent);
        });

        yetToBoxAllBtn.setOnClickListener(v -> {
            Intent intent = new Intent(HomePageCustomer.this, MerchantStockSearch.class);
            intent.putExtra("merchant_pk",merchantId);
            intent.putExtra("merchant_name",merchantName);
            intent.putExtra("isShow",false);
            startActivity(intent);
            customType(HomePageCustomer.this,"left-to-right");
        });

        logoutBtn.setOnClickListener(v -> {
            final Dialog dialog = new Dialog(HomePageCustomer.this,R.style.fadeDialog);
            dialog.setContentView(R.layout.dialog_logout);

            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.getWindow().setLayout(width,height);
            dialog.setCancelable(true);
            dialog.show();

            Button OkBtn = dialog.findViewById(R.id.dialogeLogoutOkID);
            Button cancelBtn = dialog.findViewById(R.id.dialogeLogoutCancelID);

            cancelBtn.setOnClickListener(v12 -> dialog.dismiss());

            OkBtn.setOnClickListener(v1 -> {
                SharedPreperenceUtils.removeShared(HomePageCustomer.this,SharedPreperenceUtils.USER_ID);
                SharedPreperenceUtils.clearUserData(HomePageCustomer.this);

                Intent intent = new Intent(HomePageCustomer.this,LoginPage.class);
                startActivity(intent);
                dialog.dismiss();
                finish();
            });

        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootLayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootLayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",5000);
            snackbar.show();
        }
    }

    @Override
    public void onBackPressed() {

        final Dialog dialog = new Dialog(HomePageCustomer.this,R.style.fadeDialog);
        dialog.setContentView(R.layout.dialog_logout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(true);
        dialog.show();

        final Button okBtn = dialog.findViewById(R.id.dialogeLogoutOkID);
        final Button cancelBtn = dialog.findViewById(R.id.dialogeLogoutCancelID);
        final TextView topMsg = dialog.findViewById(R.id.dialogLogoutTopTextID);
        final TextView msg = dialog.findViewById(R.id.dialogeLogoutTextMsgID);

        okBtn.setText("Exit");
        topMsg.setText("Warning!");
        msg.setText("Are you want to close app.. ?");

        cancelBtn.setOnClickListener(v -> dialog.dismiss());

        okBtn.setOnClickListener(v -> {
            dialog.dismiss();
            finish();
        });
    }

    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(response -> {
            if (response.status == 0) {
                isInvalid = true;
            }
        }, throwable -> {

        }));

        return isInvalid;
    }

    private void initialFindByID(){
        rootLayout = findViewById(R.id.customerHomePageRootLayoutID);
        userName = findViewById(R.id.homeUserNameID);
        aboutUs = findViewById(R.id.homeAboutBtnID);
        userLocation = findViewById(R.id.homeUserLocationID);
        productSearchBtn = findViewById(R.id.customerHomeProductSearchUKBtnID);
        shipmentList = findViewById(R.id.customerHomeShipmentListUKBtnID);
        boxListBtn = findViewById(R.id.customerHomeBoxListUKBtnID);
        yetToBoxAllBtn = findViewById(R.id.customerHomeCheckStockUKBtnID);
        logoutBtn = findViewById(R.id.customerHomeLogoutUKBtnID);
    }
}