package com.example.ukshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;

import com.example.ukshop.Adapters.MasterProductDetailsAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.MasterProductDetailsResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static maes.tech.intentanim.CustomIntent.customType;

public class ProductListPage extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MasterProductDetailsAdapter adapter;
    private List<MasterProductDetailsResponse.Data> list = new ArrayList<>();
    private List<MasterProductDetailsResponse.Data> mainList = new ArrayList<>();

    private EditText searchBox;
    private CoordinatorLayout rootLayout;
    private MaterialToolbar toolbar;
    private int mp_id;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list_page);

        mIRetrofitApi = Common.getApiArobil();

        mp_id = getIntent().getIntExtra("mp_id",0);
        Common.master_product_id = mp_id;


        toolbar = (MaterialToolbar)findViewById(R.id.MasterDetailsToolbarID);
        recyclerView = (RecyclerView)findViewById(R.id.productListRecyclerID);


        searchBox = (EditText)findViewById(R.id.productListSearchID);
        rootLayout = (CoordinatorLayout)findViewById(R.id.productListPageRootLayoutID);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        if (Utils.broadcastIntent(ProductListPage.this,rootLayout)){
            loadData();
        }else {
            Snackbar snackbar = Snackbar.make(rootLayout,"No Internet Connection!",Snackbar.LENGTH_LONG);
            snackbar.setAction("Go Back", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
            snackbar.show();
        }

        // toolbar code...
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        // set TextWatcher into SearchBox...
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                if (list.size() > 0 ){
                    if (!TextUtils.isEmpty(s.toString())){
                        filterText(s.toString());
                    }else {
                        filterText("");
                    }
                }


            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        mp_id = Common.master_product_id;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    private void filterText(String text){
        ArrayList<MasterProductDetailsResponse.Data> filteredList = new ArrayList<>();

        for (MasterProductDetailsResponse.Data item : list){

            if (isMatches(text,item.barcode)
                    ||isMatches(text,item.mkt_id)
                    ||isMatches(text,item.variant_name)
            ){
                filteredList.add(item);
            }
        }
        adapter.filterdItem(filteredList);
    }

    private boolean isMatches(String input,String name){
        String[] split = input.split(" ");
        for (String s : split){
            if (name.toLowerCase().contains(s.toLowerCase())){
                return true;
            }
        }
        return false;
    }

    public void loadData(){
        final Dialog dialog = new Dialog(ProductListPage.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        final String token = SharedPreperenceUtils.getToken(ProductListPage.this);

        compositeDisposable.add(mIRetrofitApi.getProductVariantList(token,mp_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<MasterProductDetailsResponse>() {
            @Override
            public void accept(MasterProductDetailsResponse masterProductDetailsResponse) throws Exception {
                if (masterProductDetailsResponse.status == 1){
                    list = masterProductDetailsResponse.data;

                    if (list.size() >= 50){
                        for (int i = 0;i < 50; i++){
                            mainList.add(i, list.get(i));
                        }
                    }else {
                        for (int i = 0;i < list.size(); i++){
                            mainList.add(i, list.get(i));
                        }
                    }

                    adapter = new MasterProductDetailsAdapter(mainList,ProductListPage.this);
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();

                    dialog.dismiss();

                    //Snackbar snackbar = Snackbar.make(rootLayout,masterProductDetailsResponse.message,Snackbar.LENGTH_LONG);
                    //snackbar.show();

                }else {
                    dialog.dismiss();

                    if (masterProductDetailsResponse.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Snackbar snackbar = Snackbar.make(rootLayout, "Session Expired!", 15000);
                        snackbar.setAction("Login again", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent(ProductListPage.this, LoginPage.class);
                                startActivity(intent);
                                customType(ProductListPage.this, "right-to-left");
                                finish();
                            }
                        });
                        snackbar.show();
                    }else {
                        Snackbar snackbar = Snackbar.make(rootLayout,masterProductDetailsResponse.message,Snackbar.LENGTH_LONG);
                        snackbar.show();
                    }


                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootLayout, "Poor Internet Connection!", 15000);
                    snackbar.setAction("Retry", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            loadData();
                        }
                    });
                    snackbar.show();
                }else {
                    Snackbar snackbar = Snackbar.make(rootLayout,""+throwable.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }


            }
        }));
    }
}