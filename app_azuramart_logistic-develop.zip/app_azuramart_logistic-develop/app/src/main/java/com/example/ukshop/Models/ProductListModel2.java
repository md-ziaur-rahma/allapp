package com.example.ukshop.Models;

import com.google.gson.annotations.SerializedName;

public class ProductListModel2 {
    @SerializedName("sku_id")
    public String sku_id;

    @SerializedName("mkt_id")
    public String mkt_id;

    @SerializedName("product_name")
    public String product_name;

    @SerializedName("product_variant_name")
    public String variant_name;

    @SerializedName("size")
    public String size;

    @SerializedName("color")
    public String color;

    @SerializedName("price")
    public float price;

    @SerializedName("variant_primary_image")
    public String variant_primary_image;

    @SerializedName("available_qty")
    public int available_qty;

    public ProductListModel2(String sku_id, String mkt_id, String product_name,
                             String variant_name, String size, String color,
                             float price, String variant_primary_image, int available_qty) {
        this.sku_id = sku_id;
        this.mkt_id = mkt_id;
        this.product_name = product_name;
        this.variant_name = variant_name;
        this.size = size;
        this.color = color;
        this.price = price;
        this.variant_primary_image = variant_primary_image;
        this.available_qty = available_qty;
    }

    public String getSku_id() {
        return sku_id;
    }

    public void setSku_id(String sku_id) {
        this.sku_id = sku_id;
    }

    public String getMkt_id() {
        return mkt_id;
    }

    public void setMkt_id(String mkt_id) {
        this.mkt_id = mkt_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getVariant_name() {
        return variant_name;
    }

    public void setVariant_name(String variant_name) {
        this.variant_name = variant_name;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getVariant_primary_image() {
        return variant_primary_image;
    }

    public void setVariant_primary_image(String variant_primary_image) {
        this.variant_primary_image = variant_primary_image;
    }

    public int getAvailable_qty() {
        return available_qty;
    }

    public void setAvailable_qty(int available_qty) {
        this.available_qty = available_qty;
    }
}
