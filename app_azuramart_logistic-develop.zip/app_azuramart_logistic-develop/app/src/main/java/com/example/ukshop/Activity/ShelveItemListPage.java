package com.example.ukshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.ukshop.Adapters.ShelveItemListAdapter;
import com.example.ukshop.Adapters.UnboxedItemAdapter;
import com.example.ukshop.Network.IRetrofitApi;
import com.example.ukshop.NetworkModel.ApiResponse;
import com.example.ukshop.NetworkModel.ShelveItemListPost;
import com.example.ukshop.NetworkModel.ShelveItemListResponse;
import com.example.ukshop.NetworkModel.UnboxedItemResponse;
import com.example.ukshop.R;
import com.example.ukshop.Utils.Common;
import com.example.ukshop.Utils.SharedPreperenceUtils;
import com.example.ukshop.Utils.Utils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class ShelveItemListPage extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private CoordinatorLayout rootlayout;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private IRetrofitApi mIRetrofitApi;


    private RecyclerView recyclerView;
    private ShelveItemListAdapter adapter;
    private List<ShelveItemListResponse.Data> mainList = new ArrayList<>();

    private MaterialToolbar toolbar;
    private Button scanShelve;

    private static boolean isShow = false;

    private static final int CAMERA_REQUEST_CODE = 501;

    Dialog scannerDialog;
    ZXingScannerView scannerView;
    private static boolean isFlash = false;

    private boolean isInvalid = false;

    private MediaPlayer rightTone = new MediaPlayer();
    private MediaPlayer wrongTone = new MediaPlayer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shelve_item_list);

        rightTone = MediaPlayer.create(this,R.raw.scanner_tone_2);
        wrongTone = MediaPlayer.create(this,R.raw.wrong_tone);

        mIRetrofitApi = Common.getApiArobil();
        initialFindFields();


        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new ShelveItemListAdapter(mainList,this);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        scanShelve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isCameraPermission(ShelveItemListPage.this)){
                    if (Utils.broadcastIntent(ShelveItemListPage.this,rootlayout)){
                        openScanner();
                    }else {
                        Utils.snackbarToast(rootlayout,"No Internet Connection!");
                    }
                }else {
                    ActivityCompat.requestPermissions(ShelveItemListPage.this,new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST_CODE);
                }
            }
        });

        scanShelve.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final Dialog dialog = new Dialog(ShelveItemListPage.this);
                dialog.setContentView(R.layout.barcod_picker_layout);

                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;

                dialog.getWindow().setLayout(width,height);
                dialog.setCancelable(true);
                dialog.show();

                final EditText barcodeText = dialog.findViewById(R.id.dialogeManuallyBarcodeTextId);
                final Button search = dialog.findViewById(R.id.boxingManuallySearchBtnID);
                Button cancel = dialog.findViewById(R.id.boxingManuallySearchCancelBtnID);
                barcodeText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(10)});

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String barcode = barcodeText.getText().toString();
                        if (!TextUtils.isEmpty(barcode)){
                            if (barcode.length() == 10){
                                dialog.dismiss();
                                loadData(barcode);
                            }else {
                                Toast.makeText(ShelveItemListPage.this,"This is not shelve label !",Toast.LENGTH_LONG).show();
                            }
                        }else {
                            Toast.makeText(ShelveItemListPage.this,"Enter Barcode !",Toast.LENGTH_LONG).show();
                        }
                    }
                });

                return false;
            }
        });


        /// Toolbar home button...
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        if (Utils.broadcastIntent(this,rootlayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootlayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootlayout,"No Internet Connection!",10000);
            snackbar.show();
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.broadcastIntent(this,rootlayout)){
            if (checkSession()){
                Utils.expiredTokenAlert(rootlayout,this);
            }
        }else {
            Snackbar snackbar = Snackbar.make(rootlayout,"No Internet Connection!",10000);
            snackbar.show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compositeDisposable != null){
            compositeDisposable.clear();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (compositeDisposable != null && !compositeDisposable.isDisposed()){
            compositeDisposable.dispose();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CAMERA_REQUEST_CODE){
            if (grantResults.length >= 0){
                openScanner();
            }else {
                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            }
        }
    }

    public boolean checkSession(){
        String token = SharedPreperenceUtils.getToken(this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(this));

        compositeDisposable.add(mIRetrofitApi.checkSession(token,user_id).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ApiResponse>() {
            @Override
            public void accept(ApiResponse response) throws Exception {
                if (response.status == 0) {
                    isInvalid = true;
                }
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        }));

        return isInvalid;
    }

    private void initialFindFields(){
        rootlayout = (CoordinatorLayout)findViewById(R.id.shelveItemListRootlayoutId);
        toolbar = (MaterialToolbar)findViewById(R.id.shelveItemListToolbarID);

        recyclerView = (RecyclerView)findViewById(R.id.shelveItemListRecyclerID);
        scanShelve = (Button)findViewById(R.id.scanshelveItemListBtnAID);
    }

    private void openScanner(){
        scannerDialog = new Dialog(ShelveItemListPage.this);
        scannerDialog.setContentView(R.layout.boxing_scaning_layout);

        int width = WindowManager.LayoutParams.MATCH_PARENT;
        int height = WindowManager.LayoutParams.MATCH_PARENT;

        scannerDialog.getWindow().setLayout(width,height);
        scannerDialog.setCancelable(true);
        scannerDialog.show();

        scannerView = scannerDialog.findViewById(R.id.boxingScannerID);
        ImageView scannerClose = scannerDialog.findViewById(R.id.boxingScannerCloseID);
        final ImageView scannerFlash = scannerDialog.findViewById(R.id.boxingScannerFlashID);



        scannerView.setAutoFocus(true);

        scannerView.setResultHandler(ShelveItemListPage.this);
        scannerView.startCamera();

        scannerClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scannerView.stopCamera();
                scannerDialog.dismiss();
            }
        });

        scannerFlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFlash){
                    scannerFlash.setImageResource(R.drawable.ic_flash_off);
                    scannerView.setFlash(false);
                    isFlash = false;
                }else {
                    scannerFlash.setImageResource(R.drawable.ic_flash_on);
                    scannerView.setFlash(true);
                    isFlash = true;
                }
            }
        });

    }

    private void loadData(String shelve_label){
        mainList = new ArrayList<>();
        adapter.updateList(mainList);

        final Dialog dialog = new Dialog(ShelveItemListPage.this);
        dialog.setContentView(R.layout.transparent_progress_dialoge);

        int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setLayout(width,height);
        dialog.setCancelable(false);
        dialog.show();

        String token = SharedPreperenceUtils.getToken(ShelveItemListPage.this);
        int user_id = Integer.parseInt(SharedPreperenceUtils.getUser(ShelveItemListPage.this));

        final ShelveItemListPost post = new ShelveItemListPost();
        post.user_id = user_id;
        post.shelve_label = shelve_label;
        post.sku_id = "";

        compositeDisposable.add(mIRetrofitApi.getShelveItemList(token,post).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<ShelveItemListResponse>() {
            @Override
            public void accept(ShelveItemListResponse response) throws Exception {

                if (response.status == 1){

                    rightTone.start();

                    mainList = response.data;
                    adapter.updateList(mainList);

                    dialog.dismiss();

                }else {

                    wrongTone.start();

                    dialog.dismiss();

                    if (response.message.toLowerCase().contains(Common.EXPIRED_TOKEN.toLowerCase())) {
                        Utils.expiredTokenAlert(rootlayout,ShelveItemListPage.this);
                    }else {
                        Utils.snackbarToast(rootlayout,response.message);
                    }
                }


            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

                wrongTone.start();

                dialog.dismiss();

                if (throwable.getMessage().toLowerCase().contains(Common.POOR_MSG.toLowerCase())) {
                    Snackbar snackbar = Snackbar.make(rootlayout, "Poor Internet Connection!", 5000);
                    snackbar.show();
                }else {
                    Utils.snackbarToast(rootlayout,throwable.getMessage());
                }
            }
        }));

    }

    @Override
    public void handleResult(Result rawResult) {

        if (!TextUtils.isEmpty(rawResult.getText())){
            if (rawResult.getText().length() == 10){
                scannerDialog.dismiss();
                scannerView.stopCamera();
                loadData(rawResult.getText());
            }else {
                wrongTone.start();

                scannerDialog.dismiss();
                scannerView.stopCamera();
                Utils.snackbarToast(rootlayout,"This is not shelve label!");
            }
        }else {

            wrongTone.start();

            scannerDialog.dismiss();
            scannerView.stopCamera();
            Utils.snackbarToast(rootlayout,"Barcode is empty!");
        }




    }
}